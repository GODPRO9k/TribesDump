local Remotes = {}

local Remote_1 = game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents"):WaitForChild("ChannelNameColorUpdated")
Remote_1.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"DefaultChatSystemChatEvents\"):WaitForChild(\"ChannelNameColorUpdated\")"] = Remote_1

local Remote_2 = game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents"):WaitForChild("GetInitDataRequest")
Remote_2.__ClassName = "RemoteFunction"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"DefaultChatSystemChatEvents\"):WaitForChild(\"GetInitDataRequest\")"] = Remote_2

local Remote_3 = game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents"):WaitForChild("MutePlayerRequest")
Remote_3.__ClassName = "RemoteFunction"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"DefaultChatSystemChatEvents\"):WaitForChild(\"MutePlayerRequest\")"] = Remote_3

local Remote_4 = game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents"):WaitForChild("OnChannelJoined")
Remote_4.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"DefaultChatSystemChatEvents\"):WaitForChild(\"OnChannelJoined\")"] = Remote_4

local Remote_5 = game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents"):WaitForChild("OnChannelLeft")
Remote_5.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"DefaultChatSystemChatEvents\"):WaitForChild(\"OnChannelLeft\")"] = Remote_5

local Remote_6 = game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents"):WaitForChild("OnMainChannelSet")
Remote_6.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"DefaultChatSystemChatEvents\"):WaitForChild(\"OnMainChannelSet\")"] = Remote_6

local Remote_7 = game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents"):WaitForChild("OnMessageDoneFiltering")
Remote_7.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"DefaultChatSystemChatEvents\"):WaitForChild(\"OnMessageDoneFiltering\")"] = Remote_7

local Remote_8 = game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents"):WaitForChild("OnMuted")
Remote_8.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"DefaultChatSystemChatEvents\"):WaitForChild(\"OnMuted\")"] = Remote_8

local Remote_9 = game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents"):WaitForChild("OnNewMessage")
Remote_9.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"DefaultChatSystemChatEvents\"):WaitForChild(\"OnNewMessage\")"] = Remote_9

local Remote_10 = game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents"):WaitForChild("OnNewSystemMessage")
Remote_10.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"DefaultChatSystemChatEvents\"):WaitForChild(\"OnNewSystemMessage\")"] = Remote_10

local Remote_11 = game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents"):WaitForChild("OnUnmuted")
Remote_11.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"DefaultChatSystemChatEvents\"):WaitForChild(\"OnUnmuted\")"] = Remote_11

local Remote_12 = game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents"):WaitForChild("SayMessageRequest")
Remote_12.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"DefaultChatSystemChatEvents\"):WaitForChild(\"SayMessageRequest\")"] = Remote_12

local Remote_13 = game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents"):WaitForChild("SetBlockedUserIdsRequest")
Remote_13.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"DefaultChatSystemChatEvents\"):WaitForChild(\"SetBlockedUserIdsRequest\")"] = Remote_13

local Remote_14 = game:GetService("ReplicatedStorage"):WaitForChild("DefaultChatSystemChatEvents"):WaitForChild("UnMutePlayerRequest")
Remote_14.__ClassName = "RemoteFunction"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"DefaultChatSystemChatEvents\"):WaitForChild(\"UnMutePlayerRequest\")"] = Remote_14

local Remote_15 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("AnalyticsReport")
Remote_15.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"AnalyticsReport\")"] = Remote_15

local Remote_16 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("AnimRelay")
Remote_16.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"AnimRelay\")"] = Remote_16

local Remote_17 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("CombatFX")
Remote_17.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"CombatFX\")"] = Remote_17

local Remote_18 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("CustomAction")
Remote_18.__ClassName = "RemoteFunction"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"CustomAction\")"] = Remote_18

local Remote_19 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("CustomHost")
Remote_19.__ClassName = "RemoteFunction"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"CustomHost\")"] = Remote_19

local Remote_20 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("CustomState")
Remote_20.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"CustomState\")"] = Remote_20

local Remote_21 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("DamageTaken")
Remote_21.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"DamageTaken\")"] = Remote_21

local Remote_22 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("EconomyEvent")
Remote_22.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"EconomyEvent\")"] = Remote_22

local Remote_23 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("GetMatchState")
Remote_23.__ClassName = "RemoteFunction"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"GetMatchState\")"] = Remote_23

local Remote_24 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("GetProfile")
Remote_24.__ClassName = "RemoteFunction"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"GetProfile\")"] = Remote_24

local Remote_25 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("HitConfirm")
Remote_25.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"HitConfirm\")"] = Remote_25

local Remote_26 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("Leaderboards")
Remote_26.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"Leaderboards\")"] = Remote_26

local Remote_27 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("LetterAction")
Remote_27.__ClassName = "RemoteFunction"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"LetterAction\")"] = Remote_27

local Remote_28 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("MatchEvent")
Remote_28.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"MatchEvent\")"] = Remote_28

local Remote_29 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("MatchState")
Remote_29.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"MatchState\")"] = Remote_29

local Remote_30 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("ModAction")
Remote_30.__ClassName = "RemoteFunction"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"ModAction\")"] = Remote_30

local Remote_31 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("ModEvent")
Remote_31.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"ModEvent\")"] = Remote_31

local Remote_32 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("NewsAction")
Remote_32.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"NewsAction\")"] = Remote_32

local Remote_33 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("Notify")
Remote_33.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"Notify\")"] = Remote_33

local Remote_34 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("PartyAction")
Remote_34.__ClassName = "RemoteFunction"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"PartyAction\")"] = Remote_34

local Remote_35 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("PartyState")
Remote_35.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"PartyState\")"] = Remote_35

local Remote_36 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("Ping")
Remote_36.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"Ping\")"] = Remote_36

local Remote_37 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("ProfileAction")
Remote_37.__ClassName = "RemoteFunction"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"ProfileAction\")"] = Remote_37

local Remote_38 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("ProfileChanged")
Remote_38.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"ProfileChanged\")"] = Remote_38

local Remote_39 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("QueueAction")
Remote_39.__ClassName = "RemoteFunction"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"QueueAction\")"] = Remote_39

local Remote_40 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("StoreAction")
Remote_40.__ClassName = "RemoteFunction"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"StoreAction\")"] = Remote_40

local Remote_41 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("TribeAction")
Remote_41.__ClassName = "RemoteFunction"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"TribeAction\")"] = Remote_41

local Remote_42 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("TribeEvent")
Remote_42.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"TribeEvent\")"] = Remote_42

local Remote_43 = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("WeaponAction")
Remote_43.__ClassName = "RemoteEvent"
Remotes["game:GetService(\"ReplicatedStorage\"):WaitForChild(\"Remotes\"):WaitForChild(\"WeaponAction\")"] = Remote_43

return Remotes