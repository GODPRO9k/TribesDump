local v_u_1 = game:GetService("ContextActionService")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = game:GetService("Workspace")
local v7 = require(script:WaitForChild("Spring"))
local v_u_8 = require(script:WaitForChild("Spectate"))
local v_u_9 = require(script:WaitForChild("Fighters"))
local v_u_10 = require(script:WaitForChild("Fades"))
local v_u_11 = require(script:WaitForChild("AimAssist"))
local v_u_12 = require(script:WaitForChild("SpectateKeys"))
local v_u_13 = require(script:WaitForChild("Smoothing"))
local v_u_14 = require(script:WaitForChild("Occlusion"))
local v_u_15 = require(script:WaitForChild("FirstPerson"))
local v_u_16 = require(script:WaitForChild("Guards"))
local v_u_17 = require(script.Parent:WaitForChild("Simulation"))
local v_u_18 = require(script:WaitForChild("Finite"))
local v19 = v_u_17.Authority
v_u_18.Authority = tostring(v19)
local v_u_20 = require(script.Parent:WaitForChild("Keybinds"))
local v_u_21 = {
	["PadLook"] = require(script:WaitForChild("PadLook"))
}
local v_u_22 = v_u_4:IsClient()
if v_u_22 then
	v_u_22 = not v_u_4:IsServer()
end
local v_u_23 = v_u_3.LocalPlayer
local v_u_24 = 0
local v_u_25 = -0.20943951023931956
local v_u_26 = 1
local v_u_27 = false
local v_u_28 = 50
local v_u_29 = 70
local v_u_30 = 10.5
local v_u_31 = 1
local v_u_32 = true
local v_u_33 = false
local v_u_34 = {}
local v_u_35 = {}
local v_u_36 = {}
local v_u_37 = {}
local v_u_38 = {}
local v_u_39 = v7.new(70, 3.2, 1)
local v_u_40 = v7.new(10.5, 3.5, 1)
local v_u_41 = v7.new(2.9, 3.5, 1)
local v_u_42 = v7.new(Vector3.new(0, 0, 0), 4, 1)
local v_u_43 = v7.new(0, 5, 1)
local v_u_44 = v7.new(0, 3.2, 0.45)
local v_u_45 = v7.new(Vector3.new(0, 0, 0), 5, 0.75)
local v_u_46 = 0
local v_u_47 = 0
local v_u_48 = 0
local v_u_49 = os.clock()
local v_u_50 = 0
local v_u_51 = false
local v_u_52 = nil
local v_u_53 = 0
local v_u_54 = 0
local v_u_55 = 1.6666666666666667
local v_u_56 = 0
local v_u_57 = nil
local v_u_58 = CFrame.new()
local v_u_59 = 70
local v_u_60 = nil
local v_u_61 = nil
local v_u_62 = false
local v_u_63 = false
local v_u_64 = false
local v_u_65 = false
local v_u_66 = nil
local v_u_67 = 70
local v_u_68 = 1
local v_u_69 = nil
local v_u_70 = false
local v_u_71 = 1
local v_u_72 = Vector2.zero
local v_u_73 = Vector2.zero
local v_u_74 = 0
local v_u_75 = 0
local v_u_76 = {}
local v_u_77 = nil
local v_u_78 = "none"
local v_u_79 = CFrame.new()
local v_u_80 = 70
local v_u_81 = nil
local v_u_82 = nil
local v_u_83 = 70
local v_u_84 = 1
local v_u_85 = CFrame.new()
local v_u_86 = 70
local v_u_87 = nil
local v_u_88 = {
	["amount"] = 0,
	["t0"] = 0,
	["rise"] = 0.05,
	["fall"] = 0.2
}
local function v_u_97() -- name: fovKickNow
	-- upvalues: (copy) v_u_88
	local v89 = v_u_88
	if v89.amount == 0 then
		return 0
	end
	local v90 = os.clock() - v89.t0
	if v90 < v89.rise then
		local v91 = v89.amount
		local v92 = v90 / v89.rise
		local v93 = math.clamp(v92, 0, 1)
		return v91 * (v93 * v93 * (3 - v93 * 2))
	end
	local v94 = (v90 - v89.rise) / v89.fall
	if v94 >= 1 then
		v89.amount = 0
		return 0
	end
	local v95 = v89.amount
	local v96 = math.clamp(v94, 0, 1)
	return v95 * (1 - v96 * v96 * (3 - v96 * 2))
end
local v_u_98 = {}
local v_u_99 = true
local v_u_100 = 0
local v_u_101 = nil
local v_u_102 = true
local v_u_103 = { "FX", "Projectiles" }
local function v_u_104() -- name: markIgnoreDirty
	-- upvalues: (ref) v_u_99
	v_u_99 = true
end
local function v_u_116(p_u_105) -- name: ignoreList
	-- upvalues: (ref) v_u_99, (ref) v_u_101, (ref) v_u_100, (copy) v_u_98, (copy) v_u_103, (copy) v_u_6, (copy) v_u_3, (copy) v_u_9, (copy) v_u_14, (ref) v_u_102
	local v106 = os.clock()
	if v_u_99 or (p_u_105 ~= v_u_101 or v106 - v_u_100 > 2) then
		table.clear(v_u_98)
		if p_u_105 then
			local v107 = v_u_98
			table.insert(v107, p_u_105)
		end
		for _, v108 in v_u_103 do
			local v109 = v_u_6:FindFirstChild(v108)
			if not v109 then
				continue
			end
			local v110 = v_u_98
			table.insert(v110, v109)
		end
		for _, v111 in v_u_3:GetPlayers() do
			if not v111.Character or v111.Character == p_u_105 then
				continue
			end
			local v112 = v_u_98
			local v113 = v111.Character
			table.insert(v112, v113)
		end
		v_u_9.EachTagged(function(p114)
			-- upvalues: (copy) p_u_105, (ref) v_u_98
			if p114 ~= p_u_105 then
				local v115 = v_u_98
				table.insert(v115, p114)
			end
		end)
		v_u_99 = false
		v_u_101 = p_u_105
		v_u_100 = v106
		v_u_14.IgnoreChanged()
		v_u_102 = true
	end
	return v_u_98
end
local v_u_117 = {}
local v_u_118 = true
local v_u_119 = {}
local v_u_120 = -1
local v_u_121 = -1
local v_u_122 = false
local v_u_123 = false
local v_u_124 = Instance.new("BindableEvent")
local v_u_125 = nil
local v_u_126 = 0
local function v_u_130(p127, p128) -- name: isHeadAccessoryPart
	for _, v129 in p127:GetChildren() do
		if not (v129:IsA("Attachment") and p128:FindFirstChild(v129.Name)) then
			continue
		end
		return true
	end
	return false
end
local function v_u_136(p131) -- name: rebuildFadeEntries
	-- upvalues: (copy) v_u_117, (copy) v_u_130, (ref) v_u_118
	table.clear(v_u_117)
	local v132 = p131:FindFirstChild("Head")
	for _, v133 in p131:GetDescendants() do
		if not (v133:IsA("BasePart") or v133:IsA("Decal")) then
			continue
		end
		local v134 = false
		if v132 and v132:IsA("BasePart") then
			if v133 == v132 or v133.Parent == v132 then
				v134 = true
			elseif v133:IsA("BasePart") and (v133.Parent and v133.Parent:IsA("Accessory")) then
				v134 = v_u_130(v133, v132)
			end
		end
		local v135 = v_u_117
		table.insert(v135, {
			["inst"] = v133,
			["head"] = v134
		})
	end
	v_u_118 = false
end
local function v_u_166(p137, p138, p139, p140) -- name: setCharacterFade
	-- upvalues: (ref) v_u_125, (copy) v_u_117, (copy) v_u_119, (ref) v_u_118, (ref) v_u_120, (ref) v_u_121, (ref) v_u_122, (copy) v_u_136, (ref) v_u_126
	local v141 = p138 < 0.01 and 0 or p138
	local v142 = math.max(v141, p139 or 0)
	local v143 = v142 < 0.01 and 0 or v142
	if p137 ~= v_u_125 then
		for _, v144 in v_u_117 do
			local v145 = v144.inst
			if not v145.Parent or v145.LocalTransparencyModifier == 0 then
				continue
			end
			v145.LocalTransparencyModifier = 0
		end
		for _, v146 in v_u_119 do
			v146:Disconnect()
		end
		table.clear(v_u_119)
		table.clear(v_u_117)
		v_u_125 = p137
		v_u_118 = true
		v_u_120 = -1
		v_u_121 = -1
		v_u_122 = false
		if p137 then
			local v147 = v_u_119
			local v148 = p137.DescendantAdded
			local function v152(p149)
				-- upvalues: (ref) v_u_118, (ref) v_u_122, (ref) v_u_120
				v_u_118 = true
				if p149:IsA("BasePart") or p149:IsA("Decal") then
					local v150
					if v_u_122 then
						v150 = 1
					else
						local v151 = v_u_120
						v150 = math.max(v151, 0)
					end
					p149.LocalTransparencyModifier = v150
				end
			end
			table.insert(v147, v148:Connect(v152))
			local v153 = v_u_119
			local v154 = p137.DescendantRemoving
			local function v155()
				-- upvalues: (ref) v_u_118
				v_u_118 = true
			end
			table.insert(v153, v154:Connect(v155))
		end
	end
	if p137 then
		local v156 = v_u_118
		if v_u_118 then
			v_u_136(p137)
		end
		local v157 = os.clock()
		local v158 = v156 or v157 - v_u_126 > 0.25
		local v159 = v141 - v_u_120
		local v160
		if math.abs(v159) >= 0.02 then
			v160 = true
		else
			local v161 = v143 - v_u_121
			v160 = (math.abs(v161) >= 0.02 or v141 == 0 and v_u_120 ~= 0 or v143 == 0 and v_u_121 ~= 0) and true or p140 == true ~= v_u_122
		end
		if v158 or v160 then
			v_u_126 = v157
			v_u_120 = v141
			v_u_121 = v143
			v_u_122 = p140 == true
			for _, v162 in v_u_117 do
				local v163 = v162.inst
				if not v163.Parent then
					continue
				end
				local v164
				if v_u_122 then
					v164 = 1
				elseif v162.head then
					v164 = v143
				else
					v164 = v141
				end
				local v165 = v163.LocalTransparencyModifier - v164
				if math.abs(v165) <= 0.001 then
					continue
				end
				v163.LocalTransparencyModifier = v164
			end
		end
	else
		return
	end
end
local v_u_167 = {}
local v_u_168 = {
	["High"] = 1,
	["Medium"] = 2,
	["Low"] = 4
}
local v_u_169 = 1
local v_u_170 = 0
local v_u_171 = {}
local v_u_172 = OverlapParams.new()
v_u_172.FilterType = Enum.RaycastFilterType.Exclude
local function v_u_186(p173, p174) -- name: boxDistance
	local v175 = p173.CFrame:PointToObjectSpace(p174)
	local v176 = p173.Size * 0.5
	local v177 = v175.X
	local v178 = math.abs(v177) - v176.X
	local v179 = math.max(v178, 0)
	local v180 = v175.Y
	local v181 = math.abs(v180) - v176.Y
	local v182 = math.max(v181, 0)
	local v183 = v175.Z
	local v184 = math.abs(v183) - v176.Z
	local v185 = math.max(v184, 0)
	return Vector3.new(v179, v182, v185).Magnitude
end
local function v_u_198(p187) -- name: propFadeable
	if p187.Transparency >= 1 or (p187:HasTag("Foliage") or p187.Size.Magnitude >= 80) then
		return false
	end
	local v188 = p187.Size
	local v189 = v188.X
	local v190 = v188.Y
	local v191 = math.min(v189, v190)
	local v192 = v188.X
	local v193 = v188.Y
	local v194 = math.max(v192, v193)
	local v195 = v188.Z
	local v196 = math.min(v194, v195)
	if math.max(v191, v196) >= 6 then
		return false
	end
	local v197 = p187:FindFirstAncestorWhichIsA("Model")
	while v197 do
		if v197:FindFirstChildOfClass("Humanoid") or v197:HasTag("BearTrap") then
			return false
		end
		v197 = v197:FindFirstAncestorWhichIsA("Model")
	end
	return true
end
local v_u_199 = RaycastParams.new()
v_u_199.FilterType = Enum.RaycastFilterType.Exclude
local function v_u_211(p_u_200, p201, p202) -- name: updatePropFade
	-- upvalues: (ref) v_u_102, (copy) v_u_172, (copy) v_u_171, (copy) v_u_6, (copy) v_u_198, (copy) v_u_186, (copy) v_u_167, (copy) v_u_199, (copy) v_u_14
	if v_u_102 then
		v_u_172.FilterDescendantsInstances = p202
		v_u_102 = false
	end
	table.clear(v_u_171)
	local function v203()
		-- upvalues: (ref) v_u_6, (copy) p_u_200, (ref) v_u_172
		return v_u_6:GetPartBoundsInRadius(p_u_200, 4.2, v_u_172)
	end
	local v204, v205 = pcall(v203)
	if v204 then
		for _, v206 in v205 do
			if v206.Position.Y + v206.Size.Y / 2 <= p_u_200.Y - 1 or not v_u_198(v206) or v_u_186(v206, p_u_200) > (v_u_167[v206] and 0.7 or 0) + 3.5 then
				continue
			end
			v_u_171[v206] = true
			if v_u_167[v206] then
				continue
			end
			v_u_167[v206] = true
			v206.LocalTransparencyModifier = 0.7
		end
	end
	if p201 then
		v_u_199.FilterDescendantsInstances = p202
		for _ = 1, 4 do
			local v207 = p201 - p_u_200
			local v208 = v207.Magnitude >= 0.05 and v_u_6:Raycast(p_u_200, v207, v_u_199)
			if not v208 then
				break
			end
			local v209 = v208.Instance
			if v209:IsA("BasePart") and (v_u_14.Classify(v209) == 2 and v_u_198(v209)) then
				v_u_171[v209] = true
				if not v_u_167[v209] then
					v_u_167[v209] = true
					v209.LocalTransparencyModifier = 0.7
				end
			end
			v_u_199:AddToFilter(v209)
			p_u_200 = v208.Position
		end
	end
	for v210 in v_u_167 do
		if v_u_171[v210] then
			continue
		end
		v_u_167[v210] = nil
		if not v210.Parent then
			continue
		end
		v210.LocalTransparencyModifier = 0
	end
end
local function v_u_217() -- name: totalModifier
	-- upvalues: (copy) v_u_37
	local v212 = 0
	local v213 = 0
	local v214 = Vector3.new(0, 0, 0)
	local v215 = 1
	for _, v216 in v_u_37 do
		v212 = v212 + (v216.fov or 0)
		v213 = v213 + (v216.distance or 0)
		v214 = v214 + (v216.pivot or Vector3.new(0, 0, 0))
		v215 = v215 * (v216.sensitivity or 1)
	end
	return v212, v213, v214, v215
end
local function v_u_218() -- name: applyMouseBehavior
	-- upvalues: (ref) v_u_32, (ref) v_u_64, (copy) v_u_34, (copy) v_u_2, (copy) v_u_5
	if v_u_32 and not v_u_64 then
		if next(v_u_34) ~= nil and true or v_u_2.MenuIsOpen then
			if v_u_5.MouseBehavior ~= Enum.MouseBehavior.Default then
				v_u_5.MouseBehavior = Enum.MouseBehavior.Default
			end
			if not v_u_5.MouseIconEnabled then
				v_u_5.MouseIconEnabled = true
				return
			end
		else
			if v_u_5.MouseBehavior ~= Enum.MouseBehavior.LockCenter then
				v_u_5.MouseBehavior = Enum.MouseBehavior.LockCenter
			end
			if v_u_5.MouseIconEnabled then
				v_u_5.MouseIconEnabled = false
			end
		end
	end
end
local v_u_219 = {
	[Enum.HumanoidStateType.Running] = true,
	[Enum.HumanoidStateType.RunningNoPhysics] = true,
	[Enum.HumanoidStateType.Jumping] = true,
	[Enum.HumanoidStateType.Freefall] = true,
	[Enum.HumanoidStateType.Landed] = true,
	[Enum.HumanoidStateType.GettingUp] = true
}
local function v_u_232(p220, p221, p222, p223) -- name: updateCharacterRotation
	-- upvalues: (copy) v_u_36, (copy) v_u_219, (ref) v_u_62, (ref) v_u_63, (copy) v_u_17, (copy) v_u_13, (ref) v_u_24, (ref) v_u_27, (ref) v_u_123
	local v224 = not p223 and (next(v_u_36) == nil and p222.Health > 0 and not p221.Anchored)
	if v224 then
		if v_u_219[p222:GetState()] == true and p222.Sit == false then
			v224 = p222.PlatformStand == false
		else
			v224 = false
		end
	end
	if v224 then
		v_u_63 = true
		local _, v225, _ = v_u_13.SimCFrame(p221):ToEulerAnglesYXZ()
		local v226 = (v_u_24 - v225 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
		local v227 = p222.MoveDirection.Magnitude > 0.05
		local v228
		if p221.Parent == nil then
			v228 = false
		else
			v228 = p221.Parent:FindFirstChildOfClass("Tool") ~= nil
		end
		local v229 = v227 or (v228 or (v_u_27 or v_u_123))
		if v229 then
			v_u_62 = false
		else
			if math.abs(v226) > 1.7453292519943295 then
				v_u_62 = true
			end
			if v_u_62 and math.abs(v226) < 0.06981317007977318 then
				v_u_62 = false
			end
			v229 = v_u_62
		end
		if v229 then
			local v230 = -(v_u_123 and 40 or ((v_u_27 or v228) and 30 or (v227 and 18 or 12))) * math.max(p220, 0.016666666666666666)
			local v231 = v225 + v226 * (1 - math.exp(v230))
			v_u_17.SetFacing(v231)
		else
			v_u_17.SetFacing(v225)
		end
	else
		v_u_62 = false
		if v_u_63 then
			v_u_17.SetFacing(nil)
			v_u_63 = false
		end
		return
	end
end
local v_u_233 = {
	Vector3.new(-1, -1, -1),
	Vector3.new(-1, -1, 1),
	Vector3.new(-1, 1, -1),
	Vector3.new(-1, 1, 1),
	Vector3.new(1, -1, -1),
	Vector3.new(1, -1, 1),
	Vector3.new(1, 1, -1),
	Vector3.new(1, 1, 1)
}
local function v_u_259(p234, p235) -- name: headCrowdsCrosshair
	-- upvalues: (copy) v_u_117, (copy) v_u_233
	local v236 = p234.ViewportSize / 2
	local v237 = p234.ViewportSize.Y
	local v238 = (p235 and 40 or 16) * math.max(v237, 200) / 768
	for _, v239 in v_u_117 do
		local v240 = v239.inst
		if not (v239.head and (v240:IsA("BasePart") and v240.Parent)) then
			continue
		end
		local v241 = v240.CFrame
		local v242 = v240.Size / 2
		local v243 = (1 / 0)
		local v244 = (-1 / 0)
		local v245 = (1 / 0)
		local v246 = (-1 / 0)
		for _, v247 in v_u_233 do
			local v248 = p234:WorldToViewportPoint(v241:PointToWorldSpace(v242 * v247))
			if v248.Z <= 0 then
				continue
			end
			local v249 = v248.X
			v243 = math.min(v243, v249)
			local v250 = v248.X
			v244 = math.max(v244, v250)
			local v251 = v248.Y
			v245 = math.min(v245, v251)
			local v252 = v248.Y
			v246 = math.max(v246, v252)
		end
		if v243 > v244 then
			break
		end
		local v253 = v243 - v236.X
		local v254 = v236.X - v244
		local v255 = math.max(v253, 0, v254)
		local v256 = v245 - v236.Y
		local v257 = v236.Y - v246
		local v258 = math.max(v256, 0, v257)
		if v255 * v255 + v258 * v258 >= v238 * v238 then
			break
		end
		return true
	end
	return false
end
local function v_u_284(p260, p261, p262, p263) -- name: frameSubject
	-- upvalues: (copy) v_u_18, (ref) v_u_85, (ref) v_u_61, (ref) v_u_60, (copy) v_u_43, (copy) v_u_14, (ref) v_u_24, (copy) v_u_45, (copy) v_u_21, (ref) v_u_25, (copy) v_u_40, (copy) v_u_44, (copy) v_u_42, (copy) v_u_41, (ref) v_u_71, (ref) v_u_26
	if not v_u_18.Vector(p262) then
		return v_u_85, v_u_85.Position + v_u_85.LookVector * 10
	end
	if p261 ~= v_u_61 or (v_u_60 == nil or (p262 - v_u_60).Magnitude > 40) then
		v_u_43:Snap(p262.Y)
		v_u_14.Reset()
		v_u_61 = p261
	end
	v_u_60 = p262
	v_u_43.target = p262.Y
	v_u_43:Update(p260)
	local v264 = v_u_43.value
	local v265 = p262.Y - 1.5
	local v266 = p262.Y + 1.5
	local v267 = math.clamp(v264, v265, v266)
	v_u_43.value = v267
	local v268 = CFrame.fromEulerAnglesYXZ(0, v_u_24, 0)
	local v269 = v_u_45.value + v_u_21.SlowRecoil.value
	local v270 = CFrame.fromEulerAnglesYXZ(v_u_25 + v269.X, v_u_24 + v269.Y, v269.Z)
	local v271 = v270.LookVector
	local v272 = v_u_40.value
	local v273 = p262.X
	local v274 = v267 + 3.1 + v_u_44.value
	local v275 = p262.Z
	local v276 = Vector3.new(v273, v274, v275) + v268:VectorToWorldSpace(v_u_42.value)
	local v277 = p262.X
	local v278 = p262.Y + 0.5
	local v279 = p262.Z
	local v280 = Vector3.new(v277, v278, v279)
	local v281, v282, v283 = v_u_14.Frame(p260, v280, v276, v268.RightVector, v271, v_u_41.value, v272, p263)
	v_u_71 = v_u_14.Side(v283, v268.RightVector, 2.9, v_u_26, p263)
	return CFrame.new(v281) * v270.Rotation, v282
end
local function v_u_300(p285, p286, p287) -- name: applyShake
	-- upvalues: (copy) v_u_38
	local v288 = 0
	for v289 = #v_u_38, 1, -1 do
		local v290 = v_u_38[v289]
		v290.t = v290.t + p286
		if v290.t >= v290.duration then
			table.remove(v_u_38, v289)
		else
			local v291 = 1 - v290.t / v290.duration
			v288 = v288 + v290.intensity * v291 * v291
		end
	end
	if v288 <= 0 then
		return p285
	end
	local v292 = math.min(v288, 3) * (p287 or 1)
	local v293 = os.clock() * 17
	local v294 = v292 * 0.022689280275926284
	local v295 = math.noise(v293, 0.37, 1.1) * 2 * v294
	local v296 = math.noise(3.1, v293, 7.3) * 2 * v294
	local v297 = math.noise(9.2, 4.4, v293) * 1.2 * v294
	local v298 = math.noise(v293, 11.3, 2.9) * 0.12 * v292
	local v299 = math.noise(5.5, v293, 13.7) * 0.12 * v292
	return p285 * CFrame.new(v298, v299, 0) * CFrame.Angles(v295, v296, v297)
end
local function v_u_304(p301) -- name: focusPointOf
	local v302 = p301:FindFirstChild("Head")
	if v302 and v302:IsA("BasePart") then
		return v302.Position - Vector3.new(0, 0.6, 0)
	else
		local v303 = p301:FindFirstChild("HumanoidRootPart")
		if v303 and v303:IsA("BasePart") then
			return v303.Position + Vector3.new(0, 1, 0)
		else
			return nil
		end
	end
end
local v_u_305 = OverlapParams.new()
v_u_305.FilterType = Enum.RaycastFilterType.Exclude
v_u_305.RespectCanCollide = true
local v_u_306 = nil
local v_u_307 = nil
local v_u_308 = 0
local function v_u_322(p309, p310, p311) -- name: pickDeathSpot
	-- upvalues: (ref) v_u_307, (copy) v_u_14, (copy) v_u_305, (copy) v_u_6
	local v312 = v_u_307
	if v312 and v_u_14.Cast(v312, p310, p311) >= (p310 - v312).Magnitude - 0.5 then
		return v312
	end
	local v313 = p309.X - p310.X
	local v314 = p309.Z - p310.Z
	local v315 = Vector3.new(v313, 0, v314)
	local v316 = v315.Magnitude <= 0.1 and Vector3.new(0, 0, 1) or v315.Unit
	for v317, v_u_318 in {
		p309,
		p309 + Vector3.new(0, 7, 0),
		p309 + Vector3.new(0, 14, 0),
		p310 + v316 * 16 + Vector3.new(0, 8, 0),
		p310 + v316 * 11 + Vector3.new(0, 4, 0),
		p310 + v316 * 14 + Vector3.new(0, 18, 0)
	} do
		if v_u_14.Cast(v_u_318, p310, p311) < (p310 - v_u_318).Magnitude - 0.5 then
			continue
		end
		if v317 ~= 1 then
			v_u_305.FilterDescendantsInstances = p311
			local function v319()
				-- upvalues: (ref) v_u_6, (copy) v_u_318, (ref) v_u_305
				return v_u_6:GetPartBoundsInRadius(v_u_318, 0.6, v_u_305)
			end
			local v320, v321 = pcall(v319)
			if v320 then
				v320 = #v321 == 0
			end
			if not v320 then
				continue
			end
		end
		return v_u_318
	end
	return p309 + Vector3.new(0, 10, 0)
end
local function v_u_345(p323) -- name: deathView
	-- upvalues: (copy) v_u_8, (ref) v_u_79, (copy) v_u_304, (ref) v_u_29, (ref) v_u_307, (ref) v_u_308, (copy) v_u_322, (copy) v_u_116, (copy) v_u_23, (ref) v_u_306, (ref) v_u_81, (ref) v_u_80
	local v324 = v_u_8.DeathElapsed() / 0.35
	local v325 = math.clamp(v324, 0, 1)
	local v326 = v325 * v325 * (3 - v325 * 2)
	local v327 = v_u_79
	local v328 = v_u_8.GetKiller()
	local v329
	if v328 and v328.Parent then
		v329 = v_u_304(v328)
	else
		v329 = nil
	end
	local v330 = v_u_29
	local v331
	if v329 then
		local v332 = os.clock()
		if v_u_307 == nil or v332 - v_u_308 > 0.25 then
			v_u_308 = v332
			v_u_307 = v_u_322(v327.Position, v329, (v_u_116(v_u_23.Character)))
		end
		v331 = v_u_307
	else
		v331 = v327.Position + Vector3.new(0, 3, 0)
		v329 = v_u_8.GetDeathPosition() or v327.Position + v327.LookVector * 10
	end
	if v_u_306 == nil then
		v_u_306 = v327.Position
	end
	local v333 = v_u_306
	local v334 = p323 * -5
	v_u_306 = v333:Lerp(v331, 1 - math.exp(v334))
	local v335 = v_u_306
	if v328 and v328.Parent then
		local v336 = (v329 - v335).Magnitude
		local v337 = 9 / math.max(v336, 1)
		local v338 = math.atan(v337)
		local v339 = math.deg(v338) * 2
		local v340 = v_u_29
		v330 = math.clamp(v339, 35, v340)
	end
	if v_u_81 == nil then
		v_u_81 = v329
	else
		local v341 = v_u_81
		local v342 = p323 * -8
		v_u_81 = v341:Lerp(v329, 1 - math.exp(v342))
	end
	local v343 = v_u_81
	local v344
	if (v343 - v335).Magnitude > 0.1 then
		v344 = CFrame.lookAt(v335, v343)
	else
		v344 = CFrame.new(v335) * v327.Rotation
	end
	return v327.Rotation:Lerp(v344.Rotation, v326) + v335, v_u_80 + (v330 - v_u_80) * v326
end
local function v_u_379(p346, p347, p348) -- name: readLookInput
	-- upvalues: (ref) v_u_31, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (copy) v_u_5, (ref) v_u_24, (ref) v_u_25, (ref) v_u_73, (copy) v_u_11, (copy) v_u_21, (ref) v_u_72, (copy) v_u_23, (copy) v_u_116, (copy) v_u_37, (ref) v_u_74
	local v349 = v_u_31 * p348
	if v_u_27 then
		local v350 = v_u_28 / v_u_29
		v349 = v349 * math.clamp(v350, 0.35, 1)
	end
	if not p347 then
		if v_u_5.MouseBehavior == Enum.MouseBehavior.LockCenter and v_u_5:GetLastInputType() ~= Enum.UserInputType.Touch then
			local v351 = v_u_5:GetMouseDelta()
			local v352 = 0.006283185307179587 * v349
			v_u_24 = v_u_24 - v351.X * v352
			v_u_25 = v_u_25 - v351.Y * v352
		end
		v_u_73 = v_u_73 + v_u_11.TakeInjected()
		local v353, v354 = v_u_21.PadLook.Step(v_u_72, p346, v_u_27)
		local v355 = v353 * (v349 / v_u_31)
		local v356 = v354 * (v349 / v_u_31)
		local v357 = v355 - v_u_73.X * 0.01745 * v349
		local v358 = -v_u_73.Y * 0.01745 * 0.66 * v349
		if v358 * v_u_25 > 0 then
			local v359 = v_u_25
			local v360 = math.abs(v359)
			v358 = v358 * ((1 - (math.min(v360, 1.5707963267948966) * 2 / 3.141592653589793) ^ 0.75) * 0.75 + 0.25)
		end
		local v361 = v356 + v358
		local v362 = v_u_11.Apply
		local v363 = v_u_24
		local v364 = v_u_25
		local v365 = v_u_23:GetAttribute("CombatMode")
		local v366
		if v365 == nil then
			v366 = v_u_23:GetAttribute("State") == "Match"
		else
			v366 = v365 == true
		end
		local v367, v368 = v362(p346, v357, v361, v363, v364, v366, v_u_116(v_u_23.Character), v_u_27, v_u_28, v_u_37.CombatDraw ~= nil)
		v_u_24 = v_u_24 + v367
		v_u_25 = v_u_25 + v368
		local v369 = v_u_74
		local v370 = v_u_73.X
		local v371 = math.abs(v370)
		local v372 = v_u_73.Y
		v_u_74 = v369 + (v371 + math.abs(v372))
	end
	v_u_73 = Vector2.zero
	v_u_24 = (v_u_24 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
	local v373 = 1.361356816555577
	for _, v374 in v_u_37 do
		if not v374.maxPitch or v374.maxPitch >= v373 then
			continue
		end
		v373 = v374.maxPitch
	end
	if v373 < v_u_25 then
		local v375 = v_u_25
		local v376 = v373 - v_u_25
		local v377 = p346 * -5
		v_u_25 = v375 + v376 * (1 - math.exp(v377))
	end
	local v378 = v_u_25
	v_u_25 = math.clamp(v378, -1.3962634015954636, 1.361356816555577)
end
local function v_u_399(p380, p381, p382) -- name: setLobby
	-- upvalues: (ref) v_u_64, (copy) v_u_23, (ref) v_u_70, (ref) v_u_66, (ref) v_u_67, (ref) v_u_68, (ref) v_u_69, (copy) v_u_21, (ref) v_u_27, (copy) v_u_38, (copy) v_u_45, (copy) v_u_44, (ref) v_u_62, (ref) v_u_63, (copy) v_u_17, (ref) v_u_125, (copy) v_u_117, (copy) v_u_119, (ref) v_u_118, (ref) v_u_120, (ref) v_u_121, (ref) v_u_122, (copy) v_u_167, (copy) v_u_5, (ref) v_u_24, (ref) v_u_25, (ref) v_u_60, (ref) v_u_61
	v_u_64 = p380
	local v383 = v_u_23
	if v383 then
		v383 = v_u_23.Character
	end
	local v384
	if v383 then
		v384 = v383:FindFirstChild("HumanoidRootPart")
		v383:FindFirstChildOfClass("Humanoid")
		if not (v384 and (v384:IsA("BasePart") and v384)) then
			v384 = nil
		end
	else
		v384 = nil
	end
	if v_u_70 then
		local v385 = p381.CFrame
		local v386 = p381.FieldOfView
		v_u_66 = v385
		v_u_67 = v386
		v_u_68 = 0
		if v384 then
			v384 = v384.Position
		end
		v_u_69 = v384
	end
	v_u_21.PopMouseUnlock("FreeCursor")
	if p380 then
		v_u_27 = false
		table.clear(v_u_38)
		v_u_45:Snap(Vector3.new(0, 0, 0))
		v_u_21.SlowRecoil:Snap(Vector3.new(0, 0, 0))
		v_u_21.SlowRecoilStay = Vector3.new(0, 0, 0)
		v_u_44:Snap(0)
		v_u_62 = false
		if v_u_63 then
			v_u_17.SetFacing(nil)
			v_u_63 = false
		end
		local v387 = 0
		local v388 = v387 < 0.01 and 0 or v387
		local _ = math.max(v388, 0) < 0.01
		if v_u_125 ~= nil then
			for _, v389 in v_u_117 do
				local v390 = v389.inst
				if not v390.Parent or v390.LocalTransparencyModifier == 0 then
					continue
				end
				v390.LocalTransparencyModifier = 0
			end
			for _, v391 in v_u_119 do
				v391:Disconnect()
			end
			table.clear(v_u_119)
			table.clear(v_u_117)
			v_u_125 = nil
			v_u_118 = true
			v_u_120 = -1
			v_u_121 = -1
			v_u_122 = false
		end
		for v392 in v_u_167 do
			if not v392.Parent then
				continue
			end
			v392.LocalTransparencyModifier = 0
		end
		table.clear(v_u_167)
		if p382 and p381.CameraSubject ~= p382 then
			p381.CameraSubject = p382
		end
		p381.CameraType = Enum.CameraType.Custom
		v_u_5.MouseBehavior = Enum.MouseBehavior.Default
		v_u_5.MouseIconEnabled = true
	else
		local v393 = p381.CFrame.LookVector
		local v394 = -v393.X
		local v395 = -v393.Z
		v_u_24 = math.atan2(v394, v395)
		local v396 = v393.Y
		local v397 = math.clamp(v396, -1, 1)
		local v398 = math.asin(v397)
		v_u_25 = math.clamp(v398, -0.6981317007977318, 0.4363323129985824)
		v_u_60 = nil
		v_u_61 = nil
		v_u_62 = false
	end
end
local function v_u_422(p400, p401, p402, p403) -- name: updateLobby
	-- upvalues: (copy) v_u_35, (ref) v_u_73, (copy) v_u_217, (copy) v_u_39, (ref) v_u_29, (ref) v_u_65, (ref) v_u_25, (ref) v_u_24, (ref) v_u_68, (ref) v_u_66, (ref) v_u_69, (ref) v_u_67, (copy) v_u_13, (copy) v_u_14, (ref) v_u_85, (ref) v_u_86, (ref) v_u_70
	if next(v_u_35) == nil then
		if p403 and (p403.Parent and p401.CameraSubject ~= p403) then
			p401.CameraSubject = p403
		end
		if p401.CameraType == Enum.CameraType.Scriptable then
			p401.CameraType = Enum.CameraType.Custom
		end
		v_u_73 = Vector2.zero
		v_u_39.target = v_u_29 + v_u_217()
		v_u_39:Update(p400)
		local v404 = v_u_39.value
		local v405 = math.clamp(v404, 20, 110)
		local v406 = p401.CFrame
		if v_u_65 then
			v_u_65 = false
			local v407 = p401.Focus.Position
			local v408 = (v406.Position - v407).Magnitude
			local v409 = math.clamp(v408, 6, 40)
			v406 = CFrame.new(v407) * CFrame.fromEulerAnglesYXZ(v_u_25, v_u_24, 0) * CFrame.new(0, 0, v409)
			p401.CFrame = v406
		else
			local v410 = v406.LookVector
			local v411 = -v410.X
			local v412 = -v410.Z
			v_u_24 = math.atan2(v411, v412)
			local v413 = v410.Y
			local v414 = math.clamp(v413, -1, 1)
			v_u_25 = math.asin(v414)
		end
		if v_u_68 < 1 and v_u_66 then
			if p402 and (v_u_69 and (p402.Position - v_u_69).Magnitude > 40) then
				v_u_68 = 1
			else
				local v415 = v_u_68 + p400 / 0.5
				v_u_68 = math.min(1, v415)
				local v416 = v_u_68
				local v417 = math.clamp(v416, 0, 1)
				local v418 = v417 * v417 * (3 - v417 * 2)
				local v419 = v_u_66:Lerp(v406, v418)
				v405 = v_u_67 + (v405 - v_u_67) * v418
				p401.CFrame = v419
			end
		end
		local v420 = v_u_13.CameraOffset()
		if v420 ~= Vector3.new(0, 0, 0) then
			p401.CFrame = p401.CFrame + v420
			p401.Focus = p401.Focus + v420
		end
		local v421 = v_u_14.AboveWater(p401.CFrame)
		if v421 ~= p401.CFrame then
			p401.CFrame = v421
		end
		p401.FieldOfView = v405
		v_u_85 = v421
		v_u_86 = v405
		v_u_70 = true
	else
		p401.CameraType = Enum.CameraType.Scriptable
		v_u_73 = Vector2.zero
	end
end
local function v_u_535(p423) -- name: update
	-- upvalues: (copy) v_u_16, (ref) v_u_32, (ref) v_u_123, (copy) v_u_6, (copy) v_u_23, (copy) v_u_18, (ref) v_u_78, (copy) v_u_8, (ref) v_u_60, (ref) v_u_79, (ref) v_u_85, (ref) v_u_80, (ref) v_u_86, (ref) v_u_81, (ref) v_u_306, (ref) v_u_307, (ref) v_u_27, (copy) v_u_38, (ref) v_u_82, (ref) v_u_83, (ref) v_u_84, (ref) v_u_87, (ref) v_u_24, (ref) v_u_25, (ref) v_u_61, (copy) v_u_21, (copy) v_u_12, (ref) v_u_68, (ref) v_u_54, (ref) v_u_53, (ref) v_u_64, (copy) v_u_399, (copy) v_u_422, (copy) v_u_10, (copy) v_u_13, (copy) v_u_218, (copy) v_u_34, (copy) v_u_2, (copy) v_u_217, (copy) v_u_35, (copy) v_u_379, (ref) v_u_73, (copy) v_u_39, (copy) v_u_40, (copy) v_u_41, (copy) v_u_42, (copy) v_u_43, (copy) v_u_44, (copy) v_u_45, (ref) v_u_28, (ref) v_u_29, (ref) v_u_30, (ref) v_u_71, (copy) v_u_345, (ref) v_u_62, (ref) v_u_63, (copy) v_u_17, (copy) v_u_166, (copy) v_u_116, (copy) v_u_284, (copy) v_u_232, (copy) v_u_15, (copy) v_u_300, (ref) v_u_66, (ref) v_u_69, (ref) v_u_67, (ref) v_u_56, (ref) v_u_52, (ref) v_u_57, (ref) v_u_55, (ref) v_u_58, (ref) v_u_59, (copy) v_u_14, (copy) v_u_97, (ref) v_u_70, (ref) v_u_170, (ref) v_u_169, (copy) v_u_211, (copy) v_u_259, (ref) v_u_51, (ref) v_u_50
	v_u_16.Step()
	if v_u_32 then
		local v424 = (p423 ~= p423 or p423 <= 0) and 0.016666666666666666 or math.min(p423, 0.1)
		local v425 = v_u_6.CurrentCamera
		if v425 then
			local v426 = v_u_23
			if v426 then
				v426 = v_u_23.Character
			end
			local v427, v428
			if v426 then
				v427 = v426:FindFirstChild("HumanoidRootPart")
				v428 = v426:FindFirstChildOfClass("Humanoid")
				if not (v427 and (v427:IsA("BasePart") and v427)) then
					v427 = nil
				end
			else
				v427 = nil
				v428 = nil
				v426 = nil
			end
			v_u_123 = false
			local v429
			if v427 then
				v429 = v427.Position
			else
				v429 = nil
			end
			if v429 and not v_u_18.Vector(v429) then
				v_u_18.Say("own root")
				v429 = nil
			end
			local v430 = v_u_78
			v_u_78 = v_u_8.Step(v429 or v_u_60)
			if v_u_78 ~= v430 then
				if v_u_78 == "death" then
					v_u_79 = v_u_85
					v_u_80 = v_u_86
					v_u_81 = nil
					v_u_306 = nil
					v_u_307 = nil
					v_u_27 = false
					table.clear(v_u_38)
				elseif v_u_78 == "follow" then
					local v431 = v_u_86
					v_u_82 = v_u_85
					v_u_83 = v431
					v_u_84 = 0
					v_u_87 = nil
				else
					local v432 = v_u_23
					if v432 then
						v432 = v_u_23.Character
					end
					local v433
					if v432 then
						v433 = v432:FindFirstChild("HumanoidRootPart")
						v432:FindFirstChildOfClass("Humanoid")
						if not (v433 and (v433:IsA("BasePart") and v433)) then
							v433 = nil
						end
					else
						v433 = nil
					end
					if v433 then
						local v434 = v433.CFrame.LookVector
						local v435 = -v434.X
						local v436 = -v434.Z
						v_u_24 = math.atan2(v435, v436)
						v_u_25 = -0.20943951023931956
					end
					v_u_60 = nil
					v_u_61 = nil
					v_u_81 = nil
					v_u_82 = nil
					v_u_84 = 1
					v_u_87 = nil
				end
				if v_u_78 == "follow" then
					v_u_21.PushMouseUnlock("Spectate")
				else
					v_u_21.PopMouseUnlock("Spectate")
				end
				v_u_12.SetActive(v_u_78 == "follow", v_u_21.SpectateNext)
				v_u_68 = 1
			end
			local v437
			if v_u_78 == "none" then
				local v438 = v_u_23:GetAttribute("CombatMode")
				local v439
				if v438 == nil then
					v439 = v_u_23:GetAttribute("State") == "Match"
				else
					v439 = v438 == true
				end
				v437 = not v439
				if v437 then
					if v_u_54 == 0 then
						v437 = v_u_53 == 0
					else
						v437 = false
					end
				end
			else
				v437 = false
			end
			if v437 ~= v_u_64 then
				v_u_399(v437, v425, v428)
			end
			if v_u_64 then
				v_u_422(v424, v425, v427, v428)
				v_u_10.ClearAllies()
				local v440 = v_u_13.DrawnModel() or v426
				if v440 then
					v440 = v440:FindFirstChild("Head")
				end
				local v441 = v_u_10.UpdateDecor
				local v442 = v425.CFrame.Position
				local v443
				if v440 and v440:IsA("BasePart") then
					v443 = v440.Position
				else
					v443 = nil
				end
				v441(v442, v443)
				return
			else
				if v425.CameraType ~= Enum.CameraType.Scriptable then
					v425.CameraType = Enum.CameraType.Scriptable
				end
				v_u_218()
				local v444 = next(v_u_34) ~= nil and true or v_u_2.MenuIsOpen
				local v445, v446, v447, v448 = v_u_217()
				if v_u_78 == "none" and next(v_u_35) == nil then
					v_u_379(v424, v444, v448)
				else
					v_u_73 = Vector2.zero
				end
				if not v_u_18.Number(v_u_24) then
					v_u_18.Say("yaw")
					v_u_24 = 0
				end
				if not v_u_18.Number(v_u_25) then
					v_u_18.Say("pitch")
					v_u_25 = -0.20943951023931956
				end
				v_u_18.HealSpring(v_u_39, 70, "fov")
				v_u_18.HealSpring(v_u_40, 10.5, "distance")
				v_u_18.HealSpring(v_u_41, 2.9, "shoulder")
				v_u_18.HealSpring(v_u_42, Vector3.new(0, 0, 0), "pivot")
				v_u_18.HealSpring(v_u_43, not v429 and 0 or v429.Y, "height")
				v_u_18.HealSpring(v_u_44, 0, "dip")
				v_u_18.HealSpring(v_u_45, Vector3.new(0, 0, 0), "recoil")
				v_u_18.HealSpring(v_u_21.SlowRecoil, Vector3.new(0, 0, 0), "slow recoil")
				local v449 = v_u_78 ~= "none"
				local v450 = v_u_39
				local v451
				if v_u_27 then
					v451 = v_u_28
				elseif v449 then
					v451 = v_u_29
				else
					v451 = v_u_29 + v445
				end
				v450.target = v451
				local v452 = v_u_40
				local v453
				if v_u_27 then
					local v454 = 50 / v_u_28
					v453 = math.clamp(v454, 1, 1.6) * 8 + v446
				else
					v453 = v449 and 10.5 or v_u_30 + v446
				end
				v452.target = v453
				v_u_41.target = (v_u_27 and 2.8 or 2.9) * v_u_71
				v_u_42.target = v449 and Vector3.new(0, 0, 0) or v447
				v_u_39:Update(v424)
				v_u_40:Update(v424)
				v_u_41:Update(v424)
				v_u_42:Update(v424)
				v_u_44:Update(v424)
				v_u_45:Update(v424)
				local v455 = v_u_21.SlowRecoil
				local v456 = v455.target
				local v457 = -v424 / v_u_21.SLOW_RECOIL_FADE
				v455.target = v456 * math.exp(v457)
				v455:Update(v424)
				local v458 = v_u_21.SlowRecoilStay
				if v458.Magnitude > 0.00001 then
					local v459 = -v424 * 14
					local v460 = v458 * (1 - math.exp(v459))
					local v461 = v_u_25 + v460.X
					v_u_25 = math.clamp(v461, -1.3962634015954636, 1.361356816555577)
					v_u_24 = (v_u_24 + v460.Y + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
					v_u_21.SlowRecoilStay = v458 - v460
				else
					v_u_21.SlowRecoilStay = Vector3.new(0, 0, 0)
				end
				local v462, v463, v464
				if v_u_78 == "death" then
					v462, v463 = v_u_345(v424)
					v464 = v462.Position + v462.LookVector * 10
					v_u_62 = false
					if v_u_63 then
						v_u_17.SetFacing(nil)
						v_u_63 = false
					end
					v_u_166(v_u_13.DrawnModel() or v426, 0, 0)
				elseif v_u_78 == "follow" then
					local v465 = v_u_8.GetTarget()
					local v466
					if v465 then
						v466 = v465:FindFirstChild("HumanoidRootPart")
					else
						v466 = v465
					end
					v_u_62 = false
					if v_u_63 then
						v_u_17.SetFacing(nil)
						v_u_63 = false
					end
					v_u_166(v_u_13.DrawnModel() or v426, 0, 0)
					if v465 and (v466 and v466:IsA("BasePart")) and (v_u_18.Vector(v466.Position) and v_u_18.Vector(v466.CFrame.LookVector) or v_u_18.Say("follow root")) then
						if v465 ~= v_u_87 then
							if v_u_87 ~= nil then
								local v467 = v_u_86
								v_u_82 = v_u_85
								v_u_83 = v467
								v_u_84 = 0
							end
							v_u_87 = v465
							local v468 = v466.CFrame.LookVector
							local v469 = -v468.X
							local v470 = -v468.Z
							v_u_24 = math.atan2(v469, v470)
							v_u_25 = -0.17453292519943295
						end
						local v471 = v_u_24
						local v472 = v466.CFrame.LookVector
						local v473 = -v472.X
						local v474 = -v472.Z
						local v475 = (math.atan2(v473, v474) - v_u_24 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
						local v476 = v424 * -4
						v_u_24 = (v471 + v475 * (1 - math.exp(v476)) + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
						local v477 = v_u_25
						local v478 = -0.17453292519943295 - v_u_25
						local v479 = v424 * -3
						v_u_25 = v477 + v478 * (1 - math.exp(v479))
						local v480 = v_u_116(v465)
						v462, v464 = v_u_284(v424, v465, v466.Position, v480)
						local v481 = v_u_39.value
						v463 = math.clamp(v481, 20, 110)
					else
						v462 = v_u_85
						v463 = v_u_86
						v464 = v462.Position + v462.LookVector * 10
					end
					if v_u_84 < 1 and v_u_82 then
						local v482 = v_u_84 + v424 / 0.45
						v_u_84 = math.min(1, v482)
						local v483 = v_u_84
						local v484 = math.clamp(v483, 0, 1)
						local v485 = v484 * v484 * (3 - v484 * 2)
						v462 = v_u_82:Lerp(v462, v485)
						v463 = v_u_83 + (v463 - v_u_83) * v485
					end
				else
					if not (v427 and (v426 and v429)) then
						return
					end
					if v428 then
						v_u_232(v424, v427, v428, v444)
					end
					local v486 = v_u_116(v426)
					local v487 = v429 + v_u_18.Offset(v_u_13)
					local v488
					v488, v464 = v_u_284(v424, v426, v487, v486)
					local v489
					if v_u_54 == 0 and (v_u_53 == 0 and v428 ~= nil) then
						v489 = v428.Health > 0
					else
						v489 = false
					end
					local v490 = v_u_15.Step(v424, v489)
					v_u_123 = v490 >= 0.5
					local v491
					if v490 > 0 then
						local v492 = v426:FindFirstChild("Head")
						local v493 = v_u_15.StepBob
						local v494
						if v428 == nil then
							v494 = false
						else
							v494 = v428.FloorMaterial ~= Enum.Material.Air
						end
						v493(v424, v487, v494, v426:GetAttribute("Sliding") == true)
						local v495, v496 = v_u_15.CameraBob()
						local v497 = v_u_15.Eye
						if not (v492 and v492:IsA("BasePart")) then
							v492 = nil
						end
						local v498 = v497(v424, v487, v427, v492, v488.LookVector)
						local v499 = v_u_44.value * 0.5 + v495
						local v500 = v498 + Vector3.new(0, v499, 0)
						v491 = CFrame.new(v500) * v488.Rotation * CFrame.Angles(0, 0, v496)
						local v501 = v_u_15.Eased()
						if v501 < 1 then
							v491 = v488:Lerp(v491, v501)
						end
						v464 = v464:Lerp(v500 + v491.LookVector * 10, v501)
					else
						v491 = v488
					end
					v462 = v_u_300(v491, v424, v_u_123 and 0.6 or 1)
					local v502 = v_u_39.value
					v463 = math.clamp(v502, 20, 110)
					if v_u_68 < 1 and v_u_66 then
						if v_u_69 and (v427.Position - v_u_69).Magnitude > 40 then
							v_u_68 = 1
						else
							local v503 = v_u_68 + v424 / 0.5
							v_u_68 = math.min(1, v503)
							local v504 = v_u_68
							local v505 = math.clamp(v504, 0, 1)
							local v506 = v505 * v505 * (3 - v505 * 2)
							v462 = v_u_66:Lerp(v462, v506)
							v463 = v_u_67 + (v463 - v_u_67) * v506
						end
					end
				end
				if v_u_54 > 0 then
					local v507 = os.clock() - v_u_56
					local v508
					if v507 > 0.5 and next(v_u_34) == nil then
						local v509 = v_u_52
						if v509 then
							v509 = v_u_52.untilStopped
						end
						v508 = not v509
					else
						v508 = false
					end
					local v510
					if v_u_57 == v426 then
						if v428 == nil then
							v510 = false
						else
							v510 = v428.Health <= 0
						end
					else
						v510 = true
					end
					if v508 or (v510 or v507 > 120) then
						v_u_54 = 0
						v_u_55 = 2.5
					end
				end
				if v_u_53 < v_u_54 then
					local v511 = v_u_54
					local v512 = v_u_53 + v424 * v_u_55
					v_u_53 = math.min(v511, v512)
				elseif v_u_54 < v_u_53 then
					local v513 = v_u_54
					local v514 = v_u_53 - v424 * v_u_55
					v_u_53 = math.max(v513, v514)
				end
				local v515 = v_u_52
				if v515 then
					v_u_58 = v515.cf
					v_u_59 = v515.fov or v_u_59
				end
				if v_u_53 > 0 then
					local v516 = v_u_53
					local v517 = math.clamp(v516, 0, 1)
					local v518 = v517 * v517 * (3 - v517 * 2)
					v462 = v462:Lerp(v_u_58, v518)
					v463 = v463 + (v_u_59 - v463) * v518
				elseif v_u_54 == 0 then
					v_u_52 = nil
				end
				if v_u_53 <= 0 then
					v462 = v_u_14.AboveWater(v462)
				end
				local v519 = v463 + v_u_97()
				local v520 = math.clamp(v519, 20, 110)
				if v_u_18.Vector(v462.Position) and (v_u_18.Vector(v462.LookVector) and v_u_18.Number(v520)) then
					if not v_u_18.Vector(v464) then
						v464 = v462.Position + v462.LookVector * 10
					end
				else
					v_u_18.Say("view " .. v_u_78)
					v462 = v_u_85
					v520 = v_u_86
					v464 = v462.Position + v462.LookVector * 10
				end
				v425.CFrame = v462
				local v521 = CFrame.new
				local v522
				if v_u_53 > 0.5 then
					v522 = v_u_58.Position
				else
					v522 = v464
				end
				v425.Focus = v521(v522)
				v425.FieldOfView = v520
				v_u_85 = v462
				v_u_86 = v520
				v_u_70 = true
				if v_u_78 == "none" then
					local v523 = v_u_13.DrawnModel() or v426
					local v524 = (v429 or v462.Position) + v_u_18.Offset(v_u_13)
					local v525
					if v523 then
						v525 = v523:FindFirstChild("Head")
					else
						v525 = v523
					end
					local v526
					if v525 and v525:IsA("BasePart") then
						v526 = v525.Position
					else
						v526 = v524 + Vector3.new(0, 1.5, 0)
					end
					local v527 = (v462.Position - v526).Magnitude
					local v528
					if v527 < 2.6 then
						local v529 = (2.6 - v527) / 1.6
						v528 = math.clamp(v529, 0, 0.85)
					else
						v528 = 0
					end
					if v515 and v515.hide then
						local v530 = v_u_53
						v528 = math.max(v528, v530)
					end
					local v531 = v426 and (v_u_53 < 0.5 and (not v_u_123 and v_u_259(v425, v_u_51))) and 0.6 or 0
					v_u_51 = v531 > 0
					local v532 = v_u_50
					local v533 = v531 - v_u_50
					local v534 = v424 * -12
					v_u_50 = v532 + v533 * (1 - math.exp(v534))
					if v531 == 0 and v_u_50 < 0.02 then
						v_u_50 = 0
					end
					v_u_166(v523, v_u_123 and 0 or v528, v_u_50, v_u_123)
					v_u_10.UpdateAllies(v462.Position, v526, v426)
					v_u_10.UpdateDecor(v462.Position, v526)
					v_u_170 = v_u_170 + 1
					if v_u_169 <= v_u_170 then
						v_u_170 = 0
						v_u_211(v462.Position, v526, (v_u_116(v426)))
					end
				else
					v_u_170 = v_u_170 + 1
					if v_u_169 <= v_u_170 then
						v_u_170 = 0
						v_u_211(v462.Position, v464, (v_u_116(v426)))
					end
					v_u_10.ClearAllies()
					v_u_10.UpdateDecor(v462.Position, v464)
				end
			end
		else
			return
		end
	else
		v_u_123 = false
		return
	end
end
local function v_u_546(p536) -- name: inThumbstickArea
	-- upvalues: (copy) v_u_23, (copy) v_u_6
	local v537 = v_u_23:FindFirstChildOfClass("PlayerGui")
	if v537 then
		v537 = v537:FindFirstChild("TouchGui")
	end
	local v538
	if v537 and (v537:IsA("ScreenGui") and v537.Enabled) then
		v538 = v537:FindFirstChild("TouchControlFrame")
	else
		v538 = nil
	end
	local v539 = false
	for _, v540 in { "DynamicThumbstickFrame", "ThumbstickFrame" } do
		local v541
		if v538 then
			v541 = v538:FindFirstChild(v540)
		else
			v541 = v538
		end
		if not (v541 and (v541:IsA("GuiObject") and v541.Visible)) then
			continue
		end
		local v542 = v541.AbsolutePosition
		local v543 = v542 + v541.AbsoluteSize
		if p536.X >= v542.X and (p536.Y >= v542.Y and (p536.X <= v543.X and p536.Y <= v543.Y)) then
			return true
		end
		v539 = true
	end
	if v539 then
		return false
	end
	local v544 = v_u_6.CurrentCamera
	local v545
	if v544 == nil or p536.X >= v544.ViewportSize.X * 0.4 then
		v545 = false
	else
		v545 = p536.Y > v544.ViewportSize.Y / 3
	end
	return v545
end
local v_u_547 = nil
local function v_u_551(p548, p549) -- name: onInputBegan
	-- upvalues: (ref) v_u_547, (copy) v_u_546, (ref) v_u_75, (copy) v_u_76, (ref) v_u_77
	if p548.UserInputType == Enum.UserInputType.Touch and not p549 then
		local v550
		if v_u_547 then
			v550 = v_u_547.UserInputState
		else
			v550 = nil
		end
		if v550 == Enum.UserInputState.End or v550 == Enum.UserInputState.Cancel then
			v_u_547 = nil
		end
		if not v_u_547 and v_u_546(p548.Position) then
			v_u_547 = p548
			v_u_75 = v_u_75 + 1
			return
		end
		v_u_76[p548] = true
		v_u_77 = nil
	end
end
local function v_u_559(p552, _) -- name: onInputChanged
	-- upvalues: (copy) v_u_76, (copy) v_u_16, (ref) v_u_73, (ref) v_u_77, (ref) v_u_30, (ref) v_u_72
	if p552.UserInputType == Enum.UserInputType.Touch then
		if not v_u_76[p552] then
			return
		end
		v_u_16.PruneTouches(v_u_76)
		local v553 = 0
		for _ in v_u_76 do
			v553 = v553 + 1
		end
		if v553 == 1 then
			v_u_73 = v_u_73 + Vector2.new(p552.Delta.X, p552.Delta.Y)
			return
		end
		if v553 == 2 then
			local v554 = nil
			local v555 = nil
			for v556 in v_u_76 do
				if v554 then
					v555 = v556
				else
					v554 = v556
				end
			end
			if v554 and v555 then
				local v557 = (Vector2.new(v554.Position.X, v554.Position.Y) - Vector2.new(v555.Position.X, v555.Position.Y)).Magnitude
				if v_u_77 then
					local v558 = v_u_30 - (v557 - v_u_77) * 0.03
					v_u_30 = math.clamp(v558, 7, 14)
				end
				v_u_77 = v557
				return
			end
		end
	elseif p552.KeyCode == Enum.KeyCode.Thumbstick2 then
		v_u_72 = Vector2.new(p552.Position.X, p552.Position.Y)
	end
end
local function v_u_561(p560, _) -- name: onInputEnded
	-- upvalues: (ref) v_u_547, (copy) v_u_76, (ref) v_u_77, (ref) v_u_72
	if p560.UserInputType == Enum.UserInputType.Touch then
		if p560 == v_u_547 then
			v_u_547 = nil
		end
		v_u_76[p560] = nil
		v_u_77 = nil
	elseif p560.KeyCode == Enum.KeyCode.Thumbstick2 then
		v_u_72 = Vector2.zero
	end
end
local function v609() -- name: start
	-- upvalues: (ref) v_u_33, (copy) v_u_22, (copy) v_u_8, (copy) v_u_13, (copy) v_u_23, (ref) v_u_169, (copy) v_u_168, (copy) v_u_6, (ref) v_u_24, (copy) v_u_3, (copy) v_u_104, (ref) v_u_99, (copy) v_u_9, (copy) v_u_5, (copy) v_u_551, (copy) v_u_559, (copy) v_u_561, (copy) v_u_16, (copy) v_u_21, (copy) v_u_20, (copy) v_u_1, (ref) v_u_64, (copy) v_u_34, (copy) v_u_2, (ref) v_u_26, (ref) v_u_78, (ref) v_u_54, (ref) v_u_53, (ref) v_u_52, (ref) v_u_50, (ref) v_u_125, (copy) v_u_117, (copy) v_u_119, (ref) v_u_118, (ref) v_u_120, (ref) v_u_121, (ref) v_u_122, (ref) v_u_60, (ref) v_u_61, (ref) v_u_62, (ref) v_u_63, (copy) v_u_17, (ref) v_u_27, (copy) v_u_38, (copy) v_u_45, (copy) v_u_44, (ref) v_u_68, (ref) v_u_25, (ref) v_u_65, (copy) v_u_35, (copy) v_u_76, (copy) v_u_4, (copy) v_u_535, (ref) v_u_46, (ref) v_u_48, (ref) v_u_47
	if not v_u_33 and v_u_22 then
		v_u_33 = true
		v_u_8.Start()
		v_u_13.Start()
		local function v562()
			-- upvalues: (ref) v_u_23
			v_u_23.CameraMinZoomDistance = 6
			v_u_23.CameraMaxZoomDistance = 40
		end
		pcall(v562)
		task.spawn(function()
			-- upvalues: (ref) v_u_23, (ref) v_u_169, (ref) v_u_168
			local v_u_563 = v_u_23:WaitForChild("PlayerScripts", 30)
			if v_u_563 then
				local function v564() -- name: readLevel
					-- upvalues: (ref) v_u_169, (ref) v_u_168, (copy) v_u_563
					v_u_169 = v_u_168[v_u_563:GetAttribute("CharacterQualityLevel")] or 1
				end
				v_u_169 = v_u_168[v_u_563:GetAttribute("CharacterQualityLevel")] or 1
				v_u_563:GetAttributeChangedSignal("CharacterQualityLevel"):Connect(v564)
			end
		end)
		local v565 = v_u_6.CurrentCamera
		if v565 then
			local v566 = v565.CFrame.LookVector
			local v567 = -v566.X
			local v568 = -v566.Z
			v_u_24 = math.atan2(v567, v568)
		end
		for _, v569 in v_u_3:GetPlayers() do
			v569.CharacterAdded:Connect(v_u_104)
			v569.CharacterRemoving:Connect(v_u_104)
		end
		v_u_3.PlayerAdded:Connect(function(p570)
			-- upvalues: (ref) v_u_104, (ref) v_u_99
			p570.CharacterAdded:Connect(v_u_104)
			p570.CharacterRemoving:Connect(v_u_104)
			v_u_99 = true
		end)
		v_u_3.PlayerRemoving:Connect(v_u_104)
		v_u_9.OnTaggedChanged(v_u_104)
		v_u_5.InputBegan:Connect(v_u_551)
		v_u_5.InputChanged:Connect(v_u_559)
		v_u_5.InputEnded:Connect(v_u_561)
		task.spawn(function()
			-- upvalues: (ref) v_u_16, (ref) v_u_21
			local v571 = game:GetService("TextChatService")
			local v_u_572 = v571:FindFirstChildOfClass("ChatInputBarConfiguration") or v571:WaitForChild("ChatInputBarConfiguration", 10)
			if v_u_572 and v_u_572:IsA("ChatInputBarConfiguration") then
				v_u_16.SetChatConfig(v_u_572)
				v_u_572:GetPropertyChangedSignal("IsFocused"):Connect(function()
					-- upvalues: (copy) v_u_572, (ref) v_u_21
					if v_u_572.IsFocused then
						v_u_21.PushMouseUnlock("ChatFocus")
					else
						v_u_21.PopMouseUnlock("ChatFocus")
					end
				end)
			end
		end)
		v_u_5.TextBoxFocused:Connect(function()
			-- upvalues: (ref) v_u_21
			v_u_21.PushMouseUnlock("TextBox")
		end)
		v_u_5.TextBoxFocusReleased:Connect(function()
			-- upvalues: (ref) v_u_21
			v_u_21.PopMouseUnlock("TextBox")
		end)
		local function v_u_582() -- name: bindKeys
			-- upvalues: (ref) v_u_20, (ref) v_u_1, (ref) v_u_16, (ref) v_u_64, (ref) v_u_34, (ref) v_u_21, (ref) v_u_2, (ref) v_u_26, (ref) v_u_78
			local v573 = v_u_20.Inputs("FreeCursor")
			if #v573 == 0 then
				v_u_1:UnbindAction("TribesFreeCursor")
			else
				v_u_1:BindActionAtPriority("TribesFreeCursor", function(_, p574, p575)
					-- upvalues: (ref) v_u_16, (ref) v_u_64, (ref) v_u_34, (ref) v_u_21
					if p574 == Enum.UserInputState.Begin then
						v_u_16.FreeKeyDown(p575)
					elseif p574 == Enum.UserInputState.End then
						if v_u_16.FreeKeyUp() and not v_u_64 then
							if v_u_34.FreeCursor then
								v_u_21.PopMouseUnlock("FreeCursor")
							else
								v_u_21.PushMouseUnlock("FreeCursor")
							end
						end
					else
						v_u_16.FreeKeyCancel()
					end
					return Enum.ContextActionResult.Pass
				end, false, Enum.ContextActionPriority.Low.Value, table.unpack(v573))
			end
			local v576 = v_u_20.Inputs("Shoulder")
			for _, v577 in v_u_20.PadInputs("Shoulder") do
				table.insert(v576, v577)
			end
			local v578 = v_u_20.Inputs("View")
			for _, v579 in v_u_20.PadInputs("View") do
				table.insert(v578, v579)
			end
			v_u_1:UnbindAction("TribesShoulderSwap")
			v_u_1:UnbindAction("TribesFirstPerson")
			if #v576 > 0 then
				v_u_1:BindActionAtPriority("TribesShoulderSwap", function(_, p580)
					-- upvalues: (ref) v_u_34, (ref) v_u_2, (ref) v_u_64, (ref) v_u_21, (ref) v_u_26
					if p580 == Enum.UserInputState.Begin and (next(v_u_34) == nil and not v_u_2.MenuIsOpen and not v_u_64) then
						v_u_21.SetShoulderSide(-v_u_26)
					end
					return Enum.ContextActionResult.Pass
				end, false, Enum.ContextActionPriority.Low.Value, table.unpack(v576))
			end
			if #v578 > 0 then
				v_u_1:BindActionAtPriority("TribesFirstPerson", function(_, p581)
					-- upvalues: (ref) v_u_34, (ref) v_u_2, (ref) v_u_64, (ref) v_u_78, (ref) v_u_21
					if p581 == Enum.UserInputState.Begin and (next(v_u_34) == nil and not v_u_2.MenuIsOpen and (not v_u_64 and v_u_78 == "none")) then
						v_u_21.ToggleFirstPerson()
					end
					return Enum.ContextActionResult.Pass
				end, false, Enum.ContextActionPriority.Low.Value, table.unpack(v578))
			end
		end
		v_u_582()
		local function v585(p583) -- name: rebindFor
			-- upvalues: (copy) v_u_582
			for _, v584 in p583 do
				if v584 ~= "FreeCursor" and (v584 ~= "Shoulder" and v584 ~= "View") then
					continue
				end
				v_u_582()
				return
			end
		end
		v_u_20.Changed:Connect(v585)
		v_u_20.PadChanged:Connect(v585)
		v_u_23.CharacterAdded:Connect(function(p586)
			-- upvalues: (ref) v_u_54, (ref) v_u_53, (ref) v_u_52, (ref) v_u_50, (ref) v_u_125, (ref) v_u_117, (ref) v_u_119, (ref) v_u_118, (ref) v_u_120, (ref) v_u_121, (ref) v_u_122, (ref) v_u_60, (ref) v_u_61, (ref) v_u_62, (ref) v_u_63, (ref) v_u_17, (ref) v_u_27, (ref) v_u_38, (ref) v_u_45, (ref) v_u_21, (ref) v_u_44, (ref) v_u_68, (ref) v_u_24, (ref) v_u_25, (ref) v_u_65, (ref) v_u_64
			v_u_54 = 0
			v_u_53 = 0
			v_u_52 = nil
			v_u_50 = 0
			local v587 = 0
			local v588 = v587 < 0.01 and 0 or v587
			local _ = math.max(v588, 0) < 0.01
			if v_u_125 ~= nil then
				for _, v589 in v_u_117 do
					local v590 = v589.inst
					if not v590.Parent or v590.LocalTransparencyModifier == 0 then
						continue
					end
					v590.LocalTransparencyModifier = 0
				end
				for _, v591 in v_u_119 do
					v591:Disconnect()
				end
				table.clear(v_u_119)
				table.clear(v_u_117)
				v_u_125 = nil
				v_u_118 = true
				v_u_120 = -1
				v_u_121 = -1
				v_u_122 = false
			end
			for _, v592 in p586:GetDescendants() do
				if not (v592:IsA("BasePart") or v592:IsA("Decal")) then
					continue
				end
				v592.LocalTransparencyModifier = 0
			end
			v_u_60 = nil
			v_u_61 = nil
			v_u_62 = false
			v_u_63 = false
			v_u_17.SetFacing(nil)
			v_u_125 = nil
			v_u_27 = false
			table.clear(v_u_38)
			v_u_45:Snap(Vector3.new(0, 0, 0))
			v_u_21.SlowRecoil:Snap(Vector3.new(0, 0, 0))
			v_u_21.SlowRecoilStay = Vector3.new(0, 0, 0)
			v_u_44:Snap(0)
			v_u_68 = 1
			v_u_21.PopMouseUnlock("FreeCursor")
			local v_u_593 = p586:WaitForChild("HumanoidRootPart", 5)
			if v_u_593 and v_u_593:IsA("BasePart") then
				local v594 = v_u_593.CFrame.LookVector
				local v595 = -v594.X
				local v596 = -v594.Z
				v_u_24 = math.atan2(v595, v596)
				v_u_25 = -0.20943951023931956
				v_u_65 = v_u_64
				local v_u_597 = os.clock()
				local v_u_598 = v_u_593.Position
				task.spawn(function()
					-- upvalues: (copy) v_u_597, (copy) v_u_593, (ref) v_u_598, (ref) v_u_24, (ref) v_u_25, (ref) v_u_65, (ref) v_u_64
					while os.clock() - v_u_597 < 1.5 and v_u_593.Parent do
						task.wait(0.05)
						if (v_u_593.Position - v_u_598).Magnitude > 40 then
							local v599 = v_u_593.CFrame.LookVector
							local v600 = -v599.X
							local v601 = -v599.Z
							v_u_24 = math.atan2(v600, v601)
							v_u_25 = -0.20943951023931956
							v_u_65 = v_u_64
						end
						v_u_598 = v_u_593.Position
					end
				end)
			end
		end)
		local v604 = {
			["lookLocks"] = v_u_35,
			["unlockReasons"] = v_u_34,
			["touches"] = v_u_76,
			["popLookLock"] = function(p602) -- name: popLookLock
				-- upvalues: (ref) v_u_21
				v_u_21.PopLookLock(p602)
			end,
			["popUnlock"] = function(p603) -- name: popUnlock
				-- upvalues: (ref) v_u_21
				v_u_21.PopMouseUnlock(p603)
			end,
			["blockers"] = function() -- name: blockers
				-- upvalues: (ref) v_u_21
				return v_u_21.GetLookBlockers()
			end
		}
		v_u_16.Start(v604)
		v_u_4:BindToRenderStep("TribesCamera", Enum.RenderPriority.Camera.Value + 1, function(p605)
			-- upvalues: (ref) v_u_535, (ref) v_u_17, (ref) v_u_24, (ref) v_u_46, (ref) v_u_48, (ref) v_u_47
			local v606 = os.clock()
			v_u_535(p605)
			v_u_17.SetLook(v_u_24)
			local v607 = os.clock() - v606
			v_u_46 = v_u_46 + v607
			v_u_48 = v_u_48 + 1
			local v608 = v_u_47
			v_u_47 = math.max(v608, v607)
		end)
	end
end
function v_u_21.SetAiming(p610, p611) -- name: SetAiming
	-- upvalues: (ref) v_u_27, (ref) v_u_78, (ref) v_u_28
	local v612
	if p610 == true then
		v612 = v_u_78 == "none"
	else
		v612 = false
	end
	v_u_27 = v612
	if v_u_27 then
		v_u_28 = typeof(p611) ~= "number" and 50 or math.clamp(p611, 20, 90)
	end
end
function v_u_21.IsAiming() -- name: IsAiming
	-- upvalues: (ref) v_u_27
	return v_u_27
end
function v_u_21.GetAimRay() -- name: GetAimRay
	-- upvalues: (copy) v_u_6
	local v613 = v_u_6.CurrentCamera
	if not v613 then
		return Ray.new(Vector3.new(0, 0, 0), Vector3.new(0, 0, -1))
	end
	local v614 = v613.CFrame
	return Ray.new(v614.Position, v614.LookVector)
end
function v_u_21.GetAimPoint(p615, p616) -- name: GetAimPoint
	-- upvalues: (copy) v_u_21, (copy) v_u_23, (copy) v_u_103, (copy) v_u_6
	local v617 = v_u_21.GetAimRay()
	local v618 = p615 or 1000
	local v619 = v_u_23
	if v619 then
		v619 = v_u_23.Character
	end
	local v620 = v617.Origin
	local v621 = v_u_23
	if v621 then
		v621 = v_u_23.Character
	end
	local v622
	if v621 then
		v622 = v621:FindFirstChild("HumanoidRootPart")
		v621:FindFirstChildOfClass("Humanoid")
		if not (v622 and (v622:IsA("BasePart") and v622)) then
			v622 = nil
		end
	else
		v622 = nil
	end
	if v622 then
		local v623 = (v622.Position - v620):Dot(v617.Direction)
		if v623 > 0 then
			local v624 = v617.Direction
			local v625 = v623 - 1.5
			v620 = v620 + v624 * math.max(0, v625)
		end
	end
	local v626 = {}
	if v619 then
		table.insert(v626, v619)
	end
	for _, v627 in v_u_103 do
		local v628 = v_u_6:FindFirstChild(v627)
		if not v628 then
			continue
		end
		table.insert(v626, v628)
	end
	if p616 then
		for _, v629 in p616 do
			table.insert(v626, v629)
		end
	end
	local v630 = RaycastParams.new()
	v630.FilterType = Enum.RaycastFilterType.Exclude
	v630.FilterDescendantsInstances = v626
	v630.IgnoreWater = true
	local v631 = v618 - (v620 - v617.Origin).Magnitude
	local v632 = v_u_6:Raycast(v620, v617.Direction * v631, v630)
	if v632 then
		return v632.Position, v632
	else
		return v620 + v617.Direction * v631, nil
	end
end
function v_u_21.FovKick(p633, p634, p635) -- name: FovKick
	-- upvalues: (copy) v_u_88
	if typeof(p633) == "number" and p633 == p633 then
		v_u_88.amount = math.clamp(p633, -20, 20)
		v_u_88.t0 = os.clock()
		v_u_88.rise = math.max(p634 or 0.05, 0.01)
		v_u_88.fall = math.max(p635 or 0.2, 0.01)
	end
end
function v_u_21.Shake(p636, p637) -- name: Shake
	-- upvalues: (copy) v_u_38
	if typeof(p636) == "number" and typeof(p637) == "number" then
		if p636 > 0 and p637 > 0 then
			if #v_u_38 > 24 then
				table.remove(v_u_38, 1)
			end
			local v638 = v_u_38
			local v639 = {
				["intensity"] = nil,
				["duration"] = nil,
				["t"] = 0,
				["intensity"] = math.min(p636, 3),
				["duration"] = math.min(p637, 5)
			}
			table.insert(v638, v639)
		end
	else
		return
	end
end
function v_u_21.Recoil(p640, p641, p642) -- name: Recoil
	-- upvalues: (copy) v_u_45
	local v643 = v_u_45
	local v644 = math.rad(p640)
	local v645 = math.rad(p641 or 0)
	local v646 = math.rad(p642 or 0)
	v643:Impulse(Vector3.new(v644, v645, v646) * 12)
end
v_u_21.SlowRecoil = v7.new(Vector3.new(0, 0, 0), 8, 1)
v_u_21.SlowRecoilStay = Vector3.new(0, 0, 0)
v_u_21.SLOW_RECOIL_FADE = 0.3
function v_u_21.RecoilSlow(p647, p648, p649, p650) -- name: RecoilSlow
	-- upvalues: (copy) v_u_21
	local v651 = v_u_21.SlowRecoil
	local v652 = v651.target
	local v653 = math.rad(p647)
	local v654 = math.rad(p648 or 0)
	local v655 = v652 + Vector3.new(v653, v654, 0)
	local v656 = v655.X
	local v657 = math.clamp(v656, -0.4363323129985824, 0.4363323129985824)
	local v658 = v655.Y
	local v659 = math.clamp(v658, -0.4363323129985824, 0.4363323129985824)
	v651.target = Vector3.new(v657, v659, 0)
	local v660 = v_u_21
	local v661 = v660.SlowRecoilStay
	local v662 = math.rad(p649 or 0)
	local v663 = math.rad(p650 or 0)
	v660.SlowRecoilStay = v661 + Vector3.new(v662, v663, 0)
end
function v_u_21.Dip(p664) -- name: Dip
	-- upvalues: (copy) v_u_44
	if typeof(p664) == "number" then
		v_u_44:Impulse(-math.clamp(p664, -3, 3) * 6)
	end
end
function v_u_21.PushMouseUnlock(p665) -- name: PushMouseUnlock
	-- upvalues: (copy) v_u_34, (ref) v_u_33, (copy) v_u_218
	v_u_34[tostring(p665)] = true
	if v_u_33 then
		v_u_218()
	end
end
function v_u_21.PopMouseUnlock(p666) -- name: PopMouseUnlock
	-- upvalues: (copy) v_u_34, (ref) v_u_33, (copy) v_u_218
	v_u_34[tostring(p666)] = nil
	if v_u_33 then
		v_u_218()
	end
end
function v_u_21.PushLookLock(p667, p668) -- name: PushLookLock
	-- upvalues: (copy) v_u_35, (copy) v_u_16
	local v669 = tostring(p667)
	v_u_35[v669] = true
	v_u_16.LockPushed(v669, p668)
end
function v_u_21.PopLookLock(p670) -- name: PopLookLock
	-- upvalues: (copy) v_u_35, (copy) v_u_16
	local v671 = tostring(p670)
	v_u_35[v671] = nil
	v_u_16.LockPopped(v671)
end
function v_u_21.IsLookLocked() -- name: IsLookLocked
	-- upvalues: (copy) v_u_35
	return next(v_u_35) ~= nil
end
function v_u_21.GetLookBlockers() -- name: GetLookBlockers
	-- upvalues: (ref) v_u_32, (ref) v_u_64, (ref) v_u_78, (ref) v_u_54, (ref) v_u_53, (copy) v_u_35, (copy) v_u_34, (copy) v_u_2
	local v672 = {}
	if not v_u_32 then
		table.insert(v672, "disabled")
	end
	if v_u_64 then
		table.insert(v672, "lobby")
	end
	if v_u_78 ~= "none" then
		local v673 = "spectate:" .. v_u_78
		table.insert(v672, v673)
	end
	if v_u_54 > 0 or v_u_53 > 0 then
		table.insert(v672, "cinematic")
	end
	for v674 in v_u_35 do
		local v675 = "lock:" .. v674
		table.insert(v672, v675)
	end
	for v676 in v_u_34 do
		local v677 = "unlock:" .. v676
		table.insert(v672, v677)
	end
	if v_u_2.MenuIsOpen then
		table.insert(v672, "robloxMenu")
	end
	table.sort(v672)
	return v672
end
function v_u_21.IsMouseUnlocked() -- name: IsMouseUnlocked
	-- upvalues: (copy) v_u_34, (copy) v_u_2
	return next(v_u_34) ~= nil and true or v_u_2.MenuIsOpen
end
function v_u_21.GetMode() -- name: GetMode
	-- upvalues: (ref) v_u_64
	return v_u_64 and "lobby" or "combat"
end
function v_u_21.GetUnlockReasons() -- name: GetUnlockReasons
	-- upvalues: (copy) v_u_34
	local v678 = {}
	for v679 in v_u_34 do
		table.insert(v678, v679)
	end
	return v678
end
function v_u_21.GetShoulderSide() -- name: GetShoulderSide
	-- upvalues: (ref) v_u_26
	return v_u_26
end
v_u_21.FirstPersonChanged = v_u_124.Event
function v_u_21.SetFirstPerson(p680) -- name: SetFirstPerson
	-- upvalues: (copy) v_u_15, (copy) v_u_124
	local v681 = p680 == true
	if v_u_15.Get() ~= v681 then
		v_u_15.Set(v681)
		v_u_124:Fire(v681)
	end
end
function v_u_21.IsFirstPerson() -- name: IsFirstPerson
	-- upvalues: (copy) v_u_15
	return v_u_15.Get()
end
function v_u_21.ToggleFirstPerson() -- name: ToggleFirstPerson
	-- upvalues: (copy) v_u_21, (copy) v_u_15
	v_u_21.SetFirstPerson(not v_u_15.Get())
end
function v_u_21.InFirstPerson() -- name: InFirstPerson
	-- upvalues: (ref) v_u_123
	return v_u_123
end
function v_u_21.SetViewBobbing(p682) -- name: SetViewBobbing
	-- upvalues: (copy) v_u_15
	v_u_15.SetBobbing(p682)
end
function v_u_21.GetViewBobbing() -- name: GetViewBobbing
	-- upvalues: (copy) v_u_15
	return v_u_15.GetBobbing()
end
function v_u_21.GetViewBob() -- name: GetViewBob
	-- upvalues: (copy) v_u_15
	return v_u_15.Bob()
end
function v_u_21.SetShoulderSide(p683) -- name: SetShoulderSide
	-- upvalues: (ref) v_u_26, (ref) v_u_71, (copy) v_u_14
	v_u_26 = p683 < 0 and -1 or 1
	v_u_71 = v_u_26
	v_u_14.Reset()
end
function v_u_21.SetModifier(p684, p685) -- name: SetModifier
	-- upvalues: (copy) v_u_37
	v_u_37[p684] = p685
end
function v_u_21.SuspendCharacterRotation(p686) -- name: SuspendCharacterRotation
	-- upvalues: (copy) v_u_36
	v_u_36[tostring(p686)] = true
end
function v_u_21.ResumeCharacterRotation(p687) -- name: ResumeCharacterRotation
	-- upvalues: (copy) v_u_36
	v_u_36[tostring(p687)] = nil
end
function v_u_21.FaceCamera() -- name: FaceCamera
	-- upvalues: (copy) v_u_23, (ref) v_u_64, (ref) v_u_63, (copy) v_u_17, (ref) v_u_24
	local v688 = v_u_23
	if v688 then
		v688 = v_u_23.Character
	end
	local v689, v690
	if v688 then
		v689 = v688:FindFirstChild("HumanoidRootPart")
		v690 = v688:FindFirstChildOfClass("Humanoid")
		if not (v689 and (v689:IsA("BasePart") and v689)) then
			v689 = nil
		end
	else
		v689 = nil
		v690 = nil
	end
	if v689 and (v690 and (v690.Health > 0 and v_u_64 == false)) then
		v_u_63 = true
		v_u_17.SetFacing(v_u_24)
	end
end
function v_u_21.GetAimAssistShot() -- name: GetAimAssistShot
	-- upvalues: (copy) v_u_11, (copy) v_u_23, (copy) v_u_116, (ref) v_u_24, (ref) v_u_25, (ref) v_u_27, (ref) v_u_28, (copy) v_u_37
	if v_u_11.IsEnabled() then
		local v691 = v_u_23:GetAttribute("CombatMode")
		local v692
		if v691 == nil then
			v692 = v_u_23:GetAttribute("State") == "Match"
		else
			v692 = v691 == true
		end
		if v692 then
			return v_u_11.Shot(v_u_116(v_u_23.Character), v_u_24, v_u_25, v_u_27, v_u_28, v_u_37.CombatDraw ~= nil)
		end
	end
	return nil
end
function v_u_21.GetAimAssist(p693) -- name: GetAimAssist
	-- upvalues: (copy) v_u_21
	local v694 = v_u_21.GetAimAssistShot()
	if v694 and (p693 == nil or p693 >= v694.deg) then
		return v694.model, v694.part, v694.deg
	else
		return nil, nil, nil
	end
end
function v_u_21.IsAssistedInput() -- name: IsAssistedInput
	-- upvalues: (copy) v_u_11
	return v_u_11.IsAssistedInput()
end
function v_u_21.GetAimAssistInput() -- name: GetAimAssistInput
	-- upvalues: (copy) v_u_11
	return v_u_11.InputKind()
end
function v_u_21.Nudge(p695, p696) -- name: Nudge
	-- upvalues: (ref) v_u_24, (copy) v_u_11
	if typeof(p695) == "number" and p695 == p695 then
		if (p696 or 0) <= 0 then
			v_u_24 = (v_u_24 + p695 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
		else
			v_u_11.Nudge(p695, p696)
		end
	else
		return
	end
end
function v_u_21.SetAimAssist(p697) -- name: SetAimAssist
	-- upvalues: (copy) v_u_11
	v_u_11.SetEnabled(p697)
end
function v_u_21.GetAimAssistEnabled() -- name: GetAimAssistEnabled
	-- upvalues: (copy) v_u_11
	return v_u_11.IsEnabled()
end
function v_u_21.AimAssistDebug(p698, ...) -- name: AimAssistDebug
	-- upvalues: (copy) v_u_11
	return v_u_11.Debug(p698, ...)
end
function v_u_21.GetYaw() -- name: GetYaw
	-- upvalues: (ref) v_u_24
	return v_u_24
end
function v_u_21.GetPitch() -- name: GetPitch
	-- upvalues: (ref) v_u_25
	return v_u_25
end
function v_u_21.SetLook(p699, p700) -- name: SetLook
	-- upvalues: (ref) v_u_24, (ref) v_u_25, (ref) v_u_65, (ref) v_u_64
	v_u_24 = (p699 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
	if p700 then
		v_u_25 = math.clamp(p700, -1.3962634015954636, 1.361356816555577)
	end
	v_u_65 = v_u_64
end
function v_u_21.SetSensitivity(p701) -- name: SetSensitivity
	-- upvalues: (ref) v_u_31
	if typeof(p701) == "number" then
		v_u_31 = math.clamp(p701, 0.05, 5)
	end
end
function v_u_21.AddTouchLook(p702) -- name: AddTouchLook
	-- upvalues: (ref) v_u_73
	v_u_73 = v_u_73 + p702
end
function v_u_21.GetSensitivity() -- name: GetSensitivity
	-- upvalues: (ref) v_u_31
	return v_u_31
end
function v_u_21.SetFOV(p703) -- name: SetFOV
	-- upvalues: (ref) v_u_29
	if typeof(p703) == "number" then
		v_u_29 = math.clamp(p703, 60, 100)
	end
end
function v_u_21.GetFOV() -- name: GetFOV
	-- upvalues: (ref) v_u_29
	return v_u_29
end
function v_u_21.SetZoom(p704) -- name: SetZoom
	-- upvalues: (ref) v_u_30
	if typeof(p704) == "number" then
		v_u_30 = math.clamp(p704, 7, 14)
	end
end
function v_u_21.SpectateNext(p705) -- name: SpectateNext
	-- upvalues: (copy) v_u_8
	v_u_8.Next(typeof(p705) == "number" and p705 < 0 and -1 or 1)
end
function v_u_21.GetSpectateTarget() -- name: GetSpectateTarget
	-- upvalues: (copy) v_u_8
	return v_u_8.GetTarget()
end
function v_u_21.GetSpectateMode() -- name: GetSpectateMode
	-- upvalues: (copy) v_u_8
	return v_u_8.GetMode()
end
function v_u_21.GetKiller() -- name: GetKiller
	-- upvalues: (copy) v_u_8
	return v_u_8.GetKiller()
end
v_u_21.SpectateChanged = v_u_8.Changed
function v_u_21.PlayCinematic(p706, p707, p708) -- name: PlayCinematic
	-- upvalues: (ref) v_u_52, (ref) v_u_54, (ref) v_u_55, (ref) v_u_56, (ref) v_u_57, (copy) v_u_23, (ref) v_u_59, (copy) v_u_6, (ref) v_u_29
	if typeof(p706) == "CFrame" then
		local v709 = p708 or {}
		local v710 = {
			["cf"] = p706
		}
		local v711
		if typeof(p707) == "number" then
			v711 = math.clamp(p707, 20, 100)
		else
			v711 = nil
		end
		v710.fov = v711
		v710.hide = v709.hideCharacter ~= false
		v710.untilStopped = v709.untilStopped == true
		v_u_52 = v710
		v_u_54 = 1
		local v712 = v709.duration or 0.6
		v_u_55 = 1 / math.max(0.05, v712)
		v_u_56 = os.clock()
		local v713 = v_u_23
		if v713 then
			v713 = v_u_23.Character
		end
		v_u_57 = v713
		if not v710.fov then
			v_u_59 = v_u_6.CurrentCamera and v_u_6.CurrentCamera.FieldOfView or v_u_29
		end
	end
end
function v_u_21.StopCinematic(p714) -- name: StopCinematic
	-- upvalues: (ref) v_u_54, (ref) v_u_55
	v_u_54 = 0
	v_u_55 = 1 / math.max(0.05, p714 or 0.5)
end
function v_u_21.IsCinematic() -- name: IsCinematic
	-- upvalues: (ref) v_u_54
	return v_u_54 > 0
end
function v_u_21.SetEnabled(p715) -- name: SetEnabled
	-- upvalues: (ref) v_u_32, (copy) v_u_6, (ref) v_u_29, (copy) v_u_5, (copy) v_u_23, (ref) v_u_62, (ref) v_u_63, (copy) v_u_17, (ref) v_u_123, (copy) v_u_15, (copy) v_u_166, (ref) v_u_125, (copy) v_u_167, (copy) v_u_10, (ref) v_u_60
	v_u_32 = p715
	local v716 = v_u_6.CurrentCamera
	if p715 then
		v_u_60 = nil
	else
		if v716 then
			v716.CameraType = Enum.CameraType.Custom
			v716.FieldOfView = v_u_29
		end
		v_u_5.MouseBehavior = Enum.MouseBehavior.Default
		v_u_5.MouseIconEnabled = true
		local v717 = v_u_23
		if v717 then
			v717 = v_u_23.Character
		end
		if v717 then
			local v718 = v717:FindFirstChild("HumanoidRootPart")
			v717:FindFirstChildOfClass("Humanoid")
			local _ = v718 and (v718:IsA("BasePart") and v718)
		end
		v_u_62 = false
		if v_u_63 then
			v_u_17.SetFacing(nil)
			v_u_63 = false
		end
		v_u_123 = false
		v_u_15.Step(0, false)
		v_u_166(v_u_125, 0, 0)
		for v719 in v_u_167 do
			if not v719.Parent then
				continue
			end
			v719.LocalTransparencyModifier = 0
		end
		table.clear(v_u_167)
		v_u_10.ClearAllies()
		v_u_10.ClearDecor()
	end
end
function v_u_21.IsEnabled() -- name: IsEnabled
	-- upvalues: (ref) v_u_32
	return v_u_32
end
function v_u_21.DebugOcclusion(p720) -- name: DebugOcclusion
	-- upvalues: (copy) v_u_14
	return v_u_14.Debug(p720)
end
function v_u_21.GetDrawnRoot() -- name: GetDrawnRoot
	-- upvalues: (copy) v_u_13
	return v_u_13.DrawnCFrame()
end
function v_u_21.Drawn(p721) -- name: Drawn
	-- upvalues: (copy) v_u_13
	return v_u_13.Drawn(p721)
end
function v_u_21.GetDrawnModel() -- name: GetDrawnModel
	-- upvalues: (copy) v_u_13
	return v_u_13.DrawnModel()
end
v_u_21.DrawnChanged = v_u_13.DrawnChanged
function v_u_21.SmoothingTrace(p722) -- name: SmoothingTrace
	-- upvalues: (copy) v_u_13
	local v723 = v_u_13.Trace(p722)
	if v723 then
		return game:GetService("HttpService"):JSONEncode(v723)
	else
		return nil
	end
end
function v_u_21.DebugStats() -- name: DebugStats
	-- upvalues: (ref) v_u_49, (ref) v_u_46, (ref) v_u_48, (ref) v_u_47, (ref) v_u_74, (ref) v_u_75, (copy) v_u_10, (copy) v_u_11, (copy) v_u_13, (copy) v_u_14, (copy) v_u_16, (copy) v_u_4, (copy) v_u_17, (ref) v_u_123
	local v724 = os.clock()
	local v725 = v724 - v_u_49
	local v726 = math.max(0.001, v725)
	local v727 = {
		["msPerSec"] = v_u_46 * 1000 / v726,
		["msPerFrame"] = v_u_48 <= 0 and 0 or v_u_46 * 1000 / v_u_48,
		["maxFrameMs"] = v_u_47 * 1000,
		["fps"] = v_u_48 / v726,
		["touchLookPx"] = v_u_74,
		["touchesIgnored"] = v_u_75
	}
	v_u_46 = 0
	v_u_47 = 0
	v_u_48 = 0
	v_u_49 = v724
	for v728, v729 in v_u_10.Stats() do
		v727[v728] = v729
	end
	for v730, v731 in v_u_11.Stats() do
		v727[v730] = v731
	end
	for v732, v733 in v_u_13.Stats() do
		v727[v732] = v733
	end
	for v734, v735 in v_u_14.Debug("stats") do
		v727["occ_" .. v734] = v735
	end
	for v736, v737 in v_u_16.Stats() do
		v727["guard_" .. v736] = v737
	end
	if v_u_4:IsStudio() and v_u_17.WriteGuardStats then
		for v738, v739 in v_u_17.WriteGuardStats() do
			v727["wg_" .. v738] = v739
		end
	end
	v727.firstPerson = v_u_123
	v727.waterLifts = v_u_14.WaterLifts()
	return v727
end
if v_u_22 and v_u_23 then
	local v_u_740 = v_u_23:FindFirstChild("TribesCameraBridge")
	if v_u_740 and v_u_740:IsA("BindableFunction") then
		for v_u_741, v742 in v_u_21 do
			if type(v742) ~= "function" then
				continue
			end
			v_u_21[v_u_741] = function(...)
				-- upvalues: (copy) v_u_740, (copy) v_u_741
				return v_u_740:Invoke(v_u_741, ...)
			end
		end
	else
		local v743 = Instance.new("BindableFunction")
		v743.Name = "TribesCameraBridge"
		local v_u_744 = table.clone(v_u_21)
		function v743.OnInvoke(p745, ...)
			-- upvalues: (copy) v_u_744
			local v746 = v_u_744[p745]
			if type(v746) == "function" then
				return v746(...)
			else
				return nil
			end
		end
		v743.Parent = v_u_23
		v609()
	end
end
return v_u_21