local v_u_1 = game:GetService("Players")
local v2 = game:GetService("RunService")
local v_u_3 = require(script.Parent:WaitForChild("Controller"))
v_u_3.Start()
local v4, v5 = pcall(function()
	require(script.Parent:WaitForChild("Ping")).Start()
end)
if not v4 then
	warn("[Combat] Ping failed to start:", v5)
end
task.spawn(function()
	local v6 = game:GetService("ReplicatedStorage"):WaitForChild("Assets", 30)
	if v6 then
		v6 = v6:WaitForChild("Weapons", 30)
	end
	if v6 then
		local v_u_7 = {}
		for _, v8 in v6:GetDescendants() do
			if not v8:IsA("MeshPart") then
				continue
			end
			table.insert(v_u_7, v8)
		end
		if #v_u_7 > 0 then
			pcall(function()
				-- upvalues: (copy) v_u_7
				game:GetService("ContentProvider"):PreloadAsync(v_u_7)
			end)
		end
	end
end)
if v2:IsStudio() then
	local v9 = v_u_1.LocalPlayer:WaitForChild("PlayerScripts")
	local v10 = Instance.new("BindableFunction")
	v10.Name = "CombatDebug"
	function v10.OnInvoke(p11, ...)
		-- upvalues: (copy) v_u_3, (copy) v_u_1
		if p11 == "Dispatch" then
			local v12, v13 = ...
			v_u_3.Dispatch(v12, v13)
			return true
		end
		if p11 == "State" then
			return v_u_3.State()
		end
		if p11 ~= "Equip" then
			return nil
		end
		local v14 = ...
		local v15 = v_u_1.LocalPlayer:FindFirstChildOfClass("Backpack")
		if v15 then
			for _, v16 in v15:GetChildren() do
				if not v16:IsA("Tool") or v16:GetAttribute("SlotIndex") ~= v14 then
					continue
				end
				return v_u_3.Equip(v16)
			end
		end
		return false
	end
	v10.Parent = v9
end