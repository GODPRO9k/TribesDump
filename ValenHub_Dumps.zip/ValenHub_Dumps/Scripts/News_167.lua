return {
	["CURRENT"] = "ranks-2026-10",
	["SINCE"] = 1792252680
}