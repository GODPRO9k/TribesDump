local v_u_1 = game:GetService("Players")
local v_u_2 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Combat"))
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("CollectionService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = game:GetService("RunService")
local v_u_7 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Tribes"))
local v_u_8 = require(script.Parent.Parent.RankArt)
return {
	["Init"] = function(p_u_9) -- name: Init
		-- upvalues: (copy) v_u_1, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (copy) v_u_3, (copy) v_u_5, (copy) v_u_6, (copy) v_u_2
		local v_u_10 = p_u_9.UI
		local v_u_11 = p_u_9.Theme
		local v_u_12 = p_u_9.State
		local v_u_13 = v_u_11.Colors
		local v_u_14 = v_u_11.Fonts
		local v_u_15 = v_u_1.LocalPlayer
		local v_u_16 = Color3.fromRGB(226, 222, 212)
		local v_u_17 = v_u_11.Lighten(v_u_13.Ally, 0.1)
		local v_u_18 = v_u_11.Lighten(v_u_13.Enemy, 0.05)
		local v_u_19 = v_u_10.new("ScreenGui", {
			["Name"] = "TR_Nameplates",
			["ResetOnSpawn"] = false,
			["DisplayOrder"] = 0,
			["Parent"] = nil,
			["Parent"] = p_u_9.PlayerGui
		})
		local v_u_20 = v_u_10.new("ScreenGui", {
			["Name"] = "TR_Plates",
			["ResetOnSpawn"] = false,
			["IgnoreGuiInset"] = true,
			["DisplayOrder"] = 1,
			["ZIndexBehavior"] = nil,
			["Parent"] = nil,
			["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
			["Parent"] = p_u_9.PlayerGui
		})
		v_u_20.ScreenInsets = Enum.ScreenInsets.None
		local v_u_21 = {}
		local v_u_22 = RaycastParams.new()
		v_u_22.FilterType = Enum.RaycastFilterType.Exclude
		v_u_22.IgnoreWater = true
		local function v_u_25(p23) -- name: levelOf
			-- upvalues: (ref) v_u_1
			local v24 = p23:GetAttribute("Level")
			if type(v24) ~= "number" then
				v24 = v_u_1:GetPlayerFromCharacter(p23)
				if v24 then
					v24 = v24:GetAttribute("Level")
				end
			end
			if type(v24) == "number" and v24 >= 1 then
				return math.floor(v24)
			else
				return nil
			end
		end
		local function v_u_29(p26) -- name: tribeOf
			-- upvalues: (ref) v_u_1
			local v27 = p26:GetAttribute("TribeTag")
			local v28 = p26:GetAttribute("TribeColor1")
			if type(v27) ~= "string" or v27 == "" then
				v28 = v_u_1:GetPlayerFromCharacter(p26)
				if v28 then
					v27 = v28:GetAttribute("TribeTag")
				else
					v27 = v28
				end
				if v28 then
					v28 = v28:GetAttribute("TribeColor1")
				end
			end
			if type(v27) == "string" and v27 ~= "" then
				if type(v28) == "number" then
					return v27, v28
				else
					return v27, 1
				end
			else
				return nil, nil
			end
		end
		local function v_u_36(p30) -- name: roleOf
			-- upvalues: (copy) v_u_12, (ref) v_u_1
			if not v_u_12.SeesMatch() then
				local v31 = p30:GetAttribute("MatchId")
				local v32
				if type(v31) == "string" then
					v32 = v31 ~= ""
				else
					v32 = false
				end
				return v_u_1:GetPlayerFromCharacter(p30) and not v32 and "lobby" or "none"
			end
			local v33 = v_u_12.SeenMatchId()
			local v34 = p30:GetAttribute("MatchId")
			if type(v33) == "string" and (v33 ~= "" and (type(v34) == "string" and (v34 ~= "" and v34 ~= v33))) then
				return "none"
			end
			local v35 = p30:GetAttribute("Team")
			if type(v35) ~= "number" then
				v35 = v_u_1:GetPlayerFromCharacter(p30)
				if v35 then
					v35 = v35:GetAttribute("Team")
				end
			end
			return type(v35) == "number" and v35 ~= 0 and (v35 == v_u_12.MyTeam() and "ally" or "enemy") or "none"
		end
		local function v_u_55(p37) -- name: ensureBillboard
			-- upvalues: (copy) v_u_10, (copy) v_u_19, (ref) v_u_1, (copy) v_u_14, (copy) v_u_16, (copy) v_u_13
			if not p37.bb then
				local v38 = v_u_10.new("BillboardGui", {
					["Name"] = "Plate",
					["Size"] = nil,
					["StudsOffsetWorldSpace"] = Vector3.new(0, 1.9, 0),
					["LightInfluence"] = 0,
					["AlwaysOnTop"] = false,
					["MaxDistance"] = 90,
					["ResetOnSpawn"] = false,
					["Active"] = false,
					["Enabled"] = false,
					["Parent"] = nil,
					["Size"] = UDim2.new(5.5, 104, 0.6, 12),
					["Parent"] = v_u_19
				})
				local v39 = v_u_10.new
				local v40 = "TextLabel"
				local v41 = {
					["Name"] = "PlayerName",
					["Size"] = nil,
					["Text"] = nil,
					["RichText"] = true,
					["FontFace"] = nil,
					["TextScaled"] = true,
					["TextColor3"] = nil,
					["TextTruncate"] = nil,
					["Parent"] = nil,
					["Size"] = UDim2.fromScale(1, 1)
				}
				local v42 = p37.model
				local v43 = v42:GetAttribute("DisplayName")
				if type(v43) ~= "string" or v43 == "" then
					local v44 = v_u_1:GetPlayerFromCharacter(v42)
					if v44 then
						v43 = v44.DisplayName
					else
						v43 = v42.Name
					end
				end
				v41.Text = v43
				v41.FontFace = v_u_14.Heavy
				v41.TextColor3 = v_u_16
				v41.TextTruncate = Enum.TextTruncate.AtEnd
				v41.Parent = v38
				local v_u_45 = v39(v40, v41)
				v_u_10.new("UITextSizeConstraint", {
					["MaxTextSize"] = 20,
					["MinTextSize"] = 9,
					["Parent"] = nil,
					["Parent"] = v_u_45
				})
				v_u_10.TextStroke(v_u_13.Void, 1.6, 0.15).Parent = v_u_45
				local v_u_46 = v_u_10.new("Frame", {
					["Name"] = "RankEmblem",
					["AnchorPoint"] = nil,
					["BackgroundTransparency"] = 1,
					["Visible"] = false,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(1, 0.5),
					["Parent"] = v38
				})
				local function v54() -- name: place
					-- upvalues: (copy) v_u_45, (copy) v_u_46
					local v47 = v_u_45.TextBounds
					local v48 = v47.Y * 1.3
					local v49 = math.floor(v48)
					local v50 = math.max(10, v49)
					v_u_46.Size = UDim2.fromOffset(v50, v50)
					local v51 = v_u_46
					local v52 = UDim2.new
					local v53 = v47.X / 2
					v51.Position = v52(0.5, -math.floor(v53) - 2, 0.5, 0)
				end
				v_u_45:GetPropertyChangedSignal("TextBounds"):Connect(v54)
				v54()
				p37.bb = v38
				p37.bbName = v_u_45
				p37.bbRank = v_u_46
			end
		end
		local function v_u_60(p56) -- name: paintRank
			-- upvalues: (ref) v_u_1, (ref) v_u_8
			local v57 = p56.bbRank
			if v57 then
				local v58 = v_u_1:GetPlayerFromCharacter(p56.model)
				if v58 then
					if v58 == v_u_1.LocalPlayer then
						v58 = false
					else
						v58 = v58:GetAttribute("Trophies")
					end
				end
				if type(v58) == "number" then
					v_u_8.SetEmblem(v57, v_u_8.Ranks.RankOf(v58))
					for _, v59 in v57:GetChildren() do
						if not v59:IsA("GuiObject") then
							continue
						end
						v59.ZIndex = 2
					end
					v57.Visible = true
				else
					v57.Visible = false
				end
			else
				return
			end
		end
		local function v_u_72(p61) -- name: lobbyName
			-- upvalues: (copy) v_u_25, (copy) v_u_29, (ref) v_u_7, (ref) v_u_1
			local v62 = v_u_25(p61.model)
			local v63 = not v62 and "" or string.format("<font color=\"%s\">[%d]</font> ", "#AEB5C2", v62)
			local v64, v65 = v_u_29(p61.model)
			local v66 = not v64 and "" or string.format("<font color=\"#%s\">[%s]</font> ", v_u_7.TextColor(v65):ToHex(), (string.gsub(string.gsub(string.gsub(v64, "&", "&amp;"), "<", "&lt;"), ">", "&gt;")))
			local v67 = p61.model
			local v68 = v67:GetAttribute("DisplayName")
			if type(v68) ~= "string" or v68 == "" then
				local v69 = v_u_1:GetPlayerFromCharacter(v67)
				if v69 then
					v68 = v69.DisplayName
				else
					v68 = v67.Name
				end
			end
			local v70 = v63 .. v66 .. string.gsub(string.gsub(string.gsub(v68, "&", "&amp;"), "<", "&lt;"), ">", "&gt;")
			local v71 = v_u_1:GetPlayerFromCharacter(p61.model)
			if v71 then
				v71 = v71:GetAttribute("Streak")
			end
			if type(v71) == "number" and v71 >= 2 then
				return string.format("%s  <font color=\"#FFA24A\">\240\159\148\165 %d</font>", v70, (math.floor(v71)))
			else
				return v70
			end
		end
		local function v_u_84(p73) -- name: paintQueue
			-- upvalues: (ref) v_u_1, (copy) p_u_9, (copy) v_u_10, (copy) v_u_19, (copy) v_u_13, (copy) v_u_11, (ref) v_u_3, (copy) v_u_14
			local v74 = v_u_1:GetPlayerFromCharacter(p73.model)
			local v75
			if v74 == nil or (v74:GetAttribute("Queued") ~= true or (p73.role ~= "lobby" or p73.head == nil)) then
				v75 = false
			else
				v75 = not p_u_9.HudHidden
			end
			if v75 then
				local v76 = v74:GetAttribute("QueueFound") == true
				local v77 = p73.queueBB
				if not v77 then
					v77 = v_u_10.new("BillboardGui", {
						["Name"] = "QueueTag",
						["Size"] = nil,
						["StudsOffsetWorldSpace"] = Vector3.new(0, 3.05, 0),
						["LightInfluence"] = 0,
						["AlwaysOnTop"] = false,
						["MaxDistance"] = 90,
						["ResetOnSpawn"] = false,
						["Active"] = false,
						["Parent"] = nil,
						["Size"] = UDim2.new(2.9, 36, 0.5, 9),
						["Parent"] = v_u_19
					})
					local v78 = v_u_10.new("Frame", {
						["Name"] = "Pill",
						["Size"] = UDim2.fromScale(1, 1),
						["BackgroundColor3"] = v_u_13.Void,
						["BackgroundTransparency"] = 0.3,
						v_u_10.Corner(v_u_11.Radius.Pill),
						["Parent"] = v77
					})
					v_u_10.new("UIStroke", {
						["Name"] = "Rim",
						["Color"] = nil,
						["Thickness"] = 1.5,
						["Transparency"] = 0.2,
						["Parent"] = nil,
						["Color"] = v_u_13.Accent,
						["Parent"] = v78
					})
					v_u_10.new("UIListLayout", {
						["FillDirection"] = Enum.FillDirection.Horizontal,
						["HorizontalAlignment"] = Enum.HorizontalAlignment.Center,
						["VerticalAlignment"] = Enum.VerticalAlignment.Center,
						["Padding"] = UDim.new(0.04, 0),
						["SortOrder"] = Enum.SortOrder.LayoutOrder,
						["Parent"] = v78
					})
					v_u_3:Create(v_u_10.new("Frame", {
						["Name"] = "Dot",
						["Size"] = UDim2.fromScale(0.34, 0.34),
						["SizeConstraint"] = Enum.SizeConstraint.RelativeYY,
						["BackgroundColor3"] = v_u_13.Accent,
						["LayoutOrder"] = 1,
						v_u_10.Corner(v_u_11.Radius.Pill),
						["Parent"] = v78
					}), TweenInfo.new(0.7, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
						["BackgroundTransparency"] = 0.75
					}):Play()
					local v79 = {
						["MaxTextSize"] = 15,
						["MinTextSize"] = 7,
						["Parent"] = nil,
						["Parent"] = v_u_10.new("TextLabel", {
							["Name"] = "Label",
							["Size"] = nil,
							["Text"] = "IN QUEUE",
							["FontFace"] = nil,
							["TextScaled"] = true,
							["TextColor3"] = nil,
							["LayoutOrder"] = 2,
							["Parent"] = nil,
							["Size"] = UDim2.fromScale(0.72, 0.62),
							["FontFace"] = v_u_14.Heavy,
							["TextColor3"] = v_u_13.Text,
							["Parent"] = v78
						})
					}
					v_u_10.new("UITextSizeConstraint", v79)
					p73.queueBB = v77
				end
				local v80 = v77:FindFirstChild("Pill")
				local v81
				if v76 then
					v81 = v_u_13.Success
				else
					v81 = v_u_13.Accent
				end
				v80:FindFirstChild("Dot").BackgroundColor3 = v81
				v80:FindFirstChild("Rim").Color = v81
				local v82 = v80:FindFirstChild("Label")
				v82.Text = v76 and "MATCH FOUND" or "IN QUEUE"
				local v83
				if v76 then
					v83 = v_u_13.Success
				else
					v83 = v_u_13.Text
				end
				v82.TextColor3 = v83
				v77.Adornee = p73.head
				v77.Enabled = true
			elseif p73.queueBB then
				p73.queueBB.Enabled = false
			end
		end
		local function v_u_101(p85) -- name: ensureFlat
			-- upvalues: (copy) v_u_10, (copy) v_u_20, (copy) v_u_14, (copy) v_u_13, (copy) v_u_17
			if p85.flat then
				return p85.flat
			end
			local v86 = v_u_10.new("Frame", {
				["Name"] = "Plate",
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["Visible"] = false,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 1),
				["Size"] = UDim2.fromOffset(220, 38),
				["Parent"] = v_u_20
			})
			local v87 = v_u_10.new("UIScale", {
				["Parent"] = v86
			})
			local v88 = v_u_10.new("Frame", {
				["Name"] = "NameRow",
				["Size"] = UDim2.new(1, 0, 0, 22),
				v_u_10.List(Enum.FillDirection.Horizontal, 5, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
				["Parent"] = v86
			})
			local v89 = v_u_10.new("TextLabel", {
				["Name"] = "Level",
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 19,
				["TextColor3"] = nil,
				["LayoutOrder"] = 1,
				["Visible"] = false,
				["Parent"] = nil,
				["Size"] = UDim2.fromOffset(0, 22),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["FontFace"] = v_u_14.Heavy,
				["TextColor3"] = Color3.fromHex("#AEB5C2"),
				["Parent"] = v88
			})
			local v90 = v_u_10.TextStroke(v_u_13.Void, 1.8, 0.1)
			v90.Parent = v89
			local v91 = v_u_10.new
			local v92 = {
				["Name"] = "PlayerName",
				["Size"] = UDim2.fromOffset(0, 22),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["Text"] = "",
				["FontFace"] = v_u_14.Heavy,
				["TextSize"] = 19,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["LayoutOrder"] = 2,
				v_u_10.new("UISizeConstraint", {
					["MaxSize"] = Vector2.new(168, 22)
				}),
				["Parent"] = v88
			}
			local v93 = v91("TextLabel", v92)
			local v94 = v_u_10.TextStroke(v_u_13.Void, 1.8, 0.1)
			v94.Parent = v93
			local v95 = v_u_10.new("Frame", {
				["Name"] = "Bar",
				["AnchorPoint"] = Vector2.new(0.5, 1),
				["Position"] = UDim2.new(0.5, 0, 1, -4),
				["Size"] = UDim2.fromOffset(96, 8),
				["BackgroundColor3"] = v_u_13.Void,
				["BackgroundTransparency"] = 0.3,
				v_u_10.Corner(4),
				["Parent"] = v86
			})
			local v96 = v_u_10.new("Frame", {
				["Name"] = "Fill",
				["Size"] = UDim2.fromScale(1, 1),
				["BackgroundColor3"] = v_u_17,
				v_u_10.Corner(4),
				["Parent"] = v95
			})
			local v97 = v_u_10.new("Frame", {
				["Name"] = "Armor",
				["AnchorPoint"] = Vector2.new(0.5, 1),
				["Position"] = UDim2.new(0.5, 0, 1, -13),
				["Size"] = UDim2.fromOffset(96, 4),
				["BackgroundColor3"] = v_u_13.Void,
				["BackgroundTransparency"] = 0.4,
				["Visible"] = false,
				v_u_10.Corner(2),
				["Parent"] = v86
			})
			local v98 = v_u_10.new("Frame", {
				["Size"] = UDim2.fromScale(1, 1),
				["BackgroundColor3"] = v_u_13.Armor,
				v_u_10.Corner(2),
				["Parent"] = v97
			})
			local v99 = v_u_10.new("Frame", {
				["Name"] = "Chevron",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ClipsDescendants"] = true,
				["Visible"] = false,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 1),
				["Position"] = UDim2.new(0.5, 0, 1, -15),
				["Size"] = UDim2.fromOffset(18, 12),
				["Parent"] = v86
			})
			v_u_10.new("Frame", {
				["Name"] = "Tri",
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0),
				["Size"] = UDim2.fromOffset(15, 15),
				["Rotation"] = 45,
				["BackgroundColor3"] = v_u_17,
				v_u_10.Stroke(v_u_13.Void, 1.5, 0.2),
				["Parent"] = v99
			})
			local v100 = {
				["frame"] = nil,
				["scale"] = nil,
				["row"] = nil,
				["level"] = nil,
				["levelStroke"] = nil,
				["name"] = nil,
				["nameStroke"] = nil,
				["barBg"] = nil,
				["fill"] = nil,
				["chevron"] = nil,
				["armorBg"] = nil,
				["armorFill"] = nil,
				["bucket"] = 0,
				["mode"] = "full",
				["faded"] = false,
				["frame"] = v86,
				["scale"] = v87,
				["row"] = v88,
				["level"] = v89,
				["levelStroke"] = v90,
				["name"] = v93,
				["nameStroke"] = v94,
				["barBg"] = v95,
				["fill"] = v96,
				["chevron"] = v99,
				["armorBg"] = v97,
				["armorFill"] = v98
			}
			p85.flat = v100
			return v100
		end
		local function v_u_113(p102) -- name: paintArmor
			local v103 = p102.flat
			if v103 then
				local v104 = p102.model:GetAttribute("MaxArmor")
				local v105 = p102.model:GetAttribute("Armor")
				local v106 = type(v104) ~= "number" and 0 or v104
				local v107 = type(v105) ~= "number" and 0 or v105
				local v108 = v103.armorBg
				local v109
				if v106 > 0 and v107 > 0 then
					v109 = v103.mode ~= "bar"
				else
					v109 = false
				end
				v108.Visible = v109
				if v106 > 0 then
					local v110 = v103.armorFill
					local v111 = UDim2.fromScale
					local v112 = v107 / v106
					v110.Size = v111(math.clamp(v112, 0, 1), 1)
				end
			end
		end
		local function v_u_117(p114, p115) -- name: setFaded
			if p114.faded ~= p115 then
				p114.faded = p115
				local v116 = p115 and 0.4 or 0
				p114.name.TextTransparency = v116
				p114.nameStroke.Transparency = p115 and 0.5 or 0.1
				p114.level.TextTransparency = v116
				p114.levelStroke.Transparency = p115 and 0.5 or 0.1
				p114.fill.BackgroundTransparency = v116
				p114.barBg.BackgroundTransparency = p115 and 0.6 or 0.3
				p114.chevron:FindFirstChild("Tri").BackgroundTransparency = v116
			end
		end
		local function v_u_121(p118, p119) -- name: setOutline
			-- upvalues: (copy) v_u_13
			if p119 and not p118.outline then
				local v120 = Instance.new("Highlight")
				v120.Name = "TR_EnemyOutline"
				v120.Adornee = p118.model
				v120.DepthMode = Enum.HighlightDepthMode.Occluded
				v120.FillTransparency = 1
				v120.OutlineTransparency = 0.35
				v120.OutlineColor = v_u_13.Enemy
				v120.Parent = p118.model
				p118.outline = v120
			elseif not p119 and p118.outline then
				p118.outline:Destroy()
				p118.outline = nil
			end
		end
		local v_u_122 = {}
		local v_u_123 = table.create(12, 0)
		local v_u_124 = table.create(12, 0)
		local v_u_125 = table.create(12, 0)
		local v_u_126 = table.create(12, 0)
		local function v_u_129(p127, p128) -- name: byDistance
			return p127.dist < p128.dist
		end
		local function v_u_136(p130, p131, p132, p133, p134) -- name: overlaps
			-- upvalues: (copy) v_u_123, (copy) v_u_125, (copy) v_u_124, (copy) v_u_126
			for v135 = 1, p130 do
				if p131 >= v_u_123[v135] + v_u_125[v135] or (p131 + p133 <= v_u_123[v135] or (p132 >= v_u_124[v135] + v_u_126[v135] or p132 + p134 <= v_u_124[v135])) then
					continue
				end
				return true
			end
			return false
		end
		local v_u_137 = nil
		local function v_u_175() -- name: step
			-- upvalues: (ref) v_u_5, (copy) p_u_9, (copy) v_u_122, (copy) v_u_129, (copy) v_u_10, (copy) v_u_136, (copy) v_u_123, (copy) v_u_124, (copy) v_u_125, (copy) v_u_126
			local v138 = v_u_5.CurrentCamera
			if v138 then
				local v139 = v138.CFrame.Position
				local v140 = p_u_9.HudHidden
				for _, v141 in v_u_122 do
					local v142 = v141.head
					v141.onScreen = false
					if v142 and v141.flat then
						local v143 = v142.Position + Vector3.new(0, 1.9, 0)
						v141.dist = (v143 - v139).Magnitude
						local v144, v145 = v138:WorldToViewportPoint(v143)
						local v146 = v141.role == "ally" and 450 or 200
						if v145 then
							if v144.Z > 0 and v141.dist <= v146 then
								v145 = not v140
							else
								v145 = false
							end
						end
						v141.onScreen = v145
						local v147 = v144.X
						local v148 = v144.Y
						v141.sx = v147
						v141.sy = v148
					else
						v141.dist = (1 / 0)
					end
				end
				table.sort(v_u_122, v_u_129)
				local v149 = p_u_9.Scoreboard
				local v150, v151, v152
				if v149 and (v149.Parent and (v149.AbsoluteSize.X > 0 and v149.Parent.Visible)) then
					v150 = v149.AbsolutePosition.X - 8
					v151 = v149.AbsolutePosition.X + v149.AbsoluteSize.X + 8
					v152 = v149.AbsolutePosition.Y + v149.AbsoluteSize.Y + 6
				else
					v151 = 0
					v152 = -1
					v150 = 0
				end
				local v153 = v_u_10.Scale * (v_u_10.Compact and 1.3 or 1)
				local v154 = 0
				for _, v155 in v_u_122 do
					local v156 = v155.flat
					if not v156 then
						continue
					end
					if v155.onScreen then
						local v157 = v155.dist < 35 and 1 or (v155.dist < 90 and 2 or 3)
						if v157 ~= v156.bucket then
							v156.bucket = v157
							v156.scale.Scale = v153 * (v157 == 1 and 1 or (v157 == 2 and 0.85 or 0.72))
						end
						local v158 = v156.scale.Scale
						local v159 = v155.role == "ally" and v155.dist > 60 and "far" or "full"
						local v160 = (v159 == "full" and 38 or (v159 == "far" and 26 or 14)) * v158
						local v161 = (v159 == "full" and 150 or 100) * v158
						local v162 = v155.sx - v161 / 2
						local v163 = v155.sy
						local v164 = 0
						while v164 < 2 and v_u_136(v154, v162, v163 - v160, v161, v160) do
							v163 = v163 - (v160 + 2)
							v164 = v164 + 1
						end
						if v_u_136(v154, v162, v163 - v160, v161, v160) then
							v160 = 14 * v158
							v159 = "bar"
						end
						if v152 > 0 and (v150 < v155.sx and (v155.sx < v151 and v163 - v160 < v152)) then
							v163 = v152 + v160
						end
						if v154 < 12 then
							v154 = v154 + 1
							local v165 = v_u_123
							local v166 = v_u_124
							local v167 = v_u_125
							local v168 = v_u_126
							local v169 = v163 - v160
							v165[v154] = v162
							v166[v154] = v169
							v167[v154] = v161
							v168[v154] = v160
						end
						if v156.mode ~= v159 then
							v156.mode = v159
							v156.row.Visible = v159 == "full"
							v156.chevron.Visible = v159 == "far"
						end
						local v170 = v156.frame
						local v171 = UDim2.fromOffset
						local v172 = v155.sx + 0.5
						local v173 = math.floor(v172)
						local v174 = v163 + 0.5
						v170.Position = v171(v173, (math.floor(v174)))
						v156.frame.Visible = true
					else
						v156.frame.Visible = false
					end
				end
			end
		end
		local function v_u_181() -- name: refreshActive
			-- upvalues: (copy) v_u_122, (copy) v_u_21, (copy) v_u_121, (ref) v_u_137, (ref) v_u_6, (copy) v_u_175
			table.clear(v_u_122)
			for _, v176 in v_u_21 do
				local v177 = v176.head ~= nil and (v176.hum == nil and true or v176.hum.Health > 0)
				if v177 then
					if v176.role == "ally" then
						v177 = true
					elseif v176.role == "enemy" then
						v177 = v176.visibleLOS
					else
						v177 = false
					end
				end
				if v177 then
					v177 = #v_u_122 < 12
				end
				v176.listed = v177
				if v177 then
					local v178 = v_u_122
					table.insert(v178, v176)
				elseif v176.flat then
					v176.flat.frame.Visible = false
				end
				local v179 = v_u_121
				local v180 = v176.role == "enemy" and (v176.hum == nil and true or v176.hum.Health > 0)
				if v180 then
					if v176.head == nil then
						v180 = false
					else
						v180 = not v176.smoked
					end
				end
				v179(v176, v180)
			end
			if #v_u_122 > 0 and not v_u_137 then
				v_u_137 = v_u_6.RenderStepped:Connect(v_u_175)
			elseif #v_u_122 == 0 and v_u_137 then
				v_u_137:Disconnect()
				v_u_137 = nil
			end
		end
		v_u_10.ScaleChanged:Connect(function()
			-- upvalues: (copy) v_u_21
			for _, v182 in v_u_21 do
				if not v182.flat then
					continue
				end
				v182.flat.bucket = 0
			end
		end)
		local function v_u_203(p183) -- name: paint
			-- upvalues: (copy) v_u_101, (copy) v_u_17, (copy) v_u_18, (copy) v_u_25, (copy) v_u_29, (ref) v_u_1, (copy) v_u_113, (copy) p_u_9, (copy) v_u_55, (copy) v_u_72, (copy) v_u_60, (copy) v_u_84, (copy) v_u_181
			local v184 = p183.role
			if v184 == "ally" or v184 == "enemy" then
				local v185 = v_u_101(p183)
				local v186
				if v184 == "ally" then
					v186 = v_u_17
				else
					v186 = v_u_18
				end
				local v187 = v_u_25(p183.model)
				v185.level.Text = not v187 and "" or string.format("[%d]", v187)
				v185.level.Visible = v187 ~= nil
				local v188 = v185.name
				local v189, _ = v_u_29(p183.model)
				local v190 = not v189 and "" or "[" .. v189 .. "] "
				local v191 = p183.model
				local v192 = v191:GetAttribute("DisplayName")
				if type(v192) ~= "string" or v192 == "" then
					local v193 = v_u_1:GetPlayerFromCharacter(v191)
					if v193 then
						v192 = v193.DisplayName
					else
						v192 = v191.Name
					end
				end
				v188.Text = v190 .. v192
				v185.name.TextColor3 = v186
				v185.fill.BackgroundColor3 = v186
				local v194 = v185.fill
				local v195 = UDim2.fromScale
				local v196 = p183.hum
				local v197
				if v196 then
					if v196.MaxHealth > 0 then
						local v198 = v196.Health / v196.MaxHealth
						v197 = math.clamp(v198, 0, 1)
					else
						v197 = 0
					end
				else
					v197 = 1
				end
				v194.Size = v195(v197, 1)
				v185.chevron:FindFirstChild("Tri").BackgroundColor3 = v186
				v_u_113(p183)
				if v184 == "enemy" and v185.faded ~= false then
					v185.faded = false
					v185.name.TextTransparency = 0
					v185.nameStroke.Transparency = 0.1
					v185.level.TextTransparency = 0
					v185.levelStroke.Transparency = 0.1
					v185.fill.BackgroundTransparency = 0
					v185.barBg.BackgroundTransparency = 0.3
					v185.chevron:FindFirstChild("Tri").BackgroundTransparency = 0
				end
			end
			if p183.bb then
				local v199 = p183.bb
				local v200
				if v184 == "lobby" and p183.head ~= nil then
					v200 = not p_u_9.HudHidden
				else
					v200 = false
				end
				v199.Enabled = v200
			elseif v184 == "lobby" then
				v_u_55(p183)
				local v201 = p183.bb
				local v202
				if p183.head == nil then
					v202 = false
				else
					v202 = not p_u_9.HudHidden
				end
				v201.Enabled = v202
			end
			if p183.bb and p183.head then
				p183.bb.Adornee = p183.head
				p183.bbName.Text = v_u_72(p183)
				v_u_60(p183)
			end
			v_u_84(p183)
			v_u_181()
		end
		local function v_u_207(p204) -- name: detach
			-- upvalues: (copy) v_u_21, (copy) v_u_181
			local v205 = v_u_21[p204]
			if v205 then
				v_u_21[p204] = nil
				for _, v206 in v205.conns do
					v206:Disconnect()
				end
				if v205.outline then
					v205.outline:Destroy()
					v205.outline = nil
				end
				if v205.bb then
					v205.bb:Destroy()
				end
				if v205.queueBB then
					v205.queueBB:Destroy()
				end
				if v205.flat then
					v205.flat.frame:Destroy()
				end
				v_u_181()
			end
		end
		local function v_u_226(p_u_208, p_u_209) -- name: hookHumanoid
			-- upvalues: (copy) v_u_181
			p_u_208.hum = p_u_209
			pcall(function()
				-- upvalues: (copy) p_u_209
				p_u_209.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
			end)
			local v210 = p_u_208.conns
			local v211 = p_u_209.HealthChanged
			local function v219()
				-- upvalues: (copy) p_u_208, (ref) v_u_181
				local v212 = p_u_208
				if v212.flat then
					local v213 = v212.flat.fill
					local v214 = UDim2.fromScale
					local v215 = v212.hum
					local v216
					if v215 then
						if v215.MaxHealth > 0 then
							local v217 = v215.Health / v215.MaxHealth
							v216 = math.clamp(v217, 0, 1)
						else
							v216 = 0
						end
					else
						v216 = 1
					end
					v213.Size = v214(v216, 1)
				end
				local v218 = v212.hum == nil and true or v212.hum.Health > 0
				if v218 ~= v212.wasAlive then
					v212.wasAlive = v218
					v_u_181()
				end
			end
			table.insert(v210, v211:Connect(v219))
			if p_u_208.flat then
				local v220 = p_u_208.flat.fill
				local v221 = UDim2.fromScale
				local v222 = p_u_208.hum
				local v223
				if v222 then
					if v222.MaxHealth > 0 then
						local v224 = v222.Health / v222.MaxHealth
						v223 = math.clamp(v224, 0, 1)
					else
						v223 = 0
					end
				else
					v223 = 1
				end
				v220.Size = v221(v223, 1)
			end
			local v225 = p_u_208.hum == nil and true or p_u_208.hum.Health > 0
			if v225 ~= p_u_208.wasAlive then
				p_u_208.wasAlive = v225
				v_u_181()
			end
		end
		local v_u_227 = false
		local function v_u_258(p_u_228) -- name: attach
			-- upvalues: (copy) v_u_21, (copy) v_u_15, (ref) v_u_227, (copy) v_u_36, (copy) v_u_226, (copy) v_u_203, (copy) v_u_113, (copy) v_u_207
			if not v_u_21[p_u_228] and (p_u_228 ~= v_u_15.Character or v_u_227) then
				local v_u_229 = {
					["model"] = nil,
					["head"] = nil,
					["bb"] = nil,
					["bbName"] = nil,
					["bbRank"] = nil,
					["queueBB"] = nil,
					["flat"] = nil,
					["hum"] = nil,
					["conns"] = nil,
					["role"] = nil,
					["visibleLOS"] = false,
					["wasAlive"] = true,
					["listed"] = false,
					["smoked"] = false,
					["outline"] = nil,
					["sx"] = 0,
					["sy"] = 0,
					["dist"] = 0,
					["onScreen"] = false,
					["model"] = p_u_228,
					["conns"] = {},
					["role"] = v_u_36(p_u_228)
				}
				v_u_21[p_u_228] = v_u_229
				local v230 = p_u_228:FindFirstChildOfClass("Humanoid")
				if v230 then
					v_u_226(v_u_229, v230)
				end
				local v231 = v_u_229.conns
				local v232 = p_u_228.ChildAdded
				local function v236(p233)
					-- upvalues: (copy) v_u_229, (ref) v_u_203, (ref) v_u_226
					if p233.Name == "Head" then
						local v234 = v_u_229
						local v235 = v234.model:FindFirstChild("Head")
						if not (v235 and v235:IsA("BasePart")) then
							v235 = nil
						end
						v234.head = v235
						v_u_203(v234)
					elseif p233:IsA("Humanoid") and not v_u_229.hum then
						v_u_226(v_u_229, p233)
					end
				end
				table.insert(v231, v232:Connect(v236))
				local v237 = v_u_229.conns
				local v238 = p_u_228.ChildRemoved
				local function v242(p239)
					-- upvalues: (copy) v_u_229, (ref) v_u_203
					if p239.Name == "Head" then
						local v240 = v_u_229
						local v241 = v240.model:FindFirstChild("Head")
						if not (v241 and v241:IsA("BasePart")) then
							v241 = nil
						end
						v240.head = v241
						v_u_203(v240)
					end
				end
				table.insert(v237, v238:Connect(v242))
				local v243 = v_u_229.conns
				local v244 = p_u_228.AttributeChanged
				local function v246(p245)
					-- upvalues: (copy) v_u_229, (ref) v_u_36, (copy) p_u_228, (ref) v_u_203
					if p245 == "Team" or (p245 == "MatchId" or (p245 == "DisplayName" or p245 == "Level")) then
						v_u_229.role = v_u_36(p_u_228)
						v_u_203(v_u_229)
					end
				end
				table.insert(v243, v244:Connect(v246))
				local v247 = v_u_229.conns
				local v248 = p_u_228:GetAttributeChangedSignal("Armor")
				local function v249()
					-- upvalues: (ref) v_u_113, (copy) v_u_229
					v_u_113(v_u_229)
				end
				table.insert(v247, v248:Connect(v249))
				local v250 = v_u_229.conns
				local v251 = p_u_228:GetAttributeChangedSignal("MaxArmor")
				local function v252()
					-- upvalues: (ref) v_u_113, (copy) v_u_229
					v_u_113(v_u_229)
				end
				table.insert(v250, v251:Connect(v252))
				local v253 = v_u_229.conns
				local v254 = p_u_228.AncestryChanged
				local function v256(_, p255)
					-- upvalues: (ref) v_u_207, (copy) p_u_228
					if not p255 then
						v_u_207(p_u_228)
					end
				end
				table.insert(v253, v254:Connect(v256))
				local v257 = v_u_229.model:FindFirstChild("Head")
				if not (v257 and v257:IsA("BasePart")) then
					v257 = nil
				end
				v_u_229.head = v257
				v_u_203(v_u_229)
			end
		end
		local function v_u_273(p_u_259) -- name: watchPlayer
			-- upvalues: (copy) v_u_15, (ref) v_u_227, (copy) v_u_207, (ref) v_u_5, (copy) v_u_258, (copy) v_u_21, (copy) v_u_36, (copy) v_u_203, (copy) v_u_84, (copy) v_u_72, (copy) v_u_60
			if p_u_259 ~= v_u_15 or v_u_227 then
				local v_u_260 = nil
				local v_u_261 = nil
				local function v_u_263(p_u_262) -- name: setChar
					-- upvalues: (ref) v_u_260, (ref) v_u_207, (ref) v_u_261, (ref) v_u_5, (ref) v_u_258
					if v_u_260 ~= p_u_262 then
						if v_u_260 then
							v_u_207(v_u_260)
						end
						if v_u_261 then
							v_u_261:Disconnect()
							v_u_261 = nil
						end
						v_u_260 = p_u_262
						if p_u_262 then
							v_u_261 = p_u_262.AncestryChanged:Connect(function()
								-- upvalues: (ref) v_u_260, (copy) p_u_262, (ref) v_u_5, (ref) v_u_258
								if v_u_260 == p_u_262 and p_u_262:IsDescendantOf(v_u_5) then
									v_u_258(p_u_262)
								end
							end)
						end
					end
					if p_u_262 and p_u_262:IsDescendantOf(v_u_5) then
						v_u_258(p_u_262)
					end
				end
				p_u_259.CharacterAdded:Connect(v_u_263)
				p_u_259.CharacterRemoving:Connect(function(p264)
					-- upvalues: (ref) v_u_260, (ref) v_u_207, (ref) v_u_261
					if p264 == v_u_260 then
						if v_u_260 ~= nil then
							if v_u_260 then
								v_u_207(v_u_260)
							end
							if v_u_261 then
								v_u_261:Disconnect()
								v_u_261 = nil
							end
							v_u_260 = nil
							return
						end
					else
						v_u_207(p264)
					end
				end)
				p_u_259:GetPropertyChangedSignal("Character"):Connect(function()
					-- upvalues: (copy) v_u_263, (copy) p_u_259
					v_u_263(p_u_259.Character)
				end)
				p_u_259:GetAttributeChangedSignal("Team"):Connect(function()
					-- upvalues: (copy) p_u_259, (ref) v_u_21, (ref) v_u_36, (ref) v_u_203
					local v265 = p_u_259.Character
					local v266
					if v265 then
						v266 = v_u_21[v265]
					else
						v266 = v265
					end
					if v266 then
						v266.role = v_u_36(v265)
						v_u_203(v266)
					end
				end)
				for _, v267 in { "Queued", "QueueFound" } do
					p_u_259:GetAttributeChangedSignal(v267):Connect(function()
						-- upvalues: (copy) p_u_259, (ref) v_u_21, (ref) v_u_84
						local v268 = p_u_259.Character
						if v268 then
							v268 = v_u_21[v268]
						end
						if v268 then
							v_u_84(v268)
						end
					end)
				end
				p_u_259:GetAttributeChangedSignal("Streak"):Connect(function()
					-- upvalues: (copy) p_u_259, (ref) v_u_21, (ref) v_u_72
					local v269 = p_u_259.Character
					if v269 then
						v269 = v_u_21[v269]
					end
					if v269 and v269.bbName then
						v269.bbName.Text = v_u_72(v269)
					end
				end)
				p_u_259:GetAttributeChangedSignal("Trophies"):Connect(function()
					-- upvalues: (copy) p_u_259, (ref) v_u_21, (ref) v_u_60
					local v270 = p_u_259.Character
					if v270 then
						v270 = v_u_21[v270]
					end
					if v270 then
						v_u_60(v270)
					end
				end)
				p_u_259:GetAttributeChangedSignal("TribeTag"):Connect(function()
					-- upvalues: (copy) p_u_259, (ref) v_u_21, (ref) v_u_203
					local v271 = p_u_259.Character
					if v271 then
						v271 = v_u_21[v271]
					end
					if v271 then
						v_u_203(v271)
					end
				end)
				p_u_259:GetAttributeChangedSignal("Level"):Connect(function()
					-- upvalues: (copy) p_u_259, (ref) v_u_21, (ref) v_u_203
					local v272 = p_u_259.Character
					if v272 then
						v272 = v_u_21[v272]
					end
					if v272 then
						v_u_203(v272)
					end
				end)
				v_u_263(p_u_259.Character)
			end
		end
		local v_u_274 = v_u_137
		local v_u_275 = v_u_227
		for _, v276 in v_u_1:GetPlayers() do
			v_u_273(v276)
		end
		v_u_1.PlayerAdded:Connect(v_u_273)
		local v_u_277 = nil
		local v_u_278 = nil
		local v_u_279 = nil
		local function v_u_293() -- name: paintSelf
			-- upvalues: (copy) v_u_15, (copy) v_u_12, (copy) p_u_9, (ref) v_u_275, (ref) v_u_277, (copy) v_u_10, (copy) v_u_19, (copy) v_u_14, (copy) v_u_13, (ref) v_u_278, (ref) v_u_279
			local v280 = v_u_15:GetAttribute("Streak")
			local v281 = v_u_15.Character
			if v281 then
				v281 = v281:FindFirstChild("Head")
			end
			local v282 = type(v280) == "number" and (v280 >= 2 and v281 ~= nil) and not (v_u_12.SeesMatch() or p_u_9.HudHidden)
			if v282 then
				v282 = not v_u_275
			end
			if v282 then
				if not v_u_277 then
					local v283 = v_u_10.new("BillboardGui", {
						["Name"] = "MyStreak",
						["Size"] = nil,
						["StudsOffsetWorldSpace"] = Vector3.new(0, 1.9, 0),
						["LightInfluence"] = 0,
						["AlwaysOnTop"] = false,
						["MaxDistance"] = 90,
						["ResetOnSpawn"] = false,
						["Active"] = false,
						["Parent"] = nil,
						["Size"] = UDim2.new(2.2, 40, 0.6, 12),
						["Parent"] = v_u_19
					})
					local v284 = v_u_10.new("TextLabel", {
						["Name"] = "Streak",
						["Size"] = nil,
						["Text"] = "",
						["FontFace"] = nil,
						["TextScaled"] = true,
						["TextColor3"] = nil,
						["Parent"] = nil,
						["Size"] = UDim2.fromScale(1, 1),
						["FontFace"] = v_u_14.Heavy,
						["TextColor3"] = Color3.fromRGB(255, 162, 74),
						["Parent"] = v283
					})
					v_u_10.new("UITextSizeConstraint", {
						["MaxTextSize"] = 22,
						["MinTextSize"] = 10,
						["Parent"] = nil,
						["Parent"] = v284
					})
					v_u_10.TextStroke(v_u_13.Void, 1.6, 0.15).Parent = v284
					v_u_277 = v283
					v_u_278 = v284
				end
				local v285 = v_u_277
				if v_u_279 == nil then
					local v286, v287 = pcall(function()
						return require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Camera"))
					end)
					if not v286 or type(v287) ~= "table" then
						v287 = false
					end
					v_u_279 = v287
				end
				local v288 = v_u_279 or nil
				if v288 then
					local v289 = v288.Drawn
					if type(v289) == "function" then
						local v290 = v288.Drawn
						local v291, v292 = pcall(v290, v281)
						if v291 and typeof(v292) == "Instance" then
							v281 = v292
						end
					end
				end
				v285.Adornee = v281
				v_u_278.Text = string.format("\240\159\148\165 %d", (math.floor(v280)))
				v285.Enabled = true
			elseif v_u_277 then
				v_u_277.Enabled = false
			end
		end
		v_u_15:GetAttributeChangedSignal("Streak"):Connect(v_u_293)
		task.spawn(function()
			-- upvalues: (ref) v_u_279, (copy) v_u_293
			if v_u_279 == nil then
				local v294, v295 = pcall(function()
					return require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Camera"))
				end)
				if not v294 or type(v295) ~= "table" then
					v295 = false
				end
				v_u_279 = v295
			end
			local v296 = v_u_279 or nil
			if v296 then
				v296 = v296.DrawnChanged
			end
			if v296 then
				v296:Connect(function()
					-- upvalues: (ref) v_u_293
					task.defer(v_u_293)
				end)
			end
		end)
		v_u_15.CharacterAdded:Connect(function(p297)
			-- upvalues: (copy) v_u_293
			p297:WaitForChild("Head", 10)
			v_u_293()
		end)
		v_u_12.PlayerStateChanged:Connect(v_u_293)
		p_u_9.HudHiddenChanged:Connect(v_u_293)
		task.defer(v_u_293)
		local function v299(p298) -- name: addFighter
			-- upvalues: (ref) v_u_1, (copy) v_u_258
			if p298:IsA("Model") and not v_u_1:GetPlayerFromCharacter(p298) then
				v_u_258(p298)
			end
		end
		for _, v300 in { "Combatant", "Bot" } do
			for _, v301 in v_u_4:GetTagged(v300) do
				if not v301:IsA("Model") or v_u_1:GetPlayerFromCharacter(v301) then
					continue
				end
				v_u_258(v301)
			end
			v_u_4:GetInstanceAddedSignal(v300):Connect(v299)
			v_u_4:GetInstanceRemovedSignal(v300):Connect(function(p302)
				-- upvalues: (ref) v_u_4, (ref) v_u_1, (copy) v_u_207
				if p302:IsA("Model") and not (v_u_4:HasTag(p302, "Combatant") or v_u_4:HasTag(p302, "Bot") or v_u_1:GetPlayerFromCharacter(p302)) then
					v_u_207(p302)
				end
			end)
		end
		local function v_u_305() -- name: repaintAll
			-- upvalues: (copy) v_u_21, (copy) v_u_36, (copy) v_u_203
			for v303, v304 in v_u_21 do
				v304.role = v_u_36(v303)
				v_u_203(v304)
			end
		end
		v_u_12.PlayerStateChanged:Connect(v_u_305)
		v_u_12.WatchChanged:Connect(v_u_305)
		v_u_12.AttrChanged:Connect(function(p306)
			-- upvalues: (copy) v_u_305
			if p306 == "Team" or p306 == "MatchId" then
				v_u_305()
			end
		end)
		v_u_12.MatchChanged:Connect(function()
			-- upvalues: (copy) v_u_21, (copy) v_u_36, (copy) v_u_203
			for v307, v308 in v_u_21 do
				local v309 = v_u_36(v307)
				if v309 == v308.role then
					continue
				end
				v308.role = v309
				v_u_203(v308)
			end
		end)
		p_u_9.HudHiddenChanged:Connect(function()
			-- upvalues: (copy) v_u_21, (copy) p_u_9, (copy) v_u_84
			for _, v310 in v_u_21 do
				if v310.flat and p_u_9.HudHidden then
					v310.flat.frame.Visible = false
				end
				if v310.bb then
					local v311 = v310.bb
					local v312
					if v310.role == "lobby" and v310.head ~= nil then
						v312 = not p_u_9.HudHidden
					else
						v312 = false
					end
					v311.Enabled = v312
				end
				v_u_84(v310)
			end
		end)
		local v_u_313 = {}
		local v_u_314 = 0
		v_u_10.Every(v_u_19, 0.2, function()
			-- upvalues: (ref) v_u_314, (ref) v_u_1, (copy) v_u_15, (ref) v_u_275, (copy) v_u_21, (ref) v_u_5, (copy) v_u_258, (copy) v_u_12, (copy) v_u_313, (copy) v_u_22, (ref) v_u_2, (copy) v_u_117, (copy) v_u_122, (copy) v_u_181
			local v315 = os.clock()
			if v_u_314 <= v315 then
				v_u_314 = v315 + 1
				for _, v316 in v_u_1:GetPlayers() do
					local v317 = v316.Character
					if not v317 or v316 == v_u_15 and not v_u_275 or (v_u_21[v317] or not v317:IsDescendantOf(v_u_5)) then
						continue
					end
					v_u_258(v317)
				end
			end
			if v_u_12.SeesMatch() then
				local v318 = v_u_5.CurrentCamera
				if v318 then
					local v319 = v318.CFrame.Position
					local v320 = v_u_15.Character
					if v320 then
						v320 = v_u_15.Character:FindFirstChild("Head")
					end
					local v321
					if v320 and (v320:IsA("BasePart") and not v_u_12.Watching()) then
						v321 = v320.Position
					else
						v321 = nil
					end
					local v322 = false
					for v323, v324 in v_u_21 do
						if v324.role == "enemy" or v324.role == "ally" then
							local v325 = false
							local v326 = false
							local v327 = v324.head
							local v328 = v324.role == "enemy" and 200 or 450
							if v327 and (v324.hum == nil or v324.hum.Health > 0) then
								local v329 = v327.Position - v319
								if v329.Magnitude <= v328 then
									table.clear(v_u_313)
									local v330 = v_u_313
									table.insert(v330, v323)
									if v_u_15.Character then
										local v331 = v_u_313
										local v332 = v_u_15.Character
										table.insert(v331, v332)
									end
									local v333 = v_u_5:FindFirstChild("FX")
									if v333 then
										local v334 = v_u_313
										table.insert(v334, v333)
									end
									local v335 = v_u_5:FindFirstChild("Projectiles")
									if v335 then
										local v336 = v_u_313
										table.insert(v336, v335)
									end
									v_u_22.FilterDescendantsInstances = v_u_313
									v325 = v_u_5:Raycast(v319, v329, v_u_22) == nil
								end
								if v324.role == "enemy" then
									v326 = v_u_2.SmokeBlocks(v319, v327.Position)
									if not v326 then
										if v321 == nil then
											v326 = false
										else
											v326 = v_u_2.SmokeBlocks(v321, v327.Position)
										end
									end
									if v325 then
										v325 = not v326
									end
								end
							end
							if v326 ~= v324.smoked then
								v324.smoked = v326
								v322 = true
							end
							if v324.role == "ally" and v324.flat then
								v_u_117(v324.flat, not v325)
							else
								v322 = v325 ~= v324.visibleLOS and true or v322
							end
							v324.visibleLOS = v325
						end
						local v337 = v324.head ~= nil and (v324.hum == nil and true or v324.hum.Health > 0)
						if v337 then
							if v324.role == "ally" then
								v337 = true
							elseif v324.role == "enemy" then
								v337 = v324.visibleLOS
							else
								v337 = false
							end
						end
						if v337 == v324.listed or v337 and #v_u_122 >= 12 then
							local v338 = v324.outline ~= nil
							local v339 = v324.role == "enemy" and (v324.hum == nil and true or v324.hum.Health > 0)
							if v339 then
								if v324.head == nil then
									v339 = false
								else
									v339 = not v324.smoked
								end
							end
							if v338 == v339 then
								continue
							end
						end
						v322 = true
					end
					if v322 then
						v_u_181()
					end
				end
			else
				return
			end
		end)
		function p_u_9.Debug.plateSelf(p340)
			-- upvalues: (ref) v_u_275, (copy) v_u_15, (copy) v_u_273, (copy) v_u_21, (copy) v_u_207, (copy) v_u_293
			v_u_275 = p340 == true
			local v341 = v_u_15.Character
			if v_u_275 then
				v_u_273(v_u_15)
			elseif v341 and v_u_21[v341] then
				v_u_207(v341)
			end
			v_u_293()
			return true
		end
		function p_u_9.Debug.plates()
			-- upvalues: (copy) v_u_122, (copy) v_u_21, (ref) v_u_1, (ref) v_u_274, (copy) p_u_9
			local v342 = {}
			for _, v343 in v_u_122 do
				v342[v343] = true
			end
			local v344 = {}
			for v345, v346 in v_u_21 do
				local v347 = {}
				local v348 = v345:GetAttribute("DisplayName")
				if type(v348) ~= "string" or v348 == "" then
					local v349 = v_u_1:GetPlayerFromCharacter(v345)
					if v349 then
						v348 = v349.DisplayName
					else
						v348 = v345.Name
					end
				end
				v347.name = v348
				v347.role = v346.role
				v347.head = v346.head ~= nil
				v347.alive = v346.hum == nil and true or v346.hum.Health > 0
				local v350
				if v346.hum then
					local v351 = v346.hum.Health
					v350 = math.floor(v351)
				else
					v350 = -1
				end
				v347.hp = v350
				v347.los = v346.visibleLOS
				v347.smoked = v346.smoked
				v347.active = v342[v346] == true
				local v352
				if v346.flat == nil then
					v352 = false
				else
					v352 = v346.flat.frame.Visible
				end
				v347.visible = v352
				v347.onScreen = v346.onScreen
				v347.parent = not v345.Parent and "nil" or v345.Parent.Name
				table.insert(v344, v347)
			end
			return {
				["plates"] = v344,
				["render"] = v_u_274 ~= nil,
				["hudHidden"] = p_u_9.HudHidden == true
			}
		end
	end
}