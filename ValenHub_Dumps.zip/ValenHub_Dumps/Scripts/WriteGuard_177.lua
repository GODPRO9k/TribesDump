local v_u_1 = game:GetService("RunService")
local v2 = {}
local v_u_3 = {
	["checks"] = 0,
	["violations"] = 0,
	["cframe"] = 0,
	["velocity"] = 0,
	["attributes"] = 0,
	["atRenderStart"] = 0,
	["atRenderEnd"] = 0,
	["atPreAnimation"] = 0,
	["atPreSimulation"] = 0,
	["rollbacks"] = 0
}
local v_u_4 = {}
local v_u_5 = false
function v2.Start(p_u_6) -- name: Start
	-- upvalues: (ref) v_u_5, (copy) v_u_1, (copy) v_u_3, (copy) v_u_4
	if not v_u_5 and (v_u_1:IsStudio() and v_u_1:IsClient()) then
		v_u_5 = true
		local v_u_7 = nil
		local v_u_8 = nil
		local v_u_9 = nil
		local v_u_10 = nil
		local v_u_11 = {}
		local function v16() -- name: record
			-- upvalues: (copy) p_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (copy) v_u_11
			local v12 = p_u_6.Character
			if v12 then
				v12 = v12:FindFirstChild("HumanoidRootPart")
			end
			if v12 and v12:IsA("BasePart") then
				local v13 = v12.CFrame
				local v14 = v12.AssemblyLinearVelocity
				local v15 = v12:GetAttributes()
				v_u_7 = v12
				v_u_8 = v13
				v_u_9 = v14
				v_u_10 = v15
			else
				v_u_7 = nil
				v_u_8 = nil
				v_u_9 = nil
				v_u_10 = nil
			end
			table.clear(v_u_11)
		end
		local function v_u_27(p17, p18, p19) -- name: flag
			-- upvalues: (ref) v_u_3, (ref) v_u_4
			local v20 = v_u_3
			v20.violations = v20.violations + 1
			local v21 = v_u_3
			v21[p18] = v21[p18] + 1
			local v22 = v_u_3
			local v23 = "at" .. p17
			v22[v23] = v22[v23] + 1
			if #v_u_4 < 30 then
				local v24 = v_u_4
				local v25 = string.format
				local v26 = os.clock()
				table.insert(v24, v25("%.2f %s %s %s", v26, p17, p18, p19))
				if #v_u_4 <= 5 then
					warn((("[WriteGuard] the predicted root changed outside the simulation (%*, %*): %*"):format(p17, p18, p19)))
				end
			end
		end
		local function v_u_45(p28) -- name: check
			-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (copy) v_u_11, (copy) p_u_6, (ref) v_u_3, (copy) v_u_27
			local v29 = v_u_7
			local v30 = v_u_8
			local v31 = v_u_9
			local v32 = v_u_10
			if v29 and (v30 and (v31 and (v32 and not v_u_11[p28]))) then
				local v33 = p_u_6.Character
				if v33 and v29.Parent == v33 then
					local v34 = v_u_3
					v34.checks = v34.checks + 1
					local v35 = v29.CFrame
					local v36
					if (v35.Position - v30.Position).Magnitude > 0.0001 or (v35.XVector - v30.XVector).Magnitude > 0.0001 then
						v36 = false
					else
						v36 = (v35.YVector - v30.YVector).Magnitude <= 0.0001
					end
					if v36 then
						local v37 = v29.AssemblyLinearVelocity
						if (v37 - v31).Magnitude > 0.0001 then
							v_u_11[p28] = true
							v_u_27(p28, "velocity", string.format("dv %.4f", (v37 - v31).Magnitude))
						else
							local v38 = v29:GetAttributes()
							for v39, v40 in v38 do
								if v32[v39] == v40 then
									continue
								end
								v_u_11[p28] = true
								local v41 = v_u_27
								local v42 = string.format
								local v43 = v32[v39]
								v41(p28, "attributes", v42("@%s %s>%s", v39, tostring(v43), (tostring(v40))))
								return
							end
							for v44 in v32 do
								if v38[v44] ~= nil then
									continue
								end
								v_u_11[p28] = true
								v_u_27(p28, "attributes", string.format("@%s removed", v44))
								return
							end
						end
					else
						v_u_11[p28] = true
						v_u_27(p28, "cframe", string.format("moved %.4f", (v35.Position - v30.Position).Magnitude))
						return
					end
				else
					return
				end
			else
				return
			end
		end
		v_u_1.PostSimulation:Connect(v16)
		v_u_1:BindToRenderStep("TribesWriteGuardStart", Enum.RenderPriority.First.Value - 1, function()
			-- upvalues: (copy) v_u_45
			v_u_45("RenderStart")
		end)
		v_u_1:BindToRenderStep("TribesWriteGuardEnd", Enum.RenderPriority.Last.Value + 2, function()
			-- upvalues: (copy) v_u_45
			v_u_45("RenderEnd")
		end)
		v_u_1.PreAnimation:Connect(function()
			-- upvalues: (copy) v_u_45
			v_u_45("PreAnimation")
		end)
		v_u_1.PreSimulation:Connect(function()
			-- upvalues: (copy) v_u_45
			v_u_45("PreSimulation")
		end)
		local function v47()
			-- upvalues: (ref) v_u_1, (ref) v_u_3
			v_u_1.Rollback:Connect(function()
				-- upvalues: (ref) v_u_3
				local v46 = v_u_3
				v46.rollbacks = v46.rollbacks + 1
			end)
		end
		pcall(v47)
	end
end
function v2.Stats() -- name: Stats
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v48 = {}
	for v49, v50 in v_u_3 do
		v48[v49] = v50
	end
	v48.log = table.concat(v_u_4, " | ")
	return v48
end
function v2.Reset() -- name: Reset
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	for v51 in v_u_3 do
		v_u_3[v51] = 0
	end
	table.clear(v_u_4)
end
return v2