local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.Ranks)
local v_u_3 = require(script.Parent.Parent.RankArt)
return {
	["Init"] = function(p_u_4) -- name: Init
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		local v_u_5 = p_u_4.UI
		local v_u_6 = p_u_4.Theme
		local v_u_7 = p_u_4.State
		local v_u_8 = p_u_4.MenuManager
		local v_u_9 = v_u_6.Colors
		local v_u_10 = v_u_6.Fonts
		local v_u_11 = p_u_4.Economy
		local v_u_12 = nil
		local v_u_13 = {}
		local v_u_14 = nil
		local v_u_15 = nil
		local function v_u_16() -- name: close
			-- upvalues: (copy) v_u_8
			v_u_8.Close("Ranks")
		end
		local v_u_17 = nil
		local function v_u_46(p18, p_u_19, p20, p21, p22, p_u_23) -- name: weaponTile
			-- upvalues: (copy) v_u_5, (copy) v_u_9, (copy) v_u_6, (copy) p_u_4, (copy) v_u_11, (copy) v_u_10, (ref) v_u_17
			local v24 = v_u_5.new
			local v25 = "TextButton"
			local v26 = {
				["Name"] = "W_" .. p_u_19,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["Selectable"] = true,
				["Size"] = UDim2.fromOffset(100, 100),
				["BackgroundColor3"] = v_u_9.PanelHi,
				["BackgroundTransparency"] = 0.2,
				["LayoutOrder"] = p20
			}
			local v27 = v_u_5.Corner(v_u_6.Radius.Large)
			local v28 = v_u_5.Stroke
			local v29
			if p21 then
				v29 = p22
			else
				v29 = v_u_9.StrokeSoft
			end
			__set_list(v26, 1, {v27, (v28(v29, 1.5, p21 and 0.35 or 0.4))})
			v26.Parent = p18
			local v_u_30 = v24(v25, v26)
			local v31 = v_u_5.new("Frame", {
				["Name"] = "Icon",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 4),
				["Size"] = UDim2.fromOffset(54, 54),
				["Parent"] = v_u_30
			})
			p_u_4.WeaponIcon.Set(v31, p_u_19, {
				["outline"] = false
			})
			local v32
			if v_u_11 then
				v32 = v_u_11.Owns(p_u_19) or false
			else
				v32 = false
			end
			local v33 = p_u_4.WeaponIcon.SetDim
			local v34 = not v32
			if v34 then
				v34 = not p21
			end
			v33(v31, v34)
			local v35 = {
				["Name"] = "Name",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = nil,
				["TextSize"] = 13,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 59),
				["Size"] = UDim2.new(1, -8, 0, 15),
				["Text"] = string.upper(p_u_4.WeaponInfo.Name(p_u_19)),
				["TextXAlignment"] = Enum.TextXAlignment.Center,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v_u_30
			}
			local v36 = table.clone(v35)
			v36.FontFace = v36.FontFace or v_u_10.Heavy
			v36.TextColor3 = v36.TextColor3 or v_u_9.Text
			v36.TextXAlignment = v36.TextXAlignment or Enum.TextXAlignment.Left
			v_u_5.new("TextLabel", v36)
			local v_u_37 = v_u_5.new("UIScale", {
				["Scale"] = 1,
				["Parent"] = nil,
				["Parent"] = v_u_30
			})
			v_u_30.MouseEnter:Connect(function()
				-- upvalues: (ref) v_u_5, (ref) p_u_4, (copy) v_u_37, (ref) v_u_6
				if not v_u_5.Touch then
					p_u_4.Sounds.Play("Hover")
					v_u_5.Tween(v_u_37, v_u_6.Tween.PopSmall, {
						["Scale"] = 1.06
					})
				end
			end)
			v_u_30.MouseLeave:Connect(function()
				-- upvalues: (ref) v_u_5, (copy) v_u_37, (ref) v_u_6
				v_u_5.Tween(v_u_37, v_u_6.Tween.Fast, {
					["Scale"] = 1
				})
			end)
			v_u_30.Activated:Connect(function()
				-- upvalues: (ref) p_u_4, (ref) v_u_17, (copy) p_u_19, (copy) p_u_23
				p_u_4.Sounds.Play("Click")
				v_u_17(p_u_19, p_u_23)
			end)
			local function v43(p38, p39, p40) -- name: status
				-- upvalues: (ref) v_u_10, (copy) v_u_30, (ref) v_u_9, (ref) v_u_5
				local v41 = {
					["Name"] = "Status",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = nil,
					["FontFace"] = nil,
					["TextSize"] = 11,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0),
					["Position"] = UDim2.new(0.5, 0, 0, p40),
					["Size"] = UDim2.new(1, -8, 0, 13),
					["Text"] = p38,
					["FontFace"] = v_u_10.Bold,
					["TextColor3"] = p39,
					["TextXAlignment"] = Enum.TextXAlignment.Center,
					["Parent"] = v_u_30
				}
				local v42 = table.clone(v41)
				v42.FontFace = v42.FontFace or v_u_10.Heavy
				v42.TextColor3 = v42.TextColor3 or v_u_9.Text
				v42.TextXAlignment = v42.TextXAlignment or Enum.TextXAlignment.Left
				v_u_5.new("TextLabel", v42)
			end
			if v32 then
				v43("OWNED", v_u_6.Lighten(v_u_9.Success, 0.1), 78)
				return v_u_30
			end
			if not (p21 and v_u_11) then
				v_u_5.Glyph("lock-closed", 16, v_u_9.TextDim, {
					["Name"] = "Lock",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0),
					["Position"] = UDim2.new(0.5, 0, 0, 78),
					["Parent"] = v_u_30
				})
				return v_u_30
			end
			local v44, v45 = v_u_11.Progress(p_u_19)
			v_u_5.Bar({
				["Name"] = "Shards",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Color"] = nil,
				["Stroke"] = false,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 77),
				["Size"] = UDim2.fromOffset(70, 5),
				["Color"] = p22,
				["Parent"] = v_u_30
			}).Set(v45 <= 0 and 0 or v44 / v45, true)
			v43(string.format("%d / %d", v44, v45), v_u_9.TextDim, 84)
			return v_u_30
		end
		local function v_u_74(p47, p48) -- name: paintRow
			-- upvalues: (ref) v_u_2, (ref) v_u_3, (copy) v_u_7, (ref) v_u_15, (copy) v_u_9, (copy) v_u_46, (copy) v_u_6, (copy) v_u_5
			local v49 = v_u_2.Get(p48)
			local v50 = v_u_3.Color(p48)
			local v51 = (v_u_7.Profile or {}).rankBest
			local v52 = tonumber(v51) or 1
			local v53 = v_u_2.RankOf
			local v54
			if v_u_15 then
				v54 = v_u_15
			else
				local v55 = 0
				local v56 = (v_u_7.Profile or {}).trophies
				local v57 = tonumber(v56)
				if not v57 then
					local v58 = v_u_7.Get
					v57 = tonumber(v58("Trophies")) or 0
				end
				v54 = math.max(v55, v57)
			end
			local v59 = math.max(v52, v53(v54))
			local v60
			if v_u_15 then
				v60 = v_u_15
			else
				local v61 = 0
				local v62 = (v_u_7.Profile or {}).trophies
				local v63 = tonumber(v62)
				if not v63 then
					local v64 = v_u_7.Get
					v63 = tonumber(v64("Trophies")) or 0
				end
				v60 = math.max(v61, v63)
			end
			local v65 = p48 <= v59
			local v66 = p48 == v_u_2.RankOf(v60)
			local v67 = p47.stroke
			local v68
			if v66 then
				v68 = v50
			else
				v68 = v_u_9.Stroke
			end
			v67.Color = v68
			p47.stroke.Transparency = v66 and 0.15 or 0.9
			p47.frame.BackgroundTransparency = v66 and 0.05 or 0.25
			local v69 = p47.name
			local v70
			if v65 then
				v70 = v50
			else
				v70 = v_u_9.TextDim
			end
			v69.TextColor3 = v70
			p47.emblemHolder.GroupTransparency = v65 and 0 or 0.45
			for _, v71 in p47.weapons:GetChildren() do
				if not v71:IsA("GuiObject") then
					continue
				end
				v71:Destroy()
			end
			if #v49.items > 0 then
				for v72, v73 in v49.items do
					v_u_46(p47.weapons, v73, v72, v65, v50, p48)
				end
				p47.note.Visible = false
			else
				p47.note.Visible = true
				p47.note.Text = p48 == 1 and "All starter weapons" or (p48 == v_u_2.Count() and "The top rank" or "A Rank Reward")
			end
			if v66 then
				p47.state.Text = "YOU ARE HERE"
				p47.state.TextColor3 = v50
				return
			elseif v65 then
				p47.state.Text = "REACHED"
				p47.state.TextColor3 = v_u_6.Lighten(v_u_9.Success, 0.1)
			else
				p47.state.Text = string.format("%s TO GO", v_u_5.FormatNumber(v49.trophies - v60))
				p47.state.TextColor3 = v_u_9.TextMuted
			end
		end
		local function v_u_92() -- name: paint
			-- upvalues: (ref) v_u_15, (copy) v_u_7, (ref) v_u_2, (ref) v_u_3, (copy) v_u_13, (copy) v_u_5, (copy) v_u_74
			local v75
			if v_u_15 then
				v75 = v_u_15
			else
				local v76 = 0
				local v77 = (v_u_7.Profile or {}).trophies
				local v78 = tonumber(v77)
				if not v78 then
					local v79 = v_u_7.Get
					v78 = tonumber(v79("Trophies")) or 0
				end
				v75 = math.max(v76, v78)
			end
			local v80, v81, v82 = v_u_2.Progress(v75)
			local v83 = v_u_3.Color(v80)
			v_u_3.SetEmblem(v_u_13.bigEmblem, v80)
			v_u_13.rankName.Text = string.upper(v_u_2.Get(v80).name)
			v_u_13.rankName.TextColor3 = v83
			v_u_13.count.Text = v_u_5.FormatNumber(v75)
			v_u_13.bar.SetColor(v83)
			v_u_13.bar.Set(not v82 and 1 or v81 / v82, true)
			v_u_13.next.Text = not v82 and "You reached the top rank" or string.format("%s more trophies to %s", v_u_5.FormatNumber(v82 - v81), string.upper(v_u_2.Get(v80 + 1).name))
			local v84 = v_u_7.Profile or {}
			local v85 = v_u_13.best
			local v86 = string.format
			local v87 = v_u_5.FormatNumber
			local v88 = v84.trophiesBest
			local v89 = tonumber(v88) or 0
			v85.Text = v86("BEST  %s", v87((math.max(v89, v75))))
			v_u_13.glow.ImageColor3 = v83
			for v90, v91 in v_u_13.rows do
				v_u_74(v91, v90)
			end
		end
		local function v_u_125() -- name: build
			-- upvalues: (ref) v_u_12, (copy) v_u_5, (copy) p_u_4, (copy) v_u_16, (copy) v_u_13, (ref) v_u_3, (copy) v_u_9, (copy) v_u_10, (ref) v_u_2, (copy) v_u_6
			v_u_12 = v_u_5.Window({
				["Name"] = "Ranks",
				["Title"] = "RANK ROAD",
				["Subtitle"] = "Win matches to earn trophies. Every rank adds new weapons to your drops.",
				["Size"] = nil,
				["HeaderHeight"] = 80,
				["Parent"] = nil,
				["OnCloseRequested"] = nil,
				["Size"] = UDim2.fromOffset(1060, 660),
				["Parent"] = p_u_4.Canvas.Menus,
				["OnCloseRequested"] = v_u_16
			})
			v_u_5.SelectionRing(v_u_12.Root)
			local v_u_93 = v_u_12.Content
			local v94 = v_u_5.Panel({
				["Name"] = "You",
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundTransparency"] = 0.25,
				["ClipsDescendants"] = true,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(0, 0),
				["Size"] = UDim2.new(0, 320, 1, 0),
				["Parent"] = v_u_93
			})
			v_u_13.glow = v_u_5.Image(v_u_5.Assets.Icons.Glow, {
				["Name"] = "Glow",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ImageTransparency"] = 0.55,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.new(0.5, 0, 0, 200),
				["Size"] = UDim2.fromOffset(440, 440),
				["Parent"] = v94
			})
			v_u_13.bigEmblem = v_u_3.Emblem(1, 210, {
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["ZIndex"] = 2,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 84),
				["Parent"] = v94
			})
			v_u_13.rankName = v_u_5.DisplayText({
				["Name"] = "RankName",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["TextSize"] = 42,
				["TextColor3"] = nil,
				["StrokeThickness"] = 2,
				["ZIndex"] = 2,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 304),
				["Size"] = UDim2.new(1, -24, 0, 46),
				["TextColor3"] = v_u_9.Text,
				["Parent"] = v94
			})
			local v95 = v_u_5.new("Frame", {
				["Name"] = "Count",
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 356),
				["Size"] = UDim2.new(1, -24, 0, 34),
				["ZIndex"] = 2,
				v_u_5.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
				["Parent"] = v94
			})
			v_u_3.Trophy(30, {
				["LayoutOrder"] = 1,
				["ZIndex"] = 2,
				["Parent"] = nil,
				["Parent"] = v95
			})
			v_u_13.count = v_u_5.new("TextLabel", {
				["Name"] = "N",
				["AutomaticSize"] = nil,
				["Size"] = nil,
				["Text"] = "0",
				["FontFace"] = nil,
				["TextSize"] = 30,
				["TextColor3"] = nil,
				["LayoutOrder"] = 2,
				["ZIndex"] = 2,
				["Parent"] = nil,
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["Size"] = UDim2.fromOffset(0, 34),
				["FontFace"] = v_u_10.Display,
				["TextColor3"] = v_u_9.Text,
				["Parent"] = v95
			})
			v_u_13.bar = v_u_5.Bar({
				["Name"] = "Bar",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Color"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 404),
				["Size"] = UDim2.new(1, -56, 0, 14),
				["Color"] = v_u_9.Gold,
				["Parent"] = v94
			})
			local v96 = v_u_13
			local v97 = {
				["Name"] = "Next",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 15,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 424),
				["Size"] = UDim2.new(1, -40, 0, 20),
				["FontFace"] = v_u_10.Bold,
				["TextColor3"] = v_u_9.TextDim,
				["TextXAlignment"] = Enum.TextXAlignment.Center,
				["Parent"] = v94
			}
			local v98 = table.clone(v97)
			v98.FontFace = v98.FontFace or v_u_10.Heavy
			v98.TextColor3 = v98.TextColor3 or v_u_9.Text
			v98.TextXAlignment = v98.TextXAlignment or Enum.TextXAlignment.Left
			v96.next = v_u_5.new("TextLabel", v98)
			local v99 = v_u_13
			local v100 = {
				["Name"] = "Best",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 13,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 450),
				["Size"] = UDim2.new(1, -40, 0, 18),
				["FontFace"] = v_u_10.Bold,
				["TextColor3"] = v_u_9.TextMuted,
				["TextXAlignment"] = Enum.TextXAlignment.Center,
				["Parent"] = v94
			}
			local v101 = table.clone(v100)
			v101.FontFace = v101.FontFace or v_u_10.Heavy
			v101.TextColor3 = v101.TextColor3 or v_u_9.Text
			v101.TextXAlignment = v101.TextXAlignment or Enum.TextXAlignment.Left
			v99.best = v_u_5.new("TextLabel", v101)
			local v102 = v_u_5.Button({
				["Name"] = "PlayerCard",
				["Text"] = "PLAYER CARD",
				["TextSize"] = 20,
				["Style"] = "Dark",
				["Size"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Parent"] = nil,
				["Size"] = UDim2.new(1, -32, 0, 52),
				["AnchorPoint"] = Vector2.new(0.5, 1),
				["Position"] = UDim2.new(0.5, 0, 1, -16),
				["Parent"] = v94
			})
			v102.Instance.ZIndex = 3
			v102.Activated:Connect(function()
				-- upvalues: (ref) p_u_4
				p_u_4.MenuManager.Open("PlayerCard")
			end)
			v_u_13.scroll = v_u_5.new("ScrollingFrame", {
				["Name"] = "Ladder",
				["Position"] = UDim2.fromOffset(336, 0),
				["Size"] = UDim2.new(1, -336, 1, 0),
				["CanvasSize"] = UDim2.new(),
				["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
				["ScrollBarThickness"] = v_u_5.Touch and 0 or 6,
				["ScrollBarImageColor3"] = v_u_9.TextMuted,
				["ScrollBarImageTransparency"] = 0.4,
				["ScrollingDirection"] = Enum.ScrollingDirection.Y,
				["BorderSizePixel"] = 0,
				["BackgroundTransparency"] = 1,
				v_u_5.List(Enum.FillDirection.Vertical, 10, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Top),
				v_u_5.Padding(2, 12, 2, 2),
				["Parent"] = v_u_93
			})
			local function v107(p103, p104, p105) -- name: fade
				-- upvalues: (ref) v_u_5, (ref) v_u_9, (copy) v_u_93
				local v106 = v_u_5.new("Frame", {
					["Name"] = "Fade",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["ZIndex"] = 5,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0, p104),
					["Position"] = UDim2.new(0, 336, p103, 0),
					["Size"] = UDim2.new(1, -348, 0, 34),
					["BackgroundColor3"] = v_u_9.Panel,
					["Parent"] = v_u_93
				})
				v_u_5.new("UIGradient", {
					["Rotation"] = p105,
					["Transparency"] = NumberSequence.new(0, 1),
					["Parent"] = v106
				})
			end
			v107(0, 0, 90)
			v107(1, 1, 270)
			v_u_13.rows = {}
			local v108 = v_u_2.Count()
			for v109 = 1, v108 do
				local v110 = v_u_2.Get(v109)
				local v111 = v_u_5.new("Frame", {
					["Name"] = "Rank_" .. v110.id,
					["Size"] = UDim2.new(1, 0, 0, 112),
					["BackgroundColor3"] = v_u_9.Panel,
					["BackgroundTransparency"] = 0.25,
					["LayoutOrder"] = v108 - v109,
					v_u_5.Corner(v_u_6.Radius.Large),
					["Parent"] = v_u_13.scroll
				})
				local v112 = v_u_5.Stroke(v_u_9.Stroke, 2, 0.9)
				v112.Parent = v111
				local v113 = v_u_5.new("CanvasGroup", {
					["Name"] = "EmblemHolder",
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundTransparency"] = 1,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(10, 10),
					["Size"] = UDim2.fromOffset(92, 92),
					["Parent"] = v111
				})
				v_u_3.Emblem(v109, 92, {
					["Parent"] = v113
				})
				local v114 = v_u_5.DisplayText({
					["Name"] = "Name",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = nil,
					["TextSize"] = 30,
					["TextXAlignment"] = nil,
					["StrokeThickness"] = 1.5,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(114, 16),
					["Size"] = UDim2.fromOffset(200, 34),
					["Text"] = string.upper(v110.name),
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Parent"] = v111
				})
				local v115 = v_u_5.new("Frame", {
					["Name"] = "Trophies",
					["Position"] = UDim2.fromOffset(114, 54),
					["Size"] = UDim2.fromOffset(200, 24),
					v_u_5.List(Enum.FillDirection.Horizontal, 5, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
					["Parent"] = v111
				})
				v_u_3.Trophy(20, {
					["LayoutOrder"] = 1,
					["Parent"] = nil,
					["Parent"] = v115
				})
				local v116 = {
					["Name"] = "N",
					["AutomaticSize"] = nil,
					["Size"] = nil,
					["Text"] = nil,
					["FontFace"] = nil,
					["TextSize"] = 20,
					["LayoutOrder"] = 2,
					["Parent"] = nil,
					["AutomaticSize"] = Enum.AutomaticSize.X,
					["Size"] = UDim2.fromOffset(0, 24),
					["Text"] = v_u_5.FormatNumber(v110.trophies),
					["FontFace"] = v_u_10.Display,
					["Parent"] = v115
				}
				local v117 = table.clone(v116)
				v117.FontFace = v117.FontFace or v_u_10.Heavy
				v117.TextColor3 = v117.TextColor3 or v_u_9.Text
				v117.TextXAlignment = v117.TextXAlignment or Enum.TextXAlignment.Left
				v_u_5.new("TextLabel", v117)
				local v118 = {
					["Name"] = "State",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["FontFace"] = nil,
					["TextSize"] = 14,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(114, 80),
					["Size"] = UDim2.fromOffset(200, 18),
					["FontFace"] = v_u_10.Heavy,
					["Parent"] = v111
				}
				local v119 = table.clone(v118)
				v119.FontFace = v119.FontFace or v_u_10.Heavy
				v119.TextColor3 = v119.TextColor3 or v_u_9.Text
				v119.TextXAlignment = v119.TextXAlignment or Enum.TextXAlignment.Left
				local v120 = v_u_5.new("TextLabel", v119)
				local v121 = v_u_5.new("Frame", {
					["Name"] = "Weapons",
					["AnchorPoint"] = Vector2.new(1, 0.5),
					["Position"] = UDim2.new(1, -10, 0.5, 0),
					["Size"] = UDim2.new(1, -330, 0, 92),
					v_u_5.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
					["Parent"] = v111
				})
				local v122 = {
					["Name"] = "Note",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["FontFace"] = nil,
					["TextSize"] = 15,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["TextWrapped"] = true,
					["Visible"] = false,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(1, 0.5),
					["Position"] = UDim2.new(1, -18, 0.5, 0),
					["Size"] = UDim2.new(1, -340, 0, 40),
					["FontFace"] = v_u_10.SemiBold,
					["TextColor3"] = v_u_9.TextDim,
					["TextXAlignment"] = Enum.TextXAlignment.Right,
					["Parent"] = v111
				}
				local v123 = table.clone(v122)
				v123.FontFace = v123.FontFace or v_u_10.Heavy
				v123.TextColor3 = v123.TextColor3 or v_u_9.Text
				v123.TextXAlignment = v123.TextXAlignment or Enum.TextXAlignment.Left
				local v124 = {
					["frame"] = v111,
					["stroke"] = v112,
					["emblemHolder"] = v113,
					["name"] = v114,
					["state"] = v120,
					["weapons"] = v121,
					["note"] = v_u_5.new("TextLabel", v123)
				}
				v_u_13.rows[v109] = v124
			end
		end
		local v_u_126 = nil
		local function v_u_127() -- name: hideInfo
			-- upvalues: (ref) v_u_126
			if v_u_126 then
				v_u_126.root.Visible = false
			end
		end
		local function v_u_147() -- name: buildInfo
			-- upvalues: (ref) v_u_126, (copy) v_u_5, (copy) v_u_9, (ref) v_u_12, (copy) v_u_127, (copy) v_u_6, (copy) v_u_10, (ref) v_u_3
			if not v_u_126 then
				v_u_126 = {
					["root"] = v_u_5.new("TextButton", {
						["Name"] = "ItemInfo",
						["Size"] = nil,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.35,
						["Text"] = "",
						["AutoButtonColor"] = false,
						["Selectable"] = false,
						["Visible"] = false,
						["ZIndex"] = 40,
						["Parent"] = nil,
						["Size"] = UDim2.fromScale(1, 1),
						["BackgroundColor3"] = v_u_9.Void,
						["Parent"] = v_u_12.Root
					})
				}
				v_u_126.root.Activated:Connect(v_u_127)
				local v128 = v_u_5.Panel({
					["Name"] = "Card",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundTransparency"] = 0.02,
					["ZIndex"] = 41,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Size"] = UDim2.fromOffset(660, 392),
					["Parent"] = v_u_126.root
				})
				v_u_126.card = v128
				v_u_5.new("TextButton", {
					["Name"] = "Swallow",
					["Size"] = nil,
					["BackgroundTransparency"] = 1,
					["Text"] = "",
					["AutoButtonColor"] = false,
					["Selectable"] = false,
					["ZIndex"] = 41,
					["Parent"] = nil,
					["Size"] = UDim2.fromScale(1, 1),
					["Parent"] = v128
				})
				v_u_126.tile = v_u_5.new("Frame", {
					["Name"] = "Tile",
					["Position"] = UDim2.fromOffset(20, 20),
					["Size"] = UDim2.fromOffset(210, 210),
					["BackgroundColor3"] = v_u_9.PanelHi,
					["ZIndex"] = 42,
					v_u_5.Corner(v_u_6.Radius.Large),
					["Parent"] = v128
				})
				v_u_126.glow = v_u_5.Image(v_u_5.Assets.Icons.Glow, {
					["Name"] = "Glow",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ImageTransparency"] = 0.6,
					["ZIndex"] = 42,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Size"] = UDim2.fromOffset(260, 260),
					["Parent"] = v_u_126.tile
				})
				v_u_126.icon = v_u_5.new("Frame", {
					["Name"] = "Icon",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 43,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Size"] = UDim2.fromOffset(176, 176),
					["Parent"] = v_u_126.tile
				})
				v_u_126.name = v_u_5.DisplayText({
					["Name"] = "Name",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["TextSize"] = 38,
					["TextXAlignment"] = nil,
					["StrokeThickness"] = 2,
					["ZIndex"] = 42,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(252, 20),
					["Size"] = UDim2.fromOffset(340, 42),
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Parent"] = v128
				})
				local v129 = v_u_126
				local v130 = {
					["Name"] = "Sub",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["FontFace"] = nil,
					["TextSize"] = 15,
					["ZIndex"] = 42,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(252, 64),
					["Size"] = UDim2.fromOffset(390, 20),
					["FontFace"] = v_u_10.Heavy,
					["Parent"] = v128
				}
				local v131 = table.clone(v130)
				v131.FontFace = v131.FontFace or v_u_10.Heavy
				v131.TextColor3 = v131.TextColor3 or v_u_9.Text
				v131.TextXAlignment = v131.TextXAlignment or Enum.TextXAlignment.Left
				v129.sub = v_u_5.new("TextLabel", v131)
				local v132 = v_u_126
				local v133 = {
					["Name"] = "Desc",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["FontFace"] = nil,
					["TextSize"] = 16,
					["TextColor3"] = nil,
					["TextWrapped"] = true,
					["TextYAlignment"] = nil,
					["ZIndex"] = 42,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(252, 92),
					["Size"] = UDim2.fromOffset(390, 64),
					["FontFace"] = v_u_10.SemiBold,
					["TextColor3"] = v_u_9.TextDim,
					["TextYAlignment"] = Enum.TextYAlignment.Top,
					["Parent"] = v128
				}
				local v134 = table.clone(v133)
				v134.FontFace = v134.FontFace or v_u_10.Heavy
				v134.TextColor3 = v134.TextColor3 or v_u_9.Text
				v134.TextXAlignment = v134.TextXAlignment or Enum.TextXAlignment.Left
				v132.desc = v_u_5.new("TextLabel", v134)
				v_u_126.stats = {}
				for v135 = 1, 4 do
					local v136 = (v135 - 1) * 18 + 162
					local v137 = {
						["Name"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Text"] = "",
						["FontFace"] = nil,
						["TextSize"] = 12,
						["TextColor3"] = nil,
						["ZIndex"] = 42,
						["Parent"] = nil,
						["Name"] = "StatL" .. v135,
						["Position"] = UDim2.fromOffset(252, v136),
						["Size"] = UDim2.fromOffset(92, 16),
						["FontFace"] = v_u_10.Heavy,
						["TextColor3"] = v_u_9.TextDim,
						["Parent"] = v128
					}
					local v138 = table.clone(v137)
					v138.FontFace = v138.FontFace or v_u_10.Heavy
					v138.TextColor3 = v138.TextColor3 or v_u_9.Text
					v138.TextXAlignment = v138.TextXAlignment or Enum.TextXAlignment.Left
					local v139 = v_u_5.new("TextLabel", v138)
					local v140 = v_u_5.Bar({
						["Name"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Color"] = nil,
						["Stroke"] = false,
						["Parent"] = nil,
						["Name"] = "StatB" .. v135,
						["Position"] = UDim2.fromOffset(348, v136 + 4),
						["Size"] = UDim2.fromOffset(200, 8),
						["Color"] = v_u_9.Accent,
						["Parent"] = v128
					})
					v140.Frame.ZIndex = 42
					v140.Fill.ZIndex = 43
					local v141 = {
						["Name"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Text"] = "",
						["FontFace"] = nil,
						["TextSize"] = 12,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["ZIndex"] = 42,
						["Parent"] = nil,
						["Name"] = "StatV" .. v135,
						["Position"] = UDim2.fromOffset(556, v136),
						["Size"] = UDim2.fromOffset(84, 16),
						["FontFace"] = v_u_10.Bold,
						["TextColor3"] = v_u_9.Text,
						["TextXAlignment"] = Enum.TextXAlignment.Right,
						["Parent"] = v128
					}
					local v142 = table.clone(v141)
					v142.FontFace = v142.FontFace or v_u_10.Heavy
					v142.TextColor3 = v142.TextColor3 or v_u_9.Text
					v142.TextXAlignment = v142.TextXAlignment or Enum.TextXAlignment.Left
					local v143 = {
						["label"] = v139,
						["bar"] = v140,
						["value"] = v_u_5.new("TextLabel", v142)
					}
					v_u_126.stats[v135] = v143
				end
				v_u_126.state = v_u_5.new("Frame", {
					["Name"] = "State",
					["Position"] = UDim2.fromOffset(20, 248),
					["Size"] = UDim2.fromOffset(620, 50),
					["BackgroundColor3"] = v_u_9.PanelLo,
					["BackgroundTransparency"] = 0.2,
					["ZIndex"] = 42,
					v_u_5.Corner(v_u_6.Radius.Medium),
					["Parent"] = v128
				})
				v_u_126.stateEmblem = v_u_3.Emblem(1, 38, {
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["ZIndex"] = 43,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0, 0.5),
					["Position"] = UDim2.new(0, 8, 0.5, 0),
					["Parent"] = v_u_126.state
				})
				local v144 = v_u_126
				local v145 = {
					["Name"] = "Text",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["FontFace"] = nil,
					["TextSize"] = 16,
					["ZIndex"] = 43,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(56, 0),
					["Size"] = UDim2.new(1, -66, 1, 0),
					["FontFace"] = v_u_10.Heavy,
					["Parent"] = v_u_126.state
				}
				local v146 = table.clone(v145)
				v146.FontFace = v146.FontFace or v_u_10.Heavy
				v146.TextColor3 = v146.TextColor3 or v_u_9.Text
				v146.TextXAlignment = v146.TextXAlignment or Enum.TextXAlignment.Left
				v144.stateText = v_u_5.new("TextLabel", v146)
				v_u_126.close = v_u_5.Button({
					["Name"] = "Close",
					["Text"] = "CLOSE",
					["TextSize"] = 20,
					["Style"] = "Dark",
					["Size"] = nil,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Radius"] = 14,
					["ZIndex"] = 42,
					["Parent"] = nil,
					["Size"] = UDim2.fromOffset(200, 58),
					["AnchorPoint"] = Vector2.new(1, 1),
					["Position"] = UDim2.new(1, -20, 1, -18),
					["Parent"] = v128
				})
				v_u_126.close.Activated:Connect(v_u_127)
			end
		end
		local function v_u_157(p148, p149, p150) -- name: statValue
			local v151 = p148.details
			if type(v151) == "table" then
				for _, v152 in p148.details do
					if type(v152) ~= "table" then
						continue
					end
					local v153 = v152[1]
					if type(v153) ~= "string" or string.upper(v152[1]) ~= p149 then
						continue
					end
					local v154 = v152[2]
					return tostring(v154)
				end
			end
			local v155 = string.format
			local v156 = p150 * 10 + 0.5
			return v155("%d / 10", (math.floor(v156)))
		end
		v_u_17 = function(p158, p159)
			-- upvalues: (copy) p_u_4, (ref) v_u_12, (copy) v_u_147, (ref) v_u_126, (ref) v_u_3, (copy) v_u_9, (copy) v_u_157, (ref) v_u_2, (copy) v_u_6, (copy) v_u_7, (ref) v_u_15, (copy) v_u_5
			local v160 = p_u_4.WeaponInfo.Get(p158)
			if v160 and v_u_12 then
				v_u_147()
				v_u_126.id = p158
				local v161 = v_u_3.Color(p159)
				local v162
				if p_u_4.WeaponInfo.CATEGORY_COLORS then
					v162 = p_u_4.WeaponInfo.CATEGORY_COLORS[v160.category] or v161
				else
					v162 = v161
				end
				p_u_4.WeaponIcon.Set(v_u_126.icon, p158, {
					["spin"] = true,
					["outline"] = true
				})
				p_u_4.WeaponIcon.SetDim(v_u_126.icon, false)
				v_u_126.glow.ImageColor3 = v162
				v_u_126.name.Text = string.upper(v160.name)
				v_u_126.sub.Text = string.format("%s  \194\183  %d POINT%s", string.upper(p_u_4.WeaponInfo.CATEGORY_SINGULAR[v160.category] or (v160.category or "")), v160.points or 0, (v160.points or 0) == 1 and "" or "S")
				v_u_126.sub.TextColor3 = v162:Lerp(v_u_9.TextDim, 0.3)
				v_u_126.desc.Text = v160.description or ""
				local v163 = p_u_4.WeaponInfo.Bars(v160)
				for v164, v165 in v_u_126.stats do
					local v166 = v163[v164]
					v165.label.Visible = v166 ~= nil
					v165.bar.Frame.Visible = v166 ~= nil
					v165.value.Visible = v166 ~= nil
					if not v166 then
						continue
					end
					v165.label.Text = v166.label
					v165.bar.Set(v166.frac, true)
					v165.bar.SetColor(v162)
					v165.value.Text = v_u_157(v160, v166.label, v166.frac)
				end
				v_u_3.SetEmblem(v_u_126.stateEmblem, p159)
				local v167 = string.upper(v_u_2.Get(p159).name)
				local v168 = p_u_4.Economy
				if v168 and v168.Owns(p158) then
					local v169 = v168.Level(p158)
					v_u_126.stateText.Text = string.format("OWNED  \194\183  LV %d", (math.max(v169, 1)))
					v_u_126.stateText.TextColor3 = v_u_6.Lighten(v_u_9.Success, 0.1)
				else
					local v170 = (v_u_7.Profile or {}).rankBest
					local v171 = tonumber(v170) or 1
					local v172 = v_u_2.RankOf
					local v173
					if v_u_15 then
						v173 = v_u_15
					else
						local v174 = 0
						local v175 = (v_u_7.Profile or {}).trophies
						local v176 = tonumber(v175)
						if not v176 then
							local v177 = v_u_7.Get
							v176 = tonumber(v177("Trophies")) or 0
						end
						v173 = math.max(v174, v176)
					end
					if p159 <= math.max(v171, v172(v173)) then
						local v178, v179
						if v168 then
							v178, v179 = v168.Progress(p158)
						else
							v178 = 0
							v179 = 0
						end
						v_u_126.stateText.Text = string.format("UNLOCKED AT %s  \194\183  %d / %d SHARDS  \194\183  FIND SHARDS IN DROPS", v167, v178, v179)
						v_u_126.stateText.TextColor3 = v_u_9.Text
					else
						local v180
						if v_u_15 then
							v180 = v_u_15
						else
							local v181 = 0
							local v182 = (v_u_7.Profile or {}).trophies
							local v183 = tonumber(v182)
							if not v183 then
								local v184 = v_u_7.Get
								v183 = tonumber(v184("Trophies")) or 0
							end
							v180 = math.max(v181, v183)
						end
						local v185 = v_u_126.stateText
						local v186 = string.format
						local v187 = v_u_5.FormatNumber
						local v188 = v_u_2.Get(p159).trophies - v180
						v185.Text = v186("REACH %s (%s TROPHIES) TO ADD IT TO YOUR DROPS", v167, v187((math.max(0, v188))) .. " MORE")
						v_u_126.stateText.TextColor3 = v161
					end
				end
				v_u_126.root.Visible = true
				v_u_5.Pop(v_u_126.card, 0.9, v_u_6.Tween.PopSmall)
			end
		end
		local v205 = {
			["open"] = function() -- name: open
				-- upvalues: (ref) v_u_12, (copy) v_u_125, (copy) p_u_4, (copy) v_u_92, (ref) v_u_14, (ref) v_u_2, (ref) v_u_15, (copy) v_u_7, (copy) v_u_13, (copy) v_u_5
				if not v_u_12 then
					v_u_125()
				end
				p_u_4.SetHudHidden("Ranks", true)
				v_u_92()
				v_u_12:Open()
				local v_u_189 = v_u_14
				if not v_u_189 then
					local v190 = v_u_2.RankOf
					local v191
					if v_u_15 then
						v191 = v_u_15
					else
						local v192 = 0
						local v193 = (v_u_7.Profile or {}).trophies
						local v194 = tonumber(v193)
						if not v194 then
							local v195 = v_u_7.Get
							v194 = tonumber(v195("Trophies")) or 0
						end
						v191 = math.max(v192, v194)
					end
					v_u_189 = v190(v191)
				end
				v_u_14 = nil
				task.defer(function()
					-- upvalues: (copy) v_u_189, (ref) v_u_2, (ref) v_u_13, (ref) v_u_5
					local v196 = v_u_189
					local v197 = (v_u_2.Count() - v196) * 122
					local v198 = v_u_13.scroll.AbsoluteWindowSize.Y
					local v199 = v_u_5.Scale
					local v200 = v198 / math.max(0.01, v199)
					local v201 = v_u_13.scroll
					local v202 = Vector2.new
					local v203 = v197 - v200 / 2 + 56
					v201.CanvasPosition = v202(0, (math.max(0, v203)))
				end)
				v_u_5.Pop(v_u_13.bigEmblem, 0.7)
			end,
			["close"] = function(p204) -- name: close
				-- upvalues: (ref) v_u_126, (copy) p_u_4, (ref) v_u_15, (ref) v_u_12
				if v_u_126 then
					v_u_126.root.Visible = false
				end
				p_u_4.SetHudHidden("Ranks", false)
				v_u_15 = nil
				v_u_12:Close(p204)
			end
		}
		v_u_8.Register("Ranks", v205)
		local function v206() -- name: refresh
			-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_92
			if v_u_12 and v_u_8.IsOpen("Ranks") then
				v_u_92()
			end
		end
		v_u_7.ProfileChanged:Connect(v206)
		v_u_7.AttrChanged:Connect(function(p207)
			-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) v_u_92
			if (p207 == "Trophies" or p207 == "RankBest") and (v_u_12 and v_u_8.IsOpen("Ranks")) then
				v_u_92()
			end
		end)
		p_u_4.RankRoad = {
			["Focus"] = function(p208) -- name: Focus
				-- upvalues: (ref) v_u_14
				v_u_14 = p208
			end,
			["OpenAt"] = function(p209) -- name: OpenAt
				-- upvalues: (ref) v_u_14, (copy) v_u_8
				v_u_14 = p209
				v_u_8.Open("Ranks")
			end
		}
		function p_u_4.Debug.rankInfo(p210)
			-- upvalues: (ref) v_u_12, (copy) v_u_8, (copy) p_u_4, (ref) v_u_17
			if not (v_u_12 and v_u_8.IsOpen("Ranks")) then
				v_u_8.Open("Ranks")
			end
			local v211 = p_u_4.Economy
			v_u_17(tostring(p210), not v211 and 1 or v211.ItemRank((tostring(p210))))
			return true
		end
		function p_u_4.Debug.ranks(p212)
			-- upvalues: (ref) v_u_15, (copy) v_u_8
			v_u_15 = tonumber(p212)
			v_u_8.Open("Ranks")
			return true
		end
	end
}