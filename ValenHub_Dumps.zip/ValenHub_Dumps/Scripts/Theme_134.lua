local v1 = game:GetService("ReplicatedStorage")
local v2 = {}
local v3 = Color3.fromRGB
local v4 = v3(70, 170, 255)
local v5 = v3(255, 72, 72)
local v6 = v1:FindFirstChild("Shared")
if v6 then
	v6 = v6:FindFirstChild("Config")
end
if v6 and v6:IsA("ModuleScript") then
	local v7 = require
	local v8, v9 = pcall(v7, v6)
	if v8 and type(v9) == "table" then
		local v10 = v9.ALLY_COLOR
		if typeof(v10) == "Color3" then
			v4 = v9.ALLY_COLOR
		end
		local v11 = v9.ENEMY_COLOR
		if typeof(v11) == "Color3" then
			v5 = v9.ENEMY_COLOR
		end
	end
end
v2.Colors = {
	["Void"] = v3(6, 7, 10),
	["Bg"] = v3(12, 13, 17),
	["Panel"] = v3(18, 20, 26),
	["PanelHi"] = v3(28, 31, 39),
	["PanelLo"] = v3(14, 15, 20),
	["Raised"] = v3(36, 40, 50),
	["Inset"] = v3(10, 11, 15),
	["Stroke"] = v3(255, 255, 255),
	["StrokeSoft"] = v3(64, 70, 84),
	["Divider"] = v3(52, 57, 70),
	["Text"] = v3(255, 255, 255),
	["TextDim"] = v3(186, 192, 206),
	["TextMuted"] = v3(124, 131, 148),
	["TextDark"] = v3(10, 12, 18),
	["Accent"] = v3(40, 150, 255),
	["AccentDark"] = v3(18, 96, 214),
	["AccentDeep"] = v3(10, 50, 120),
	["Success"] = v3(64, 214, 110),
	["SuccessDark"] = v3(28, 150, 70),
	["Danger"] = v3(245, 64, 72),
	["DangerDark"] = v3(170, 26, 38),
	["Warning"] = v3(255, 176, 40),
	["Bone"] = v3(228, 232, 240),
	["Ally"] = v4,
	["AllyDark"] = v4:Lerp(v3(0, 0, 0), 0.5),
	["Enemy"] = v5,
	["EnemyDark"] = v5:Lerp(v3(0, 0, 0), 0.5),
	["Health"] = v3(96, 222, 110),
	["HealthLow"] = v3(245, 64, 72),
	["HealthTrail"] = v3(255, 214, 140),
	["Armor"] = v3(150, 200, 255),
	["Shell"] = v3(255, 176, 120),
	["Xp"] = v3(40, 150, 255),
	["Gold"] = v3(255, 200, 60),
	["White"] = v3(255, 255, 255),
	["Black"] = v3(0, 0, 0)
}
v2.Fonts = {
	["Display"] = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Heavy),
	["Title"] = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.ExtraBold),
	["Heavy"] = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.ExtraBold),
	["Bold"] = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Bold),
	["SemiBold"] = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.SemiBold),
	["Medium"] = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Medium)
}
v2.Radius = {
	["Small"] = UDim.new(0, 6),
	["Medium"] = UDim.new(0, 10),
	["Large"] = UDim.new(0, 12),
	["Pill"] = UDim.new(1, 0)
}
v2.Tween = {
	["Instant"] = TweenInfo.new(0.06, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
	["Fast"] = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
	["Smooth"] = TweenInfo.new(0.22, Enum.EasingStyle.Quint, Enum.EasingDirection.Out),
	["Slow"] = TweenInfo.new(0.5, Enum.EasingStyle.Quint, Enum.EasingDirection.Out),
	["Pop"] = TweenInfo.new(0.34, Enum.EasingStyle.Back, Enum.EasingDirection.Out),
	["PopSmall"] = TweenInfo.new(0.18, Enum.EasingStyle.Back, Enum.EasingDirection.Out),
	["Close"] = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.In),
	["Slam"] = TweenInfo.new(0.28, Enum.EasingStyle.Back, Enum.EasingDirection.Out, 0, false, 0)
}
v2.DesignSize = Vector2.new(1600, 900)
v2.ShowCurrency = false
function v2.Lighten(p12, p13) -- name: Lighten
	return p12:Lerp(Color3.new(1, 1, 1), p13)
end
function v2.Darken(p14, p15) -- name: Darken
	return p14:Lerp(Color3.new(0, 0, 0), p15)
end
return v2