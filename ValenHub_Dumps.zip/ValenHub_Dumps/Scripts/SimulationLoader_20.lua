local v1 = game:GetService("ReplicatedStorage")
require(v1:WaitForChild("Shared"):WaitForChild("Simulation")).Initialize()