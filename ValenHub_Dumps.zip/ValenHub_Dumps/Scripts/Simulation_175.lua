local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Workspace")
local v4 = script.Parent
local v_u_5 = require(script:WaitForChild("Inputs"))
local v_u_6 = require(script:WaitForChild("WriteGuard"))
local v_u_7 = require(v4:WaitForChild("Combat"))
local v_u_8 = {
	["Inputs"] = v_u_5,
	["BASE_SPEED"] = 21,
	["JUMP_HEIGHT"] = 7.4
}
local v_u_9 = v_u_8.BASE_SPEED
local v_u_10 = v_u_8.JUMP_HEIGHT
local v_u_11 = 39
local v_u_12 = 48
local v_u_13 = 15
local v_u_14 = 13
local v_u_15 = 11
local v_u_16 = 45
local v_u_17 = {
	"HumanoidRootPart",
	"Head",
	"UpperTorso",
	"LowerTorso"
}
local v_u_18 = 8
local v_u_19 = 9
local v_u_20 = 7
local v_u_21 = 18
v_u_8.SLIDE_TIME = 0.65
v_u_8.SLIDE_START = 36
local v_u_22 = {
	"SSpeed",
	"SSlide",
	"SSlideDir",
	"SSlideCD",
	"SSlideBuf",
	"SSlideIn",
	"SSlope",
	"SLift",
	"SJumpIn",
	"SJumpBuf",
	"SAir",
	"SJumped",
	"SJumping",
	"SGround",
	"SBoost",
	"SKb",
	"SKbF",
	"SKbN",
	"SDashV",
	"SDashF",
	"SDashCD",
	"SDashB",
	"SCharge",
	"SChargeRel",
	"SLungeIn",
	"SHipBase",
	"SHip",
	"SFrozen",
	"SSlow",
	"SNoJump",
	"STp",
	"SWade",
	"SWet"
}
local v_u_23 = v_u_2:IsServer()
local v_u_28 = (function() -- name: detectClientAuthority
	-- upvalues: (copy) v_u_23, (copy) v_u_3
	if not v_u_23 then
		local v24 = v_u_3:GetAttribute("TribesAuthority")
		local v25 = os.clock()
		while v24 == nil and os.clock() - v25 < 15 do
			task.wait()
			v24 = v_u_3:GetAttribute("TribesAuthority")
		end
		return v24 == "Client"
	end
	local v_u_26 = Instance.new("Part")
	v_u_26.Name = "TribesAuthorityProbe"
	v_u_26.Size = Vector3.new(1, 1, 1)
	v_u_26.Transparency = 1
	v_u_26.CanCollide = false
	v_u_26.CanQuery = false
	v_u_26.CanTouch = false
	v_u_26.CFrame = CFrame.new(0, 4000, 0)
	v_u_26.Parent = v_u_3
	local v27 = pcall(function()
		-- upvalues: (copy) v_u_26
		v_u_26:SetNetworkOwner(nil)
	end)
	v_u_26:Destroy()
	v_u_3:SetAttribute("TribesAuthority", v27 and "Client" or "Server")
	return v27
end)()
local v_u_29
if v_u_23 then
	v_u_29 = not v_u_28
else
	v_u_29 = v_u_23
end
local v_u_30 = v_u_23 and v_u_28
v_u_8.ClientAuthority = v_u_28
v_u_8.Authority = v_u_28 and "Client" or "Server"
local v_u_31 = v_u_2:IsStudio()
if v_u_31 then
	v_u_31 = v_u_3:GetAttribute("WaterSimOff") == true
end
local v_u_32 = v_u_2:IsStudio()
if v_u_32 then
	v_u_32 = v_u_3:GetAttribute("SimAuditOff") == true
end
local v_u_33 = {}
local v_u_34 = {}
local v_u_35 = {
	["SFrozen"] = true,
	["SSlow"] = true,
	["SNoJump"] = true,
	["STp"] = true
}
local function v_u_43(p36) -- name: load
	-- upvalues: (copy) v_u_28, (copy) v_u_35, (copy) v_u_22
	local v37 = p36.s
	local v38 = p36.prev
	local v39 = p36.root
	if v_u_28 then
		for v40 in v_u_35 do
			v37[v40] = v39:GetAttribute(v40)
		end
	else
		for _, v41 in v_u_22 do
			local v42 = v39:GetAttribute(v41)
			v37[v41] = v42
			v38[v41] = v42
		end
	end
end
local function v_u_52(p44) -- name: save
	-- upvalues: (copy) v_u_28, (copy) v_u_22, (copy) v_u_35
	local v45 = p44.s
	local v46 = p44.prev
	local v47 = p44.root
	if v_u_28 then
		for _, v48 in v_u_22 do
			if v_u_35[v48] then
				continue
			end
			local v49 = v45[v48]
			if v47:GetAttribute(v48) == v49 then
				continue
			end
			v47:SetAttribute(v48, v49)
		end
	else
		for _, v50 in v_u_22 do
			local v51 = v45[v50]
			if v51 == v46[v50] then
				continue
			end
			v47:SetAttribute(v50, v51)
		end
	end
end
local v_u_53 = {}
local v_u_54 = {
	["Look"] = true,
	["Facing"] = true
}
local function v_u_69(p55) -- name: lookMove
	-- upvalues: (copy) v_u_28, (copy) v_u_23, (copy) v_u_54, (copy) v_u_53
	if not p55.move then
		return nil
	end
	local v56
	if v_u_28 and (not v_u_23 and v_u_54.Look) then
		v56 = v_u_53.Look
	else
		local v57 = p55.actions.Look
		if v57 then
			v56 = v57:GetState()
		else
			v56 = nil
		end
	end
	local v58
	if typeof(v56) == "Vector2" and (v56.X == v56.X and v56.Y == v56.Y) then
		local v59 = v56.X
		if math.abs(v59) < 1000000 then
			local v60 = v56.Y
			v58 = math.abs(v60) < 1000000
		else
			v58 = false
		end
	else
		v58 = false
	end
	if not v58 or (v56.Magnitude < 0.5 or v56.Magnitude > 1.5) then
		return nil
	end
	local v61
	if p55.move then
		v61 = p55.move:GetState()
	else
		v61 = nil
	end
	local v62
	if typeof(v61) == "Vector2" and (v61.X == v61.X and v61.Y == v61.Y) then
		local v63 = v61.X
		if math.abs(v63) < 1000000 then
			local v64 = v61.Y
			v62 = math.abs(v64) < 1000000
		else
			v62 = false
		end
	else
		v62 = false
	end
	if not v62 then
		return Vector3.new(0, 0, 0)
	end
	local v65 = v56.Unit
	local v66 = v65.X * v61.Y - v65.Y * v61.X
	local v67 = v65.Y * v61.Y + v65.X * v61.X
	local v68 = Vector3.new(v66, 0, v67)
	if v68.Magnitude > 1 then
		v68 = v68.Unit
	end
	return v68
end
local function v_u_76(p70, p71) -- name: toolInSlot
	local v72 = p70.holdTool
	local v73 = p70.player:FindFirstChild("Backpack")
	if p70.holdSlot == p71 and (v72 and (v72:IsDescendantOf(p70.character) or v73 ~= nil and v72:IsDescendantOf(v73))) and v72:GetAttribute("SlotIndex") == p71 then
		return v72
	end
	p70.holdSlot = p71
	p70.holdTool = nil
	if p71 <= 0 then
		return nil
	end
	for _, v74 in { p70.character, v73 } do
		if not v74 then
			continue
		end
		for _, v75 in v74:GetChildren() do
			if v75:GetAttribute("SlotIndex") ~= p71 or v75:GetAttribute("WeaponId") == nil then
				continue
			end
			p70.holdTool = v75
			return v75
		end
	end
	return nil
end
local v_u_77 = 45
local function v_u_87(p78) -- name: heldWeapon
	-- upvalues: (copy) v_u_28, (copy) v_u_23, (copy) v_u_54, (copy) v_u_53, (copy) v_u_5, (copy) v_u_76, (copy) v_u_29, (copy) v_u_77
	local v79 = p78.character:FindFirstChildWhichIsA("Tool")
	local v80
	if p78.actions.Hold then
		if v_u_28 and (not v_u_23 and v_u_54.Hold) then
			v80 = v_u_53.Hold
		else
			local v81 = p78.actions.Hold
			if v81 then
				v80 = v81:GetState()
			else
				v80 = nil
			end
		end
	else
		v80 = nil
	end
	local v82
	if type(v80) == "number" and v80 == v80 then
		local v83 = v80 * v_u_5.HOLD_SCALE + 0.5
		local v84 = math.floor(v83)
		local v85 = v_u_5.HOLD_SLOTS
		v82 = v_u_76(p78, (math.clamp(v84, 0, v85)))
		if v_u_29 then
			if v82 == v79 then
				p78.holdBad = 0
			else
				p78.holdBad = p78.holdBad + 1
				if v_u_77 < p78.holdBad then
					v82 = v79
				end
			end
		end
	else
		v82 = v79
	end
	local v86
	if v82 then
		v86 = v82:GetAttribute("WeaponId")
	else
		v86 = nil
	end
	if type(v86) == "string" then
		return v86
	else
		return nil
	end
end
local v_u_88 = RaycastParams.new()
v_u_88.FilterType = Enum.RaycastFilterType.Include
v_u_88.FilterDescendantsInstances = { v_u_3.Terrain }
v_u_88.IgnoreWater = false
local function v_u_113(p89, p90) -- name: probeWater
	-- upvalues: (copy) v_u_31, (copy) v_u_3, (copy) v_u_88
	if v_u_31 then
		return 0, nil, nil, nil
	end
	local v91 = p89.root
	local v92 = v91.Position
	local v93 = v91.Size.Y * 0.5
	local v94 = v_u_3
	local v95 = v92.X
	local v96 = v92.Y + 16
	local v97 = v92.Z
	local v98 = Vector3.new(v95, v96, v97)
	local v99 = -(p90 + 16 + v93 + 0.5)
	local v100 = v94:Raycast(v98, Vector3.new(0, v99, 0), v_u_88)
	if not v100 or v100.Material ~= Enum.Material.Water then
		return 0, nil, nil, nil
	end
	local v101 = v100.Position.Y
	local v102 = v_u_3:Raycast(v92, Vector3.new(0, -40, 0), p89.ray)
	if not v102 then
		return 1, nil, nil, nil
	end
	local v103 = v102.Position.Y
	local v104 = v101 - v103
	local v105 = p90 + v93 + 0.6
	local v106 = (v104 - 0.4) / (v105 - 0.4)
	local v107 = math.clamp(v106, 0, 1)
	local v108 = v101 - 0.6 - v103 - v93
	local v109 = v107 / 0.01 + 0.5
	local v110 = math.floor(v109) * 0.01
	local v111
	if p90 < v108 then
		local v112 = v108 / 0.001 + 0.5
		v111 = math.floor(v112) * 0.001
	else
		v111 = nil
	end
	return v110, v111, v103, v101 - 0.6
end
local function v_u_132(p114, p115, p116, p117) -- name: probeBank
	-- upvalues: (copy) v_u_3
	local v118 = p114.root.Position + p115 * 2
	local v119 = p117 + p116 * 2 + 2.5
	local v120 = v_u_3
	local v121 = v118.X
	local v122 = v118.Z
	local v123 = Vector3.new(v121, v119, v122)
	local v124 = -(v119 - p117 + 1)
	local v125 = v120:Raycast(v123, Vector3.new(0, v124, 0), p114.ray)
	if not v125 then
		return nil
	end
	local v126 = v125.Position.Y - p117
	local v127 = p116 + 0.5
	local v128 = math.min(v126, v127)
	local v129 = v127 + 1 - v126
	local v130 = v128 * math.clamp(v129, 0, 1)
	if v130 <= 0.01 then
		return nil
	end
	local v131 = (p116 + v130) / 0.001 + 0.5
	return math.floor(v131) * 0.001
end
local function v_u_149(p133, p134, p135, p136, p137) -- name: tryStartSlide
	if p133.SSlide ~= nil or (p133.SSlideCD ~= nil or not p137) then
		return false
	end
	local v138 = p136.X
	local v139 = p136.Z
	if Vector3.new(v138, 0, v139).Magnitude < 11 or p135.Magnitude < 0.2 then
		return false
	end
	local v140 = p135.X
	local v141 = p135.Z
	local v142 = Vector3.new(v140, 0, v141).Unit
	p133.SSlide = 0
	local v143 = v142.X / 0.0001 + 0.5
	local v144 = math.floor(v143) * 0.0001
	local v145 = v142.Z / 0.0001 + 0.5
	local v146 = math.floor(v145) * 0.0001
	p133.SSlideDir = Vector3.new(v144, 0, v146)
	p133.SSlideBuf = nil
	p133.SSpeed = 36
	local v147 = p133.SHipBase
	if type(v147) ~= "number" then
		local v148 = p134.HipHeight / 0.001 + 0.5
		p133.SHipBase = math.floor(v148) * 0.001
	end
	return true
end
local function v_u_181(p150, p151, p152, p153, p154, p155) -- name: probeGround
	-- upvalues: (copy) v_u_3
	local v156 = p150.root
	local v157 = v156.Position
	local v158 = v_u_3
	local v159 = -(p154 + v156.Size.Y * 0.5 + 1.5)
	local v160 = v158:Raycast(v157, Vector3.new(0, v159, 0), p150.ray)
	if v160 then
		local v161 = v160.Normal
		local v162
		if v161.Y >= 0.5 then
			local v163 = p152 * ((v161.X * p151.X + v161.Z * p151.Z) / v161.Y)
			v162 = math.clamp(v163, -12, 12) * 0.6
		else
			v162 = nil
		end
		local v164 = v160.Position.Y
		local v165
		if p150.hull then
			v165 = p150.hull.Size.Y * 0.5
		else
			v165 = v156.Size.Z * 0.5
		end
		local v166 = p153 * 0.16 + v165 + 0.1
		local v167 = v_u_3
		local v168 = v157.X
		local v169 = v164 + 0.25
		local v170 = v157.Z
		local v171 = v167:Raycast(Vector3.new(v168, v169, v170), p151 * v166, p150.ray)
		if v171 and v171.Normal.Y <= 0.3 then
			local v172 = v171.Position + p151 * 0.3
			local v173 = v_u_3
			local v174 = v172.X
			local v175 = v164 + p155 + 0.3
			local v176 = v172.Z
			local v177 = Vector3.new(v174, v175, v176)
			local v178 = -(p155 + 0.3 - 0.25)
			local v179 = v173:Raycast(v177, Vector3.new(0, v178, 0), p150.ray)
			if v179 and v179.Normal.Y >= 0.7 then
				local v180 = v179.Position.Y - v164
				if v180 < 0.25 or p155 < v180 then
					return v162, nil
				else
					return v162, v180 + 0.35
				end
			else
				return v162, nil
			end
		else
			return v162, nil
		end
	else
		return nil, nil
	end
end
local function v_u_195(p182, p183, p184, p185) -- name: slideCushion
	-- upvalues: (copy) v_u_3
	if p183 >= -12 then
		return nil
	else
		local v186 = p182.root
		local v187 = v186.Position
		local v188 = p184 + v186.Size.Y * 0.5
		local v189 = v_u_3
		local v190 = -(v188 + (p185 or 2.5))
		local v191 = v189:Raycast(v187, Vector3.new(0, v190, 0), p182.ray)
		if v191 and v191.Normal.Y >= 0.5 then
			local v192 = v187.Y - v191.Position.Y - v188 - 0.5
			local v193 = math.max(v192, 0.05)
			local v194 = (p183 * p183 - 144) / (v193 * 2)
			if v194 < 350 then
				return nil
			else
				return math.min(v194, 900)
			end
		else
			return nil
		end
	end
end
local function v_u_210(p196) -- name: finCF
	local v197 = p196.Position
	local v198
	if v197.X == v197.X and (v197.Y == v197.Y and v197.Z == v197.Z) then
		local v199 = v197.X
		if math.abs(v199) < 200000 then
			local v200 = v197.Y
			if math.abs(v200) < 200000 then
				local v201 = v197.Z
				if math.abs(v201) < 200000 then
					local v202 = p196.LookVector
					local v203 = v202.X
					if v203 == v203 and v203 > -10000000 then
						v198 = v203 < 10000000
					else
						v198 = false
					end
					if v198 then
						local v204 = v202.Y
						if v204 == v204 and v204 > -10000000 then
							v198 = v204 < 10000000
						else
							v198 = false
						end
						if v198 then
							local v205 = v202.Z
							if v205 == v205 and v205 > -10000000 then
								v198 = v205 < 10000000
							else
								v198 = false
							end
						end
					end
					if v198 then
						local v206 = p196.UpVector
						local v207 = v206.X
						if v207 == v207 and v207 > -10000000 then
							v198 = v207 < 10000000
						else
							v198 = false
						end
						if v198 then
							local v208 = v206.Y
							if v208 == v208 and v208 > -10000000 then
								v198 = v208 < 10000000
							else
								v198 = false
							end
							if v198 then
								local v209 = v206.Z
								if v209 == v209 and v209 > -10000000 then
									v198 = v209 < 10000000
								else
									v198 = false
								end
							end
						end
					end
				else
					v198 = false
				end
			else
				v198 = false
			end
		else
			v198 = false
		end
	else
		v198 = false
	end
	return v198
end
local v_u_211 = {}
local function v_u_221(p212, p213) -- name: stepCollisions
	-- upvalues: (copy) v_u_32
	local v214 = p212.hull
	if v214 and not v_u_32 then
		if p213 then
			local v215 = p212.body
			for v216 = 1, #v215 do
				local v217 = v215[v216]
				if not v217.CanCollide then
					continue
				end
				v217.CanCollide = false
			end
			if not v214.CanCollide then
				v214.CanCollide = true
				return
			end
		else
			local v218 = p212.corpse
			for v219 = 1, #v218 do
				local v220 = v218[v219]
				if v220.CanCollide then
					continue
				end
				v220.CanCollide = true
			end
			if v214.CanCollide then
				v214.CanCollide = false
			end
		end
	end
end
local function v_u_247(p222, p223, p224) -- name: startKnockback
	-- upvalues: (copy) v_u_211, (copy) v_u_28, (copy) v_u_23, (copy) v_u_12
	local v225 = p222.humanoid
	local v226 = p222.root
	local v227 = p222.s
	local v228 = p223.X
	local v229
	if v228 == v228 and v228 > -10000000 then
		v229 = v228 < 10000000
	else
		v229 = false
	end
	if v229 then
		local v230 = p223.Y
		if v230 == v230 and v230 > -10000000 then
			v229 = v230 < 10000000
		else
			v229 = false
		end
		if v229 then
			local v231 = p223.Z
			if v231 == v231 and v231 > -10000000 then
				v229 = v231 < 10000000
			else
				v229 = false
			end
		end
	end
	if v229 then
		if p224 ~= nil then
			local v232
			if p224 == p224 and p224 > -10000000 then
				v232 = p224 < 10000000
			else
				v232 = false
			end
			if not v232 then
				p224 = nil
			end
		end
		local v233 = p223.X
		local v234 = p223.Z
		local v235 = Vector3.new(v233, 0, v234)
		if v235.Magnitude > 90 then
			v235 = v235.Unit * 90
		end
		if v235.Magnitude >= 1 then
			if v227.SSlide ~= nil then
				v227.SSlide = nil
				v227.SSlideDir = nil
				v227.SSlope = nil
				v227.SLift = nil
				v227.SSlideCD = v_u_12
				local v236 = v227.SSpeed
				v227.SSpeed = math.max(v236, 17)
			end
			local v237 = math.clamp(p224 or 0.35, 0.05, 1) * 60 + 0.5
			local v238 = math.floor(v237)
			local v239 = math.max(1, v238)
			v227.SKb = v235
			v227.SKbF = v239
			v227.SKbN = v239
			v227.SDashV = nil
			v227.SDashF = nil
		end
		if p223.Y > 8 then
			local v240 = v226.AssemblyLinearVelocity
			local v241 = v240.X
			local v242 = v240.Y
			local v243 = p223.Y
			local v244 = math.min(v243, 40) * 0.8
			local v245 = math.max(v242, v244)
			local v246 = v240.Z
			v226.AssemblyLinearVelocity = Vector3.new(v241, v245, v246)
			v225:ChangeState(Enum.HumanoidStateType.Freefall)
		end
		return
	elseif not v_u_211.knockback then
		v_u_211.knockback = true
		warn((("[SimNaN] knockback auth=%* side=%*"):format(v_u_28 and "Client" or "Server", v_u_23 and "server" or "client")))
	end
end
local function v_u_260(p248, _) -- name: stepRelay
	-- upvalues: (copy) v_u_221
	local v249 = p248.humanoid
	local v250 = p248.root
	local v251
	if v249:GetState() == Enum.HumanoidStateType.Dead then
		v251 = false
	else
		v251 = v249.Health > 0
	end
	v_u_221(p248, v251)
	local v252 = p248.frozen and true or nil
	if v250:GetAttribute("SFrozen") ~= v252 then
		v250:SetAttribute("SFrozen", v252)
	end
	local v253
	if p248.slow == 1 then
		v253 = nil
	else
		local v254 = p248.slow / 0.001 + 0.5
		v253 = math.floor(v254) * 0.001
	end
	if v250:GetAttribute("SSlow") ~= v253 then
		v250:SetAttribute("SSlow", v253)
	end
	local v255 = p248.noJump and true or nil
	if v250:GetAttribute("SNoJump") ~= v255 then
		v250:SetAttribute("SNoJump", v255)
	end
	local v256 = p248.pending
	if v256.tp then
		local v257 = v256.tp
		v256.tp = nil
		p248.character:PivotTo(v257)
		v250:SetAttribute("STpCF", v257)
		local v258 = v250:GetAttribute("STp")
		v250:SetAttribute("STp", (type(v258) ~= "number" and 0 or v258) + 1)
	end
	if v256.kb and v251 then
		local v259 = v250:GetAttribute("NKbSeq")
		v250:SetAttribute("NKb", v256.kb)
		v250:SetAttribute("NKbDur", v256.kbDur)
		v250:SetAttribute("NKbSeq", (type(v259) ~= "number" and 0 or v259) + 1)
	end
	v256.kb = nil
	v256.kbDur = nil
end
local function v_u_521(p261, p262) -- name: stepChar
	-- upvalues: (copy) v_u_43, (copy) v_u_210, (copy) v_u_211, (copy) v_u_28, (copy) v_u_23, (copy) v_u_9, (copy) v_u_52, (copy) v_u_221, (copy) v_u_29, (copy) v_u_247, (copy) v_u_31, (copy) v_u_54, (copy) v_u_53, (copy) v_u_32, (copy) v_u_69, (copy) v_u_87, (copy) v_u_7, (copy) v_u_113, (copy) v_u_132, (copy) v_u_16, (copy) v_u_19, (copy) v_u_20, (copy) v_u_21, (copy) v_u_12, (copy) v_u_14, (copy) v_u_149, (copy) v_u_13, (copy) v_u_11, (copy) v_u_181, (copy) v_u_15, (copy) v_u_10, (copy) v_u_18, (copy) v_u_3, (copy) v_u_195
	local v263 = p261.humanoid
	local v264 = p261.root
	local v265 = p261.s
	v_u_43(p261)
	local v266 = v264.CFrame
	if not v_u_210(v266) then
		local v267 = p261.goodCF and "root" or "root (no last place)"
		if not v_u_211[v267] then
			v_u_211[v267] = true
			warn((("[SimNaN] %* auth=%* side=%*"):format(v267, v_u_28 and "Client" or "Server", v_u_23 and "server" or "client")))
		end
		local v268 = p261.root
		local v269 = p261.s
		local v270 = p261.push
		local v271 = p261.align
		local v272 = p261.gravity
		if v270 then
			v270.PlaneVelocity = Vector2.zero
			v270.Enabled = false
		end
		if v271 then
			v271.Enabled = false
			v271.CFrame = CFrame.identity
		end
		if v272 then
			v272.Force = Vector3.new(0, 0, 0)
			v272.Enabled = false
		end
		local v273 = p261.goodCF
		if v273 then
			v268.CFrame = v273
		end
		v268.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
		v268.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
		v269.SSlide = nil
		v269.SSlideDir = nil
		v269.SSlideBuf = nil
		v269.SSlope = nil
		v269.SLift = nil
		v269.SKb = nil
		v269.SKbF = nil
		v269.SKbN = nil
		v269.SDashV = nil
		v269.SDashF = nil
		v269.SDashB = nil
		v269.SBoost = nil
		v269.SJumpBuf = nil
		v269.SSpeed = v_u_9
		v_u_52(p261)
		return
	end
	p261.goodCF = v266
	local v274 = v263:GetState()
	local v275 = v274 ~= Enum.HumanoidStateType.Dead
	v_u_221(p261, v275)
	if v_u_29 then
		v265.SFrozen = p261.frozen and true or nil
		local v276
		if p261.slow == 1 then
			v276 = nil
		else
			local v277 = p261.slow / 0.001 + 0.5
			v276 = math.floor(v277) * 0.001
		end
		v265.SSlow = v276
		v265.SNoJump = p261.noJump and true or nil
		local v278 = p261.pending
		if v278.tp then
			local v279 = v278.tp
			v278.tp = nil
			p261.character:PivotTo(v279)
			v264.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
			v265.SSlide = nil
			v265.SSlideDir = nil
			v265.SSlideBuf = nil
			v265.SSlope = nil
			v265.SLift = nil
			v265.SKb = nil
			v265.SKbF = nil
			v265.SKbN = nil
			v265.SDashV = nil
			v265.SDashF = nil
			v265.SDashB = nil
			v265.SBoost = nil
			v265.SJumpBuf = nil
			v265.SSpeed = v_u_9
			local v280 = v265.STp
			v265.STp = (type(v280) ~= "number" and 0 or v265.STp) + 1
		end
		if v278.kb and v275 then
			v_u_247(p261, v278.kb, v278.kbDur)
		end
		v278.kb = nil
		v278.kbDur = nil
	elseif v_u_28 then
		local v281 = v265.STp
		if v281 ~= p261.tpSeen then
			p261.tpSeen = v281
			local v282 = v264:GetAttribute("STpCF")
			if typeof(v282) == "CFrame" and (v_u_210(v282) and (v264.Position - v282.Position).Magnitude > 30) then
				p261.character:PivotTo(v282)
			end
			v264.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
			v265.SSlide = nil
			v265.SSlideDir = nil
			v265.SSlideBuf = nil
			v265.SSlope = nil
			v265.SLift = nil
			v265.SKb = nil
			v265.SKbF = nil
			v265.SKbN = nil
			v265.SDashV = nil
			v265.SDashF = nil
			v265.SDashB = nil
			v265.SBoost = nil
			v265.SJumpBuf = nil
			v265.SSpeed = v_u_9
		end
		local v283 = v264:GetAttribute("NKbSeq")
		if v283 ~= p261.kbSeen then
			p261.kbSeen = v283
			local v284 = v264:GetAttribute("NKb")
			if v275 and (typeof(v284) == "Vector3" and v284 == v284) then
				local v285 = v264:GetAttribute("NKbDur")
				local v286 = v_u_247
				if type(v285) ~= "number" then
					v285 = nil
				end
				v286(p261, v284, v285)
			end
		end
	end
	if v263.UseJumpPower then
		v263.UseJumpPower = false
	end
	if v263:GetStateEnabled(Enum.HumanoidStateType.FallingDown) then
		v263:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false)
	end
	if v263:GetStateEnabled(Enum.HumanoidStateType.Ragdoll) then
		v263:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, false)
	end
	if v263:GetStateEnabled(Enum.HumanoidStateType.Swimming) ~= v_u_31 then
		v263:SetStateEnabled(Enum.HumanoidStateType.Swimming, v_u_31)
	end
	if not v275 then
		v265.SSlide = nil
		v265.SSlideDir = nil
		v265.SSlideBuf = nil
		v265.SSlope = nil
		v265.SLift = nil
		v265.SKb = nil
		v265.SKbF = nil
		v265.SKbN = nil
		v265.SDashV = nil
		v265.SDashF = nil
		v265.SDashB = nil
		v265.SBoost = nil
		v265.SJumpBuf = nil
		v265.SSpeed = v_u_9
		if p261.push and p261.push.Enabled then
			p261.push.Enabled = false
		end
		if p261.align and p261.align.Enabled then
			p261.align.Enabled = false
		end
		if p261.gravity and p261.gravity.Enabled then
			p261.gravity.Enabled = false
		end
		v_u_52(p261)
		return
	end
	local v287 = v265.SFrozen == true
	local v288 = v265.SSlow
	local v289 = type(v288) ~= "number" and 1 or v265.SSlow
	local v290 = v265.SNoJump == true and true or v289 <= 0.001
	local v291 = v265.SSpeed
	local v292
	if type(v291) == "number" then
		v292 = v265.SSpeed
	else
		v292 = v_u_9
	end
	local v293
	if v_u_28 and (not v_u_23 and v_u_54.Slide) then
		v293 = v_u_53.Slide
	else
		local v294 = p261.actions.Slide
		if v294 then
			v293 = v294:GetState()
		else
			v293 = nil
		end
	end
	local v295 = v293 == true
	local v296
	if v_u_28 and (not v_u_23 and v_u_54.Jump) then
		v296 = v_u_53.Jump
	else
		local v297 = p261.actions.Jump
		if v297 then
			v296 = v297:GetState()
		else
			v296 = nil
		end
	end
	local v298 = v296 == true
	local v299
	if v_u_28 and (not v_u_23 and v_u_54.Aim) then
		v299 = v_u_53.Aim
	else
		local v300 = p261.actions.Aim
		if v300 then
			v299 = v300:GetState()
		else
			v299 = nil
		end
	end
	local v301 = v299 == true
	local v302
	if v_u_28 and (not v_u_23 and v_u_54.Charge) then
		v302 = v_u_53.Charge
	else
		local v303 = p261.actions.Charge
		if v303 then
			v302 = v303:GetState()
		else
			v302 = nil
		end
	end
	local v304 = v302 == true
	local v305
	if v_u_28 and (not v_u_23 and v_u_54.Block) then
		v305 = v_u_53.Block
	else
		local v306 = p261.actions.Block
		if v306 then
			v305 = v306:GetState()
		else
			v305 = nil
		end
	end
	local v307 = v305 == true
	local v308
	if v_u_28 and (not v_u_23 and v_u_54.Reload) then
		v308 = v_u_53.Reload
	else
		local v309 = p261.actions.Reload
		if v309 then
			v308 = v309:GetState()
		else
			v308 = nil
		end
	end
	local v310 = v308 == true
	local v311
	if v_u_28 and (not v_u_23 and v_u_54.Use) then
		v311 = v_u_53.Use
	else
		local v312 = p261.actions.Use
		if v312 then
			v311 = v312:GetState()
		else
			v311 = nil
		end
	end
	local v313 = v311 == true
	local v314
	if v_u_28 and (not v_u_23 and v_u_54.Lunge) then
		v314 = v_u_53.Lunge
	else
		local v315 = p261.actions.Lunge
		if v315 then
			v314 = v315:GetState()
		else
			v314 = nil
		end
	end
	local v316 = v314 == true
	local v317 = nil
	local v318
	if v_u_28 and (not v_u_23 and v_u_54.Facing) then
		v318 = v_u_53.Facing
	else
		local v319 = p261.actions.Facing
		if v319 then
			v318 = v319:GetState()
		else
			v318 = nil
		end
	end
	if typeof(v318) == "Vector2" and (v318.X == v318.X and (v318.Y == v318.Y and (v318.Magnitude > 0.5 and v318.Magnitude < 1.5))) then
		v317 = v318.Unit
	end
	local v320 = v263.MoveDirection
	local v321
	if v_u_32 then
		v321 = nil
	else
		v321 = v_u_69(p261)
	end
	if v321 then
		v263:Move(v321, false)
	else
		v321 = v320
	end
	local v322 = v_u_87(p261)
	if v_u_32 then
		local v323 = p261.character:FindFirstChildWhichIsA("Tool")
		if v323 then
			v322 = v323:GetAttribute("WeaponId")
		else
			v322 = nil
		end
		if type(v322) ~= "string" then
			v322 = nil
		end
	end
	local v324, v325 = v_u_7.MoveSpeed(v322, v301, v304, v307, v310, v313)
	if not v_u_32 then
		local v326 = v265.SHipBase
		if type(v326) == "number" then
			if (v_u_23 or v_u_28) and p261.hipWritten then
				local v327 = v263.HipHeight - p261.hipWritten
				if math.abs(v327) > 0.002 then
					local v328 = v263.HipHeight / 0.001 + 0.5
					v265.SHipBase = math.floor(v328) * 0.001
					v265.SHip = nil
				end
			end
		else
			local v329 = v263.HipHeight / 0.001 + 0.5
			v265.SHipBase = math.floor(v329) * 0.001
		end
	end
	local v330 = v265.SHipBase
	local v331
	if type(v330) == "number" then
		v331 = v265.SHipBase
	else
		v331 = v263.HipHeight
	end
	local v332, v333, v334, v335 = v_u_113(p261, v331)
	local v336
	if v332 > 0 then
		v336 = v332
	else
		v336 = nil
	end
	v265.SWade = v336
	local v337 = v324 * v289 * (1 - v332 * 0.4)
	local v338 = v332 > 0.3 and true or v325
	local v339 = v289 <= 0.42 and true or v338
	local v340 = v263.FloorMaterial ~= Enum.Material.Air
	local v341 = v264.AssemblyLinearVelocity
	local v342 = not v340 or (v274 == Enum.HumanoidStateType.Jumping and true or v274 == Enum.HumanoidStateType.Freefall)
	local v343
	if v342 then
		v343 = v274 == Enum.HumanoidStateType.Jumping and true or v341.Y > 0
	else
		v343 = v342
	end
	local v344
	if v333 and (v343 or v342 and v264.Position.Y > v335 + 0.05) then
		v344 = nil
	else
		v344 = v333
	end
	local v345
	if v334 and (not v342 and v265.SSlide == nil) then
		local v346 = v321.X
		local v347 = v321.Z
		local v348 = Vector3.new(v346, 0, v347)
		if v348.Magnitude > 0.3 then
			v345 = v_u_132(p261, v348.Unit, v331, v334)
			if not v345 or v344 ~= nil and v344 >= v345 then
				v345 = v344
			end
		else
			v345 = v344
		end
	else
		v345 = v344
	end
	if v345 then
		v265.SWet = v_u_16
		local v349 = v265.SHipBase
		if type(v349) ~= "number" then
			local v350 = v263.HipHeight / 0.001 + 0.5
			v265.SHipBase = math.floor(v350) * 0.001
		end
	elseif v265.SWet ~= nil then
		local v351
		if v265.SWet > 1 then
			v351 = v265.SWet - 1
		else
			v351 = nil
		end
		v265.SWet = v351
	end
	local v352
	if v340 then
		v352 = v265.SGround ~= true
	else
		v352 = v340
	end
	v265.SGround = v340 and true or nil
	local v353
	if v340 then
		v353 = 0
	else
		local v354 = (v265.SAir or 0) + 1
		v353 = math.min(v354, 600)
	end
	local v355
	if v353 > 0 then
		v355 = v353
	else
		v355 = nil
	end
	v265.SAir = v355
	local v356 = v274 == Enum.HumanoidStateType.Jumping
	local v357
	if v356 then
		v357 = v265.SJumping ~= true
	else
		v357 = v356
	end
	v265.SJumping = v356 and true or nil
	if v356 then
		v265.SJumped = true
	elseif v340 then
		v265.SJumped = nil
	end
	local v358
	if (v265.SSlideCD or 0) > 1 then
		v358 = v265.SSlideCD - 1
	else
		v358 = nil
	end
	v265.SSlideCD = v358
	local v359
	if (v265.SSlideBuf or 0) > 1 then
		v359 = v265.SSlideBuf - 1
	else
		v359 = nil
	end
	v265.SSlideBuf = v359
	local v360
	if (v265.SDashCD or 0) > 1 then
		v360 = v265.SDashCD - 1
	else
		v360 = nil
	end
	v265.SDashCD = v360
	local v361 = p261.dashCd
	if v361 then
		for v362, v363 in v361 do
			local v364
			if v363 > 1 then
				v364 = v363 - 1
			else
				v364 = nil
			end
			v361[v362] = v364
		end
	end
	local v365 = (v265.SJumpBuf or 0) - 1
	local v366 = math.max(v365, 0)
	if v298 and v265.SJumpIn ~= true then
		v366 = v_u_19
	end
	if v352 and v366 > 0 then
		local v367 = v_u_20
		v366 = math.max(v366, v367)
	end
	v265.SJumpIn = v298 and true or nil
	if v304 then
		local v368 = (v265.SCharge or 0) + 1
		v265.SCharge = math.min(v368, 600)
		v265.SChargeRel = nil
	elseif v265.SCharge then
		local v369 = (v265.SChargeRel or 0) + 1
		if v_u_21 < v369 then
			v265.SCharge = nil
			v265.SChargeRel = nil
		else
			v265.SChargeRel = v369
		end
	end
	if v357 then
		v366 = 0
		if v265.SSlide ~= nil then
			if v265.SSlide ~= nil then
				v265.SSlide = nil
				v265.SSlideDir = nil
				v265.SSlope = nil
				v265.SLift = nil
				v265.SSlideCD = v_u_12
				local v370 = v265.SSpeed
				v265.SSpeed = math.max(v370, 17)
			end
			local v371 = v265.SSpeed
			v292 = math.max(v371, 27)
			v265.SBoost = v_u_14
		end
	end
	v265.SSpeed = v292
	local v372 = v265.SDashF or 0
	if v316 and v265.SLungeIn ~= true then
		local v373 = v_u_7.Tuning(v322).lunge
		if type(v373) == "table" and (v265.SDashCD == nil and not (p261.dashCd and p261.dashCd[v322])) and (not v287 and (v289 > 0.001 and (v265.SCharge or 0) * 0.016666666666666666 >= (v373.charge or 0.6) * 0.65)) then
			local v374
			if v317 then
				local v375 = v317.X
				local v376 = v317.Y
				v374 = Vector3.new(v375, 0, v376)
			else
				local v377 = v264.CFrame.LookVector
				local v378 = v377.X
				local v379 = v377.Z
				v374 = Vector3.new(v378, 0, v379)
			end
			if v374.Magnitude > 0.05 then
				local v380 = v374.Unit
				local v381 = v373.speed or 70
				local v382 = (v373.distance or 16) / v381
				local v383 = math.clamp(v382, 0.12, 0.35) * 60 + 0.5
				local v384 = math.floor(v383)
				v372 = math.max(1, v384)
				local v385 = v380.X * v381 / 0.01 + 0.5
				local v386 = math.floor(v385) * 0.01
				local v387 = v380.Z * v381 / 0.01 + 0.5
				local v388 = math.floor(v387) * 0.01
				v265.SDashV = Vector3.new(v386, 0, v388)
				v265.SDashB = v373.brake and 2 or nil
				local v389 = v_u_7.DASH_GAP * 0.85 * 60 + 0.5
				local v390 = math.floor(v389)
				v265.SDashCD = math.max(1, v390)
				p261.dashCd = p261.dashCd or {}
				local v391 = p261.dashCd
				local v392
				if v373.refreshOnKill then
					local v393 = v373.cooldown or 1
					v392 = math.min(v393, 0.6)
				else
					v392 = v373.cooldown or 1
				end
				local v394 = v392 * 0.85 * 60 + 0.5
				local v395 = math.floor(v394)
				v391[v322] = math.max(1, v395)
				v265.SCharge = nil
				v265.SChargeRel = nil
				if v265.SSlide ~= nil then
					v265.SSlide = nil
					v265.SSlideDir = nil
					v265.SSlope = nil
					v265.SLift = nil
					v265.SSlideCD = v_u_12
					local v396 = v265.SSpeed
					v265.SSpeed = math.max(v396, 17)
				end
			end
		end
	end
	v265.SLungeIn = v316 and true or nil
	local v397 = not (v287 or v339)
	if v397 then
		if v289 > 0.001 then
			if v265.SDashV == nil then
				v397 = v340
			else
				v397 = false
			end
		else
			v397 = false
		end
	end
	if v295 and v265.SSlideIn ~= true then
		if not v_u_149(v265, v263, v321, v341, v397) then
			v265.SSlideBuf = v_u_13
		end
	elseif v265.SSlide == nil and (v352 and v295 or v265.SSlideBuf ~= nil) and v321.Magnitude > 0.2 then
		v_u_149(v265, v263, v321, v341, v397)
	end
	v265.SSlideIn = v295 and true or nil
	local v398 = nil
	local v399
	if v265.SSlide == nil then
		local v400 = v_u_9
		local v401 = v265.SBoost or 0
		if v401 > 0 then
			local v402 = v265.SSpeed
			v400 = math.max(v400, v402)
			local v403
			if v401 > 1 then
				v403 = v401 - 1
			else
				v403 = nil
			end
			v265.SBoost = v403
		end
		local v404 = v340 and 8 or 1.6
		local v405 = v265.SSpeed
		if v405 >= v400 then
			local v406 = v400 - v405
			local v407 = -v404 * p262
			local v408 = v405 + v406 * (1 - math.exp(v407))
			local v409 = v408 - v400
			if math.abs(v409) >= 0.03 then
				v400 = v408
			end
		end
		v265.SSpeed = v400
		v399 = v400 * v337
	else
		local v410 = v265.SSlide + (v340 and 1 or 0)
		v265.SSlide = v410
		local v411 = v410 / v_u_11
		local v412 = math.clamp(v411, 0, 1)
		local v413 = v412 * -19 * v412 + 36
		local v414 = v265.SSlideDir
		if not v414 then
			local v415 = v264.CFrame.LookVector
			local v416 = v415.X
			local v417 = v415.Z
			v414 = Vector3.new(v416, 0, v417)
		end
		local v418 = v321.X
		local v419 = v321.Z
		local v420 = Vector3.new(v418, 0, v419)
		if v420.Magnitude > 0.3 then
			local v421 = v420.Unit
			local v422 = v414:Dot(v421)
			local v423 = math.clamp(v422, -1, 1)
			local v424 = math.acos(v423)
			if v424 > 0.001 and v424 < 2.0943951023931953 then
				local v425 = p262 * 1.6580627893946132 / v424
				v414 = v414:Lerp(v421, (math.min(1, v425))).Unit
			end
		end
		local v426 = v414.X / 0.0001 + 0.5
		local v427 = math.floor(v426) * 0.0001
		local v428 = v414.Z / 0.0001 + 0.5
		local v429 = math.floor(v428) * 0.0001
		v398 = Vector3.new(v427, 0, v429)
		v265.SSlideDir = v398
		local v430 = v265.SSlope
		local v431 = type(v430) ~= "number" and 0 or v265.SSlope
		local v432
		if v340 then
			local v433 = v265.SHip
			local v434
			if type(v433) == "number" then
				v434 = v265.SHip
			elseif v_u_32 then
				v434 = v263.HipHeight
			else
				v434 = v265.SHipBase
			end
			local v435 = v265.SHipBase
			local v436
			if type(v435) == "number" then
				v436 = v265.SHipBase
			else
				v436 = v434
			end
			local v437 = v_u_181
			local v438 = v341.X
			local v439 = v341.Z
			local v440
			v440, v432 = v437(p261, v398, v413, Vector3.new(v438, 0, v439).Magnitude, v434, v436)
			if v440 then
				local v441 = p262 * 40
				local v442 = v440 - v431
				local v443 = -v441
				local v444 = (v431 + math.clamp(v442, v443, v441)) / 0.01 + 0.5
				v431 = math.floor(v444) * 0.01
			end
		else
			v432 = nil
		end
		local v445
		if v431 == 0 then
			v445 = nil
		else
			v445 = v431
		end
		v265.SSlope = v445
		local v446
		if v432 then
			local v447 = v432 / 0.01 + 0.5
			v446 = math.floor(v447) * 0.01
		else
			v446 = nil
		end
		v265.SLift = v446
		local v448 = v413 + v431
		v265.SSpeed = v448
		v399 = v448 * v337
		v263:Move(v398, false)
		local v449 = v341.X
		local v450 = v341.Z
		local v451 = Vector3.new(v449, 0, v450).Magnitude
		if v340 or v_u_15 >= v353 then
			if (v412 >= 1 or v410 * 0.016666666666666666 > 0.2 and v451 < 6 or (v287 or v339)) and v265.SSlide ~= nil then
				v265.SSlide = nil
				v265.SSlideDir = nil
				v265.SSlope = nil
				v265.SLift = nil
				v265.SSlideCD = v_u_12
				local v452 = v265.SSpeed
				v265.SSpeed = math.max(v452, 17)
			end
		else
			if v265.SSlide ~= nil then
				v265.SSlide = nil
				v265.SSlideDir = nil
				v265.SSlope = nil
				v265.SLift = nil
				v265.SSlideCD = v_u_12
				local v453 = v265.SSpeed
				v265.SSpeed = math.max(v453, 17)
			end
			local v454 = v265.SSpeed
			v265.SSpeed = math.max(v454, v448)
			v265.SBoost = v_u_14
		end
	end
	local v455 = v265.SSpeed / 0.001 + 0.5
	v265.SSpeed = math.floor(v455) * 0.001
	if v287 then
		v265.SSpeed = v_u_9
		v399 = 0
	end
	local v456 = v399 / 0.01 + 0.5
	local v457 = math.floor(v456) * 0.01
	local v458
	if v457 == v457 and v457 > -10000000 then
		v458 = v457 < 10000000
	else
		v458 = false
	end
	if not v458 then
		if not v_u_211["walk speed"] then
			v_u_211["walk speed"] = true
			warn((("[SimNaN] walk speed auth=%* side=%*"):format(v_u_28 and "Client" or "Server", v_u_23 and "server" or "client")))
		end
		v457 = v_u_9
		v265.SSpeed = v_u_9
	end
	if v263.WalkSpeed ~= v457 then
		v263.WalkSpeed = v457
	end
	local v459 = v265.SHipBase
	if type(v459) == "number" then
		if v265.SSlide ~= nil then
			local v460 = v459 - 1.4
			local v461 = math.max(0.3, v460)
			v459 = v265.SLift
			if type(v459) == "number" then
				if v461 >= v459 then
					v459 = v461
				end
			else
				v459 = v461
			end
		end
		if v345 then
			if v459 < v345 then
				v459 = v345
			end
		end
	else
		v459 = nil
	end
	local v462, v463, v464, v465, v466, v467, v468, v469, v470, v471, v472, v473, v474, v475, v476, v477, v478, v479, v480, v481, v482, v483, v484, v485, v486, v487, v488, v489, v490, v491, v492, v493, v494, v495, v496, v497, v498, v499, v500, v501, v502, v503, v504, v505, v506, v507
	if v459 then
		local v508 = v265.SHip
		local v509
		if type(v508) == "number" then
			v509 = v265.SHip
		elseif v_u_32 then
			local v510 = v263.HipHeight / 0.001 + 0.5
			v509 = math.floor(v510) * 0.001
		else
			v509 = v265.SHipBase
		end
		local v511
		if v344 and v459 == v344 or v265.SWet ~= nil and (v265.SSlide == nil and (v459 < v509 and v342)) then
			v511 = v459
		else
			local v512 = v509 - v459
			if math.abs(v512) > 0.01 then
				local v513 = v459 < v509 and 30 or (v265.SLift == nil and (v345 and 30 or 14) or 45)
				local v514 = v459 - v509
				local v515 = -v513 * p262
				local v516 = (v509 + v514 * (1 - math.exp(v515))) / 0.001 + 0.5
				v511 = math.floor(v516) * 0.001
			else
				v511 = v459
			end
		end
		if v265.SSlide == nil and (v265.SWet == nil and v511 == v459) then
			v265.SHip = nil
			if v_u_32 then
				v265.SHipBase = nil
			end
		else
			v265.SHip = v511
		end
		local v517
		if v511 == v511 and v511 > -10000000 then
			v517 = v511 < 10000000
		else
			v517 = false
		end
		if v517 then
			if v263.HipHeight ~= v511 then
				v263.HipHeight = v511
			end
			p261.hipWritten = v511
		else
			if not v_u_211["hip height"] then
				v_u_211["hip height"] = true
				warn((("[SimNaN] hip height auth=%* side=%*"):format(v_u_28 and "Client" or "Server", v_u_23 and "server" or "client")))
			end
			local v518 = v265.SHipBase
			if type(v518) == "number" then
				local v519 = v265.SHipBase
				local v520
				if v519 == v519 and v519 > -10000000 then
					v520 = v519 < 10000000
				else
					v520 = false
				end
				if v520 then
					v511 = v265.SHipBase
					v265.SHip = nil
				else
					v511 = v263.HipHeight
					v265.SHip = nil
				end
			else
				v511 = v263.HipHeight
				v265.SHip = nil
			end
			if v263.HipHeight ~= v511 then
				v263.HipHeight = v511
			end
			p261.hipWritten = v511
		end
		v462 = not (v287 or v290)
		if v462 then
			v462 = v263.SeatPart == nil
		end
		if v462 then
			v463 = v_u_10 * (1 - v332 * 0.45) / 0.01 + 0.5
			v464 = math.floor(v463) * 0.01
		else
			v464 = 0
		end
		if v263.JumpHeight ~= v464 then
			v263.JumpHeight = v464
		end
		v465 = false
		if v462 then
			if v340 then
				v465 = v298 or v366 > 0
			elseif v265.SJumped ~= true and (v353 <= v_u_18 and (v341.Y <= 1 and v366 > 0)) then
				v265.SJumped = true
				v263:ChangeState(Enum.HumanoidStateType.Jumping)
				v366 = 0
			end
		end
		v263.Jump = v465
		if v366 <= 0 then
			v366 = nil
		end
		v265.SJumpBuf = v366
		v466 = p261.gravity
		v467 = not v340
		if v467 then
			if v341.Y < 0 then
				v467 = v274 ~= Enum.HumanoidStateType.Climbing
			else
				v467 = false
			end
		end
		if v466 then
			if v467 then
				v468 = -v_u_3.Gravity * 0.30000000000000004
				if v265.SSlide == nil then
					if v333 then
						v469 = v_u_195(p261, v341.Y, v333, 4)
						if v469 then
							v468 = v469 + v_u_3.Gravity
						end
					end
				else
					v470 = v_u_195(p261, v341.Y, v263.HipHeight)
					if v470 then
						v468 = v470 + v_u_3.Gravity
					end
				end
				v471 = v468 * v264.AssemblyMass
				if v471 == v471 and v471 > -10000000 then
					v472 = v471 < 10000000
				else
					v472 = false
				end
				if not v472 then
					if v_u_211["fall force"] then
						v471 = 0
					else
						v_u_211["fall force"] = true
						warn((("[SimNaN] fall force auth=%* side=%*"):format(v_u_28 and "Client" or "Server", v_u_23 and "server" or "client")))
						v471 = 0
					end
				end
				v466.Force = Vector3.new(0, v471, 0)
			end
			if v466.Enabled ~= v467 then
				v466.Enabled = v467
			end
		end
		v473 = v265.SKbF or 0
		if v473 > 0 and v265.SKb then
			v474 = v265.SKbN or v473
			v475 = v473 / math.max(v474, 1)
			v476 = v321.X
			v477 = v321.Z
			v478 = Vector3.new(v476, 0, v477) * v457
			v479 = v265.SKb * v475 + v478 * (1 - v475)
			v480 = v473 - 1
			if v480 <= 0 then
				v265.SKb = nil
				v265.SKbF = nil
				v265.SKbN = nil
			else
				v265.SKbF = v480
			end
		else
			v479 = nil
		end
		if v372 > 0 and v265.SDashV then
			v481 = v265.SDashV
			if v479 then
				v479 = v479 + v481
			else
				v479 = v481
			end
			v482 = v481.X
			v483 = v481.Z
			v398 = Vector3.new(v482, 0, v483).Unit
			v372 = v372 - 1
		elseif v265.SDashB then
			if not v479 then
				v484 = v321.X
				v485 = v321.Z
				v479 = Vector3.new(v484, 0, v485) * v457
			end
			if v265.SDashB > 1 then
				v486 = v265.SDashB - 1
			else
				v486 = nil
			end
			v265.SDashB = v486
		end
		if v372 <= 0 then
			v265.SDashV = nil
			v265.SDashF = nil
		else
			v265.SDashF = v372
		end
		if v479 then
			v487 = v479.X
			if v487 == v487 and v487 > -10000000 then
				v488 = v487 < 10000000
			else
				v488 = false
			end
			if v488 then
				v489 = v479.Y
				if v489 == v489 and v489 > -10000000 then
					v488 = v489 < 10000000
				else
					v488 = false
				end
				if v488 then
					v490 = v479.Z
					if v490 == v490 and v490 > -10000000 then
						v488 = v490 < 10000000
					else
						v488 = false
					end
				end
			end
			if not v488 then
				v491 = v265.SKb == nil and (v265.SDashV == nil and "push" or "push (dash)") or "push (knockback)"
				if not v_u_211[v491] then
					v_u_211[v491] = true
					warn((("[SimNaN] %* auth=%* side=%*"):format(v491, v_u_28 and "Client" or "Server", v_u_23 and "server" or "client")))
				end
				v265.SKb = nil
				v265.SKbF = nil
				v265.SKbN = nil
				v265.SDashV = nil
				v265.SDashF = nil
				v479 = nil
			end
		end
		v492 = p261.push
		if v492 then
			if v479 then
				v492.PlaneVelocity = Vector2.new(v479.X, v479.Z)
			end
			v493 = v479 ~= nil
			if v492.Enabled ~= v493 then
				v492.Enabled = v493
			end
		end
		if not v398 and (v317 and (not v287 and v263.SeatPart == nil)) then
			v494 = v317.X
			v495 = v317.Y
			v398 = Vector3.new(v494, 0, v495)
		end
		v496 = p261.align
		if v398 then
			v497 = v398.X
			if v497 == v497 and v497 > -10000000 then
				v498 = v497 < 10000000
			else
				v498 = false
			end
			if v498 then
				v499 = v398.Y
				if v499 == v499 and v499 > -10000000 then
					v498 = v499 < 10000000
				else
					v498 = false
				end
				if v498 then
					v500 = v398.Z
					if v500 == v500 and v500 > -10000000 then
						v498 = v500 < 10000000
					else
						v498 = false
					end
				end
			end
			if not v498 then
				if v_u_211.facing then
					v398 = nil
				else
					v_u_211.facing = true
					warn((("[SimNaN] facing auth=%* side=%*"):format(v_u_28 and "Client" or "Server", v_u_23 and "server" or "client")))
					v398 = nil
				end
			end
		end
		if v398 and (v496 and v398.Magnitude > 0.1) then
			if v263.AutoRotate then
				v263.AutoRotate = false
			end
			v501 = v398.Unit
			v502 = CFrame.lookAt
			v503 = v501.X / 0.0001 + 0.5
			v504 = math.floor(v503) * 0.0001
			v505 = v501.Z / 0.0001 + 0.5
			v506 = math.floor(v505) * 0.0001
			v507 = v502(Vector3.new(0, 0, 0), (Vector3.new(v504, 0, v506)))
			if v496.CFrame ~= v507 then
				v496.CFrame = v507
			end
			if not v496.Enabled then
				v496.Enabled = true
			end
		else
			if v496 and v496.Enabled then
				v496.Enabled = false
			end
			if not v263.AutoRotate then
				v263.AutoRotate = true
			end
		end
		v_u_52(p261)
	else
		v462 = not (v287 or v290)
		if v462 then
			v462 = v263.SeatPart == nil
		end
		if v462 then
			v463 = v_u_10 * (1 - v332 * 0.45) / 0.01 + 0.5
			v464 = math.floor(v463) * 0.01
		else
			v464 = 0
		end
		if v263.JumpHeight ~= v464 then
			v263.JumpHeight = v464
		end
		v465 = false
		if v462 then
			if v340 then
				v465 = v298 or v366 > 0
			elseif v265.SJumped ~= true and (v353 <= v_u_18 and (v341.Y <= 1 and v366 > 0)) then
				v265.SJumped = true
				v263:ChangeState(Enum.HumanoidStateType.Jumping)
				v366 = 0
			end
		end
		v263.Jump = v465
		if v366 <= 0 then
			v366 = nil
		end
		v265.SJumpBuf = v366
		v466 = p261.gravity
		v467 = not v340
		if v467 then
			if v341.Y < 0 then
				v467 = v274 ~= Enum.HumanoidStateType.Climbing
			else
				v467 = false
			end
		end
		if v466 then
			if v467 then
				v468 = -v_u_3.Gravity * 0.30000000000000004
				if v265.SSlide == nil then
					if v333 then
						v469 = v_u_195(p261, v341.Y, v333, 4)
						if v469 then
							v468 = v469 + v_u_3.Gravity
						end
					end
				else
					v470 = v_u_195(p261, v341.Y, v263.HipHeight)
					if v470 then
						v468 = v470 + v_u_3.Gravity
					end
				end
				v471 = v468 * v264.AssemblyMass
				if v471 == v471 and v471 > -10000000 then
					v472 = v471 < 10000000
				else
					v472 = false
				end
				if not v472 then
					if v_u_211["fall force"] then
						v471 = 0
					else
						v_u_211["fall force"] = true
						warn((("[SimNaN] fall force auth=%* side=%*"):format(v_u_28 and "Client" or "Server", v_u_23 and "server" or "client")))
						v471 = 0
					end
				end
				v466.Force = Vector3.new(0, v471, 0)
			end
			if v466.Enabled ~= v467 then
				v466.Enabled = v467
			end
		end
		v473 = v265.SKbF or 0
		if v473 > 0 and v265.SKb then
			v474 = v265.SKbN or v473
			v475 = v473 / math.max(v474, 1)
			v476 = v321.X
			v477 = v321.Z
			v478 = Vector3.new(v476, 0, v477) * v457
			v479 = v265.SKb * v475 + v478 * (1 - v475)
			v480 = v473 - 1
			if v480 <= 0 then
				v265.SKb = nil
				v265.SKbF = nil
				v265.SKbN = nil
			else
				v265.SKbF = v480
			end
		else
			v479 = nil
		end
		if v372 > 0 and v265.SDashV then
			v481 = v265.SDashV
			if v479 then
				v479 = v479 + v481
			else
				v479 = v481
			end
			v482 = v481.X
			v483 = v481.Z
			v398 = Vector3.new(v482, 0, v483).Unit
			v372 = v372 - 1
		elseif v265.SDashB then
			if not v479 then
				v484 = v321.X
				v485 = v321.Z
				v479 = Vector3.new(v484, 0, v485) * v457
			end
			if v265.SDashB > 1 then
				v486 = v265.SDashB - 1
			else
				v486 = nil
			end
			v265.SDashB = v486
		end
		if v372 <= 0 then
			v265.SDashV = nil
			v265.SDashF = nil
		else
			v265.SDashF = v372
		end
		if v479 then
			v487 = v479.X
			if v487 == v487 and v487 > -10000000 then
				v488 = v487 < 10000000
			else
				v488 = false
			end
			if v488 then
				v489 = v479.Y
				if v489 == v489 and v489 > -10000000 then
					v488 = v489 < 10000000
				else
					v488 = false
				end
				if v488 then
					v490 = v479.Z
					if v490 == v490 and v490 > -10000000 then
						v488 = v490 < 10000000
					else
						v488 = false
					end
				end
			end
			if not v488 then
				v491 = v265.SKb == nil and (v265.SDashV == nil and "push" or "push (dash)") or "push (knockback)"
				if not v_u_211[v491] then
					v_u_211[v491] = true
					warn((("[SimNaN] %* auth=%* side=%*"):format(v491, v_u_28 and "Client" or "Server", v_u_23 and "server" or "client")))
				end
				v265.SKb = nil
				v265.SKbF = nil
				v265.SKbN = nil
				v265.SDashV = nil
				v265.SDashF = nil
				v479 = nil
			end
		end
		v492 = p261.push
		if v492 then
			if v479 then
				v492.PlaneVelocity = Vector2.new(v479.X, v479.Z)
			end
			v493 = v479 ~= nil
			if v492.Enabled ~= v493 then
				v492.Enabled = v493
			end
		end
		if not v398 and (v317 and (not v287 and v263.SeatPart == nil)) then
			v494 = v317.X
			v495 = v317.Y
			v398 = Vector3.new(v494, 0, v495)
		end
		v496 = p261.align
		if v398 then
			v497 = v398.X
			if v497 == v497 and v497 > -10000000 then
				v498 = v497 < 10000000
			else
				v498 = false
			end
			if v498 then
				v499 = v398.Y
				if v499 == v499 and v499 > -10000000 then
					v498 = v499 < 10000000
				else
					v498 = false
				end
				if v498 then
					v500 = v398.Z
					if v500 == v500 and v500 > -10000000 then
						v498 = v500 < 10000000
					else
						v498 = false
					end
				end
			end
			if not v498 then
				if v_u_211.facing then
					v398 = nil
				else
					v_u_211.facing = true
					warn((("[SimNaN] facing auth=%* side=%*"):format(v_u_28 and "Client" or "Server", v_u_23 and "server" or "client")))
					v398 = nil
				end
			end
		end
		if v398 and (v496 and v398.Magnitude > 0.1) then
			if v263.AutoRotate then
				v263.AutoRotate = false
			end
			v501 = v398.Unit
			v502 = CFrame.lookAt
			v503 = v501.X / 0.0001 + 0.5
			v504 = math.floor(v503) * 0.0001
			v505 = v501.Z / 0.0001 + 0.5
			v506 = math.floor(v505) * 0.0001
			v507 = v502(Vector3.new(0, 0, 0), (Vector3.new(v504, 0, v506)))
			if v496.CFrame ~= v507 then
				v496.CFrame = v507
			end
			if not v496.Enabled then
				v496.Enabled = true
			end
		else
			if v496 and v496.Enabled then
				v496.Enabled = false
			end
			if not v263.AutoRotate then
				v263.AutoRotate = true
			end
		end
		v_u_52(p261)
	end
end
local v_u_522 = {
	["steps"] = 0,
	["time"] = 0,
	["maxStep"] = 0,
	["chars"] = 0
}
function v_u_8.DebugStats() -- name: DebugStats
	-- upvalues: (copy) v_u_522, (copy) v_u_34
	return {
		["steps"] = v_u_522.steps,
		["msPerStep"] = v_u_522.steps <= 0 and 0 or v_u_522.time / v_u_522.steps * 1000,
		["maxStepMs"] = v_u_522.maxStep * 1000,
		["characters"] = #v_u_34
	}
end
v_u_8.CORRECTION_MAX = 20
local v_u_523 = Vector3.new(0, 0, 0)
local v_u_524 = nil
local v_u_525 = Vector3.new(0, 0, 0)
local v_u_526 = nil
local v_u_527 = nil
local v_u_528 = false
local function v_u_537(p529) -- name: trackCorrection
	-- upvalues: (copy) v_u_2, (ref) v_u_528, (copy) v_u_34, (ref) v_u_524, (ref) v_u_526, (ref) v_u_527, (ref) v_u_525, (ref) v_u_523
	if v_u_2:IsResimulating() then
		v_u_528 = true
		return
	else
		local v530 = v_u_34[1]
		if v530 then
			local v531 = v530.root
			local v532 = v531.Position
			local v533 = v531.AssemblyLinearVelocity
			local v534 = v531:GetAttribute("STp")
			if v_u_528 and (v_u_524 and (v531 == v_u_526 and v534 == v_u_527)) then
				local v535 = v532 - (v_u_524 + (v_u_525 + v533) * 0.5 * p529)
				local v536 = v535.Magnitude
				if v536 > 0.02 and v536 < 20 then
					v_u_523 = v_u_523 + v535
				end
			end
			v_u_524 = v532
			v_u_525 = v533
			v_u_526 = v531
			v_u_527 = v534
			v_u_528 = false
		else
			v_u_524 = nil
			v_u_526 = nil
			v_u_528 = false
		end
	end
end
function v_u_8.TakeCorrection() -- name: TakeCorrection
	-- upvalues: (ref) v_u_523
	local v538 = v_u_523
	v_u_523 = Vector3.new(0, 0, 0)
	return v538
end
function v_u_8.RebaseCorrection() -- name: RebaseCorrection
	-- upvalues: (copy) v_u_34, (copy) v_u_23, (ref) v_u_524, (ref) v_u_525, (ref) v_u_526, (ref) v_u_527, (ref) v_u_528
	local v539 = v_u_34[1]
	if not v_u_23 and v539 then
		local v540 = v539.root
		local v541 = v540.AssemblyLinearVelocity
		local v542 = v540.Position - v541 * 0.016666666666666666
		local v543 = v540:GetAttribute("STp")
		v_u_524 = v542
		v_u_525 = v541
		v_u_526 = v540
		v_u_527 = v543
		v_u_528 = false
	end
end
local function v_u_553(p544) -- name: step
	-- upvalues: (copy) v_u_23, (copy) v_u_537, (copy) v_u_30, (copy) v_u_260, (copy) v_u_521, (copy) v_u_34, (copy) v_u_522
	local v545 = os.clock()
	if not v_u_23 then
		v_u_537(p544)
	end
	local v546
	if v_u_30 then
		v546 = v_u_260
	else
		v546 = v_u_521
	end
	for _, v547 in v_u_34 do
		if v547.failed then
			continue
		end
		local v548, v549 = pcall(v546, v547, p544)
		if v548 then
			continue
		end
		v547.failed = true
		warn((("[Simulation] step failed for %*: %*"):format(v547.character.Name, v549)))
	end
	local v550 = os.clock() - v545
	local v551 = v_u_522
	v551.steps = v551.steps + 1
	local v552 = v_u_522
	v552.time = v552.time + v550
	if v_u_522.maxStep < v550 then
		v_u_522.maxStep = v550
	end
end
local function v_u_559(p554) -- name: unregister
	-- upvalues: (copy) v_u_33, (copy) v_u_34
	local v555 = v_u_33[p554]
	if v555 then
		v_u_33[p554] = nil
		for _, v556 in v555.conns do
			v556:Disconnect()
		end
		table.clear(v_u_34)
		for _, v557 in v_u_33 do
			local v558 = v_u_34
			table.insert(v558, v557)
		end
	end
end
local function v_u_566(p560, p561) -- name: actionsOf
	-- upvalues: (copy) v_u_5
	local v562 = {}
	local v563 = p560:FindFirstChild(v_u_5.CONTEXT) or p560:WaitForChild(v_u_5.CONTEXT, p561)
	if not v563 then
		return v562
	end
	for _, v564 in v_u_5.ACTIONS do
		local v565 = v563:FindFirstChild(v564.name) or v563:WaitForChild(v564.name, 5)
		if not (v565 and v565:IsA("InputAction")) then
			continue
		end
		v562[v564.name] = v565
	end
	return v562
end
local function v_u_570(p567, p568) -- name: moveActionOf
	local v569 = p567:FindFirstChild("InputContexts") or p567:WaitForChild("InputContexts", p568)
	if v569 then
		v569 = v569:FindFirstChild("CharacterContext") or v569:WaitForChild("CharacterContext", 5)
	end
	if v569 then
		v569 = v569:FindFirstChild("MoveAction") or v569:WaitForChild("MoveAction", 5)
	end
	if v569 and v569:IsA("InputAction") then
		return v569
	end
	warn("[Simulation] no InputContexts.CharacterContext.MoveAction: walking falls back to the PlayerModule")
	return nil
end
local function v_u_576(p571) -- name: recomputeMirrors
	local v572 = p571.humanoid
	local v573 = 1
	for v574, v575 in v572:GetAttributes() do
		if typeof(v575) ~= "number" or (string.sub(v574, 1, 9) ~= "SpeedMult" or v575 ~= v575) then
			continue
		end
		v573 = v573 * math.clamp(v575, 0, 3)
	end
	p571.slow = v573
	p571.frozen = p571.player:GetAttribute("Frozen") == true
	p571.noJump = (v572:GetAttribute("NoJump") == true or p571.character:GetAttribute("NoJump") == true) and true or p571.character:GetAttribute("Rooted") == true
end
local function v_u_582(p577) -- name: ensureConstraints
	local v578 = p577:FindFirstChild("RootAttachment")
	if v578 and v578:IsA("Attachment") then
		local v579 = p577:FindFirstChild("TribesKnockback")
		if not v579 then
			v579 = Instance.new("LinearVelocity")
			v579.Name = "TribesKnockback"
			v579.Attachment0 = v578
			v579.RelativeTo = Enum.ActuatorRelativeTo.World
			v579.VelocityConstraintMode = Enum.VelocityConstraintMode.Plane
			v579.PrimaryTangentAxis = Vector3.new(1, 0, 0)
			v579.SecondaryTangentAxis = Vector3.new(0, 0, 1)
			v579.ForceLimitMode = Enum.ForceLimitMode.Magnitude
			v579.MaxForce = 1000000
			v579.Enabled = false
			v579.Parent = p577
		end
		local v580 = p577:FindFirstChild("TribesFallGravity")
		if not v580 then
			v580 = Instance.new("VectorForce")
			v580.Name = "TribesFallGravity"
			v580.Attachment0 = v578
			v580.RelativeTo = Enum.ActuatorRelativeTo.World
			v580.ApplyAtCenterOfMass = true
			v580.Force = Vector3.new(0, 0, 0)
			v580.Enabled = false
			v580.Parent = p577
		end
		local v581 = p577:FindFirstChild("TribesFacing")
		if not v581 then
			v581 = Instance.new("AlignOrientation")
			v581.Name = "TribesFacing"
			v581.Mode = Enum.OrientationAlignmentMode.OneAttachment
			v581.Attachment0 = v578
			v581.RigidityEnabled = true
			v581.MaxTorque = (1 / 0)
			v581.MaxAngularVelocity = (1 / 0)
			v581.Enabled = false
			v581.Parent = p577
		end
		if not (v579 and v579:IsA("LinearVelocity")) then
			v579 = nil
		end
		if not (v580 and v580:IsA("VectorForce")) then
			v580 = nil
		end
		if v581 and v581:IsA("AlignOrientation") then
			return v579, v580, v581
		else
			return v579, v580, nil
		end
	else
		return nil, nil, nil
	end
end
local function v_u_591(p583) -- name: ensureHull
	-- upvalues: (copy) v_u_32
	local v584 = p583:FindFirstChild("TribesHull")
	if v584 and v584:IsA("BasePart") then
		return v584
	end
	if v_u_32 then
		return nil
	end
	local v585 = p583.Size
	local v586 = Instance.new("Part")
	v586.Name = "TribesHull"
	v586.Shape = Enum.PartType.Cylinder
	local v587 = v585.Y * 1.4
	local v588 = v585.X * 0.9
	local v589 = v585.X * 0.9
	v586.Size = Vector3.new(v587, v588, v589)
	v586.Transparency = 1
	v586.CastShadow = false
	v586.Massless = true
	v586.CanCollide = true
	v586.CanQuery = false
	v586.CanTouch = false
	v586.CollisionGroup = p583.CollisionGroup
	v586.CFrame = p583.CFrame * CFrame.new(0, v585.Y * 0.2, 0) * CFrame.Angles(0, 0, 1.5707963267948966)
	local v590 = Instance.new("WeldConstraint")
	v590.Part0 = p583
	v590.Part1 = v586
	v590.Parent = v586
	v586.Parent = p583
	return v586
end
local function v_u_596(p592) -- name: corpseParts
	-- upvalues: (copy) v_u_17
	local v593 = {}
	for _, v594 in v_u_17 do
		local v595 = p592:FindFirstChild(v594)
		if not (v595 and v595:IsA("BasePart")) then
			continue
		end
		table.insert(v593, v595)
	end
	return v593
end
local function v_u_600(p597) -- name: bodyParts
	local v598 = {}
	for _, v599 in p597:GetChildren() do
		if not v599:IsA("BasePart") then
			continue
		end
		table.insert(v598, v599)
	end
	return v598
end
local function v_u_635(p_u_601, p_u_602) -- name: register
	-- upvalues: (copy) v_u_33, (copy) v_u_34, (copy) v_u_23, (copy) v_u_10, (copy) v_u_9, (copy) v_u_31, (copy) v_u_582, (copy) v_u_591, (copy) v_u_28, (copy) v_u_2, (copy) v_u_32, (copy) v_u_30, (copy) v_u_566, (copy) v_u_570, (copy) v_u_600, (copy) v_u_596, (copy) v_u_576
	local v603 = v_u_33[p_u_602]
	if v603 then
		v_u_33[p_u_602] = nil
		for _, v604 in v603.conns do
			v604:Disconnect()
		end
		table.clear(v_u_34)
		for _, v605 in v_u_33 do
			local v606 = v_u_34
			table.insert(v606, v605)
		end
	end
	local v607 = p_u_602:WaitForChild("Humanoid", 10)
	local v_u_608 = p_u_602:WaitForChild("HumanoidRootPart", 10)
	if v607 and (v607:IsA("Humanoid") and (v_u_608 and v_u_608:IsA("BasePart"))) then
		if p_u_601.Character == p_u_602 then
			local v609, v610, v611, v612
			if v_u_23 then
				v607.UseJumpPower = false
				v607.JumpHeight = v_u_10
				v607.WalkSpeed = v_u_9
				v607:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false)
				v607:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, false)
				v607:SetStateEnabled(Enum.HumanoidStateType.Swimming, v_u_31)
				v609, v610, v611 = v_u_582(v_u_608)
				v612 = v_u_591(v_u_608)
				if v_u_28 then
					pcall(function()
						-- upvalues: (copy) v_u_608, (copy) p_u_601
						v_u_608:SetNetworkOwner(p_u_601)
					end)
				end
			else
				local function v613()
					-- upvalues: (ref) v_u_2, (copy) v_u_608
					v_u_2:SetPredictionMode(v_u_608, Enum.PredictionMode.On)
				end
				pcall(v613)
				v607:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false)
				v607:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, false)
				v607:SetStateEnabled(Enum.HumanoidStateType.Swimming, v_u_31)
				v609 = v_u_608:WaitForChild("TribesKnockback", 10)
				v610 = v_u_608:WaitForChild("TribesFallGravity", 10)
				v611 = v_u_608:WaitForChild("TribesFacing", 10)
				if not (v609 and v609:IsA("LinearVelocity")) then
					v609 = nil
				end
				if not (v610 and v610:IsA("VectorForce")) then
					v610 = nil
				end
				if not (v611 and v611:IsA("AlignOrientation")) then
					v611 = nil
				end
				if v_u_32 then
					v612 = nil
				else
					v612 = v_u_608:WaitForChild("TribesHull", 10)
				end
				if not (v612 and v612:IsA("BasePart")) then
					v612 = nil
				end
			end
			local v614 = v_u_30 and {} or v_u_566(p_u_601, 20)
			local v615
			if v_u_28 then
				v615 = nil
			else
				v615 = v_u_570(p_u_601, 10)
			end
			if p_u_601.Character == p_u_602 and p_u_602.Parent then
				local v616 = RaycastParams.new()
				v616.FilterType = Enum.RaycastFilterType.Exclude
				v616.FilterDescendantsInstances = { p_u_602 }
				v616.RespectCanCollide = true
				v616.IgnoreWater = true
				local v_u_617 = {
					["player"] = nil,
					["character"] = nil,
					["humanoid"] = nil,
					["root"] = nil,
					["push"] = nil,
					["gravity"] = nil,
					["align"] = nil,
					["actions"] = nil,
					["move"] = nil,
					["hull"] = nil,
					["body"] = nil,
					["corpse"] = nil,
					["ray"] = nil,
					["s"] = nil,
					["prev"] = nil,
					["holdSlot"] = -1,
					["holdTool"] = nil,
					["frozen"] = false,
					["slow"] = 1,
					["noJump"] = false,
					["holdBad"] = 0,
					["hipWritten"] = nil,
					["tpSeen"] = nil,
					["kbSeen"] = nil,
					["pending"] = nil,
					["conns"] = nil,
					["failed"] = false,
					["player"] = p_u_601,
					["character"] = p_u_602,
					["humanoid"] = v607,
					["root"] = v_u_608,
					["push"] = v609,
					["gravity"] = v610,
					["align"] = v611,
					["actions"] = v614,
					["move"] = v615,
					["hull"] = v612,
					["body"] = v_u_600(p_u_602),
					["corpse"] = v_u_596(p_u_602),
					["ray"] = v616,
					["s"] = {},
					["prev"] = {},
					["tpSeen"] = v_u_608:GetAttribute("STp"),
					["kbSeen"] = v_u_608:GetAttribute("NKbSeq"),
					["pending"] = {},
					["conns"] = {}
				}
				if v_u_23 then
					v_u_576(v_u_617)
					local function v618() -- name: refresh
						-- upvalues: (ref) v_u_576, (copy) v_u_617
						v_u_576(v_u_617)
					end
					local v619 = v_u_617.conns
					local v620 = v607.AttributeChanged
					table.insert(v619, v620:Connect(v618))
					local v621 = v_u_617.conns
					local v622 = p_u_602.AttributeChanged
					table.insert(v621, v622:Connect(v618))
					local v623 = v_u_617.conns
					local v624 = p_u_601:GetAttributeChangedSignal("Frozen")
					table.insert(v623, v624:Connect(v618))
				end
				local v625 = v_u_617.conns
				local v626 = p_u_602.AncestryChanged
				local function v632()
					-- upvalues: (copy) p_u_602, (ref) v_u_33, (ref) v_u_34
					if not p_u_602:IsDescendantOf(game) then
						local v627 = p_u_602
						local v628 = v_u_33[v627]
						if not v628 then
							return
						end
						v_u_33[v627] = nil
						for _, v629 in v628.conns do
							v629:Disconnect()
						end
						table.clear(v_u_34)
						for _, v630 in v_u_33 do
							local v631 = v_u_34
							table.insert(v631, v630)
						end
					end
				end
				table.insert(v625, v626:Connect(v632))
				v_u_33[p_u_602] = v_u_617
				table.clear(v_u_34)
				for _, v633 in v_u_33 do
					local v634 = v_u_34
					table.insert(v634, v633)
				end
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_638(p_u_636) -- name: onPlayer
	-- upvalues: (copy) v_u_23, (copy) v_u_5, (copy) v_u_635, (copy) v_u_559
	if v_u_23 then
		v_u_5.Build(p_u_636)
	end
	p_u_636.CharacterAdded:Connect(function(p637)
		-- upvalues: (ref) v_u_635, (copy) p_u_636
		v_u_635(p_u_636, p637)
	end)
	p_u_636.CharacterRemoving:Connect(v_u_559)
	if p_u_636.Character then
		task.spawn(v_u_635, p_u_636, p_u_636.Character)
	end
end
function v_u_8.Knockback(p639, p640, p641) -- name: Knockback
	-- upvalues: (copy) v_u_33, (copy) v_u_23
	local v642 = v_u_33[p639]
	if not v642 or (not v_u_23 or (typeof(p640) ~= "Vector3" or p640 ~= p640)) then
		return false
	end
	local v643 = v642.pending
	if v643.kb then
		p640 = v643.kb + p640
	end
	v643.kb = p640
	v643.kbDur = p641
	return true
end
function v_u_8.Teleport(p644, p645) -- name: Teleport
	-- upvalues: (copy) v_u_33, (copy) v_u_23, (copy) v_u_210
	local v646 = v_u_33[p644]
	if not v646 or (not v_u_23 or (typeof(p645) ~= "CFrame" or not v_u_210(p645))) then
		return false
	end
	v646.pending.tp = p645
	return true
end
local v_u_647 = {}
local v_u_648 = {}
local v_u_649 = {}
local function v_u_653(p650) -- name: fire
	-- upvalues: (copy) v_u_647, (copy) v_u_53, (copy) v_u_648, (copy) v_u_28, (copy) v_u_54
	local v_u_651 = v_u_647[p650]
	local v_u_652 = v_u_53[p650]
	if v_u_651 and (v_u_652 ~= nil and v_u_648[p650] ~= v_u_652) then
		if not (v_u_28 and v_u_54[p650]) then
			if pcall(function()
				-- upvalues: (copy) v_u_651, (copy) v_u_652
				v_u_651:Fire(v_u_652)
			end) then
				v_u_648[p650] = v_u_652
			end
		end
	else
		return
	end
end
function v_u_8.SetInput(p654, p655) -- name: SetInput
	-- upvalues: (copy) v_u_23, (copy) v_u_649, (copy) v_u_53, (copy) v_u_653
	if not v_u_23 then
		v_u_649[p654] = (v_u_649[p654] or 0) + 1
		v_u_53[p654] = p655
		v_u_653(p654)
	end
end
function v_u_8.Pulse(p_u_656, p657) -- name: Pulse
	-- upvalues: (copy) v_u_8, (copy) v_u_649
	v_u_8.SetInput(p_u_656, true)
	local v_u_658 = v_u_649[p_u_656]
	task.delay(p657 or 0.12, function()
		-- upvalues: (ref) v_u_649, (copy) p_u_656, (copy) v_u_658, (ref) v_u_8
		if v_u_649[p_u_656] == v_u_658 then
			v_u_8.SetInput(p_u_656, false)
		end
	end)
end
function v_u_8.SetFacing(p659) -- name: SetFacing
	-- upvalues: (copy) v_u_8
	if p659 == nil or p659 ~= p659 then
		v_u_8.SetInput("Facing", Vector2.zero)
	else
		local v660 = v_u_8.SetInput
		local v661 = Vector2.new
		local v662 = -math.sin(p659) / 0.001 + 0.5
		local v663 = math.floor(v662) * 0.001
		local v664 = -math.cos(p659) / 0.001 + 0.5
		v660("Facing", v661(v663, math.floor(v664) * 0.001))
	end
end
function v_u_8.SetLook(p665) -- name: SetLook
	-- upvalues: (copy) v_u_23, (copy) v_u_8
	if not v_u_23 and (type(p665) == "number" and p665 == p665) then
		local v666 = v_u_8.SetInput
		local v667 = Vector2.new
		local v668 = -math.sin(p665) / 0.001 + 0.5
		local v669 = math.floor(v668) * 0.001
		local v670 = -math.cos(p665) / 0.001 + 0.5
		v666("Look", v667(v669, math.floor(v670) * 0.001))
	end
end
local function v_u_690(p671) -- name: watchHold
	-- upvalues: (copy) v_u_5, (copy) v_u_8
	local v_u_672 = {}
	local function v_u_680(p673) -- name: update
		-- upvalues: (ref) v_u_5, (ref) v_u_8
		local v674 = p673:FindFirstChildWhichIsA("Tool")
		local v675
		if v674 then
			v675 = v674:GetAttribute("SlotIndex")
		else
			v675 = nil
		end
		local v676
		if type(v675) == "number" and v675 == v675 then
			local v677 = v675 + 0.5
			local v678 = math.floor(v677)
			local v679 = v_u_5.HOLD_SLOTS
			v676 = math.clamp(v678, 0, v679)
		else
			v676 = 0
		end
		v_u_8.SetInput("Hold", v676 / v_u_5.HOLD_SCALE)
	end
	local function v689(p_u_681) -- name: onCharacter
		-- upvalues: (copy) v_u_672, (copy) v_u_680
		for _, v682 in v_u_672 do
			v682:Disconnect()
		end
		table.clear(v_u_672)
		local function v684(p683) -- name: changed
			-- upvalues: (ref) v_u_680, (copy) p_u_681
			if p683:IsA("Tool") then
				v_u_680(p_u_681)
			end
		end
		local v685 = v_u_672
		local v686 = p_u_681.ChildAdded
		table.insert(v685, v686:Connect(v684))
		local v687 = v_u_672
		local v688 = p_u_681.ChildRemoved
		table.insert(v687, v688:Connect(v684))
		v_u_680(p_u_681)
	end
	p671.CharacterAdded:Connect(v689)
	if p671.Character then
		v689(p671.Character)
	end
end
function v_u_8.WriteGuardStats() -- name: WriteGuardStats
	-- upvalues: (copy) v_u_6
	return v_u_6.Stats()
end
function v_u_8.WriteGuardReset() -- name: WriteGuardReset
	-- upvalues: (copy) v_u_6
	v_u_6.Reset()
end
function v_u_8.IsSliding(p691) -- name: IsSliding
	if p691 then
		p691 = p691:FindFirstChild("HumanoidRootPart")
	end
	local v692
	if p691 == nil then
		v692 = false
	else
		v692 = p691:GetAttribute("SSlide") ~= nil
	end
	return v692
end
function v_u_8.IsDashing(p693) -- name: IsDashing
	if p693 then
		p693 = p693:FindFirstChild("HumanoidRootPart")
	end
	local v694
	if p693 == nil then
		v694 = false
	else
		v694 = p693:GetAttribute("SDashF") ~= nil
	end
	return v694
end
local v_u_695 = {}
local v_u_696 = false
function v_u_8.BindStep(p_u_697, p_u_698) -- name: BindStep
	-- upvalues: (copy) v_u_695, (copy) v_u_2, (copy) v_u_28, (ref) v_u_696
	local v_u_699 = {
		["fn"] = nil,
		["priority"] = nil,
		["calls"] = 0,
		["fallback"] = false,
		["fn"] = p_u_697,
		["priority"] = p_u_698
	}
	local v700 = v_u_695
	table.insert(v700, v_u_699)
	table.sort(v_u_695, function(p701, p702)
		return p701.priority < p702.priority
	end)
	local function v705()
		-- upvalues: (ref) v_u_2, (copy) v_u_699, (copy) p_u_697, (copy) p_u_698
		v_u_2:BindToSimulation(function(p703)
			-- upvalues: (ref) v_u_699, (ref) p_u_697
			local v704 = v_u_699
			v704.calls = v704.calls + 1
			v_u_699.fallback = false
			p_u_697(p703)
		end, Enum.StepFrequency.Hz60, p_u_698)
	end
	local v_u_706, v_u_707 = pcall(v705)
	if not v_u_706 or v_u_28 then
		task.delay(v_u_706 and 1.5 or 0, function()
			-- upvalues: (copy) v_u_699, (ref) v_u_696, (ref) v_u_2, (ref) v_u_695, (copy) p_u_698, (copy) v_u_706, (copy) v_u_707
			if v_u_699.calls == 0 then
				v_u_699.fallback = true
				if not v_u_696 then
					v_u_696 = true
					local v_u_708 = 0
					v_u_2.PreSimulation:Connect(function(p709)
						-- upvalues: (ref) v_u_708, (ref) v_u_695
						local v710 = v_u_708 + p709
						v_u_708 = math.min(v710, 0.06666666666666667)
						while v_u_708 >= 0.016666666666666666 do
							v_u_708 = v_u_708 - 0.016666666666666666
							for _, v711 in v_u_695 do
								if not v711.fallback then
									continue
								end
								v711.fn(0.016666666666666666)
							end
						end
					end)
				end
				if v_u_2:IsStudio() then
					local v712 = warn
					local v713 = "[Simulation] BindToSimulation isn\'t running the priority-%* step (%*): stepping it from PreSimulation at 60 Hz"
					local v714 = p_u_698
					local v715
					if v_u_706 then
						v715 = "never called"
					else
						local v716 = v_u_707
						v715 = tostring(v716)
					end
					v712((v713:format(v714, v715)))
				end
			end
		end)
	end
end
function v_u_8.StepSource() -- name: StepSource
	-- upvalues: (copy) v_u_695
	local v717 = false
	local v718 = false
	for _, v719 in v_u_695 do
		v717 = v717 or v719.calls > 0
		v718 = v718 or v719.fallback
	end
	return v718 and "fallback" or (v717 and "engine" or "waiting")
end
local function v_u_733(p_u_720, p_u_721, p722) -- name: predictionOff
	-- upvalues: (copy) v_u_2
	local v_u_723 = p722 or Enum.PredictionMode.Off
	local function v726(p_u_724) -- name: off
		-- upvalues: (ref) v_u_2, (copy) v_u_723
		if p_u_724:IsA("BasePart") then
			local function v725()
				-- upvalues: (ref) v_u_2, (copy) p_u_724, (ref) v_u_723
				v_u_2:SetPredictionMode(p_u_724, v_u_723)
			end
			pcall(v725)
		end
	end
	local v_u_727 = {}
	for _, v_u_728 in p_u_720:GetDescendants() do
		if not v_u_728:IsA("BasePart") then
			continue
		end
		local function v729()
			-- upvalues: (ref) v_u_2, (copy) v_u_728, (copy) v_u_723
			v_u_2:SetPredictionMode(v_u_728, v_u_723)
		end
		pcall(v729)
	end
	local v730 = p_u_720.DescendantAdded
	table.insert(v_u_727, v730:Connect(v726))
	local v731 = p_u_720.AncestryChanged
	table.insert(v_u_727, v731:Connect(function()
		-- upvalues: (copy) p_u_720, (copy) v_u_727, (copy) p_u_721
		if not p_u_720:IsDescendantOf(game) then
			for _, v732 in v_u_727 do
				v732:Disconnect()
			end
			p_u_721()
		end
	end))
end
local function v_u_756(p_u_734, p_u_735) -- name: startRemoteCollisionGuard
	-- upvalues: (copy) v_u_2, (copy) v_u_8
	local v_u_736 = 0
	local v_u_737 = nil
	local v_u_738 = {}
	local v_u_739 = 0.25
	v_u_2.Heartbeat:Connect(function(p740)
		-- upvalues: (ref) v_u_739, (copy) p_u_734, (ref) v_u_737, (copy) p_u_735, (ref) v_u_738
		v_u_739 = v_u_739 + p740
		if v_u_739 >= 0.25 then
			v_u_739 = 0
			local v741 = p_u_734.Character
			local v742
			if v741 then
				v742 = v741:FindFirstChild("HumanoidRootPart")
			else
				v742 = v741
			end
			if not (v742 and v742:IsA("BasePart")) then
				v742 = nil
			end
			v_u_737 = v742
			local v743 = {}
			if v_u_737 then
				local v744 = v_u_737.Position
				for v745 in p_u_735 do
					local v746 = v745:FindFirstChild("HumanoidRootPart")
					if v745 == v741 or (not v746 or (not v746:IsA("BasePart") or (v746.Position - v744).Magnitude > 70)) then
						continue
					end
					local v747 = v745:FindFirstChildOfClass("Humanoid")
					if not v747 or (v747.Health <= 0 or not v746:FindFirstChild("TribesHull")) then
						continue
					end
					local v748 = {}
					for _, v749 in v745:GetChildren() do
						if not v749:IsA("BasePart") then
							continue
						end
						table.insert(v748, v749)
					end
					table.insert(v743, {
						["root"] = v746,
						["parts"] = v748
					})
				end
			end
			v_u_738 = v743
		end
	end)
	v_u_8.BindStep(function()
		-- upvalues: (ref) v_u_737, (ref) v_u_738, (ref) v_u_736
		local v750 = v_u_737
		if v750 then
			local v751 = v750.Position
			for _, v752 in v_u_738 do
				if (v752.root.Position - v751).Magnitude > 40 then
					continue
				end
				local v753 = v752.parts
				for v754 = 1, #v753 do
					local v755 = v753[v754]
					if not v755.CanCollide then
						continue
					end
					v755.CanCollide = false
					v_u_736 = v_u_736 + 1
				end
			end
		end
	end, 1)
	function v_u_8.RemoteCollisionFixes()
		-- upvalues: (ref) v_u_736
		return v_u_736
	end
end
local function v_u_775(p_u_757) -- name: startPredictionPolicy
	-- upvalues: (copy) v_u_733, (copy) v_u_2, (copy) v_u_1, (copy) v_u_756
	local v758 = game:GetService("CollectionService")
	local v_u_759 = setmetatable({}, {
		["__mode"] = "k"
	})
	local function v_u_762(p_u_760, p761) -- name: apply
		-- upvalues: (copy) v_u_759, (ref) v_u_733
		if p_u_760:IsA("Model") and not v_u_759[p_u_760] then
			v_u_759[p_u_760] = true
			v_u_733(p_u_760, function()
				-- upvalues: (ref) v_u_759, (copy) p_u_760
				v_u_759[p_u_760] = nil
			end, p761)
		end
	end
	local v_u_763 = nil
	if v_u_2:IsStudio() then
		local v764 = workspace:GetAttribute("BotPredictionMode")
		if v764 == "On" then
			v_u_763 = Enum.PredictionMode.On
		elseif v764 == "Automatic" then
			v_u_763 = Enum.PredictionMode.Automatic
		end
	end
	local function v767(p_u_765) -- name: applyTagged
		-- upvalues: (ref) v_u_1, (ref) v_u_763, (copy) v_u_759, (ref) v_u_733
		if p_u_765:IsA("Model") and v_u_1:GetPlayerFromCharacter(p_u_765) == nil then
			local v766 = v_u_763
			if p_u_765:IsA("Model") and not v_u_759[p_u_765] then
				v_u_759[p_u_765] = true
				v_u_733(p_u_765, function()
					-- upvalues: (ref) v_u_759, (copy) p_u_765
					v_u_759[p_u_765] = nil
				end, v766)
			end
		end
	end
	for _, v768 in { "Combatant", "Bot" } do
		v758:GetInstanceAddedSignal(v768):Connect(v767)
		for _, v_u_769 in v758:GetTagged(v768) do
			if not v_u_769:IsA("Model") or v_u_1:GetPlayerFromCharacter(v_u_769) ~= nil then
				continue
			end
			if not v_u_769:IsA("Model") or v_u_759[v_u_769] then
				continue
			end
			v_u_759[v_u_769] = true
			v_u_733(v_u_769, function()
				-- upvalues: (copy) v_u_759, (copy) v_u_769
				v_u_759[v_u_769] = nil
			end, v_u_763)
		end
	end
	local function v772(p770) -- name: watchPlayer
		-- upvalues: (copy) p_u_757, (copy) v_u_762, (copy) v_u_759, (ref) v_u_733
		if p770 ~= p_u_757 then
			p770.CharacterAdded:Connect(v_u_762)
			if p770.Character then
				local v_u_771 = p770.Character
				if v_u_771:IsA("Model") and not v_u_759[v_u_771] then
					v_u_759[v_u_771] = true
					v_u_733(v_u_771, function()
						-- upvalues: (ref) v_u_759, (copy) v_u_771
						v_u_759[v_u_771] = nil
					end, nil)
				end
			end
		end
	end
	v_u_1.PlayerAdded:Connect(v772)
	for _, v773 in v_u_1:GetPlayers() do
		if v773 == p_u_757 then
			continue
		end
		v773.CharacterAdded:Connect(v_u_762)
		if not v773.Character then
			continue
		end
		local v_u_774 = v773.Character
		if not v_u_774:IsA("Model") or v_u_759[v_u_774] then
			continue
		end
		v_u_759[v_u_774] = true
		v_u_733(v_u_774, function()
			-- upvalues: (copy) v_u_759, (copy) v_u_774
			v_u_759[v_u_774] = nil
		end, nil)
	end
	if not v_u_2:IsStudio() or workspace:GetAttribute("RemoteCollideGuardOff") ~= true then
		v_u_756(p_u_757, v_u_759)
	end
end
local function v_u_795(p_u_776) -- name: startArrivalGuard
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_8
	local v_u_777 = RaycastParams.new()
	v_u_777.FilterType = Enum.RaycastFilterType.Exclude
	v_u_777.RespectCanCollide = true
	v_u_777.IgnoreWater = true
	local v_u_778 = nil
	local v_u_779 = nil
	local v_u_780 = false
	local v_u_781 = 0
	local v_u_782 = nil
	local v_u_783 = 0
	local v_u_784 = 0
	v_u_2.PreSimulation:Connect(function(p785)
		-- upvalues: (copy) p_u_776, (ref) v_u_778, (ref) v_u_779, (ref) v_u_780, (ref) v_u_782, (ref) v_u_781, (copy) v_u_777, (ref) v_u_3, (ref) v_u_783, (ref) v_u_784
		local v786 = p_u_776.Character
		local v787
		if v786 then
			v787 = v786:FindFirstChild("HumanoidRootPart")
		else
			v787 = v786
		end
		if v786 and (v787 and v787:IsA("BasePart")) then
			local v788 = v787.Position
			local v789 = v787 ~= v_u_778
			if not v789 and v_u_779 then
				v789 = (v788 - v_u_779 - v787.AssemblyLinearVelocity * p785).Magnitude > 20
			end
			if v789 then
				if v_u_782 and v_u_782 ~= v787 then
					v_u_782 = nil
				end
				v_u_780 = true
				v_u_781 = 0
			end
			v_u_778 = v787
			v_u_779 = v788
			if v_u_780 then
				v_u_781 = v_u_781 + p785
				local v790 = v786:FindFirstChildOfClass("Humanoid")
				if v790 and v790.Health > 0 then
					v_u_777.FilterDescendantsInstances = { v786 }
					local v791 = v_u_3:Raycast(v788, Vector3.new(0, -80, 0), v_u_777)
					local v792
					if v791 == nil then
						v792 = false
					else
						v792 = v788.Y - v791.Position.Y <= 12
					end
					if v792 or v791 ~= nil and v_u_781 >= 6 or v_u_781 >= 12 then
						v_u_780 = false
						local v793 = v_u_782
						v_u_782 = nil
						if v793 and (v793.Parent and v793.Anchored) then
							v793.Anchored = false
							return
						end
					else
						if not v787.Anchored then
							v787.Anchored = true
							v_u_782 = v787
							v_u_783 = v_u_783 + 1
						end
						if v_u_782 == v787 then
							v_u_784 = v_u_784 + p785
						end
					end
				else
					v_u_780 = false
					local v794 = v_u_782
					v_u_782 = nil
					if v794 and (v794.Parent and v794.Anchored) then
						v794.Anchored = false
					end
				end
			else
				return
			end
		else
			v_u_778 = nil
			v_u_779 = nil
			v_u_780 = false
			v_u_782 = nil
			return
		end
	end)
	function v_u_8.ArrivalHolds()
		-- upvalues: (ref) v_u_783, (ref) v_u_784
		return v_u_783, v_u_784
	end
end
local v_u_796 = false
function v_u_8.Initialize() -- name: Initialize
	-- upvalues: (ref) v_u_796, (copy) v_u_23, (copy) v_u_1, (copy) v_u_638, (copy) v_u_33, (copy) v_u_34, (copy) v_u_2, (copy) v_u_22, (copy) v_u_8, (copy) v_u_5, (copy) v_u_647, (copy) v_u_653, (copy) v_u_775, (copy) v_u_690, (copy) v_u_28, (copy) v_u_795, (copy) v_u_6, (copy) v_u_553
	if v_u_796 then
		return
	else
		v_u_796 = true
		if v_u_23 then
			for _, v797 in v_u_1:GetPlayers() do
				v_u_638(v797)
			end
			v_u_1.PlayerAdded:Connect(v_u_638)
			v_u_1.PlayerRemoving:Connect(function(p798)
				-- upvalues: (ref) v_u_33, (ref) v_u_34
				if p798.Character then
					local v799 = p798.Character
					local v800 = v_u_33[v799]
					if not v800 then
						return
					end
					v_u_33[v799] = nil
					for _, v801 in v800.conns do
						v801:Disconnect()
					end
					table.clear(v_u_34)
					for _, v802 in v_u_33 do
						local v803 = v_u_34
						table.insert(v803, v802)
					end
				end
			end)
			if v_u_2:IsStudio() then
				local v804 = Instance.new("BindableFunction")
				v804.Name = "SimulationDebug"
				function v804.OnInvoke(p805, p806, p807)
					-- upvalues: (ref) v_u_33, (ref) v_u_22, (ref) v_u_8, (ref) v_u_34
					local v808 = p806 and p806.Character
					if v808 then
						v808 = v_u_33[p806.Character]
					end
					if p805 == "state" and v808 then
						local v809 = {}
						for _, v810 in v_u_22 do
							v809[v810] = v808.root:GetAttribute(v810)
						end
						v809.walkSpeed = v808.humanoid.WalkSpeed
						v809.jumpHeight = v808.humanoid.JumpHeight
						return v809
					elseif p805 == "knockback" and v808 then
						return v_u_8.Knockback(v808.character, p807)
					elseif p805 == "teleport" and v808 then
						return v_u_8.Teleport(v808.character, p807)
					elseif p805 == "count" then
						return #v_u_34
					elseif p805 == "perf" then
						return v_u_8.DebugStats()
					else
						return nil
					end
				end
				v804.Parent = game:GetService("ServerStorage")
			end
		else
			local v_u_811 = v_u_1.LocalPlayer
			task.spawn(function()
				-- upvalues: (copy) v_u_811, (ref) v_u_5, (ref) v_u_647, (ref) v_u_653
				local v812 = v_u_811:WaitForChild(v_u_5.CONTEXT, 60)
				if v812 then
					for _, v813 in v_u_5.ACTIONS do
						local v814 = v812:WaitForChild(v813.name, 10)
						if v814 then
							v814 = v814:WaitForChild("Script", 10)
						end
						if not (v814 and v814:IsA("InputBinding")) then
							continue
						end
						v_u_647[v813.name] = v814
						v_u_653(v813.name)
					end
				else
					warn("[Simulation] TribesInputs never arrived")
				end
			end)
			v_u_638(v_u_811)
			v_u_775(v_u_811)
			v_u_690(v_u_811)
			if v_u_28 then
				v_u_795(v_u_811)
			end
			if v_u_2:IsStudio() and not v_u_28 then
				v_u_6.Start(v_u_811)
			end
		end
		if v_u_2:IsStudio() and workspace:GetAttribute("SimDisabled") == true then
			warn("[Simulation] disabled by the Studio test knob workspace.SimDisabled (engine-only baseline)")
		else
			v_u_8.BindStep(v_u_553, 2100)
		end
	end
end
return v_u_8