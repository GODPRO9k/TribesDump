local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("UserInputService")
local v5 = v2:WaitForChild("Shared")
local v_u_6 = require(v5:WaitForChild("Camera"))
local v_u_7 = require(v5:WaitForChild("Simulation"))
local v_u_8 = require(script.Parent:WaitForChild("Effects"))
local v_u_9 = require(script.Parent:WaitForChild("Footsteps"))
local v_u_10 = require(script.Parent:WaitForChild("Perf"))
local v_u_11 = require(script.Parent:WaitForChild("AnimationIds"))
local v_u_12 = {}
local v_u_13 = v_u_7.BASE_SPEED
local v_u_14 = v1.LocalPlayer
local v_u_15 = nil
local v_u_16 = {
	["fov"] = 0
}
local v_u_17 = false
local v_u_18 = {
	["fov"] = 8,
	["pivot"] = Vector3.new(0, -1.2, 0)
}
function v_u_12.IsSliding() -- name: IsSliding
	-- upvalues: (ref) v_u_15
	local v19
	if v_u_15 == nil then
		v19 = false
	else
		v19 = v_u_15.sliding
	end
	return v19
end
function v_u_12.BaseSpeed() -- name: BaseSpeed
	-- upvalues: (copy) v_u_13
	return v_u_13
end
local function v_u_38(p20) -- name: renderSlideStart
	-- upvalues: (copy) v_u_6, (copy) v_u_18, (copy) v_u_8
	p20.sliding = true
	p20.slideAirborne = false
	p20.character:SetAttribute("Sliding", true)
	v_u_6.SuspendCharacterRotation("Slide")
	v_u_6.SetModifier("Slide", v_u_18)
	v_u_6.Shake(0.1, 0.2)
	if p20.legsTrack then
		local v21 = p20.legsTrack
		local v22
		if v21 == nil then
			v22 = false
		else
			v22 = v21.IsPlaying
		end
		if not v22 then
			p20.legsTrack:Play(0.08, 1, 1)
		end
	end
	if p20.upperTrack then
		local v23 = p20.upperTrack
		local v24
		if v23 == nil then
			v24 = false
		else
			v24 = v23.IsPlaying
		end
		if not v24 then
			p20.upperTrack:Play(0.12, 1, 1)
		end
	end
	if not p20.slideSound then
		local v25 = v_u_8.PlaySound
		local v26 = "Slide"
		local v27 = v_u_6.Drawn
		local v28 = p20.root
		local v29, v30 = pcall(v27, v28)
		if not v29 or (typeof(v30) ~= "Instance" or not v30:IsA("BasePart")) then
			v30 = p20.root
		end
		p20.slideSound = v25(v26, v30, {
			["pitchVar"] = 0.08,
			["looped"] = true,
			["volume"] = 1.2
		})
	end
	local v31 = v_u_8.DustColor(p20.humanoid.FloorMaterial)
	local v32 = v_u_8.Dust
	local v33 = v_u_6.Drawn
	local v34 = p20.root
	local v35, v36 = pcall(v33, v34)
	if not v35 or (typeof(v36) ~= "Instance" or not v36:IsA("BasePart")) then
		v36 = p20.root
	end
	v32(v36.Position - Vector3.new(0, 2.6, 0), 1.1, v31)
	if p20.trailAttachment then
		if not (p20.slideTrail and p20.slideTrail.Parent) then
			p20.slideTrail = v_u_8.Trail(p20.trailAttachment, v31)
		end
		local v37 = p20.slideTrail
		v37.Color = ColorSequence.new(v31)
		v37.Enabled = true
	end
end
local function v_u_42(p39) -- name: renderSlideEnd
	-- upvalues: (copy) v_u_6
	p39.sliding = false
	if p39.character.Parent then
		p39.character:SetAttribute("Sliding", false)
	end
	if p39.legsTrack then
		p39.legsTrack:Stop(0.15)
	end
	if p39.upperTrack then
		p39.upperTrack:Stop(0.15)
	end
	if p39.slideTrail then
		p39.slideTrail.Enabled = false
	end
	local v_u_40 = p39.slideSound
	if v_u_40 then
		p39.slideSound = nil
		task.spawn(function()
			-- upvalues: (copy) v_u_40
			for _ = 1, 8 do
				if not v_u_40.Parent then
					break
				end
				local v41 = v_u_40
				v41.Volume = v41.Volume * 0.7
				task.wait(0.02)
			end
			v_u_40:Destroy()
		end)
	end
	v_u_6.SetModifier("Slide", nil)
	v_u_6.ResumeCharacterRotation("Slide")
end
local function v_u_52(p43) -- name: feetOf
	-- upvalues: (copy) v_u_6
	local v44 = p43.humanoid.HipHeight
	local v45 = p43.root:GetAttribute("SHipBase")
	if type(v45) == "number" then
		if v45 >= v44 then
			v45 = v44
		end
	else
		v45 = v44
	end
	local v46 = v_u_6.Drawn
	local v47 = p43.root
	local v48, v49 = pcall(v46, v47)
	if not v48 or (typeof(v49) ~= "Instance" or not v49:IsA("BasePart")) then
		v49 = p43.root
	end
	local v50 = v49.Position
	local v51 = v45 + p43.root.Size.Y / 2 - 0.2
	return v50 - Vector3.new(0, v51, 0)
end
local v_u_53 = RaycastParams.new()
v_u_53.FilterType = Enum.RaycastFilterType.Include
v_u_53.FilterDescendantsInstances = { workspace.Terrain }
v_u_53.IgnoreWater = false
local function v_u_58(p54) -- name: waterSplashAt
	-- upvalues: (copy) v_u_53
	local v55 = p54.root:GetAttribute("SWade")
	if type(v55) == "number" and v55 >= 0.3 then
		local v56 = p54.root.Position
		local v57 = workspace:Raycast(v56 + Vector3.new(0, 4, 0), Vector3.new(0, -12, 0), v_u_53)
		if v57 and v57.Material == Enum.Material.Water then
			return v57.Position
		else
			return nil
		end
	else
		return nil
	end
end
local function v_u_68(p59) -- name: onJumped
	-- upvalues: (copy) v_u_8, (copy) v_u_6, (copy) v_u_58, (copy) v_u_52
	local v60 = os.clock()
	if v60 - p59.lastJumpFx < 0.4 then
		return
	else
		p59.airStart = v60
		p59.minVy = 0
		p59.lastJumpFx = v60
		local v61 = v_u_8.PlaySound
		local v62 = "Jump"
		local v63 = v_u_6.Drawn
		local v64 = p59.root
		local v65, v66 = pcall(v63, v64)
		if not v65 or (typeof(v66) ~= "Instance" or not v66:IsA("BasePart")) then
			v66 = p59.root
		end
		v61(v62, v66, {
			["pitchVar"] = 0.08,
			["volume"] = 0.8
		})
		local v67 = v_u_58(p59)
		if v67 then
			v_u_8.Dust(v67, 0.55, v_u_8.DustColor(Enum.Material.Water))
		else
			v_u_8.Dust(v_u_52(p59), 0.4, v_u_8.DustColor(p59.humanoid.FloorMaterial))
		end
	end
end
local function v_u_82(p69) -- name: onLanded
	-- upvalues: (copy) v_u_58, (copy) v_u_8, (copy) v_u_6, (copy) v_u_52, (copy) v_u_9
	local v70 = -p69.minVy
	p69.minVy = 0
	local v71 = os.clock()
	local v72 = v71 - p69.airStart
	if v70 < 18 or (v72 < 0.12 or v71 - p69.lastLandFx < 0.4) then
		return
	else
		p69.lastLandFx = v71
		local v73 = p69.humanoid.FloorMaterial
		local v74 = (v70 - 70) / 60
		local v75 = math.clamp(v74, 0, 1)
		local v76 = v_u_58(p69)
		if v76 then
			v_u_8.Dust(v76, v75 * 1.2 + 0.6, v_u_8.DustColor(Enum.Material.Water))
			return
		else
			v_u_6.Dip(v75 * 1.2 + 0.12)
			if v75 > 0.6 then
				v_u_6.Shake(v75 * 0.3 + 0.15, 0.3)
			end
			v_u_8.Dust(v_u_52(p69), v75 * 1.8 + 0.45, v_u_8.DustColor(v73))
			local v77 = v_u_6.Drawn
			local v78 = p69.root
			local v79, v80 = pcall(v77, v78)
			if not v79 or (typeof(v80) ~= "Instance" or not v80:IsA("BasePart")) then
				v80 = p69.root
			end
			if v75 <= 0 then
				local v81 = v_u_9.SurfaceFor(v73)
				v_u_8.PlaySound(v_u_9.StepSoundName(v81), v80, {
					["volume"] = 0.8,
					["pitchVar"] = 0.08
				})
				return
			elseif v75 < 0.5 then
				v_u_8.PlaySound("Land", v80, {
					["volume"] = nil,
					["pitchVar"] = 0.06,
					["volume"] = v75 * 0.9 + 0.35
				})
			else
				v_u_8.PlaySound("LandHeavy", v80, {
					["volume"] = nil,
					["pitchVar"] = 0.05,
					["volume"] = v75 * 0.5 + 0.5
				})
			end
		end
	end
end
local function v_u_107() -- name: render
	-- upvalues: (ref) v_u_15, (copy) v_u_6, (copy) v_u_38, (copy) v_u_42, (copy) v_u_8, (copy) v_u_52, (ref) v_u_17, (copy) v_u_13, (copy) v_u_16
	local v83 = v_u_15
	if v83 then
		local v84 = v83.humanoid
		local v85 = v83.root
		local v86
		if v84.Parent == nil then
			v86 = false
		else
			v86 = v84.Health > 0
		end
		local v_u_87 = v83.trailAttachment
		if v_u_87 then
			local v88 = v_u_6.Drawn
			local v89 = v83.root
			local v90, v_u_91 = pcall(v88, v89)
			if not v90 or (typeof(v_u_91) ~= "Instance" or not v_u_91:IsA("BasePart")) then
				v_u_91 = v83.root
			end
			if v_u_87.Parent ~= v_u_91 and not pcall(function()
				-- upvalues: (copy) v_u_87, (copy) v_u_91
				v_u_87.Parent = v_u_91
			end) then
				local v92 = Instance.new("Attachment")
				v92.Name = "TribesSlideTrail"
				v92.Position = Vector3.new(0, -2.3, 1)
				v92.Parent = v_u_91
				v83.trailAttachment = v92
				v83.slideTrail = nil
			end
		end
		local v93
		if v86 then
			v93 = v85:GetAttribute("SSlide") ~= nil
		else
			v93 = v86
		end
		if v93 == v83.sliding then
			if v93 then
				if v83.legsTrack then
					local v94 = v83.legsTrack
					local v95
					if v94 == nil then
						v95 = false
					else
						v95 = v94.IsPlaying
					end
					if not v95 then
						v83.legsTrack:Play(0.05, 1, 1)
					end
				end
				if v83.upperTrack then
					local v96 = v83.upperTrack
					local v97
					if v96 == nil then
						v97 = false
					else
						v97 = v96.IsPlaying
					end
					if not v97 then
						v83.upperTrack:Play(0.05, 1, 1)
					end
				end
				local v98 = v84.FloorMaterial == Enum.Material.Air
				if v98 ~= v83.slideAirborne then
					v83.slideAirborne = v98
					local v99 = os.clock()
					if v98 then
						v83.slideAirAt = v99
					elseif v99 - v83.slideAirAt > 0.08 then
						v_u_8.Dust(v_u_52(v83), 0.5, v_u_8.DustColor(v84.FloorMaterial))
					end
					if v83.slideTrail then
						v83.slideTrail.Enabled = not v98
					end
				end
			end
		elseif v93 then
			v_u_38(v83)
		else
			v_u_42(v83)
		end
		if v86 then
			local v100 = v85.AssemblyLinearVelocity
			if v84.FloorMaterial == Enum.Material.Air then
				local v101 = v83.minVy
				local v102 = v100.Y
				v83.minVy = math.min(v101, v102)
			end
			if v93 or v_u_6.IsAiming() then
				if v_u_17 then
					v_u_17 = false
					v_u_6.SetModifier("Speed", nil)
					return
				end
			else
				local v103 = v100.X
				local v104 = v100.Z
				local v105 = (Vector3.new(v103, 0, v104).Magnitude - v_u_13 - 1) * 0.45
				local v106 = math.clamp(v105, 0, 7)
				if v106 > 0.05 then
					v_u_16.fov = v106
					if not v_u_17 then
						v_u_17 = true
						v_u_6.SetModifier("Speed", v_u_16)
						return
					end
				elseif v_u_17 then
					v_u_17 = false
					v_u_6.SetModifier("Speed", nil)
				end
			end
		elseif v_u_17 then
			v_u_17 = false
			v_u_6.SetModifier("Speed", nil)
		end
	else
		return
	end
end
local function v_u_115(p_u_108, p109, p110, p111) -- name: loadTrack
	if p109 == "" or p109 == "rbxassetid://0" then
		return nil
	end
	local v_u_112 = Instance.new("Animation")
	v_u_112.Name = p111
	v_u_112.AnimationId = p109
	local v113, v114 = pcall(function()
		-- upvalues: (copy) p_u_108, (copy) v_u_112
		return p_u_108:LoadAnimation(v_u_112)
	end)
	if not (v113 and v114) then
		return nil
	end
	v114.Priority = p110
	v114.Looped = true
	return v114
end
local function v_u_118() -- name: unbind
	-- upvalues: (ref) v_u_15, (copy) v_u_42, (ref) v_u_17, (copy) v_u_6
	local v116 = v_u_15
	if v116 then
		if v116.sliding then
			v_u_42(v116)
		end
		if v_u_17 then
			v_u_17 = false
			v_u_6.SetModifier("Speed", nil)
		end
		for _, v117 in v116.connections do
			v117:Disconnect()
		end
		if v116.trailAttachment then
			v116.trailAttachment:Destroy()
		end
		v_u_15 = nil
	end
end
local function v_u_135(p119) -- name: bindCharacter
	-- upvalues: (copy) v_u_118, (copy) v_u_14, (copy) v_u_115, (copy) v_u_11, (ref) v_u_15, (copy) v_u_3, (copy) v_u_68, (copy) v_u_82, (copy) v_u_42, (ref) v_u_17, (copy) v_u_6
	v_u_118()
	local v120 = p119:WaitForChild("Humanoid", 10)
	local v121 = p119:WaitForChild("HumanoidRootPart", 10)
	if v120 and (v121 and v_u_14.Character == p119) then
		local v122 = Instance.new("Attachment")
		v122.Name = "TribesSlideTrail"
		v122.Position = Vector3.new(0, -2.3, 1)
		local v123 = v120:FindFirstChildOfClass("Animator") or v120:WaitForChild("Animator", 5)
		local v124, v125
		if v123 and v123:IsA("Animator") then
			v124 = v_u_115(v123, v_u_11.SlideLegs, Enum.AnimationPriority.Action2, "SlideLegs")
			v125 = v_u_115(v123, v_u_11.SlideUpper, Enum.AnimationPriority.Movement, "SlideUpper")
			if not v124 then
				v124 = v_u_115(v123, v_u_11.SlideFallback, Enum.AnimationPriority.Movement, "SlideFallback")
			end
		else
			v124 = nil
			v125 = nil
		end
		local v_u_126 = {
			["character"] = nil,
			["humanoid"] = nil,
			["root"] = nil,
			["sliding"] = false,
			["legsTrack"] = nil,
			["upperTrack"] = nil,
			["slideSound"] = nil,
			["slideTrail"] = nil,
			["trailAttachment"] = nil,
			["slideAirborne"] = false,
			["slideAirAt"] = 0,
			["minVy"] = 0,
			["airStart"] = nil,
			["lastJumpFx"] = 0,
			["lastLandFx"] = 0,
			["connections"] = nil,
			["character"] = p119,
			["humanoid"] = v120,
			["root"] = v121,
			["legsTrack"] = v124,
			["upperTrack"] = v125,
			["trailAttachment"] = v122,
			["airStart"] = os.clock(),
			["connections"] = {}
		}
		v_u_15 = v_u_126
		p119:SetAttribute("Sliding", false)
		local v127 = v_u_126.connections
		local v128 = v120.StateChanged
		local function v131(p129, p130)
			-- upvalues: (ref) v_u_3, (ref) v_u_68, (copy) v_u_126, (ref) v_u_82
			if v_u_3:IsResimulating() then
				return
			elseif p130 == Enum.HumanoidStateType.Jumping then
				v_u_68(v_u_126)
			elseif p130 == Enum.HumanoidStateType.Freefall then
				if p129 ~= Enum.HumanoidStateType.Jumping and os.clock() - v_u_126.lastJumpFx >= 0.4 then
					v_u_126.airStart = os.clock()
					v_u_126.minVy = 0
					return
				end
			elseif p130 == Enum.HumanoidStateType.Landed then
				v_u_82(v_u_126)
			end
		end
		table.insert(v127, v128:Connect(v131))
		local v132 = v_u_126.connections
		local v133 = v120.Died
		local function v134()
			-- upvalues: (copy) v_u_126, (ref) v_u_42, (ref) v_u_17, (ref) v_u_6
			if v_u_126.sliding then
				v_u_42(v_u_126)
			end
			if v_u_17 then
				v_u_17 = false
				v_u_6.SetModifier("Speed", nil)
			end
		end
		table.insert(v132, v133:Connect(v134))
	end
end
function v_u_12.SetSlideHeld(p136) -- name: SetSlideHeld
	-- upvalues: (copy) v_u_7
	v_u_7.SetInput("Slide", p136 == true)
end
function v_u_12.RequestSlide() -- name: RequestSlide
	-- upvalues: (copy) v_u_7
	v_u_7.Pulse("Slide", 0.1)
end
function v_u_12.SetJumpHeld(p137) -- name: SetJumpHeld
	-- upvalues: (copy) v_u_7
	v_u_7.SetInput("Jump", p137 == true)
end
local v_u_138 = false
function v_u_12.Start() -- name: Start
	-- upvalues: (ref) v_u_138, (copy) v_u_4, (copy) v_u_7, (copy) v_u_14, (copy) v_u_135, (ref) v_u_15, (copy) v_u_118, (copy) v_u_3, (copy) v_u_12, (copy) v_u_10, (copy) v_u_107
	if not v_u_138 then
		v_u_138 = true
		v_u_4.WindowFocusReleased:Connect(function()
			-- upvalues: (ref) v_u_7
			v_u_7.SetInput("Slide", false)
			v_u_7.SetInput("Jump", false)
		end)
		if v_u_14.Character then
			task.spawn(v_u_135, v_u_14.Character)
		end
		v_u_14.CharacterAdded:Connect(v_u_135)
		v_u_14.CharacterRemoving:Connect(function(p139)
			-- upvalues: (ref) v_u_15, (ref) v_u_118
			if v_u_15 and v_u_15.character == p139 then
				v_u_118()
			end
		end)
		if v_u_3:IsStudio() then
			local v140 = Instance.new("BindableFunction")
			v140.Name = "CharacterDebug"
			function v140.OnInvoke(p141, _)
				-- upvalues: (ref) v_u_7, (ref) v_u_12, (ref) v_u_15
				if p141 == "jump" then
					v_u_7.Pulse("Jump", 0.05)
					return true
				end
				if p141 == "slide" then
					v_u_12.RequestSlide()
					return true
				end
				if p141 == "simperf" then
					return v_u_7.DebugStats()
				end
				if p141 ~= "state" then
					return nil
				end
				local v142 = v_u_15
				if not v142 then
					return nil
				end
				local v143 = {
					["walkSpeed"] = v142.humanoid.WalkSpeed,
					["jumpHeight"] = v142.humanoid.JumpHeight,
					["hipHeight"] = v142.humanoid.HipHeight,
					["rendered"] = v142.sliding
				}
				for v144, v145 in v142.root:GetAttributes() do
					if string.sub(v144, 1, 1) ~= "S" then
						continue
					end
					v143[v144] = v145
				end
				return v143
			end
			v140.Parent = v_u_14
		end
		v_u_3.RenderStepped:Connect(function()
			-- upvalues: (ref) v_u_10, (ref) v_u_107
			local v146 = v_u_10.Begin()
			v_u_107()
			v_u_10.End("Movement", v146)
		end)
	end
end
return v_u_12