local v1 = game:GetService("Players")
local v_u_2 = game:GetService("StarterGui")
local v3 = {}
local v_u_4 = v1.LocalPlayer
local v_u_5 = 0
local function v_u_9() -- name: apply
	-- upvalues: (ref) v_u_5, (copy) v_u_4, (copy) v_u_2
	v_u_5 = v_u_5 + 1
	local v6 = v_u_5
	local v_u_7 = v_u_4:GetAttribute("State") ~= "Match"
	for _ = 1, 40 do
		if v6 ~= v_u_5 then
			return
		end
		local function v8()
			-- upvalues: (ref) v_u_2, (copy) v_u_7
			v_u_2:SetCore("ResetButtonCallback", v_u_7)
		end
		if pcall(v8) then
			return
		end
		task.wait(0.5)
	end
end
local v_u_10 = false
function v3.Start() -- name: Start
	-- upvalues: (ref) v_u_10, (copy) v_u_4, (copy) v_u_9
	if not v_u_10 then
		v_u_10 = true
		v_u_4:GetAttributeChangedSignal("State"):Connect(function()
			-- upvalues: (ref) v_u_9
			task.spawn(v_u_9)
		end)
		task.spawn(v_u_9)
	end
end
return v3