game:GetService("CollectionService")
local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v3 = require(script.Parent.Parent:WaitForChild("Signal"))
local v_u_4 = require(script.Parent:WaitForChild("Fighters"))
local v_u_5 = {}
local v_u_6 = v_u_1.LocalPlayer
local v_u_7 = "none"
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = ""
local v_u_12 = 0
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = (-1 / 0)
local v_u_16 = nil
local v_u_17 = 0
local v_u_18 = false
v_u_5.Changed = v3.new()
function v_u_5.ResolveCombatant(p_u_19) -- name: ResolveCombatant
	-- upvalues: (copy) v_u_1, (copy) v_u_4
	if type(p_u_19) ~= "string" or p_u_19 == "" then
		return nil
	end
	if string.sub(p_u_19, 1, 1) == "p" then
		local v20 = string.sub(p_u_19, 2)
		local v21 = tonumber(v20)
		local v22 = v21
		if v22 then
			v22 = v_u_1:GetPlayerByUserId(v21)
		end
		if v22 then
			v22 = v22.Character
		end
		if v22 and v22.Parent then
			return v22
		end
	end
	local v_u_23 = nil
	v_u_4.EachTagged(function(p24)
		-- upvalues: (ref) v_u_23, (copy) p_u_19
		if not v_u_23 and (p24:GetAttribute("CombatantId") == p_u_19 and p24.Parent) then
			v_u_23 = p24
		end
	end)
	return v_u_23
end
local function v_u_50(p_u_25) -- name: candidates
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_4
	local v26 = v_u_6:GetAttribute("Spectating")
	local v27 = (type(v26) ~= "string" or (v26 == "" or v_u_6:GetAttribute("State") == "Match")) and "" or v26
	local v_u_28
	if v27 == "" then
		v_u_28 = v_u_6:GetAttribute("MatchId")
	else
		v_u_28 = v27
	end
	local v_u_29 = v_u_6:GetAttribute("Team")
	local v_u_30 = v27 ~= ""
	local v_u_31 = {}
	if type(v_u_28) ~= "string" or v_u_28 == "" then
		return v_u_31
	end
	for _, v32 in v_u_1:GetPlayers() do
		if v32 == v_u_6 or (v32:GetAttribute("MatchId") ~= v_u_28 or v32:GetAttribute("Alive") == false) or not v_u_30 and v32:GetAttribute("Team") == v_u_29 ~= p_u_25 then
			continue
		end
		local v33 = v32.Character
		if not v33 then
			continue
		end
		local v34 = v33:FindFirstChildOfClass("Humanoid")
		local v35
		if v34 == nil or (v34.Health <= 0 or v33.Parent == nil) then
			v35 = false
		else
			v35 = v33:FindFirstChild("HumanoidRootPart") ~= nil
		end
		if not v35 then
			continue
		end
		table.insert(v_u_31, v33)
	end
	v_u_4.EachTagged(function(p36)
		-- upvalues: (ref) v_u_1, (copy) v_u_28, (copy) v_u_30, (copy) v_u_29, (copy) p_u_25, (copy) v_u_31
		if v_u_1:GetPlayerFromCharacter(p36) == nil and p36:GetAttribute("MatchId") == v_u_28 then
			local v37 = p36:FindFirstChildOfClass("Humanoid")
			local v38
			if v37 == nil or (v37.Health <= 0 or p36.Parent == nil) then
				v38 = false
			else
				v38 = p36:FindFirstChild("HumanoidRootPart") ~= nil
			end
			if v38 and (v_u_30 or p36:GetAttribute("Team") == v_u_29 == p_u_25) then
				local v39 = v_u_31
				table.insert(v39, p36)
			end
		end
	end)
	table.sort(v_u_31, function(p40, p41)
		-- upvalues: (copy) v_u_30, (ref) v_u_1
		if v_u_30 then
			local v42 = p40:GetAttribute("Team")
			if type(v42) ~= "number" then
				v42 = v_u_1:GetPlayerFromCharacter(p40)
				if v42 then
					v42 = v42:GetAttribute("Team")
				end
			end
			local v43 = type(v42) ~= "number" and 0 or v42
			local v44 = p41:GetAttribute("Team")
			if type(v44) ~= "number" then
				v44 = v_u_1:GetPlayerFromCharacter(p41)
				if v44 then
					v44 = v44:GetAttribute("Team")
				end
			end
			local v45 = type(v44) ~= "number" and 0 or v44
			if v43 ~= v45 then
				return v43 < v45
			end
		end
		local v46
		if p40 then
			v46 = p40:GetAttribute("CombatantId")
			if type(v46) ~= "string" then
				local v47 = v_u_1:GetPlayerFromCharacter(p40)
				if v47 then
					v46 = "p" .. v47.UserId
				else
					v46 = p40.Name
				end
			end
		else
			v46 = ""
		end
		local v48
		if p41 then
			v48 = p41:GetAttribute("CombatantId")
			if type(v48) ~= "string" then
				local v49 = v_u_1:GetPlayerFromCharacter(p41)
				if v49 then
					v48 = "p" .. v49.UserId
				else
					v48 = p41.Name
				end
			end
		else
			v48 = ""
		end
		return v46 < v48
	end)
	return v_u_31
end
local function v_u_65() -- name: publish
	-- upvalues: (ref) v_u_7, (copy) v_u_50, (copy) v_u_6, (ref) v_u_8, (copy) v_u_1, (ref) v_u_11, (copy) v_u_5
	local v51
	if v_u_7 == "follow" then
		local v52 = #v_u_50(true)
		v51 = v52 == 0 and #v_u_50(false) or v52
	else
		v51 = 0
	end
	v_u_6:SetAttribute("SpectateCount", v51)
	v_u_6:SetAttribute("SpectateMode", v_u_7)
	local v53 = v_u_6
	local v54 = "SpectateTargetId"
	local v55
	if v_u_7 == "follow" then
		local v56 = v_u_8
		if v56 then
			v55 = v56:GetAttribute("CombatantId")
			if type(v55) ~= "string" then
				local v57 = v_u_1:GetPlayerFromCharacter(v56)
				if v57 then
					v55 = "p" .. v57.UserId
				else
					v55 = v56.Name
				end
			end
		else
			v55 = ""
		end
	else
		v55 = ""
	end
	v53:SetAttribute(v54, v55)
	local v58 = v_u_6
	local v59 = "SpectateTargetName"
	local v60
	if v_u_7 == "follow" then
		local v61 = v_u_8
		if v61 then
			v60 = v61:GetAttribute("DisplayName")
			if type(v60) ~= "string" or v60 == "" then
				local v62 = v_u_1:GetPlayerFromCharacter(v61)
				if v62 then
					v60 = v62.DisplayName
				else
					v60 = v61.Name
				end
			end
		else
			v60 = ""
		end
	else
		v60 = ""
	end
	v58:SetAttribute(v59, v60)
	v_u_6:SetAttribute("SpectateKillerName", v_u_11)
	local v63 = v_u_5.Changed
	local v64
	if v_u_7 == "follow" then
		v64 = v_u_8
	else
		v64 = nil
	end
	v63:Fire(v64, v_u_7)
end
local v_u_66 = nil
local function v_u_73() -- name: playSwitch
	-- upvalues: (ref) v_u_66
	if v_u_66 == nil then
		local v67 = script.Parent.Parent:FindFirstChild("Sfx")
		v_u_66 = false
		if v67 and v67:IsA("ModuleScript") then
			local v68 = require
			local v69, v70 = pcall(v68, v67)
			if v69 and type(v70) == "table" then
				v_u_66 = v70
			end
		end
	end
	if v_u_66 then
		local v71 = v_u_66.PlayUI
		if type(v71) == "function" then
			local v72 = v_u_66.PlayUI
			pcall(v72, "UI/Spectate_Switch")
		end
	end
end
local function v_u_79(p74) -- name: pick
	-- upvalues: (copy) v_u_50, (ref) v_u_8, (ref) v_u_7, (copy) v_u_73, (ref) v_u_16, (copy) v_u_65
	local v75 = v_u_50(true)
	if #v75 == 0 then
		v75 = v_u_50(false)
	end
	if #v75 == 0 then
		if v_u_8 ~= nil then
			local _ = v_u_8 == nil
			v_u_8 = nil
			v_u_16 = nil
			v_u_65()
		end
	else
		local v76
		if v_u_8 then
			v76 = table.find(v75, v_u_8)
		else
			v76 = nil
		end
		local v77
		if v76 then
			v77 = (v76 - 1 + p74) % #v75 + 1
		else
			v77 = p74 < 0 and #v75 or 1
		end
		if v75[v77] ~= v_u_8 then
			local v78 = v75[v77]
			if v78 ~= v_u_8 and (v78 ~= nil and v_u_7 == "follow") then
				v_u_73()
			end
			v_u_8 = v78
			v_u_16 = nil
			v_u_65()
		end
	end
end
local function v_u_85() -- name: followWanted
	-- upvalues: (copy) v_u_6, (copy) v_u_50, (copy) v_u_1, (ref) v_u_8, (ref) v_u_7, (copy) v_u_73, (ref) v_u_16, (copy) v_u_65
	local v80 = v_u_6:GetAttribute("SpectateFollow")
	if type(v80) == "string" and v80 ~= "" then
		local v81 = v_u_6:GetAttribute("Spectating")
		if ((type(v81) ~= "string" or (v81 == "" or v_u_6:GetAttribute("State") == "Match")) and "" or v81) ~= "" then
			for _, v82 in v_u_50(false) do
				local v83
				if v82 then
					v83 = v82:GetAttribute("CombatantId")
					if type(v83) ~= "string" then
						local v84 = v_u_1:GetPlayerFromCharacter(v82)
						if v84 then
							v83 = "p" .. v84.UserId
						else
							v83 = v82.Name
						end
					end
				else
					v83 = ""
				end
				if v83 ~= v80 then
					continue
				end
				if v82 ~= v_u_8 and (v82 ~= nil and v_u_7 == "follow") then
					v_u_73()
				end
				v_u_8 = v82
				v_u_16 = nil
				v_u_65()
				v_u_6:SetAttribute("SpectateFollow", nil)
				return true
			end
			return false
		end
	end
	return false
end
local function v_u_89() -- name: wantsSpectate
	-- upvalues: (copy) v_u_6
	local v86 = v_u_6:GetAttribute("Spectating")
	if ((type(v86) ~= "string" or (v86 == "" or v_u_6:GetAttribute("State") == "Match")) and "" or v86) ~= "" then
		return true
	end
	if v_u_6:GetAttribute("State") ~= "Match" then
		return false
	end
	if v_u_6:GetAttribute("Alive") == false then
		return true
	end
	local v87 = v_u_6.Character
	if v87 then
		v87 = v87:FindFirstChildOfClass("Humanoid")
	end
	local v88
	if v87 == nil then
		v88 = false
	else
		v88 = v87.Health <= 0
	end
	return v88
end
function v_u_5.Step(p90) -- name: Step
	-- upvalues: (copy) v_u_89, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_13, (ref) v_u_16, (copy) v_u_65, (copy) v_u_6, (copy) v_u_85, (copy) v_u_79, (ref) v_u_12, (ref) v_u_15, (ref) v_u_14, (copy) v_u_5, (copy) v_u_1, (ref) v_u_17, (copy) v_u_50
	local v91 = os.clock()
	if not v_u_89() then
		if v_u_7 ~= "none" then
			v_u_7 = "none"
			v_u_8 = nil
			v_u_9 = nil
			v_u_10 = nil
			v_u_11 = ""
			v_u_13 = nil
			v_u_16 = nil
			v_u_65()
		end
		return v_u_7
	end
	if v_u_7 == "none" then
		local v92 = v_u_6:GetAttribute("Spectating")
		if ((type(v92) ~= "string" or (v92 == "" or v_u_6:GetAttribute("State") == "Match")) and "" or v92) ~= "" then
			v_u_7 = "follow"
			v_u_8 = nil
			v_u_11 = ""
			if not v_u_85() then
				v_u_79(1)
			end
			v_u_65()
			return v_u_7
		end
		v_u_7 = "death"
		v_u_12 = os.clock()
		v_u_13 = p90
		v_u_8 = nil
		v_u_9 = nil
		v_u_11 = ""
		if v_u_10 == nil and os.clock() - v_u_15 < 4 then
			v_u_10 = v_u_14
		end
		local v93 = v_u_5.ResolveCombatant(v_u_10)
		v_u_9 = v93
		if v93 then
			local v94
			if v93 then
				v94 = v93:GetAttribute("DisplayName")
				if type(v94) ~= "string" or v94 == "" then
					local v95 = v_u_1:GetPlayerFromCharacter(v93)
					if v95 then
						v94 = v95.DisplayName
					else
						v94 = v93.Name
					end
				end
			else
				v94 = ""
			end
			v_u_11 = v94
		end
		v_u_65()
		return v_u_7
	end
	if v91 - v_u_17 < 0.25 then
		return v_u_7
	end
	v_u_17 = v91
	if v_u_7 == "death" then
		if v_u_9 == nil or v_u_9.Parent == nil then
			local v96 = v_u_5.ResolveCombatant(v_u_10)
			v_u_9 = v96
			if v96 then
				local v97
				if v96 then
					v97 = v96:GetAttribute("DisplayName")
					if type(v97) ~= "string" or v97 == "" then
						local v98 = v_u_1:GetPlayerFromCharacter(v96)
						if v98 then
							v97 = v98.DisplayName
						else
							v97 = v96.Name
						end
					end
				else
					v97 = ""
				end
				v_u_11 = v97
			end
		end
		if v91 - v_u_12 >= 1.55 then
			v_u_7 = "follow"
			v_u_79(1)
			v_u_65()
		end
		return v_u_7
	end
	if v_u_7 ~= "follow" then
		return v_u_7
	end
	local v99
	if v_u_7 == "follow" then
		local v100 = #v_u_50(true)
		v99 = v100 == 0 and #v_u_50(false) or v100
	else
		v99 = 0
	end
	v_u_6:SetAttribute("SpectateCount", v99)
	v_u_85()
	local v101 = v_u_8
	if v101 == nil then
		if v_u_16 == nil then
			v_u_16 = v91
		end
		if v101 == nil or v91 - v_u_16 >= 0.9 then
			v_u_79(1)
		end
	else
		local v102 = v101:FindFirstChildOfClass("Humanoid")
		local v103
		if v102 == nil or (v102.Health <= 0 or v101.Parent == nil) then
			v103 = false
		else
			v103 = v101:FindFirstChild("HumanoidRootPart") ~= nil
		end
		if v103 then
			v_u_16 = nil
			return v_u_7
		end
		if v_u_16 == nil then
			v_u_16 = v91
		end
		if v101 == nil or v91 - v_u_16 >= 0.9 then
			v_u_79(1)
		end
	end
	return v_u_7
end
function v_u_5.GetMode() -- name: GetMode
	-- upvalues: (ref) v_u_7
	return v_u_7
end
function v_u_5.GetTarget() -- name: GetTarget
	-- upvalues: (ref) v_u_7, (ref) v_u_8
	if v_u_7 == "follow" then
		return v_u_8
	else
		return nil
	end
end
function v_u_5.GetKiller() -- name: GetKiller
	-- upvalues: (ref) v_u_9
	return v_u_9
end
function v_u_5.GetDeathPosition() -- name: GetDeathPosition
	-- upvalues: (ref) v_u_13
	return v_u_13
end
function v_u_5.DeathElapsed() -- name: DeathElapsed
	-- upvalues: (ref) v_u_12
	return os.clock() - v_u_12
end
function v_u_5.Next(p104) -- name: Next
	-- upvalues: (ref) v_u_7, (copy) v_u_79
	if v_u_7 == "follow" then
		v_u_79(p104 < 0 and -1 or 1)
	end
end
function v_u_5.Start() -- name: Start
	-- upvalues: (ref) v_u_18, (copy) v_u_65, (copy) v_u_6, (ref) v_u_10, (ref) v_u_11, (ref) v_u_7, (copy) v_u_5, (ref) v_u_9, (copy) v_u_1, (ref) v_u_8, (ref) v_u_16, (copy) v_u_2, (ref) v_u_14, (ref) v_u_15
	if not v_u_18 then
		v_u_18 = true
		v_u_65()
		local function v_u_119(p105, p106)
			-- upvalues: (ref) v_u_6, (ref) v_u_10, (ref) v_u_11, (ref) v_u_7, (ref) v_u_5, (ref) v_u_9, (ref) v_u_1, (ref) v_u_65, (ref) v_u_8, (ref) v_u_16
			if p105 == "Elimination" and type(p106) == "table" then
				local v107 = p106.victimId
				local v108 = v_u_6.UserId
				if v107 == "p" .. tostring(v108) then
					local v109 = p106.killerId
					local v110
					if type(v109) == "string" then
						v110 = p106.killerId
					else
						v110 = nil
					end
					v_u_10 = v110
					local v111 = p106.killerName
					if type(v111) == "string" then
						v_u_11 = p106.killerName
					end
					if v_u_7 == "death" then
						local v112 = v_u_5.ResolveCombatant(v_u_10)
						v_u_9 = v112
						if v112 then
							local v113
							if v112 then
								v113 = v112:GetAttribute("DisplayName")
								if type(v113) ~= "string" or v113 == "" then
									local v114 = v_u_1:GetPlayerFromCharacter(v112)
									if v114 then
										v113 = v114.DisplayName
									else
										v113 = v112.Name
									end
								end
							else
								v113 = ""
							end
							v_u_11 = v113
						end
						v_u_65()
						return
					end
				elseif v_u_7 == "follow" and v_u_8 then
					local v115 = p106.victimId
					local v116 = v_u_8
					local v117
					if v116 then
						v117 = v116:GetAttribute("CombatantId")
						if type(v117) ~= "string" then
							local v118 = v_u_1:GetPlayerFromCharacter(v116)
							if v118 then
								v117 = "p" .. v118.UserId
							else
								v117 = v116.Name
							end
						end
					else
						v117 = ""
					end
					if v115 == v117 then
						v_u_16 = os.clock()
					end
				end
			end
		end
		local v_u_120 = "MatchEvent"
		task.spawn(function()
			-- upvalues: (ref) v_u_2, (copy) v_u_120, (copy) v_u_119
			local v121 = v_u_2:WaitForChild("Remotes", 60)
			while not v121 do
				v121 = v_u_2:WaitForChild("Remotes", 60)
			end
			local v122 = v121:FindFirstChild(v_u_120)
			while not v122 do
				v121.ChildAdded:Wait()
				v122 = v121:FindFirstChild(v_u_120)
			end
			if v122 and v122:IsA("RemoteEvent") then
				v122.OnClientEvent:Connect(v_u_119)
			end
		end)
		local function v_u_125(p123)
			-- upvalues: (ref) v_u_14, (ref) v_u_15
			if type(p123) == "table" then
				local v124 = p123.attackerId
				if type(v124) == "string" then
					v_u_14 = p123.attackerId
					v_u_15 = os.clock()
				end
			end
		end
		local v_u_126 = "DamageTaken"
		task.spawn(function()
			-- upvalues: (ref) v_u_2, (copy) v_u_126, (copy) v_u_125
			local v127 = v_u_2:WaitForChild("Remotes", 60)
			while not v127 do
				v127 = v_u_2:WaitForChild("Remotes", 60)
			end
			local v128 = v127:FindFirstChild(v_u_126)
			while not v128 do
				v127.ChildAdded:Wait()
				v128 = v127:FindFirstChild(v_u_126)
			end
			if v128 and v128:IsA("RemoteEvent") then
				v128.OnClientEvent:Connect(v_u_125)
			end
		end)
		v_u_6.CharacterAdded:Connect(function()
			-- upvalues: (ref) v_u_7, (ref) v_u_10
			if v_u_7 == "none" then
				v_u_10 = nil
			end
		end)
	end
end
return v_u_5