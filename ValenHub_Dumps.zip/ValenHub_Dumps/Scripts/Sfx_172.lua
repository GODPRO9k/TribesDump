local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("ContentProvider")
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("ReplicatedStorage")
local v5 = game:GetService("RunService")
local v_u_6 = game:GetService("SoundService")
local v_u_7 = game:GetService("TweenService")
local v_u_8 = game:GetService("Workspace")
local v_u_9 = require(script.Parent:WaitForChild("Sounds"))
local v_u_10 = v5:IsServer()
local v11 = {}
local v_u_12 = nil
local v_u_13 = {}
local v_u_14 = {}
local v_u_15 = (-1 / 0)
local v_u_16 = {}
local v_u_17 = {}
local function v_u_22(p18, p19) -- name: relPath
	local v20 = {}
	while p19 and p19 ~= p18 do
		local v21 = p19.Name
		table.insert(v20, 1, v21)
		p19 = p19.Parent
	end
	return table.concat(v20, "/")
end
local function v_u_26(p23) -- name: rebuildLeafIndex
	-- upvalues: (ref) v_u_15, (copy) v_u_14, (copy) v_u_22
	v_u_15 = os.clock()
	table.clear(v_u_14)
	for _, v24 in p23:GetDescendants() do
		if not (v24:IsA("Sound") or v24:IsA("Folder")) then
			continue
		end
		local v25 = v_u_14[v24.Name]
		if v25 == nil then
			v_u_14[v24.Name] = v_u_22(p23, v24)
		else
			if v25 == v_u_22(p23, v24) then
				continue
			end
			v_u_14[v24.Name] = false
		end
	end
end
local function v_u_30(p27, p28) -- name: findPath
	for v29 in string.gmatch(p28, "[^/]+") do
		if p27 then
			p27 = p27:FindFirstChild(v29)
		end
		if p27 then
			continue
		end
		return nil
	end
	return p27
end
local function v_u_37(p31) -- name: fromManifest
	-- upvalues: (copy) v_u_16, (copy) v_u_9
	local v32 = v_u_16[p31]
	if v32 then
		return v32
	end
	local v33 = v_u_9.Get(p31)
	if not v33 then
		return nil
	end
	local v34 = v33.id
	if not v34 and (v33.variants and v33.variants[1]) then
		v34 = v33.variants[1][2]
	end
	if type(v34) ~= "number" or v34 <= 0 then
		return nil
	end
	local v35 = Instance.new("Sound")
	v35.Name = string.match(p31, "([^/]+)$") or p31
	v35.SoundId = "rbxassetid://" .. v34
	v35.Volume = v33.vol or 0.5
	v35.PlaybackSpeed = v33.pitch or 1
	v35.Looped = v33.looped == true
	local v36 = v33.roll or v_u_9.ROLL.default
	v35.RollOffMinDistance = v36[1]
	v35.RollOffMaxDistance = v36[2]
	v35.RollOffMode = Enum.RollOffMode.InverseTapered
	if v33.region then
		v35.PlaybackRegionsEnabled = true
		v35.PlaybackRegion = NumberRange.new(v33.region[1], v33.region[2])
	end
	if v33.fade then
		v35:SetAttribute("FadeOut", v33.fade)
	end
	v_u_16[p31] = v35
	return v35
end
local v_u_38 = {}
local function v_u_45(p39) -- name: resolve
	-- upvalues: (copy) v_u_13, (copy) v_u_38, (ref) v_u_12, (copy) v_u_4, (copy) v_u_30, (copy) v_u_14, (ref) v_u_15, (copy) v_u_26, (copy) v_u_37
	local v40 = v_u_13[p39]
	if v40 and v40.Parent then
		return v40, v_u_38[p39] or p39
	end
	local v41
	if v_u_12 and v_u_12.Parent then
		v41 = v_u_12
	else
		local v42 = v_u_4:FindFirstChild("Assets")
		if v42 then
			v42 = v42:FindFirstChild("Sounds")
		end
		v_u_12 = v42
		v41 = v_u_12
	end
	if v41 then
		local v43 = v_u_30(v41, p39)
		local v44
		if v43 or string.find(p39, "/", 1, true) then
			v44 = p39
		else
			if v_u_14[p39] == nil and os.clock() - v_u_15 > 3 then
				v_u_26(v41)
			end
			v44 = v_u_14[p39]
			if v44 then
				v43 = v_u_30(v41, v44)
			else
				v44 = p39
			end
		end
		if v43 and (v43:IsA("Sound") or v43:IsA("Folder")) then
			v_u_13[p39] = v43
			v_u_38[p39] = v44
			return v43, v44
		end
	end
	return v_u_37(p39), p39
end
local v_u_46 = {}
local function v_u_53(p47) -- name: pickVariant
	-- upvalues: (copy) v_u_46
	local v48 = p47:GetChildren()
	local v49 = #v48
	if v49 == 0 then
		return nil
	end
	local v50 = math.random(1, v49)
	if v49 > 1 and v_u_46[p47] == v50 then
		v50 = v50 % v49 + 1
	end
	v_u_46[p47] = v50
	for v51 = 0, v49 - 1 do
		local v52 = v48[(v50 + v51 - 1) % v49 + 1]
		if not v52:IsA("Sound") then
			continue
		end
		return v52
	end
	return nil
end
local function v_u_57(p54) -- name: whereToPosition
	local v55 = typeof(p54)
	if v55 == "Vector3" then
		return p54, nil
	end
	if v55 == "CFrame" then
		return p54.Position, nil
	end
	if v55 == "Instance" then
		local v56 = not p54:IsA("Model") or (p54.PrimaryPart or (p54:FindFirstChild("HumanoidRootPart") or p54:FindFirstChildWhichIsA("BasePart")))
		if not v56 then
			return nil, nil
		end
		if v56:IsA("BasePart") then
			return v56.Position, v56
		end
		if v56:IsA("Attachment") then
			return v56.WorldPosition, v56
		end
	end
	return nil, nil
end
local v_u_58 = {}
local v_u_59 = {}
local v_u_60 = {
	["Master"] = 1,
	["SFX"] = 1,
	["UI"] = 1,
	["Music"] = 1,
	["Ambient"] = 1
}
local v_u_61 = {}
local function v_u_67(p62) -- name: duckFactor
	-- upvalues: (copy) v_u_61
	local v63 = os.clock()
	local v64 = 1
	for _, v65 in v_u_61 do
		if v65.group ~= p62 or v63 >= v65.untilT then
			continue
		end
		local v66 = v65.factor
		v64 = math.min(v64, v66)
	end
	return v64
end
local function v_u_73(p68, p69) -- name: applyGroup
	-- upvalues: (copy) v_u_6, (copy) v_u_9, (copy) v_u_60, (copy) v_u_67, (copy) v_u_7
	local v70 = v_u_6:FindFirstChild(p68)
	if not (v70 and v70:IsA("SoundGroup")) then
		v70 = nil
	end
	local v71 = v_u_9.GROUPS[p68]
	if v70 and v71 then
		local v72 = v71 * (v_u_60[p68] or 1) * v_u_60.Master * v_u_67(p68)
		if p69 and p69 > 0 then
			v_u_7:Create(v70, TweenInfo.new(p69, Enum.EasingStyle.Sine), {
				["Volume"] = v72
			}):Play()
		else
			v70.Volume = v72
		end
	else
		return
	end
end
function v11.SetVolume(p74, p75) -- name: SetVolume
	-- upvalues: (copy) v_u_60, (copy) v_u_10, (copy) v_u_9, (copy) v_u_6, (copy) v_u_67
	v_u_60[p74] = math.clamp(p75, 0, 1)
	if not v_u_10 then
		if p74 == "Master" then
			for v76 in v_u_9.GROUPS do
				local v77 = v_u_6:FindFirstChild(v76)
				if not (v77 and v77:IsA("SoundGroup")) then
					v77 = nil
				end
				local v78 = v_u_9.GROUPS[v76]
				if not v77 then
					continue
				end
				if not v78 then
					continue
				end
				v77.Volume = v78 * (v_u_60[v76] or 1) * v_u_60.Master * v_u_67(v76)
			end
		else
			local v79 = v_u_6:FindFirstChild(p74)
			if not (v79 and v79:IsA("SoundGroup")) then
				v79 = nil
			end
			local v80 = v_u_9.GROUPS[p74]
			if v79 and v80 then
				v79.Volume = v80 * (v_u_60[p74] or 1) * v_u_60.Master * v_u_67(p74)
			end
		end
		local v81
		if p74 == "Master" then
			v81 = v_u_6
		else
			v81 = v_u_6:FindFirstChild(p74)
			if not (v81 and v81:IsA("SoundGroup")) then
				v81 = nil
			end
		end
		if v81 then
			v81:SetAttribute(p74 == "Master" and "MasterVolume" or "UserVolume", v_u_60[p74])
		end
	end
end
function v11.GetVolume(p82) -- name: GetVolume
	-- upvalues: (copy) v_u_60
	return v_u_60[p82] or 1
end
function v11.Duck(p_u_83, p84, p85) -- name: Duck
	-- upvalues: (copy) v_u_10, (copy) v_u_61, (copy) v_u_73
	if not v_u_10 then
		local v86 = v_u_61
		local v87 = {
			["group"] = p_u_83,
			["factor"] = math.clamp(p84, 0, 1),
			["untilT"] = os.clock() + p85
		}
		table.insert(v86, v87)
		v_u_73(p_u_83, 0.35)
		task.delay(p85, function()
			-- upvalues: (ref) v_u_61, (ref) v_u_73, (copy) p_u_83
			local v88 = os.clock()
			for v89 = #v_u_61, 1, -1 do
				if v_u_61[v89].untilT > v88 then
					continue
				end
				table.remove(v_u_61, v89)
			end
			v_u_73(p_u_83, 0.8)
		end)
	end
end
function v11.ApplyGroups() -- name: ApplyGroups
	-- upvalues: (copy) v_u_9, (copy) v_u_6, (copy) v_u_60, (copy) v_u_67
	for v90 in v_u_9.GROUPS do
		local v91 = v_u_6:FindFirstChild(v90)
		if not (v91 and v91:IsA("SoundGroup")) then
			v91 = nil
		end
		local v92 = v_u_9.GROUPS[v90]
		if not v91 then
			continue
		end
		if not v92 then
			continue
		end
		v91.Volume = v92 * (v_u_60[v90] or 1) * v_u_60.Master * v_u_67(v90)
	end
end
local v_u_93 = {}
local v_u_94 = {}
local v_u_95 = {}
local v_u_96 = {}
local v_u_97 = nil
local v_u_98 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_105(p99) -- name: acquireSound
	-- upvalues: (copy) v_u_93, (copy) v_u_98, (copy) v_u_96, (ref) v_u_97
	local v100 = v_u_93[p99]
	if v100 then
		if #v100 > 0 then
			local v101 = table.remove(v100)
			if v_u_98[v101] then
				continue
			end
			return v101
		end
	end
	local v_u_102 = p99:Clone()
	v_u_102.Looped = false
	v_u_102.Ended:Connect(function()
		-- upvalues: (ref) v_u_96, (copy) v_u_102, (ref) v_u_97
		local v103 = v_u_96[v_u_102]
		if v103 then
			v_u_97(v103)
		end
	end)
	v_u_102.Destroying:Connect(function()
		-- upvalues: (ref) v_u_98, (copy) v_u_102, (ref) v_u_96, (ref) v_u_97
		v_u_98[v_u_102] = true
		local v104 = v_u_96[v_u_102]
		if v104 then
			v_u_97(v104)
		end
	end)
	return v_u_102
end
v_u_97 = function(p106) -- name: release
	-- upvalues: (copy) v_u_95, (copy) v_u_96, (copy) v_u_98, (copy) v_u_93, (copy) v_u_94
	if not p106.released then
		p106.released = true
		if p106.tween then
			p106.tween:Cancel()
		end
		local v107 = table.find(v_u_95, p106)
		if v107 then
			v_u_95[v107] = v_u_95[#v_u_95]
			v_u_95[#v_u_95] = nil
		end
		local v_u_108 = p106.sound
		if v_u_96[v_u_108] == p106 then
			v_u_96[v_u_108] = nil
		end
		if pcall(function()
			-- upvalues: (copy) v_u_108
			v_u_108:Stop()
			v_u_108.Parent = nil
		end) and not v_u_98[v_u_108] then
			local v109 = v_u_93[p106.template]
			if not v109 then
				v109 = {}
				v_u_93[p106.template] = v109
			end
			if #v109 < 8 then
				table.insert(v109, v_u_108)
			else
				v_u_108:Destroy()
			end
		end
		local v110 = p106.holder
		if v110 then
			if #v_u_94 < 40 and v110.Parent then
				local v111 = v_u_94
				table.insert(v111, v110)
				return
			end
			v110:Destroy()
		end
	end
end
local function v_u_118(p112) -- name: inTrainingZone
	-- upvalues: (copy) v_u_1, (copy) v_u_8
	for _, v113 in v_u_1:GetTagged("TrainingZone") do
		if not (v113:IsA("BasePart") and v113:IsDescendantOf(v_u_8)) then
			continue
		end
		local v114 = v113.CFrame:PointToObjectSpace(p112)
		local v115 = v113.Size * 0.5
		local v116 = v114.X
		if math.abs(v116) > v115.X + 2 then
			continue
		end
		local v117 = v114.Z
		if math.abs(v117) > v115.Z + 2 or (v114.Y < -v115.Y - 4 or v114.Y > v115.Y + 10) then
			continue
		end
		return true
	end
	return false
end
local function v_u_129(p119, p120) -- name: admit3D
	-- upvalues: (copy) v_u_95, (copy) v_u_8, (ref) v_u_97
	if #v_u_95 < 28 then
		return true
	end
	local v121 = v_u_8.CurrentCamera
	local v122
	if v121 then
		v122 = v121.CFrame.Position
	else
		v122 = nil
	end
	local v123 = -1
	local v124 = nil
	for _, v125 in v_u_95 do
		if v125.priority then
			continue
		end
		local v126 = v125.inst
		local v127, v128
		if v126 and v126.Parent then
			if v126:IsA("BasePart") then
				v127 = v126.Position
				v128 = not (v127 and v122) and 0 or (v127 - v122).Magnitude
				if v123 >= v128 then
					continue
				end
				v124 = v125
				v123 = v128
			elseif v126:IsA("Attachment") then
				v127 = v126.WorldPosition
				v128 = not (v127 and v122) and 0 or (v127 - v122).Magnitude
				if v123 >= v128 then
					continue
				end
				v124 = v125
				v123 = v128
			else
				v127 = v125.pos
				v128 = not (v127 and v122) and 0 or (v127 - v122).Magnitude
				if v123 >= v128 then
					continue
				end
				v124 = v125
				v123 = v128
			end
		else
			v127 = v125.pos
			v128 = not (v127 and v122) and 0 or (v127 - v122).Magnitude
			if v123 >= v128 then
				continue
			end
			v124 = v125
			v123 = v128
		end
	end
	if not v124 or not p120 and p119 >= v123 then
		return p120
	end
	v_u_97(v124)
	return true
end
local function v_u_144(p_u_130) -- name: scheduleEnd
	-- upvalues: (copy) v_u_96, (copy) v_u_7, (ref) v_u_97
	local v_u_131 = p_u_130.sound
	local function v_u_142() -- name: arm
		-- upvalues: (copy) p_u_130, (copy) v_u_131, (ref) v_u_96, (ref) v_u_7, (ref) v_u_97
		if not p_u_130.released then
			local v132 = v_u_131
			local v133 = v132.TimeLength
			local v134
			if v133 <= 0 then
				v134 = 0
			else
				if v132.PlaybackRegionsEnabled then
					local v135 = v132.PlaybackRegion
					local v136 = v135.Max
					v133 = math.min(v136, v133) - v135.Min
				end
				local v137 = math.max(v133, 0.05)
				local v138 = v132.PlaybackSpeed
				v134 = v137 / math.max(v138, 0.05)
			end
			local v139 = v134 <= 0 and 6 or v134
			local v_u_140 = v_u_131:GetAttribute("FadeOut")
			if type(v_u_140) == "number" and (v_u_140 > 0 and v_u_140 < v139) then
				task.delay(v139 - v_u_140, function()
					-- upvalues: (ref) p_u_130, (ref) v_u_96, (ref) v_u_131, (ref) v_u_7, (copy) v_u_140
					if not p_u_130.released and v_u_96[v_u_131] == p_u_130 then
						local v141 = v_u_7:Create(v_u_131, TweenInfo.new(v_u_140, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
							["Volume"] = 0
						})
						p_u_130.tween = v141
						v141:Play()
					end
				end)
			end
			task.delay(v139 + 0.1, v_u_97, p_u_130)
		end
	end
	if v_u_131.IsLoaded then
		v_u_142()
	else
		local v_u_143 = nil
		v_u_143 = v_u_131.Loaded:Connect(function()
			-- upvalues: (ref) v_u_143, (copy) v_u_142
			if v_u_143 then
				v_u_143:Disconnect()
			end
			v_u_142()
		end)
		task.delay(5, function()
			-- upvalues: (ref) v_u_143, (copy) v_u_142
			if v_u_143 and v_u_143.Connected then
				v_u_143:Disconnect()
				v_u_142()
			end
		end)
	end
end
local v_u_145 = nil
local function v_u_158(p146, p_u_147, p148) -- name: playExtras
	-- upvalues: (ref) v_u_145
	if p146 and not (p148 and p148.noLayers) then
		local v_u_149 = p148 and (p148.volume or 1) or 1
		if p146.layers then
			for _, v150 in p146.layers do
				local v151
				if type(v150) == "table" then
					v151 = v150[1]
				else
					v151 = v150
				end
				local v152 = v_u_145
				local v153 = {
					["volume"] = nil,
					["pitch"] = nil,
					["noLayers"] = true,
					["priority"] = nil,
					["volume"] = (type(v150) == "table" and (v150[2] or 1) or 1) * v_u_149
				}
				local v154
				if p148 then
					v154 = p148.pitch
				else
					v154 = p148
				end
				v153.pitch = v154
				local v155
				if p148 then
					v155 = p148.priority
				else
					v155 = p148
				end
				v153.priority = v155
				v152(v151, p_u_147, v153)
			end
		end
		if p146.sequence then
			for _, v_u_156 in p146.sequence do
				task.delay(v_u_156[2] or 0, function()
					-- upvalues: (copy) p_u_147, (ref) v_u_145, (copy) v_u_156, (copy) v_u_149
					local v157 = p_u_147
					if typeof(v157) ~= "Instance" or v157.Parent then
						v_u_145(v_u_156[1], v157, {
							["volume"] = nil,
							["pitch"] = nil,
							["noLayers"] = true,
							["volume"] = (v_u_156[3] or 1) * v_u_149,
							["pitch"] = v_u_156[4]
						})
					end
				end)
			end
		end
	end
end
v_u_145 = function(p159, p160, p161) -- name: playClient
	-- upvalues: (copy) v_u_45, (copy) v_u_17, (copy) v_u_53, (copy) v_u_9, (copy) v_u_57, (copy) v_u_10, (copy) v_u_3, (copy) v_u_58, (copy) v_u_59, (copy) v_u_8, (copy) v_u_118, (copy) v_u_129, (copy) v_u_105, (copy) v_u_6, (copy) v_u_94, (copy) v_u_96, (copy) v_u_95, (copy) v_u_144, (copy) v_u_158
	local v162, v163 = v_u_45(p159)
	if not v162 then
		if not v_u_17[p159] then
			v_u_17[p159] = true
			warn((("[Sfx] unknown sound \'%*\'"):format(p159)))
		end
		return nil
	end
	if not v162:IsA("Sound") then
		v162 = v_u_53(v162)
	end
	if not v162 then
		return nil
	end
	local v164 = v_u_9.Get(v163)
	if not v164 then
		local v165 = string.match(v163, "^(.*)/[^/]+$")
		if v165 then
			v164 = v_u_9.Get(v165)
		else
			v164 = nil
		end
	end
	local v166, v167 = v_u_57(p160)
	if p160 ~= nil and not v166 then
		return nil
	end
	local v168 = p161 and p161.priority or v164 and v164.priority
	if not v168 then
		local v169
		if v167 and not v_u_10 then
			local v170 = v_u_3.LocalPlayer
			if v170 then
				v170 = v170.Character
			end
			if v170 == nil then
				v169 = false
			else
				v169 = v167:IsDescendantOf(v170)
			end
		else
			v169 = false
		end
		v168 = v169 or false
	end
	local v171 = os.clock()
	local v172 = v164 and (v164.throttle or 0.035) or 0.035
	local v173 = v_u_58[v163]
	local v174, v175, v176, v177, v178, v179, v180, v181, v182
	if not v173 or v171 - v173 >= v172 then
		v_u_58[v163] = v171
		v_u_59[v163] = v166 or false
		v184 = false
		if v184 then
			return nil
		end
		v185 = v162.RollOffMaxDistance
		v186 = 1
		if v166 then
			v174 = v_u_8.CurrentCamera
			if v174 then
				v175 = v174.CFrame.Position
			else
				v175 = nil
			end
			v176 = not v175 and 0 or (v166 - v175).Magnitude
			if v185 >= 100 and v_u_118(v166) then
				v185 = math.min(v185, 80)
				v186 = (v175 and not v_u_118(v175) and 0.45 or 1) * 0.7
			end
			if not v168 and v185 < v176 then
				return nil
			end
			if not v_u_129(v176, v168) then
				return nil
			end
		end
		v187 = v_u_105(v162)
		v188 = p161 or {}
		v187.Volume = v162.Volume * (v188.volume or 1) * v186
		v187.RollOffMaxDistance = v185
		v189 = v162.PlaybackSpeed * (v188.pitch or 1)
		if not v188.pitch then
			if v164 then
				v177 = v164.jitter
			else
				v177 = v164
			end
			if v177 == nil then
				if v164 and v164.group then
					v178 = v164.group
				else
					v178 = v_u_9.groupOf(v163)
					if v178 == "SFX" then
						v179 = string.match(v163, "^(.*)/[^/]+$")
						if v179 then
							v178 = v_u_9.groupOf(v179)
						end
					end
				end
				v177 = v178 == "SFX" and 0.04 or 0
			end
			if v177 > 0 then
				v189 = v189 * (1 + (math.random() * 2 - 1) * v177)
			end
		end
		v187.PlaybackSpeed = v189
		v190 = v188.group
		if not v190 then
			if v164 and v164.group then
				v190 = v164.group
			else
				v190 = v_u_9.groupOf(v163)
				if v190 == "SFX" then
					v180 = string.match(v163, "^(.*)/[^/]+$")
					if v180 then
						v190 = v_u_9.groupOf(v180)
					end
				end
			end
		end
		v191 = v_u_6:FindFirstChild(v190)
		if not (v191 and v191:IsA("SoundGroup")) then
			v191 = nil
		end
		v187.SoundGroup = v191
		v187.TimePosition = not v187.PlaybackRegionsEnabled and 0 or v187.PlaybackRegion.Min
		v192 = {
			["sound"] = nil,
			["template"] = nil,
			["pos"] = nil,
			["inst"] = nil,
			["holder"] = nil,
			["priority"] = nil,
			["released"] = false,
			["tween"] = nil,
			["sound"] = v187,
			["template"] = v162,
			["pos"] = v166,
			["inst"] = v167,
			["priority"] = v168
		}
		if v166 then
			if v167 then
				v187.Parent = v167
			else
				v181 = table.remove(v_u_94)
				if not (v181 and v181.Parent) then
					v181 = Instance.new("Attachment")
					v181.Name = "SfxHolder"
					v181.Parent = v_u_8.Terrain
				end
				v181.WorldPosition = v166
				v192.holder = v181
				v187.Parent = v181
			end
		else
			v187.Parent = v_u_6
		end
		v_u_96[v187] = v192
		if v166 then
			v182 = v_u_95
			table.insert(v182, v192)
		end
		v187:Play()
		v_u_144(v192)
		v_u_158(v164, p160, p161)
		return v187
	end
	local v183 = v_u_59[v163]
	if not v166 or (not v183 or (v166 - v183).Magnitude < 8) then
		v184 = true
		if v184 then
			return nil
		end
		v185 = v162.RollOffMaxDistance
		v186 = 1
		if v166 then
			v174 = v_u_8.CurrentCamera
			if v174 then
				v175 = v174.CFrame.Position
			else
				v175 = nil
			end
			v176 = not v175 and 0 or (v166 - v175).Magnitude
			if v185 >= 100 and v_u_118(v166) then
				v185 = math.min(v185, 80)
				v186 = (v175 and not v_u_118(v175) and 0.45 or 1) * 0.7
			end
			if not v168 and v185 < v176 then
				return nil
			end
			if not v_u_129(v176, v168) then
				return nil
			end
		end
		v187 = v_u_105(v162)
		v188 = p161 or {}
		v187.Volume = v162.Volume * (v188.volume or 1) * v186
		v187.RollOffMaxDistance = v185
		v189 = v162.PlaybackSpeed * (v188.pitch or 1)
		if not v188.pitch then
			if v164 then
				v177 = v164.jitter
			else
				v177 = v164
			end
			if v177 == nil then
				if v164 and v164.group then
					v178 = v164.group
				else
					v178 = v_u_9.groupOf(v163)
					if v178 == "SFX" then
						v179 = string.match(v163, "^(.*)/[^/]+$")
						if v179 then
							v178 = v_u_9.groupOf(v179)
						end
					end
				end
				v177 = v178 == "SFX" and 0.04 or 0
			end
			if v177 > 0 then
				v189 = v189 * (1 + (math.random() * 2 - 1) * v177)
			end
		end
		v187.PlaybackSpeed = v189
		v190 = v188.group
		if not v190 then
			if v164 and v164.group then
				v190 = v164.group
			else
				v190 = v_u_9.groupOf(v163)
				if v190 == "SFX" then
					v180 = string.match(v163, "^(.*)/[^/]+$")
					if v180 then
						v190 = v_u_9.groupOf(v180)
					end
				end
			end
		end
		v191 = v_u_6:FindFirstChild(v190)
		if not (v191 and v191:IsA("SoundGroup")) then
			v191 = nil
		end
		v187.SoundGroup = v191
		v187.TimePosition = not v187.PlaybackRegionsEnabled and 0 or v187.PlaybackRegion.Min
		v192 = {
			["sound"] = nil,
			["template"] = nil,
			["pos"] = nil,
			["inst"] = nil,
			["holder"] = nil,
			["priority"] = nil,
			["released"] = false,
			["tween"] = nil,
			["sound"] = v187,
			["template"] = v162,
			["pos"] = v166,
			["inst"] = v167,
			["priority"] = v168
		}
		if v166 then
			if v167 then
				v187.Parent = v167
			else
				v181 = table.remove(v_u_94)
				if not (v181 and v181.Parent) then
					v181 = Instance.new("Attachment")
					v181.Name = "SfxHolder"
					v181.Parent = v_u_8.Terrain
				end
				v181.WorldPosition = v166
				v192.holder = v181
				v187.Parent = v181
			end
		else
			v187.Parent = v_u_6
		end
		v_u_96[v187] = v192
		if v166 then
			v182 = v_u_95
			table.insert(v182, v192)
		end
		v187:Play()
		v_u_144(v192)
		v_u_158(v164, p160, p161)
		return v187
	end
	v_u_58[v163] = v171
	v_u_59[v163] = v166 or false
	local v184 = false
	if v184 then
		return nil
	end
	local v185 = v162.RollOffMaxDistance
	local v186 = 1
	if v166 then
		v174 = v_u_8.CurrentCamera
		if v174 then
			v175 = v174.CFrame.Position
		else
			v175 = nil
		end
		v176 = not v175 and 0 or (v166 - v175).Magnitude
		if v185 >= 100 and v_u_118(v166) then
			v185 = math.min(v185, 80)
			v186 = (v175 and not v_u_118(v175) and 0.45 or 1) * 0.7
		end
		if not v168 and v185 < v176 then
			return nil
		end
		if not v_u_129(v176, v168) then
			return nil
		end
	end
	local v187 = v_u_105(v162)
	local v188 = p161 or {}
	v187.Volume = v162.Volume * (v188.volume or 1) * v186
	v187.RollOffMaxDistance = v185
	local v189 = v162.PlaybackSpeed * (v188.pitch or 1)
	if not v188.pitch then
		if v164 then
			v177 = v164.jitter
		else
			v177 = v164
		end
		if v177 == nil then
			if v164 and v164.group then
				v178 = v164.group
			else
				v178 = v_u_9.groupOf(v163)
				if v178 == "SFX" then
					v179 = string.match(v163, "^(.*)/[^/]+$")
					if v179 then
						v178 = v_u_9.groupOf(v179)
					end
				end
			end
			v177 = v178 == "SFX" and 0.04 or 0
		end
		if v177 > 0 then
			v189 = v189 * (1 + (math.random() * 2 - 1) * v177)
		end
	end
	v187.PlaybackSpeed = v189
	local v190 = v188.group
	if not v190 then
		if v164 and v164.group then
			v190 = v164.group
		else
			v190 = v_u_9.groupOf(v163)
			if v190 == "SFX" then
				v180 = string.match(v163, "^(.*)/[^/]+$")
				if v180 then
					v190 = v_u_9.groupOf(v180)
				end
			end
		end
	end
	local v191 = v_u_6:FindFirstChild(v190)
	if not (v191 and v191:IsA("SoundGroup")) then
		v191 = nil
	end
	v187.SoundGroup = v191
	v187.TimePosition = not v187.PlaybackRegionsEnabled and 0 or v187.PlaybackRegion.Min
	local v192 = {
		["sound"] = nil,
		["template"] = nil,
		["pos"] = nil,
		["inst"] = nil,
		["holder"] = nil,
		["priority"] = nil,
		["released"] = false,
		["tween"] = nil,
		["sound"] = v187,
		["template"] = v162,
		["pos"] = v166,
		["inst"] = v167,
		["priority"] = v168
	}
	if v166 then
		if v167 then
			v187.Parent = v167
		else
			v181 = table.remove(v_u_94)
			if not (v181 and v181.Parent) then
				v181 = Instance.new("Attachment")
				v181.Name = "SfxHolder"
				v181.Parent = v_u_8.Terrain
			end
			v181.WorldPosition = v166
			v192.holder = v181
			v187.Parent = v181
		end
	else
		v187.Parent = v_u_6
	end
	v_u_96[v187] = v192
	if v166 then
		v182 = v_u_95
		table.insert(v182, v192)
	end
	v187:Play()
	v_u_144(v192)
	v_u_158(v164, p160, p161)
	return v187
end
local v_u_193 = nil
local function v_u_197(p194) -- name: focusOf
	local v195 = p194.ReplicationFocus
	if v195 and (v195:IsA("BasePart") and v195.Parent) then
		return v195.Position
	else
		local v196 = p194.Character
		if v196 then
			v196 = v196.PrimaryPart or v196:FindFirstChild("HumanoidRootPart")
		end
		if v196 and v196:IsA("BasePart") then
			return v196.Position
		else
			return nil
		end
	end
end
local function v_u_230(p198, p199, p200, p201) -- name: playServer
	-- upvalues: (ref) v_u_193, (copy) v_u_45, (copy) v_u_17, (copy) v_u_53, (copy) v_u_57, (copy) v_u_9, (copy) v_u_58, (copy) v_u_59, (copy) v_u_3, (copy) v_u_197
	local v202
	if v_u_193 then
		v202 = v_u_193
	else
		local v203, v204 = pcall(function()
			return require(script.Parent:WaitForChild("Net")).UnreliableEvent("SfxPlay")
		end)
		if v203 then
			v_u_193 = v204
		end
		v202 = v_u_193
	end
	if not v202 then
		return
	end
	local v205, v206 = v_u_45(p198)
	if not v205 then
		if not v_u_17[p198] then
			v_u_17[p198] = true
			warn((("[Sfx] unknown sound \'%*\'"):format(p198)))
		end
		return
	end
	if not v205:IsA("Sound") then
		v205 = v_u_53(v205)
	end
	local v207, v208 = v_u_57(p199)
	if p199 ~= nil and not v207 then
		return
	end
	local v209 = "srv:" .. v206
	local v210 = v_u_9.Get(v206)
	if not v210 then
		local v211 = string.match(v206, "^(.*)/[^/]+$")
		if v211 then
			v210 = v_u_9.Get(v211)
		else
			v210 = nil
		end
	end
	local v212 = os.clock()
	local v213 = v210 and v210.throttle or 0.035
	local v214 = v_u_58[v209]
	local v215, v216, v217, v218, v219, v220, v221, v222
	if v214 and v212 - v214 < v213 then
		local v223 = v_u_59[v209]
		if v207 and (v223 and (v207 - v223).Magnitude >= 8) then
			v_u_58[v209] = v212
			v_u_59[v209] = v207 or false
			v215 = false
			if v215 then
				return
			else
				v216 = p200 or {}
				v217 = v216.volume
				v218 = v216.pitch
				v219 = (v205 and v205.RollOffMaxDistance or 150) + 40
				v220 = p201 or v216.players
				if v207 or v220 then
					for v228, v229 in v220 or v_u_3:GetPlayers() do
						if v229 == v216.except or v229.Parent ~= v_u_3 then
							continue
						end
						if v207 and not v220 then
							v221 = v_u_197(v229)
							v222 = v221 == nil and true or (v221 - v207).Magnitude <= v219
						else
							v222 = true
						end
						if not v222 then
							continue
						end
						v202:FireClient(v229, v206, v207, v208, v217, v218)
					end
				else
					warn((("[Sfx] server 2D play of \'%*\' needs opts.players (or Sfx.PlayFor)"):format(p198)))
				end
			end
		else
			v215 = true
			if v215 then
				return
			else
				v216 = p200 or {}
				v217 = v216.volume
				v218 = v216.pitch
				v219 = (v205 and v205.RollOffMaxDistance or 150) + 40
				v220 = p201 or v216.players
				if v207 or v220 then
					for v228, v229 in v220 or v_u_3:GetPlayers() do
						if v229 == v216.except or v229.Parent ~= v_u_3 then
							continue
						end
						if v207 and not v220 then
							v221 = v_u_197(v229)
							v222 = v221 == nil and true or (v221 - v207).Magnitude <= v219
						else
							v222 = true
						end
						if not v222 then
							continue
						end
						v202:FireClient(v229, v206, v207, v208, v217, v218)
					end
				else
					warn((("[Sfx] server 2D play of \'%*\' needs opts.players (or Sfx.PlayFor)"):format(p198)))
				end
			end
		end
	else
		v_u_58[v209] = v212
		v_u_59[v209] = v207 or false
		v215 = false
		if v215 then
			return
		else
			v216 = p200 or {}
			v217 = v216.volume
			v218 = v216.pitch
			v219 = (v205 and v205.RollOffMaxDistance or 150) + 40
			v220 = p201 or v216.players
			if v207 or v220 then
				for v228, v229 in v220 or v_u_3:GetPlayers() do
					if v229 == v216.except or v229.Parent ~= v_u_3 then
						continue
					end
					if v207 and not v220 then
						v221 = v_u_197(v229)
						v222 = v221 == nil and true or (v221 - v207).Magnitude <= v219
					else
						v222 = true
					end
					if not v222 then
						continue
					end
					v202:FireClient(v229, v206, v207, v208, v217, v218)
				end
			else
				warn((("[Sfx] server 2D play of \'%*\' needs opts.players (or Sfx.PlayFor)"):format(p198)))
			end
		end
	end
end
function v11.Play(p231, p232, p233) -- name: Play
	-- upvalues: (copy) v_u_10, (copy) v_u_230, (ref) v_u_145
	if not v_u_10 then
		return v_u_145(p231, p232, p233)
	end
	v_u_230(p231, p232, p233, nil)
	return nil
end
function v11.PlayUI(p234) -- name: PlayUI
	-- upvalues: (copy) v_u_10, (ref) v_u_12, (copy) v_u_4, (copy) v_u_9, (ref) v_u_145
	if v_u_10 then
		return nil
	end
	if not string.find(p234, "/", 1, true) then
		local v235
		if v_u_12 and v_u_12.Parent then
			v235 = v_u_12
		else
			local v236 = v_u_4:FindFirstChild("Assets")
			if v236 then
				v236 = v236:FindFirstChild("Sounds")
			end
			v_u_12 = v236
			v235 = v_u_12
		end
		if v235 and not (v235:FindFirstChild(p234) or v_u_9.Get(p234)) then
			p234 = "UI/" .. p234
		end
	end
	return v_u_145(p234, nil, {
		["group"] = v_u_9.Get(p234) and v_u_9.groupOf(p234) or "UI"
	})
end
function v11.PlayFor(p237, p238, p239, p240) -- name: PlayFor
	-- upvalues: (copy) v_u_10, (copy) v_u_230, (copy) v_u_3, (ref) v_u_145
	local v241 = typeof(p237) == "Instance" and { p237 } or p237
	if v_u_10 then
		v_u_230(p238, p239, p240, v241)
		return nil
	elseif table.find(v241, v_u_3.LocalPlayer) then
		return v_u_145(p238, p239, p240)
	else
		return nil
	end
end
function v11.Loop(p242, p243, p244) -- name: Loop
	-- upvalues: (copy) v_u_45, (copy) v_u_53, (copy) v_u_17, (copy) v_u_10, (copy) v_u_9, (copy) v_u_6, (copy) v_u_7
	local v245, v246 = v_u_45(p242)
	local v247
	if v245 and not v245:IsA("Sound") then
		v247 = v_u_53(v245)
	else
		v247 = v245
	end
	if not v247 then
		if not (v245 or v_u_17[p242]) then
			v_u_17[p242] = true
			warn((("[Sfx] unknown sound \'%*\'"):format(p242)))
		end
		return function() end, nil
	end
	if v_u_10 and not p243 then
		warn((("[Sfx] server loop \'%*\' needs a parent instance"):format(p242)))
		return function() end, nil
	end
	local v248 = v_u_9.Get(v246)
	if not v248 then
		local v249 = string.match(v246, "^(.*)/[^/]+$")
		if v249 then
			v248 = v_u_9.Get(v249)
		else
			v248 = nil
		end
	end
	local v250 = p244 or {}
	local v_u_251 = v247:Clone()
	v_u_251.Looped = true
	local v252 = v247.Volume * (v250.volume or 1)
	v_u_251.PlaybackSpeed = v247.PlaybackSpeed * (v250.pitch or 1)
	local v253 = v250.group
	if not v253 then
		if v248 and v248.group then
			v253 = v248.group
		else
			v253 = v_u_9.groupOf(v246)
			if v253 == "SFX" then
				local v254 = string.match(v246, "^(.*)/[^/]+$")
				if v254 then
					v253 = v_u_9.groupOf(v254)
				end
			end
		end
	end
	local v255 = v_u_6:FindFirstChild(v253)
	if not (v255 and v255:IsA("SoundGroup")) then
		v255 = nil
	end
	v_u_251.SoundGroup = v255
	v_u_251.TimePosition = not v_u_251.PlaybackRegionsEnabled and 0 or v_u_251.PlaybackRegion.Min
	if v250.fadeIn and v250.fadeIn > 0 then
		v_u_251.Volume = 0
	else
		v_u_251.Volume = v252
	end
	v_u_251.Parent = p243 or v_u_6
	v_u_251:Play()
	if v250.fadeIn and v250.fadeIn > 0 then
		v_u_7:Create(v_u_251, TweenInfo.new(v250.fadeIn), {
			["Volume"] = v252
		}):Play()
	end
	local v_u_256 = false
	return function(p257) -- name: stop
		-- upvalues: (ref) v_u_256, (copy) v_u_251, (ref) v_u_7
		if v_u_256 then
			return
		else
			v_u_256 = true
			if p257 and (p257 > 0 and v_u_251.Parent) then
				local v258 = v_u_7:Create(v_u_251, TweenInfo.new(p257), {
					["Volume"] = 0
				})
				v258.Completed:Once(function()
					-- upvalues: (ref) v_u_251
					v_u_251:Destroy()
				end)
				v258:Play()
			else
				v_u_251:Destroy()
			end
		end
	end, v_u_251
end
function v11.Clone(p259) -- name: Clone
	-- upvalues: (copy) v_u_45, (copy) v_u_53, (copy) v_u_17, (copy) v_u_9, (copy) v_u_6
	local v260, v261 = v_u_45(p259)
	local v262
	if v260 and not v260:IsA("Sound") then
		v262 = v_u_53(v260)
	else
		v262 = v260
	end
	if not v262 then
		if not (v260 or v_u_17[p259]) then
			v_u_17[p259] = true
			warn((("[Sfx] unknown sound \'%*\'"):format(p259)))
		end
		return nil
	end
	local v263 = v262:Clone()
	local v264 = v_u_9.Get(v261)
	if not v264 then
		local v265 = string.match(v261, "^(.*)/[^/]+$")
		if v265 then
			v264 = v_u_9.Get(v265)
		else
			v264 = nil
		end
	end
	local v266
	if v264 and v264.group then
		v266 = v264.group
	else
		v266 = v_u_9.groupOf(v261)
		if v266 == "SFX" then
			local v267 = string.match(v261, "^(.*)/[^/]+$")
			if v267 then
				v266 = v_u_9.groupOf(v267)
			end
		end
	end
	local v268 = v_u_6:FindFirstChild(v266)
	if not (v268 and v268:IsA("SoundGroup")) then
		v268 = nil
	end
	v263.SoundGroup = v268
	return v263
end
function v11.Has(p269) -- name: Has
	-- upvalues: (copy) v_u_45
	return v_u_45(p269) ~= nil
end
function v11.Length(p270) -- name: Length
	-- upvalues: (copy) v_u_45, (copy) v_u_53
	local v271 = v_u_45(p270)
	if v271 and not v271:IsA("Sound") then
		v271 = v_u_53(v271)
	end
	if not v271 then
		return 0
	end
	local v272 = v271.TimeLength
	if v272 <= 0 then
		return 0
	end
	if v271.PlaybackRegionsEnabled then
		local v273 = v271.PlaybackRegion
		local v274 = v273.Max
		v272 = math.min(v274, v272) - v273.Min
	end
	local v275 = math.max(v272, 0.05)
	local v276 = v271.PlaybackSpeed
	return v275 / math.max(v276, 0.05)
end
function v11.Preload(p_u_277) -- name: Preload
	-- upvalues: (copy) v_u_45, (ref) v_u_12, (copy) v_u_4, (copy) v_u_2
	task.spawn(function()
		-- upvalues: (copy) p_u_277, (ref) v_u_45, (ref) v_u_12, (ref) v_u_4, (ref) v_u_2
		local v278 = {}
		if p_u_277 then
			for _, v279 in p_u_277 do
				local v280 = v_u_45(v279)
				if not v280 then
					continue
				end
				if v280:IsA("Folder") then
					for _, v281 in v280:GetChildren() do
						table.insert(v278, v281)
					end
				else
					table.insert(v278, v280)
				end
			end
		else
			local v282
			if v_u_12 and v_u_12.Parent then
				v282 = v_u_12
			else
				local v283 = v_u_4:FindFirstChild("Assets")
				if v283 then
					v283 = v283:FindFirstChild("Sounds")
				end
				v_u_12 = v283
				v282 = v_u_12
			end
			if v282 then
				for _, v284 in v282:GetDescendants() do
					if not v284:IsA("Sound") then
						continue
					end
					table.insert(v278, v284)
				end
			end
		end
		local v285 = v_u_2.PreloadAsync
		local v286 = v_u_2
		pcall(v285, v286, v278)
	end)
end
function v11.Stats() -- name: Stats
	-- upvalues: (copy) v_u_93, (copy) v_u_95
	local v287 = 0
	for _, v288 in v_u_93 do
		v287 = v287 + #v288
	end
	return {
		["live3D"] = #v_u_95,
		["pooled"] = v287
	}
end
return v11