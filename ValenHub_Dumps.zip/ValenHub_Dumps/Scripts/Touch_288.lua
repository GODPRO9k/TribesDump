local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = require(v2:WaitForChild("Shared"):WaitForChild("TouchStart"))
local v5 = {}
local v_u_6 = v1.LocalPlayer
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = {}
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = {}
local v_u_13 = false
local v_u_14 = false
local v_u_15 = true
local v_u_16 = nil
local v_u_17 = Color3.fromRGB(40, 150, 255)
local v_u_18 = Color3.fromRGB(18, 20, 26)
local v_u_19 = Color3.fromRGB(36, 40, 50)
local v_u_20 = Color3.fromRGB(255, 255, 255)
local v_u_21 = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Heavy)
local v_u_22 = {
	["Fists"] = "PUNCH",
	["Sword"] = "ATTACK",
	["Axe"] = "ATTACK",
	["Spear"] = "ATTACK",
	["Dagger"] = "ATTACK",
	["Club"] = "ATTACK",
	["Shield"] = "BASH",
	["Gauntlets"] = "PUNCH",
	["Scythe"] = "ATTACK",
	["Katana"] = "ATTACK",
	["Hatchets"] = "CHOP",
	["Bow"] = "DRAW",
	["Crossbow"] = "FIRE",
	["Musket"] = "FIRE",
	["Pistol"] = "FIRE",
	["Blunderbuss"] = "FIRE",
	["Knives"] = "THROW",
	["Javelin"] = "THROW",
	["Sling"] = "SLING",
	["Bomb"] = "THROW",
	["Herbs"] = "HEAL",
	["Trap"] = "SET",
	["Horn"] = "BLOW"
}
local v_u_23 = {
	["Crossbow"] = true,
	["Musket"] = true,
	["Pistol"] = true,
	["Blunderbuss"] = true
}
local function v_u_26(p24, p25) -- name: secondaryFor
	-- upvalues: (copy) v_u_23
	if p24 then
		if p24 == "Bow" or (v_u_23[p24] or (p24 == "Knives" or p24 == "Sling")) then
			return "AIM", "toggle"
		elseif p24 == "Javelin" or p24 == "Bomb" then
			return "CANCEL", "tap"
		elseif p25.parry then
			return "PARRY", "hold"
		elseif p25.throw then
			return "THROW", "hold"
		elseif p25.block then
			return "BLOCK", "hold"
		elseif p25.heavy then
			return "HEAVY", "hold"
		elseif p25.lunge and (p25.lunge.charge or 0.6) <= 0 then
			return "DASH", "hold"
		elseif p25.lunge then
			return "LUNGE", "hold"
		else
			return nil, nil
		end
	else
		return nil, nil
	end
end
local function v_u_35(p27, p28, p29, p30, p31) -- name: makeButton
	-- upvalues: (copy) v_u_18, (copy) v_u_20, (copy) v_u_21
	local v32 = Instance.new("TextButton")
	v32.Name = p28
	v32.AnchorPoint = Vector2.new(0.5, 0.5)
	v32.Size = UDim2.fromOffset(p29, p29)
	v32.BackgroundColor3 = v_u_18
	v32.BackgroundTransparency = 0.3
	v32.AutoButtonColor = false
	v32.Text = p30
	v32.TextColor3 = v_u_20
	v32.TextSize = p31
	v32.FontFace = v_u_21
	v32.Active = true
	v32.Selectable = false
	local v33 = Instance.new("UICorner")
	v33.CornerRadius = UDim.new(1, 0)
	v33.Parent = v32
	local v34 = Instance.new("UIStroke")
	v34.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v34.Thickness = 2
	v34.Color = v_u_20
	v34.Transparency = 0.8
	v34.Parent = v32
	Instance.new("UIScale").Parent = v32
	v32.Parent = p27
	return v32
end
local function v_u_42(p36, p37) -- name: setPressedLook
	-- upvalues: (copy) v_u_19, (copy) v_u_18, (copy) v_u_17, (copy) v_u_20
	local v38
	if p37 then
		v38 = v_u_19
	else
		v38 = v_u_18
	end
	p36.BackgroundColor3 = v38
	p36.BackgroundTransparency = p37 and 0.12 or 0.3
	local v39 = p36:FindFirstChildOfClass("UIStroke")
	if v39 then
		local v40
		if p37 then
			v40 = v_u_17
		else
			v40 = v_u_20
		end
		v39.Color = v40
		v39.Thickness = p37 and 3 or 2
		v39.Transparency = p37 and 0 or 0.8
	end
	local v41 = p36:FindFirstChildOfClass("UIScale")
	if v41 then
		v41.Scale = p37 and 0.92 or 1
	end
end
local function v_u_53(p43, p44, p45, p46) -- name: readOverride
	local v47 = p43:GetAttribute("Override_" .. p44)
	if type(v47) ~= "string" then
		return nil, nil
	end
	local v48, v49, v50 = string.match(v47, "^(%-?%d+),(%-?%d+),(%d+)$")
	if not v48 then
		return nil, nil
	end
	local v51 = tonumber(v50) / 1000 * p46 + 0.5
	local v52 = math.floor(v51)
	return UDim2.fromOffset(tonumber(v48) / 1000 * p45.X, tonumber(v49) / 1000 * p45.Y), math.max(v52, 24)
end
local function v_u_62(p54) -- name: obstacle
	-- upvalues: (copy) v_u_6
	local v55 = p54.Y
	local v56 = p54.X
	local v57 = v_u_6:FindFirstChildOfClass("PlayerGui")
	if not v57 then
		return v55, v56
	end
	local v58 = v57:FindFirstChild("CharacterTouch")
	if v58 and (v58:IsA("ScreenGui") and v58.Enabled) then
		local v59 = v58:GetAttribute("ReservedMinY")
		if type(v59) == "number" and v59 > 0 then
			v55 = math.min(v55, v59)
		end
	end
	local v60 = v57:FindFirstChild("TouchGui")
	if v60 then
		v60 = v60:FindFirstChild("JumpButton", true)
	end
	if v60 and (v60:IsA("GuiObject") and (v60.Visible and v60.AbsoluteSize.X > 0)) then
		local v61 = v60.AbsolutePosition.Y
		v55 = math.min(v55, v61)
	end
	return v55, v56
end
local function v_u_91() -- name: layout
	-- upvalues: (ref) v_u_7, (ref) v_u_8, (copy) v_u_62, (copy) v_u_9, (copy) v_u_53
	local v63 = v_u_7
	local v64 = v_u_8
	if v63 and v64 then
		local v65 = v64.AbsolutePosition
		local v66 = v64.AbsoluteSize
		if v66.X >= 10 then
			local v67 = v65 + v66
			local v68 = v_u_62(v67)
			local v69 = v66.Y < 500
			local v70 = v69 and 92 or 100
			local v71 = v69 and 66 or 72
			local v72 = v69 and 58 or 62
			local v73 = v67.Y
			local v74 = math.min(v68, v73) - 12
			local v75 = v67.X - 22 - v70 / 2
			local v76 = v74 - v70 / 2
			local v77 = v65.Y + v70 / 2 + 70
			local v78 = math.max(v76, v77)
			local v79 = v_u_9.Attack
			v79.Size = UDim2.fromOffset(v70, v70)
			v79.Position = UDim2.fromOffset(v75 - v65.X, v78 - v65.Y)
			local v80 = v75 - v70 / 2 - 14 - v71 / 2
			local v81 = v_u_9.Secondary
			local v82 = v78 + (v70 - v71) / 2
			v81.Size = UDim2.fromOffset(v71, v71)
			v81.Position = UDim2.fromOffset(v80 - v65.X, v82 - v65.Y)
			local v83
			if v_u_9.Secondary.Visible then
				v83 = v80 - v71 / 2
			else
				v83 = v75 - v70 / 2
			end
			local v84 = v83 - 14 - v72 / 2
			local v85 = v_u_9.Reload
			local v86 = v78 + (v70 - v72) / 2
			v85.Size = UDim2.fromOffset(v72, v72)
			v85.Position = UDim2.fromOffset(v84 - v65.X, v86 - v65.Y)
			for v87, v88 in v_u_9 do
				v88:SetAttribute("DefaultSize", v88.Size.X.Offset)
				local v89, v90 = v_u_53(v63, v87, v66, v88.Size.X.Offset)
				if not (v89 and v90) then
					continue
				end
				v88.Position = v89
				v88.Size = UDim2.fromOffset(v90, v90)
			end
		end
	else
		return
	end
end
local function v_u_99() -- name: refresh
	-- upvalues: (ref) v_u_7, (copy) v_u_6, (ref) v_u_14, (ref) v_u_15, (copy) v_u_9, (copy) v_u_22, (ref) v_u_11, (copy) v_u_26, (ref) v_u_12, (ref) v_u_13, (copy) v_u_23, (copy) v_u_91
	local v92 = v_u_7
	if v92 then
		local v93 = v_u_6.Character
		if v93 then
			v93 = v93:FindFirstChildOfClass("Humanoid")
		end
		local v94
		if v93 == nil then
			v94 = false
		else
			v94 = v93.Health > 0
		end
		local v95 = v92:GetAttribute("EditPreview") == true
		if not v_u_14 and v92:GetAttribute("ForceVisible") ~= true or not (v_u_15 and v94) then
			v94 = v95
		end
		v92.Enabled = v94
		v_u_9.Attack.Text = v_u_22[v_u_11 or "Fists"] or "ATTACK"
		local v96 = v_u_26(v_u_11, v_u_12)
		v_u_9.Secondary.Visible = v96 ~= nil and true or v95
		v_u_9.Secondary.Text = v96 == "AIM" and v_u_13 and "AIM ON" or (v96 or (v95 and "ALT" or ""))
		local v97 = v_u_9.Reload
		if v_u_11 ~= nil and v_u_23[v_u_11] == true then
			local v98 = v_u_12.magazine
			v95 = (tonumber(v98) or 1) > 1 and true or v95
		end
		v97.Visible = v95
		if v92.Enabled then
			v_u_91()
		end
	end
end
local function v_u_113(p_u_100) -- name: bindAttack
	-- upvalues: (copy) v_u_4, (copy) v_u_19, (copy) v_u_17, (ref) v_u_10, (copy) v_u_3, (ref) v_u_16, (copy) v_u_18, (copy) v_u_20
	local v_u_101 = nil
	p_u_100.InputBegan:Connect(function(p102)
		-- upvalues: (ref) v_u_101, (ref) v_u_4, (copy) p_u_100, (ref) v_u_19, (ref) v_u_17, (ref) v_u_10
		if p102.UserInputType == Enum.UserInputType.Touch and (not v_u_101 and v_u_4.BeganOn(p_u_100, p102)) then
			v_u_101 = p102
			local v103 = p_u_100
			v103.BackgroundColor3 = v_u_19
			v103.BackgroundTransparency = 0.12
			local v104 = v103:FindFirstChildOfClass("UIStroke")
			if v104 then
				v104.Color = v_u_17
				v104.Thickness = 3
				v104.Transparency = 0
			end
			local v105 = v103:FindFirstChildOfClass("UIScale")
			if v105 then
				v105.Scale = 0.92
			end
			if v_u_10 then
				v_u_10("Primary", true)
			end
		end
	end)
	v_u_3.TouchMoved:Connect(function(p106)
		-- upvalues: (ref) v_u_101, (ref) v_u_16, (ref) v_u_3
		if p106 == v_u_101 and (v_u_16 and not v_u_3.MouseEnabled) then
			local v_u_107 = p106.Delta
			local function v108()
				-- upvalues: (ref) v_u_16, (copy) v_u_107
				v_u_16.AddTouchLook(Vector2.new(v_u_107.X, v_u_107.Y))
			end
			if not pcall(v108) then
				v_u_16 = nil
			end
		end
	end)
	v_u_3.TouchEnded:Connect(function(p109)
		-- upvalues: (ref) v_u_101, (copy) p_u_100, (ref) v_u_18, (ref) v_u_20, (ref) v_u_10
		if p109 == v_u_101 then
			v_u_101 = nil
			local v110 = p_u_100
			v110.BackgroundColor3 = v_u_18
			v110.BackgroundTransparency = 0.3
			local v111 = v110:FindFirstChildOfClass("UIStroke")
			if v111 then
				v111.Color = v_u_20
				v111.Thickness = 2
				v111.Transparency = 0.8
			end
			local v112 = v110:FindFirstChildOfClass("UIScale")
			if v112 then
				v112.Scale = 1
			end
			if v_u_10 then
				v_u_10("Primary", false)
			end
		end
	end)
end
local function v_u_126(p_u_114) -- name: bindSecondary
	-- upvalues: (copy) v_u_4, (copy) v_u_26, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (copy) v_u_42, (ref) v_u_10, (copy) v_u_99, (copy) v_u_19, (copy) v_u_17, (copy) v_u_3, (copy) v_u_18, (copy) v_u_20
	local v_u_115 = nil
	p_u_114.InputBegan:Connect(function(p116)
		-- upvalues: (ref) v_u_115, (ref) v_u_4, (copy) p_u_114, (ref) v_u_26, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_42, (ref) v_u_10, (ref) v_u_99, (ref) v_u_19, (ref) v_u_17
		if p116.UserInputType == Enum.UserInputType.Touch and (not v_u_115 and v_u_4.BeganOn(p_u_114, p116)) then
			local _, v117 = v_u_26(v_u_11, v_u_12)
			if v117 == "toggle" then
				v_u_13 = not v_u_13
				v_u_42(p_u_114, v_u_13)
				local v118 = v_u_13
				if v_u_10 then
					v_u_10("Secondary", v118)
				end
				v_u_99()
			elseif v117 == "tap" then
				if v_u_10 then
					v_u_10("Secondary", true)
				end
				if v_u_10 then
					v_u_10("Secondary", false)
					return
				end
			elseif v117 == "hold" then
				v_u_115 = p116
				local v119 = p_u_114
				v119.BackgroundColor3 = v_u_19
				v119.BackgroundTransparency = 0.12
				local v120 = v119:FindFirstChildOfClass("UIStroke")
				if v120 then
					v120.Color = v_u_17
					v120.Thickness = 3
					v120.Transparency = 0
				end
				local v121 = v119:FindFirstChildOfClass("UIScale")
				if v121 then
					v121.Scale = 0.92
				end
				if v_u_10 then
					v_u_10("Secondary", true)
				end
			end
		else
			return
		end
	end)
	v_u_3.TouchEnded:Connect(function(p122)
		-- upvalues: (ref) v_u_115, (copy) p_u_114, (ref) v_u_18, (ref) v_u_20, (ref) v_u_10
		if p122 == v_u_115 then
			v_u_115 = nil
			local v123 = p_u_114
			v123.BackgroundColor3 = v_u_18
			v123.BackgroundTransparency = 0.3
			local v124 = v123:FindFirstChildOfClass("UIStroke")
			if v124 then
				v124.Color = v_u_20
				v124.Thickness = 2
				v124.Transparency = 0.8
			end
			local v125 = v123:FindFirstChildOfClass("UIScale")
			if v125 then
				v125.Scale = 1
			end
			if v_u_10 then
				v_u_10("Secondary", false)
			end
		end
	end)
end
function v5.SetWeapon(p127, p128) -- name: SetWeapon
	-- upvalues: (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (copy) v_u_9, (copy) v_u_18, (copy) v_u_20, (copy) v_u_99
	v_u_11 = p127
	v_u_12 = p128 or {}
	v_u_13 = false
	if v_u_9.Secondary then
		local v129 = v_u_9.Secondary
		v129.BackgroundColor3 = v_u_18
		v129.BackgroundTransparency = 0.3
		local v130 = v129:FindFirstChildOfClass("UIStroke")
		if v130 then
			v130.Color = v_u_20
			v130.Thickness = 2
			v130.Transparency = 0.8
		end
		local v131 = v129:FindFirstChildOfClass("UIScale")
		if v131 then
			v131.Scale = 1
		end
	end
	v_u_99()
end
function v5.SetVisible(p132) -- name: SetVisible
	-- upvalues: (ref) v_u_15, (copy) v_u_99
	if p132 ~= v_u_15 then
		v_u_15 = p132
		v_u_99()
	end
end
function v5.IsActive() -- name: IsActive
	-- upvalues: (ref) v_u_14
	return v_u_14
end
local function v_u_136(p133) -- name: updateActive
	-- upvalues: (copy) v_u_3, (ref) v_u_14, (copy) v_u_99
	local v134 = p133 or v_u_3:GetLastInputType()
	local v135
	if v134 == Enum.UserInputType.Touch then
		v135 = true
	elseif v134 == Enum.UserInputType.MouseButton1 or (v134 == Enum.UserInputType.MouseMovement or (v134 == Enum.UserInputType.Keyboard or string.find(v134.Name, "Gamepad"))) then
		v135 = false
	else
		v135 = v_u_3.TouchEnabled
		if v135 then
			v135 = not v_u_3.MouseEnabled
		end
	end
	if v135 ~= v_u_14 then
		v_u_14 = v135
		v_u_99()
	end
end
function v5.Start(p137) -- name: Start
	-- upvalues: (ref) v_u_7, (ref) v_u_10, (ref) v_u_16, (copy) v_u_6, (ref) v_u_8, (copy) v_u_9, (copy) v_u_35, (copy) v_u_113, (copy) v_u_126, (copy) v_u_4, (copy) v_u_19, (copy) v_u_17, (copy) v_u_18, (copy) v_u_20, (copy) v_u_99, (copy) v_u_136, (copy) v_u_3, (copy) v_u_91, (ref) v_u_13
	if not v_u_7 then
		v_u_10 = p137
		task.spawn(function()
			-- upvalues: (ref) v_u_16
			local v138, v139 = pcall(function()
				return require((game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Camera", 10)))
			end)
			if not v138 or (type(v139) ~= "table" or not (v139.SetLook and v139.GetYaw)) then
				v139 = nil
			end
			v_u_16 = v139
		end)
		local v_u_140 = Instance.new("ScreenGui")
		v_u_140.Name = "CombatTouch"
		v_u_140.ResetOnSpawn = false
		v_u_140.IgnoreGuiInset = true
		v_u_140.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
		v_u_140.DisplayOrder = 5
		v_u_140.Enabled = false
		v_u_140.Parent = v_u_6:WaitForChild("PlayerGui")
		v_u_7 = v_u_140
		local v141 = Instance.new("Frame")
		v141.Name = "Root"
		v141.BackgroundTransparency = 1
		v141.Size = UDim2.fromScale(1, 1)
		v141.Parent = v_u_140
		v_u_8 = v141
		v_u_9.Attack = v_u_35(v141, "Attack", 96, "ATTACK", 16)
		v_u_9.Secondary = v_u_35(v141, "Secondary", 70, "BLOCK", 14)
		v_u_9.Reload = v_u_35(v141, "Reload", 60, "RELOAD", 12)
		v_u_113(v_u_9.Attack)
		v_u_126(v_u_9.Secondary)
		v_u_9.Reload.InputBegan:Connect(function(p142)
			-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_19, (ref) v_u_17, (ref) v_u_10, (ref) v_u_18, (ref) v_u_20
			if p142.UserInputType == Enum.UserInputType.Touch and v_u_4.BeganOn(v_u_9.Reload, p142) then
				local v143 = v_u_9.Reload
				v143.BackgroundColor3 = v_u_19
				v143.BackgroundTransparency = 0.12
				local v144 = v143:FindFirstChildOfClass("UIStroke")
				if v144 then
					v144.Color = v_u_17
					v144.Thickness = 3
					v144.Transparency = 0
				end
				local v145 = v143:FindFirstChildOfClass("UIScale")
				if v145 then
					v145.Scale = 0.92
				end
				if v_u_10 then
					v_u_10("Reload", true)
				end
				if v_u_10 then
					v_u_10("Reload", false)
				end
				task.delay(0.12, function()
					-- upvalues: (ref) v_u_9, (ref) v_u_18, (ref) v_u_20
					local v146 = v_u_9.Reload
					v146.BackgroundColor3 = v_u_18
					v146.BackgroundTransparency = 0.3
					local v147 = v146:FindFirstChildOfClass("UIStroke")
					if v147 then
						v147.Color = v_u_20
						v147.Thickness = 2
						v147.Transparency = 0.8
					end
					local v148 = v146:FindFirstChildOfClass("UIScale")
					if v148 then
						v148.Scale = 1
					end
				end)
			end
		end)
		v_u_140:GetAttributeChangedSignal("ForceVisible"):Connect(v_u_99)
		v_u_140.AttributeChanged:Connect(function(p149)
			-- upvalues: (ref) v_u_99
			if p149 == "EditPreview" or string.sub(p149, 1, 9) == "Override_" then
				v_u_99()
			end
		end)
		v_u_136(nil)
		v_u_3.LastInputTypeChanged:Connect(v_u_136)
		v141:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
			-- upvalues: (copy) v_u_140, (ref) v_u_91
			if v_u_140.Enabled then
				v_u_91()
			end
		end)
		v_u_6.CharacterAdded:Connect(function(p150)
			-- upvalues: (ref) v_u_13, (ref) v_u_99
			v_u_13 = false
			local v151 = p150:WaitForChild("Humanoid", 10)
			if v151 then
				v151.Died:Connect(v_u_99)
			end
			v_u_99()
		end)
		task.spawn(function()
			-- upvalues: (copy) v_u_140, (ref) v_u_91
			while v_u_140.Parent do
				task.wait(1.5)
				if not v_u_140.Enabled then
					continue
				end
				v_u_91()
			end
		end)
		v_u_99()
	end
end
return v5