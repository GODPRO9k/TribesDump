local v_u_1 = game:GetService("ContentProvider")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game:GetService("Workspace")
local v7 = {}
local v_u_8 = v3.LocalPlayer
local v_u_9 = {
	{
		["height"] = 16,
		["tile"] = 34,
		["speed"] = 0.045,
		["transparency"] = 0.3
	},
	{
		["height"] = 10.5,
		["tile"] = 21,
		["speed"] = -0.07,
		["transparency"] = 0.38
	}
}
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = {}
local v_u_13 = {}
local v_u_14 = {}
local v_u_15 = {}
local v_u_16 = {}
local v_u_17 = {}
local v_u_18 = {}
local v_u_19 = {}
local v_u_20 = nil
local v_u_21 = {}
local v_u_22 = false
local v_u_23 = -1
local v_u_24 = 0
local v_u_25 = 0
local v_u_26 = -1
local v_u_27 = -1
local v_u_28 = nil
local v_u_29 = false
local v_u_30 = RaycastParams.new()
v_u_30.FilterType = Enum.RaycastFilterType.Include
v_u_30.RespectCanCollide = true
local v_u_31 = "pending"
local function v_u_36() -- name: styleBeams
	-- upvalues: (copy) v_u_17, (ref) v_u_31, (copy) v_u_15, (copy) v_u_16
	for v32, v33 in v_u_17 do
		local v34 = v33.visible
		if v34 then
			v34 = v_u_31 == "ok"
		end
		for _, v35 in v_u_15 do
			v35[v32].Enabled = v34
		end
		v_u_16[v32].Enabled = v33.visible
	end
end
local function v_u_52(p37) -- name: makeSegment
	local v38 = Instance.new("Part")
	v38.Name = "RingSegment"
	v38.Anchored = true
	v38.CanCollide = false
	v38.CanQuery = false
	v38.CanTouch = false
	v38.CastShadow = false
	v38.Transparency = 1
	v38.Size = Vector3.new(8, 1, 1.5)
	local v39 = {
		["Name"] = "Licks",
		["Texture"] = "rbxassetid://109193145976179",
		["Shape"] = nil,
		["EmissionDirection"] = nil,
		["Orientation"] = nil,
		["Color"] = nil,
		["Transparency"] = nil,
		["Size"] = nil,
		["Squash"] = nil,
		["Lifetime"] = nil,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Rotation"] = nil,
		["RotSpeed"] = nil,
		["Drag"] = 1,
		["LightEmission"] = 0.35,
		["LightInfluence"] = 0,
		["ZOffset"] = 1,
		["Shape"] = Enum.ParticleEmitterShape.Box,
		["EmissionDirection"] = Enum.NormalId.Top,
		["Orientation"] = Enum.ParticleOrientation.FacingCameraWorldUp,
		["Color"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 236, 214)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 190, 150)), ColorSequenceKeypoint.new(1, Color3.fromRGB(220, 120, 90)) }),
		["Transparency"] = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 0.5),
			NumberSequenceKeypoint.new(0.18, 0.05),
			NumberSequenceKeypoint.new(0.7, 0.25),
			NumberSequenceKeypoint.new(1, 1)
		}),
		["Size"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 4), NumberSequenceKeypoint.new(0.35, 7, 1.5), NumberSequenceKeypoint.new(1, 2.5) }),
		["Squash"] = NumberSequence.new(-0.35),
		["Lifetime"] = NumberRange.new(0.8, 1.25),
		["Speed"] = NumberRange.new(6, 10),
		["SpreadAngle"] = Vector2.new(5, 5),
		["Rotation"] = NumberRange.new(-8, 8),
		["RotSpeed"] = NumberRange.new(-10, 10)
	}
	local v40 = Instance.new("ParticleEmitter")
	for v41, v42 in v39 do
		v40[v41] = v42
	end
	v40.Parent = v38
	local v43 = {
		["Name"] = "Embers",
		["Shape"] = nil,
		["EmissionDirection"] = nil,
		["Color"] = nil,
		["Transparency"] = nil,
		["Size"] = nil,
		["Lifetime"] = nil,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Acceleration"] = Vector3.new(0, 1.5, 0),
		["Drag"] = 0.6,
		["LightEmission"] = 0.4,
		["LightInfluence"] = 0,
		["Shape"] = Enum.ParticleEmitterShape.Box,
		["EmissionDirection"] = Enum.NormalId.Top,
		["Color"] = ColorSequence.new(Color3.fromRGB(255, 150, 60), Color3.fromRGB(230, 70, 30)),
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.8, 0.2), NumberSequenceKeypoint.new(1, 1) }),
		["Size"] = NumberSequence.new(0.25, 0.08),
		["Lifetime"] = NumberRange.new(1.6, 2.8),
		["Speed"] = NumberRange.new(10, 18),
		["SpreadAngle"] = Vector2.new(22, 22)
	}
	local v44 = Instance.new("ParticleEmitter")
	for v45, v46 in v43 do
		v44[v45] = v46
	end
	v44.Parent = v38
	local v47 = Instance.new("Part")
	v47.Name = "RingSmoke"
	v47.Anchored = true
	v47.CanCollide = false
	v47.CanQuery = false
	v47.CanTouch = false
	v47.CastShadow = false
	v47.Transparency = 1
	v47.Size = Vector3.new(8, 1, 1.5)
	local v48 = {
		["Name"] = "Smoke",
		["Texture"] = "rbxassetid://8030839542",
		["Shape"] = nil,
		["EmissionDirection"] = nil,
		["Color"] = nil,
		["Transparency"] = nil,
		["Size"] = nil,
		["Lifetime"] = nil,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Rotation"] = nil,
		["RotSpeed"] = nil,
		["Drag"] = 0.35,
		["LightEmission"] = 0,
		["LightInfluence"] = 1,
		["ZOffset"] = -1,
		["Shape"] = Enum.ParticleEmitterShape.Box,
		["EmissionDirection"] = Enum.NormalId.Top,
		["Color"] = ColorSequence.new(Color3.fromRGB(70, 55, 48), Color3.fromRGB(46, 40, 38)),
		["Transparency"] = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.15, 0.55),
			NumberSequenceKeypoint.new(0.7, 0.7),
			NumberSequenceKeypoint.new(1, 1)
		}),
		["Size"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 7), NumberSequenceKeypoint.new(1, 16) }),
		["Lifetime"] = NumberRange.new(2.6, 3.6),
		["Speed"] = NumberRange.new(5, 7),
		["SpreadAngle"] = Vector2.new(12, 12),
		["Rotation"] = NumberRange.new(-180, 180),
		["RotSpeed"] = NumberRange.new(-15, 15)
	}
	local v49 = Instance.new("ParticleEmitter")
	for v50, v51 in v48 do
		v49[v50] = v51
	end
	v49.Parent = v47
	v38.Parent = p37
	v47.Parent = p37
	return {
		["part"] = nil,
		["smokePart"] = nil,
		["licks"] = nil,
		["embers"] = nil,
		["smoke"] = nil,
		["visible"] = true,
		["part"] = v38,
		["smokePart"] = v47,
		["licks"] = v40,
		["embers"] = v44,
		["smoke"] = v49
	}
end
local function v_u_53() -- name: clear
	-- upvalues: (ref) v_u_10, (ref) v_u_11, (copy) v_u_12, (copy) v_u_13, (copy) v_u_14, (copy) v_u_15, (copy) v_u_16, (copy) v_u_17, (copy) v_u_18, (copy) v_u_19, (ref) v_u_23, (ref) v_u_27, (ref) v_u_26
	if v_u_10 then
		v_u_10:Destroy()
	end
	v_u_10 = nil
	v_u_11 = nil
	table.clear(v_u_12)
	table.clear(v_u_13)
	table.clear(v_u_14)
	table.clear(v_u_15)
	table.clear(v_u_16)
	table.clear(v_u_17)
	table.clear(v_u_18)
	table.clear(v_u_19)
	v_u_23 = -1
	v_u_27 = -1
	v_u_26 = -1
end
local function v_u_81(p54, p55) -- name: build
	-- upvalues: (ref) v_u_11, (copy) v_u_9, (copy) v_u_12, (copy) v_u_14, (copy) v_u_15, (copy) v_u_13, (copy) v_u_16, (copy) v_u_17, (copy) v_u_52, (copy) v_u_18, (copy) v_u_19, (copy) v_u_6, (ref) v_u_10, (copy) v_u_36
	local v56 = Instance.new("Folder")
	v56.Name = "CoreRingOfFire"
	local v57 = Instance.new("Part")
	v57.Name = "RingAnchor"
	v57.Anchored = true
	v57.CanCollide = false
	v57.CanQuery = false
	v57.CanTouch = false
	v57.CastShadow = false
	v57.Transparency = 1
	v57.Size = Vector3.new(8, 1, 1.5)
	v57.Size = Vector3.new(1, 1, 1)
	v57.CFrame = CFrame.new(p55)
	v57.Parent = v56
	v_u_11 = v57
	for v58, v59 in v_u_9 do
		local v60 = {}
		for v61 = 1, p54 do
			local v62 = Instance.new("Attachment")
			v62.Name = ("L%*_%*"):format(v58, v61)
			v62.Parent = v57
			v60[v61] = v62
		end
		v_u_12[v58] = v60
		local v63 = {}
		for v64 = 1, p54 do
			local v65 = v60[v64]
			local v66 = v60[v64 % p54 + 1]
			local v67 = ("Wall%*_%*"):format(v58, v64)
			local v68 = Instance.new("Beam")
			v68.Name = v67
			v68.Attachment0 = v65
			v68.Attachment1 = v66
			v68.FaceCamera = false
			v68.Segments = 1
			v68.Width0 = v59.height
			v68.Width1 = v59.height
			v68.Texture = "rbxassetid://82559613851503"
			v68.TextureMode = Enum.TextureMode.Wrap
			v68.TextureLength = v59.tile
			v68.TextureSpeed = v59.speed
			v68.Color = ColorSequence.new(Color3.fromRGB(255, 240, 228))
			v68.Transparency = NumberSequence.new(v59.transparency)
			v68.LightEmission = 0.25
			v68.LightInfluence = 0
			v68.Brightness = 1
			v68.ZOffset = v58 - 1
			v68.Enabled = false
			v68.Parent = v57
			v63[v64] = v68
			local v69 = v_u_14
			table.insert(v69, v68)
		end
		v_u_15[v58] = v63
	end
	for v70 = 1, p54 do
		local v71 = Instance.new("Attachment")
		v71.Name = ("S_%*"):format(v70)
		v71.Parent = v57
		v_u_13[v70] = v71
	end
	for v72 = 1, p54 do
		local v73 = v_u_13[v72]
		local v74 = v_u_13[v72 % p54 + 1]
		local v75 = ("Scorch%*"):format(v72)
		local v76 = Instance.new("Beam")
		v76.Name = v75
		v76.Attachment0 = v73
		v76.Attachment1 = v74
		v76.FaceCamera = false
		v76.Segments = 1
		v76.Width0 = 3
		v76.Width1 = 3
		v76.Color = ColorSequence.new(Color3.fromRGB(36, 28, 25))
		v76.Transparency = NumberSequence.new(0.12)
		v76.LightEmission = 0
		v76.LightInfluence = 1
		v76.Parent = v57
		v_u_16[v72] = v76
	end
	for _ = 1, p54 do
		local v77 = v_u_17
		local v78 = v_u_52(v56)
		table.insert(v77, v78)
		local v79 = v_u_18
		table.insert(v79, 0)
		local v80 = v_u_19
		table.insert(v80, false)
	end
	v56.Parent = v_u_6
	v_u_10 = v56
	v_u_36()
end
local function v_u_96(p82) -- name: currentRadius
	-- upvalues: (copy) v_u_6
	local v83 = p82:GetAttribute("RingRadius")
	local v84 = (type(v83) ~= "number" or v83 ~= v83) and 0 or v83
	if v84 <= 0 then
		return 0
	end
	local v85 = p82:GetAttribute("RingStartRadius")
	if type(v85) ~= "number" or v85 ~= v85 then
		v85 = v84
	end
	local v86 = p82:GetAttribute("RingMinRadius")
	if type(v86) ~= "number" or v86 ~= v86 then
		v86 = v84
	end
	local v87 = p82:GetAttribute("RingShrinkStart")
	local v88 = (type(v87) ~= "number" or v87 ~= v87) and 0 or v87
	local v89 = p82:GetAttribute("RingShrinkEnd")
	local v90 = (type(v89) ~= "number" or v89 ~= v89) and 0 or v89
	if v88 >= v90 then
		return v84
	end
	local v91 = (v_u_6:GetServerTimeNow() - v88) / (v90 - v88)
	local v92 = math.clamp(v91, 0, 1)
	local v93 = v85 + (v86 - v85) * v92
	local v94 = v84 - 3
	local v95 = v84 + 3
	return math.clamp(v93, v94, v95)
end
local function v_u_106(p97) -- name: setTint
	-- upvalues: (ref) v_u_29, (ref) v_u_28, (copy) v_u_2, (copy) v_u_5
	if p97 ~= v_u_29 then
		v_u_29 = p97
		if not v_u_28 then
			local v98 = Instance.new("ColorCorrectionEffect")
			v98.Name = "CoreRingHeat"
			v98.TintColor = Color3.new(1, 1, 1)
			v98.Enabled = false
			v98.Parent = v_u_2
			v_u_28 = v98
		end
		local v_u_99 = v_u_28
		v_u_99.Enabled = true
		local v100 = v_u_5
		local v101 = TweenInfo.new(0.4)
		local v102 = {}
		local v103
		if p97 then
			v103 = Color3.fromRGB(255, 226, 206)
		else
			v103 = Color3.new(1, 1, 1)
		end
		v102.TintColor = v103
		v102.Saturation = p97 and 0.08 or 0
		local v104 = v100:Create(v_u_99, v101, v102)
		v104.Completed:Connect(function(p105)
			-- upvalues: (ref) v_u_29, (copy) v_u_99
			if p105 == Enum.PlaybackState.Completed and not v_u_29 then
				v_u_99.Enabled = false
			end
		end)
		v104:Play()
	end
end
local function v_u_117(p107, p108, p109) -- name: sampleGround
	-- upvalues: (copy) v_u_6, (copy) v_u_30
	local v110 = v_u_6
	local v111 = p107.Y + 110
	local v112 = v110:Raycast(Vector3.new(p108, v111, p109), Vector3.new(0, -150, 0), v_u_30)
	if not v112 then
		return 0, false
	end
	local v113 = v112.Position.Y - p107.Y
	if v113 <= 6 then
		return math.max(v113, -12), false
	end
	local v114 = v112.Instance
	if v114:IsA("BasePart") and v112.Normal.Y > 0.8 then
		local v115 = v114.Size
		local v116 = { v115.X, v115.Y, v115.Z }
		table.sort(v116)
		if v116[2] >= 14 then
			return v113, false
		end
	end
	return v113, true
end
local function v_u_132(p118, p119, p120, p121) -- name: sampleAll
	-- upvalues: (copy) v_u_30, (copy) v_u_117, (copy) v_u_18, (copy) v_u_19
	local v122 = p118:FindFirstChild("Map")
	v_u_30.FilterDescendantsInstances = v122 and { v122 } or {}
	local v123 = table.create(p121, false)
	for v124 = 1, p121 do
		local v125 = (v124 - 1) / p121 * 2 * 3.141592653589793
		local v126, v127 = v_u_117(p119, p119.X + math.cos(v125) * p120, p119.Z + math.sin(v125) * p120)
		v_u_18[v124] = v126
		v123[v124] = v127
	end
	for v128 = 1, p121 do
		local v129 = (v128 - 0.5) / p121 * 2 * 3.141592653589793
		local _, v130 = v_u_117(p119, p119.X + math.cos(v129) * p120, p119.Z + math.sin(v129) * p120)
		local v131 = v128 % p121 + 1
		v_u_19[v128] = v130 or (v123[v128] or v123[v131])
	end
end
local function v_u_211(p133, p134, p135) -- name: layout
	-- upvalues: (ref) v_u_10, (copy) v_u_53, (copy) v_u_81, (copy) v_u_17, (ref) v_u_11, (ref) v_u_25, (ref) v_u_26, (copy) v_u_132, (copy) v_u_19, (copy) v_u_36, (copy) v_u_9, (copy) v_u_12, (copy) v_u_18, (copy) v_u_13, (copy) v_u_6, (ref) v_u_27, (copy) v_u_8, (copy) v_u_106
	local v136 = p133:GetAttribute("RingCenterX")
	local v137 = (type(v136) ~= "number" or v136 ~= v136) and 0 or v136
	local v138 = p133:GetAttribute("RingCenterY")
	local v139 = (type(v138) ~= "number" or v138 ~= v138) and 0 or v138
	local v140 = p133:GetAttribute("RingCenterZ")
	local v141 = (type(v140) ~= "number" or v140 ~= v140) and 0 or v140
	local v142 = Vector3.new(v137, v139, v141)
	if not (v_u_10 and v_u_10.Parent) then
		v_u_53()
		local v143 = p133:GetAttribute("RingStartRadius")
		if type(v143) ~= "number" or v143 ~= v143 then
			v143 = p134
		end
		local v144 = 6.283185307179586 * math.max(p134, v143) / 10 + 0.5
		local v145 = math.floor(v144)
		v_u_81(math.clamp(v145, 16, 48), v142)
		p135 = true
	end
	local v146 = #v_u_17
	local v147 = v_u_11
	if (v147.Position - v142).Magnitude > 0.01 then
		v147.CFrame = CFrame.new(v142)
	end
	local v148 = os.clock()
	local v149
	if v148 - v_u_25 >= 0.1 then
		local v150 = p134 - v_u_26
		v149 = math.abs(v150) > 0.25 and true or v148 - v_u_25 >= 1
	else
		v149 = false
	end
	if p135 or v149 then
		v_u_25 = v148
		v_u_26 = p134
		v_u_132(p133, v142, p134, v146)
		local v151 = false
		for v152, v153 in v_u_17 do
			local v154 = not v_u_19[v152]
			if v153.visible == v154 then
				continue
			end
			v153.visible = v154
			v153.licks.Enabled = v154
			v153.embers.Enabled = v154
			v153.smoke.Enabled = v154
			v151 = true
		end
		if v151 or p135 then
			v_u_36()
		end
	end
	for v155, v156 in v_u_9 do
		local v157 = v_u_12[v155]
		local v158 = v156.height * 0.5 - 0.6
		for v159 = 1, v146 do
			local v160 = (v159 - 1) / v146 * 2 * 3.141592653589793
			local v161 = math.cos(v160)
			local v162 = math.sin(v160)
			local v163 = v157[v159]
			local v164 = CFrame.fromMatrix
			local v165 = v161 * p134
			local v166 = v_u_18[v159] + v158
			local v167 = v162 * p134
			local v168 = Vector3.new(v165, v166, v167)
			local v169 = -v162
			v163.CFrame = v164(v168, Vector3.new(v169, 0, v161), Vector3.new(0, 1, 0))
		end
	end
	local v170 = p134 + 1.5 + 0.3
	for v171 = 1, v146 do
		local v172 = (v171 - 1) / v146 * 2 * 3.141592653589793
		local v173 = math.cos(v172)
		local v174 = math.sin(v172)
		local v175 = v_u_13[v171]
		local v176 = CFrame.fromMatrix
		local v177 = v173 * v170
		local v178 = v_u_18[v171] + 0.12
		local v179 = v174 * v170
		local v180 = Vector3.new(v177, v178, v179)
		local v181 = -v174
		v175.CFrame = v176(v180, Vector3.new(v181, 0, v173), (Vector3.new(v173, 0, v174)))
	end
	local v182 = p134 * 2
	local v183 = 3.141592653589793 / v146
	local v184 = v182 * math.sin(v183)
	local v185 = 3.141592653589793 / v146
	local v186 = p134 * math.cos(v185)
	local v187 = table.create(v146 * 2)
	local v188 = table.create(v146 * 2)
	for v189, v190 in v_u_17 do
		local v191 = (v189 - 0.5) / v146 * 2 * 3.141592653589793
		local v192 = math.cos(v191)
		local v193 = math.sin(v191)
		local v194 = (v_u_18[v189] + v_u_18[v189 % v146 + 1]) * 0.5
		local v195 = v192 * v186
		local v196 = v194 + 0.6
		local v197 = v193 * v186
		local v198 = v142 + Vector3.new(v195, v196, v197)
		local v199 = CFrame.fromMatrix
		local v200 = -v193
		local v201 = v199(Vector3.new(0, 0, 0), Vector3.new(v200, 0, v192), Vector3.new(0, 1, 0))
		local v202 = v190.part
		table.insert(v187, v202)
		local v203 = v201 + v198
		table.insert(v188, v203)
		local v204 = v190.smokePart
		table.insert(v187, v204)
		local v205 = v201 + v198 + Vector3.new(0, 11, 0)
		table.insert(v188, v205)
	end
	v_u_6:BulkMoveTo(v187, v188, Enum.BulkMoveMode.FireCFrameChanged)
	local v206 = v184 - v_u_27
	if math.abs(v206) > 0.4 then
		v_u_27 = v184
		for _, v207 in v_u_17 do
			v207.part.Size = Vector3.new(v184, 1, 1.5)
			v207.smokePart.Size = Vector3.new(v184, 1, 2)
			v207.licks.Rate = v184 * 0.8
			v207.embers.Rate = v184 * 0.08
			v207.smoke.Rate = v184 * 0.12
		end
	end
	local v208 = v_u_8.Character
	if v208 then
		v208 = v208:FindFirstChild("HumanoidRootPart")
	end
	if v208 and v208:IsA("BasePart") then
		local v209 = v_u_106
		local v210
		if p134 < Vector2.new(v208.Position.X - v142.X, v208.Position.Z - v142.Z).Magnitude then
			v210 = v_u_8:GetAttribute("Alive") == true
		else
			v210 = false
		end
		v209(v210)
	end
end
local function v_u_217() -- name: step
	-- upvalues: (ref) v_u_20, (copy) v_u_96, (ref) v_u_22, (copy) v_u_53, (copy) v_u_106, (ref) v_u_23, (ref) v_u_24, (copy) v_u_211
	local v212 = v_u_20
	local v213 = not (v212 and v212.Parent) and 0 or v_u_96(v212)
	if v213 <= 0 or not v212 then
		if v_u_22 then
			v_u_22 = false
			v_u_53()
			v_u_106(false)
		end
		return
	else
		v_u_22 = true
		local v214 = os.clock()
		local v215 = v213 - v_u_23
		local v216 = math.abs(v215) >= 0.05
		if v214 - v_u_24 >= (v216 and 0.03333333333333333 or 0.1) then
			v_u_24 = v214
			v_u_23 = v213
			v_u_211(v212, v213, false)
		end
	end
end
local function v_u_226() -- name: bindArena
	-- upvalues: (copy) v_u_21, (ref) v_u_20, (copy) v_u_53, (ref) v_u_22, (copy) v_u_106, (copy) v_u_8, (copy) v_u_6
	for _, v218 in v_u_21 do
		v218:Disconnect()
	end
	table.clear(v_u_21)
	v_u_20 = nil
	v_u_53()
	v_u_22 = false
	v_u_106(false)
	local v_u_219
	if v_u_8:GetAttribute("State") == "Match" then
		v_u_219 = v_u_8:GetAttribute("MatchId")
	else
		v_u_219 = v_u_8:GetAttribute("Spectating")
	end
	if type(v_u_219) == "string" and v_u_219 ~= "" then
		local v220 = v_u_6:FindFirstChild("Arenas")
		local v221
		if v220 then
			v221 = v220:FindFirstChild(v_u_219)
		else
			v221 = v220
		end
		if v221 then
			v_u_20 = v221
		elseif v220 then
			local v222 = v_u_21
			local v223 = v220.ChildAdded
			local function v225(p224)
				-- upvalues: (copy) v_u_219, (ref) v_u_20
				if p224.Name == v_u_219 then
					v_u_20 = p224
				end
			end
			table.insert(v222, v223:Connect(v225))
		end
	else
		return
	end
end
function v7.Start() -- name: Start
	-- upvalues: (ref) v_u_31, (copy) v_u_1, (copy) v_u_4, (copy) v_u_36, (copy) v_u_8, (copy) v_u_226, (copy) v_u_6, (ref) v_u_20, (ref) v_u_22, (copy) v_u_217
	task.spawn(function()
		-- upvalues: (ref) v_u_31, (ref) v_u_1, (ref) v_u_4, (ref) v_u_36
		local v227 = 0
		while v_u_31 ~= "ok" do
			local v_u_228 = {}
			local v_u_229 = nil
			for _, v230 in { "rbxassetid://82559613851503", "rbxassetid://109193145976179" } do
				local v231 = Instance.new("Beam")
				v231.Texture = v230
				table.insert(v_u_228, v231)
			end
			local function v234()
				-- upvalues: (ref) v_u_1, (copy) v_u_228, (ref) v_u_229
				v_u_1:PreloadAsync(v_u_228, function(p232, p233)
					-- upvalues: (ref) v_u_229
					if p232 == "rbxassetid://82559613851503" then
						v_u_229 = p233
					end
				end)
			end
			pcall(v234)
			for _, v235 in v_u_228 do
				v235:Destroy()
			end
			v227 = v227 + 1
			if v_u_229 == Enum.AssetFetchStatus.Success then
				v_u_31 = "ok"
			elseif v227 == 3 then
				v_u_31 = "failed"
				if v_u_4:IsStudio() then
					print("[RingOfFire] wall texture not loaded yet; the ring shows particles until it does")
				end
			end
			v_u_36()
			if v_u_31 == "ok" then
				break
			end
			local v236 = task.wait
			local v237 = v227 * 3
			v236((math.min(30, v237)))
		end
	end)
	v_u_8:GetAttributeChangedSignal("MatchId"):Connect(v_u_226)
	v_u_8:GetAttributeChangedSignal("State"):Connect(v_u_226)
	v_u_8:GetAttributeChangedSignal("Spectating"):Connect(v_u_226)
	task.spawn(function()
		-- upvalues: (ref) v_u_6, (ref) v_u_226
		v_u_6:WaitForChild("Arenas", 60)
		v_u_226()
	end)
	v_u_4.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_20, (ref) v_u_22, (ref) v_u_217
		if v_u_20 or v_u_22 then
			v_u_217()
		end
	end)
end
return v7