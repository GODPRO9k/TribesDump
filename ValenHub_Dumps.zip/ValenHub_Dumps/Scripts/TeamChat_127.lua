local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("TextChatService")
return {
	["Init"] = function(p_u_3) -- name: Init
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		local v_u_4 = p_u_3.UI
		local v5 = p_u_3.Theme
		local v_u_6 = p_u_3.State
		local v_u_7 = v5.Colors
		local v8 = v5.Fonts
		local v_u_9 = v_u_1.LocalPlayer
		local v_u_10 = v5.Lighten(v_u_7.Ally, 0.25)
		local v_u_11 = v_u_10:ToHex()
		local v_u_12 = "all"
		local function v_u_18() -- name: enabled
			-- upvalues: (ref) v_u_2
			local function v13()
				-- upvalues: (ref) v_u_2
				return v_u_2.ChatVersion
			end
			local v14, v15 = pcall(v13)
			if v14 and v15 == Enum.ChatVersion.TextChatService then
				return true
			end
			local v16 = v_u_2:FindFirstChild("TextChannels")
			local v17
			if v16 == nil then
				v17 = false
			else
				v17 = v16:FindFirstChild("RBXGeneral") ~= nil
			end
			return v17
		end
		local v_u_19 = {}
		local function v_u_23(p_u_20) -- name: hook
			-- upvalues: (copy) v_u_19, (copy) v_u_11, (ref) v_u_2
			if not v_u_19[p_u_20] then
				v_u_19[p_u_20] = true
				function p_u_20.OnIncomingMessage(p21)
					-- upvalues: (ref) v_u_11
					local v22 = Instance.new("TextChatMessageProperties")
					v22.PrefixText = string.format("<font color=\"#%s\">[TEAM] %s</font>", v_u_11, p21.PrefixText)
					return v22
				end
				p_u_20.AncestryChanged:Connect(function()
					-- upvalues: (copy) p_u_20, (ref) v_u_2, (ref) v_u_19
					if not p_u_20:IsDescendantOf(v_u_2) then
						v_u_19[p_u_20] = nil
					end
				end)
			end
		end
		local function v_u_31() -- name: apply
			-- upvalues: (copy) v_u_18, (ref) v_u_2, (copy) v_u_9, (copy) v_u_23, (copy) v_u_6, (ref) v_u_12
			if v_u_18() then
				local v24 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
				if v24 then
					local v25 = v_u_9:GetAttribute("TeamChannel")
					local v26 = v_u_2:FindFirstChild("TribesTeamChat")
					if v26 then
						if type(v25) == "string" then
							v26 = v26:FindFirstChild(v25)
						else
							v26 = false
						end
					end
					if not (v26 and v26:IsA("TextChannel")) then
						v26 = nil
					end
					if v26 then
						v_u_23(v26)
					end
					local v27 = v24.TargetTextChannel
					local v28 = v_u_2:FindFirstChild("TribesTeamChat")
					local v29
					if v27 == nil then
						v29 = true
					else
						v29 = true
						local v30 = v_u_2:FindFirstChild("TextChannels")
						if v30 then
							v30 = v30:FindFirstChild("RBXGeneral")
						end
						if not (v30 and v30:IsA("TextChannel")) then
							v30 = nil
						end
						if v27 ~= v30 then
							if v28 == nil then
								v29 = false
							else
								v29 = v27:IsDescendantOf(v28)
							end
						end
					end
					if v29 then
						if not v_u_6.InMatch() or (not v26 or v_u_12 ~= "team") then
							v26 = v_u_2:FindFirstChild("TextChannels")
							if v26 then
								v26 = v26:FindFirstChild("RBXGeneral")
							end
							if not (v26 and v26:IsA("TextChannel")) then
								v26 = nil
							end
						end
						if v26 and v24.TargetTextChannel ~= v26 then
							v24.TargetTextChannel = v26
						end
					end
				else
					return
				end
			else
				return
			end
		end
		local v_u_32 = v_u_4.new("Frame", {
			["Name"] = "TeamChat",
			["Size"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = p_u_3.Canvas.HUD
		})
		local v_u_33 = v_u_4.new("TextButton", {
			["Name"] = "Pill",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Size"] = UDim2.fromOffset(122, 30),
			["BackgroundColor3"] = v_u_7.Panel,
			["BackgroundTransparency"] = 0.15,
			["Visible"] = false,
			v_u_4.Corner(v5.Radius.Pill),
			["Parent"] = v_u_32
		})
		local v_u_34 = v_u_4.Stroke(v_u_10, 1.5, 0.35)
		v_u_34.Parent = v_u_33
		local v_u_35 = v_u_4.Glyph("three-people", 16, v_u_10, {
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 10, 0.5, 0),
			["Parent"] = v_u_33
		})
		local v_u_36 = v_u_4.new("TextLabel", {
			["Name"] = "Text",
			["Text"] = "TEAM CHAT",
			["FontFace"] = nil,
			["TextSize"] = 13,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v8.Heavy,
			["TextColor3"] = v_u_10,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Position"] = UDim2.fromOffset(32, 0),
			["Size"] = UDim2.new(1, -38, 1, 0),
			["Parent"] = v_u_33
		})
		local v_u_37 = 0
		local function v_u_50() -- name: placePill
			-- upvalues: (copy) v_u_18, (copy) v_u_6, (copy) v_u_9, (ref) v_u_2, (copy) p_u_3, (ref) v_u_37, (copy) v_u_4, (copy) v_u_32, (copy) v_u_33
			local v38 = v_u_18() and v_u_6.InMatch()
			if v38 then
				local v39 = v_u_9:GetAttribute("TeamChannel")
				local v40 = v_u_2:FindFirstChild("TribesTeamChat")
				if v40 then
					if type(v39) == "string" then
						v40 = v40:FindFirstChild(v39)
					else
						v40 = false
					end
				end
				if not (v40 and v40:IsA("TextChannel")) then
					v40 = nil
				end
				v38 = v40 ~= nil and not p_u_3.HudHidden
				if v38 then
					local v_u_41 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
					local v42, v43 = pcall(function()
						-- upvalues: (copy) v_u_41
						return v_u_41.IsFocused
					end)
					if v42 then
						v42 = v43 == true
					end
					v38 = v42 or os.clock() < v_u_37
				end
			end
			local v44
			if v38 then
				v44 = v_u_4.ChatRectIn(v_u_32)
			else
				v44 = nil
			end
			local v45
			if v38 then
				v45 = v_u_4.ChatRect()
			else
				v45 = nil
			end
			if v44 and v45 then
				local v46 = v44.Max.Y - 20
				local v47 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
				local v48 = v45.Max.Y - v45.Min.Y
				if v47 and v48 > 1 then
					local v49 = v47.AbsolutePosition.Y + v47.AbsoluteSize.Y / 2
					v46 = v44.Min.Y + (v49 - v45.Min.Y) * (v44.Max.Y - v44.Min.Y) / v48
				end
				v_u_33.Position = UDim2.fromOffset(v44.Max.X + 8, v46)
				v_u_33.Visible = true
			else
				v_u_33.Visible = false
			end
		end
		v_u_33.Activated:Connect(function()
			-- upvalues: (copy) p_u_3, (ref) v_u_12, (copy) v_u_31, (copy) v_u_10, (copy) v_u_7, (copy) v_u_36, (copy) v_u_35, (copy) v_u_34
			p_u_3.Sounds.Play("Click")
			local v51 = v_u_12 == "team" and "all" or "team"
			v_u_12 = v51
			v_u_31()
			local v52 = v_u_12 == "team"
			local v53
			if v52 then
				v53 = v_u_10
			else
				v53 = v_u_7.TextDim
			end
			v_u_36.Text = v52 and "TEAM CHAT" or "ALL CHAT"
			v_u_36.TextColor3 = v53
			v_u_35.Text = v52 and "three-people" or "globe-simplified"
			v_u_35.TextColor3 = v53
			v_u_34.Color = v53
			p_u_3.Toast(v51 == "team" and "Chat: your team" or "Chat: everyone", "info")
		end)
		local function v_u_62(p54, p55) -- name: onCommand
			-- upvalues: (copy) v_u_9, (ref) v_u_2, (copy) v_u_6, (copy) p_u_3, (ref) v_u_12, (copy) v_u_31, (copy) v_u_10, (copy) v_u_7, (copy) v_u_36, (copy) v_u_35, (copy) v_u_34
			local v56 = v_u_9:GetAttribute("TeamChannel")
			local v_u_57 = v_u_2:FindFirstChild("TribesTeamChat")
			if v_u_57 then
				if type(v56) == "string" then
					v_u_57 = v_u_57:FindFirstChild(v56)
				else
					v_u_57 = false
				end
			end
			if not (v_u_57 and v_u_57:IsA("TextChannel")) then
				v_u_57 = nil
			end
			if not (v_u_6.InMatch() and v_u_57) then
				p_u_3.Toast(p54 == "team" and "Team chat works in matches" or "You\'re talking to everyone", "info")
				return "not in a match"
			end
			local v_u_58 = string.match(p55, "^%S+%s+(.-)%s*$")
			if v_u_58 and v_u_58 ~= "" then
				if p54 ~= "team" then
					v_u_57 = v_u_2:FindFirstChild("TextChannels")
					if v_u_57 then
						v_u_57 = v_u_57:FindFirstChild("RBXGeneral")
					end
					if not (v_u_57 and v_u_57:IsA("TextChannel")) then
						v_u_57 = nil
					end
				end
				if v_u_57 then
					task.spawn(function()
						-- upvalues: (copy) v_u_57, (copy) v_u_58
						local function v59()
							-- upvalues: (ref) v_u_57, (ref) v_u_58
							v_u_57:SendAsync(v_u_58)
						end
						pcall(v59)
					end)
				end
				return "sent to " .. p54
			end
			v_u_12 = p54
			v_u_31()
			local v60 = v_u_12 == "team"
			local v61
			if v60 then
				v61 = v_u_10
			else
				v61 = v_u_7.TextDim
			end
			v_u_36.Text = v60 and "TEAM CHAT" or "ALL CHAT"
			v_u_36.TextColor3 = v61
			v_u_35.Text = v60 and "three-people" or "globe-simplified"
			v_u_35.TextColor3 = v61
			v_u_34.Color = v61
			p_u_3.Toast(p54 == "team" and "Chat: your team" or "Chat: everyone", "info")
			return "switched to " .. p54
		end
		local function v_u_69(p63, p64, p65, p_u_66) -- name: command
			-- upvalues: (ref) v_u_2, (copy) v_u_62
			if not v_u_2:FindFirstChild(p63) then
				local v67 = Instance.new("TextChatCommand")
				v67.Name = p63
				v67.PrimaryAlias = p64
				v67.SecondaryAlias = p65
				v67.Triggered:Connect(function(_, p68)
					-- upvalues: (ref) v_u_62, (copy) p_u_66
					v_u_62(p_u_66, p68)
				end)
				v67.Parent = v_u_2
			end
		end
		local v_u_70 = false
		local v_u_71 = nil
		local function v79() -- name: refresh
			-- upvalues: (ref) v_u_2, (ref) v_u_71, (ref) v_u_37, (copy) v_u_50, (ref) v_u_70, (copy) v_u_18, (copy) v_u_69, (copy) v_u_31, (ref) v_u_12, (copy) v_u_10, (copy) v_u_7, (copy) v_u_36, (copy) v_u_35, (copy) v_u_34
			local v_u_72 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
			if v_u_72 and v_u_72 ~= v_u_71 then
				v_u_71 = v_u_72
				local function v76()
					-- upvalues: (copy) v_u_72, (ref) v_u_2, (ref) v_u_37, (ref) v_u_50
					v_u_72:GetPropertyChangedSignal("IsFocused"):Connect(function()
						-- upvalues: (ref) v_u_2, (ref) v_u_37, (ref) v_u_50
						local v_u_73 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
						local v74, v75 = pcall(function()
							-- upvalues: (copy) v_u_73
							return v_u_73.IsFocused
						end)
						if v74 then
							v74 = v75 == true
						end
						if not v74 then
							v_u_37 = os.clock() + 2.5
							task.delay(2.55, v_u_50)
						end
						v_u_50()
					end)
				end
				pcall(v76)
			end
			if not v_u_70 and v_u_18() then
				v_u_70 = true
				v_u_69("TribesTeamChat_Team", "/t", "/team", "team")
				v_u_69("TribesTeamChat_All", "/a", "/all", "all")
			end
			v_u_31()
			local v77 = v_u_12 == "team"
			local v78
			if v77 then
				v78 = v_u_10
			else
				v78 = v_u_7.TextDim
			end
			v_u_36.Text = v77 and "TEAM CHAT" or "ALL CHAT"
			v_u_36.TextColor3 = v78
			v_u_35.Text = v77 and "three-people" or "globe-simplified"
			v_u_35.TextColor3 = v78
			v_u_34.Color = v78
			v_u_50()
		end
		v_u_6.PlayerStateChanged:Connect(v79)
		v_u_6.AttrChanged:Connect(function(p80)
			-- upvalues: (ref) v_u_2, (ref) v_u_71, (ref) v_u_37, (copy) v_u_50, (ref) v_u_70, (copy) v_u_18, (copy) v_u_69, (copy) v_u_31, (ref) v_u_12, (copy) v_u_10, (copy) v_u_7, (copy) v_u_36, (copy) v_u_35, (copy) v_u_34
			if p80 == "Team" or p80 == "MatchId" then
				local v_u_81 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
				if v_u_81 and v_u_81 ~= v_u_71 then
					v_u_71 = v_u_81
					local function v85()
						-- upvalues: (copy) v_u_81, (ref) v_u_2, (ref) v_u_37, (ref) v_u_50
						v_u_81:GetPropertyChangedSignal("IsFocused"):Connect(function()
							-- upvalues: (ref) v_u_2, (ref) v_u_37, (ref) v_u_50
							local v_u_82 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
							local v83, v84 = pcall(function()
								-- upvalues: (copy) v_u_82
								return v_u_82.IsFocused
							end)
							if v83 then
								v83 = v84 == true
							end
							if not v83 then
								v_u_37 = os.clock() + 2.5
								task.delay(2.55, v_u_50)
							end
							v_u_50()
						end)
					end
					pcall(v85)
				end
				if not v_u_70 and v_u_18() then
					v_u_70 = true
					v_u_69("TribesTeamChat_Team", "/t", "/team", "team")
					v_u_69("TribesTeamChat_All", "/a", "/all", "all")
				end
				v_u_31()
				local v86 = v_u_12 == "team"
				local v87
				if v86 then
					v87 = v_u_10
				else
					v87 = v_u_7.TextDim
				end
				v_u_36.Text = v86 and "TEAM CHAT" or "ALL CHAT"
				v_u_36.TextColor3 = v87
				v_u_35.Text = v86 and "three-people" or "globe-simplified"
				v_u_35.TextColor3 = v87
				v_u_34.Color = v87
				v_u_50()
			end
		end)
		v_u_9:GetAttributeChangedSignal("TeamChannel"):Connect(v79)
		p_u_3.HudHiddenChanged:Connect(v_u_50)
		v_u_4.ChatChanged:Connect(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_71, (ref) v_u_37, (copy) v_u_50
			local v_u_88 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
			if v_u_88 and v_u_88 ~= v_u_71 then
				v_u_71 = v_u_88
				local function v92()
					-- upvalues: (copy) v_u_88, (ref) v_u_2, (ref) v_u_37, (ref) v_u_50
					v_u_88:GetPropertyChangedSignal("IsFocused"):Connect(function()
						-- upvalues: (ref) v_u_2, (ref) v_u_37, (ref) v_u_50
						local v_u_89 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
						local v90, v91 = pcall(function()
							-- upvalues: (copy) v_u_89
							return v_u_89.IsFocused
						end)
						if v90 then
							v90 = v91 == true
						end
						if not v90 then
							v_u_37 = os.clock() + 2.5
							task.delay(2.55, v_u_50)
						end
						v_u_50()
					end)
				end
				pcall(v92)
			end
			v_u_50()
		end)
		v_u_4.LayoutChanged:Connect(v_u_50)
		local v_u_93 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
		if v_u_93 and v_u_93 ~= v_u_71 then
			v_u_71 = v_u_93
			local function v97()
				-- upvalues: (copy) v_u_93, (ref) v_u_2, (ref) v_u_37, (copy) v_u_50
				v_u_93:GetPropertyChangedSignal("IsFocused"):Connect(function()
					-- upvalues: (ref) v_u_2, (ref) v_u_37, (ref) v_u_50
					local v_u_94 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
					local v95, v96 = pcall(function()
						-- upvalues: (copy) v_u_94
						return v_u_94.IsFocused
					end)
					if v95 then
						v95 = v96 == true
					end
					if not v95 then
						v_u_37 = os.clock() + 2.5
						task.delay(2.55, v_u_50)
					end
					v_u_50()
				end)
			end
			pcall(v97)
		end
		if not v_u_70 and v_u_18() then
			v_u_70 = true
			v_u_69("TribesTeamChat_Team", "/t", "/team", "team")
			v_u_69("TribesTeamChat_All", "/a", "/all", "all")
		end
		v_u_31()
		local v98 = v_u_12 == "team"
		local v99
		if v98 then
			v99 = v_u_10
		else
			v99 = v_u_7.TextDim
		end
		v_u_36.Text = v98 and "TEAM CHAT" or "ALL CHAT"
		v_u_36.TextColor3 = v99
		v_u_35.Text = v98 and "three-people" or "globe-simplified"
		v_u_35.TextColor3 = v99
		v_u_34.Color = v99
		v_u_50()
		function p_u_3.Debug.teamChat(p100, p101)
			-- upvalues: (ref) v_u_12, (copy) v_u_31, (copy) v_u_10, (copy) v_u_7, (copy) v_u_36, (copy) v_u_35, (copy) v_u_34, (copy) v_u_62, (ref) v_u_2, (copy) v_u_18, (copy) v_u_9, (copy) v_u_33
			local v102 = nil
			if p100 == "team" or p100 == "all" then
				v_u_12 = p100
				v_u_31()
				local v103 = v_u_12 == "team"
				local v104
				if v103 then
					v104 = v_u_10
				else
					v104 = v_u_7.TextDim
				end
				v_u_36.Text = v103 and "TEAM CHAT" or "ALL CHAT"
				v_u_36.TextColor3 = v104
				v_u_35.Text = v103 and "three-people" or "globe-simplified"
				v_u_35.TextColor3 = v104
				v_u_34.Color = v104
			elseif p100 == "cmd" and type(p101) == "string" then
				local v105 = string.match(p101, "^(%S+)")
				v102 = v_u_62((v105 == "/a" or v105 == "/all") and "all" or "team", p101)
			end
			local v106 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
			if v106 then
				v106 = v106.TargetTextChannel
			end
			local v107 = {
				["enabled"] = v_u_18(),
				["mode"] = v_u_12,
				["channel"] = v_u_9:GetAttribute("TeamChannel") or false
			}
			local v108
			if v106 then
				v108 = v106:GetFullName()
			else
				v108 = false
			end
			v107.target = v108
			v107.pill = v_u_33.Visible
			v107.did = v102 or false
			return v107
		end
	end
}