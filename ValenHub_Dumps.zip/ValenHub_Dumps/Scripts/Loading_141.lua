local v_u_1 = game:GetService("ReplicatedFirst")
pcall(function()
	-- upvalues: (copy) v_u_1
	v_u_1:RemoveDefaultLoadingScreen()
end)
local v_u_2 = os.clock()
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("UserInputService")
local v_u_7 = game:GetService("Workspace")
local v_u_8 = v3.LocalPlayer
local v_u_9 = v_u_8:WaitForChild("PlayerGui")
pcall(function()
	-- upvalues: (copy) v_u_9
	v_u_9.ScreenOrientation = Enum.ScreenOrientation.LandscapeSensor
end)
local v_u_10
if v_u_6.TouchEnabled then
	if v_u_6.KeyboardEnabled and v_u_6.MouseEnabled then
		local v11
		v_u_10, v11 = pcall(function()
			-- upvalues: (copy) v_u_6
			return v_u_6.PreferredInput == Enum.PreferredInput.Touch
		end)
		if v_u_10 then
			v_u_10 = v11 == true
		end
	else
		v_u_10 = true
	end
else
	v_u_10 = false
end
local v12 = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Heavy)
local v13 = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Bold)
local v14 = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.ExtraBold)
local v15 = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.SemiBold)
local v16 = Color3.fromRGB(6, 7, 10)
local v17 = Color3.fromRGB(40, 150, 255)
local v18 = Color3.fromRGB(236, 240, 247)
local v19 = {
	["Name"] = "TR_Loading",
	["DisplayOrder"] = 100,
	["IgnoreGuiInset"] = true,
	["ResetOnSpawn"] = false,
	["ZIndexBehavior"] = nil,
	["Parent"] = nil,
	["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
	["Parent"] = v_u_9
}
local v20 = Instance.new("ScreenGui")
local function v28(p21, p22, p23) -- name: new
	local v24 = Instance.new(p21)
	for v25, v26 in p22 do
		if v25 == "Parent" then
			continue
		end
		v24[v25] = v26
	end
	if v24:IsA("GuiObject") then
		v24.BorderSizePixel = 0
	end
	if p23 then
		for _, v27 in p23 do
			v27.Parent = v24
		end
	end
	if p22.Parent then
		v24.Parent = p22.Parent
	end
	return v24
end
for v29, v30 in v19 do
	if v29 == "Parent" then
		continue
	end
	v20[v29] = v30
end
if v20:IsA("GuiObject") then
	v20.BorderSizePixel = 0
end
if v19.Parent then
	v20.Parent = v19.Parent
end
v20.ScreenInsets = Enum.ScreenInsets.None
local v31 = {
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["Active"] = true,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["BackgroundColor3"] = Color3.new(1, 1, 1),
	["Parent"] = v20
}
local v32 = {
	["Color"] = nil,
	["Rotation"] = 90,
	["Color"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(26, 30, 40)), ColorSequenceKeypoint.new(0.55, Color3.fromRGB(14, 16, 22)), ColorSequenceKeypoint.new(1, Color3.fromRGB(6, 7, 10)) })
}
local v33 = Instance.new("UIGradient")
local v34 = v28
local v35 = {}
local v36 = "Frame"
for v37, v38 in v32 do
	if v37 == "Parent" then
		continue
	end
	v33[v37] = v38
end
if v33:IsA("GuiObject") then
	v33.BorderSizePixel = 0
end
if v32.Parent then
	v33.Parent = v32.Parent
end
__set_list(v35, 1, {v33})
local v39 = v28(v36, v31, v35)
local v_u_40
if v_u_10 then
	v_u_40 = Vector2.new(1280, 600)
else
	v_u_40 = Vector2.new(1600, 900)
end
local v41 = {
	["Size"] = nil,
	["BackgroundTransparency"] = 1,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v20
}
local v_u_42 = Instance.new("Frame")
for v43, v44 in v41 do
	if v43 == "Parent" then
		continue
	end
	v_u_42[v43] = v44
end
if v_u_42:IsA("GuiObject") then
	v_u_42.BorderSizePixel = 0
end
if v41.Parent then
	v_u_42.Parent = v41.Parent
end
local v45 = {
	["Parent"] = v_u_42
}
local v_u_46 = Instance.new("UIScale")
for v47, v48 in v45 do
	if v47 == "Parent" then
		continue
	end
	v_u_46[v47] = v48
end
if v_u_46:IsA("GuiObject") then
	v_u_46.BorderSizePixel = 0
end
if v45.Parent then
	v_u_46.Parent = v45.Parent
end
local function v55() -- name: rescale
	-- upvalues: (copy) v_u_7, (copy) v_u_40, (copy) v_u_46, (copy) v_u_42
	local v49 = v_u_7.CurrentCamera
	local v50 = v49 and v49.ViewportSize or v_u_40
	local v51 = v50.X / v_u_40.X
	local v52 = v50.Y / v_u_40.Y
	local v53 = math.min(v51, v52)
	local v54 = math.clamp(v53, 0.4, 1.6)
	v_u_46.Scale = v54
	v_u_42.Size = UDim2.fromScale(1 / v54, 1 / v54)
end
local v56 = v_u_7.CurrentCamera
local v57
if v56 then
	v57 = v56.ViewportSize or v_u_40
else
	v57 = v_u_40
end
local v58 = v57.X / v_u_40.X
local v59 = v57.Y / v_u_40.Y
local v60 = math.min(v58, v59)
local v61 = math.clamp(v60, 0.4, 1.6)
v_u_46.Scale = v61
v_u_42.Size = UDim2.fromScale(1 / v61, 1 / v61)
local v62 = v_u_7.CurrentCamera
if v62 then
	v62 = v_u_7.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(v55)
end
local v63 = {
	["Size"] = nil,
	["BackgroundTransparency"] = 1,
	["Parent"] = nil,
	["Size"] = UDim2.fromOffset(1, 1),
	["Parent"] = v_u_42
}
local v_u_64 = Instance.new("Frame")
for v65, v66 in v63 do
	if v65 == "Parent" then
		continue
	end
	v_u_64[v65] = v66
end
if v_u_64:IsA("GuiObject") then
	v_u_64.BorderSizePixel = 0
end
if v63.Parent then
	v_u_64.Parent = v63.Parent
end
local v67 = {
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundTransparency"] = 1,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.4),
	["Size"] = UDim2.fromOffset(1100, 300),
	["Parent"] = v_u_42
}
local v68 = Instance.new("Frame")
for v69, v70 in v67 do
	if v69 == "Parent" then
		continue
	end
	v68[v69] = v70
end
if v68:IsA("GuiObject") then
	v68.BorderSizePixel = 0
end
if v67.Parent then
	v68.Parent = v67.Parent
end
local v71 = {
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundTransparency"] = 1,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.fromScale(0.5, 0),
	["Size"] = UDim2.fromOffset(560, 116),
	["Parent"] = v68
}
local v72 = Instance.new("Frame")
for v73, v74 in v71 do
	if v73 == "Parent" then
		continue
	end
	v72[v73] = v74
end
if v72:IsA("GuiObject") then
	v72.BorderSizePixel = 0
end
if v71.Parent then
	v72.Parent = v71.Parent
end
local v75 = {
	["Scale"] = 1.9,
	["Parent"] = nil,
	["Parent"] = v72
}
local v76 = Instance.new("UIScale")
for v77, v78 in v75 do
	if v77 == "Parent" then
		continue
	end
	v76[v77] = v78
end
if v76:IsA("GuiObject") then
	v76.BorderSizePixel = 0
end
if v75.Parent then
	v76.Parent = v75.Parent
end
local v79 = {
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundTransparency"] = 1,
	["Text"] = "TRIBES",
	["FontFace"] = nil,
	["TextSize"] = 100,
	["TextColor3"] = nil,
	["TextTransparency"] = 0.7,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(4, 7),
	["Size"] = UDim2.fromScale(1, 1),
	["FontFace"] = v12,
	["TextColor3"] = Color3.new(0, 0, 0),
	["Parent"] = v72
}
local v80 = Instance.new("TextLabel")
for v81, v82 in v79 do
	if v81 == "Parent" then
		continue
	end
	v80[v81] = v82
end
if v80:IsA("GuiObject") then
	v80.BorderSizePixel = 0
end
if v79.Parent then
	v80.Parent = v79.Parent
end
v34("TextLabel", {
	["Size"] = nil,
	["BackgroundTransparency"] = 1,
	["Text"] = "TRIBES",
	["FontFace"] = nil,
	["TextSize"] = 100,
	["TextColor3"] = nil,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["FontFace"] = v12,
	["TextColor3"] = Color3.new(1, 1, 1),
	["Parent"] = v72
}, {})
local v83 = {
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.new(0.5, 0, 0, 238),
	["Size"] = UDim2.fromOffset(180, 6),
	["BackgroundColor3"] = v17,
	["Parent"] = v68
}
local v84 = {
	["CornerRadius"] = UDim.new(1, 0)
}
local v85 = Instance.new("UICorner")
local v86 = v34
local v87 = {}
local v88 = "Frame"
for v89, v90 in v84 do
	if v89 == "Parent" then
		continue
	end
	v85[v89] = v90
end
if v85:IsA("GuiObject") then
	v85.BorderSizePixel = 0
end
if v84.Parent then
	v85.Parent = v84.Parent
end
__set_list(v87, 1, {v85})
v34(v88, v83, v87)
local v91 = {
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundTransparency"] = 1,
	["Text"] = "3V3 ARENA  \194\183  BEST OF 5",
	["FontFace"] = nil,
	["TextSize"] = 28,
	["TextColor3"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.new(0.5, 0, 0, 262),
	["Size"] = UDim2.fromOffset(900, 36),
	["FontFace"] = v13,
	["TextColor3"] = v18,
	["Parent"] = v68
}
local v92 = {
	["Color"] = nil,
	["Thickness"] = 2,
	["Transparency"] = 0.3,
	["Color"] = v16
}
local v93 = Instance.new("UIStroke")
local v94 = v86
local v95 = {}
local v96 = "TextLabel"
for v97, v98 in v92 do
	if v97 == "Parent" then
		continue
	end
	v93[v97] = v98
end
if v93:IsA("GuiObject") then
	v93.BorderSizePixel = 0
end
if v92.Parent then
	v93.Parent = v92.Parent
end
__set_list(v95, 1, {v93})
v86(v96, v91, v95)
local v_u_99 = v_u_10 and 760 or 900
local v100 = {
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.25,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.new(0.5, 0, 1, -112),
	["Size"] = UDim2.fromOffset(v_u_99, 58),
	["BackgroundColor3"] = Color3.fromRGB(20, 22, 28),
	["Parent"] = v_u_42
}
local v101 = {
	["CornerRadius"] = UDim.new(0, 12)
}
local v102 = Instance.new("UICorner")
local v103 = v94
local v104 = {}
local v105 = "Frame"
local v106 = {
	"Best of 5: win three rounds to take the match. One life per round.",
	"Arrows drop over distance. Aim a little high on far targets.",
	"Headshots hit much harder. Aim for the head.",
	"Slide into cover, then jump out swinging.",
	"When the ring of fire closes in, fight in the middle or burn.",
	"Open LOADOUT and spend your gear points on any mix you like.",
	"Ammo is part of your loadout: bring enough arrows for the round.",
	"Hold block with the Iron Sword to soften hits from the front.",
	"Throwing knives: 5 per round. Make them count.",
	"Practise on the dummies in the lobby\'s training range."
}
for v107, v108 in v101 do
	if v107 == "Parent" then
		continue
	end
	v102[v107] = v108
end
if v102:IsA("GuiObject") then
	v102.BorderSizePixel = 0
end
if v101.Parent then
	v102.Parent = v101.Parent
end
local v109 = {
	["Color"] = nil,
	["Thickness"] = 2,
	["Transparency"] = 0.7,
	["Color"] = v18
}
local v110 = Instance.new("UIStroke")
for v111, v112 in v109 do
	if v111 == "Parent" then
		continue
	end
	v110[v111] = v112
end
if v110:IsA("GuiObject") then
	v110.BorderSizePixel = 0
end
if v109.Parent then
	v110.Parent = v109.Parent
end
__set_list(v104, 1, {v102, v110})
local v_u_113 = v94(v105, v100, v104)
local v114 = {
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundTransparency"] = 1,
	["Text"] = "TIP",
	["FontFace"] = nil,
	["TextSize"] = 24,
	["TextColor3"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(18, 0),
	["Size"] = UDim2.new(0, 60, 1, 0),
	["FontFace"] = v12,
	["TextColor3"] = v17,
	["Parent"] = v_u_113
}
local v115 = Instance.new("TextLabel")
for v116, v117 in v114 do
	if v116 == "Parent" then
		continue
	end
	v115[v116] = v117
end
if v115:IsA("GuiObject") then
	v115.BorderSizePixel = 0
end
if v114.Parent then
	v115.Parent = v114.Parent
end
local v118 = {
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundTransparency"] = 1,
	["Text"] = nil,
	["TextWrapped"] = true,
	["FontFace"] = nil,
	["TextSize"] = 19,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(84, 0),
	["Size"] = UDim2.new(1, -102, 1, 0),
	["Text"] = v106[math.random(1, #v106)],
	["FontFace"] = v15,
	["TextColor3"] = v18,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Parent"] = v_u_113
}
local v119 = Instance.new("TextLabel")
for v120, v121 in v118 do
	if v120 == "Parent" then
		continue
	end
	v119[v120] = v121
end
if v119:IsA("GuiObject") then
	v119.BorderSizePixel = 0
end
if v118.Parent then
	v119.Parent = v118.Parent
end
local v122 = {
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.2,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.new(0.5, 0, 1, -62),
	["Size"] = UDim2.fromOffset(v_u_99, 14),
	["BackgroundColor3"] = v16,
	["Parent"] = v_u_42
}
local v123 = {
	["CornerRadius"] = UDim.new(1, 0)
}
local v124 = Instance.new("UICorner")
local v125 = v103
local v126 = {}
local v127 = "Frame"
for v128, v129 in v123 do
	if v128 == "Parent" then
		continue
	end
	v124[v128] = v129
end
if v124:IsA("GuiObject") then
	v124.BorderSizePixel = 0
end
if v123.Parent then
	v124.Parent = v123.Parent
end
local v130 = {
	["Color"] = nil,
	["Thickness"] = 2,
	["Transparency"] = 0.6,
	["Color"] = v18
}
local v131 = Instance.new("UIStroke")
for v132, v133 in v130 do
	if v132 == "Parent" then
		continue
	end
	v131[v132] = v133
end
if v131:IsA("GuiObject") then
	v131.BorderSizePixel = 0
end
if v130.Parent then
	v131.Parent = v130.Parent
end
__set_list(v126, 1, {v124, v131})
local v_u_134 = v103(v127, v122, v126)
local v135 = {
	["Size"] = UDim2.fromScale(0.04, 1),
	["BackgroundColor3"] = Color3.new(1, 1, 1),
	["Parent"] = v_u_134
}
local v136 = {
	["CornerRadius"] = UDim.new(1, 0)
}
local v137 = Instance.new("UICorner")
local v138 = v125
local v139 = {}
local v140 = "Frame"
for v141, v142 in v136 do
	if v141 == "Parent" then
		continue
	end
	v137[v141] = v142
end
if v137:IsA("GuiObject") then
	v137.BorderSizePixel = 0
end
if v136.Parent then
	v137.Parent = v136.Parent
end
local v143 = {
	["Color"] = ColorSequence.new(Color3.fromRGB(90, 180, 255), Color3.fromRGB(28, 132, 246))
}
local v144 = Instance.new("UIGradient")
for v145, v146 in v143 do
	if v145 == "Parent" then
		continue
	end
	v144[v145] = v146
end
if v144:IsA("GuiObject") then
	v144.BorderSizePixel = 0
end
if v143.Parent then
	v144.Parent = v143.Parent
end
__set_list(v139, 1, {v137, v144})
local v_u_147 = v125(v140, v135, v139)
local v148 = {
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundTransparency"] = 1,
	["Text"] = "LOADING\226\128\166",
	["FontFace"] = nil,
	["TextSize"] = 16,
	["TextColor3"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.new(0.5, 0, 1, -28),
	["Size"] = UDim2.fromOffset(900, 24),
	["FontFace"] = v14,
	["TextColor3"] = Color3.fromRGB(130, 138, 156),
	["Parent"] = v_u_42
}
local v_u_149 = Instance.new("TextLabel")
for v150, v151 in v148 do
	if v150 == "Parent" then
		continue
	end
	v_u_149[v150] = v151
end
if v_u_149:IsA("GuiObject") then
	v_u_149.BorderSizePixel = 0
end
if v148.Parent then
	v_u_149.Parent = v148.Parent
end
local v_u_152 = false
local v_u_153 = false
local v154 = "TextButton"
local v155 = {
	["Name"] = "Skip",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 1,
	["AutoButtonColor"] = false,
	["Text"] = "SKIP  \226\128\186",
	["FontFace"] = nil,
	["TextSize"] = nil,
	["TextColor3"] = nil,
	["TextTransparency"] = 1,
	["Visible"] = false,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(1, 1)
}
local v156
if v_u_10 then
	v156 = UDim2.new(1, -70, 1, -40)
else
	v156 = UDim2.new(1, -36, 1, -36)
end
v155.Position = v156
local v157
if v_u_10 then
	v157 = UDim2.fromOffset(210, 80)
else
	v157 = UDim2.fromOffset(180, 62)
end
v155.Size = v157
v155.BackgroundColor3 = Color3.fromRGB(28, 132, 246)
v155.FontFace = v12
v155.TextSize = v_u_10 and 34 or 28
v155.TextColor3 = v18
v155.Parent = v_u_42
local v158 = {
	["CornerRadius"] = UDim.new(1, 0)
}
local v159 = Instance.new("UICorner")
local v160 = {}
for v161, v162 in v158 do
	if v161 == "Parent" then
		continue
	end
	v159[v161] = v162
end
if v159:IsA("GuiObject") then
	v159.BorderSizePixel = 0
end
if v158.Parent then
	v159.Parent = v158.Parent
end
__set_list(v160, 1, {v159})
local v_u_163 = v138(v154, v155, v160)
local v164 = {
	["Color"] = nil,
	["Thickness"] = 3,
	["Transparency"] = 1,
	["ApplyStrokeMode"] = nil,
	["Parent"] = nil,
	["Color"] = v17,
	["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
	["Parent"] = v_u_163
}
local v_u_165 = Instance.new("UIStroke")
for v166, v167 in v164 do
	if v166 == "Parent" then
		continue
	end
	v_u_165[v166] = v167
end
if v_u_165:IsA("GuiObject") then
	v_u_165.BorderSizePixel = 0
end
if v164.Parent then
	v_u_165.Parent = v164.Parent
end
local function v183() -- name: footer
	-- upvalues: (copy) v_u_46, (copy) v_u_42, (copy) v_u_163, (copy) v_u_10, (copy) v_u_99, (copy) v_u_113, (copy) v_u_134, (copy) v_u_149
	local v168 = v_u_46.Scale
	local v169 = math.max(v168, 0.01)
	local v170 = v_u_42.AbsoluteSize.X / v169
	if v170 >= 10 then
		local v171 = (v_u_163.AbsolutePosition.X - v_u_42.AbsolutePosition.X) / v169
		if v_u_163.AbsoluteSize.X < 1 then
			v171 = v170 - (v_u_10 and 280 or 216)
		end
		local v172 = v170 - 40
		local v173 = v171 - 16
		local v174 = math.min(v172, v173)
		local v175 = v_u_99
		local v176 = v174 - 40
		local v177 = math.min(v175, v176)
		local v178 = v177 / 2 + 40
		local v179 = v170 / 2
		local v180 = v174 - v177 / 2
		local v181 = math.min(v179, v180)
		local v182 = math.max(v178, v181)
		v_u_113.Size = UDim2.fromOffset(v177, 58)
		v_u_113.Position = UDim2.new(0, v182, 1, -112)
		v_u_134.Size = UDim2.fromOffset(v177, 14)
		v_u_134.Position = UDim2.new(0, v182, 1, -62)
		v_u_149.Size = UDim2.fromOffset(v177, 24)
		v_u_149.Position = UDim2.new(0, v182, 1, -28)
	end
end
v183()
v_u_42:GetPropertyChangedSignal("AbsoluteSize"):Connect(v183)
v_u_163:GetPropertyChangedSignal("AbsolutePosition"):Connect(v183)
task.delay(0.6, function()
	-- upvalues: (ref) v_u_153, (copy) v_u_163, (copy) v_u_4, (copy) v_u_165
	if not v_u_153 then
		v_u_163.Visible = true
		v_u_4:Create(v_u_163, TweenInfo.new(0.25, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			["BackgroundTransparency"] = 0.1,
			["TextTransparency"] = 0
		}):Play()
		v_u_4:Create(v_u_165, TweenInfo.new(0.25, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			["Transparency"] = 0
		}):Play()
	end
end)
v_u_163.Activated:Connect(function()
	-- upvalues: (ref) v_u_152
	v_u_152 = true
end)
local v185 = v_u_6.InputBegan:Connect(function(p184)
	-- upvalues: (copy) v_u_163, (ref) v_u_152
	if v_u_163.Visible and (p184.KeyCode == Enum.KeyCode.Space or (p184.KeyCode == Enum.KeyCode.Return or p184.KeyCode == Enum.KeyCode.ButtonA)) then
		v_u_152 = true
	end
end)
v76.Scale = 2.4
local v186 = Enum.EasingStyle.Back
v_u_4:Create(v76, TweenInfo.new(0.5, v186 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
	["Scale"] = 1.9
}):Play()
local v_u_187 = 0.04
local v199 = v_u_5.RenderStepped:Connect(function(p188)
	-- upvalues: (copy) v_u_64, (copy) v_u_2, (copy) v_u_5, (copy) v_u_7, (copy) v_u_8, (copy) v_u_149, (ref) v_u_187, (copy) v_u_147
	v_u_64.Rotation = (v_u_64.Rotation + p188 * 3) % 360
	local v189 = os.clock() - v_u_2
	local v190
	if v_u_5:IsStudio() and v_u_7:GetAttribute("UIHoldLoading") == true then
		v190 = false
	else
		v190 = v_u_8.Character ~= nil
	end
	local v191
	if v190 then
		v191 = 1
		v_u_149.Text = "READY!"
		if not v_u_8:GetAttribute("CharacterAtMs") then
			local v192 = v_u_8
			local v193 = v189 * 1000
			v192:SetAttribute("CharacterAtMs", (math.floor(v193)))
		end
	else
		local v194 = -v189 / 4
		v191 = (1 - math.exp(v194)) * 0.75 + 0.1
		v_u_149.Text = v189 < 2 and "LOADING\226\128\166" or "ALMOST THERE\226\128\166"
	end
	local v195 = v_u_187
	local v196 = v191 - v_u_187
	local v197 = p188 * 6
	v_u_187 = v195 + v196 * math.min(1, v197)
	local v198 = v_u_187
	v_u_147.Size = UDim2.fromScale(math.clamp(v198, 0.04, 1), 1)
end)
local v200 = v_u_2 + (v_u_5:IsStudio() and v_u_7:GetAttribute("UIHoldLoading") == true and 120 or 25)
while not v_u_152 do
	local v201
	if v_u_5:IsStudio() and v_u_7:GetAttribute("UIHoldLoading") == true then
		v201 = false
	else
		v201 = v_u_8.Character ~= nil
	end
	if v201 or os.clock() >= v200 then
		break
	end
	task.wait()
end
local _ = true
v199:Disconnect()
v185:Disconnect()
if v62 then
	v62:Disconnect()
end
local v202 = (os.clock() - v_u_2) * 1000
v_u_8:SetAttribute("LoadingShownMs", (math.floor(v202)))
v_u_8:SetAttribute("LoadingSkipped", v_u_152)
v39.Active = false
for _, v203 in v20:GetDescendants() do
	if v203:IsA("TextLabel") or v203:IsA("TextButton") then
		v_u_4:Create(v203, TweenInfo.new(0.3, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			["TextTransparency"] = 1,
			["BackgroundTransparency"] = 1
		}):Play()
	elseif v203:IsA("Frame") then
		v_u_4:Create(v203, TweenInfo.new(0.3, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			["BackgroundTransparency"] = 1
		}):Play()
	else
		if not v203:IsA("UIStroke") then
			continue
		end
		v_u_4:Create(v203, TweenInfo.new(0.24, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			["Transparency"] = 1
		}):Play()
	end
end
task.wait(0.3)
v20:Destroy()