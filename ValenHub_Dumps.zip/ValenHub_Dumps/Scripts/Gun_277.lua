local v1 = game:GetService("ReplicatedStorage")
local v2 = script.Parent.Parent
local v_u_3 = require(v2.Util)
local v_u_4 = require(v2.Hud)
local v_u_5 = require(v2.Effects)
local v_u_6 = require(v2.Poses)
local v_u_7 = require(v1:WaitForChild("Shared"):WaitForChild("Combat"))
local v_u_8 = {}
v_u_8.__index = v_u_8
function v_u_8.new(p9) -- name: new
	-- upvalues: (copy) v_u_8
	local v10 = v_u_8
	local v11 = setmetatable({}, v10)
	v11.ctx = p9
	v11.tuning = p9.tuning
	v11.preset = p9.preset
	v11.kind = p9.kind
	v11.magazine = p9.tuning.magazine or 1
	v11.ammo = v11.magazine
	v11.reloading = false
	v11.reloadToken = 0
	v11.lastShot = (-1 / 0)
	v11.holding = false
	v11.aiming = false
	v11.aimStart = 0
	v11.spreadNow = 0
	v11.conns = {}
	v11.bufferedAt = nil
	return v11
end
function v_u_8.SyncAmmo(p12) -- name: SyncAmmo
	-- upvalues: (copy) v_u_4
	local v13 = p12.ctx.tool
	if v13 then
		v13 = v13:GetAttribute("Ammo")
	end
	if type(v13) == "number" then
		p12.ammo = v13
	end
	v_u_4.SetPips(p12.ammo, p12.magazine)
end
function v_u_8.SyncPool(p14) -- name: SyncPool
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v15 = p14.tuning.ammo
	if v15 then
		v_u_4.SetAmmoCount(v_u_3.AmmoShown(p14.ctx.char, v15))
	end
end
function v_u_8.OutOfAmmo(p16) -- name: OutOfAmmo
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v17 = p16.tuning.ammo
	if not v17 or v_u_3.AmmoLeft(p16.ctx.char, v17) >= 1 then
		return false
	end
	local v18 = os.clock()
	if v18 - (p16.lastDry or 0) > 0.4 then
		p16.lastDry = v18
		v_u_3.Sound("Dry_Fire", p16.ctx.root)
		v_u_4.Toast(v_u_3.AMMO_OUT[v17] or "OUT OF AMMO", Color3.fromRGB(255, 110, 90), 1)
	end
	return true
end
function v_u_8.Equip(p_u_19) -- name: Equip
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v_u_20 = p_u_19.ctx
	v_u_4.SetStyle(p_u_19.preset.crosshair or "Gun")
	p_u_19:SyncAmmo()
	local v21 = p_u_19.tuning.ammo
	if v21 and v_u_20.char then
		p_u_19:SyncPool()
		p_u_19.poolConns = v_u_3.WatchAmmo(v_u_20.char, v21, function()
			-- upvalues: (copy) p_u_19
			p_u_19:SyncPool()
		end)
	end
	p_u_19.spreadNow = p_u_19:TargetSpread()
	v_u_3.PlayAnim(v_u_20.animator, p_u_19.preset.hold, 1, 0.2)
	if not v_u_3.InFirstPerson() then
		v_u_3.Sound(p_u_19.preset.equip or "Equip_Crossbow", v_u_20.root)
	end
	local v_u_22 = v_u_20.tool
	local v23 = p_u_19.conns
	local v24 = v_u_22:GetAttributeChangedSignal("Ammo")
	local function v25()
		-- upvalues: (copy) p_u_19, (ref) v_u_3, (copy) v_u_20
		p_u_19:SyncAmmo()
		if p_u_19.ammo >= p_u_19.magazine and p_u_19.reloading then
			p_u_19:FinishReload()
			if p_u_19.preset.reloadDoneSound and not v_u_3.InFirstPerson() then
				v_u_3.Sound(p_u_19.preset.reloadDoneSound, v_u_20.root)
			end
		end
	end
	table.insert(v23, v24:Connect(v25))
	local v26 = p_u_19.conns
	local v27 = v_u_22:GetAttributeChangedSignal("Reloading")
	table.insert(v26, v27:Connect(function()
		-- upvalues: (copy) v_u_22, (copy) p_u_19
		if v_u_22:GetAttribute("Reloading") == true and not p_u_19.reloading then
			p_u_19:LocalReload()
		end
	end))
	if p_u_19.ammo <= 0 or v_u_22:GetAttribute("Reloading") == true then
		p_u_19:LocalReload()
	end
end
function v_u_8.Unequip(p28) -- name: Unequip
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v29 = p28.ctx
	for _, v30 in p28.conns do
		v30:Disconnect()
	end
	table.clear(p28.conns)
	p28.holding = false
	p28.reloading = false
	p28.reloadToken = p28.reloadToken + 1
	v_u_4.SetArc(nil)
	v_u_4.SetPips(0, 0)
	if p28.aiming then
		p28:SetAim(false)
	end
	v29.setSpeed("Reload", nil)
	v_u_3.StopAnim(v29.animator, p28.preset.hold, 0.15)
	v_u_3.StopAnim(v29.animator, p28.preset.aim, 0.1)
	v_u_3.StopAnim(v29.animator, p28.preset.fire, 0.1)
	v_u_3.StopAnim(v29.animator, p28.preset.reload, 0.1)
	if p28.poolConns then
		for _, v31 in p28.poolConns do
			v31:Disconnect()
		end
		p28.poolConns = nil
	end
	v_u_4.SetAmmoCount(nil)
end
function v_u_8.Aimed(p32) -- name: Aimed
	local v33 = p32.aiming
	if v33 then
		v33 = os.clock() - p32.aimStart >= 0.12
	end
	return v33
end
function v_u_8.TargetSpread(p34) -- name: TargetSpread
	local v35 = p34.tuning
	if p34.kind ~= "Blunderbuss" then
		return p34.kind == "Crossbow" and 0.4 or (p34:Aimed() and (v35.spreadAim or 0) or (v35.spreadHip or 0))
	end
	local v36
	if p34:Aimed() then
		v36 = v35.spreadAim or v35.spread
		if not v36 then
			return 6
		end
	else
		v36 = v35.spread or 6
	end
	return v36
end
function v_u_8.FinishReload(p37) -- name: FinishReload
	-- upvalues: (copy) v_u_4
	p37.reloading = false
	p37.ctx.emit("ReloadEnd", nil)
	p37.ctx.setSpeed("Reload", nil)
	v_u_4.SetArc(nil)
end
function v_u_8.LocalReload(p_u_38) -- name: LocalReload
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v_u_39 = p_u_38.ctx
	if not p_u_38.reloading then
		p_u_38.reloading = true
		p_u_38.reloadToken = p_u_38.reloadToken + 1
		local v_u_40 = p_u_38.reloadToken
		local v41 = p_u_38.tuning.reloadTime or 1.5
		local v42 = v_u_39.tool:GetAttribute("ReloadEndsAt")
		local v_u_43
		if type(v42) == "number" and v42 > 0 then
			local v44 = v42 - workspace:GetServerTimeNow()
			v_u_43 = math.clamp(v44, 0.05, v41)
		else
			v_u_43 = v41
		end
		v_u_4.SetArc(v41, Color3.fromRGB(228, 232, 240), v41 - v_u_43)
		local v45 = {
			["time"] = v_u_43,
			["total"] = v41
		}
		v_u_39.emit("Reload", v45)
		v_u_39.setSpeed("Reload", p_u_38.tuning.reloadSpeedMult)
		local v_u_46 = 0.55 - (os.clock() - p_u_38.lastShot)
		local function v51() -- name: crank
			-- upvalues: (copy) p_u_38, (copy) v_u_40, (ref) v_u_3, (copy) v_u_39, (ref) v_u_43, (copy) v_u_46
			if p_u_38.reloadToken == v_u_40 and p_u_38.reloading then
				local v47 = v_u_3.PlayAnim(v_u_39.animator, p_u_38.preset.reload, 1, 0.1)
				local v48 = v_u_46
				local v49 = v_u_43 - math.max(0, v48)
				local v50 = math.max(0.2, v49)
				if v47 and v47.Length > 0 then
					v47:AdjustSpeed(v47.Length / v50)
				end
				if not v_u_3.InFirstPerson() then
					v_u_3.Sound(p_u_38.preset.reloadSound or "Crossbow_Reload", v_u_39.root)
					if p_u_38.preset.reloadSound2 then
						v_u_3.Sound(p_u_38.preset.reloadSound2, v_u_39.root)
					end
				end
			end
		end
		if v_u_46 > 0 then
			task.delay(v_u_46, v51)
		else
			v51()
		end
		task.delay(v_u_43 + 0.4, function()
			-- upvalues: (copy) p_u_38, (copy) v_u_40
			if p_u_38.reloadToken == v_u_40 and p_u_38.reloading then
				p_u_38:FinishReload()
				p_u_38:SyncAmmo()
			end
		end)
	end
end
function v_u_8.RequestReload(p52) -- name: RequestReload
	if p52.reloading or p52.ammo >= p52.magazine then
		return
	elseif not p52:OutOfAmmo() then
		p52.ctx.send("Reload", {
			["tool"] = p52.ctx.tool
		})
		p52:LocalReload()
	end
end
function v_u_8.Fire(p_u_53) -- name: Fire
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_7, (copy) v_u_6
	local v_u_54 = p_u_53.ctx
	local v55 = p_u_53.tuning
	local v56 = p_u_53.preset
	local v57 = os.clock()
	if p_u_53.reloading then
		return "reloading"
	end
	if v57 - p_u_53.lastShot < (v55.fireInterval or 0.3) then
		return "cooldown"
	end
	if not v_u_3.CanAct() then
		return "frozen"
	end
	if p_u_53:OutOfAmmo() then
		p_u_53.lastShot = v57
		return "empty"
	end
	if p_u_53.ammo <= 0 then
		p_u_53.lastShot = v57
		v_u_3.Sound(v56.emptySound or "Dry_Fire", v_u_54.root)
		p_u_53:RequestReload()
		return "empty"
	end
	p_u_53.lastShot = v57
	p_u_53.bufferedAt = nil
	p_u_53.ammo = p_u_53.ammo - 1
	v_u_4.SetPips(p_u_53.ammo, p_u_53.magazine)
	v_u_3.FaceCamera()
	local v58 = v_u_3.ShotOrigin(v_u_54.tool, "Muzzle")
	local v59 = v_u_3.AssistDirection(v58, v_u_3.AimDirection(v58), false)
	local v60 = v_u_54.nextId()
	local v61 = v_u_5.MyKey(v60)
	local v62 = v_u_7.ShotSpeed(v55)
	local v63 = v_u_3.ShotKind(v_u_54.char, v55.ammo, v55.projectile or "Bolt")
	local v64 = p_u_53:Aimed()
	if p_u_53.kind == "Blunderbuss" then
		local v65
		if v64 then
			v65 = v55.spreadAim or v55.spread
		else
			v65 = v55.spread
		end
		v_u_5.Pellets(v61, v63, v58, v59, v62, v55.gravity or 0, v55.pellets or 8, v65 or 6, p_u_53:Seed(v60), v_u_54.char, {
			["damage"] = v55.damage * v_u_3.ItemBonus(v_u_54.weaponId),
			["tuning"] = v55
		})
	else
		local v66
		if p_u_53.kind == "Crossbow" then
			v66 = 0
		elseif v64 then
			v66 = v55.spreadAim or 0
		else
			v66 = v55.spreadHip or 0
		end
		local v67 = v_u_7.SpreadDir(v59, v66, p_u_53:Seed(v60), 0)
		v_u_5.Projectile(v61, v63, v58, v67 * v62, v55.gravity or 0, v_u_54.char, {
			["damage"] = v55.damage * v_u_3.ItemBonus(v_u_54.weaponId),
			["tuning"] = v55
		})
	end
	v_u_54.send("Shoot", {
		["tool"] = v_u_54.tool,
		["origin"] = v58,
		["dir"] = v59,
		["id"] = v60
	})
	v_u_3.PlayAnim(v_u_54.animator, v56.fire, v56.fireAnimSpeed or 1.2, 0.02)
	v_u_3.Sound(v56.fireSound or "Crossbow_Fire", v_u_54.root)
	if v56.flash or v56.puff then
		v_u_5.Muzzle(CFrame.lookAt(v58, v58 + v59), p_u_53.kind ~= "Pistol", v56.puff ~= false, v_u_3.InFirstPerson())
	end
	local v68 = v55.kick or (v56.kick or 2)
	v_u_54.emit("Fire", {
		["kick"] = v68,
		["aimed"] = v64
	})
	local v69 = v55.climb
	if type(v69) == "number" then
		local v70 = v55.jolt or v68 * 0.585
		v_u_3.RecoilSlow(v70, (math.random() - 0.5) * v70 * 0.25, v69, (math.random() - 0.5) * v69 * 0.5)
	else
		v_u_3.Recoil(v68, (math.random() - 0.5) * v68 * 0.5)
	end
	v_u_3.Shake(v55.shake or (v56.shake or 0.25), 0.14)
	v_u_4.Kick(v68 * 3)
	v_u_6.Kick(v_u_54.char, v68 * 5)
	if p_u_53.ammo <= 0 and (not v55.ammo or v_u_3.AmmoLeft(v_u_54.char, v55.ammo) > 1) then
		task.delay(0.25, function()
			-- upvalues: (copy) v_u_54, (copy) p_u_53
			if v_u_54.tool and v_u_54.tool.Parent == v_u_54.char then
				p_u_53:LocalReload()
			end
		end)
	end
	return "fired"
end
function v_u_8.Seed(p71, p72) -- name: Seed
	-- upvalues: (copy) v_u_7
	local v73 = p71.ctx.char:GetAttribute("ShotNonce")
	return v_u_7.SeedFor(p72, type(v73) ~= "number" and 0 or v73)
end
function v_u_8.SetAim(p74, p75) -- name: SetAim
	-- upvalues: (copy) v_u_3
	local v76 = p74.ctx
	if p74.aiming ~= p75 then
		p74.aiming = p75
		p74.aimStart = os.clock()
		p74.aimSent = os.clock()
		v_u_3.SetAiming(p75, p74.tuning.aimFov)
		if p75 then
			v_u_3.PlayAnim(v76.animator, p74.preset.aim, 1, 0.12)
		else
			v_u_3.StopAnim(v76.animator, p74.preset.aim, 0.18)
		end
		v76.send("Aim", {
			["tool"] = v76.tool,
			["on"] = p75
		})
		v76.setSpeed("Aim", p75 and (p74.tuning.aimSpeedMult or 0.8) or nil)
	end
end
function v_u_8.Input(p77, p78, p79) -- name: Input
	if p78 == "Primary" then
		p77.holding = p79
		if p79 and p77:Fire() == "cooldown" then
			p77.bufferedAt = os.clock()
			return
		end
	else
		if p78 == "Secondary" then
			p77:SetAim(p79)
			return
		end
		if p78 == "Reload" and p79 then
			p77:RequestReload()
		end
	end
end
function v_u_8.Update(p80, p81) -- name: Update
	-- upvalues: (copy) v_u_4
	if p80.aiming and os.clock() - (p80.aimSent or 0) > 1 then
		p80.aimSent = os.clock()
		p80.ctx.send("Aim", {
			["tool"] = nil,
			["on"] = true,
			["tool"] = p80.ctx.tool
		})
	end
	if p80.bufferedAt then
		if os.clock() - p80.bufferedAt > 0.15 then
			p80.bufferedAt = nil
		elseif p80:Fire() ~= "cooldown" then
			p80.bufferedAt = nil
		end
	end
	local v82 = p80:TargetSpread()
	local v83 = p80.spreadNow
	local v84 = v82 - p80.spreadNow
	local v85 = p81 * 14
	p80.spreadNow = v83 + v84 * math.min(1, v85)
	v_u_4.SetSpread(p80.spreadNow)
end
function v_u_8.Interrupt(_) -- name: Interrupt end
function v_u_8.OnDenied(p86, p87) -- name: OnDenied
	if p87 == "NoAmmo" then
		p86.lastDry = 0
		p86:OutOfAmmo()
	end
end
return v_u_8