local v_u_1 = game:GetService("GuiService")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = {}
local v_u_6 = nil
local v_u_7 = v2.LocalPlayer
local v_u_8 = {}
local v_u_9 = {}
local v_u_10 = 0
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = {}
local v_u_14 = {}
setmetatable(v_u_14, {
	["__mode"] = "k"
})
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = 0
local v_u_18 = false
local v_u_19 = true
local function v_u_23() -- name: matchPhase
	-- upvalues: (copy) v_u_7, (copy) v_u_4
	if v_u_7:GetAttribute("State") == "Match" then
		local v20 = v_u_7:GetAttribute("MatchId")
		local v21 = v_u_4:FindFirstChild("Arenas")
		local v22
		if v21 and (type(v20) == "string" and v20 ~= "") then
			v22 = v21:FindFirstChild(v20)
		else
			v22 = nil
		end
		if v22 then
			v22 = v22:GetAttribute("Phase")
		end
		if type(v22) == "string" then
			return v22
		else
			return nil
		end
	else
		return "none"
	end
end
function v_u_5.PruneTouches(p24) -- name: PruneTouches
	-- upvalues: (copy) v_u_13
	local v25 = 0
	for v26 in p24 do
		local v27 = v26.UserInputState
		if v27 == Enum.UserInputState.End or v27 == Enum.UserInputState.Cancel then
			p24[v26] = nil
			v_u_13["touches:ended"] = (v_u_13["touches:ended"] or 0) + 1
		else
			v25 = v25 + 1
		end
	end
	return v25
end
function v_u_5.LockPushed(p28, p29) -- name: LockPushed
	-- upvalues: (copy) v_u_8, (copy) v_u_9
	v_u_8[p28] = os.clock()
	local v30 = v_u_9
	local v31 = typeof(p29) ~= "number" and 10 or p29
	v30[p28] = math.clamp(v31, 0.1, 10)
end
function v_u_5.LockPopped(p32) -- name: LockPopped
	-- upvalues: (copy) v_u_8, (copy) v_u_9
	v_u_8[p32] = nil
	v_u_9[p32] = nil
end
function v_u_5.SetChatConfig(p33) -- name: SetChatConfig
	-- upvalues: (ref) v_u_12
	v_u_12 = p33
end
function v_u_5.FreeKeyDown(p34) -- name: FreeKeyDown
	-- upvalues: (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (ref) v_u_19
	local v35 = p34.KeyCode
	local v36 = p34.UserInputType
	local v37 = os.clock()
	local v38 = v_u_19
	v_u_15 = v35
	v_u_16 = v36
	v_u_17 = v37
	v_u_18 = v38
end
function v_u_5.FreeKeyUp() -- name: FreeKeyUp
	-- upvalues: (ref) v_u_15, (ref) v_u_18, (ref) v_u_19, (ref) v_u_17
	local v39 = v_u_15 ~= nil and (v_u_18 and v_u_19)
	if v39 then
		v39 = os.clock() - v_u_17 <= 1
	end
	v_u_15 = nil
	return v39
end
function v_u_5.FreeKeyCancel() -- name: FreeKeyCancel
	-- upvalues: (ref) v_u_15
	v_u_15 = nil
end
function v_u_5.Blockers() -- name: Blockers
	-- upvalues: (ref) v_u_6
	local v40 = v_u_6
	return not v40 and {} or v40.blockers()
end
local function v_u_58(p41) -- name: pass
	-- upvalues: (ref) v_u_6, (copy) v_u_8, (copy) v_u_5, (copy) v_u_9, (copy) v_u_13, (copy) v_u_23, (copy) v_u_3, (copy) v_u_14, (ref) v_u_12, (ref) v_u_11, (copy) v_u_7
	local v42 = v_u_6
	local v43 = nil
	local v44 = false
	for v45 in v42.lookLocks do
		local v46 = v_u_8[v45]
		if v46 == nil then
			v_u_5.LockPushed(v45)
			v46 = v_u_8[v45]
		end
		local v47 = p41 - v46
		if (v_u_9[v45] or 10) < v47 then
			local v48 = "lock:" .. v45 .. ":timeout"
			v_u_13[v48] = (v_u_13[v48] or 0) + 1
			v42.popLookLock(v45)
		else
			if v45 ~= "Intro" or v47 <= 0.5 then
				continue
			end
			if not v44 then
				v43 = v_u_23()
				v44 = true
			end
			if v43 == nil or (v43 == "Intro" or v43 == "Loading") then
				continue
			end
			local v49 = "lock:Intro:" .. tostring(v43)
			v_u_13[v49] = (v_u_13[v49] or 0) + 1
			v42.popLookLock(v45)
		end
	end
	if v42.unlockReasons.TextBox then
		local v_u_50 = v_u_3:GetFocusedTextBox()
		if v_u_50 then
			local v53, v54 = pcall(function()
				-- upvalues: (copy) v_u_50
				local v51 = v_u_50
				while v51 do
					if v51:IsA("GuiObject") and not v51.Visible then
						return false
					end
					if v51:IsA("LayerCollector") then
						local v52 = v51.Enabled
						if v52 then
							v52 = v51.Parent ~= nil
						end
						return v52
					end
					v51 = v51.Parent
				end
				return false
			end)
			if v53 and v54 ~= true then
				if p41 - (v_u_14[v_u_50] or (-1 / 0)) >= 1 then
					v_u_14[v_u_50] = p41
					pcall(function()
						-- upvalues: (copy) v_u_50
						v_u_50:ReleaseFocus()
					end)
				end
				v_u_13["unlock:TextBox:hidden"] = (v_u_13["unlock:TextBox:hidden"] or 0) + 1
				v42.popUnlock("TextBox")
			end
		else
			v_u_13["unlock:TextBox:none"] = (v_u_13["unlock:TextBox:none"] or 0) + 1
			v42.popUnlock("TextBox")
		end
	end
	if v42.unlockReasons.ChatFocus then
		local v55 = v_u_12
		if v55 and (v55.Parent and not v55.IsFocused) then
			v_u_13["unlock:ChatFocus"] = (v_u_13["unlock:ChatFocus"] or 0) + 1
			v42.popUnlock("ChatFocus")
		end
	end
	v_u_5.PruneTouches(v42.touches)
	local v56 = v42.blockers()
	local v57 = table.concat(v56, " ")
	if v57 ~= v_u_11 then
		v_u_11 = v57
		v_u_7:SetAttribute("CameraLookBlock", v57)
	end
end
function v_u_5.Step() -- name: Step
	-- upvalues: (ref) v_u_6, (ref) v_u_10, (copy) v_u_58
	if v_u_6 then
		local v59 = os.clock()
		if v59 - v_u_10 >= 0.25 then
			v_u_10 = v59
			v_u_58(v59)
		end
	else
		return
	end
end
function v_u_5.Stats() -- name: Stats
	-- upvalues: (copy) v_u_13
	return table.clone(v_u_13)
end
local v_u_60 = false
function v_u_5.Start(p61) -- name: Start
	-- upvalues: (ref) v_u_6, (ref) v_u_60, (copy) v_u_3, (ref) v_u_15, (ref) v_u_16, (ref) v_u_18, (ref) v_u_19, (copy) v_u_13, (copy) v_u_1
	v_u_6 = p61
	if not v_u_60 then
		v_u_60 = true
		v_u_3.InputBegan:Connect(function(p62)
			-- upvalues: (ref) v_u_15, (ref) v_u_16, (ref) v_u_18
			if v_u_15 == nil then
				return
			else
				local v63 = p62.UserInputType
				if v63 ~= v_u_16 or v63 == Enum.UserInputType.Keyboard and p62.KeyCode ~= v_u_15 then
					if v63 == Enum.UserInputType.Keyboard or (v63 == Enum.UserInputType.MouseButton1 or (v63 == Enum.UserInputType.MouseButton2 or v63 == Enum.UserInputType.MouseButton3)) then
						v_u_18 = false
					end
				end
			end
		end)
		v_u_3.WindowFocusReleased:Connect(function()
			-- upvalues: (ref) v_u_19, (ref) v_u_15, (ref) v_u_6, (ref) v_u_13
			v_u_19 = false
			v_u_15 = nil
			local v64 = v_u_6
			if v64 and next(v64.touches) ~= nil then
				table.clear(v64.touches)
				v_u_13["touches:focus"] = (v_u_13["touches:focus"] or 0) + 1
			end
			local v65 = v_u_6
			if v65 and v65.unlockReasons.FreeCursor then
				v_u_13["unlock:FreeCursor:focus"] = (v_u_13["unlock:FreeCursor:focus"] or 0) + 1
				v65.popUnlock("FreeCursor")
			end
		end)
		v_u_3.WindowFocused:Connect(function()
			-- upvalues: (ref) v_u_19
			v_u_19 = true
		end)
		v_u_1.MenuOpened:Connect(function()
			-- upvalues: (ref) v_u_15, (ref) v_u_6, (ref) v_u_13
			v_u_15 = nil
			local v66 = v_u_6
			if v66 and next(v66.touches) ~= nil then
				table.clear(v66.touches)
				v_u_13["touches:menu"] = (v_u_13["touches:menu"] or 0) + 1
			end
		end)
	end
end
return v_u_5