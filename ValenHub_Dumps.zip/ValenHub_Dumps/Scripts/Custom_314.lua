local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(v2:WaitForChild("Shared"):WaitForChild("Signal"))
local v_u_5 = require(v2.Shared:WaitForChild("CustomMatch"))
return {
	["Init"] = function(p_u_6) -- name: Init
		-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_3, (copy) v_u_5
		local v_u_7 = p_u_6.Remotes
		local v_u_8 = v_u_1.LocalPlayer
		local v_u_9 = false
		local v_u_10 = nil
		local v_u_11 = {
			["Changed"] = v_u_4.new(),
			["RevealChanged"] = v_u_4.new(),
			["MASK"] = "\226\128\162\226\128\162\226\128\162 \226\128\162\226\128\162\226\128\162"
		}
		v_u_7.Timeouts.CustomAction = 25
		v_u_7.Timeouts.CustomHost = 15
		function v_u_11.IsServer() -- name: IsServer
			-- upvalues: (ref) v_u_10, (ref) v_u_3
			return v_u_10 ~= nil and true or v_u_3:GetAttribute("CustomServer") == true
		end
		function v_u_11.State() -- name: State
			-- upvalues: (ref) v_u_10, (ref) v_u_9
			return v_u_10 or v_u_9
		end
		function v_u_11.Code() -- name: Code
			-- upvalues: (ref) v_u_10, (ref) v_u_9, (ref) v_u_3
			local v12 = v_u_10 or v_u_9
			if v12 then
				local v13 = v12.code
				if type(v13) == "string" then
					return v12.code
				end
			end
			local v14 = v_u_3:GetAttribute("CustomCode")
			return type(v14) ~= "string" and "" or v14
		end
		function v_u_11.IsHost() -- name: IsHost
			-- upvalues: (ref) v_u_10, (ref) v_u_9, (copy) v_u_8, (copy) v_u_11, (ref) v_u_3
			local v15 = v_u_10 or v_u_9
			if v15 and v15.custom then
				local v16 = v15.ownerId
				if type(v16) == "number" then
					return v15.ownerId == v_u_8.UserId
				end
			end
			local v17 = v_u_11.IsServer()
			if v17 then
				v17 = v_u_3:GetAttribute("CustomOwner") == v_u_8.UserId
			end
			return v17
		end
		function v_u_11.IsPrivate() -- name: IsPrivate
			-- upvalues: (ref) v_u_10, (ref) v_u_9, (copy) v_u_11
			local v18 = v_u_10 or v_u_9
			local v19 = v_u_11.IsServer()
			if v19 then
				if type(v18) == "table" then
					v19 = v18.public == false
				else
					v19 = false
				end
			end
			return v19
		end
		local v_u_20 = 0
		local v_u_21 = false
		function v_u_11.IsRevealed() -- name: IsRevealed
			-- upvalues: (ref) v_u_21
			return v_u_21
		end
		function v_u_11.Reveal(p22) -- name: Reveal
			-- upvalues: (ref) v_u_20, (ref) v_u_21, (copy) v_u_11
			v_u_20 = v_u_20 + 1
			local v_u_23 = v_u_20
			if not v_u_21 then
				v_u_21 = true
				v_u_11.RevealChanged:Fire(true)
			end
			task.delay(p22 or 10, function()
				-- upvalues: (copy) v_u_23, (ref) v_u_20, (ref) v_u_21, (ref) v_u_11
				if v_u_23 == v_u_20 and v_u_21 then
					v_u_21 = false
					v_u_11.RevealChanged:Fire(false)
				end
			end)
		end
		function v_u_11.Hide() -- name: Hide
			-- upvalues: (ref) v_u_20, (ref) v_u_21, (copy) v_u_11
			v_u_20 = v_u_20 + 1
			if v_u_21 then
				v_u_21 = false
				v_u_11.RevealChanged:Fire(false)
			end
		end
		function v_u_11.CodeShown() -- name: CodeShown
			-- upvalues: (copy) v_u_11, (ref) v_u_21, (ref) v_u_5
			return v_u_11.IsPrivate() and not v_u_21 and "\226\128\162\226\128\162\226\128\162 \226\128\162\226\128\162\226\128\162" or v_u_5.FormatCode(v_u_11.Code())
		end
		function v_u_11.MaskDots(p24) -- name: MaskDots
			-- upvalues: (copy) p_u_6
			local v25 = p_u_6.UI
			local v26 = p24.Dot or 8
			local v27 = p24.Gap or 4
			local v28 = p24.GroupGap or 10
			local v29 = v25.new("Frame", {
				["Name"] = p24.Name or "Mask",
				["AnchorPoint"] = p24.AnchorPoint or Vector2.new(1, 0.5),
				["Position"] = p24.Position or UDim2.new(),
				["Size"] = UDim2.fromOffset(6 * v26 + 4 * v27 + v28, v26),
				["Parent"] = p24.Parent
			})
			for v30 = 1, 6 do
				local v31 = (v30 - 1) * (v26 + v27) + (v30 <= 3 and 0 or v28 - v27)
				v25.new("Frame", {
					["Name"] = "Dot" .. v30,
					["Position"] = UDim2.fromOffset(v31, 0),
					["Size"] = UDim2.fromOffset(v26, v26),
					["BackgroundColor3"] = p24.Color or p_u_6.Theme.Colors.TextDim,
					v25.Corner(p_u_6.Theme.Radius.Pill),
					["Parent"] = v29
				})
			end
			return v29
		end
		local function v33(p32) -- name: apply
			-- upvalues: (ref) v_u_9, (ref) v_u_10, (copy) v_u_11
			if type(p32) == "table" then
				if p32.custom == false then
					v_u_9 = false
				else
					v_u_9 = p32
				end
				if not v_u_10 then
					v_u_11.Changed:Fire(v_u_10 or v_u_9)
				end
			end
		end
		v_u_7.On("CustomState", v33)
		function v_u_11.Host(p34, p35) -- name: Host
			-- upvalues: (ref) v_u_10, (copy) v_u_7, (ref) v_u_9, (copy) v_u_11
			if v_u_10 then
				return true, v_u_10
			else
				local v36, v37, v38 = v_u_7.Invoke("CustomHost", p34, p35)
				if v36 then
					if v37 == true then
						if type(v38) == "table" and type(v38) == "table" then
							if v38.custom == false then
								v_u_9 = false
							else
								v_u_9 = v38
							end
							if not v_u_10 then
								v_u_11.Changed:Fire(v_u_10 or v_u_9)
							end
						end
						return true, v38
					else
						local v39 = false
						if type(v38) == "string" then
							return v39, v38
						else
							return v39, "Couldn\'t do that"
						end
					end
				else
					return false, tostring(v37 or "Server unavailable")
				end
			end
		end
		function v_u_11.Action(p40, p41) -- name: Action
			-- upvalues: (copy) v_u_7
			local v42, v43, v44 = v_u_7.Invoke("CustomAction", p40, p41)
			if v42 then
				if v43 == true then
					return true, v44
				else
					local v45 = false
					if type(v44) == "string" then
						return v45, v44
					else
						return v45, "Couldn\'t do that"
					end
				end
			else
				return false, tostring(v43 or "Server unavailable")
			end
		end
		local function v48() -- name: fetch
			-- upvalues: (copy) v_u_11, (ref) v_u_9, (ref) v_u_10
			if v_u_11.IsServer() and not v_u_9 then
				task.spawn(function()
					-- upvalues: (ref) v_u_11, (ref) v_u_9, (ref) v_u_10
					local v46, v47 = v_u_11.Host("Get")
					if v46 and type(v47) == "table" then
						if type(v47) ~= "table" then
							return
						end
						if v47.custom == false then
							v_u_9 = false
						else
							v_u_9 = v47
						end
						if not v_u_10 then
							v_u_11.Changed:Fire(v_u_10 or v_u_9)
						end
					end
				end)
			end
		end
		v_u_3:GetAttributeChangedSignal("CustomServer"):Connect(function()
			-- upvalues: (ref) v_u_3, (ref) v_u_9, (copy) v_u_11, (ref) v_u_10
			if v_u_3:GetAttribute("CustomServer") == true then
				if v_u_11.IsServer() and not v_u_9 then
					task.spawn(function()
						-- upvalues: (ref) v_u_11, (ref) v_u_9, (ref) v_u_10
						local v49, v50 = v_u_11.Host("Get")
						if v49 and type(v50) == "table" then
							if type(v50) ~= "table" then
								return
							end
							if v50.custom == false then
								v_u_9 = false
							else
								v_u_9 = v50
							end
							if not v_u_10 then
								v_u_11.Changed:Fire(v_u_10 or v_u_9)
							end
						end
					end)
				end
			else
				v_u_9 = false
				v_u_11.Changed:Fire(v_u_10 or v_u_9)
			end
		end)
		v_u_3:GetAttributeChangedSignal("CustomOwner"):Connect(function()
			-- upvalues: (copy) v_u_11, (ref) v_u_10, (ref) v_u_9
			v_u_11.Changed:Fire(v_u_10 or v_u_9)
		end)
		task.delay(1, v48)
		function v_u_11.SetMock(p51) -- name: SetMock
			-- upvalues: (ref) v_u_10, (copy) v_u_11, (ref) v_u_9
			if type(p51) ~= "table" then
				p51 = nil
			end
			v_u_10 = p51
			v_u_11.Changed:Fire(v_u_10 or v_u_9)
		end
		p_u_6.Custom = v_u_11
	end
}