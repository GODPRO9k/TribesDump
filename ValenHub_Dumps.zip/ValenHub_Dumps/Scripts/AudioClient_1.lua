local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("RunService")
local v_u_4 = game:GetService("SoundService")
local v5 = v_u_2:WaitForChild("Shared")
local v_u_6 = require(v5:WaitForChild("Sfx"))
local v7 = require(v5:WaitForChild("Sounds"))
local v_u_8 = require(script.Parent:WaitForChild("Director"))
local v9 = v1.LocalPlayer
if v3:IsStudio() then
	local function v_u_12(p10) -- name: muteSound
		if p10:IsA("Sound") and not p10:FindFirstChild("StudioMute") then
			local v11 = Instance.new("EqualizerSoundEffect")
			v11.Name = "StudioMute"
			v11.LowGain = -80
			v11.MidGain = -80
			v11.HighGain = -80
			v11.Priority = 10000
			v11.Parent = p10
		end
	end
	local v_u_13 = nil
	local function v19() -- name: apply
		-- upvalues: (ref) v_u_13, (copy) v_u_12
		if workspace:GetAttribute("StudioAudio") ~= true then
			if not v_u_13 then
				v_u_13 = game.DescendantAdded:Connect(function(p14)
					if p14:IsA("Sound") and (p14:IsA("Sound") and not p14:FindFirstChild("StudioMute")) then
						local v15 = Instance.new("EqualizerSoundEffect")
						v15.Name = "StudioMute"
						v15.LowGain = -80
						v15.MidGain = -80
						v15.HighGain = -80
						v15.Priority = 10000
						v15.Parent = p14
					end
				end)
				for _, v16 in game:GetDescendants() do
					local v17 = v_u_12
					pcall(v17, v16)
				end
				return
			end
		else
			if v_u_13 then
				v_u_13:Disconnect()
				v_u_13 = nil
			end
			for _, v_u_18 in game:GetDescendants() do
				pcall(function()
					-- upvalues: (copy) v_u_18
					if v_u_18.Name == "StudioMute" and v_u_18:IsA("EqualizerSoundEffect") then
						v_u_18:Destroy()
					end
				end)
			end
		end
	end
	v19()
	workspace:GetAttributeChangedSignal("StudioAudio"):Connect(v19)
end
local function v25(p_u_20) -- name: hookGroup
	-- upvalues: (copy) v_u_4, (copy) v_u_6
	local v_u_21 = v_u_4:WaitForChild(p_u_20, 30)
	if v_u_21 then
		local v22 = v_u_21:GetAttribute("UserVolume")
		if type(v22) == "number" then
			v_u_6.SetVolume(p_u_20, v22)
		else
			v_u_6.ApplyGroups()
		end
		v_u_21:GetAttributeChangedSignal("UserVolume"):Connect(function()
			-- upvalues: (copy) v_u_21, (ref) v_u_6, (copy) p_u_20
			local v23 = v_u_21:GetAttribute("UserVolume")
			if type(v23) == "number" then
				local v24 = v23 - v_u_6.GetVolume(p_u_20)
				if math.abs(v24) > 0.001 then
					v_u_6.SetVolume(p_u_20, v23)
				end
			end
		end)
	else
		warn("[Audio] SoundGroup " .. p_u_20 .. " never arrived")
	end
end
for v26 in v7.GROUPS do
	task.spawn(v25, v26)
end
v_u_4:GetAttributeChangedSignal("MasterVolume"):Connect(function()
	-- upvalues: (copy) v_u_4, (copy) v_u_6
	local v27 = v_u_4:GetAttribute("MasterVolume")
	if type(v27) == "number" then
		local v28 = v27 - v_u_6.GetVolume("Master")
		if math.abs(v28) > 0.001 then
			v_u_6.SetVolume("Master", v27)
		end
	end
end)
task.spawn(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_6
	local v29 = v_u_2:WaitForChild("Remotes", 60)
	if v29 then
		v29 = v29:WaitForChild("SfxPlay", 60)
	end
	if v29 and v29:IsA("UnreliableRemoteEvent") then
		v29.OnClientEvent:Connect(function(p30, p31, p32, p33, p34)
			-- upvalues: (ref) v_u_6
			if type(p30) == "string" then
				local v35 = nil
				if typeof(p32) == "Instance" and p32.Parent then
					p31 = p32
				elseif typeof(p31) ~= "Vector3" then
					p31 = v35
				end
				local v36 = v_u_6.Play
				local v37 = {}
				if type(p33) ~= "number" then
					p33 = nil
				end
				v37.volume = p33
				if type(p34) ~= "number" then
					p34 = nil
				end
				v37.pitch = p34
				v36(p30, p31, v37)
			end
		end)
	end
end)
v_u_8.Start(v_u_6)
local v_u_38 = game:GetService("TextChatService")
local function v_u_41(p_u_39) -- name: chatLine
	-- upvalues: (copy) v_u_38
	local v_u_40 = v_u_38:FindFirstChild("TextChannels")
	if v_u_40 then
		v_u_40 = v_u_40:FindFirstChild("RBXSystem")
	end
	if v_u_40 and v_u_40:IsA("TextChannel") then
		pcall(function()
			-- upvalues: (copy) v_u_40, (copy) p_u_39
			v_u_40:DisplaySystemMessage((("<font color=\"#9FD8FF\"><b>\226\153\170</b></font> <font color=\"#E4E8F0\">%*</font>"):format(p_u_39)))
		end)
	end
end
local function v_u_59() -- name: nowPlaying
	-- upvalues: (copy) v_u_8, (copy) v_u_41
	local v42 = v_u_8.NowPlaying()
	if #v42 == 0 then
		v_u_41("No music is playing right now.")
	else
		for v43, v44 in v42 do
			local v45 = v44.src or v44.name
			local v46 = string.gsub(string.gsub(string.gsub(v45, "&", "&amp;"), "<", "&lt;"), ">", "&gt;")
			local v47
			if v44.length > 0 then
				local v48 = v44.at
				local v49 = math.floor(v48)
				local v50 = math.max(0, v49)
				local v51 = string.format("%d:%02d", v50 // 60, v50 % 60)
				local v52 = v44.length
				local v53 = math.floor(v52)
				local v54 = math.max(0, v53)
				v47 = (" \194\183 %* / %*"):format(v51, (string.format("%d:%02d", v54 // 60, v54 % 60)))
			else
				v47 = ""
			end
			local v55 = not v44.id and "" or (", id %*"):format(v44.id)
			local v56 = v_u_41
			local v57 = v43 == 1 and "Now playing" or "Also"
			local v58 = v44.name
			v56((("%*: <b>%*</b>%* (%*%*)"):format(v57, v46, v47, string.gsub(string.gsub(string.gsub(v58, "&", "&amp;"), "<", "&lt;"), ">", "&gt;"), v55)))
		end
	end
end
if not v_u_38:FindFirstChild("TribesMusic") then
	local v60 = Instance.new("TextChatCommand")
	v60.Name = "TribesMusic"
	v60.PrimaryAlias = "/music"
	v60.Triggered:Connect(function()
		-- upvalues: (copy) v_u_59
		v_u_59()
	end)
	v60.Parent = v_u_38
end
task.delay(3, function()
	-- upvalues: (copy) v_u_6
	v_u_6.Preload({
		"Hitmarker",
		"Hitmarker_Ranged",
		"Hitmarker_Headshot",
		"Kill_Confirm",
		"Kill_Confirm_Headshot",
		"Damage_Receive",
		"Damage_Receive_Heavy",
		"Match/Countdown_3",
		"Match/Countdown_2",
		"Match/Countdown_1",
		"Match/Fight",
		"Match/Fight_Drums",
		"Match/Elimination",
		"UI/Click",
		"UI/Hover",
		"UI/Open",
		"UI/Close"
	})
end)
if v3:IsStudio() then
	local v61 = v9:WaitForChild("PlayerScripts")
	local v62 = Instance.new("BindableFunction")
	v62.Name = "AudioDebug"
	function v62.OnInvoke(p63, ...)
		-- upvalues: (copy) v_u_8, (copy) v_u_6
		if p63 == "State" then
			return v_u_8.State()
		end
		if p63 == "Play" then
			local v64 = v_u_6.Play(...)
			return not v64 and "nil" or v64:GetFullName()
		end
		if p63 ~= "Stats" then
			return nil
		end
		local v65 = v_u_6.Stats()
		return string.format("live3D=%d pooled=%d", v65.live3D, v65.pooled)
	end
	v62.Parent = v61
end