local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("GuiService")
local v_u_4 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("CustomMatch"))
local v_u_5 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Keybinds"))
local v6 = {}
local v_u_7 = {
	["W"] = 1180,
	["H"] = 700,
	["left"] = 410,
	["gap"] = 24,
	["pad"] = 16,
	["sectionH"] = 24,
	["sectionGap"] = 8,
	["blockGap"] = 20,
	["status"] = 18,
	["button"] = 60,
	["hint"] = 16,
	["rowH"] = 62,
	["label"] = 18,
	["desc"] = 15,
	["switchW"] = 58,
	["mapCols"] = 4,
	["mapGap"] = 12,
	["mapName"] = 16,
	["playerH"] = 58,
	["playerName"] = 18,
	["playerSub"] = 14,
	["removeW"] = 104,
	["leaveH"] = 50
}
local v_u_8 = {
	["W"] = 1180,
	["H"] = 700,
	["left"] = 390,
	["gap"] = 16,
	["pad"] = 14,
	["sectionH"] = 24,
	["sectionGap"] = 6,
	["blockGap"] = 14,
	["status"] = 17,
	["button"] = 54,
	["hint"] = 15,
	["rowH"] = 56,
	["label"] = 17,
	["desc"] = 14,
	["switchW"] = 58,
	["mapCols"] = 3,
	["mapGap"] = 10,
	["mapName"] = 15,
	["playerH"] = 62,
	["playerName"] = 17,
	["playerSub"] = 13,
	["removeW"] = 112,
	["leaveH"] = 54
}
local v_u_9 = Color3.fromRGB(142, 149, 166)
function v6.Init(p_u_10) -- name: Init
	-- upvalues: (copy) v_u_1, (copy) v_u_8, (copy) v_u_7, (copy) v_u_9, (copy) v_u_4, (copy) v_u_2, (copy) v_u_5, (copy) v_u_3
	local v_u_11 = p_u_10.UI
	local v_u_12 = p_u_10.Theme
	local _ = p_u_10.State
	local v_u_13 = v_u_12.Colors
	local v_u_14 = v_u_12.Fonts
	local v_u_15 = p_u_10.Custom
	local v_u_16 = v_u_1.LocalPlayer
	local v_u_17 = UDim2.fromOffset
	local v_u_18
	if v_u_11.Compact then
		v_u_18 = v_u_8
	else
		v_u_18 = v_u_7
	end
	local v_u_19 = v_u_11.Window({
		["Name"] = "CustomHost",
		["Title"] = "CUSTOM MATCH",
		["Subtitle"] = "",
		["Size"] = nil,
		["HeaderHeight"] = 80,
		["Parent"] = nil,
		["OnCloseRequested"] = nil,
		["Size"] = v_u_17(v_u_18.W, v_u_18.H),
		["Parent"] = p_u_10.Canvas.Menus,
		["OnCloseRequested"] = function() -- name: OnCloseRequested
			-- upvalues: (copy) p_u_10
			p_u_10.MenuManager.Close("CustomHost")
		end
	})
	local v20 = v_u_19.Content
	v_u_11.SelectionRing(v_u_19.Root)
	local v_u_21 = v_u_11.new("Frame", {
		["Name"] = "Code",
		["AnchorPoint"] = Vector2.new(1, 0),
		["BackgroundColor3"] = v_u_13.Inset,
		["BackgroundTransparency"] = 0.2,
		v_u_11.Corner(10),
		v_u_11.Stroke(v_u_13.Accent, 1.5, 0.5),
		["Parent"] = v_u_19.Header
	})
	v_u_11.new("TextLabel", {
		["Name"] = "Cap",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "CODE",
		["FontFace"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["Position"] = v_u_17(14, 0),
		["Size"] = UDim2.new(0, 48, 1, 0),
		["FontFace"] = v_u_14.Heavy,
		["TextColor3"] = v_u_13.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_21
	})
	local v_u_22 = v_u_11.new("TextBox", {
		["Name"] = "Value",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["PlaceholderText"] = "",
		["TextEditable"] = false,
		["ClearTextOnFocus"] = false,
		["FontFace"] = nil,
		["TextSize"] = 28,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["BackgroundTransparency"] = 1,
		["Selectable"] = false,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -14, 0, 0),
		["Size"] = UDim2.new(1, -70, 1, 0),
		["FontFace"] = v_u_14.Display,
		["TextColor3"] = v_u_13.Text,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_21
	})
	local v_u_23 = v_u_15.MaskDots({
		["Name"] = "Mask",
		["Dot"] = 9,
		["Gap"] = 5,
		["GroupGap"] = 12,
		["Color"] = nil,
		["AnchorPoint"] = nil,
		["Parent"] = nil,
		["Color"] = v_u_13.TextDim,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Parent"] = v_u_21
	})
	v_u_23.Visible = false
	local v_u_24 = v_u_11.IconButton({
		["Name"] = "Reveal",
		["Size"] = nil,
		["AnchorPoint"] = nil,
		["Color"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Size"] = v_u_17(36, 36),
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Color"] = v_u_13.Raised,
		["Parent"] = v_u_21
	})
	local v_u_25 = v_u_11.Glyph("eye", 22, v_u_13.Text, {
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Parent"] = v_u_24
	})
	local v_u_26 = v_u_11.Glyph("two-stacked-squares", 18, v_u_13.Text)
	local v_u_27 = v_u_11.Button({
		["Name"] = "Copy",
		["Text"] = "COPY",
		["TextSize"] = 17,
		["Style"] = "Dark",
		["AnchorPoint"] = nil,
		["Icon"] = nil,
		["Gap"] = 6,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Icon"] = v_u_26,
		["Parent"] = v_u_19.Header
	})
	local v_u_28 = v_u_11.new("TextLabel", {
		["Name"] = "CopyHint",
		["AnchorPoint"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["FontFace"] = v_u_14.Bold,
		["TextColor3"] = v_u_13.Accent,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_19.Header
	})
	local function v31(p29, p30) -- name: card
		-- upvalues: (copy) v_u_11, (copy) v_u_13
		return v_u_11.new("Frame", {
			["Name"] = p29,
			["BackgroundColor3"] = v_u_13.PanelHi,
			["BackgroundTransparency"] = 0.3,
			v_u_11.Corner(12),
			v_u_11.Stroke(v_u_13.Stroke, 1, 0.92),
			["Parent"] = p30
		})
	end
	local v_u_32 = v_u_11.new("ScrollingFrame", {
		["Name"] = "Left",
		["ScrollBarThickness"] = 3,
		["AutomaticCanvasSize"] = nil,
		["VerticalScrollBarInset"] = nil,
		["Selectable"] = false,
		["Parent"] = nil,
		["AutomaticCanvasSize"] = Enum.AutomaticSize.None,
		["VerticalScrollBarInset"] = Enum.ScrollBarInset.None,
		["Parent"] = v20
	})
	local v_u_33 = v_u_11.SectionTitle("MATCH", {
		["Parent"] = v_u_32
	})
	local v_u_34 = v31("Match", v_u_32)
	local v_u_35 = v_u_11.new("Frame", {
		["Name"] = "Dot",
		["Size"] = v_u_17(10, 10),
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["BackgroundColor3"] = v_u_13.Success,
		v_u_11.Corner(v_u_12.Radius.Pill),
		["Parent"] = v_u_34
	})
	local v_u_36 = v_u_11.new("TextLabel", {
		["Name"] = "Status",
		["Text"] = "",
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_14.Heavy,
		["TextColor3"] = v_u_13.Text,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Parent"] = v_u_34
	})
	local v_u_37 = v_u_11.new("TextLabel", {
		["Name"] = "Teams",
		["AnchorPoint"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["FontFace"] = v_u_14.Bold,
		["TextColor3"] = v_u_13.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_34
	})
	local v_u_38 = v_u_11.Button({
		["Name"] = "Start",
		["Text"] = "START MATCH",
		["Style"] = "Primary",
		["Icon"] = nil,
		["Parent"] = nil,
		["Icon"] = v_u_11.Glyph("play-large", 26, v_u_13.Text),
		["Parent"] = v_u_34
	})
	local v_u_39 = v_u_11.new("Frame", {
		["Name"] = "HostedBy",
		["BackgroundColor3"] = v_u_13.Inset,
		["BackgroundTransparency"] = 0.35,
		["Visible"] = false,
		v_u_11.Corner(12),
		v_u_11.Stroke(v_u_13.Stroke, 1, 0.9),
		v_u_11.List(Enum.FillDirection.Horizontal, 10, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
		["Parent"] = v_u_34
	})
	v_u_11.Glyph("crown", 22, v_u_13.Gold, {
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["Parent"] = v_u_39
	})
	local v_u_40 = v_u_11.new("TextLabel", {
		["Name"] = "Text",
		["Text"] = "",
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["FontFace"] = v_u_14.Heavy,
		["TextColor3"] = v_u_13.TextDim,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = v_u_17(0, 24),
		["Parent"] = v_u_39
	})
	local v_u_41 = v_u_11.Button({
		["Name"] = "End",
		["Text"] = "END MATCH",
		["Style"] = "Danger",
		["Visible"] = false,
		["Parent"] = nil,
		["Parent"] = v_u_34
	})
	local v_u_42 = v_u_11.new("TextLabel", {
		["Name"] = "Hint",
		["Text"] = "",
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_14.SemiBold,
		["TextColor3"] = v_u_9,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Parent"] = v_u_34
	})
	local v_u_43 = v_u_11.SectionTitle("SETTINGS", {
		["Parent"] = v_u_32
	})
	local v_u_44 = v31("Settings", v_u_32)
	local function v50(p45, p46) -- name: row
		-- upvalues: (copy) v_u_11, (copy) v_u_44, (copy) v_u_13, (copy) v_u_17, (copy) v_u_15, (copy) v_u_12
		local v47 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["Parent"] = nil,
			["Name"] = p45,
			["Parent"] = v_u_44
		}
		local v48 = v_u_11.new("TextButton", v47)
		if p46 > 1 then
			v_u_11.new("Frame", {
				["Name"] = "Divider",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.93,
				["Size"] = nil,
				["Position"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_13.Stroke,
				["Size"] = UDim2.new(1, -32, 0, 1),
				["Position"] = v_u_17(16, 0),
				["Parent"] = v48
			})
		end
		local v_u_49 = v_u_11.new("Frame", {
			["Name"] = "Highlight",
			["BackgroundColor3"] = v_u_13.White,
			["BackgroundTransparency"] = 1,
			["Position"] = v_u_17(4, 4),
			["Size"] = UDim2.new(1, -8, 1, -8),
			v_u_11.Corner(9),
			["Parent"] = v48
		})
		v48.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_11, (ref) v_u_15, (copy) v_u_49, (ref) v_u_12
			if not v_u_11.Touch and v_u_15.IsHost() then
				v_u_11.Tween(v_u_49, v_u_12.Tween.Fast, {
					["BackgroundTransparency"] = 0.955
				})
			end
		end)
		v48.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_11, (copy) v_u_49, (ref) v_u_12
			v_u_11.Tween(v_u_49, v_u_12.Tween.Fast, {
				["BackgroundTransparency"] = 1
			})
		end)
		return v48, v_u_49
	end
	local function v53(p51, p52) -- name: rowText
		-- upvalues: (copy) v_u_11, (copy) v_u_13, (copy) v_u_14, (ref) v_u_9
		return v_u_11.Glyph("pencil", 22, v_u_13.Text, {
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Parent"] = p51
		}), v_u_11.new("TextLabel", {
			["Name"] = "Label",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Parent"] = nil,
			["Text"] = p52,
			["FontFace"] = v_u_14.Heavy,
			["TextColor3"] = v_u_13.Text,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = p51
		}), v_u_11.new("TextLabel", {
			["Name"] = "Desc",
			["Text"] = "",
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_14.SemiBold,
			["TextColor3"] = v_u_9,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = p51
		})
	end
	local v_u_54 = v50("NameRow", 1)
	local v_u_55, v_u_56, v_u_57 = v53(v_u_54, "SERVER NAME")
	v_u_57.TextColor3 = v_u_13.TextDim
	local v_u_58 = v_u_11.new("TextLabel", {
		["Name"] = "Edit",
		["AnchorPoint"] = nil,
		["Text"] = "EDIT",
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["FontFace"] = v_u_14.Heavy,
		["TextColor3"] = v_u_13.Accent,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_54
	})
	local v_u_59 = v_u_11.new("TextBox", {
		["Name"] = "NameBox",
		["Text"] = "",
		["PlaceholderText"] = "",
		["PlaceholderColor3"] = v_u_13.TextMuted,
		["ClearTextOnFocus"] = false,
		["FontFace"] = v_u_14.Bold,
		["TextColor3"] = v_u_13.Text,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["BackgroundColor3"] = v_u_13.Inset,
		["BackgroundTransparency"] = 0.05,
		["Visible"] = false,
		["ZIndex"] = 4,
		v_u_11.Corner(8),
		v_u_11.Padding(0, 10, 0, 10),
		["Parent"] = v_u_54
	})
	v_u_11.Stroke(v_u_13.Accent, 1.5, 0.3).Parent = v_u_59
	local v_u_60 = v50("PublicRow", 2)
	local v_u_61, v_u_62, v_u_63 = v53(v_u_60, "PUBLIC")
	local v_u_64 = v_u_11.Switch({
		["Width"] = 58,
		["AnchorPoint"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Parent"] = v_u_60
	})
	local v_u_65 = v50("BotsRow", 3)
	local v_u_66, _, v_u_67 = v53(v_u_65, "FILL WITH BOTS")
	v_u_66.Text = "three-people"
	v_u_67.Text = "Bots take the empty slots, up to 3v3"
	local v_u_68 = v_u_11.Switch({
		["Width"] = 58,
		["AnchorPoint"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Parent"] = v_u_65
	})
	local v_u_69 = v_u_11.new("TextLabel", {
		["Name"] = "Value",
		["AnchorPoint"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["FontFace"] = v_u_14.Heavy,
		["TextColor3"] = v_u_13.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_65
	})
	local v_u_70 = v_u_11.Button({
		["Name"] = "Leave",
		["Text"] = "LEAVE SERVER",
		["TextSize"] = 18,
		["Style"] = "Dark",
		["Parent"] = nil,
		["Parent"] = v_u_32
	})
	local v_u_71 = v_u_11.new("ScrollingFrame", {
		["Name"] = "Right",
		["ScrollBarThickness"] = 5,
		["AutomaticCanvasSize"] = nil,
		["Selectable"] = false,
		["Parent"] = nil,
		["AutomaticCanvasSize"] = Enum.AutomaticSize.None,
		["Parent"] = v20
	})
	local v_u_72 = v_u_11.new("Frame", {
		["Name"] = "Fade",
		["AnchorPoint"] = Vector2.new(0, 1),
		["BackgroundColor3"] = v_u_13.PanelLo,
		["ZIndex"] = 6,
		["Visible"] = false,
		v_u_11.Gradient(Color3.new(1, 1, 1), Color3.new(1, 1, 1), 90, NumberSequence.new(1, 0.05)),
		["Parent"] = v20
	})
	local function v_u_73() -- name: updateFade
		-- upvalues: (copy) v_u_72, (copy) v_u_71
		v_u_72.Visible = v_u_71.AbsoluteCanvasSize.Y - (v_u_71.CanvasPosition.Y + v_u_71.AbsoluteWindowSize.Y) > 2
	end
	v_u_71:GetPropertyChangedSignal("CanvasPosition"):Connect(v_u_73)
	v_u_71:GetPropertyChangedSignal("AbsoluteCanvasSize"):Connect(v_u_73)
	v_u_71:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(v_u_73)
	local v_u_74 = v_u_11.SectionTitle("MAP", {
		["Parent"] = v_u_71
	})
	local v_u_75 = v_u_11.new("TextLabel", {
		["Name"] = "MapValue",
		["AnchorPoint"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["FontFace"] = v_u_14.Heavy,
		["TextColor3"] = v_u_13.Accent,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_71
	})
	local v_u_76 = v_u_11.new("Frame", {
		["Name"] = "Maps",
		["Parent"] = nil,
		["Parent"] = v_u_71
	})
	local v_u_77 = v_u_11.SectionTitle("PLAYERS", {
		["Parent"] = v_u_71
	})
	local v_u_78 = v_u_11.new("Frame", {
		["Name"] = "Players",
		["Parent"] = nil,
		["Parent"] = v_u_71
	})
	local v_u_79 = false
	local v_u_80 = {}
	local v_u_81 = false
	local v_u_82 = false
	local v_u_83 = {}
	local v_u_84 = ""
	local v_u_85 = nil
	local function v_u_102(p86) -- name: buildMapCards
		-- upvalues: (ref) v_u_84, (copy) v_u_83, (copy) v_u_11, (copy) v_u_13, (copy) v_u_76, (copy) v_u_14, (ref) v_u_18, (copy) v_u_17, (copy) v_u_12, (copy) v_u_15, (copy) p_u_10, (ref) v_u_85
		local v87 = ""
		for _, v88 in p86 do
			v87 = v87 .. v88.id .. ";"
		end
		if v87 ~= v_u_84 then
			v_u_84 = v87
			for _, v89 in v_u_83 do
				v89.btn:Destroy()
			end
			table.clear(v_u_83)
			local v90 = {
				{
					["id"] = "",
					["name"] = "Random",
					["thumb"] = ""
				}
			}
			for _, v91 in p86 do
				table.insert(v90, v91)
			end
			for v92, v93 in v90 do
				local v94 = v_u_11.new("TextButton", {
					["Name"] = "Map_" .. (v93.id == "" and "Random" or v93.id),
					["Text"] = "",
					["AutoButtonColor"] = false,
					["BackgroundColor3"] = v_u_13.Raised,
					["LayoutOrder"] = v92,
					v_u_11.Corner(10),
					["Parent"] = v_u_76
				})
				local v95 = v_u_11.Stroke(v_u_13.Stroke, 1, 0.88)
				v95.Parent = v94
				local v96 = v_u_11.new("ImageLabel", {
					["Name"] = "Thumb",
					["Size"] = UDim2.fromScale(1, 1),
					["ScaleType"] = Enum.ScaleType.Crop,
					["Image"] = v93.thumb or "",
					["BackgroundTransparency"] = 1,
					v_u_11.Corner(10),
					["Parent"] = v94
				})
				if v93.id == "" then
					v_u_11.Gradient(Color3.fromRGB(52, 58, 74), Color3.fromRGB(26, 29, 38), 120).Parent = v94
					v94.BackgroundColor3 = Color3.new(1, 1, 1)
					v_u_11.new("TextLabel", {
						["Name"] = "Mark",
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Text"] = "?",
						["FontFace"] = nil,
						["TextSize"] = 46,
						["TextColor3"] = nil,
						["Parent"] = nil,
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.fromScale(0.5, 0.4),
						["Size"] = UDim2.fromScale(1, 0.6),
						["FontFace"] = v_u_14.Display,
						["TextColor3"] = v_u_13.TextDim,
						["Parent"] = v94
					})
				end
				local v97 = v_u_11.new("Frame", {
					["Name"] = "Band",
					["AnchorPoint"] = Vector2.new(0, 1),
					["Position"] = UDim2.fromScale(0, 1),
					["Size"] = UDim2.new(1, 0, 0, 34),
					["BackgroundColor3"] = v_u_13.Void,
					["BackgroundTransparency"] = 0,
					v_u_11.Corner(10),
					v_u_11.Gradient(Color3.new(1, 1, 1), Color3.new(1, 1, 1), 90, NumberSequence.new(0.85, 0.2)),
					["Parent"] = v94
				})
				local v98 = v_u_11.new("TextLabel", {
					["Name"] = "MapName",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = nil,
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["TextTruncate"] = nil,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0, 1),
					["Position"] = UDim2.new(0, 10, 1, -6),
					["Size"] = UDim2.new(1, -20, 0, 20),
					["Text"] = string.upper(v93.name),
					["FontFace"] = v_u_14.Heavy,
					["TextSize"] = v_u_18.mapName,
					["TextColor3"] = v_u_13.Text,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["TextTruncate"] = Enum.TextTruncate.AtEnd,
					["Parent"] = v97
				})
				local v99 = v_u_11.new("Frame", {
					["Name"] = "Check",
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1, -8, 0, 8),
					["Size"] = v_u_17(26, 26),
					["BackgroundColor3"] = v_u_13.Accent,
					["Visible"] = false,
					["ZIndex"] = 3,
					v_u_11.Corner(v_u_12.Radius.Pill),
					v_u_11.Stroke(v_u_13.Void, 1, 0.6),
					["Parent"] = v94
				})
				v_u_11.Icon("check", 16, v_u_13.Text, {
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["ZIndex"] = 4,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Parent"] = v99
				})
				local v_u_100 = {
					["id"] = v93.id,
					["btn"] = v94,
					["stroke"] = v95,
					["check"] = v99,
					["img"] = v96,
					["name"] = v98,
					["scaleObj"] = v_u_11.GetScaleObj(v94, "HoverScale")
				}
				v94.MouseEnter:Connect(function()
					-- upvalues: (ref) v_u_11, (ref) v_u_15, (ref) p_u_10, (copy) v_u_100, (ref) v_u_12
					if not v_u_11.Touch and v_u_15.IsHost() then
						p_u_10.Sounds.Play("Hover")
						v_u_11.Tween(v_u_100.scaleObj, v_u_12.Tween.PopSmall, {
							["Scale"] = 1.03
						})
						if v_u_100.stroke.Thickness < 2 then
							v_u_11.Tween(v_u_100.stroke, v_u_12.Tween.Fast, {
								["Transparency"] = 0.55
							})
						end
					end
				end)
				v94.MouseLeave:Connect(function()
					-- upvalues: (ref) v_u_11, (copy) v_u_100, (ref) v_u_12
					v_u_11.Tween(v_u_100.scaleObj, v_u_12.Tween.PopSmall, {
						["Scale"] = 1
					})
					if v_u_100.stroke.Thickness < 2 then
						v_u_11.Tween(v_u_100.stroke, v_u_12.Tween.Fast, {
							["Transparency"] = 0.88
						})
					end
				end)
				v94.Activated:Connect(function()
					-- upvalues: (ref) v_u_15, (ref) v_u_85, (copy) v_u_100
					if v_u_15.IsHost() then
						v_u_85(v_u_100.id)
					end
				end)
				local v101 = v_u_83
				table.insert(v101, v_u_100)
			end
		end
	end
	local v_u_103 = {}
	local v_u_104 = {}
	local v_u_105 = nil
	local function v_u_112(p106, p107, p108, p109, p110) -- name: tag
		-- upvalues: (copy) v_u_11, (copy) v_u_17, (copy) v_u_12, (copy) v_u_14
		local v111 = v_u_11.new("Frame", {
			["Name"] = "Tag",
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = v_u_17(0, 20),
			["BackgroundColor3"] = p108,
			["LayoutOrder"] = p110,
			v_u_11.Corner(v_u_12.Radius.Pill),
			v_u_11.Padding(0, 8, 0, 8),
			["Parent"] = p106
		})
		v_u_11.new("TextLabel", {
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 12,
			["TextColor3"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = p107,
			["FontFace"] = v_u_14.Heavy,
			["TextColor3"] = p109,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromScale(0, 1),
			["Parent"] = v111
		})
	end
	local function v_u_126(p113) -- name: makePRow
		-- upvalues: (copy) v_u_11, (copy) v_u_13, (copy) v_u_78, (copy) v_u_12, (copy) v_u_14, (ref) v_u_9, (copy) v_u_17, (ref) v_u_105, (copy) v_u_104, (ref) v_u_1
		local v114 = v_u_11.new("Frame", {
			["Name"] = "P" .. p113.userId,
			["BackgroundColor3"] = v_u_13.PanelHi,
			["BackgroundTransparency"] = 0.3,
			v_u_11.Corner(10),
			["Parent"] = v_u_78
		})
		local v_u_115 = v_u_11.new("ImageLabel", {
			["Name"] = "Headshot",
			["BackgroundColor3"] = v_u_13.Raised,
			v_u_11.Corner(v_u_12.Radius.Pill),
			["Parent"] = v114
		})
		local v116 = v_u_11.new("Frame", {
			["Name"] = "Line",
			v_u_11.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
			["Parent"] = v114
		})
		local v117 = v_u_11.new("TextLabel", {
			["Name"] = "PlayerName",
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["FontFace"] = v_u_14.Heavy,
			["TextColor3"] = v_u_13.Text,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Parent"] = v116
		})
		v_u_11.new("UISizeConstraint", {
			["Parent"] = v117
		})
		local v118 = v_u_11.new("TextLabel", {
			["Name"] = "Username",
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_14.SemiBold,
			["TextColor3"] = v_u_9,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v114
		})
		local v119 = v_u_11.new("Frame", {
			["Name"] = "Tags",
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = v_u_17(0, 20),
			["LayoutOrder"] = 2,
			v_u_11.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
			["Parent"] = v116
		})
		v117:SetAttribute("_cap", true)
		local v120 = v_u_11.Button({
			["Name"] = "Remove",
			["Text"] = "REMOVE",
			["TextSize"] = 15,
			["Style"] = "Dark",
			["AnchorPoint"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Parent"] = v114
		})
		local v_u_121 = {
			["frame"] = v114,
			["img"] = v_u_115,
			["name"] = v117,
			["sub"] = v118,
			["tags"] = v119,
			["remove"] = v120,
			["userId"] = p113.userId
		}
		v120.Activated:Connect(function()
			-- upvalues: (ref) v_u_105, (copy) v_u_121
			v_u_105(v_u_121.userId, v_u_121.name.Text)
		end)
		local v_u_122 = p113.userId
		if v_u_122 <= 0 then
			v_u_115.Image = ""
			return v_u_121
		elseif v_u_104[v_u_122] then
			v_u_115.Image = v_u_104[v_u_122]
			return v_u_121
		else
			task.spawn(function()
				-- upvalues: (ref) v_u_1, (copy) v_u_122, (ref) v_u_104, (copy) v_u_115
				local function v123()
					-- upvalues: (ref) v_u_1, (ref) v_u_122
					return v_u_1:GetUserThumbnailAsync(v_u_122, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size150x150)
				end
				local v124, v125 = pcall(v123)
				if v124 and type(v125) == "string" then
					v_u_104[v_u_122] = v125
					if v_u_115.Parent then
						v_u_115.Image = v125
					end
				end
			end)
			return v_u_121
		end
	end
	local function v_u_144(p127, p128) -- name: layoutPRow
		-- upvalues: (ref) v_u_18, (copy) v_u_17, (copy) v_u_11
		local v129 = v_u_18.playerH
		p127.frame.Size = v_u_17(p128, v129)
		local v130 = p127.img
		local v131 = v_u_17
		local v132 = (v129 - 40) / 2
		v130.Position = v131(10, (math.floor(v132)))
		p127.img.Size = v_u_17(40, 40)
		local v133 = p128 - 62 - 16 - v_u_18.removeW - 12
		local v134 = math.max(160, v133)
		local v135 = p127.name.Parent
		local v136 = v_u_17
		local v137 = v129 / 2
		v135.Position = v136(62, math.floor(v137) - v_u_18.playerName - 3)
		v135.Size = v_u_17(v134, v_u_18.playerName + 4)
		p127.name.Size = v_u_17(0, v_u_18.playerName + 4)
		p127.name.TextSize = v_u_18.playerName
		local v138 = p127.name:FindFirstChildOfClass("UISizeConstraint")
		local v139 = Vector2.new
		local v140 = v134 - 170
		v138.MaxSize = v139(math.max(80, v140), v_u_18.playerName + 4)
		local v141 = p127.sub
		local v142 = v_u_17
		local v143 = v129 / 2
		v141.Position = v142(62, math.floor(v143) + 2)
		p127.sub.Size = v_u_17(v134, v_u_18.playerSub + 2)
		p127.sub.TextSize = v_u_18.playerSub
		p127.remove.Instance.Position = UDim2.new(1, -10, 0.5, 0)
		p127.remove.Instance.Size = v_u_17(v_u_18.removeW, v_u_11.Compact and 48 or 40)
	end
	local v_u_145 = 600
	local function v_u_173(p146) -- name: paintPlayers
		-- upvalues: (copy) v_u_103, (copy) v_u_126, (copy) v_u_144, (ref) v_u_145, (copy) v_u_17, (ref) v_u_18, (copy) v_u_112, (copy) v_u_13, (copy) v_u_12, (copy) v_u_16, (copy) v_u_15, (copy) v_u_78, (copy) v_u_77, (ref) v_u_4
		local v147 = p146.players
		local v148 = type(v147) ~= "table" and {} or p146.players
		local v149 = {}
		local v150 = 0
		for v151, v152 in v148 do
			if type(v152) ~= "table" then
				continue
			end
			local v153 = v152.userId
			if type(v153) ~= "number" then
				continue
			end
			v149[v152.userId] = true
			local v154 = v_u_103[v152.userId]
			if not v154 then
				v154 = v_u_126(v152)
				v_u_103[v152.userId] = v154
			end
			v_u_144(v154, v_u_145)
			v154.frame.Position = v_u_17(0, v150)
			v150 = v150 + (v_u_18.playerH + 6)
			local v155 = v154.name
			local v156 = v152.name or "?"
			v155.Text = tostring(v156)
			local v157 = v154.sub
			local v158 = v152.username or ""
			v157.Text = "@" .. tostring(v158)
			for _, v159 in v154.tags:GetChildren() do
				if not v159:IsA("GuiObject") then
					continue
				end
				v159:Destroy()
			end
			local v160 = v152.userId == p146.ownerId
			if v160 then
				v_u_112(v154.tags, "HOST", v_u_13.Gold:Lerp(v_u_13.Panel, 0.72), v_u_12.Lighten(v_u_13.Gold, 0.1), 1)
			end
			if v152.userId == v_u_16.UserId then
				v_u_112(v154.tags, "YOU", v_u_13.Accent:Lerp(v_u_13.Panel, 0.7), v_u_12.Lighten(v_u_13.Accent, 0.25), 2)
			end
			if v152.playing then
				v_u_112(v154.tags, "PLAYING", v_u_13.Success:Lerp(v_u_13.Panel, 0.75), v_u_12.Lighten(v_u_13.Success, 0.1), 3)
			elseif v152.watching then
				v_u_112(v154.tags, "WATCHING", v_u_13.Accent:Lerp(v_u_13.Panel, 0.75), v_u_12.Lighten(v_u_13.Accent, 0.25), 3)
			elseif v152.satOut then
				v_u_112(v154.tags, "NEXT UP", v_u_13.Warning:Lerp(v_u_13.Panel, 0.75), v_u_12.Lighten(v_u_13.Warning, 0.1), 3)
			end
			local v161 = v154.remove.Instance
			local v162 = not v160
			if v162 then
				if v152.userId == v_u_16.UserId then
					v162 = false
				else
					v162 = v_u_15.IsHost()
				end
			end
			v161.Visible = v162
			v154.frame.LayoutOrder = v151
		end
		for v163, v164 in v_u_103 do
			if v149[v163] then
				continue
			end
			v164.frame:Destroy()
			v_u_103[v163] = nil
		end
		local v165 = v_u_78
		local v166 = v_u_17
		local v167 = v_u_145
		local v168 = v150 - 6
		v165.Size = v166(v167, (math.max(0, v168)))
		local v169 = v_u_77.Text
		local v170 = string.format
		local v171 = #v148
		local v172 = p146.max
		v169.Text = v170("PLAYERS  \194\183  %d/%d", v171, tonumber(v172) or v_u_4.MAX_PLAYERS)
	end
	local function v_u_184(p174) -- name: teamsPreview
		-- upvalues: (ref) v_u_4, (copy) v_u_80
		local v175 = p174.players
		local v176 = 0
		for _, v177 in type(v175) ~= "table" and {} or p174.players do
			if v177.playing then
				continue
			end
			v176 = v176 + 1
		end
		local v178 = v_u_4.TEAM_SIZE * 2
		local v179 = math.min(v176, v178)
		local v180 = v179 / 2
		local v181 = math.ceil(v180)
		local v182 = v179 - v181
		local v183
		if v_u_80.bots == nil then
			v183 = p174.bots
		else
			v183 = v_u_80.bots
		end
		if v183 then
			return string.format("%d V %d", v_u_4.TEAM_SIZE, v_u_4.TEAM_SIZE)
		else
			return v179 < 2 and "" or string.format("%d V %d", v181, v182)
		end
	end
	local function v_u_194(p185, p186) -- name: paintSwitches
		-- upvalues: (copy) v_u_15, (copy) v_u_80, (copy) v_u_64, (copy) v_u_62, (copy) v_u_61, (copy) v_u_63, (copy) v_u_68, (copy) v_u_69, (copy) v_u_13, (copy) v_u_58, (ref) v_u_82, (copy) v_u_54, (copy) v_u_43
		local v187 = v_u_15.IsHost()
		local v188
		if v_u_80.public == nil then
			v188 = p185.public == true
		else
			v188 = v_u_80.public
		end
		v_u_64:Set(v188, p186)
		v_u_64.Instance.Visible = v187
		v_u_62.Text = v188 and "PUBLIC" or "PRIVATE"
		v_u_61.Text = v188 and "globe-simplified" or "lock-closed"
		v_u_63.Text = v188 and "Listed in every lobby\'s Custom Matches" or "Only people with the code can join"
		local v189
		if v_u_80.bots == nil then
			v189 = p185.bots == true
		else
			v189 = v_u_80.bots
		end
		v_u_68:Set(v189, p186)
		v_u_68.Instance.Visible = v187
		v_u_69.Visible = not v187
		v_u_69.Text = v189 and "ON" or "OFF"
		local v190 = v_u_69
		local v191
		if v189 then
			v191 = v_u_13.Text
		else
			v191 = v_u_13.TextDim
		end
		v190.TextColor3 = v191
		local v192 = v_u_58
		local v193
		if v187 then
			v193 = not v_u_82
		else
			v193 = v187
		end
		v192.Visible = v193
		v_u_54.AutoButtonColor = false
		v_u_43.Text.Text = v187 and "SETTINGS" or "SERVER"
	end
	local function v_u_206(p195) -- name: paintMaps
		-- upvalues: (copy) v_u_102, (copy) v_u_80, (copy) v_u_83, (copy) v_u_13, (copy) v_u_75
		local v196 = v_u_102
		local v197 = p195.maps
		v196(type(v197) ~= "table" and {} or p195.maps)
		local v198
		if v_u_80.map == nil then
			v198 = p195.map or ""
		else
			v198 = v_u_80.map
		end
		for _, v199 in v_u_83 do
			local v200 = v199.id == v198
			v199.check.Visible = v200
			local v201 = v199.stroke
			local v202
			if v200 then
				v202 = v_u_13.Accent
			else
				v202 = v_u_13.Stroke
			end
			v201.Color = v202
			v199.stroke.Thickness = v200 and 3 or 1
			v199.stroke.Transparency = v200 and 0 or 0.88
			v199.img.ImageTransparency = (v200 or v198 == "") and 0 or 0.15
		end
		local v203 = p195.maps
		local v204 = "RANDOM"
		for _, v205 in type(v203) ~= "table" and {} or p195.maps do
			if v205.id ~= v198 then
				continue
			end
			v204 = string.upper(v205.name)
		end
		v_u_75.Text = v204
	end
	local function v_u_223(p207) -- name: paintMatch
		-- upvalues: (copy) v_u_15, (copy) v_u_38, (copy) v_u_41, (copy) v_u_39, (copy) v_u_40, (ref) v_u_81, (copy) v_u_35, (copy) v_u_13, (copy) v_u_36, (copy) v_u_37, (copy) v_u_184, (copy) v_u_42, (ref) v_u_9, (copy) v_u_80, (copy) v_u_12
		local v208 = p207.status or "Lobby"
		local v209 = v208 == "Match" and true or v208 == "Results"
		local v210 = v_u_15.IsHost()
		local v211 = v_u_38.Instance
		local v212
		if v210 then
			v212 = not v209
		else
			v212 = v210
		end
		v211.Visible = v212
		v_u_41.Instance.Visible = v210 and v209
		v_u_39.Visible = not v210
		local v213 = v_u_40
		local v214 = string.upper
		local v215 = p207.ownerName or "?"
		v213.Text = "HOSTED BY " .. v214((tostring(v215)))
		v_u_41:SetText(v208 == "Results" and "CLOSE RESULTS" or "END MATCH")
		local v216 = v_u_38
		local v217
		if p207.canStart == true then
			v217 = not v_u_81
		else
			v217 = false
		end
		v216:SetEnabled(v217)
		v_u_38:SetText(p207.startHint == "Starting..." and "STARTING..." or "START MATCH")
		if v208 == "Match" then
			v_u_35.BackgroundColor3 = v_u_13.Warning
			v_u_36.Text = "Match in progress"
		elseif v208 == "Results" then
			v_u_35.BackgroundColor3 = v_u_13.Accent
			v_u_36.Text = "Showing the results"
		else
			v_u_35.BackgroundColor3 = v_u_13.Success
			v_u_36.Text = "Waiting to start"
		end
		v_u_37.Text = v209 and "" or v_u_184(p207)
		if v209 then
			v_u_42.Text = "Everyone comes back here after the match"
			v_u_42.TextColor3 = v_u_9
			return
		elseif v210 then
			if p207.canStart then
				local v218
				if v_u_80.bots == nil then
					v218 = p207.bots == true
				else
					v218 = v_u_80.bots
				end
				v_u_42.Text = v218 and "Teams are shuffled, bots fill the empty slots" or "Teams are shuffled every match"
				v_u_42.TextColor3 = v_u_9
			else
				local v219 = v_u_42
				local v220 = p207.startHint or ""
				v219.Text = tostring(v220)
				local v221 = v_u_42
				local v222
				if p207.startHint == "Starting..." then
					v222 = v_u_9
				else
					v222 = v_u_12.Lighten(v_u_13.Warning, 0.15)
				end
				v221.TextColor3 = v222
			end
		else
			v_u_42.Text = "The host picks the map and starts the match"
			v_u_42.TextColor3 = v_u_9
			return
		end
	end
	local v_u_224 = false
	local function v_u_232(p225) -- name: paintCode
		-- upvalues: (copy) v_u_15, (ref) v_u_4, (copy) v_u_22, (copy) v_u_23, (copy) v_u_24, (copy) v_u_25
		local v226 = p225.public == false
		local v227
		if v226 then
			v227 = not v_u_15.IsRevealed()
		else
			v227 = v226
		end
		local v228 = v_u_4.FormatCode
		local v229 = p225.code or ""
		local v230 = v228((tostring(v229)))
		if v_u_22.Text ~= v230 then
			v_u_22.Text = v230
		end
		v_u_22.TextTransparency = v227 and 1 or 0
		v_u_23.Visible = v227
		v_u_24.Visible = v226
		v_u_25.Text = v_u_15.IsRevealed() and "eye-slash" or "eye"
		local v231 = v226 and -52 or -14
		v_u_22.Position = UDim2.new(1, v231, 0, 0)
		v_u_23.Position = UDim2.new(1, v231 - 2, 0.5, 0)
		v_u_22.Size = UDim2.new(1, v231 - 56, 1, 0)
	end
	local function v_u_245(p233) -- name: paintHeader
		-- upvalues: (copy) v_u_19, (copy) v_u_15, (ref) v_u_4, (copy) v_u_232, (copy) v_u_59, (copy) v_u_57
		v_u_19.Title.Text = "CUSTOM MATCH"
		local v234 = p233.players
		local v235 = type(v234) == "table" and #p233.players or 0
		local v236
		if v_u_15.IsHost() then
			v236 = ""
		else
			local v237 = p233.ownerName or "?"
			v236 = "  \194\183  hosted by " .. tostring(v237)
		end
		local v238 = v_u_19.Subtitle
		local v239 = string.format
		local v240 = p233.name or ""
		local v241 = tostring(v240)
		local v242 = p233.max
		v238.Text = v239("%s  \194\183  %d/%d players%s", v241, v235, tonumber(v242) or v_u_4.MAX_PLAYERS, v236)
		v_u_232(p233)
		if not v_u_59.Visible then
			local v243 = v_u_57
			local v244 = p233.name or ""
			v243.Text = tostring(v244)
		end
	end
	local v_u_246 = false
	local function v_u_250(p247) -- name: paint
		-- upvalues: (copy) v_u_15, (ref) v_u_79, (copy) v_u_245, (copy) v_u_223, (copy) v_u_194, (copy) v_u_206, (copy) v_u_173, (copy) v_u_78, (ref) v_u_246, (copy) v_u_70, (copy) v_u_17, (ref) v_u_18, (copy) v_u_71
		local v248 = v_u_15.State() or {}
		v_u_79 = v248
		v_u_245(v248)
		v_u_223(v248)
		v_u_194(v248, p247)
		v_u_206(v248)
		v_u_173(v248)
		local v249 = v_u_78.Position.Y.Offset + v_u_78.Size.Y.Offset
		if v_u_246 then
			v_u_70.Instance.Position = v_u_17(v_u_78.Position.X.Offset, v249 + 16)
			v249 = v249 + (16 + v_u_18.leaveH)
		end
		v_u_71.CanvasSize = v_u_17(0, v249 + 8)
	end
	local function v_u_257(p251, p252, p253, p254) -- name: host
		-- upvalues: (copy) v_u_80, (copy) v_u_250, (copy) v_u_15, (copy) p_u_10
		if p253 then
			v_u_80[p253] = p254
			v_u_250()
		end
		local v255, v256 = v_u_15.Host(p251, p252)
		if p253 then
			v_u_80[p253] = nil
		end
		if not v255 then
			p_u_10.Toast(tostring(v256), "error")
		end
		v_u_250()
		return v255
	end
	v_u_85 = function(p258)
		-- upvalues: (copy) v_u_15, (copy) v_u_80, (copy) p_u_10, (copy) v_u_83, (copy) v_u_11, (copy) v_u_257
		local v259 = v_u_15.State() or {}
		local v260
		if v_u_80.map == nil then
			v260 = v259.map or ""
		else
			v260 = v_u_80.map
		end
		if p258 ~= v260 then
			p_u_10.Sounds.Play("Select")
			for _, v261 in v_u_83 do
				if v261.id ~= p258 then
					continue
				end
				v_u_11.Bump(v261.btn, 0.05)
			end
			task.spawn(v_u_257, "SetMap", p258, "map", p258)
		end
	end
	v_u_60.Activated:Connect(function()
		-- upvalues: (copy) v_u_15, (copy) v_u_80, (copy) p_u_10, (copy) v_u_257
		if v_u_15.IsHost() then
			local v262 = v_u_15.State() or {}
			local v263
			if v_u_80.public == nil then
				v263 = v262.public == true
			else
				v263 = v_u_80.public
			end
			p_u_10.Sounds.Play("Click", {
				["pitch"] = v263 and 0.94 or 1.08
			})
			task.spawn(v_u_257, "SetPublic", not v263, "public", not v263)
		end
	end)
	v_u_65.Activated:Connect(function()
		-- upvalues: (copy) v_u_15, (copy) v_u_80, (copy) p_u_10, (copy) v_u_257
		if v_u_15.IsHost() then
			local v264 = v_u_15.State() or {}
			local v265
			if v_u_80.bots == nil then
				v265 = v264.bots == true
			else
				v265 = v_u_80.bots
			end
			p_u_10.Sounds.Play("Click", {
				["pitch"] = v265 and 0.94 or 1.08
			})
			task.spawn(v_u_257, "SetBots", not v265, "bots", not v265)
		end
	end)
	v_u_38.Activated:Connect(function()
		-- upvalues: (ref) v_u_81, (copy) v_u_38, (copy) v_u_15, (copy) p_u_10, (copy) v_u_250
		if v_u_81 then
			return
		else
			v_u_81 = true
			v_u_38:SetText("STARTING...")
			v_u_38:SetEnabled(false)
			local v266, v267 = v_u_15.Host("Start", nil)
			if not v266 then
				p_u_10.Toast(tostring(v267), "error")
			end
			v_u_250()
			v_u_81 = false
			if v266 then
				p_u_10.Sounds.Play("Match_Found")
				p_u_10.MenuManager.Close("CustomHost")
			else
				v_u_250()
			end
		end
	end)
	v_u_54.Activated:Connect(function()
		-- upvalues: (copy) v_u_15, (copy) p_u_10, (ref) v_u_82, (copy) v_u_59, (ref) v_u_4, (copy) v_u_16, (copy) v_u_57, (copy) v_u_56, (copy) v_u_58, (copy) v_u_55
		if v_u_15.IsHost() then
			p_u_10.Sounds.Play("Click")
			if not v_u_82 then
				v_u_82 = true
				local v268 = v_u_59
				local v269 = (v_u_15.State() or {}).name or ""
				v268.Text = tostring(v269)
				v_u_59.PlaceholderText = v_u_4.DefaultName(v_u_16.DisplayName)
				v_u_59.Visible = true
				v_u_57.Visible = false
				v_u_56.Visible = false
				v_u_58.Visible = false
				v_u_55.Visible = false
				v_u_59:CaptureFocus()
			end
		else
			return
		end
	end)
	v_u_59:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_59, (ref) v_u_4
		local v270 = v_u_59.Text
		if (utf8.len(v270) or #v270) > v_u_4.NAME_MAX then
			local v271 = v_u_59
			local v272 = (utf8.offset(v270, v_u_4.NAME_MAX + 1) or #v270 + 1) - 1
			v271.Text = string.sub(v270, 1, v272)
		end
	end)
	v_u_59.FocusLost:Connect(function()
		-- upvalues: (ref) v_u_82, (copy) v_u_59, (copy) v_u_15, (copy) v_u_57, (copy) v_u_56, (copy) v_u_58, (copy) v_u_55, (ref) v_u_4, (copy) v_u_16, (copy) p_u_10, (copy) v_u_250
		if v_u_82 then
			local v_u_273 = v_u_59.Text
			local v274 = (v_u_15.State() or {}).name or ""
			local v_u_275 = tostring(v274)
			v_u_82 = false
			v_u_59.Visible = false
			v_u_57.Visible = true
			v_u_56.Visible = true
			v_u_58.Visible = true
			v_u_55.Visible = true
			if v_u_4.CleanName(v_u_273) ~= v_u_275 then
				local v276 = v_u_57
				local v277
				if v_u_4.CleanName(v_u_273) == "" then
					v277 = v_u_4.DefaultName(v_u_16.DisplayName)
				else
					v277 = v_u_4.CleanName(v_u_273)
				end
				v276.Text = v277
				task.spawn(function()
					-- upvalues: (copy) v_u_273, (ref) v_u_15, (ref) p_u_10, (ref) v_u_250, (ref) v_u_57, (copy) v_u_275
					local v278 = v_u_273
					local v279, v280 = v_u_15.Host("SetName", v278)
					if not v279 then
						p_u_10.Toast(tostring(v280), "error")
					end
					v_u_250()
					if v279 then
						p_u_10.Sounds.Play("Select")
					else
						v_u_57.Text = v_u_275
					end
				end)
			end
		else
			return
		end
	end)
	v_u_24.Activated:Connect(function()
		-- upvalues: (copy) v_u_15
		if v_u_15.IsRevealed() then
			v_u_15.Hide()
		else
			v_u_15.Reveal()
		end
	end)
	local v_u_281 = 0
	local v_u_282 = 0
	local function v_u_286() -- name: copyCode
		-- upvalues: (copy) v_u_15, (copy) v_u_11, (copy) v_u_232, (ref) v_u_281, (ref) v_u_282, (copy) v_u_26, (ref) v_u_224, (copy) v_u_22, (copy) v_u_28, (copy) v_u_27
		local v283 = v_u_15.State() or {}
		local v284 = v283.code
		if type(v284) == "string" and v283.code ~= "" then
			if v_u_11.Touch and (v283.public == false and not v_u_15.IsRevealed()) then
				v_u_15.Reveal()
			end
			v_u_232(v283)
			v_u_281 = v_u_281 + 1
			v_u_282 = 0
			v_u_26.Text = "two-stacked-squares"
			v_u_224 = true
			v_u_22:CaptureFocus()
			local function v285() -- name: selectAll
				-- upvalues: (ref) v_u_224, (ref) v_u_22
				if v_u_224 and v_u_22:IsFocused() then
					v_u_22.SelectionStart = 1
					v_u_22.CursorPosition = #v_u_22.Text + 1
				end
			end
			if v_u_224 and v_u_22:IsFocused() then
				v_u_22.SelectionStart = 1
				v_u_22.CursorPosition = #v_u_22.Text + 1
			end
			task.defer(v285)
			v_u_28.Text = v_u_11.Touch and "Tap and hold the code to copy" or "Press Ctrl+C (Cmd+C on Mac) to copy"
			v_u_28.Visible = true
			v_u_11.Enter(v_u_28, Vector2.new(0, -4), 0, v_u_28.Position)
			v_u_27:SetText("SELECTED")
		end
	end
	v_u_27.Activated:Connect(v_u_286)
	v_u_27.Instance.Visible = not v_u_11.Gamepad
	v_u_11.GamepadChanged:Connect(function() -- name: refreshCopy
		-- upvalues: (copy) v_u_27, (copy) v_u_11
		v_u_27.Instance.Visible = not v_u_11.Gamepad
	end)
	local function v_u_288() -- name: copyModifier
		-- upvalues: (ref) v_u_2
		for _, v287 in {
			Enum.KeyCode.LeftControl,
			Enum.KeyCode.RightControl,
			Enum.KeyCode.LeftSuper,
			Enum.KeyCode.RightSuper,
			Enum.KeyCode.LeftMeta,
			Enum.KeyCode.RightMeta
		} do
			if not v_u_2:IsKeyDown(v287) then
				continue
			end
			return true
		end
		return false
	end
	v_u_2.InputBegan:Connect(function(p289)
		-- upvalues: (ref) v_u_224, (copy) v_u_22, (copy) v_u_288, (ref) v_u_281, (ref) v_u_282, (copy) v_u_27, (copy) v_u_26, (copy) v_u_28, (ref) v_u_5, (copy) p_u_10
		if v_u_224 and v_u_22:IsFocused() then
			if p289.KeyCode == Enum.KeyCode.C and v_u_288() then
				v_u_281 = v_u_281 + 1
				local v_u_290 = v_u_281
				v_u_282 = os.clock() + 1.6
				v_u_27:SetText("COPIED")
				v_u_26.Text = "check"
				v_u_28.Text = "Copied to your clipboard"
				v_u_28.Visible = true
				task.delay(0.2, function()
					-- upvalues: (copy) v_u_290, (ref) v_u_281, (ref) v_u_22
					if v_u_290 == v_u_281 and v_u_22:IsFocused() then
						v_u_22:ReleaseFocus()
					end
				end)
				task.delay(1.65, function()
					-- upvalues: (copy) v_u_290, (ref) v_u_281, (ref) v_u_224, (ref) v_u_28, (ref) v_u_27, (ref) v_u_26
					if v_u_290 == v_u_281 and not v_u_224 then
						v_u_28.Visible = false
						v_u_27:SetText("COPY")
						v_u_26.Text = "two-stacked-squares"
					end
				end)
			elseif v_u_5.IsPad(p289, "CustomMenu") or v_u_5.ActionOf(p289) == "CustomMenu" then
				p_u_10.MenuManager.Toggle("CustomHost")
			end
		else
			return
		end
	end)
	v_u_22.FocusLost:Connect(function()
		-- upvalues: (copy) v_u_11, (copy) v_u_22, (ref) v_u_224, (ref) v_u_282, (copy) v_u_28, (copy) v_u_27, (copy) v_u_26
		task.delay(v_u_11.Touch and 0 or 0.15, function()
			-- upvalues: (ref) v_u_22, (ref) v_u_224, (ref) v_u_282, (ref) v_u_28, (ref) v_u_27, (ref) v_u_26
			if not v_u_22:IsFocused() then
				v_u_224 = false
				if v_u_282 <= os.clock() then
					v_u_28.Visible = false
					v_u_27:SetText("COPY")
					v_u_26.Text = "two-stacked-squares"
				end
			end
		end)
	end)
	v_u_22:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (ref) v_u_4, (copy) v_u_15, (copy) v_u_22
		local v291 = v_u_4.FormatCode
		local v292 = (v_u_15.State() or {}).code or ""
		local v293 = v291((tostring(v292)))
		if v_u_22.Text ~= v293 then
			v_u_22.Text = v293
		end
	end)
	v_u_15.RevealChanged:Connect(function()
		-- upvalues: (copy) v_u_19, (copy) v_u_232, (copy) v_u_15
		if v_u_19.IsOpen then
			v_u_232(v_u_15.State() or {})
		end
	end)
	local v_u_294 = nil
	local v_u_295 = nil
	local function v_u_296() -- name: closeConfirm
		-- upvalues: (ref) v_u_295, (ref) v_u_294
		v_u_295 = nil
		if v_u_294 then
			v_u_294.layer.Visible = false
		end
	end
	local function v_u_311(p297, p298, p299, p300, p301, p302) -- name: openConfirm
		-- upvalues: (ref) v_u_294, (copy) v_u_11, (copy) v_u_13, (copy) v_u_19, (copy) v_u_296, (copy) v_u_17, (copy) v_u_14, (ref) v_u_295, (copy) p_u_10, (ref) v_u_3
		if not v_u_294 then
			local v303 = v_u_11.new("TextButton", {
				["Name"] = "Confirm",
				["Size"] = UDim2.fromScale(1, 1),
				["BackgroundColor3"] = v_u_13.Void,
				["BackgroundTransparency"] = 0.3,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["Selectable"] = false,
				["ZIndex"] = 40,
				v_u_11.Corner(UDim.new(0, 16)),
				["Parent"] = v_u_19.Holder
			})
			v303.Activated:Connect(v_u_296)
			local v304 = v_u_11.Panel({
				["Name"] = "Card",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundTransparency"] = 0.02,
				["Radius"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = v_u_17(480, 256),
				["Radius"] = UDim.new(0, 16),
				["Parent"] = v303
			})
			v_u_11.new("TextButton", {
				["Name"] = "Sink",
				["Size"] = nil,
				["BackgroundTransparency"] = 1,
				["Text"] = "",
				["Selectable"] = false,
				["ZIndex"] = 41,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v304
			})
			local v305 = v_u_11.DisplayText({
				["Name"] = "Title",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["TextSize"] = 34,
				["TextColor3"] = nil,
				["ZIndex"] = 42,
				["Parent"] = nil,
				["Position"] = v_u_17(0, 24),
				["Size"] = UDim2.new(1, 0, 0, 40),
				["TextColor3"] = v_u_13.Text,
				["Parent"] = v304
			})
			local v306 = v_u_11.new("TextLabel", {
				["Name"] = "Body",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 19,
				["TextColor3"] = nil,
				["TextWrapped"] = true,
				["ZIndex"] = 42,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 74),
				["Size"] = UDim2.new(1, -56, 0, 74),
				["FontFace"] = v_u_14.Bold,
				["TextColor3"] = v_u_13.TextDim,
				["Parent"] = v304
			})
			local v307 = v_u_11.Button({
				["Name"] = "No",
				["Text"] = "",
				["TextSize"] = 21,
				["Style"] = "Dark",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 43,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.new(0, 28, 1, -24),
				["Size"] = v_u_17(200, 58),
				["Parent"] = v304
			})
			local v308 = v_u_11.Button({
				["Name"] = "Yes",
				["Text"] = "",
				["TextSize"] = 21,
				["Style"] = "Danger",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 43,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(1, 1),
				["Position"] = UDim2.new(1, -28, 1, -24),
				["Size"] = v_u_17(200, 58),
				["Parent"] = v304
			})
			v307.Activated:Connect(v_u_296)
			v308.Activated:Connect(function()
				-- upvalues: (ref) v_u_295, (ref) v_u_294
				local v309 = v_u_295
				v_u_295 = nil
				if v_u_294 then
					v_u_294.layer.Visible = false
				end
				if v309 then
					v309()
				end
			end)
			v_u_294 = {
				["layer"] = v303,
				["card"] = v304,
				["title"] = v305,
				["body"] = v306,
				["no"] = v307,
				["yes"] = v308
			}
		end
		local v310 = v_u_294
		v310.title.Text = p297
		v310.body.Text = p298
		v310.no:SetText(p299)
		v310.yes:SetText(p300)
		v310.yes:SetStyle(p301)
		v_u_295 = p302
		v310.layer.Visible = true
		v_u_11.Enter(v310.card, Vector2.new(0, 16), 0, UDim2.fromScale(0.5, 0.5))
		p_u_10.Sounds.Play("Open")
		if v_u_11.Gamepad then
			v_u_3.SelectedObject = v310.no.Instance
		end
	end
	v_u_41.Activated:Connect(function()
		-- upvalues: (copy) v_u_15, (copy) v_u_257, (copy) v_u_311, (copy) p_u_10, (copy) v_u_250
		if (v_u_15.State() or {}).status == "Results" then
			task.spawn(v_u_257, "End")
		else
			v_u_311("END MATCH?", "Everyone goes back to the lobby now. The match won\'t count for anything.", "KEEP PLAYING", "END MATCH", "Danger", function()
				-- upvalues: (ref) v_u_15, (ref) p_u_10, (ref) v_u_250
				task.spawn(function()
					-- upvalues: (ref) v_u_15, (ref) p_u_10, (ref) v_u_250
					local v312, v313 = v_u_15.Host("End", nil)
					if not v312 then
						p_u_10.Toast(tostring(v313), "error")
					end
					v_u_250()
					if v312 then
						p_u_10.MenuManager.Close("CustomHost")
					end
				end)
			end)
		end
	end)
	v_u_105 = function(p_u_314, p_u_315)
		-- upvalues: (copy) v_u_311, (copy) v_u_15, (copy) p_u_10, (copy) v_u_250
		v_u_311("REMOVE PLAYER?", string.format("%s goes back to a public lobby and can\'t rejoin this match.", p_u_315), "CANCEL", "REMOVE", "Danger", function()
			-- upvalues: (copy) p_u_314, (ref) v_u_15, (ref) p_u_10, (ref) v_u_250, (copy) p_u_315
			task.spawn(function()
				-- upvalues: (ref) p_u_314, (ref) v_u_15, (ref) p_u_10, (ref) v_u_250, (ref) p_u_315
				local v316 = p_u_314
				local v317, v318 = v_u_15.Host("Kick", v316)
				if not v317 then
					p_u_10.Toast(tostring(v318), "error")
				end
				v_u_250()
				if v317 then
					p_u_10.Toast(string.format("%s was removed", p_u_315), "info")
				end
			end)
		end)
	end
	v_u_70.Activated:Connect(function()
		-- upvalues: (copy) v_u_311, (copy) v_u_15, (copy) p_u_10
		v_u_311("LEAVE SERVER?", "You\'ll go back to a public lobby. The player here longest becomes the host.", "STAY", "LEAVE", "Danger", function()
			-- upvalues: (ref) v_u_15, (ref) p_u_10
			task.spawn(function()
				-- upvalues: (ref) v_u_15, (ref) p_u_10
				local v319, v320 = v_u_15.Action("Leave")
				if v319 then
					p_u_10.MenuManager.Close("CustomHost")
				else
					p_u_10.Toast(tostring(v320), "error")
				end
			end)
		end)
	end)
	local function v_u_414() -- name: layout
		-- upvalues: (ref) v_u_18, (copy) v_u_11, (ref) v_u_8, (ref) v_u_7, (copy) v_u_19, (copy) v_u_17, (copy) v_u_27, (copy) v_u_21, (copy) v_u_22, (copy) v_u_23, (copy) v_u_24, (copy) v_u_28, (copy) v_u_32, (copy) v_u_33, (copy) v_u_35, (copy) v_u_36, (copy) v_u_37, (copy) v_u_38, (copy) v_u_41, (copy) v_u_39, (copy) v_u_40, (copy) v_u_42, (copy) v_u_34, (copy) v_u_43, (copy) v_u_54, (copy) v_u_60, (copy) v_u_65, (copy) v_u_55, (copy) v_u_56, (copy) v_u_57, (copy) v_u_61, (copy) v_u_62, (copy) v_u_63, (copy) v_u_66, (copy) v_u_67, (copy) v_u_58, (copy) v_u_59, (copy) v_u_64, (copy) v_u_68, (copy) v_u_69, (copy) v_u_44, (copy) v_u_70, (copy) v_u_71, (copy) v_u_72, (copy) v_u_73, (ref) v_u_145, (copy) v_u_74, (copy) v_u_75, (copy) v_u_76, (copy) v_u_83, (copy) v_u_77, (copy) v_u_78, (ref) v_u_246
		local v321
		if v_u_11.Compact then
			v321 = v_u_8
		else
			v321 = v_u_7
		end
		v_u_18 = v321
		local v322 = v_u_11.CanvasSize()
		local v323 = v_u_11.TopInset()
		if v_u_11.Compact then
			local v324 = v_u_19.Holder
			local v325 = v_u_17
			local v326 = v_u_18.W
			local v327 = v322.X - 24
			local v328 = math.min(v326, v327)
			local v329 = math.floor(v328)
			local v330 = v_u_18.H
			local v331 = v322.Y - v323 - 12
			local v332 = math.min(v330, v331)
			v324.Size = v325(v329, (math.floor(v332)))
		else
			local v333 = v_u_19.Holder
			local v334 = v_u_17
			local v335 = v322.X - 240
			local v336 = v_u_18.W
			local v337 = math.clamp(v335, v336, 1280)
			local v338 = math.floor(v337)
			local v339 = v322.Y - v323 - 90
			local v340 = math.clamp(v339, 660, 740)
			v333.Size = v334(v338, (math.floor(v340)))
		end
		v_u_19.Subtitle.TextSize = v_u_11.Compact and 15 or 17
		local v341 = v_u_11.Compact and 226 or 246
		local v342 = v_u_11.Compact and 44 or 48
		local v343 = v_u_11.Compact and 116 or 118
		local v344 = v_u_11.WindowCloseSize() + 30
		v_u_27.Instance.Position = UDim2.new(1, -v344, 0, 14)
		v_u_27.Instance.Size = v_u_17(v343, v342 + 3)
		v_u_27.Label.TextSize = v_u_11.Compact and 18 or 17
		v_u_21.Size = v_u_17(v341, v342)
		v_u_21.Position = UDim2.new(1, -(v344 + v343 + 10), 0, 14)
		v_u_22.TextSize = v_u_11.Compact and 25 or 28
		local v345 = v_u_11.Compact and 8 or 9
		for v346, v347 in v_u_23:GetChildren() do
			local v348 = string.match
			local v349 = v347.Name
			local v350 = tonumber(v348(v349, "%d+")) or v346
			local v351 = v345 * 0.55
			local v352 = v345 * 1.35
			v347.Size = v_u_17(v345, v345)
			v347.Position = v_u_17((v350 - 1) * (v345 + v351) + (v350 <= 3 and 0 or v352 - v351), 0)
		end
		v_u_23.Size = v_u_17(v345 * 6 + v345 * 4 * 0.55 + v345 * 1.35, v345)
		v_u_24.Position = UDim2.new(1, -8, 0.5, 0)
		v_u_28.Position = UDim2.new(1, -v344, 0, v342 + 14 + 4)
		v_u_28.Size = v_u_17(v341 + v343 + 10, 14)
		local v353 = v341 + v343 + v344 + 40
		v_u_19.Title.Size = UDim2.new(1, -v353, 0, 40)
		v_u_19.Subtitle.Size = UDim2.new(1, -v353, 0, 20)
		v_u_19.Subtitle.TextTruncate = Enum.TextTruncate.AtEnd
		local v354 = v_u_19.Holder.Size.X.Offset - 44
		local v355 = v_u_19.Holder.Size.Y.Offset - 80 - 32
		local v356 = v_u_18.left
		v_u_32.Size = v_u_17(v356, v355)
		local v357 = v_u_18.pad
		local v358 = v356 - v357 * 2
		v_u_33.Size = UDim2.new(1, 0, 0, v_u_18.sectionH)
		v_u_35.Position = v_u_17(v357 + 2, v357 + 11)
		v_u_36.Position = v_u_17(v357 + 20, v357)
		v_u_36.Size = v_u_17(v358 - 110, 22)
		v_u_36.TextSize = v_u_18.status
		v_u_37.Position = UDim2.new(1, -v357, 0, v357)
		v_u_37.Size = v_u_17(100, 22)
		v_u_37.TextSize = v_u_18.status - 1
		local v359 = v357 + 32
		for _, v360 in { v_u_38, v_u_41 } do
			v360.Instance.Position = v_u_17(v357, v359)
			v360.Instance.Size = v_u_17(v358, v_u_18.button)
			v360.Label.TextSize = v_u_11.Compact and 23 or 26
		end
		v_u_39.Position = v_u_17(v357, v359)
		v_u_39.Size = v_u_17(v358, v_u_18.button - 3)
		v_u_40.TextSize = v_u_11.Compact and 19 or 20
		local v361 = v359 + (v_u_18.button + 8)
		v_u_42.Position = v_u_17(v357, v361)
		v_u_42.Size = v_u_17(v358, v_u_18.hint + 2)
		v_u_42.TextSize = v_u_18.hint
		local v362 = v361 + (v_u_18.hint + 2 + v357 - 4)
		local v363 = v_u_18.sectionH + v_u_18.sectionGap
		v_u_34.Position = v_u_17(0, v363)
		v_u_34.Size = v_u_17(v356, v362)
		local v364 = v363 + v362 + v_u_18.blockGap
		v_u_43.Position = v_u_17(0, v364)
		v_u_43.Size = UDim2.new(1, 0, 0, v_u_18.sectionH)
		local v365 = v364 + v_u_18.sectionH + v_u_18.sectionGap
		local v366 = { v_u_54, v_u_60, v_u_65 }
		for v367, v368 in v366 do
			v368.Position = v_u_17(0, (v367 - 1) * v_u_18.rowH)
			v368.Size = v_u_17(v356, v_u_18.rowH)
		end
		for _, v369 in {
			{
				v_u_54,
				v_u_55,
				v_u_56,
				v_u_57
			},
			{
				v_u_60,
				v_u_61,
				v_u_62,
				v_u_63
			}
		} do
			local _ = v369[1]
			local v370 = v369[2]
			local v371 = v369[3]
			local v372 = v369[4]
			v370.Position = UDim2.new(0, v357 + 2, 0.5, 0)
			v370.TextSize = 22
			local v373 = v_u_17
			local v374 = v357 + 36
			local v375 = v_u_18.rowH / 2
			v371.Position = v373(v374, math.floor(v375) - v_u_18.label - 1)
			v371.Size = v_u_17(v358 - 36 - 86, v_u_18.label + 2)
			v371.TextSize = v_u_18.label
			local v376 = v_u_17
			local v377 = v357 + 36
			local v378 = v_u_18.rowH / 2
			v372.Position = v376(v377, math.floor(v378) + 2)
			v372.Size = v_u_17(v358 - 36 - 86, v_u_18.desc + 2)
			v372.TextSize = v_u_18.desc
		end
		v_u_66.Position = UDim2.new(0, v357 + 2, 0.5, 0)
		local v379 = v_u_65:FindFirstChild("Label")
		local v380 = v_u_17
		local v381 = v357 + 36
		local v382 = v_u_18.rowH / 2
		v379.Position = v380(v381, math.floor(v382) - v_u_18.label - 1)
		v379.Size = v_u_17(v358 - 36 - 86, v_u_18.label + 2)
		v379.TextSize = v_u_18.label
		local v383 = v_u_67
		local v384 = v_u_17
		local v385 = v357 + 36
		local v386 = v_u_18.rowH / 2
		v383.Position = v384(v385, math.floor(v386) + 2)
		v_u_67.Size = v_u_17(v358 - 36 - 86, v_u_18.desc + 2)
		v_u_67.TextSize = v_u_18.desc
		v_u_58.Position = UDim2.new(1, -v357, 0.5, 0)
		v_u_58.Size = v_u_17(60, 20)
		v_u_58.TextSize = v_u_18.label - 2
		v_u_59.Position = v_u_17(v357 - 4, 8)
		v_u_59.Size = v_u_17(v358 + 8, v_u_18.rowH - 16)
		v_u_59.TextSize = v_u_18.label
		v_u_64.Instance.Position = UDim2.new(1, -v357, 0.5, 0)
		v_u_68.Instance.Position = UDim2.new(1, -v357, 0.5, 0)
		v_u_69.Position = UDim2.new(1, -v357, 0.5, 0)
		v_u_69.Size = v_u_17(60, 22)
		v_u_69.TextSize = v_u_18.label
		v_u_44.Position = v_u_17(0, v365)
		v_u_44.Size = v_u_17(v356, #v366 * v_u_18.rowH)
		v_u_70.Label.TextSize = v_u_11.Compact and 17 or 18
		local v387 = v365 + #v366 * v_u_18.rowH + 12 + v_u_18.leaveH <= v355
		local v388 = v_u_32
		local v389 = v_u_17
		local v390 = 0
		local v391
		if v387 then
			v391 = v355
		else
			v391 = v365 + #v366 * v_u_18.rowH + 2
		end
		v388.CanvasSize = v389(v390, v391)
		v_u_71.Position = v_u_17(v356 + v_u_18.gap - 8, -8)
		local v392 = v354 - v356 - v_u_18.gap
		v_u_71.Size = v_u_17(v392 + 8, v355 + 8)
		v_u_72.Position = v_u_17(v356 + v_u_18.gap, v355)
		v_u_72.Size = v_u_17(v392 - 10, 40)
		task.defer(v_u_73)
		v_u_145 = v392 - 14
		v_u_74.Position = v_u_17(8, 8)
		v_u_74.Size = UDim2.new(0, v_u_145, 0, v_u_18.sectionH)
		v_u_75.Position = v_u_17(v_u_145 + 8, 11)
		v_u_75.Size = v_u_17(260, 18)
		local v393 = v_u_18.mapCols
		local v394 = (v_u_145 - (v393 - 1) * v_u_18.mapGap) / v393
		local v395 = math.floor(v394)
		local v396 = v395 * 9 / 16
		local v397 = math.floor(v396)
		local v398 = 8 + v_u_18.sectionH + v_u_18.sectionGap
		v_u_76.Position = v_u_17(8, v398)
		local v399 = #v_u_83
		local v400 = math.max(1, v399) / v393
		local v401 = math.ceil(v400)
		for v402, v403 in v_u_83 do
			local v404 = (v402 - 1) % v393
			local v405 = (v402 - 1) // v393
			v403.btn.AnchorPoint = Vector2.new(0.5, 0.5)
			local v406 = v403.btn
			local v407 = v_u_17
			local v408 = v404 * (v395 + v_u_18.mapGap)
			local v409 = v395 / 2
			local v410 = v408 + math.floor(v409)
			local v411 = v405 * (v397 + v_u_18.mapGap)
			local v412 = v397 / 2
			v406.Position = v407(v410, v411 + math.floor(v412))
			v403.btn.Size = v_u_17(v395, v397)
			v403.name.TextSize = v_u_18.mapName
		end
		v_u_76.Size = v_u_17(v_u_145, v401 * v397 + (v401 - 1) * v_u_18.mapGap)
		local v413 = v398 + v_u_76.Size.Y.Offset + v_u_18.blockGap
		v_u_77.Position = v_u_17(8, v413)
		v_u_77.Size = UDim2.new(0, v_u_145, 0, v_u_18.sectionH)
		v_u_78.Position = v_u_17(8, v413 + v_u_18.sectionH + v_u_18.sectionGap)
		if v387 then
			v_u_70.Instance.Parent = v_u_32
			v_u_70.Instance.AnchorPoint = Vector2.new(0, 1)
			v_u_70.Instance.Position = UDim2.new(0, 0, 1, 0)
			v_u_70.Instance.Size = v_u_17(v356, v_u_18.leaveH)
		else
			v_u_70.Instance.Parent = v_u_71
			v_u_70.Instance.AnchorPoint = Vector2.new(0, 0)
			v_u_70.Instance.Size = v_u_17(v_u_145, v_u_18.leaveH)
		end
		v_u_246 = not v387
		v_u_19.Refit()
	end
	local function v415() -- name: relayout
		-- upvalues: (copy) v_u_19, (copy) v_u_250, (copy) v_u_414
		if v_u_19.IsOpen then
			v_u_250(true)
			v_u_414()
			v_u_250(true)
		end
	end
	v_u_11.LayoutChanged:Connect(v415)
	v_u_11.ScaleChanged:Connect(v415)
	v_u_15.Changed:Connect(function()
		-- upvalues: (copy) v_u_19, (ref) v_u_82, (copy) v_u_15, (copy) v_u_59, (copy) v_u_83, (copy) v_u_250, (copy) v_u_414
		if v_u_19.IsOpen then
			if v_u_82 and not v_u_15.IsHost() then
				v_u_59:ReleaseFocus()
			end
			local v416 = #v_u_83
			v_u_250()
			if #v_u_83 ~= v416 then
				v_u_414()
				v_u_250(true)
			end
		end
	end)
	local v421 = {
		["open"] = function() -- name: open
			-- upvalues: (copy) p_u_10, (copy) v_u_80, (ref) v_u_295, (ref) v_u_294, (ref) v_u_82, (copy) v_u_59, (copy) v_u_57, (copy) v_u_56, (copy) v_u_58, (copy) v_u_55, (copy) v_u_250, (copy) v_u_414, (copy) v_u_71, (copy) v_u_19, (copy) v_u_11, (copy) v_u_32, (ref) v_u_3, (copy) v_u_38, (copy) v_u_41, (copy) v_u_15
			p_u_10.SetHudHidden("CustomHost", true)
			table.clear(v_u_80)
			v_u_295 = nil
			if v_u_294 then
				v_u_294.layer.Visible = false
			end
			if v_u_82 then
				v_u_82 = false
				v_u_59.Visible = false
				v_u_57.Visible = true
				v_u_56.Visible = true
				v_u_58.Visible = true
				v_u_55.Visible = true
			end
			v_u_250(true)
			v_u_414()
			v_u_250(true)
			v_u_71.CanvasPosition = Vector2.zero
			v_u_19:Open()
			v_u_11.SlideIn(v_u_32, Vector2.new(-18, 0), TweenInfo.new(0.38, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), UDim2.new())
			if v_u_11.Gamepad then
				local v417 = v_u_3
				local v418
				if v_u_38.Instance.Visible then
					v418 = v_u_38.Instance
				elseif v_u_41.Instance.Visible then
					v418 = v_u_41.Instance
				else
					v418 = v_u_19.CloseButton
				end
				v417.SelectedObject = v418
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_15
				v_u_15.Host("Get")
			end)
		end,
		["close"] = function(p419) -- name: close
			-- upvalues: (copy) p_u_10, (ref) v_u_295, (ref) v_u_294, (ref) v_u_82, (copy) v_u_59, (copy) v_u_22, (ref) v_u_282, (ref) v_u_224, (copy) v_u_28, (copy) v_u_27, (copy) v_u_26, (copy) v_u_15, (ref) v_u_3, (copy) v_u_19
			p_u_10.SetHudHidden("CustomHost", false)
			v_u_295 = nil
			if v_u_294 then
				v_u_294.layer.Visible = false
			end
			if v_u_82 then
				v_u_59:ReleaseFocus()
			end
			if v_u_22:IsFocused() then
				v_u_22:ReleaseFocus()
			end
			v_u_282 = 0
			v_u_224 = false
			if v_u_282 <= os.clock() then
				v_u_28.Visible = false
				v_u_27:SetText("COPY")
				v_u_26.Text = "two-stacked-squares"
			end
			v_u_15.Hide()
			local v420 = v_u_3.SelectedObject
			if v420 and v420:IsDescendantOf(v_u_19.Root) then
				v_u_3.SelectedObject = nil
			end
			v_u_19:Close(p419)
		end
	}
	p_u_10.MenuManager.Register("CustomHost", v421)
	function p_u_10.Debug.customHost(p422, p423)
		-- upvalues: (copy) p_u_10, (ref) v_u_85, (copy) v_u_257, (copy) v_u_38, (copy) v_u_41, (copy) v_u_103, (ref) v_u_105, (copy) v_u_70, (ref) v_u_294, (ref) v_u_295, (ref) v_u_82, (copy) v_u_59, (copy) v_u_15, (ref) v_u_4, (copy) v_u_16, (copy) v_u_57, (copy) v_u_56, (copy) v_u_58, (copy) v_u_55, (copy) v_u_286, (copy) v_u_83, (copy) v_u_19, (copy) v_u_42, (copy) v_u_22, (copy) v_u_23, (copy) v_u_24, (ref) v_u_224, (copy) v_u_28, (copy) v_u_27, (copy) v_u_39
		if p422 == "open" then
			p_u_10.MenuManager.Open("CustomHost")
		elseif p422 == "map" then
			v_u_85((tostring(p423 or "")))
		elseif p422 == "public" then
			task.spawn(v_u_257, "SetPublic", p423 ~= false, "public", p423 ~= false)
		elseif p422 == "bots" then
			task.spawn(v_u_257, "SetBots", p423 == true, "bots", p423 == true)
		elseif p422 == "start" then
			v_u_38.Activated:Fire()
		elseif p422 == "end" then
			v_u_41.Activated:Fire()
		elseif p422 == "kick" then
			local v424 = v_u_103[tonumber(p423) or 0]
			v_u_105(tonumber(p423) or 0, not v424 and "Player" or v424.name.Text)
		elseif p422 == "leave" then
			v_u_70.Activated:Fire()
		elseif p422 == "confirmYes" then
			if v_u_294 then
				v_u_294.yes.Activated:Fire()
			end
		elseif p422 == "confirmNo" then
			v_u_295 = nil
			if v_u_294 then
				v_u_294.layer.Visible = false
			end
		elseif p422 == "edit" then
			if not v_u_82 then
				v_u_82 = true
				local v425 = v_u_59
				local v426 = (v_u_15.State() or {}).name or ""
				v425.Text = tostring(v426)
				v_u_59.PlaceholderText = v_u_4.DefaultName(v_u_16.DisplayName)
				v_u_59.Visible = true
				v_u_57.Visible = false
				v_u_56.Visible = false
				v_u_58.Visible = false
				v_u_55.Visible = false
				v_u_59:CaptureFocus()
			end
		elseif p422 == "name" then
			if not v_u_82 then
				v_u_82 = true
				local v427 = v_u_59
				local v428 = (v_u_15.State() or {}).name or ""
				v427.Text = tostring(v428)
				v_u_59.PlaceholderText = v_u_4.DefaultName(v_u_16.DisplayName)
				v_u_59.Visible = true
				v_u_57.Visible = false
				v_u_56.Visible = false
				v_u_58.Visible = false
				v_u_55.Visible = false
				v_u_59:CaptureFocus()
			end
			v_u_59.Text = tostring(p423 or "")
			v_u_59:ReleaseFocus()
		elseif p422 == "copy" then
			v_u_286()
		elseif p422 == "reveal" then
			if p423 == false then
				v_u_15.Hide()
			else
				v_u_15.Reveal()
			end
		elseif p422 == "hoverMap" then
			for _, v429 in v_u_83 do
				if v429.id ~= tostring(p423 or "") then
					continue
				end
				v429.scaleObj.Scale = 1.03
				v429.stroke.Transparency = 0.55
			end
		end
		local v430 = v_u_15.State() or {}
		local v431 = {
			["open"] = v_u_19.IsOpen,
			["host"] = v_u_15.IsHost(),
			["status"] = v430.status or false,
			["canStart"] = v430.canStart or false,
			["hint"] = v_u_42.Text,
			["map"] = v430.map or false,
			["public"] = v430.public or false,
			["bots"] = v430.bots or false
		}
		local v432 = v430.players
		v431.players = type(v432) == "table" and #v430.players or 0
		v431.mapCards = #v_u_83
		local v433
		if v_u_294 == nil then
			v433 = false
		else
			v433 = v_u_294.layer.Visible
		end
		v431.confirm = v433
		v431.code = v_u_22.Text
		local v434
		if v_u_23.Visible then
			v434 = v_u_15.MASK
		else
			v434 = v_u_22.Text
		end
		v431.codeShown = v434
		v431.masked = v_u_23.Visible
		v431.eye = v_u_24.Visible
		v431.copying = v_u_224
		v431.focused = v_u_22:IsFocused()
		v431.selection = string.format("%d..%d", v_u_22.SelectionStart, v_u_22.CursorPosition)
		local v435
		if v_u_28.Visible then
			v435 = v_u_28.Text
		else
			v435 = false
		end
		v431.copyHint = v435
		v431.copyLabel = v_u_27.Label.Text
		v431.readOnly = v_u_39.Visible
		v431.size = string.format("%dx%d", v_u_19.Holder.Size.X.Offset, v_u_19.Holder.Size.Y.Offset)
		return v431
	end
end
return v6