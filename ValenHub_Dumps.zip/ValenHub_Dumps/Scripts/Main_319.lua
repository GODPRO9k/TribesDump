local v1 = os.clock()
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("StarterGui")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("ProximityPromptService")
local v_u_7 = game:GetService("GuiService")
local v_u_8 = game:GetService("Workspace")
local v_u_9 = v2.LocalPlayer
local v_u_10 = v_u_9:WaitForChild("PlayerGui")
pcall(function()
	-- upvalues: (copy) v_u_10
	v_u_10.ScreenOrientation = Enum.ScreenOrientation.LandscapeSensor
end)
local v_u_11 = script.Parent
local v12 = v4:WaitForChild("Shared")
local v13 = require(v12:WaitForChild("Signal"))
local v_u_14 = require(v_u_11.Theme)
local v_u_15 = require(v_u_11.UI)
local v16 = require(v_u_11.Sounds)
local v_u_17 = require(v_u_11.Remotes)
local v_u_18 = require(v_u_11.State)
local v_u_19 = require(v_u_11.MenuManager)
local v20 = require(v_u_11.WeaponInfo)
local v21 = require(v_u_11.WeaponIcon)
local v_u_22 = require(v_u_11.Portraits)
local v23 = require(v_u_11.Fighters)
v21.Init(v_u_15, v20)
v_u_22.Init(v_u_15, v23)
pcall(function()
	-- upvalues: (copy) v_u_7
	v_u_7.AutoSelectGuiEnabled = false
end)
v_u_15.SelectionRing(v_u_10)
local v_u_24 = false
local function v_u_25()
	return false
end
local function v_u_31() -- name: applyPlayerList
	-- upvalues: (ref) v_u_24, (copy) v_u_3, (copy) v_u_18, (ref) v_u_25
	if v_u_24 then
		local function v29()
			-- upvalues: (ref) v_u_3, (ref) v_u_18, (ref) v_u_25
			local v26 = v_u_3
			local v27 = Enum.CoreGuiType.PlayerList
			local v28 = not v_u_18.InMatch()
			if v28 then
				v28 = not v_u_25()
			end
			v26:SetCoreGuiEnabled(v27, v28)
		end
		pcall(v29)
		local function v30()
			-- upvalues: (ref) v_u_3, (ref) v_u_18
			v_u_3:SetCoreGuiEnabled(Enum.CoreGuiType.EmotesMenu, not v_u_18.InMatch())
		end
		pcall(v30)
	end
end
task.spawn(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_18, (ref) v_u_25, (ref) v_u_24, (copy) v_u_31
	for _ = 1, 20 do
		local function v35()
			-- upvalues: (ref) v_u_3, (ref) v_u_18, (ref) v_u_25
			v_u_3:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
			v_u_3:SetCoreGuiEnabled(Enum.CoreGuiType.Health, false)
			local v32 = v_u_3
			local v33 = Enum.CoreGuiType.PlayerList
			local v34 = not v_u_18.InMatch()
			if v34 then
				v34 = not v_u_25()
			end
			v32:SetCoreGuiEnabled(v33, v34)
		end
		if pcall(v35) then
			v_u_24 = true
			v_u_31()
			return
		end
		task.wait(0.5)
	end
end)
local _, v_u_36 = v_u_15.Screen("TR_HUD", 5, v_u_10)
local _, v37 = v_u_15.Screen("TR_Backdrop", 9, v_u_10, {
	["fullBleed"] = true
})
v_u_15.BackdropCanvas = v37
local _, v38 = v_u_15.Screen("TR_Menus", 10, v_u_10)
local _, v39 = v_u_15.Screen("TR_Overlay", 20, v_u_10, {
	["fullBleed"] = true
})
local _, v40 = v_u_15.Screen("TR_Top", 40, v_u_10, {
	["fullBleed"] = true
})
local v_u_43 = {
	["UI"] = nil,
	["Theme"] = nil,
	["Sounds"] = nil,
	["Remotes"] = nil,
	["State"] = nil,
	["MenuManager"] = nil,
	["WeaponInfo"] = nil,
	["WeaponIcon"] = nil,
	["Portraits"] = nil,
	["Fighters"] = nil,
	["Player"] = nil,
	["PlayerGui"] = nil,
	["Canvas"] = nil,
	["HudHidden"] = false,
	["HudHiddenChanged"] = nil,
	["HeldWeaponChanged"] = nil,
	["Debug"] = nil,
	["Toast"] = nil,
	["UI"] = v_u_15,
	["Theme"] = v_u_14,
	["Sounds"] = v16,
	["Remotes"] = v_u_17,
	["State"] = v_u_18,
	["MenuManager"] = v_u_19,
	["WeaponInfo"] = v20,
	["WeaponIcon"] = v21,
	["Portraits"] = v_u_22,
	["Fighters"] = v23,
	["Player"] = v_u_9,
	["PlayerGui"] = v_u_10,
	["Canvas"] = {
		["HUD"] = v_u_36,
		["Backdrop"] = v37,
		["Menus"] = v38,
		["Overlay"] = v39,
		["Top"] = v40
	},
	["HudHiddenChanged"] = v13.new(),
	["HeldWeaponChanged"] = v13.new(),
	["Debug"] = {},
	["Toast"] = function(p41, p42, _) -- name: Toast
		print("[UI toast]", p41, p42)
	end
}
local v_u_44 = {}
function v_u_43.SetHudHidden(p45, p46) -- name: SetHudHidden
	-- upvalues: (copy) v_u_44, (copy) v_u_43
	v_u_44[p45] = p46 and true or nil
	local v47 = next(v_u_44) ~= nil
	if v_u_43._refreshMenuOpen then
		task.defer(v_u_43._refreshMenuOpen)
	end
	if v47 ~= v_u_43.HudHidden then
		v_u_43.HudHidden = v47
		v_u_43.HudHiddenChanged:Fire(v47)
	end
end
function v_u_43.IsHudHiddenFor(p48) -- name: IsHudHiddenFor
	-- upvalues: (copy) v_u_44
	return v_u_44[p48] == true
end
local v_u_49 = game:GetService("ContentProvider")
local v_u_50 = {}
function v_u_43.PreloadThumb(p_u_51, p52) -- name: PreloadThumb
	-- upvalues: (copy) v_u_50, (copy) v_u_49
	if type(p_u_51) == "string" and p_u_51 ~= "" then
		if v_u_50[p_u_51] == nil or p52 then
			if v_u_50[p_u_51] == nil then
				v_u_50[p_u_51] = false
				local function v53()
					-- upvalues: (ref) v_u_49, (copy) p_u_51
					v_u_49:PreloadAsync({ p_u_51 })
				end
				pcall(v53)
				v_u_50[p_u_51] = true
			else
				local v54 = os.clock()
				while v_u_50[p_u_51] == false and os.clock() - v54 < 8 do
					task.wait(0.1)
				end
			end
		else
			return
		end
	else
		return
	end
end
v_u_18.MatchChanged:Connect(function(p55)
	-- upvalues: (copy) v_u_50, (copy) v_u_43
	if p55 then
		local v56 = p55.mapThumb
		if type(v56) == "string" and v_u_50[p55.mapThumb] == nil then
			task.spawn(v_u_43.PreloadThumb, p55.mapThumb)
		end
	end
end)
v_u_18.MatchEvent:Connect(function(p57, p58)
	-- upvalues: (copy) v_u_43
	if p57 == "MatchStart" and type(p58) == "table" then
		task.spawn(v_u_43.PreloadThumb, p58.mapThumb)
	end
end)
function v_u_43.ProfileAction(p59, ...) -- name: ProfileAction
	-- upvalues: (copy) v_u_18, (copy) v_u_43, (copy) v_u_17
	if v_u_18.Mock then
		return v_u_43.Debug._mockProfileAction(p59, ...)
	else
		local v60, v61, v62, v63 = v_u_17.Invoke("ProfileAction", p59, ...)
		if v60 then
			if v61 == true then
				task.delay(0.6, v_u_18.Refresh)
				return true, nil, v63
			else
				v_u_43.Toast(tostring(v62 or "Couldn\'t do that"), "error")
				return false, v62
			end
		else
			v_u_43.Toast(tostring(v61 or "Server unavailable"), "error")
			return false, tostring(v61)
		end
	end
end
function v_u_43.QueueAction(p64, p65) -- name: QueueAction
	-- upvalues: (copy) v_u_18, (copy) v_u_43, (copy) v_u_17
	if v_u_18.Mock then
		if v_u_43.Debug._mockQueueAction then
			return v_u_43.Debug._mockQueueAction(p64)
		end
		v_u_43.Toast("(mock) " .. p64, "info")
		return true, nil
	end
	local v66, v67, v68 = v_u_17.Invoke("QueueAction", p64, p65 or "menu")
	if not v66 then
		v_u_43.Toast(tostring(v67 or "Server unavailable"), "error")
		return false, tostring(v67)
	end
	if v67 == true then
		return true, nil
	end
	if v68 then
		v_u_43.Toast(tostring(v68), "error")
	end
	return false, v68
end
v_u_18.Start()
require(v_u_11.SettingsStore).Init(v_u_43)
require(v_u_11.Economy).Init(v_u_43)
require(v_u_11.Custom).Init(v_u_43)
require(v_u_11.Tribes).Init(v_u_43)
v_u_19.Changed:Connect(function(p69)
	-- upvalues: (copy) v_u_6
	v_u_6.Enabled = p69 == nil
end)
local v_u_70 = false
local function v75() -- name: refreshMenuOpen
	-- upvalues: (copy) v_u_19, (copy) v_u_44, (copy) v_u_9, (copy) v_u_15, (ref) v_u_70, (copy) v_u_7
	local v71 = v_u_19.IsOpen() or ((v_u_44.MatchEnd == true or (v_u_44.Intro == true or (v_u_44.Celebrate == true or v_u_44.Reveal == true))) and true or v_u_44.RankUp == true)
	if v_u_9:GetAttribute("MenuOpen") ~= v71 then
		v_u_9:SetAttribute("MenuOpen", v71)
	end
	if v_u_15.Touch then
		local v_u_72 = v71 or v_u_9:GetAttribute("TouchControlsReady") == false
		v_u_70 = v_u_72
		local function v73()
			-- upvalues: (ref) v_u_7, (copy) v_u_72
			v_u_7.TouchControlsEnabled = not v_u_72
		end
		pcall(v73)
	elseif v_u_70 then
		v_u_70 = false
		local function v74()
			-- upvalues: (ref) v_u_7
			v_u_7.TouchControlsEnabled = true
		end
		pcall(v74)
	end
end
v_u_19.Changed:Connect(v75)
v_u_25 = function()
	-- upvalues: (copy) v_u_19, (copy) v_u_43
	return v_u_19.IsOpen() or v_u_43.HudHidden == true
end
v_u_19.Changed:Connect(v_u_31)
v_u_43.HudHiddenChanged:Connect(v_u_31)
v_u_15.TouchChanged:Connect(v75)
v_u_9:GetAttributeChangedSignal("TouchControlsReady"):Connect(v75)
v_u_43._refreshMenuOpen = v75
task.defer(v75)
v_u_43.PendingEvent = nil
function v_u_43.OnMatchEvent(p76) -- name: OnMatchEvent
	-- upvalues: (copy) v_u_18, (copy) v_u_43
	v_u_18.MatchEvent:Connect(p76)
	local v77 = v_u_43.PendingEvent
	if v77 then
		task.spawn(p76, v77.kind, v77.data)
	end
end
local v_u_78 = {
	"MatchHud",
	"TabList",
	"KillFeed",
	"Decider",
	"Banners",
	"Celebration",
	"Spectate",
	"LoadoutSwap",
	"TeamChat"
}
local v_u_79 = {
	"Leaderboards",
	"CustomLive",
	"MoveDebug",
	"TribeHall",
	"News",
	"GoldenOffer"
}
local v_u_80 = {
	["Ranks"] = "RankRoad",
	["Loadout"] = "Loadout",
	["Settings"] = "Settings",
	["Collection"] = "Collection",
	["Letter"] = "Letter",
	["PlayerCard"] = "PlayerCard",
	["CustomMatches"] = "CustomMatches",
	["CustomHost"] = "CustomHost",
	["Tribe"] = "Tribe",
	["News"] = "News",
	["GoldenOffer"] = "GoldenOffer"
}
local v_u_81 = v_u_11:WaitForChild("Screens")
local v_u_82 = {}
local v_u_83 = {}
local v_u_84 = false
local function v_u_93(p85) -- name: ensureScreen
	-- upvalues: (copy) v_u_83, (copy) v_u_81, (copy) v_u_43, (copy) v_u_82, (ref) v_u_84, (copy) v_u_5
	if v_u_83[p85] then
		return true
	else
		v_u_83[p85] = true
		local v_u_86 = v_u_81:FindFirstChild(p85) or v_u_81:WaitForChild(p85, 5)
		if v_u_86 then
			local v87 = os.clock()
			local function v88()
				-- upvalues: (copy) v_u_86, (ref) v_u_43
				require(v_u_86).Init(v_u_43)
			end
			local v89 = debug.traceback
			local v90, v91 = xpcall(v88, v89)
			local v92 = (os.clock() - v87) * 1000
			v_u_82[p85] = v92
			if v90 then
				if v_u_84 and v_u_5:IsStudio() then
					print(string.format("[UI] built %s on demand in %.1f ms", p85, v92))
				end
				return v90
			else
				warn("[UI] screen " .. p85 .. " failed to init: " .. tostring(v91))
				return v90
			end
		else
			warn("[UI] missing screen module " .. p85)
			return false
		end
	end
end
v_u_43.EnsureScreen = v_u_93
function v_u_43.IsScreenLoaded(p94)
	-- upvalues: (copy) v_u_83
	return v_u_83[p94] == true
end
v_u_19.SetLoader(function(p95)
	-- upvalues: (copy) v_u_80, (copy) v_u_93
	local v96 = v_u_80[p95]
	if v96 then
		v_u_93(v96)
	end
end)
function v_u_43.BuildMatchScreens() -- name: buildMatchScreens
	-- upvalues: (copy) v_u_78, (copy) v_u_93
	for _, v97 in v_u_78 do
		v_u_93(v97)
	end
end
for _, v98 in {
	"Notifications",
	"LobbyHud",
	"MatchSettings",
	"Hotbar",
	"ActionHints",
	"Nameplates",
	"TouchLayout",
	"Economy",
	"Party",
	"Joining",
	"DropReveal",
	"ChatTags",
	"CustomLobby",
	"Onboarding",
	"Moderation"
} do
	v_u_93(v98)
end
local v99 = os.clock()
v_u_84 = true
v_u_18.PlayerStateChanged:Connect(function(p100)
	-- upvalues: (copy) v_u_31, (copy) v_u_78, (copy) v_u_93
	v_u_31()
	if p100 == "Match" then
		for _, v101 in v_u_78 do
			v_u_93(v101)
		end
	end
end)
v_u_18.WatchChanged:Connect(function(p102)
	-- upvalues: (copy) v_u_78, (copy) v_u_93
	if p102 then
		for _, v103 in v_u_78 do
			v_u_93(v103)
		end
	end
end)
if v_u_18.Watching() then
	for _, v104 in v_u_78 do
		v_u_93(v104)
	end
end
v_u_31()
if v_u_18.InMatch() then
	for _, v105 in v_u_78 do
		v_u_93(v105)
	end
end
v_u_18.MatchEvent:Connect(function(p106, p107)
	-- upvalues: (copy) v_u_83, (copy) v_u_22, (copy) v_u_43, (copy) v_u_78, (copy) v_u_93
	if p106 == "MatchStart" and v_u_83.MatchHud then
		v_u_22.Reset()
	end
	local v108 = not v_u_83.MatchHud
	local v109
	if p106 == "MatchEnd" then
		v109 = not v_u_83.MatchEnd
	else
		v109 = false
	end
	if v108 or v109 then
		v_u_43.PendingEvent = {
			["kind"] = p106,
			["data"] = p107
		}
		if p106 == "MatchStart" then
			v_u_22.Reset()
		end
		if v108 then
			for _, v110 in v_u_78 do
				v_u_93(v110)
			end
		end
		if v109 then
			v_u_93("MatchEnd")
		end
		v_u_43.PendingEvent = nil
	end
end)
local v_u_111 = game:GetService("UserInputService")
local v_u_112 = require(v4.Shared:WaitForChild("Keybinds"))
v_u_112.OnInput("Began", function(p113, p114)
	-- upvalues: (copy) v_u_111, (copy) v_u_43, (copy) v_u_19
	if not v_u_111:GetFocusedTextBox() then
		if p113.KeyCode == Enum.KeyCode.M and not p114 or p113.KeyCode == Enum.KeyCode.ButtonSelect and not v_u_43.PadCapturing then
			v_u_19.Toggle("Settings")
		end
	end
end)
local v_u_115 = {
	["kb"] = Enum.KeyCode.E,
	["pad"] = Enum.KeyCode.ButtonX
}
local v_u_116 = (-1 / 0)
v_u_43.LoadoutKeys = v_u_115
local v_u_117 = {
	["LoadoutPrompt"] = "Loadout",
	["ContractPrompt"] = "Collection",
	["LetterPrompt"] = "Letter",
	["CustomMatchesPrompt"] = "CustomMatches",
	["TribePrompt"] = "Tribe",
	["TribeBoardPrompt"] = "Tribe"
}
local v_u_118 = {
	["TribeBoardPrompt"] = "Leaderboard"
}
local v_u_119 = {
	["Loadout"] = true,
	["Collection"] = true,
	["Letter"] = true,
	["CustomMatches"] = true,
	["Tribe"] = true
}
v_u_19.Changed:Connect(function(p120)
	-- upvalues: (copy) v_u_119, (ref) v_u_116
	if p120 and v_u_119[p120] then
		v_u_116 = os.clock()
	end
end)
v_u_6.PromptTriggered:Connect(function(p121)
	-- upvalues: (copy) v_u_117, (copy) v_u_115, (copy) v_u_19, (copy) v_u_118, (ref) v_u_116
	local v122 = v_u_117[p121.Name]
	if v122 then
		v_u_115.kb = p121.KeyboardKeyCode
		v_u_115.pad = p121.GamepadKeyCode
		v_u_19.Open(v122, v_u_118[p121.Name])
		v_u_116 = os.clock()
	end
end)
v_u_111.InputBegan:Connect(function(p123)
	-- upvalues: (copy) v_u_19, (copy) v_u_119, (copy) v_u_111, (copy) v_u_115, (ref) v_u_116
	local v124 = v_u_19.Current()
	if v124 and (v_u_119[v124] and not v_u_111:GetFocusedTextBox()) then
		if p123.KeyCode == v_u_115.kb or p123.KeyCode == v_u_115.pad then
			if os.clock() - v_u_116 >= 0.3 then
				v_u_19.Close(v124)
			end
		else
			return
		end
	else
		return
	end
end)
task.spawn(function()
	-- upvalues: (copy) v_u_9, (copy) v_u_79, (copy) v_u_93
	if not v_u_9.Character then
		v_u_9.CharacterAdded:Wait()
	end
	task.wait(1)
	for _, v125 in v_u_79 do
		v_u_93(v125)
	end
end)
if v_u_5:IsStudio() then
	local v_u_126 = v_u_43.Debug
	function v_u_126.open(p127, ...)
		-- upvalues: (copy) v_u_19
		v_u_19.Open(p127, ...)
		return true
	end
	function v_u_126.close()
		-- upvalues: (copy) v_u_19
		v_u_19.CloseAll()
		return true
	end
	function v_u_126.notify(p128, p129)
		-- upvalues: (copy) v_u_43
		v_u_43.Toast(p128, p129)
		return true
	end
	function v_u_126.event(p130, p131)
		-- upvalues: (copy) v_u_18
		v_u_18.InjectEvent(p130, p131)
		return true
	end
	function v_u_126.snapshot(p132)
		-- upvalues: (copy) v_u_18
		v_u_18.InjectSnapshot(p132)
		return true
	end
	function v_u_126.attr(p133, p134)
		-- upvalues: (copy) v_u_18
		v_u_18.SetMockAttr(p133, p134)
		return true
	end
	function v_u_126.profile(p135)
		-- upvalues: (copy) v_u_18
		v_u_18.SetProfile(p135, true)
		return true
	end
	function v_u_126.setting(p136, p137)
		local v138 = require(script.Parent:WaitForChild("SettingsStore"))
		v138.Set(p136, p137, true)
		return v138.Get(p136)
	end
	function v_u_126.screens()
		-- upvalues: (copy) v_u_83
		local v139 = {}
		for v140 in v_u_83 do
			table.insert(v139, v140)
		end
		table.sort(v139)
		return table.concat(v139, ",")
	end
	function v_u_126.instances()
		-- upvalues: (copy) v_u_10
		local v141 = 0
		for _, _ in v_u_10:GetDescendants() do
			v141 = v141 + 1
		end
		return v141
	end
	function v_u_126.device(p142, p143, p144)
		-- upvalues: (copy) v_u_8, (copy) v_u_15
		local v145 = v_u_8.CurrentCamera
		local v146 = v145 and v145.ViewportSize or Vector2.new(1920, 1080)
		local v147
		if type(p143) == "number" and type(p144) == "number" then
			v147 = Vector2.new(p143, p144)
		else
			v147 = v146
		end
		if p142 == "desktop1080" then
			local v148 = v147.X / 1920
			local v149 = v147.Y / 1080
			local v150 = math.min(v148, v149)
			local v151 = Vector2.new
			local v152 = v150 * 1920
			local v153 = math.floor(v152)
			local v154 = v150 * 1080
			local v155 = v151(v153, (math.floor(v154)))
			v_u_15.SetDebugDevice({
				["rect"] = nil,
				["scale"] = nil,
				["compact"] = false,
				["topLeft"] = nil,
				["topInset"] = 48.333333333333336,
				["rect"] = v155,
				["scale"] = v155.X / 1600,
				["topLeft"] = v147 ~= v146
			}, false)
			return {
				["rect"] = v155
			}
		end
		local v156 = ({
			["iphone14"] = {
				["safe"] = nil,
				["full"] = nil,
				["bar"] = 44,
				["safe"] = Vector2.new(750, 390),
				["full"] = Vector2.new(844, 390)
			},
			["iphone13promax"] = {
				["safe"] = nil,
				["full"] = nil,
				["bar"] = 44,
				["safe"] = Vector2.new(832, 407),
				["full"] = Vector2.new(926, 428)
			},
			["galaxya06"] = {
				["safe"] = nil,
				["full"] = nil,
				["bar"] = 40,
				["safe"] = Vector2.new(705, 338),
				["full"] = Vector2.new(800, 360)
			},
			["ipad"] = {
				["safe"] = nil,
				["full"] = nil,
				["bar"] = 44,
				["tablet"] = true,
				["safe"] = Vector2.new(1180, 800),
				["full"] = Vector2.new(1180, 820)
			}
		})[p142 or ""]
		if not v156 then
			v_u_15.SetDebugDevice(nil)
			return "reset"
		end
		local v157 = v156.full.X / 1280
		local v158 = v156.full.Y / 600
		local v159 = math.min(v157, v158)
		local v160 = v147.X / v156.safe.X
		local v161 = v147.Y / v156.safe.Y
		local v162 = math.min(v160, v161)
		local v163 = Vector2.new
		local v164 = v156.safe.X * v162
		local v165 = math.floor(v164)
		local v166 = v156.safe.Y * v162
		local v167 = v163(v165, (math.floor(v166)))
		v_u_15.SetDebugDevice({
			["rect"] = v167,
			["scale"] = v159 * v162,
			["topLeft"] = v147 ~= v146,
			["tablet"] = v156.tablet,
			["topInset"] = v156.bar / v159
		}, true)
		return {
			["rect"] = v167,
			["canvas"] = v167 / (v159 * v162)
		}
	end
	function v_u_126.screen(p168, p169, p170)
		-- upvalues: (copy) v_u_15, (copy) v_u_8, (copy) v_u_14
		if type(p168) ~= "number" or type(p169) ~= "number" then
			v_u_15.SetDebugDevice(nil)
			return "reset"
		end
		local v171 = v_u_8.CurrentCamera
		local v172 = v171 and v171.ViewportSize or Vector2.new(1920, 1080)
		local v173 = v172.X / p168
		local v174 = v172.Y / p169
		local v175 = math.min(v173, v174)
		local v176 = Vector2.new
		local v177 = p168 * v175
		local v178 = math.floor(v177)
		local v179 = p169 * v175
		local v180 = v176(v178, (math.floor(v179)))
		local v181
		if p170 == true then
			local v182 = p168 / v_u_14.DesignSize.X
			local v183 = p169 / v_u_14.DesignSize.Y
			local v184 = math.min(v182, v183)
			v181 = math.clamp(v184, 0.4, 1.6)
		else
			local v185 = p168 / 1600
			local v186 = p169 / 900
			v181 = math.min(v185, v186)
		end
		v_u_15.SetDebugDevice({
			["rect"] = nil,
			["scale"] = nil,
			["compact"] = nil,
			["topLeft"] = false,
			["topInset"] = nil,
			["rect"] = v180,
			["scale"] = v181 * v175,
			["compact"] = p169 < 560,
			["topInset"] = 58 / v181
		}, false)
		return {
			["rect"] = v180,
			["canvas"] = v180 / (v181 * v175)
		}
	end
	function v_u_126.chat()
		-- upvalues: (copy) v_u_15, (copy) v_u_43
		local v187 = v_u_15.ChatRect()
		local v188 = v_u_43.LobbyColumn and v_u_43.LobbyColumn.Shift() or Vector2.zero
		return {
			["rect"] = not v187 and "closed" or string.format("%d,%d %d,%d", v187.Min.X, v187.Min.Y, v187.Max.X, v187.Max.Y),
			["shift"] = string.format("%d,%d", v188.X, v188.Y)
		}
	end
	function v_u_126.gamepad(p189, p190)
		-- upvalues: (copy) v_u_15, (copy) v_u_19, (copy) v_u_7
		if p189 == "tv" then
			v_u_15.SetDebugTenFoot(p190 == true)
		elseif p189 == true or p189 == false then
			v_u_15.SetDebugGamepad(p189)
		elseif p189 == "auto" then
			v_u_15.SetDebugGamepad(nil)
		else
			if p189 == "hud" then
				return v_u_19.HudFocus(p190)
			end
			if p189 == "back" then
				return v_u_19.Back()
			end
		end
		local v191 = v_u_7.SelectedObject
		local v192 = {
			["gamepad"] = v_u_15.Gamepad,
			["tv"] = v_u_15.TenFoot
		}
		local v193
		if v191 then
			v193 = v191:GetFullName()
		else
			v193 = false
		end
		v192.selected = v193
		v192.menu = v_u_19.Current() or false
		v192.hudFocus = v_u_19.HudFocused()
		v192.screenFocus = v_u_19.HasFocus()
		v192.padBlocked = v_u_19.PadBlocked()
		return v192
	end
	function v_u_126.padInput(p_u_194, p195, p196)
		-- upvalues: (copy) v_u_112
		local v197, v198 = pcall(function()
			-- upvalues: (copy) p_u_194
			return Enum.KeyCode[p_u_194]
		end)
		if not (v197 and v198) then
			return "unknown KeyCode " .. tostring(p_u_194)
		end
		if string.sub(p_u_194, 1, 10) ~= "Thumbstick" then
			if p195 == "down" then
				local v199 = Enum.UserInputState.Begin
				local v200 = {
					["KeyCode"] = nil,
					["UserInputType"] = nil,
					["UserInputState"] = nil,
					["Position"] = Vector3.new(0, 0, 0),
					["Delta"] = Vector3.new(0, 0, 0),
					["KeyCode"] = v198,
					["UserInputType"] = Enum.UserInputType.Gamepad1,
					["UserInputState"] = v199
				}
				v_u_112.FakeInput:Fire("Began", v200, false)
			elseif p195 == "up" then
				local v201 = Enum.UserInputState.End
				local v202 = {
					["KeyCode"] = nil,
					["UserInputType"] = nil,
					["UserInputState"] = nil,
					["Position"] = Vector3.new(0, 0, 0),
					["Delta"] = Vector3.new(0, 0, 0),
					["KeyCode"] = v198,
					["UserInputType"] = Enum.UserInputType.Gamepad1,
					["UserInputState"] = v201
				}
				v_u_112.FakeInput:Fire("Ended", v202, false)
			else
				local v203 = Enum.UserInputState.Begin
				local v204 = {
					["KeyCode"] = nil,
					["UserInputType"] = nil,
					["UserInputState"] = nil,
					["Position"] = Vector3.new(0, 0, 0),
					["Delta"] = Vector3.new(0, 0, 0),
					["KeyCode"] = v198,
					["UserInputType"] = Enum.UserInputType.Gamepad1,
					["UserInputState"] = v203
				}
				v_u_112.FakeInput:Fire("Began", v204, false)
				task.wait(p195 == "hold" and (tonumber(p196) or 0.8) or 0.05)
				local v205 = Enum.UserInputState.End
				local v206 = {
					["KeyCode"] = nil,
					["UserInputType"] = nil,
					["UserInputState"] = nil,
					["Position"] = Vector3.new(0, 0, 0),
					["Delta"] = Vector3.new(0, 0, 0),
					["KeyCode"] = v198,
					["UserInputType"] = Enum.UserInputType.Gamepad1,
					["UserInputState"] = v205
				}
				v_u_112.FakeInput:Fire("Ended", v206, false)
			end
			return true
		end
		local v207 = tonumber(p195) or 0
		local v208 = tonumber(p196) or 0
		local v209 = Enum.UserInputState.Change
		local v210 = Vector3.new(v207, v208, 0)
		local v211 = {
			["KeyCode"] = nil,
			["UserInputType"] = nil,
			["UserInputState"] = nil,
			["Position"] = nil,
			["Delta"] = Vector3.new(0, 0, 0),
			["KeyCode"] = v198,
			["UserInputType"] = Enum.UserInputType.Gamepad1,
			["UserInputState"] = v209,
			["Position"] = v210
		}
		v_u_112.FakeInput:Fire("Changed", v211, false)
		if v207 == 0 and v208 == 0 then
			local v212 = Enum.UserInputState.End
			local v213 = {
				["KeyCode"] = nil,
				["UserInputType"] = nil,
				["UserInputState"] = nil,
				["Position"] = Vector3.new(0, 0, 0),
				["Delta"] = Vector3.new(0, 0, 0),
				["KeyCode"] = v198,
				["UserInputType"] = Enum.UserInputType.Gamepad1,
				["UserInputState"] = v212
			}
			v_u_112.FakeInput:Fire("Ended", v213, false)
		end
		return {
			["stick"] = p_u_194,
			["x"] = v207,
			["y"] = v208
		}
	end
	function v_u_126.padBind(p214, p215, p216)
		-- upvalues: (copy) v_u_112
		local v217 = require(script.Parent:WaitForChild("SettingsStore"))
		if p214 == "reset" then
			local v218 = v_u_112.PadResetAll()
			v217.SavePadBinds(v218)
			return {
				["changed"] = v218
			}
		end
		if p215 == "-" then
			v_u_112.PadClear(p214, p216 or 1)
			v217.SavePadBinds({ p214 })
			return {
				["changed"] = { p214 },
				["now"] = v_u_112.PadGet(p214)
			}
		end
		local v219, v220 = v_u_112.PadAssign(p214, p216 or 1, p215 or "")
		if #v219 > 0 then
			v217.SavePadBinds(v219)
		end
		local v221 = {}
		for _, v222 in v220 do
			v221[v222.id] = table.concat(v222.now, ",")
		end
		return {
			["changed"] = v219,
			["moved"] = v221,
			["now"] = v_u_112.PadGet(p214)
		}
	end
	function v_u_126.padState()
		-- upvalues: (copy) v_u_112, (copy) v_u_19, (copy) v_u_43, (copy) v_u_9, (copy) v_u_18, (copy) v_u_126
		local v223 = {}
		local v224 = {}
		for _, v225 in v_u_112.PAD_ACTIONS do
			v223[v225.id] = table.concat(v_u_112.PadGet(v225.id), ",")
		end
		v224.binds = v223
		v224.allDefault = v_u_112.PadAllDefault()
		v224.padBlocked = v_u_112.PadBlocked()
		v224.menuPadBlocked = v_u_19.PadBlocked()
		v224.padCapturing = v_u_43.PadCapturing == true
		local v226 = v_u_9:FindFirstChild("TribesInputs")
		local v227 = {}
		for _, v228 in { "Jump", "Slide" } do
			local v229
			if v226 then
				v229 = v226:FindFirstChild(v228)
			else
				v229 = v226
			end
			local v230 = {}
			if v229 then
				for _, v231 in v229:GetChildren() do
					if not v231:IsA("InputBinding") or v231.Name == "Script" then
						continue
					end
					local v232 = v231.Name .. "=" .. v231.KeyCode.Name
					table.insert(v230, v232)
				end
				table.sort(v230)
			end
			v227[v228] = table.concat(v230, " ")
		end
		v224.ias = v227
		local v233 = game:GetService("ContextActionService")
		local v234 = {}
		for _, v235 in {
			"TribesFirstPerson",
			"TribesShoulderSwap",
			"TribesSpectateCycle",
			"TribesFreeCursor"
		} do
			local v236 = v233:GetBoundActionInfo(v235)
			local v237 = {}
			if type(v236) == "table" then
				local v238 = v236.inputTypes
				if type(v238) == "table" then
					for _, v239 in v236.inputTypes do
						local v240 = v239.Name
						local v241 = tostring(v240)
						table.insert(v237, v241)
					end
				end
			end
			local v242
			if #v237 > 0 then
				v242 = table.concat(v237, ",")
			else
				v242 = false
			end
			v234[v235] = v242
		end
		v224.cas = v234
		local v243 = {}
		local v244 = v_u_18.Profile
		if type(v244) == "table" then
			local v245 = v244.settings
			if type(v245) == "table" then
				for v246, v247 in v244.settings do
					if type(v246) ~= "string" or string.sub(v246, 1, 3) ~= v_u_112.PAD_PREFIX then
						continue
					end
					v243[v246] = v247
				end
			end
		end
		v224.profileGp = v243
		local v248 = require
		local v249 = script.Parent
		local v250, v251 = pcall(v248, v249:WaitForChild("SettingsStore"))
		local v252
		if v250 then
			v252 = v251.PendingKeys()
		else
			v252 = false
		end
		v224.unsaved = v252
		if v_u_126.padSettings then
			local v253 = v_u_126.padSettings
			local v254, v255 = pcall(v253)
			if not v254 then
				v255 = tostring(v255)
			end
			v224.settings = v255
		end
		return v224
	end
	function v_u_126.padCaps(p256)
		-- upvalues: (copy) v_u_10, (copy) v_u_15
		local v257 = {}
		for _, v258 in v_u_10:GetDescendants() do
			if not v258:IsA("Frame") or v258.Name ~= "KeyCap" and (v258.Name ~= "PadPrev" and v258.Name ~= "PadNext") then
				continue
			end
			local v259 = v_u_15.CapInfo(v258)
			if not (v259 and v259.pad) then
				continue
			end
			local v260 = v258:GetFullName()
			local v261 = string.gsub(v260, "^.-PlayerGui%.", "")
			if p256 and not string.find(v261, p256, 1, true) then
				continue
			end
			local v262 = v259.visible
			local v263 = v258.Parent
			while v262 and (v263 and not v263:IsA("LayerCollector")) do
				if v263:IsA("GuiObject") and not v263.Visible then
					v262 = false
				end
				v263 = v263.Parent
			end
			v257[v261] = string.format("%s%s%s", v259.pad, v259.padUnbound and " (unbound)" or "", v262 and " shown" or "")
		end
		return v257
	end
	function v_u_126.platform()
		-- upvalues: (copy) v_u_15
		local v264 = v_u_15.CanvasSize()
		local v265 = {
			["touch"] = v_u_15.Touch,
			["gamepad"] = v_u_15.Gamepad,
			["tv"] = v_u_15.TenFoot,
			["compact"] = v_u_15.Compact,
			["tablet"] = v_u_15.Tablet
		}
		local v266 = v_u_15.Scale * 1000 + 0.5
		v265.scale = math.floor(v266) / 1000
		v265.canvas = string.format("%dx%d", v264.X, v264.Y)
		v265.topInset = v_u_15.TopInset()
		return v265
	end
	local v_u_267 = {
		["killfeed"] = "KillFeed",
		["banner"] = "Banners",
		["matchEnd"] = "MatchEnd",
		["finalRound"] = "Decider",
		["loadoutSwap"] = "LoadoutSwap",
		["ranks"] = "RankRoad",
		["rankUp"] = "RankUp",
		["playerCard"] = "PlayerCard"
	}
	local function v_u_272(p268, ...) -- name: onInvoke
		-- upvalues: (copy) v_u_267, (copy) v_u_93, (copy) v_u_126
		if v_u_267[p268] then
			v_u_93(v_u_267[p268])
		end
		local v269 = v_u_126[p268]
		if v269 then
			local v270, v271 = pcall(v269, ...)
			if v270 then
				return v271 == nil and true or v271
			else
				return "error: " .. tostring(v271)
			end
		else
			return "unknown command " .. tostring(p268)
		end
	end
	local v273 = Instance.new("BindableFunction")
	v273.Name = "TR_Debug"
	v273.OnInvoke = v_u_272
	v273.Parent = v_u_10
	v_u_10.ChildRemoved:Connect(function(p274)
		-- upvalues: (copy) v_u_10, (copy) v_u_272
		if p274.Name == "TR_Debug" then
			task.defer(function()
				-- upvalues: (ref) v_u_10, (ref) v_u_272
				if not v_u_10:FindFirstChild("TR_Debug") then
					local v275 = Instance.new("BindableFunction")
					v275.Name = "TR_Debug"
					v275.OnInvoke = v_u_272
					v275.Parent = v_u_10
				end
			end)
		end
	end)
	local v276, v277 = pcall(function()
		-- upvalues: (copy) v_u_11, (copy) v_u_43
		require(v_u_11.Mock).Init(v_u_43)
	end)
	if not v276 then
		warn("[UI] mock init failed: " .. tostring(v277))
	end
end
task.spawn(function()
	-- upvalues: (copy) v_u_11, (copy) v_u_78, (copy) v_u_93, (copy) v_u_43, (copy) v_u_36
	local v278 = v_u_11.Parent:WaitForChild("Replay", 30)
	if v278 then
		v278 = v278:WaitForChild("HudBridge", 10)
	end
	if v278 and v278:IsA("ModuleScript") then
		local v279 = require
		local v280, v281 = pcall(v279, v278)
		if v280 and type(v281) == "table" then
			local v_u_282 = {}
			v281.ui = {
				["Enter"] = function(p283) -- name: Enter
					-- upvalues: (ref) v_u_78, (ref) v_u_93, (ref) v_u_43, (ref) v_u_36, (copy) v_u_282
					for _, v284 in v_u_78 do
						v_u_93(v284)
					end
					local v285 = v_u_43.HotbarRoot
					local v286 = v_u_43.MatchHud
					if v286 then
						v286 = v_u_43.MatchHud.Root
					end
					for _, v287 in v_u_36:GetChildren() do
						if not v287:IsA("GuiObject") or (not v287.Visible or (v287 == v285 or v287 == v286)) then
							continue
						end
						v287.Visible = false
						local v288 = v_u_282
						table.insert(v288, v287)
					end
					if v_u_43.Hotbar and v_u_43.Hotbar.SetReplaySource then
						v_u_43.Hotbar.SetReplaySource(p283)
					end
					if v_u_43.MatchHud and v_u_43.MatchHud.SetReplaySource then
						v_u_43.MatchHud.SetReplaySource(p283.model)
					end
				end,
				["Leave"] = function() -- name: Leave
					-- upvalues: (ref) v_u_43, (copy) v_u_282
					if v_u_43.Hotbar and v_u_43.Hotbar.SetReplaySource then
						v_u_43.Hotbar.SetReplaySource(nil)
					end
					if v_u_43.MatchHud and v_u_43.MatchHud.SetReplaySource then
						v_u_43.MatchHud.SetReplaySource(nil)
					end
					for _, v289 in v_u_282 do
						if not v289.Parent then
							continue
						end
						v289.Visible = true
					end
					table.clear(v_u_282)
				end
			}
		end
	else
		return
	end
end)
v_u_9:SetAttribute("UIReady", true)
local v290 = {}
for v291, v292 in v_u_82 do
	local v293 = string.format
	table.insert(v290, v293("%s=%.1f", v291, v292))
end
table.sort(v290)
local v294 = string.format("total=%.1fms | %s", (v99 - v1) * 1000, table.concat(v290, " "))
v_u_9:SetAttribute("UIStartup", v294)
if v_u_5:IsStudio() then
	print("[UI] startup " .. v294)
end