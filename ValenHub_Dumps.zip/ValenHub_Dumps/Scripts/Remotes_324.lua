local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = {}
local v_u_3 = v1:FindFirstChild("Remotes")
local v_u_4 = {}
local v_u_5 = {}
local v_u_6 = {}
local function v_u_10(p7) -- name: hookRemote
	-- upvalues: (copy) v_u_5, (copy) v_u_6
	local v_u_8 = v_u_5[p7.Name]
	if v_u_8 and not v_u_6[p7] then
		if p7:IsA("RemoteEvent") or p7:IsA("UnreliableRemoteEvent") then
			v_u_6[p7] = true
			p7.OnClientEvent:Connect(function(...)
				-- upvalues: (copy) v_u_8
				for _, v9 in v_u_8 do
					task.spawn(v9, ...)
				end
			end)
		end
	end
end
local function v_u_14(p11) -- name: onFolder
	-- upvalues: (ref) v_u_3, (copy) v_u_10, (copy) v_u_4
	v_u_3 = p11
	for _, v12 in p11:GetChildren() do
		v_u_10(v12)
	end
	p11.ChildAdded:Connect(v_u_10)
	for _, v13 in v_u_4 do
		task.spawn(v13)
	end
	table.clear(v_u_4)
end
if v_u_3 then
	v_u_14(v_u_3)
else
	local v_u_15 = nil
	v_u_15 = v1.ChildAdded:Connect(function(p16)
		-- upvalues: (ref) v_u_3, (ref) v_u_15, (copy) v_u_14
		if p16.Name == "Remotes" and not v_u_3 then
			v_u_15:Disconnect()
			v_u_14(p16)
		end
	end)
end
function v_u_2.Get(p17, p18) -- name: Get
	-- upvalues: (ref) v_u_3
	local v19 = os.clock() + (p18 or 0)
	while true do
		local v20 = v_u_3
		if v20 then
			v20 = v20:FindFirstChild(p17)
		end
		if v20 then
			return v20
		end
		if v19 <= os.clock() then
			return nil
		end
		task.wait(0.1)
	end
end
function v_u_2.On(p21, p22) -- name: On
	-- upvalues: (copy) v_u_5, (ref) v_u_3, (copy) v_u_10
	local v23 = v_u_5[p21]
	if not v23 then
		v23 = {}
		v_u_5[p21] = v23
	end
	table.insert(v23, p22)
	local v24 = v_u_3
	if v24 then
		v24 = v24:FindFirstChild(p21)
	end
	if v24 then
		v_u_10(v24)
	end
end
function v_u_2.Fire(p25, ...) -- name: Fire
	-- upvalues: (copy) v_u_2
	local v26 = v_u_2.Get(p25)
	if not (v26 and (v26:IsA("RemoteEvent") or v26:IsA("UnreliableRemoteEvent"))) then
		return false
	end
	v26:FireServer(...)
	return true
end
v_u_2.Timeouts = {
	["QueueAction"] = 20,
	["ProfileAction"] = 20
}
function v_u_2.Invoke(p27, ...) -- name: Invoke
	-- upvalues: (copy) v_u_2
	local v_u_28 = v_u_2.Get(p27, 3)
	if v_u_28 and v_u_28:IsA("RemoteFunction") then
		local v_u_29 = table.pack(...)
		local v_u_30 = false
		local v_u_31 = {}
		local v_u_32 = coroutine.running()
		local v_u_33 = true
		task.spawn(function()
			-- upvalues: (copy) v_u_28, (copy) v_u_29, (ref) v_u_30, (ref) v_u_31, (ref) v_u_33, (copy) v_u_32
			local function v37()
				-- upvalues: (ref) v_u_28, (ref) v_u_29
				local v34 = v_u_28
				local v35 = v_u_29
				local v36 = v_u_29.n
				return v34:InvokeServer(table.unpack(v35, 1, v36))
			end
			local v38 = table.pack(pcall(v37))
			v_u_30 = true
			v_u_31 = v38
			if v_u_33 then
				task.defer(v_u_32)
			end
		end)
		if not v_u_30 then
			local v39 = task.delay(v_u_2.Timeouts[p27] or 10, function()
				-- upvalues: (ref) v_u_30, (ref) v_u_33, (copy) v_u_32
				if not v_u_30 then
					v_u_33 = false
					task.defer(v_u_32)
				end
			end)
			coroutine.yield()
			task.cancel(v39)
		end
		if v_u_30 then
			if v_u_31[1] then
				local v40 = v_u_31.n
				return true, table.unpack(v_u_31, 2, v40)
			else
				local v41 = v_u_31[2]
				return false, tostring(v41)
			end
		else
			return false, "Request timed out"
		end
	else
		return false, "Server not ready"
	end
end
return v_u_2