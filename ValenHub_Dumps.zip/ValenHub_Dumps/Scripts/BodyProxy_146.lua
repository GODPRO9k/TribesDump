local v1 = game:GetService("Players")
local v2 = game:GetService("RunService")
local v_u_3 = game:GetService("Workspace")
local v4 = v2:IsStudio()
local v5 = {}
local v_u_6 = {
	"LuaSourceContainer",
	"JointInstance",
	"WeldConstraint",
	"NoCollisionConstraint",
	"Constraint",
	"BodyMover",
	"Sound",
	"Animator",
	"AnimationController",
	"HumanoidDescription",
	"Humanoid",
	"ForceField",
	"BillboardGui",
	"SurfaceGui",
	"ProximityPrompt",
	"ClickDetector",
	"Highlight",
	"ValueBase",
	"Configuration",
	"Backpack"
}
local v_u_7 = {
	"ParticleEmitter",
	"Trail",
	"Beam",
	"Light",
	"Fire",
	"Smoke",
	"Sparkles"
}
local v_u_8 = v1.LocalPlayer
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = {}
local v_u_13 = {}
local v_u_14 = {}
local v_u_15 = {}
local v_u_16 = true
local v_u_17 = {}
local v_u_18 = {}
local v_u_19 = {}
local v_u_20 = {}
local v_u_21 = true
local v_u_22 = false
local v_u_23 = nil
local v_u_24 = 0
local v_u_25 = Instance.new("BindableEvent")
local v_u_26 = {
	["builds"] = 0,
	["parts"] = 0,
	["copies"] = 0,
	["frames"] = 0,
	["jointsStripped"] = 0,
	["hideWrites"] = 0,
	["props"] = 0,
	["maxMs"] = 0,
	["collisionResets"] = 0,
	["totalMs"] = 0
}
v5.Changed = v_u_25.Event
local function v_u_31(p27) -- name: stripInstance
	for _, v28 in p27:GetTags() do
		p27:RemoveTag(v28)
	end
	for v29 in p27:GetAttributes() do
		if string.sub(v29, 1, 3) == "RBX" then
			continue
		end
		local v30 = p27.SetAttribute
		pcall(v30, p27, v29, nil)
	end
end
local function v_u_35(p32) -- name: noCollisions
	-- upvalues: (copy) v_u_26
	for _, v33 in p32:GetDescendants() do
		if not v33:IsA("BasePart") then
			continue
		end
		if v33.CanCollide then
			v33.CanCollide = false
			local v34 = v_u_26
			v34.collisionResets = v34.collisionResets + 1
		end
		if v33.CanQuery then
			v33.CanQuery = false
		end
		if not v33.CanTouch then
			continue
		end
		v33.CanTouch = false
	end
end
local function v_u_45(p36, p37) -- name: pair
	-- upvalues: (copy) v_u_12, (copy) v_u_45
	v_u_12[p36] = p37
	local v38 = p37:GetChildren()
	local v39 = 1
	local v40 = {}
	for _, v41 in p36:GetChildren() do
		local v42 = nil
		for v43 = v39, #v38 do
			local v44 = v38[v43]
			if v40[v44] or (v44.Name ~= v41.Name or v44.ClassName ~= v41.ClassName) then
				continue
			end
			v40[v44] = true
			if v43 == v39 then
				v39 = v39 + 1
				v42 = v44
			else
				v42 = v44
			end
		end
		if not v42 then
			break
		end
		v_u_45(v41, v42)
	end
end
local function v_u_62(p46) -- name: clean
	-- upvalues: (copy) v_u_12, (copy) v_u_6, (copy) v_u_26, (copy) v_u_31, (copy) v_u_7
	local v47 = { p46 }
	for _, v48 in p46:GetDescendants() do
		table.insert(v47, v48)
	end
	for _, v49 in v47 do
		local v50 = v_u_12[v49]
		if not v50 then
			continue
		end
		local v51
		if v49.Name == "TribesHull" then
			if v49:IsA("JointInstance") or (v49:IsA("WeldConstraint") or v49:IsA("Constraint")) then
				v51 = v_u_26
				v51.jointsStripped = v51.jointsStripped + 1
			end
			v_u_12[v49] = nil
			for v56, v57 in v49:GetDescendants() do
				v_u_12[v57] = nil
			end
			if not v50.Parent then
				break
			end
			v50:Destroy()
		else
			for _, v54 in v_u_6 do
				if not v49:IsA(v54) then
					continue
				end
				v55 = true
			end
			local v55 = false
			if v55 then
				if v49:IsA("JointInstance") or (v49:IsA("WeldConstraint") or v49:IsA("Constraint")) then
					v51 = v_u_26
					v51.jointsStripped = v51.jointsStripped + 1
				end
				v_u_12[v49] = nil
				for v56, v57 in v49:GetDescendants() do
					v_u_12[v57] = nil
				end
				if not v50.Parent then
					break
				end
				v50:Destroy()
			else
				v_u_31(v50)
				if v50:IsA("BasePart") and v49:IsA("BasePart") then
					v50.Anchored = true
					v50.CanCollide = false
					v50.CanQuery = false
					v50.CanTouch = false
					v50.Massless = true
					v50.LocalTransparencyModifier = 0
					v50.CastShadow = v49.CastShadow
				else
					for _, v58 in v_u_7 do
						if not v50:IsA(v58) then
							continue
						end
						v59 = true
					end
					local v59 = false
					if v59 then
						v50.Enabled = false
					else
						if not v50:IsA("Tool") then
							break
						end
						local v60 = Instance.new("Model")
						v60.Name = v50.Name
						for _, v61 in v50:GetChildren() do
							v61.Parent = v60
						end
						v60.Parent = v50.Parent
						v_u_12[v49] = v60
						v50:Destroy()
					end
				end
			end
		end
	end
end
local function v_u_70(p_u_63) -- name: add
	-- upvalues: (copy) v_u_12, (ref) v_u_9, (ref) v_u_10, (copy) v_u_6, (copy) v_u_45, (copy) v_u_62, (copy) v_u_35, (ref) v_u_16
	if v_u_12[p_u_63] or not (v_u_9 and v_u_10) then
		return
	else
		local v64 = p_u_63.Parent
		if v64 then
			v64 = v_u_12[v64]
		end
		if v64 then
			if p_u_63.Name ~= "TribesHull" then
				for _, v65 in v_u_6 do
					if not p_u_63:IsA(v65) then
						continue
					end
					v66 = true
				end
				local v66 = false
				if not v66 then
					if p_u_63.Archivable then
						local v67, v68 = pcall(function()
							-- upvalues: (copy) p_u_63
							return p_u_63:Clone()
						end)
						if v67 and v68 then
							v_u_45(p_u_63, v68)
							v_u_62(p_u_63)
							local v69 = v_u_12[p_u_63]
							if v69 then
								v69.Parent = v64
								if v_u_9 and v_u_9.Parent then
									v_u_35(v_u_9)
								end
							end
							v_u_16 = true
						end
					else
						return
					end
				end
			end
		end
	end
end
local function v_u_78() -- name: rebuildLists
	-- upvalues: (ref) v_u_16, (copy) v_u_13, (copy) v_u_14, (copy) v_u_17, (copy) v_u_18, (copy) v_u_12, (copy) v_u_19, (copy) v_u_26
	v_u_16 = false
	table.clear(v_u_13)
	table.clear(v_u_14)
	table.clear(v_u_17)
	table.clear(v_u_18)
	for v71, v72 in v_u_12 do
		if v71:IsA("BasePart") and v72:IsA("BasePart") then
			if not (v71.Parent and v72.Parent) then
				continue
			end
			local v73 = v_u_13
			local v74 = {
				["real"] = nil,
				["copy"] = nil,
				["t"] = -1,
				["color"] = nil,
				["mat"] = nil,
				["real"] = v71,
				["copy"] = v72,
				["color"] = v72.Color,
				["mat"] = v72.Material
			}
			table.insert(v73, v74)
			local v75 = v_u_17
			table.insert(v75, v71)
			local v76 = v_u_18
			table.insert(v76, v72)
		else
			if not (v71:IsA("Decal") and v72:IsA("Decal")) then
				continue
			end
			local v77 = v_u_14
			table.insert(v77, {
				["real"] = nil,
				["copy"] = nil,
				["t"] = -1,
				["real"] = v71,
				["copy"] = v72
			})
		end
	end
	table.clear(v_u_19)
	v_u_26.parts = #v_u_17
	v_u_26.copies = #v_u_18
end
local function v_u_81() -- name: destroy
	-- upvalues: (copy) v_u_20, (copy) v_u_15, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (copy) v_u_12, (ref) v_u_16, (copy) v_u_78, (ref) v_u_22, (copy) v_u_25
	for _, v79 in v_u_20 do
		v79:Disconnect()
	end
	table.clear(v_u_20)
	for v80 in v_u_15 do
		if not v80.Parent then
			continue
		end
		v80.LocalTransparencyModifier = 0
	end
	table.clear(v_u_15)
	if v_u_9 then
		v_u_9:Destroy()
	end
	v_u_9 = nil
	v_u_10 = nil
	v_u_11 = nil
	table.clear(v_u_12)
	v_u_16 = true
	v_u_78()
	if v_u_22 then
		v_u_22 = false
		v_u_25:Fire(nil)
	end
end
local function v_u_106(p82, p83) -- name: build
	-- upvalues: (copy) v_u_81, (ref) v_u_10, (ref) v_u_11, (ref) v_u_9, (copy) v_u_12, (copy) v_u_70, (copy) v_u_20, (copy) v_u_26, (ref) v_u_22, (copy) v_u_15, (ref) v_u_16
	v_u_81()
	local v84 = Instance.new("Model")
	v84.Name = "TribesDrawnBody"
	v_u_10 = p82
	v_u_11 = p83
	v_u_9 = v84
	v_u_12[p82] = v84
	for _, v85 in p82:GetChildren() do
		v_u_70(v85)
	end
	local v86 = Instance.new("Humanoid")
	local v87 = p82:FindFirstChildOfClass("Humanoid")
	local v88
	if v87 then
		v88 = v87.RigType
	else
		v88 = Enum.HumanoidRigType.R15
	end
	v86.RigType = v88
	v86.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
	v86.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
	v86.RequiresNeck = false
	v86.BreakJointsOnDeath = false
	v86.AutomaticScalingEnabled = false
	v86.EvaluateStateMachine = false
	v86.Parent = v84
	local v89 = v_u_20
	local v90 = v84.DescendantAdded
	local function v93(p_u_91)
		-- upvalues: (ref) v_u_26
		if p_u_91:IsA("JointInstance") or (p_u_91:IsA("WeldConstraint") or p_u_91:IsA("Constraint")) then
			local v92 = v_u_26
			v92.jointsStripped = v92.jointsStripped + 1
			task.defer(function()
				-- upvalues: (copy) p_u_91
				if p_u_91.Parent then
					p_u_91:Destroy()
				end
			end)
		end
	end
	table.insert(v89, v90:Connect(v93))
	local v94 = v_u_20
	local v95 = p82.DescendantAdded
	local function v98(p96)
		-- upvalues: (ref) v_u_70, (ref) v_u_22, (ref) v_u_15, (ref) v_u_26
		v_u_70(p96)
		if v_u_22 and (p96:IsA("BasePart") or p96:IsA("Decal")) then
			v_u_15[p96] = true
			if p96.LocalTransparencyModifier ~= 1 then
				p96.LocalTransparencyModifier = 1
				local v97 = v_u_26
				v97.hideWrites = v97.hideWrites + 1
			end
		end
	end
	table.insert(v94, v95:Connect(v98))
	local v99 = v_u_20
	local v100 = p82.DescendantRemoving
	local function v104(p_u_101)
		-- upvalues: (ref) v_u_15, (ref) v_u_12, (ref) v_u_16
		if v_u_15[p_u_101] then
			v_u_15[p_u_101] = nil
			pcall(function()
				-- upvalues: (copy) p_u_101
				p_u_101.LocalTransparencyModifier = 0
			end)
		end
		local v102 = v_u_12[p_u_101]
		if v102 then
			v_u_12[p_u_101] = nil
			v_u_16 = true
			for _, v103 in p_u_101:GetDescendants() do
				v_u_12[v103] = nil
			end
			v102:Destroy()
		end
	end
	table.insert(v99, v100:Connect(v104))
	local v105 = v_u_26
	v105.builds = v105.builds + 1
	v_u_16 = true
end
local function v_u_114(p107) -- name: setShown
	-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_22, (copy) v_u_3, (copy) v_u_35, (copy) v_u_15, (copy) v_u_26, (copy) v_u_8, (copy) v_u_25
	local v108 = v_u_9
	local v109 = v_u_10
	if not (v108 and v109) then
		p107 = false
	end
	if p107 ~= v_u_22 then
		v_u_22 = p107
		if p107 then
			v108.Parent = v_u_3.CurrentCamera
			v_u_35(v108)
			for _, v110 in v109:GetDescendants() do
				if not (v110:IsA("BasePart") or v110:IsA("Decal")) then
					continue
				end
				v_u_15[v110] = true
				if v110.LocalTransparencyModifier == 1 then
					continue
				end
				v110.LocalTransparencyModifier = 1
				local v111 = v_u_26
				v111.hideWrites = v111.hideWrites + 1
			end
		else
			if v108 then
				v108.Parent = nil
			end
			if v_u_8:GetAttribute("ReplayPlaying") == true then
				table.clear(v_u_15)
			else
				for v112 in v_u_15 do
					if not v112.Parent then
						continue
					end
					v112.LocalTransparencyModifier = 0
				end
				table.clear(v_u_15)
			end
		end
		local v113 = v_u_25
		if not p107 then
			v108 = nil
		end
		v113:Fire(v108)
	end
end
function v5.Render(p115, p116) -- name: Render
	-- upvalues: (ref) v_u_10, (ref) v_u_11, (ref) v_u_23, (ref) v_u_24, (copy) v_u_106, (copy) v_u_81, (ref) v_u_21, (ref) v_u_9, (copy) v_u_8, (copy) v_u_114, (ref) v_u_22, (copy) v_u_3, (copy) v_u_35, (ref) v_u_16, (copy) v_u_78, (copy) v_u_13, (copy) v_u_19, (copy) v_u_26, (copy) v_u_14, (copy) v_u_18
	local v117 = os.clock()
	local v118
	if p115 then
		v118 = p115.Parent
	else
		v118 = nil
	end
	if p115 and (v118 and (v118:IsA("Model") and (v118 ~= v_u_10 or p115 ~= v_u_11))) and (p115 ~= v_u_23 or os.clock() - v_u_24 > 5) then
		local v119 = v_u_106
		local v120, v121 = pcall(v119, v118, p115)
		if not v120 then
			local v122 = os.clock()
			v_u_23 = p115
			v_u_24 = v122
			v_u_81()
			warn("[BodyProxy] build failed, the real body is shown: " .. tostring(v121))
		end
	elseif not p115 and v_u_10 then
		v_u_81()
	end
	local v123 = v_u_21
	if v123 then
		if p116 == nil or v_u_9 == nil then
			v123 = false
		else
			v123 = v_u_8:GetAttribute("ReplayPlaying") ~= true
		end
	end
	v_u_114(v123)
	if v_u_22 and (p116 and v_u_11) then
		local v124 = v_u_9
		if v124.Parent ~= v_u_3.CurrentCamera then
			v124.Parent = v_u_3.CurrentCamera
			v_u_35(v124)
		end
		if v_u_16 then
			v_u_78()
		end
		local v125 = p116 * v_u_11.CFrame:Inverse()
		for v126, v127 in v_u_13 do
			local v128 = v127.real
			v_u_19[v126] = v125 * v128.CFrame
			local v129 = v127.copy
			if v129.CanCollide then
				v129.CanCollide = false
				v129.CanQuery = false
				local v130 = v_u_26
				v130.collisionResets = v130.collisionResets + 1
			end
			local v131 = v128.Transparency
			if v131 ~= v127.t then
				v127.t = v131
				v127.copy.Transparency = v131
				local v132 = v_u_26
				v132.props = v132.props + 1
			end
			local v133 = v128.Color
			if v133 ~= v127.color then
				v127.color = v133
				v127.copy.Color = v133
				local v134 = v_u_26
				v134.props = v134.props + 1
			end
			local v135 = v128.Material
			if v135 == v127.mat then
				continue
			end
			v127.mat = v135
			v127.copy.Material = v135
			local v136 = v_u_26
			v136.props = v136.props + 1
		end
		for _, v137 in v_u_14 do
			local v138 = v137.real.Transparency
			if v138 == v137.t then
				continue
			end
			v137.t = v138
			v137.copy.Transparency = v138
		end
		if #v_u_18 > 0 then
			local function v139()
				-- upvalues: (ref) v_u_3, (ref) v_u_18, (ref) v_u_19
				v_u_3:BulkMoveTo(v_u_18, v_u_19, Enum.BulkMoveMode.FireCFrameChanged)
			end
			if not pcall(v139) then
				v_u_16 = true
			end
		end
		local v140 = v_u_26
		v140.frames = v140.frames + 1
		local v141 = (os.clock() - v117) * 1000
		local v142 = v_u_26
		v142.totalMs = v142.totalMs + v141
		if v_u_26.maxMs < v141 then
			v_u_26.maxMs = v141
		end
	end
end
function v5.EnforceHidden() -- name: EnforceHidden
	-- upvalues: (ref) v_u_22, (copy) v_u_15, (copy) v_u_26
	if v_u_22 then
		for v143 in v_u_15 do
			if v143.LocalTransparencyModifier == 1 then
				continue
			end
			if v143.Parent then
				v143.LocalTransparencyModifier = 1
				local v144 = v_u_26
				v144.hideWrites = v144.hideWrites + 1
			else
				v_u_15[v143] = nil
			end
		end
	end
end
function v5.SetEnabled(p145) -- name: SetEnabled
	-- upvalues: (ref) v_u_21, (copy) v_u_114
	v_u_21 = p145 == true
	if not v_u_21 then
		v_u_114(false)
	end
end
function v5.IsShown() -- name: IsShown
	-- upvalues: (ref) v_u_22
	return v_u_22
end
function v5.Model() -- name: Model
	-- upvalues: (ref) v_u_22, (ref) v_u_9
	if v_u_22 then
		return v_u_9
	else
		return nil
	end
end
function v5.Drawn(p146) -- name: Drawn
	-- upvalues: (ref) v_u_22, (copy) v_u_12
	if p146 and v_u_22 then
		return v_u_12[p146] or p146
	else
		return p146
	end
end
function v5.Stats() -- name: Stats
	-- upvalues: (ref) v_u_22, (copy) v_u_26
	local v147 = {
		["proxyShown"] = v_u_22,
		["proxyBuilds"] = v_u_26.builds,
		["proxyParts"] = v_u_26.parts,
		["proxyFrames"] = v_u_26.frames,
		["proxyJointsStripped"] = v_u_26.jointsStripped,
		["proxyHideWrites"] = v_u_26.hideWrites,
		["proxyPropCopies"] = v_u_26.props
	}
	local v148 = v_u_26.maxMs * 1000
	v147.proxyMaxMs = math.floor(v148) / 1000
	local v149
	if v_u_26.frames > 0 then
		local v150 = v_u_26.totalMs / v_u_26.frames * 10000
		v149 = math.floor(v150) / 10000
	else
		v149 = 0
	end
	v147.proxyAvgMs = v149
	v147.proxyCollisionResets = v_u_26.collisionResets
	return v147
end
if v4 then
	function v5.DebugMap() -- name: DebugMap
		-- upvalues: (copy) v_u_12
		local v151 = {
			["parts"] = 0,
			["decals"] = 0,
			["attachments"] = 0,
			["other"] = 0
		}
		for v152 in v_u_12 do
			if v152:IsA("BasePart") then
				v151.parts = v151.parts + 1
			elseif v152:IsA("Decal") then
				v151.decals = v151.decals + 1
			elseif v152:IsA("Attachment") then
				v151.attachments = v151.attachments + 1
			else
				v151.other = v151.other + 1
			end
		end
		return v151
	end
end
return v5