local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = require(script.Parent.Util)
local v_u_6 = require(script.Parent.Effects)
local v_u_7 = require(script.Parent.Quality)
local v_u_8 = {}
local v_u_9 = v2.LocalPlayer
local v_u_10 = v_u_5.Assets:WaitForChild("VFX", 10)
local v_u_11 = Color3.fromRGB(196, 70, 64)
local v_u_12 = Color3.fromRGB(70, 132, 196)
local v_u_13 = Color3.fromRGB(232, 172, 40)
local v_u_14 = Color3.fromRGB(44, 34, 26)
local v_u_15 = Color3.fromRGB(255, 214, 140)
local function v_u_19(p16) -- name: rootOf
	-- upvalues: (copy) v_u_5
	if p16 then
		local v17 = v_u_5.Drawn(p16)
		if v17 then
			if not v17:IsA("Model") then
				v17 = p16
			end
		else
			v17 = p16
		end
		local v18 = v17:FindFirstChild("HumanoidRootPart") or p16:FindFirstChild("HumanoidRootPart")
		if v18 and v18:IsA("BasePart") then
			return v18
		else
			return nil
		end
	else
		return nil
	end
end
local v_u_20 = {}
local v_u_21 = nil
local v_u_22 = 0
local function v_u_43(p23, p24) -- name: newBee
	-- upvalues: (copy) v_u_10, (copy) v_u_13, (copy) v_u_14
	local v25 = v_u_10
	if v25 then
		v25 = v_u_10:FindFirstChild("Bee")
	end
	local v26 = {}
	local v27 = {}
	if v25 then
		local v28 = v25:Clone()
		local v29
		if v28:IsA("Model") then
			v29 = v28.PrimaryPart
		elseif v28:IsA("BasePart") then
			v29 = v28
		else
			v29 = nil
		end
		if v28:IsA("Model") and p24 ~= 1 then
			v28:ScaleTo(p24)
		end
		for _, v30 in v28:IsA("BasePart") and { v28 } or v28:GetDescendants() do
			if not v30:IsA("BasePart") then
				continue
			end
			v30.Anchored = true
			v30.CanCollide = false
			v30.CanQuery = false
			v30.CanTouch = false
			v30.CastShadow = false
			table.insert(v26, v30)
			local v31
			if v29 then
				v31 = v29.CFrame:ToObjectSpace(v30.CFrame)
			else
				v31 = CFrame.identity
			end
			table.insert(v27, v31)
		end
		v28.Parent = p23
		return v29 or v26[1], v26, v27
	end
	local v32 = Vector3.new(0.16, 0.16, 0.26) * p24
	local v33 = v_u_13
	local v34 = Enum.Material.SmoothPlastic
	local v35 = Instance.new("Part")
	v35.Name = "Bee"
	v35.Anchored = true
	v35.CanCollide = false
	v35.CanQuery = false
	v35.CanTouch = false
	v35.CastShadow = false
	v35.Size = v32
	v35.Color = v33
	v35.Material = v34 or Enum.Material.SmoothPlastic
	v35.Transparency = 0
	v35.Shape = Enum.PartType.Ball
	local v36 = Vector3.new(0.17, 0.17, 0.06) * p24
	local v37 = v_u_14
	local v38 = Instance.new("Part")
	v38.Name = "Band"
	v38.Anchored = true
	v38.CanCollide = false
	v38.CanQuery = false
	v38.CanTouch = false
	v38.CastShadow = false
	v38.Size = v36
	v38.Color = v37
	v38.Material = Enum.Material.SmoothPlastic
	v38.Transparency = 0
	v38.Shape = Enum.PartType.Ball
	local v39 = Vector3.new(0.32, 0.02, 0.1) * p24
	local v40 = Color3.fromRGB(196, 214, 226)
	local v41 = Enum.Material.SmoothPlastic
	local v42 = Instance.new("Part")
	v42.Name = "Wings"
	v42.Anchored = true
	v42.CanCollide = false
	v42.CanQuery = false
	v42.CanTouch = false
	v42.CastShadow = false
	v42.Size = v39
	v42.Color = v40
	v42.Material = v41 or Enum.Material.SmoothPlastic
	v42.Transparency = 0.35
	v35.Parent = p23
	v38.Parent = p23
	v42.Parent = p23
	return v35, { v35, v38, v42 }, { CFrame.identity, CFrame.new(0, 0, p24 * 0.04), CFrame.new(0, p24 * 0.08, p24 * -0.02) }
end
local function v_u_50(p44, p45) -- name: endSwarm
	-- upvalues: (copy) v_u_20, (copy) v_u_4, (copy) v_u_1
	if v_u_20[p44.id] == p44 then
		v_u_20[p44.id] = nil
		p44.ending = true
		if p44.stopLoop then
			p44.stopLoop(p45)
			p44.stopLoop = nil
		end
		for _, v46 in p44.bees do
			local v47 = v46.part.Position - p44.pos
			local v48 = v47.Magnitude <= 0.01 and Vector3.new(0, 1, 0) or v47.Unit
			for _, v49 in v46.parts do
				v_u_4:Create(v49, TweenInfo.new(p45, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					["Transparency"] = 1,
					["CFrame"] = nil,
					["CFrame"] = v49.CFrame + v48 * 2.5 + Vector3.new(0, 1, 0)
				}):Play()
			end
		end
		if p44.ring then
			v_u_4:Create(p44.ring, TweenInfo.new(p45), {
				["Transparency"] = 1
			}):Play()
		end
		v_u_1:AddItem(p44.folder, p45 + 0.1)
		v_u_1:AddItem(p44.anchor, p45 + 0.2)
	end
end
local v_u_51 = RaycastParams.new()
v_u_51.FilterType = Enum.RaycastFilterType.Exclude
v_u_51.IgnoreWater = true
local v_u_52 = {}
local v_u_53 = {}
local function v_u_101(p54) -- name: stepSwarms
	-- upvalues: (copy) v_u_52, (copy) v_u_53, (copy) v_u_9, (copy) v_u_19, (copy) v_u_20, (copy) v_u_50, (copy) v_u_51, (ref) v_u_22, (copy) v_u_8, (ref) v_u_21
	local v55 = os.clock()
	table.clear(v_u_52)
	table.clear(v_u_53)
	local v56 = v_u_9.Character
	local v57 = v_u_19(v56)
	local v58 = 0
	local v59 = false
	for _, v60 in v_u_20 do
		v59 = true
		if v60.untilT <= v55 then
			v_u_50(v60, 0.35)
		else
			local v61 = v60.target
			local v62
			if v61 and v61.Parent then
				v62 = v_u_19(v61)
			else
				v62 = nil
			end
			if v62 then
				local v63 = v62.Position + Vector3.new(0, 0.6, 0) - v60.pos
				local v64 = v63.Magnitude
				local v65 = v60.speed * p54
				local v66 = v64 - 0.6
				local v67 = math.max(0, v66)
				local v68 = math.min(v65, v67)
				if v64 > 0.01 and v68 > 0 then
					v60.pos = v60.pos + v63.Unit * v68
				end
			end
			local v69 = -p54 * 6
			local v70 = 1 - math.exp(v69)
			v60.pos = v60.pos + v60.err * v70
			v60.err = v60.err * (1 - v70)
			v60.anchor.CFrame = CFrame.new(v60.pos)
			local v71 = v60.pos
			local v72 = workspace.CurrentCamera
			if (not v72 and 0 or (v72.CFrame.Position - v71).Magnitude) <= 140 then
				for _, v73 in v60.bees do
					local v74 = v55 * v73.speed + v73.phase
					local v75 = v73.radius
					local v76 = v55 * 3.1 + v73.phase
					local v77 = v75 * (math.sin(v76) * 0.15 + 0.85)
					local v78 = math.cos(v74) * v77
					local v79 = v55 * v73.bob + v73.phase
					local v80 = math.sin(v79) * 0.45 + math.sin(v74) * v73.tilt
					local v81 = math.sin(v74) * v77
					local v82 = Vector3.new(v78, v80, v81)
					local v83 = -math.sin(v74)
					local v84 = math.cos(v74) * v73.tilt * 0.6
					local v85 = math.cos(v74)
					local v86 = Vector3.new(v83, v84, v85)
					local v87 = v60.pos + v82
					local v88 = CFrame.lookAt(v87, v87 - v86)
					for v89, v90 in v73.parts do
						local v91 = v_u_52
						table.insert(v91, v90)
						local v92 = v_u_53
						local v93 = v88 * v73.rel[v89]
						table.insert(v92, v93)
					end
				end
			end
			local v94 = v60.ring
			if v94 and v55 - v60.ringAt > 0.1 then
				v60.ringAt = v55
				v_u_51.FilterDescendantsInstances = { workspace:FindFirstChild("FX") or workspace, v56 }
				local v95 = workspace:Raycast(v60.pos, Vector3.new(0, -14, 0), v_u_51)
				if v95 then
					v94.CFrame = CFrame.lookAt(v95.Position + v95.Normal * 0.06, v95.Position + v95.Normal * 1.06) * CFrame.Angles(0, 1.5707963267948966, 0)
					v94.Transparency = 0.6
				else
					v94.Transparency = 1
				end
			end
			if not v61 or (v61 ~= v56 or not v57) then
				continue
			end
			local v96 = 1 - ((v57.Position + Vector3.new(0, 0.6, 0) - v60.pos).Magnitude - v60.reach) / 5
			local v97 = math.clamp(v96, 0, 1)
			v58 = math.max(v58, v97)
		end
	end
	if #v_u_52 > 0 then
		workspace:BulkMoveTo(v_u_52, v_u_53, Enum.BulkMoveMode.FireCFrameChanged)
	end
	local v98 = v_u_22
	local v99 = v58 - v_u_22
	local v100 = -p54 * (v_u_22 < v58 and 10 or 3)
	v_u_22 = v98 + v99 * (1 - math.exp(v100))
	v_u_8.StepBuzz(p54, v_u_22)
	if not v59 and (v_u_22 < 0.01 and v_u_21) then
		v_u_21:Disconnect()
		v_u_21 = nil
		v_u_8.StepBuzz(p54, 0)
	end
end
function v_u_8.Swarm(p102) -- name: Swarm
	-- upvalues: (copy) v_u_20, (copy) v_u_50, (copy) v_u_5, (copy) v_u_13, (copy) v_u_11, (copy) v_u_12, (copy) v_u_7, (copy) v_u_43, (copy) v_u_6, (ref) v_u_21, (copy) v_u_3, (copy) v_u_101
	local v103 = p102.id
	local v104 = tonumber(v103)
	local v105 = p102.position
	if v104 and typeof(v105) == "Vector3" then
		local v106 = v_u_20[v104]
		if v106 then
			v_u_50(v106, 0)
		end
		local v107 = p102.attacker
		if typeof(v107) ~= "Instance" or not v107:IsA("Model") then
			v107 = nil
		end
		local v108
		if v107 == nil then
			v108 = false
		else
			v108 = v_u_5.IsEnemy(v107)
		end
		local v109 = Instance.new("Folder")
		v109.Name = "Swarm"
		v109.Parent = workspace:FindFirstChild("FX") or workspace
		local v110 = v_u_13
		local v111 = Instance.new("Part")
		v111.Name = "SwarmCore"
		v111.Anchored = true
		v111.CanCollide = false
		v111.CanQuery = false
		v111.CanTouch = false
		v111.CastShadow = false
		v111.Size = Vector3.new(0.2, 0.2, 0.2)
		v111.Color = v110
		v111.Material = Enum.Material.SmoothPlastic
		v111.Transparency = 1
		v111.CFrame = CFrame.new(v105)
		v111.Parent = v109
		local v112 = Instance.new("ParticleEmitter")
		v112.Name = "Haze"
		v112.Texture = "rbxasset://textures/particles/sparkles_main.dds"
		local v113 = ColorSequence.new
		local v114
		if v108 then
			v114 = v_u_11
		else
			v114 = v_u_12
		end
		v112.Color = v113(v114)
		v112.LightEmission = 0.25
		v112.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.38), NumberSequenceKeypoint.new(1, 0) })
		v112.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(1, 1) })
		v112.Lifetime = NumberRange.new(0.35, 0.6)
		v112.Rate = v_u_7.layers and 22 or 10
		v112.Speed = NumberRange.new(0.5, 2)
		v112.SpreadAngle = Vector2.new(180, 180)
		v112.Shape = Enum.ParticleEmitterShape.Sphere
		v112.Parent = v111
		local v115 = Instance.new("ParticleEmitter")
		v115.Name = "Specks"
		v115.Texture = "rbxasset://textures/particles/sparkles_main.dds"
		v115.Color = ColorSequence.new(Color3.fromRGB(60, 44, 20), Color3.fromRGB(150, 110, 30))
		v115.LightEmission = 0
		v115.LightInfluence = 1
		v115.Size = NumberSequence.new(0.16, 0.12)
		v115.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(0.8, 0.25), NumberSequenceKeypoint.new(1, 1) })
		v115.Lifetime = NumberRange.new(0.25, 0.45)
		v115.Rate = v_u_7.layers and 70 or 30
		v115.Speed = NumberRange.new(4, 8)
		v115.SpreadAngle = Vector2.new(180, 180)
		v115.Acceleration = Vector3.new(0, 0, 0)
		v115.Drag = 3
		v115.Shape = Enum.ParticleEmitterShape.Sphere
		v115.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
		v115.Parent = v111
		v111.Size = Vector3.new(2.6, 2.6, 2.6)
		local v116 = workspace.CurrentCamera
		local v117 = (not v116 and 0 or (v116.CFrame.Position - v105).Magnitude) > 90 and 10 or (v_u_7.layers and 22 or 14)
		local v118 = Random.new(v104)
		local v119 = {}
		for _ = 1, v117 do
			local v120, v121, v122 = v_u_43(v109, 1.5 * v118:NextNumber(0.85, 1.15))
			local v123 = {
				["part"] = v120,
				["parts"] = v121,
				["rel"] = v122,
				["radius"] = v118:NextNumber(0.9, 2.4),
				["speed"] = v118:NextNumber(5, 9) * (v118:NextNumber() < 0.5 and -1 or 1),
				["phase"] = v118:NextNumber(0, 6.283185307179586),
				["tilt"] = v118:NextNumber(-0.5, 0.5),
				["bob"] = v118:NextNumber(5, 9)
			}
			table.insert(v119, v123)
		end
		local v124
		if v108 then
			v124 = v_u_11
		else
			v124 = v_u_12
		end
		local v125 = Instance.new("Part")
		v125.Name = "SwarmRing"
		v125.Anchored = true
		v125.CanCollide = false
		v125.CanQuery = false
		v125.CanTouch = false
		v125.CastShadow = false
		v125.Size = Vector3.new(0.05, 5, 5)
		v125.Color = v124
		v125.Material = Enum.Material.SmoothPlastic
		v125.Transparency = 1
		v125.Shape = Enum.PartType.Cylinder
		v125.Parent = v109
		local v126 = p102.duration
		local v127 = tonumber(v126) or 4.5
		local v128 = {
			["id"] = nil,
			["pos"] = nil,
			["err"] = Vector3.new(0, 0, 0),
			["target"] = nil,
			["speed"] = nil,
			["reach"] = nil,
			["untilT"] = nil,
			["enemy"] = nil,
			["bees"] = nil,
			["ring"] = nil,
			["ringAt"] = 0,
			["folder"] = nil,
			["stopLoop"] = nil,
			["anchor"] = nil,
			["ending"] = false,
			["id"] = v104,
			["pos"] = v105
		}
		local v129 = p102.speed
		v128.speed = tonumber(v129) or 18
		local v130 = p102.reach
		v128.reach = tonumber(v130) or 4
		v128.untilT = os.clock() + v127
		v128.enemy = v108
		v128.bees = v119
		v128.ring = v125
		v128.folder = v109
		v128.anchor = v111
		v_u_20[v104] = v128
		local v131 = workspace.CurrentCamera
		if (not v131 and 0 or (v131.CFrame.Position - v105).Magnitude) <= 160 then
			v_u_5.Sound("Beehive_Break", v105)
			v128.stopLoop = v_u_5.Loop("Bees_Loop", v111)
			v_u_6.Puff(v105, Color3.fromRGB(196, 160, 96), 8, 0.9, 6, 0.5)
		end
		if not v_u_21 then
			v_u_21 = v_u_3.Heartbeat:Connect(v_u_101)
		end
	end
end
function v_u_8.SwarmTarget(p132) -- name: SwarmTarget
	-- upvalues: (copy) v_u_20, (copy) v_u_9, (copy) v_u_5
	local v133 = v_u_20
	local v134 = p132.id
	local v135 = v133[tonumber(v134) or -1]
	if v135 then
		local v136 = p132.position
		if typeof(v136) == "Vector3" then
			v135.err = p132.position - v135.pos
		end
		local v137 = p132.target
		if typeof(v137) ~= "Instance" or not v137:IsA("Model") then
			v137 = nil
		end
		v135.target = v137
		if v137 and v137 == v_u_9.Character then
			v_u_5.Sound("Bees_Angry", v135.anchor)
		end
	end
end
function v_u_8.SwarmSync(p138) -- name: SwarmSync
	-- upvalues: (copy) v_u_20
	local v139 = v_u_20
	local v140 = p138.id
	local v141 = v139[tonumber(v140) or -1]
	if v141 then
		local v142 = p138.position
		if typeof(v142) == "Vector3" then
			v141.err = p138.position - v141.pos
		end
	end
end
function v_u_8.SwarmEnd(p143) -- name: SwarmEnd
	-- upvalues: (copy) v_u_20, (copy) v_u_50
	local v144 = v_u_20
	local v145 = p143.id
	local v146 = v144[tonumber(v145) or -1]
	if v146 then
		v_u_50(v146, 0.3)
	end
end
local v_u_147 = nil
local v_u_148 = {}
local v_u_149 = {}
local function v_u_168() -- name: buildGui
	-- upvalues: (copy) v_u_9, (ref) v_u_147, (copy) v_u_148, (copy) v_u_13, (copy) v_u_14, (copy) v_u_149
	local v150 = v_u_9:FindFirstChildOfClass("PlayerGui")
	if v150 then
		local v151 = Instance.new("ScreenGui")
		v151.Name = "TribesSwarm"
		v151.IgnoreGuiInset = true
		v151.ResetOnSpawn = false
		v151.DisplayOrder = 4
		v151.Enabled = false
		v151.Parent = v150
		v_u_147 = v151
		for _, v152 in {
			{
				UDim2.new(1, 0, 0.22, 0),
				UDim2.fromScale(0.5, 0),
				Vector2.new(0.5, 0),
				90
			},
			{
				UDim2.new(1, 0, 0.22, 0),
				UDim2.fromScale(0.5, 1),
				Vector2.new(0.5, 1),
				-90
			},
			{
				UDim2.new(0.18, 0, 1, 0),
				UDim2.fromScale(0, 0.5),
				Vector2.new(0, 0.5),
				0
			},
			{
				UDim2.new(0.18, 0, 1, 0),
				UDim2.fromScale(1, 0.5),
				Vector2.new(1, 0.5),
				180
			}
		} do
			local v153 = Instance.new("Frame")
			v153.Name = "Edge"
			v153.Size = v152[1]
			v153.Position = v152[2]
			v153.AnchorPoint = v152[3]
			v153.BorderSizePixel = 0
			v153.BackgroundColor3 = Color3.fromRGB(196, 136, 30)
			v153.BackgroundTransparency = 1
			local v154 = Instance.new("UIGradient")
			v154.Rotation = v152[4]
			v154.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
			v154.Parent = v153
			v153.Parent = v151
			local v155 = v_u_148
			table.insert(v155, v153)
		end
		local v156 = Random.new()
		for v157 = 1, 12 do
			local v158 = Instance.new("Frame")
			v158.Name = "Bee" .. v157
			v158.AnchorPoint = Vector2.new(0.5, 0.5)
			v158.BackgroundColor3 = v_u_13
			v158.BorderSizePixel = 0
			v158.BackgroundTransparency = 1
			local v159 = v156:NextInteger(10, 18)
			local v160 = UDim2.fromOffset
			local v161 = v159 * 0.66
			v158.Size = v160(v159, (math.floor(v161)))
			local v162 = Instance.new("UICorner")
			v162.CornerRadius = UDim.new(0.5, 0)
			v162.Parent = v158
			local v163 = Instance.new("UIGradient")
			v163.Color = ColorSequence.new({
				ColorSequenceKeypoint.new(0, v_u_14),
				ColorSequenceKeypoint.new(0.22, v_u_14),
				ColorSequenceKeypoint.new(0.23, v_u_13),
				ColorSequenceKeypoint.new(0.44, v_u_13),
				ColorSequenceKeypoint.new(0.45, v_u_14),
				ColorSequenceKeypoint.new(0.6, v_u_14),
				ColorSequenceKeypoint.new(0.61, v_u_13),
				ColorSequenceKeypoint.new(1, v_u_13)
			})
			v163.Parent = v158
			local v164 = Instance.new("Frame")
			v164.Name = "Wing"
			v164.AnchorPoint = Vector2.new(0.5, 1)
			v164.Position = UDim2.fromScale(0.45, 0.15)
			v164.Size = UDim2.fromScale(0.55, 0.9)
			v164.BackgroundColor3 = Color3.fromRGB(200, 216, 228)
			v164.BackgroundTransparency = 1
			v164.BorderSizePixel = 0
			local v165 = Instance.new("UICorner")
			v165.CornerRadius = UDim.new(0.5, 0)
			v165.Parent = v164
			v164.Parent = v158
			v158.Parent = v151
			local v166 = v_u_149
			local v167 = {
				["f"] = nil,
				["x"] = nil,
				["y"] = nil,
				["vx"] = 0,
				["vy"] = 0,
				["t"] = nil,
				["f"] = v158,
				["x"] = v156:NextNumber(),
				["y"] = v156:NextNumber(),
				["t"] = v156:NextNumber(0, 10)
			}
			table.insert(v166, v167)
		end
	end
end
function v_u_8.StepBuzz(p169, p170) -- name: StepBuzz
	-- upvalues: (ref) v_u_147, (copy) v_u_168, (copy) v_u_148, (copy) v_u_149
	if p170 < 0.02 then
		if v_u_147 and v_u_147.Enabled then
			v_u_147.Enabled = false
		end
		return
	else
		if not v_u_147 then
			v_u_168()
		end
		local v171 = v_u_147
		if v171 then
			v171.Enabled = true
			for _, v172 in v_u_148 do
				v172.BackgroundTransparency = 1 - p170 * 0.4
			end
			local v173 = #v_u_149 * math.clamp(p170, 0, 1)
			local v174 = math.ceil(v173)
			for v175, v176 in v_u_149 do
				v176.t = v176.t + p169
				local v177 = v175 <= v174
				v176.f.BackgroundTransparency = v177 and 0.05 or 1
				local v178 = v176.f:FindFirstChild("Wing")
				if v178 then
					local v179
					if v177 then
						local v180 = v176.t * 30
						v179 = math.floor(v180) % 2 == 0 and 0.35 or 0.75
					else
						v179 = 1
					end
					v178.BackgroundTransparency = v179
				end
				if not v177 then
					continue
				end
				local v181 = v176.t * 1.7 + v175
				local v182 = math.sin(v181) * 0.38 * (1.15 - p170 * 0.6) + 0.5
				local v183 = v176.t * 1.3 + v175 * 2
				local v184 = math.cos(v183) * 0.32 * (1.15 - p170 * 0.6) + 0.5
				v176.vx = v176.vx + ((v182 - v176.x) * 9 + (math.random() - 0.5) * 6) * p169
				v176.vy = v176.vy + ((v184 - v176.y) * 9 + (math.random() - 0.5) * 6) * p169
				v176.vx = v176.vx * 0.94
				v176.vy = v176.vy * 0.94
				local v185 = v176.x + v176.vx * p169
				v176.x = math.clamp(v185, -0.05, 1.05)
				local v186 = v176.y + v176.vy * p169
				v176.y = math.clamp(v186, -0.05, 1.05)
				v176.f.Position = UDim2.fromScale(v176.x, v176.y)
				local v187 = v176.f
				local v188 = v176.vy
				local v189 = v176.vx
				local v190 = math.atan2(v188, v189)
				v187.Rotation = math.deg(v190)
			end
		end
	end
end
function v_u_8.Stung() -- name: Stung
	-- upvalues: (ref) v_u_22, (copy) v_u_5, (ref) v_u_21, (copy) v_u_3, (copy) v_u_101
	local v191 = v_u_22
	v_u_22 = math.max(v191, 0.7)
	v_u_5.Sound("Bees_Angry")
	if not v_u_21 then
		v_u_21 = v_u_3.Heartbeat:Connect(v_u_101)
	end
end
local v_u_192 = {}
local function v_u_203() -- name: hatchetModel
	-- upvalues: (copy) v_u_10
	local v193 = v_u_10 and (not v_u_10:FindFirstChild("Hatchet") and v_u_10:FindFirstChild("Projectiles"))
	if v193 then
		v193 = v_u_10.Projectiles:FindFirstChild("Hatchet")
	end
	if v193 then
		local v194 = v193:Clone()
		for _, v195 in v194:IsA("BasePart") and { v194 } or v194:GetDescendants() do
			if v195:IsA("BasePart") then
				v195.Anchored = true
				v195.CanCollide = false
				v195.CanQuery = false
				v195.CanTouch = false
			else
				if not (v195:IsA("Trail") or v195:IsA("ParticleEmitter")) then
					continue
				end
				v195.Enabled = false
			end
		end
		return v194
	end
	local v196 = Instance.new("Model")
	local v197 = Color3.fromRGB(150, 104, 66)
	local v198 = Enum.Material.Wood
	local v199 = Instance.new("Part")
	v199.Name = "Haft"
	v199.Anchored = true
	v199.CanCollide = false
	v199.CanQuery = false
	v199.CanTouch = false
	v199.CastShadow = false
	v199.Size = Vector3.new(0.18, 2.2, 0.18)
	v199.Color = v197
	v199.Material = v198 or Enum.Material.SmoothPlastic
	v199.Transparency = 0
	v199.CFrame = CFrame.new(0, 1.1, 0.3)
	v199.Parent = v196
	local v200 = Color3.fromRGB(80, 80, 86)
	local v201 = Enum.Material.Metal
	local v202 = Instance.new("Part")
	v202.Name = "Head"
	v202.Anchored = true
	v202.CanCollide = false
	v202.CanQuery = false
	v202.CanTouch = false
	v202.CastShadow = false
	v202.Size = Vector3.new(0.12, 0.8, 0.75)
	v202.Color = v200
	v202.Material = v201 or Enum.Material.SmoothPlastic
	v202.Transparency = 0
	v202.CFrame = CFrame.new(0, 0.2, 0)
	v202.Parent = v196
	v196.PrimaryPart = v202
	return v196
end
function v_u_8.HatchetDrop(p204) -- name: HatchetDrop
	-- upvalues: (copy) v_u_192, (copy) v_u_203, (copy) v_u_5, (copy) v_u_6
	local v_u_205 = p204.key
	local v206 = p204.cframe
	if type(v_u_205) == "string" and typeof(v206) == "CFrame" then
		local v207 = v_u_192[v_u_205]
		if v207 then
			v207.model:Destroy()
		end
		local v_u_208 = v_u_203()
		if v_u_208:IsA("Model") then
			v_u_208:PivotTo(v206)
		elseif v_u_208:IsA("BasePart") then
			v_u_208.CFrame = v206
		end
		v_u_208.Parent = workspace:FindFirstChild("FX") or workspace
		local v209 = v_u_192
		local v210 = {
			["model"] = v_u_208
		}
		local v211 = p204.owner
		if typeof(v211) ~= "Instance" or not v211:IsA("Model") then
			v211 = nil
		end
		v210.owner = v211
		v209[v_u_205] = v210
		local v212 = v206.Position
		local v213 = workspace.CurrentCamera
		if (not v213 and 0 or (v213.CFrame.Position - v212).Magnitude) <= 120 then
			v_u_5.Sound("Hatchet_Thunk", v206.Position)
			v_u_6.Puff(v206.Position, Color3.fromRGB(150, 132, 108), 5, 0.6, 4, 0.4)
		end
		task.delay(10, function()
			-- upvalues: (ref) v_u_192, (copy) v_u_205, (copy) v_u_208
			local v214 = v_u_192[v_u_205]
			if v214 and v214.model == v_u_208 then
				v_u_192[v_u_205] = nil
				v_u_208:Destroy()
			end
		end)
	end
end
function v_u_8.HatchetEnd(p215) -- name: HatchetEnd
	-- upvalues: (copy) v_u_192, (copy) v_u_19, (copy) v_u_3, (copy) v_u_4, (copy) v_u_1, (copy) v_u_9, (copy) v_u_5
	local v216 = p215.key
	if type(v216) ~= "string" then
		return
	end
	local v217 = v_u_192[v216]
	v_u_192[v216] = nil
	local v218 = p215.owner
	if typeof(v218) ~= "Instance" or not v218:IsA("Model") then
		v218 = nil
	end
	local v_u_219
	if v218 then
		v_u_219 = v_u_19(v218)
	else
		v_u_219 = nil
	end
	if v217 then
		local v_u_220 = v217.model
		if v_u_219 and p215.how == "pickup" then
			local v_u_221
			if v_u_220:IsA("Model") then
				v_u_221 = v_u_220:GetPivot()
			else
				v_u_221 = v_u_220.CFrame
			end
			local v_u_222 = os.clock()
			local v_u_223 = nil
			v_u_223 = v_u_3.Heartbeat:Connect(function()
				-- upvalues: (copy) v_u_222, (copy) v_u_220, (copy) v_u_219, (ref) v_u_223, (copy) v_u_221
				local v224 = (os.clock() - v_u_222) / 0.12
				local v225 = math.clamp(v224, 0, 1)
				if v_u_220.Parent and (v_u_219.Parent and v225 < 1) then
					local v226 = v_u_220
					local v227 = v_u_221:Lerp(v_u_219.CFrame * CFrame.new(0.8, 0.6, -0.6), v225 * v225)
					if v226:IsA("Model") then
						v226:PivotTo(v227)
					elseif v226:IsA("BasePart") then
						v226.CFrame = v227
					end
				else
					if v_u_223 then
						v_u_223:Disconnect()
					end
					v_u_220:Destroy()
					return
				end
			end)
		else
			for _, v228 in v_u_220:IsA("BasePart") and { v_u_220 } or v_u_220:GetDescendants() do
				if not v228:IsA("BasePart") then
					continue
				end
				v_u_4:Create(v228, TweenInfo.new(0.25), {
					["Transparency"] = 1
				}):Play()
			end
			v_u_1:AddItem(v_u_220, 0.3)
		end
	end
	if p215.how ~= "reset" and (v218 and v_u_219) then
		if v218 == v_u_9.Character then
			v_u_5.Sound("Hatchet_Catch", v_u_219)
		else
			local v229 = v_u_219.Position
			local v230 = workspace.CurrentCamera
			if (not v230 and 0 or (v230.CFrame.Position - v229).Magnitude) > 80 then
				return
			end
			v_u_5.Sound("Hatchet_Catch", v_u_219)
		end
	end
end
function v_u_8.ParryStart(p231) -- name: ParryStart
	-- upvalues: (copy) v_u_9, (copy) v_u_19, (copy) v_u_5, (copy) v_u_6
	local v232 = p231.attacker
	if typeof(v232) ~= "Instance" or not v232:IsA("Model") then
		v232 = nil
	end
	if v232 and v232 ~= v_u_9.Character then
		local v233 = v_u_19(v232)
		if v233 then
			local v234 = v233.Position
			local v235 = workspace.CurrentCamera
			if (not v235 and 0 or (v235.CFrame.Position - v234).Magnitude) <= 150 then
				v_u_5.Sound("Katana_Flick", v233)
				local v236 = v232:FindFirstChildOfClass("Tool")
				local v237 = v_u_5.ToolPoint(v236, "Tip")
				if v237 then
					v_u_6.Burst("Charge_Sparkle", CFrame.new(v237), 0.6, Color3.fromRGB(170, 210, 240))
				end
				return
			end
		end
	end
end
function v_u_8.Parried(p238) -- name: Parried
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_15, (copy) v_u_19, (copy) v_u_4, (copy) v_u_1
	local v239 = p238.position
	if typeof(v239) == "Vector3" then
		local v240 = workspace.CurrentCamera
		if (not v240 and 0 or (v240.CFrame.Position - v239).Magnitude) <= 160 then
			local v241 = p238.ranged == true
			v_u_5.Sound(v241 and "Katana_Deflect" or "Katana_Parry", v239)
			v_u_6.Burst("Block_Spark", CFrame.new(v239), v241 and 1.2 or 1.6, v_u_15)
			v_u_6.Burst("Impact_Sparks", CFrame.new(v239), 0.8, v_u_15)
			local v242 = p238.target
			if typeof(v242) ~= "Instance" or not v242:IsA("Model") then
				v242 = nil
			end
			local v243 = v_u_19(v242)
			local v244 = not v243 and Vector3.new(0, 0, 1) or v243.CFrame.LookVector
			local v245 = Color3.fromRGB(176, 214, 240)
			local v246 = Instance.new("Part")
			v246.Name = "ParryRing"
			v246.Anchored = true
			v246.CanCollide = false
			v246.CanQuery = false
			v246.CanTouch = false
			v246.CastShadow = false
			v246.Size = Vector3.new(0.05, 0.6, 0.6)
			v246.Color = v245
			v246.Material = Enum.Material.SmoothPlastic
			v246.Transparency = 0.3
			v246.Shape = Enum.PartType.Cylinder
			v246.CFrame = CFrame.lookAt(v239, v239 + v244) * CFrame.Angles(0, 1.5707963267948966, 0)
			v246.Parent = workspace:FindFirstChild("FX") or workspace
			v_u_4:Create(v246, TweenInfo.new(0.22, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), {
				["Size"] = nil,
				["Transparency"] = 1,
				["Size"] = Vector3.new(0.05, v241 and 3.2 or 4.2, v241 and 3.2 or 4.2)
			}):Play()
			v_u_1:AddItem(v246, 0.3)
			return
		end
	end
end
return v_u_8