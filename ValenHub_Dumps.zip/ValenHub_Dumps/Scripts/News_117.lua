local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Lighting")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("TweenService")
local v6 = v2:WaitForChild("Shared")
local v_u_7 = require(v6:WaitForChild("News"))
local v_u_8 = require(v6:WaitForChild("Ranks"))
local v_u_9 = require(script.Parent.Parent:WaitForChild("RankArt"))
local v10 = {}
local v_u_11 = Color3.fromRGB(255, 206, 92)
local v_u_12 = Color3.fromRGB(214, 140, 34)
local v_u_13 = {
	0,
	2,
	4,
	5,
	7,
	9,
	11
}
local v_u_14 = {
	{
		["key"] = "trophy",
		["title"] = "WIN TO CLIMB",
		["text"] = "Every win earns trophies.\nClimb to Immortal."
	},
	{
		["key"] = "weapons",
		["title"] = "NEW WEAPONS",
		["text"] = "Each rank adds new\nweapons to your drops."
	},
	{
		["key"] = "reward",
		["title"] = "RANK REWARDS",
		["text"] = "Every rank-up opens\na Rank Reward."
	}
}
function v10.Init(p_u_15) -- name: Init
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_11, (copy) v_u_12, (copy) v_u_8, (copy) v_u_9, (copy) v_u_14, (copy) v_u_3, (copy) v_u_13, (copy) v_u_7, (copy) v_u_4
	local v_u_16 = p_u_15.UI
	local v_u_17 = p_u_15.Theme
	local v_u_18 = p_u_15.State
	local v_u_19 = v_u_17.Colors
	local v_u_20 = v_u_17.Fonts
	local v_u_21 = v_u_16.Assets
	local v_u_22 = p_u_15.MenuManager
	local v_u_23 = v_u_1.LocalPlayer
	local v_u_24 = nil
	local v_u_25 = 0
	local v_u_26 = false
	local v_u_27 = nil
	local v_u_28 = nil
	local v_u_29 = nil
	local function v_u_30() -- name: close
		-- upvalues: (copy) v_u_22
		v_u_22.Close("News")
	end
	local function v_u_61() -- name: build
		-- upvalues: (ref) v_u_24, (copy) v_u_16, (copy) p_u_15, (copy) v_u_19, (copy) v_u_21, (ref) v_u_11, (copy) v_u_17, (copy) v_u_20, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9, (ref) v_u_14, (copy) v_u_22, (copy) v_u_30
		if not v_u_24 then
			local v31, v32 = v_u_16.Screen("TR_News", 30, p_u_15.PlayerGui, {
				["fullBleed"] = true
			})
			v_u_24 = {
				["sg"] = v31
			}
			local v33 = v_u_16.new("Frame", {
				["Name"] = "Root",
				["Size"] = nil,
				["Visible"] = false,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v32
			})
			v_u_24.root = v33
			v_u_24.dim = v_u_16.new("Frame", {
				["Name"] = "Dim",
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 1,
				["ZIndex"] = 1,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["BackgroundColor3"] = v_u_19.Void,
				["Parent"] = v33
			})
			v_u_24.catcher = v_u_16.new("TextButton", {
				["Name"] = "Backdrop",
				["Size"] = nil,
				["BackgroundTransparency"] = 1,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["Selectable"] = false,
				["ZIndex"] = 2,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v33
			})
			local v34 = v_u_16.new("Frame", {
				["Name"] = "Stage",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 3,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromOffset(1600, 900),
				["Parent"] = v33
			})
			local v_u_35 = v_u_16.new("UIScale", {
				["Scale"] = 1,
				["Parent"] = nil,
				["Parent"] = v34
			})
			local function v40() -- name: fit
				-- upvalues: (ref) v_u_16, (copy) v_u_35
				local v36 = v_u_16.CanvasSize()
				local v37 = v_u_35
				local v38 = v36.X / 1600
				local v39 = v36.Y / 900
				v37.Scale = math.min(1, v38, v39)
			end
			local v41 = v_u_16.CanvasSize()
			local v42 = v41.X / 1600
			local v43 = v41.Y / 900
			v_u_35.Scale = math.min(1, v42, v43)
			v_u_16.ScaleChanged:Connect(v40)
			v_u_16.LayoutChanged:Connect(v40)
			v_u_24.stage = v34
			v_u_24.glow = v_u_16.Image(v_u_21.Icons.Glow, {
				["Name"] = "Glow",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ImageColor3"] = nil,
				["ImageTransparency"] = 1,
				["ZIndex"] = 3,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(800, 300),
				["Size"] = UDim2.fromOffset(1500, 1000),
				["ImageColor3"] = v_u_11,
				["Parent"] = v34
			})
			v_u_24.rays = v_u_16.Image(v_u_21.Fx.Rays, {
				["Name"] = "Rays",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ImageColor3"] = nil,
				["ImageTransparency"] = 1,
				["ZIndex"] = 3,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(800, 270),
				["Size"] = UDim2.fromOffset(1250, 1250),
				["ImageColor3"] = v_u_11,
				["Parent"] = v34
			})
			v_u_24.raysThin = v_u_16.Image(v_u_21.Fx.RaysThin, {
				["Name"] = "RaysThin",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ImageColor3"] = nil,
				["ImageTransparency"] = 1,
				["ZIndex"] = 3,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(800, 270),
				["Size"] = UDim2.fromOffset(1500, 1500),
				["ImageColor3"] = v_u_17.Lighten(v_u_11, 0.4),
				["Parent"] = v34
			})
			v_u_24.pill = v_u_16.new("Frame", {
				["Name"] = "Pill",
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(800, 74),
				["Size"] = UDim2.fromOffset(232, 46),
				["BackgroundColor3"] = v_u_19.Accent,
				["ZIndex"] = 6,
				v_u_16.Corner(UDim.new(0.5, 0)),
				["Parent"] = v34
			})
			v_u_16.new("TextLabel", {
				["Name"] = "T",
				["Size"] = nil,
				["Text"] = "NEW UPDATE",
				["FontFace"] = nil,
				["TextSize"] = 25,
				["TextColor3"] = nil,
				["ZIndex"] = 7,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["FontFace"] = v_u_20.Display,
				["TextColor3"] = Color3.new(1, 1, 1),
				["Parent"] = v_u_24.pill
			})
			v_u_24.pillScale = v_u_16.new("UIScale", {
				["Scale"] = 1,
				["Parent"] = nil,
				["Parent"] = v_u_24.pill
			})
			v_u_24.title = v_u_16.DisplayText({
				["Name"] = "Title",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "THE RANKED UPDATE",
				["TextSize"] = 116,
				["TextColor3"] = nil,
				["StrokeThickness"] = 4,
				["ZIndex"] = 6,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(800, 168),
				["Size"] = UDim2.fromOffset(1500, 128),
				["TextColor3"] = Color3.new(1, 1, 1),
				["Parent"] = v34
			})
			v_u_16.Gradient(v_u_17.Lighten(v_u_11, 0.45), v_u_12, 90).Parent = v_u_24.title
			v_u_24.titleScale = v_u_16.new("UIScale", {
				["Scale"] = 1,
				["Parent"] = nil,
				["Parent"] = v_u_24.title
			})
			v_u_24.sub = v_u_16.new("TextLabel", {
				["Name"] = "Sub",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "Eight ranks. New weapons. Prove you\'re Immortal.",
				["FontFace"] = nil,
				["TextSize"] = 36,
				["TextColor3"] = nil,
				["TextTransparency"] = 1,
				["ZIndex"] = 6,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(800, 258),
				["Size"] = UDim2.fromOffset(1300, 44),
				["FontFace"] = v_u_20.Heavy,
				["TextColor3"] = v_u_19.Text,
				["Parent"] = v34
			})
			v_u_24.subStroke = v_u_16.TextStroke(v_u_19.Void, 2, 0.35)
			v_u_24.subStroke.Parent = v_u_24.sub
			local v44 = v_u_8.Count()
			v_u_16.new("Frame", {
				["Name"] = "RoadBack",
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.fromOffset(190, 405),
				["Size"] = UDim2.fromOffset(1220, 8),
				["BackgroundColor3"] = v_u_19.Void,
				["BackgroundTransparency"] = 0.45,
				["ZIndex"] = 4,
				v_u_16.Corner(UDim.new(0.5, 0)),
				["Parent"] = v34
			})
			v_u_24.road = v_u_16.new("Frame", {
				["Name"] = "Road",
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.fromOffset(190, 405),
				["Size"] = UDim2.fromOffset(0, 8),
				["BackgroundColor3"] = Color3.new(1, 1, 1),
				["ZIndex"] = 5,
				v_u_16.Corner(UDim.new(0.5, 0)),
				["Parent"] = v34
			})
			v_u_16.new("UIGradient", {
				["Color"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_9.Color(1)), ColorSequenceKeypoint.new(0.5, v_u_9.Color(4)), ColorSequenceKeypoint.new(1, v_u_11) }),
				["Parent"] = v_u_24.road
			})
			v_u_24.emblems = {}
			for v45 = 1, v44 do
				local v46 = 190 + (v45 - 1) * 1220 / (v44 - 1)
				local v47 = v45 == v44 and 176 or (v45 - 1) * 7 + 100
				local v48 = v45 == v44 and 393 or 405
				local v49 = v_u_16.new("Frame", {
					["Name"] = nil,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Visible"] = false,
					["ZIndex"] = 8,
					["Parent"] = nil,
					["Name"] = "Rank" .. v45,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromOffset(v46, v48),
					["Size"] = UDim2.fromOffset(v47, v47),
					["Parent"] = v34
				})
				v_u_9.Emblem(v45, v47, {
					["ZIndex"] = 8,
					["Parent"] = nil,
					["Parent"] = v49
				})
				local v50 = v_u_16.new("UIScale", {
					["Scale"] = 1,
					["Parent"] = nil,
					["Parent"] = v49
				})
				local v51 = v_u_9.Color(v45)
				local v52 = v_u_16.new("Frame", {
					["Name"] = "Ring",
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromOffset(v46, v48),
					["Size"] = UDim2.fromOffset(v47, v47),
					["BackgroundTransparency"] = 1,
					["Visible"] = false,
					["ZIndex"] = 7,
					v_u_16.Corner(UDim.new(0.5, 0)),
					["Parent"] = v34
				})
				local v53 = v_u_16.Stroke(v51, 4, 0)
				v53.Parent = v52
				local v54 = v_u_16.new("TextLabel", {
					["Name"] = "Name",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = nil,
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextTransparency"] = 1,
					["ZIndex"] = 8,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0),
					["Position"] = UDim2.fromOffset(v46, 485),
					["Size"] = UDim2.fromOffset(200, 34),
					["Text"] = string.upper(v_u_8.Get(v45).name),
					["FontFace"] = v_u_20.Display,
					["TextSize"] = v45 == v44 and 31 or 24,
					["TextColor3"] = v51,
					["Parent"] = v34
				})
				local v55 = v_u_16.TextStroke(v_u_19.Void, 2, 0.3)
				v55.Parent = v54
				v_u_24.emblems[v45] = {
					["holder"] = v49,
					["scale"] = v50,
					["ring"] = v52,
					["ringStroke"] = v53,
					["name"] = v54,
					["nameStroke"] = v55,
					["size"] = v47
				}
			end
			v_u_24.cards = {}
			for v56, v57 in v_u_14 do
				local v58 = v_u_16.Panel({
					["Name"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundTransparency"] = 0.12,
					["StrokeColor"] = nil,
					["StrokeTransparency"] = 0.55,
					["Visible"] = false,
					["ZIndex"] = 6,
					["Parent"] = nil,
					["Name"] = "Card_" .. v57.key,
					["Position"] = UDim2.fromOffset(71 + (v56 - 1) * 494, 548),
					["Size"] = UDim2.fromOffset(470, 156),
					["StrokeColor"] = v_u_11,
					["Parent"] = v34
				})
				local v59 = v_u_16.new("Frame", {
					["Name"] = "Icon",
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundTransparency"] = 1,
					["ZIndex"] = 7,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(16, 0),
					["Size"] = UDim2.fromOffset(124, 156),
					["Parent"] = v58
				})
				if v57.key == "trophy" then
					v_u_9.Trophy(96, {
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["ZIndex"] = 7,
						["Parent"] = nil,
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.fromScale(0.5, 0.5),
						["Parent"] = v59
					})
				elseif v57.key == "weapons" then
					local v60 = v_u_21.News.NewWeapons
					v_u_16.Image(v60, {
						["Name"] = "Shadow",
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["ImageColor3"] = nil,
						["ImageTransparency"] = 0.55,
						["ZIndex"] = 7,
						["Parent"] = nil,
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.new(0.5, 3, 0.5, 5),
						["Size"] = UDim2.fromOffset(136, 136),
						["ImageColor3"] = Color3.new(0, 0, 0),
						["Parent"] = v59
					})
					v_u_16.Image(v60, {
						["Name"] = "Art",
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["ZIndex"] = 8,
						["Parent"] = nil,
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.fromScale(0.5, 0.5),
						["Size"] = UDim2.fromOffset(136, 136),
						["Parent"] = v59
					})
				else
					v_u_9.Emblem(v_u_8.Count() - 1, 100, {
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["ZIndex"] = 7,
						["Parent"] = nil,
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.fromScale(0.5, 0.5),
						["Parent"] = v59
					})
				end
				v_u_16.DisplayText({
					["Name"] = "Title",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = nil,
					["TextSize"] = 34,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["StrokeThickness"] = 2,
					["ZIndex"] = 7,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(156, 26),
					["Size"] = UDim2.fromOffset(294, 38),
					["Text"] = v57.title,
					["TextColor3"] = v_u_11,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Parent"] = v58
				})
				v_u_16.new("TextLabel", {
					["Name"] = "Text",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = nil,
					["FontFace"] = nil,
					["TextSize"] = 25,
					["TextColor3"] = nil,
					["TextWrapped"] = true,
					["TextXAlignment"] = nil,
					["TextYAlignment"] = nil,
					["ZIndex"] = 7,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(156, 70),
					["Size"] = UDim2.fromOffset(294, 70),
					["Text"] = v57.text,
					["FontFace"] = v_u_20.SemiBold,
					["TextColor3"] = v_u_19.TextDim,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["TextYAlignment"] = Enum.TextYAlignment.Top,
					["Parent"] = v58
				})
				v_u_24.cards[v56] = v58
			end
			v_u_24.rankBtn = v_u_16.Button({
				["Name"] = "SeeRank",
				["Text"] = "SEE YOUR RANK",
				["TextSize"] = 30,
				["Style"] = "Primary",
				["Size"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Radius"] = 16,
				["Visible"] = false,
				["Parent"] = nil,
				["Size"] = UDim2.fromOffset(360, 80),
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(604, 790),
				["Parent"] = v34
			})
			v_u_24.goBtn = v_u_16.Button({
				["Name"] = "Go",
				["Text"] = "LET\'S GO",
				["TextSize"] = 30,
				["Style"] = "Dark",
				["Size"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Radius"] = 16,
				["Visible"] = false,
				["Parent"] = nil,
				["Size"] = UDim2.fromOffset(360, 80),
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(996, 790),
				["Parent"] = v34
			})
			v_u_24.rankBtn.Activated:Connect(function()
				-- upvalues: (ref) v_u_22
				v_u_22.Open("Ranks")
			end)
			v_u_24.goBtn.Activated:Connect(v_u_30)
		end
	end
	local v_u_62 = nil
	local function v_u_65() -- name: showAll
		-- upvalues: (ref) v_u_24, (ref) v_u_27, (ref) v_u_26
		v_u_24.dim.BackgroundTransparency = 0.18
		v_u_24.glow.ImageTransparency = 0.72
		v_u_24.rays.ImageTransparency = 0.8
		v_u_24.raysThin.ImageTransparency = 0.88
		v_u_24.pill.Visible = true
		v_u_24.pillScale.Scale = 1
		v_u_24.title.Visible = true
		v_u_24.titleScale.Scale = 1
		v_u_24.sub.TextTransparency = 0
		v_u_24.subStroke.Transparency = 0.35
		v_u_24.road.Size = UDim2.fromOffset(1220, 8)
		for _, v63 in v_u_24.emblems do
			v63.holder.Visible = true
			v63.scale.Scale = 1
			v63.ring.Visible = false
			v63.name.TextTransparency = 0
			v63.nameStroke.Transparency = 0.3
		end
		for _, v64 in v_u_24.cards do
			v64.Visible = true
			v64.Position = UDim2.fromOffset(v64.Position.X.Offset, 548)
		end
		v_u_24.rankBtn.Instance.Visible = true
		v_u_24.goBtn.Instance.Visible = true
		v_u_27 = nil
		v_u_26 = false
	end
	local function v_u_103() -- name: play
		-- upvalues: (ref) v_u_25, (ref) v_u_26, (ref) v_u_24, (ref) v_u_27, (copy) v_u_65, (ref) v_u_5, (copy) p_u_15, (copy) v_u_16, (ref) v_u_13
		v_u_25 = v_u_25 + 1
		local v_u_66 = v_u_25
		v_u_26 = true
		v_u_24.dim.BackgroundTransparency = 1
		for _, v67 in { v_u_24.glow, v_u_24.rays, v_u_24.raysThin } do
			v67.ImageTransparency = 1
		end
		v_u_24.pill.Visible = false
		v_u_24.title.Visible = false
		v_u_24.sub.TextTransparency = 1
		v_u_24.subStroke.Transparency = 1
		v_u_24.road.Size = UDim2.fromOffset(0, 8)
		for _, v68 in v_u_24.emblems do
			v68.holder.Visible = false
			v68.ring.Visible = false
			v68.name.TextTransparency = 1
			v68.nameStroke.Transparency = 1
		end
		for _, v69 in v_u_24.cards do
			v69.Visible = false
		end
		v_u_24.rankBtn.Instance.Visible = false
		v_u_24.goBtn.Instance.Visible = false
		v_u_27 = function()
			-- upvalues: (ref) v_u_25, (ref) v_u_65
			v_u_25 = v_u_25 + 1
			v_u_65()
		end
		v_u_5:Create(v_u_24.dim, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["BackgroundTransparency"] = 0.18
		}):Play()
		v_u_5:Create(v_u_24.glow, TweenInfo.new(0.9, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["ImageTransparency"] = 0.72
		}):Play()
		v_u_5:Create(v_u_24.rays, TweenInfo.new(1.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["ImageTransparency"] = 0.8
		}):Play()
		v_u_5:Create(v_u_24.raysThin, TweenInfo.new(1.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["ImageTransparency"] = 0.88
		}):Play()
		local function v_u_72()
			-- upvalues: (ref) v_u_24, (ref) v_u_5, (ref) p_u_15
			v_u_24.pill.Visible = true
			v_u_24.pillScale.Scale = 0.4
			local v70 = v_u_24.pillScale
			local v71 = Enum.EasingStyle.Back
			v_u_5:Create(v70, TweenInfo.new(0.35, v71 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Scale"] = 1
			}):Play()
			p_u_15.Sounds.Play("Whoosh")
		end
		task.delay(0.15, function()
			-- upvalues: (copy) v_u_66, (ref) v_u_25, (copy) v_u_72
			if v_u_66 == v_u_25 then
				v_u_72()
			end
		end)
		local function v_u_75()
			-- upvalues: (ref) v_u_24, (ref) v_u_5, (ref) p_u_15, (ref) v_u_16
			v_u_24.title.Visible = true
			v_u_24.titleScale.Scale = 1.9
			local v73 = v_u_24.titleScale
			local v74 = Enum.EasingStyle.Back
			v_u_5:Create(v73, TweenInfo.new(0.32, v74 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Scale"] = 1
			}):Play()
			p_u_15.Sounds.Play("LevelUp")
			v_u_16.Shake(v_u_24.stage, 6, 0.25)
		end
		task.delay(0.3, function()
			-- upvalues: (copy) v_u_66, (ref) v_u_25, (copy) v_u_75
			if v_u_66 == v_u_25 then
				v_u_75()
			end
		end)
		local function v_u_76()
			-- upvalues: (ref) v_u_24, (ref) v_u_5
			v_u_5:Create(v_u_24.sub, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["TextTransparency"] = 0
			}):Play()
			v_u_5:Create(v_u_24.subStroke, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Transparency"] = 0.35
			}):Play()
		end
		task.delay(0.6, function()
			-- upvalues: (copy) v_u_66, (ref) v_u_25, (copy) v_u_76
			if v_u_66 == v_u_25 then
				v_u_76()
			end
		end)
		local v_u_77 = #v_u_24.emblems
		local function v_u_82()
			-- upvalues: (ref) v_u_24, (copy) v_u_77, (ref) v_u_5
			local v78 = v_u_24.road
			local v79 = (v_u_77 - 1) * 0.26 + 0.1
			local v80 = {
				["Size"] = UDim2.fromOffset(1220, 8)
			}
			local v81 = Enum.EasingStyle.Linear
			v_u_5:Create(v78, TweenInfo.new(v79, v81 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v80):Play()
		end
		task.delay(0.75, function()
			-- upvalues: (copy) v_u_66, (ref) v_u_25, (copy) v_u_82
			if v_u_66 == v_u_25 then
				v_u_82()
			end
		end)
		for v_u_83, v_u_84 in v_u_24.emblems do
			local v85 = 0.75 + (v_u_83 - 1) * 0.26
			local function v_u_91()
				-- upvalues: (copy) v_u_84, (copy) v_u_83, (copy) v_u_77, (ref) v_u_5, (ref) p_u_15, (ref) v_u_16, (ref) v_u_24, (copy) v_u_66, (ref) v_u_25, (ref) v_u_13
				v_u_84.holder.Visible = true
				v_u_84.scale.Scale = v_u_83 == v_u_77 and 2.4 or 1.7
				local v86 = v_u_84.scale
				local v87 = v_u_83 == v_u_77 and 0.5 or 0.34
				local v88 = Enum.EasingStyle.Back
				v_u_5:Create(v86, TweenInfo.new(v87, v88 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Scale"] = 1
				}):Play()
				v_u_5:Create(v_u_84.name, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["TextTransparency"] = 0
				}):Play()
				v_u_5:Create(v_u_84.nameStroke, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Transparency"] = 0.3
				}):Play()
				v_u_84.ring.Visible = true
				v_u_84.ring.Size = UDim2.fromOffset(v_u_84.size * 0.8, v_u_84.size * 0.8)
				v_u_84.ringStroke.Transparency = 0
				local v89 = v_u_84.ring
				local v90 = {
					["Size"] = UDim2.fromOffset(v_u_84.size * 1.9, v_u_84.size * 1.9)
				}
				v_u_5:Create(v89, TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v90):Play()
				v_u_5:Create(v_u_84.ringStroke, TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Transparency"] = 1
				}):Play()
				if v_u_83 == v_u_77 then
					p_u_15.Sounds.Play("Fanfare")
					v_u_16.Shake(v_u_24.stage, 10, 0.35)
					v_u_5:Create(v_u_24.glow, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["ImageTransparency"] = 0.5
					}):Play()
					task.delay(0.3, function()
						-- upvalues: (ref) v_u_66, (ref) v_u_25, (ref) v_u_24, (ref) v_u_5
						if v_u_66 == v_u_25 then
							v_u_5:Create(v_u_24.glow, TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
								["ImageTransparency"] = 0.72
							}):Play()
						end
					end)
				else
					p_u_15.Sounds.Play("Rank_Pop", {
						["pitch"] = 0.8 * 2 ^ ((v_u_13[v_u_83] or 12) / 12)
					})
				end
			end
			task.delay(v85, function()
				-- upvalues: (copy) v_u_66, (ref) v_u_25, (copy) v_u_91
				if v_u_66 == v_u_25 then
					v_u_91()
				end
			end)
		end
		local v92 = (v_u_77 - 1) * 0.26 + 0.75 + 0.45
		for v93, v_u_94 in v_u_24.cards do
			local v95 = v92 + (v93 - 1) * 0.12
			local function v_u_100()
				-- upvalues: (copy) v_u_94, (ref) v_u_5, (ref) p_u_15
				v_u_94.Visible = true
				local v96 = v_u_94.Position.X.Offset
				v_u_94.Position = UDim2.fromOffset(v96, 628)
				local v97 = v_u_94
				local v98 = {
					["Position"] = UDim2.fromOffset(v96, 548)
				}
				local v99 = Enum.EasingStyle.Back
				v_u_5:Create(v97, TweenInfo.new(0.4, v99 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v98):Play()
				p_u_15.Sounds.Play("Whoosh", {
					["volume"] = 0.3
				})
			end
			task.delay(v95, function()
				-- upvalues: (copy) v_u_66, (ref) v_u_25, (copy) v_u_100
				if v_u_66 == v_u_25 then
					v_u_100()
				end
			end)
		end
		local v101 = v92 + 0.55
		local function v_u_102()
			-- upvalues: (ref) v_u_24, (ref) v_u_16, (ref) v_u_27, (ref) v_u_26
			v_u_24.rankBtn.Instance.Visible = true
			v_u_24.goBtn.Instance.Visible = true
			v_u_16.Pop(v_u_24.rankBtn.Instance, 0.7)
			v_u_16.Pop(v_u_24.goBtn.Instance, 0.7)
			v_u_27 = nil
			v_u_26 = false
		end
		task.delay(v101, function()
			-- upvalues: (copy) v_u_66, (ref) v_u_25, (copy) v_u_102
			if v_u_66 == v_u_25 then
				v_u_102()
			end
		end)
	end
	local v112 = {
		["open"] = function() -- name: open
			-- upvalues: (copy) v_u_61, (ref) v_u_28, (copy) v_u_23, (ref) v_u_7, (copy) p_u_15, (ref) v_u_62, (copy) v_u_16, (ref) v_u_3, (ref) v_u_5, (ref) v_u_24, (ref) v_u_29, (ref) v_u_4, (copy) v_u_103
			v_u_61()
			v_u_28 = v_u_23:GetAttribute("News") or v_u_7.CURRENT
			p_u_15.SetHudHidden("News", true)
			if not (v_u_62 and v_u_62.Parent) then
				local v104 = {
					["Name"] = "TR_NewsBlur",
					["Size"] = 0,
					["Parent"] = nil,
					["Parent"] = v_u_3
				}
				v_u_62 = v_u_16.new("BlurEffect", v104)
			end
			v_u_5:Create(v_u_62, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Size"] = 16
			}):Play()
			if p_u_15.TopbarSettings then
				local v105 = p_u_15.TopbarSettings.SetHidden
				if type(v105) == "function" then
					local v106 = p_u_15.TopbarSettings.SetHidden
					pcall(v106, "News", true)
				end
			end
			v_u_24.root.Visible = true
			if v_u_29 then
				v_u_29:Disconnect()
			end
			v_u_29 = v_u_4.RenderStepped:Connect(function(p107)
				-- upvalues: (ref) v_u_24
				v_u_24.rays.Rotation = (v_u_24.rays.Rotation + p107 * 6) % 360
				v_u_24.raysThin.Rotation = (v_u_24.raysThin.Rotation - p107 * 3.5) % 360
			end)
			v_u_103()
		end,
		["close"] = function(_) -- name: close
			-- upvalues: (ref) v_u_25, (ref) v_u_27, (ref) v_u_26, (ref) v_u_29, (copy) p_u_15, (ref) v_u_62, (ref) v_u_5, (ref) v_u_28, (ref) v_u_24
			v_u_25 = v_u_25 + 1
			v_u_27 = nil
			v_u_26 = false
			if v_u_29 then
				v_u_29:Disconnect()
				v_u_29 = nil
			end
			p_u_15.SetHudHidden("News", false)
			if v_u_62 then
				local v_u_108 = v_u_62
				v_u_62 = nil
				local v109 = v_u_5:Create(v_u_108, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Size"] = 0
				})
				v109:Play()
				v109.Completed:Connect(function()
					-- upvalues: (copy) v_u_108
					v_u_108:Destroy()
				end)
			end
			if p_u_15.TopbarSettings then
				local v110 = p_u_15.TopbarSettings.SetHidden
				if type(v110) == "function" then
					local v111 = p_u_15.TopbarSettings.SetHidden
					pcall(v111, "News", false)
				end
			end
			if v_u_28 then
				p_u_15.Remotes.Fire("NewsAction", "Seen", v_u_28)
				v_u_28 = nil
			end
			if v_u_24 then
				v_u_24.root.Visible = false
			end
		end,
		["select"] = function() -- name: select
			-- upvalues: (ref) v_u_24
			if v_u_24 then
				return v_u_24.rankBtn.Instance
			else
				return nil
			end
		end,
		["back"] = function() -- name: back
			-- upvalues: (ref) v_u_26
			return v_u_26
		end
	}
	v_u_22.Register("News", v112)
	local function v_u_114() -- name: lobbyQuiet
		-- upvalues: (copy) v_u_18, (copy) v_u_22, (copy) p_u_15, (copy) v_u_23
		local v113 = not (v_u_18.InMatch() or (v_u_22.IsOpen() or p_u_15.IsHudHiddenFor("Reveal")) or (p_u_15.IsHudHiddenFor("RankUp") or p_u_15.IsHudHiddenFor("MatchEnd") or (p_u_15.IsHudHiddenFor("Celebrate") or p_u_15.IsHudHiddenFor("Intro"))))
		if v113 then
			if v_u_23:GetAttribute("WelcomeCard") == true or (v_u_23:GetAttribute("Teleporting") == true or v_u_23:GetAttribute("Queued") == true) then
				v113 = false
			else
				v113 = v_u_23.Character ~= nil
			end
		end
		return v113
	end
	local v_u_115 = false
	local function v118() -- name: maybeShow
		-- upvalues: (ref) v_u_115, (copy) v_u_23, (ref) v_u_7, (copy) v_u_114, (copy) v_u_22
		if not v_u_115 and v_u_23:GetAttribute("News") == v_u_7.CURRENT then
			v_u_115 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_23, (ref) v_u_7, (ref) v_u_114, (ref) v_u_22, (ref) v_u_115
				local v116 = os.clock()
				local v117 = nil
				while v_u_23:GetAttribute("News") == v_u_7.CURRENT and os.clock() - v116 < 180 do
					if v_u_114() then
						v117 = v117 or os.clock()
						if os.clock() - v117 >= 1.5 then
							v_u_22.Open("News")
							break
						end
					else
						v117 = nil
					end
					task.wait(0.25)
				end
				v_u_115 = false
			end)
		end
	end
	v_u_23:GetAttributeChangedSignal("News"):Connect(v118)
	if not v_u_115 and v_u_23:GetAttribute("News") == v_u_7.CURRENT then
		v_u_115 = true
		task.spawn(function()
			-- upvalues: (copy) v_u_23, (ref) v_u_7, (copy) v_u_114, (copy) v_u_22, (ref) v_u_115
			local v119 = os.clock()
			local v120 = nil
			while v_u_23:GetAttribute("News") == v_u_7.CURRENT and os.clock() - v119 < 180 do
				if v_u_114() then
					v120 = v120 or os.clock()
					if os.clock() - v120 >= 1.5 then
						v_u_22.Open("News")
						break
					end
				else
					v120 = nil
				end
				task.wait(0.25)
			end
			v_u_115 = false
		end)
	end
	function p_u_15.ShowNews()
		-- upvalues: (copy) v_u_22
		v_u_22.Open("News")
	end
	function p_u_15.Debug.news(p121)
		-- upvalues: (copy) v_u_22, (ref) v_u_27, (copy) v_u_23, (ref) v_u_115, (ref) v_u_7, (ref) v_u_26
		if p121 == "open" then
			v_u_22.Open("News")
		elseif p121 == "skip" and v_u_27 then
			v_u_27()
		elseif p121 == "close" then
			v_u_22.Close("News")
		end
		return {
			["attr"] = v_u_23:GetAttribute("News") or false,
			["open"] = v_u_22.IsOpen("News"),
			["waiting"] = v_u_115,
			["item"] = v_u_7.CURRENT,
			["playing"] = v_u_26
		}
	end
end
return v10