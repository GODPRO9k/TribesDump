local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v4 = v2:WaitForChild("Shared")
local v_u_5 = require(v4:WaitForChild("Tribes"))
local v_u_6 = require(v4:WaitForChild("TribeArt"))
local v7 = {}
local v_u_8 = Color3.fromRGB(176, 162, 134)
local v_u_9 = Color3.fromRGB(228, 232, 240)
local v_u_10 = Color3.fromRGB(142, 149, 166)
local v_u_11 = Color3.fromRGB(255, 186, 46)
local v_u_12 = { v_u_11, Color3.fromRGB(196, 206, 222), Color3.fromRGB(222, 140, 74) }
local v_u_13 = Color3.fromRGB(14, 15, 20)
function v7.Init(p_u_14) -- name: Init
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_1, (copy) v_u_3, (copy) v_u_6, (copy) v_u_13, (copy) v_u_11, (copy) v_u_10, (copy) v_u_12, (copy) v_u_9
	local v_u_15 = p_u_14.UI
	local v_u_16 = p_u_14.Theme
	local v_u_17 = v_u_16.Fonts
	local v_u_18 = p_u_14.Tribes
	local v_u_19 = require(script.Parent.Parent:WaitForChild("TribeEmblem"))
	v_u_19.Init(v_u_15)
	local v_u_20 = {}
	local v_u_21 = {}
	local v_u_22 = {}
	local function v_u_45(p23) -- name: paintBanner
		-- upvalues: (ref) v_u_20, (copy) v_u_22, (ref) v_u_5, (ref) v_u_8, (copy) v_u_19, (copy) v_u_15, (copy) v_u_17
		local v24 = p23:GetAttribute("Rank")
		local v25
		if type(v24) == "number" then
			v25 = v_u_20[v24]
		else
			v25 = nil
		end
		local v26
		if v25 then
			local v27 = string.format
			local v28 = v25.id
			local v29 = tostring(v28)
			local v30 = v25.icon
			local v31 = tostring(v30)
			local v32 = v25.color1
			local v33 = tostring(v32)
			local v34 = v25.color2
			v26 = v27("%s:%s:%s:%s", v29, v31, v33, (tostring(v34)))
		else
			v26 = "-"
		end
		if v_u_22[p23] == v26 then
			return
		else
			v_u_22[p23] = v26
			local v35
			if v25 then
				v35 = v_u_5.Color(v25.color1):Lerp(Color3.new(0, 0, 0), 0.12)
			else
				v35 = v_u_8
			end
			p23.Color = v35
			local v36 = p23:FindFirstAncestorOfClass("Model")
			if v36 then
				for _, v37 in v36:GetDescendants() do
					if not v37:IsA("BasePart") or v37:GetAttribute("BannerTail") ~= v24 then
						continue
					end
					v37.Color = v35
				end
			end
			local v38 = p23:FindFirstChild("Placeholder")
			if v38 and v38:IsA("SurfaceGui") then
				v38.Enabled = v25 == nil
			end
			local v39 = p23:FindFirstChild("Emblem")
			if v39 then
				for _, v40 in v39:GetChildren() do
					v40:Destroy()
				end
				if v25 then
					v_u_19.new(116, {
						["AnchorPoint"] = Vector2.new(0.5, 0),
						["Position"] = UDim2.new(0.5, 0, 0, 22),
						["Parent"] = v39
					}):Set(v25.icon, v25.color2, v25.color1, v25.tag)
					local v41 = v_u_15.new
					local v42 = {
						["Name"] = "Tag",
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Text"] = nil,
						["FontFace"] = nil,
						["TextScaled"] = true,
						["TextColor3"] = nil,
						["Parent"] = nil,
						["AnchorPoint"] = Vector2.new(0.5, 0),
						["Position"] = UDim2.new(0.5, 0, 0, 160),
						["Size"] = UDim2.new(1, -16, 0, 40)
					}
					local v43 = v25.tag
					v42.Text = "[" .. tostring(v43) .. "]"
					v42.FontFace = v_u_17.Display
					v42.TextColor3 = v_u_5.Color(v25.color2)
					v42.Parent = v39
					local v44 = v41("TextLabel", v42)
					v_u_15.TextStroke(Color3.new(0, 0, 0), 1.5, 0.6).Parent = v44
				end
			else
				return
			end
		end
	end
	local function v_u_47() -- name: paintAll
		-- upvalues: (ref) v_u_1, (copy) v_u_45
		for _, v46 in v_u_1:GetTagged("TribeBanner") do
			if not v46:IsA("BasePart") then
				continue
			end
			v_u_45(v46)
		end
	end
	local function v_u_50() -- name: paintMap
		-- upvalues: (ref) v_u_3, (ref) v_u_6, (copy) v_u_15
		local v48 = v_u_3:FindFirstChild("TribeHall")
		if v48 then
			v48 = v48:FindFirstChild("MapCloth", true)
		end
		if v48 then
			v48 = v48:FindFirstChild("Map")
		end
		if v48 and (v_u_6.Map.image ~= "" and not v48:FindFirstChild("Base")) then
			local v49 = v48:FindFirstChild("Title")
			if v49 and v49:IsA("GuiObject") then
				v49.Visible = false
			end
			v_u_15.new("ImageLabel", {
				["Name"] = "Base",
				["Image"] = nil,
				["Size"] = nil,
				["ScaleType"] = nil,
				["Parent"] = nil,
				["Image"] = v_u_6.Map.image,
				["Size"] = UDim2.fromScale(1, 1),
				["ScaleType"] = Enum.ScaleType.Crop,
				["Parent"] = v48
			})
		end
	end
	local v_u_51 = game:GetService("Players").LocalPlayer
	local v_u_52 = v_u_15.new("ScreenGui", {
		["Name"] = "TR_TribeBoards",
		["ResetOnSpawn"] = false,
		["Parent"] = nil,
		["Parent"] = p_u_14.PlayerGui
	})
	local v_u_53 = {}
	local v_u_54 = "top"
	local function v_u_88(p55) -- name: buildBoard
		-- upvalues: (copy) v_u_15, (copy) v_u_52, (ref) v_u_13, (copy) v_u_17, (ref) v_u_11, (copy) v_u_16, (ref) v_u_10, (ref) v_u_12, (ref) v_u_9
		local v56 = 800 * p55.Size.Y
		local v57 = p55.Size.X
		local v58 = v56 / math.max(v57, 0.1)
		local v59 = math.floor(v58)
		local v60 = v_u_15.new("SurfaceGui", {
			["Name"] = "TopTribes",
			["Adornee"] = nil,
			["Face"] = nil,
			["SizingMode"] = nil,
			["CanvasSize"] = nil,
			["LightInfluence"] = 0,
			["MaxDistance"] = 220,
			["ResetOnSpawn"] = false,
			["ZIndexBehavior"] = nil,
			["Parent"] = nil,
			["Adornee"] = p55,
			["Face"] = Enum.NormalId.Front,
			["SizingMode"] = Enum.SurfaceGuiSizingMode.FixedSize,
			["CanvasSize"] = Vector2.new(800, v59),
			["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
			["Parent"] = v_u_52
		})
		local v61 = v_u_15.new("Frame", {
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.05,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = v_u_13,
			["Parent"] = v60
		})
		v_u_15.new("UIPadding", {
			["PaddingTop"] = UDim.new(0.03, 0),
			["PaddingBottom"] = UDim.new(0.03, 0),
			["PaddingLeft"] = UDim.new(0.04, 0),
			["PaddingRight"] = UDim.new(0.04, 0),
			["Parent"] = v61
		})
		local v62 = v_u_15.new("TextLabel", {
			["Size"] = nil,
			["Text"] = "TOP TRIBES",
			["FontFace"] = nil,
			["TextScaled"] = true,
			["TextColor3"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 0.1),
			["FontFace"] = v_u_17.Display,
			["TextColor3"] = v_u_11,
			["Parent"] = v61
		})
		v_u_15.TextStroke(v_u_16.Colors.Void, 3, 0).Parent = v62
		local v63 = v_u_15.new("TextLabel", {
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextScaled"] = true,
			["TextColor3"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromScale(0, 0.105),
			["Size"] = UDim2.fromScale(1, 0.045),
			["FontFace"] = v_u_17.Heavy,
			["TextColor3"] = v_u_10,
			["Parent"] = v61
		})
		v_u_15.new("Frame", {
			["Position"] = UDim2.fromScale(0, 0.162),
			["Size"] = UDim2.new(1, 0, 0, 4),
			["BackgroundColor3"] = Color3.fromRGB(176, 120, 22),
			["Parent"] = v61
		})
		local v64 = v_u_15.new("Frame", {
			["Position"] = UDim2.fromScale(0, 0.185),
			["Size"] = UDim2.fromScale(1, 0.815),
			v_u_15.new("UIListLayout", {
				["Padding"] = UDim.new(0.022, 0),
				["SortOrder"] = Enum.SortOrder.LayoutOrder
			}),
			["Parent"] = v61
		})
		local v65 = v59 * 0.94 * 0.815 * 0.18
		local v66 = v65 * 0.36
		local v67 = math.floor(v66)
		local v68 = math.clamp(v67, 14, 60)
		local v69 = {}
		for v70 = 1, 5 do
			local v71 = v_u_15.new
			local v72 = "Frame"
			local v73 = {
				["Name"] = "Row" .. v70,
				["Size"] = UDim2.fromScale(1, 0.18)
			}
			local v74
			if v70 % 2 == 1 then
				v74 = Color3.fromRGB(30, 33, 42)
			else
				v74 = Color3.fromRGB(24, 26, 34)
			end
			v73.BackgroundColor3 = v74
			v73.LayoutOrder = v70
			__set_list(v73, 1, {(v_u_15.Corner(UDim.new(0.18, 0)))})
			v73.Parent = v64
			local v75 = v71(v72, v73)
			local v76 = v_u_15.new("UIStroke", {
				["Color"] = nil,
				["Thickness"] = 4,
				["Enabled"] = false,
				["Parent"] = nil,
				["Color"] = v_u_16.Colors.Ally,
				["Parent"] = v75
			})
			local v77 = v65 * 0.8
			local v78 = math.floor(v77)
			local v79 = v_u_15.new("TextLabel", {
				["Position"] = UDim2.fromScale(0.005, 0),
				["Size"] = UDim2.fromScale(0.09, 1),
				["Text"] = "#" .. v70,
				["FontFace"] = v_u_17.Display,
				["TextSize"] = v68,
				["TextColor3"] = v_u_12[v70] or v_u_9,
				["Parent"] = v75
			})
			local v80 = v_u_15.new("Frame", {
				["Name"] = "Crest",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.fromScale(0.095, 0.5),
				["Size"] = UDim2.fromOffset(v78, v78),
				["Parent"] = v75
			})
			local v81 = v_u_15.new
			local v82 = {
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0.095, v78 + 14, 0.5, 0),
				["Size"] = UDim2.new(0.705, -(v78 + 14), 0.5, 0),
				["Text"] = "-",
				["RichText"] = true,
				["FontFace"] = v_u_17.Heavy,
				["TextScaled"] = true,
				["TextWrapped"] = false,
				["TextColor3"] = v_u_9,
				["TextXAlignment"] = Enum.TextXAlignment.Left
			}
			local v83 = v_u_15.new
			local v84 = {
				["MaxTextSize"] = v68
			}
			local v85 = v68 * 0.55
			v84.MinTextSize = math.floor(v85)
			__set_list(v82, 1, {(v83("UITextSizeConstraint", v84))})
			v82.Parent = v75
			v69[v70] = {
				["frame"] = v75,
				["rank"] = v79,
				["crest"] = v80,
				["name"] = v81("TextLabel", v82),
				["value"] = v_u_15.new("TextLabel", {
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.fromScale(0.975, 0),
					["Size"] = UDim2.fromScale(0.175, 1),
					["FontFace"] = v_u_17.Display,
					["TextSize"] = v68,
					["TextColor3"] = v_u_11,
					["TextXAlignment"] = Enum.TextXAlignment.Right,
					["Parent"] = v75
				}),
				["stroke"] = v76
			}
		end
		local v86 = {
			["sg"] = v60,
			["rows"] = v69,
			["caption"] = v63,
			["emblems"] = {}
		}
		local v87 = v65 * 0.74
		v86.emblemSize = math.floor(v87)
		return v86
	end
	local function v_u_109(p89) -- name: fillBoard
		-- upvalues: (ref) v_u_54, (ref) v_u_21, (ref) v_u_20, (copy) v_u_51, (ref) v_u_5, (copy) v_u_19, (ref) v_u_9, (copy) v_u_15, (ref) v_u_10
		local v90
		if v_u_54 == "alltime" then
			v90 = v_u_21
		else
			v90 = v_u_20
		end
		local v91 = v_u_51:GetAttribute("TribeId")
		if v_u_54 == "alltime" then
			p89.caption.Text = "ALL TIME  \194\183  GLORY"
		else
			local v92 = v_u_5.WeekEndsAt(v_u_5.WeekOf(os.time())) - os.time()
			local v93 = math.max(0, v92)
			local v94
			if v93 >= 86400 then
				v94 = ("%*D %*H"):format(v93 // 86400, v93 % 86400 // 3600)
			else
				v94 = ("%*H %*M"):format(v93 // 3600, v93 % 3600 // 60)
			end
			p89.caption.Text = ("THIS WEEK  \194\183  RESETS IN %*"):format(v94)
		end
		for v95, v96 in p89.rows do
			local v97 = v90[v95]
			local v98 = p89.emblems[v95]
			if v97 then
				if not v98 then
					v98 = v_u_19.new(p89.emblemSize, {
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.fromScale(0.5, 0.5),
						["Parent"] = v96.crest
					})
					p89.emblems[v95] = v98
				end
				v98:Set(v97.icon, v97.color1, v97.color2, v97.tag)
				v96.crest.Visible = true
				local v99 = v96.name
				local v100 = string.format
				local v101 = v_u_19.TagColor(v97.color1):ToHex()
				local v102 = v_u_19.Tag(v97.tag)
				local v103 = v97.name or ""
				v99.Text = v100("<font color=\"#%s\">%s</font> %s", v101, v102, (tostring(v103)))
				v96.name.TextColor3 = v_u_9
				local v104 = v96.value
				local v105 = v_u_15.FormatNumber
				local v106
				if v_u_54 == "alltime" then
					v106 = v97.renown
				else
					v106 = v97.weekRenown
				end
				v104.Text = v105(tonumber(v106) or 0)
				local v107 = v96.stroke
				local v108
				if type(v91) == "number" and v91 > 0 then
					v108 = v97.id == v91
				else
					v108 = false
				end
				v107.Enabled = v108
			else
				v96.crest.Visible = false
				v96.name.Text = "-"
				v96.name.TextColor3 = v_u_10
				v96.value.Text = ""
				v96.stroke.Enabled = false
			end
		end
	end
	local v_u_110 = v_u_21
	local v_u_111 = v_u_54
	local v_u_112 = v_u_20
	local function v115(p113) -- name: addBoard
		-- upvalues: (copy) v_u_53, (copy) v_u_88, (copy) v_u_109
		if p113:IsA("BasePart") and not v_u_53[p113] then
			local v114 = v_u_88(p113)
			v_u_53[p113] = v114
			v_u_109(v114)
		end
	end
	local function v117() -- name: fillAll
		-- upvalues: (copy) v_u_53, (copy) v_u_109
		for _, v116 in v_u_53 do
			v_u_109(v116)
		end
	end
	for _, v118 in v_u_1:GetTagged("TribeLeaderboard") do
		if not v118:IsA("BasePart") or v_u_53[v118] then
			continue
		end
		local v119 = v_u_88(v118)
		v_u_53[v118] = v119
		v_u_109(v119)
	end
	v_u_1:GetInstanceAddedSignal("TribeLeaderboard"):Connect(v115)
	v_u_1:GetInstanceRemovedSignal("TribeLeaderboard"):Connect(function(p120)
		-- upvalues: (copy) v_u_53
		local v121 = v_u_53[p120]
		if v121 then
			v_u_53[p120] = nil
			v121.sg:Destroy()
		end
	end)
	v_u_51:GetAttributeChangedSignal("TribeId"):Connect(v117)
	local function v_u_127(p122, p123) -- name: fadeText
		-- upvalues: (copy) v_u_53, (copy) v_u_15
		local v124 = TweenInfo.new(p123, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
		for _, v125 in v_u_53 do
			v_u_15.Tween(v125.caption, v124, {
				["TextTransparency"] = p122
			})
			for _, v126 in v125.rows do
				v_u_15.Tween(v126.name, v124, {
					["TextTransparency"] = p122
				})
				v_u_15.Tween(v126.value, v124, {
					["TextTransparency"] = p122
				})
			end
		end
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_111, (ref) v_u_110, (ref) v_u_112, (copy) v_u_53, (copy) v_u_127, (copy) v_u_109
		while true do
			while true do
				task.wait(8)
				local v128 = v_u_111 == "top" and #v_u_110 > 0 and "alltime" or (#v_u_112 > 0 and "top" or "alltime")
				if v128 == v_u_111 or not next(v_u_53) then
					break
				end
				v_u_127(1, 0.18)
				task.wait(0.2)
				v_u_111 = v128
				for _, v129 in v_u_53 do
					v_u_109(v129)
				end
				v_u_127(0, 0.3)
			end
			if v128 == v_u_111 then
				continue
			end
			v_u_111 = v128
		end
	end)
	v_u_1:GetInstanceAddedSignal("TribeBanner"):Connect(function(p130)
		-- upvalues: (copy) v_u_22, (copy) v_u_45, (copy) v_u_50
		if p130:IsA("BasePart") then
			v_u_22[p130] = nil
			v_u_45(p130)
			v_u_50()
		end
	end)
	v_u_1:GetInstanceRemovedSignal("TribeBanner"):Connect(function(p131)
		-- upvalues: (copy) v_u_22
		v_u_22[p131] = nil
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_3, (copy) p_u_14, (copy) v_u_18, (ref) v_u_112, (copy) v_u_47, (ref) v_u_110, (ref) v_u_111, (copy) v_u_53, (copy) v_u_109, (copy) v_u_50
		while true do
			if v_u_3:FindFirstChild("TribeHall") and not p_u_14.State.InMatch() then
				local v132, v133 = v_u_18.Board("top")
				if v132 and type(v133) == "table" then
					v_u_112 = {}
					for _, v134 in v133 do
						if type(v134) ~= "table" then
							continue
						end
						local v135 = v134.weekRenown
						if (tonumber(v135) or 0) <= 0 or #v_u_112 >= 5 then
							continue
						end
						local v136 = v_u_112
						table.insert(v136, v134)
					end
					v_u_47()
				end
				local v137, v138 = v_u_18.Board("alltime")
				if v137 and type(v138) == "table" then
					v_u_110 = {}
					for _, v139 in v138 do
						if type(v139) ~= "table" then
							continue
						end
						local v140 = v139.renown
						if (tonumber(v140) or 0) <= 0 or #v_u_110 >= 5 then
							continue
						end
						local v141 = v_u_110
						table.insert(v141, v139)
					end
				end
				if v_u_111 == "top" and #v_u_112 == 0 then
					v_u_111 = "alltime"
				end
				for _, v142 in v_u_53 do
					v_u_109(v142)
				end
				v_u_50()
			end
			task.wait(120)
		end
	end)
end
return v7