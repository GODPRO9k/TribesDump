local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("CustomMatch"))
local v4 = {}
local v_u_5 = {
	["W"] = 1120,
	["H"] = 660,
	["left"] = 400,
	["gap"] = 24,
	["pad"] = 16,
	["label"] = true,
	["box"] = 50,
	["switchRow"] = 60,
	["button"] = 58,
	["section"] = 16,
	["sectionH"] = 24,
	["sectionGap"] = 8,
	["cardGap"] = 22,
	["slotH"] = 56,
	["joinW"] = 100,
	["errH"] = 18,
	["rowH"] = 88,
	["thumbW"] = 128,
	["name"] = 20,
	["sub"] = 15,
	["rowGap"] = 8,
	["rowBtn"] = 108,
	["rowBtnH"] = 48,
	["text"] = 18,
	["desc"] = 15
}
local v_u_6 = {
	["W"] = 1120,
	["H"] = 660,
	["left"] = 380,
	["gap"] = 16,
	["pad"] = 14,
	["label"] = false,
	["box"] = 52,
	["switchRow"] = 56,
	["button"] = 56,
	["section"] = 16,
	["sectionH"] = 24,
	["sectionGap"] = 6,
	["cardGap"] = 14,
	["slotH"] = 58,
	["joinW"] = 100,
	["errH"] = 18,
	["rowH"] = 84,
	["thumbW"] = 112,
	["name"] = 19,
	["sub"] = 14,
	["rowGap"] = 8,
	["rowBtn"] = 112,
	["rowBtnH"] = 56,
	["text"] = 18,
	["desc"] = 14
}
local v_u_7 = Color3.fromRGB(142, 149, 166)
local v_u_8 = Color3.fromRGB(10, 11, 15)
function v4.Init(p_u_9) -- name: Init
	-- upvalues: (copy) v_u_1, (copy) v_u_6, (copy) v_u_5, (copy) v_u_3, (copy) v_u_8, (copy) v_u_7, (copy) v_u_2
	local v_u_10 = p_u_9.UI
	local v_u_11 = p_u_9.Theme
	local v12 = p_u_9.State
	local v_u_13 = v_u_11.Colors
	local v_u_14 = v_u_11.Fonts
	local v_u_15 = p_u_9.Custom
	local v_u_16 = v_u_1.LocalPlayer
	local v_u_17 = UDim2.fromOffset
	local v_u_18
	if v_u_10.Compact then
		v_u_18 = v_u_6
	else
		v_u_18 = v_u_5
	end
	local v_u_19 = v_u_10.Window({
		["Name"] = "CustomMatches",
		["Title"] = "CUSTOM MATCHES",
		["Subtitle"] = nil,
		["Size"] = nil,
		["HeaderHeight"] = 80,
		["Parent"] = nil,
		["OnCloseRequested"] = nil,
		["Subtitle"] = "Your own server: invite friends, pick the map, start when you\'re ready  \194\183  " .. v_u_3.NO_REWARDS,
		["Size"] = v_u_17(v_u_18.W, v_u_18.H),
		["Parent"] = p_u_9.Canvas.Menus,
		["OnCloseRequested"] = function() -- name: OnCloseRequested
			-- upvalues: (copy) p_u_9
			p_u_9.MenuManager.Close("CustomMatches")
		end
	})
	local v20 = v_u_19.Content
	v_u_10.SelectionRing(v_u_19.Root)
	local function v23(p21, p22) -- name: card
		-- upvalues: (copy) v_u_10, (copy) v_u_13
		return v_u_10.new("Frame", {
			["Name"] = p21,
			["BackgroundColor3"] = v_u_13.PanelHi,
			["BackgroundTransparency"] = 0.3,
			v_u_10.Corner(12),
			v_u_10.Stroke(v_u_13.Stroke, 1, 0.92),
			["Parent"] = p22
		})
	end
	local v_u_24 = v_u_10.new("ScrollingFrame", {
		["Name"] = "Left",
		["ScrollBarThickness"] = 3,
		["AutomaticCanvasSize"] = nil,
		["VerticalScrollBarInset"] = nil,
		["Selectable"] = false,
		["Parent"] = nil,
		["AutomaticCanvasSize"] = Enum.AutomaticSize.None,
		["VerticalScrollBarInset"] = Enum.ScrollBarInset.None,
		["Parent"] = v20
	})
	local v_u_25 = v_u_10.SectionTitle("CREATE A MATCH", {
		["Parent"] = v_u_24
	})
	local v_u_26 = v23("Create", v_u_24)
	local v_u_27 = v_u_10.new("TextLabel", {
		["Name"] = "NameLabel",
		["Text"] = "SERVER NAME",
		["FontFace"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_14.Heavy,
		["TextColor3"] = v_u_13.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_26
	})
	local v_u_28 = v_u_10.new("Frame", {
		["Name"] = "NameField",
		["BackgroundColor3"] = v_u_8,
		["BackgroundTransparency"] = 0.25,
		v_u_10.Corner(10),
		["Parent"] = v_u_26
	})
	local v_u_29 = v_u_10.Stroke(v_u_13.Stroke, 1, 0.88)
	v_u_29.Parent = v_u_28
	local v_u_30 = v_u_10.new("TextBox", {
		["Name"] = "NameBox",
		["Text"] = "",
		["PlaceholderText"] = nil,
		["PlaceholderColor3"] = nil,
		["ClearTextOnFocus"] = false,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Parent"] = nil,
		["PlaceholderText"] = v_u_3.DefaultName(v_u_16.DisplayName),
		["PlaceholderColor3"] = v_u_13.TextMuted,
		["FontFace"] = v_u_14.Bold,
		["TextColor3"] = v_u_13.Text,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = v_u_17(14, 0),
		["Parent"] = v_u_28
	})
	local v_u_31 = v_u_10.new("TextLabel", {
		["Name"] = "Counter",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -12, 0.5, 0),
		["Size"] = v_u_17(56, 20),
		["Text"] = "0/" .. v_u_3.NAME_MAX,
		["FontFace"] = v_u_14.SemiBold,
		["TextColor3"] = v_u_13.TextMuted,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_28
	})
	local v_u_32 = v_u_10.new("TextButton", {
		["Name"] = "PublicRow",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["Parent"] = nil,
		["Parent"] = v_u_26
	})
	local v_u_33 = v_u_10.new("Frame", {
		["Name"] = "Highlight",
		["BackgroundColor3"] = v_u_13.White,
		["BackgroundTransparency"] = 1,
		["Size"] = UDim2.fromScale(1, 1),
		v_u_10.Corner(10),
		["Parent"] = v_u_32
	})
	local v_u_34 = v_u_10.Glyph("globe-simplified", 24, v_u_13.Text, {
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Parent"] = v_u_32
	})
	local v_u_35 = v_u_10.new("TextLabel", {
		["Name"] = "Label",
		["Text"] = "PUBLIC",
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_14.Heavy,
		["TextColor3"] = v_u_13.Text,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_32
	})
	local v_u_36 = v_u_10.new("TextLabel", {
		["Name"] = "Desc",
		["Text"] = "",
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_14.SemiBold,
		["TextColor3"] = v_u_7,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Parent"] = v_u_32
	})
	local v_u_37 = v_u_10.Switch({
		["Width"] = 58,
		["AnchorPoint"] = nil,
		["Parent"] = nil,
		["On"] = true,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Parent"] = v_u_32
	})
	local v_u_38 = v_u_10.Button({
		["Name"] = "Create",
		["Text"] = "CREATE MATCH",
		["Style"] = "Primary",
		["Icon"] = nil,
		["Parent"] = nil,
		["Icon"] = v_u_10.Glyph("person-plus", 24, v_u_13.Text),
		["Parent"] = v_u_26
	})
	local v_u_39 = v_u_10.SectionTitle("JOIN WITH A CODE", {
		["Parent"] = v_u_24
	})
	local v_u_40 = v23("Join", v_u_24)
	local v_u_41 = v_u_10.new("TextButton", {
		["Name"] = "Slots",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["Parent"] = nil,
		["Parent"] = v_u_40
	})
	local v_u_42 = {}
	local v_u_43 = true
	for v44 = 1, v_u_3.CODE_LEN do
		local v45 = v_u_10.new("Frame", {
			["Name"] = "Slot" .. v44,
			["BackgroundColor3"] = v_u_8,
			["BackgroundTransparency"] = 0.25,
			v_u_10.Corner(9),
			["Parent"] = v_u_41
		})
		local v46 = v_u_10.Stroke(v_u_13.Stroke, 1.5, 0.86)
		v46.Parent = v45
		v_u_42[v44] = {
			["frame"] = v45,
			["stroke"] = v46,
			["label"] = v_u_10.new("TextLabel", {
				["Name"] = "Char",
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 28,
				["TextColor3"] = nil,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["FontFace"] = v_u_14.Display,
				["TextColor3"] = v_u_13.Text,
				["Parent"] = v45
			}),
			["caret"] = v_u_10.new("Frame", {
				["Name"] = "Caret",
				["AnchorPoint"] = Vector2.new(0.5, 1),
				["Position"] = UDim2.new(0.5, 0, 1, -9),
				["Size"] = v_u_17(16, 3),
				["BackgroundColor3"] = v_u_13.Accent,
				["Visible"] = false,
				v_u_10.Corner(v_u_11.Radius.Pill),
				["Parent"] = v45
			})
		}
	end
	local v_u_47 = v_u_10.new("TextBox", {
		["Name"] = "CodeBox",
		["Size"] = nil,
		["Text"] = "",
		["PlaceholderText"] = "",
		["ClearTextOnFocus"] = false,
		["TextTransparency"] = 1,
		["BackgroundTransparency"] = 1,
		["FontFace"] = nil,
		["TextSize"] = 20,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["FontFace"] = v_u_14.Display,
		["Parent"] = v_u_41
	})
	local v_u_48 = v_u_10.Button({
		["Name"] = "JoinCode",
		["Text"] = "JOIN",
		["Style"] = "Primary",
		["Parent"] = nil,
		["Parent"] = v_u_40
	})
	local v_u_49 = v_u_10.new("TextLabel", {
		["Name"] = "Error",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_14.Bold,
		["TextColor3"] = v_u_11.Lighten(v_u_13.Danger, 0.15),
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Parent"] = v_u_40
	})
	local v_u_50 = v_u_10.new("Frame", {
		["Name"] = "Right",
		["Parent"] = nil,
		["Parent"] = v20
	})
	local v_u_51 = v_u_10.SectionTitle("PUBLIC MATCHES", {
		["Parent"] = v_u_50
	})
	local v_u_52 = v_u_10.new("Frame", {
		["Name"] = "Live",
		["AnchorPoint"] = Vector2.new(1, 0),
		["Size"] = v_u_17(200, 24),
		v_u_10.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
		["Parent"] = v_u_50
	})
	local v_u_53 = v_u_10.new("Frame", {
		["Name"] = "Dot",
		["Size"] = v_u_17(8, 8),
		["BackgroundColor3"] = v_u_13.Success,
		["LayoutOrder"] = 1,
		v_u_10.Corner(v_u_11.Radius.Pill),
		["Parent"] = v_u_52
	})
	local v_u_54 = v_u_10.new("TextLabel", {
		["Name"] = "Text",
		["Text"] = "LIVE",
		["FontFace"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["FontFace"] = v_u_14.Heavy,
		["TextColor3"] = v_u_13.TextDim,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = v_u_17(0, 20),
		["Parent"] = v_u_52
	})
	local v55 = v_u_10.IconButton({
		["Name"] = "Refresh",
		["Size"] = nil,
		["Color"] = nil,
		["LayoutOrder"] = 3,
		["Parent"] = nil,
		["Size"] = v_u_17(34, 34),
		["Color"] = v_u_13.Raised,
		["Parent"] = v_u_52
	})
	local v_u_56 = v_u_10.Glyph("arrow-spin-clockwise", 20, v_u_13.Text, {
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Parent"] = v55
	})
	local v_u_57 = v_u_10.new("ScrollingFrame", {
		["Name"] = "List",
		["ScrollBarThickness"] = 5,
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["Selectable"] = false,
		v_u_10.List(Enum.FillDirection.Vertical, 8),
		v_u_10.Padding(0, 10, 4, 0),
		["Parent"] = v_u_50
	})
	local v_u_58 = v_u_10.new("Frame", {
		["Name"] = "Fade",
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, -10, 0, 40),
		["BackgroundColor3"] = v_u_13.PanelLo,
		["ZIndex"] = 4,
		["Visible"] = false,
		v_u_10.Gradient(Color3.new(1, 1, 1), Color3.new(1, 1, 1), 90, NumberSequence.new(1, 0.05)),
		["Parent"] = v_u_50
	})
	local function v_u_59() -- name: updateFade
		-- upvalues: (copy) v_u_57, (copy) v_u_58
		v_u_58.Visible = v_u_57.AbsoluteCanvasSize.Y - (v_u_57.CanvasPosition.Y + v_u_57.AbsoluteWindowSize.Y) > 2
	end
	v_u_57:GetPropertyChangedSignal("CanvasPosition"):Connect(v_u_59)
	v_u_57:GetPropertyChangedSignal("AbsoluteCanvasSize"):Connect(v_u_59)
	v_u_57:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(v_u_59)
	local v_u_60 = v_u_10.new("Frame", {
		["Name"] = "Empty",
		["Visible"] = false,
		["Parent"] = nil,
		["Parent"] = v_u_50
	})
	v_u_10.Glyph("three-people", 52, v_u_13.TextMuted, {
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 0),
		["Parent"] = v_u_60
	})
	local v_u_61 = v_u_10.new("TextLabel", {
		["Name"] = "Title",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "No public matches right now",
		["FontFace"] = nil,
		["TextSize"] = 21,
		["TextColor3"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 64),
		["Size"] = UDim2.new(1, -40, 0, 26),
		["FontFace"] = v_u_14.Heavy,
		["TextColor3"] = v_u_13.Text,
		["Parent"] = v_u_60
	})
	local v_u_62 = v_u_10.new("TextLabel", {
		["Name"] = "Sub",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "Create one and it shows up here for everyone. Private matches only take a code.",
		["TextWrapped"] = true,
		["FontFace"] = nil,
		["TextSize"] = 16,
		["TextColor3"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 94),
		["Size"] = UDim2.new(1, -60, 0, 44),
		["FontFace"] = v_u_14.SemiBold,
		["TextColor3"] = v_u_13.TextDim,
		["Parent"] = v_u_60
	})
	local v_u_63 = v_u_10.Button({
		["Name"] = "Retry",
		["Text"] = "TRY AGAIN",
		["TextSize"] = 18,
		["Style"] = "Dark",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 150),
		["Size"] = v_u_17(180, 48),
		["Parent"] = v_u_60
	})
	local v_u_64 = {}
	local v_u_65 = {}
	local v_u_66 = nil
	local function v_u_68(p67) -- name: statusLook
		-- upvalues: (copy) v_u_13, (copy) v_u_11
		if p67 == "Match" then
			return "IN MATCH", v_u_13.Warning:Lerp(v_u_13.Panel, 0.78), v_u_11.Lighten(v_u_13.Warning, 0.1)
		else
			return "LOBBY", v_u_13.Success:Lerp(v_u_13.Panel, 0.78), v_u_11.Lighten(v_u_13.Success, 0.1)
		end
	end
	local v_u_69 = nil
	local function v_u_83(p70) -- name: makeRow
		-- upvalues: (copy) v_u_10, (copy) v_u_13, (copy) v_u_57, (copy) v_u_14, (ref) v_u_7, (copy) v_u_17, (copy) v_u_11, (ref) v_u_69
		local v71 = v_u_10.new("Frame", {
			["Name"] = "Match_" .. p70.code,
			["BackgroundColor3"] = v_u_13.PanelHi,
			["BackgroundTransparency"] = 0.3,
			v_u_10.Corner(12),
			v_u_10.Stroke(v_u_13.Stroke, 1, 0.92),
			["Parent"] = v_u_57
		})
		local v72 = v_u_10.new("ImageLabel", {
			["Name"] = "Thumb",
			["ScaleType"] = Enum.ScaleType.Crop,
			["BackgroundColor3"] = v_u_13.Raised,
			["BackgroundTransparency"] = 0,
			v_u_10.Corner(8),
			["Parent"] = v71
		})
		v_u_10.Gradient(Color3.fromRGB(46, 52, 66), Color3.fromRGB(28, 31, 40), 120).Parent = v72
		local v73 = v_u_10.new("TextLabel", {
			["Name"] = "Random",
			["Size"] = nil,
			["Text"] = "?",
			["FontFace"] = nil,
			["TextSize"] = 34,
			["TextColor3"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["FontFace"] = v_u_14.Display,
			["TextColor3"] = v_u_13.TextMuted,
			["Parent"] = v72
		})
		local v74 = v_u_10.new("TextLabel", {
			["Name"] = "MatchName",
			["Text"] = "",
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_14.Heavy,
			["TextColor3"] = v_u_13.Text,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v71
		})
		local v75 = v_u_10.new("TextLabel", {
			["Name"] = "Sub",
			["Text"] = "",
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_14.SemiBold,
			["TextColor3"] = v_u_7,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v71
		})
		local v76 = v_u_10.new("Frame", {
			["Name"] = "Players",
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Size"] = v_u_17(96, 22),
			v_u_10.List(Enum.FillDirection.Horizontal, 4, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
			["Parent"] = v71
		})
		local v77 = v_u_10.Glyph("person", 17, v_u_13.TextDim, {
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Parent"] = v76
		})
		local v78 = v_u_10.new("TextLabel", {
			["Name"] = "Count",
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 18,
			["TextColor3"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["FontFace"] = v_u_14.Heavy,
			["TextColor3"] = v_u_13.Text,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = v_u_17(0, 22),
			["Parent"] = v76
		})
		local v79 = v_u_10.new("Frame", {
			["Name"] = "Status",
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = v_u_17(0, 22),
			v_u_10.Corner(v_u_11.Radius.Pill),
			v_u_10.Padding(0, 9, 0, 9),
			["Parent"] = v71
		})
		local v80 = v_u_10.new("TextLabel", {
			["Name"] = "Text",
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 13,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_14.Heavy,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromScale(0, 1),
			["Parent"] = v79
		})
		local v81 = v_u_10.Button({
			["Name"] = "Join",
			["Text"] = "JOIN",
			["TextSize"] = 19,
			["Style"] = "Primary",
			["AnchorPoint"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Parent"] = v71
		})
		local v_u_82 = {
			["frame"] = nil,
			["thumb"] = nil,
			["random"] = nil,
			["name"] = nil,
			["sub"] = nil,
			["count"] = nil,
			["people"] = nil,
			["pill"] = nil,
			["pillText"] = nil,
			["button"] = nil,
			["code"] = nil,
			["full"] = false,
			["frame"] = v71,
			["thumb"] = v72,
			["random"] = v73,
			["name"] = v74,
			["sub"] = v75,
			["count"] = v78,
			["people"] = v77,
			["pill"] = v79,
			["pillText"] = v80,
			["button"] = v81,
			["code"] = p70.code
		}
		v81.Activated:Connect(function()
			-- upvalues: (ref) v_u_69, (ref) v_u_82
			v_u_69(v_u_82.code, v_u_82)
		end)
		return v_u_82
	end
	local function v_u_108(p84, p85) -- name: layoutRow
		-- upvalues: (ref) v_u_18, (copy) v_u_17
		local v86 = v_u_18.rowH
		p84.frame.Size = UDim2.new(1, -4, 0, v86)
		local v87 = v_u_18.thumbW
		local v88 = v87 * 9 / 16
		local v89 = math.floor(v88)
		local v90 = p84.thumb
		local v91 = v_u_17
		local v92 = (v86 - v89) / 2
		v90.Position = v91(10, (math.floor(v92)))
		p84.thumb.Size = v_u_17(v87, v89)
		local v93 = 10 + v87 + 14
		local v94 = v_u_18.rowBtn + 16 + 96
		local v95 = p84.name
		local v96 = v_u_17
		local v97 = v86 / 2
		v95.Position = v96(v93, math.floor(v97) - v_u_18.name - 4)
		local v98 = p84.name
		local v99 = v_u_17
		local v100 = p85 - v93 - v94
		v98.Size = v99(math.max(80, v100), v_u_18.name + 4)
		p84.name.TextSize = v_u_18.name
		local v101 = p84.sub
		local v102 = v_u_17
		local v103 = v86 / 2
		v101.Position = v102(v93, math.floor(v103) + 3)
		local v104 = p84.sub
		local v105 = v_u_17
		local v106 = p85 - v93 - v94
		v104.Size = v105(math.max(80, v106), v_u_18.sub + 4)
		p84.sub.TextSize = v_u_18.sub
		p84.button.Instance.Position = UDim2.new(1, -12, 0.5, 0)
		p84.button.Instance.Size = v_u_17(v_u_18.rowBtn, v_u_18.rowBtnH)
		local v107 = -(12 + v_u_18.rowBtn + 16)
		p84.count.Parent.Position = UDim2.new(1, v107, 0.5, -12)
		p84.pill.Position = UDim2.new(1, v107, 0.5, 14)
	end
	local function v_u_118(p109, p110, p111) -- name: paintRow
		-- upvalues: (copy) v_u_68, (ref) v_u_66
		p109.name.Text = p110.name
		local v112 = p110.host
		local v113 = (type(v112) ~= "string" or p110.host == "") and "" or "  \194\183  " .. p110.host
		p109.sub.Text = string.upper(p110.mapName or "Random") .. v113
		local v114 = p110.thumb
		if type(v114) == "string" and p110.thumb ~= "" then
			p109.thumb.Image = p110.thumb
			p109.random.Visible = false
		else
			p109.thumb.Image = ""
			p109.random.Visible = true
		end
		p109.count.Text = string.format("%d/%d", p110.players, p110.max)
		local v115, v116, v117 = v_u_68(p110.status)
		p109.pillText.Text = v115
		p109.pillText.TextColor3 = v117
		p109.pill.BackgroundColor3 = v116
		p109.full = p110.players >= p110.max
		p109.frame.LayoutOrder = p111
		if v_u_66 == p110.code then
			p109.button:SetText("JOINING...")
			p109.button:SetEnabled(false)
			return
		elseif p109.full then
			p109.button:SetText("FULL")
			p109.button:SetEnabled(false)
		else
			p109.button:SetText("JOIN")
			p109.button:SetEnabled(v_u_66 == nil)
		end
	end
	local v_u_119 = 600
	local v_u_120 = "loading"
	local v_u_121 = {}
	local function v_u_142() -- name: showSkeletons
		-- upvalues: (copy) v_u_65, (copy) v_u_10, (ref) v_u_18, (copy) v_u_13, (copy) v_u_57, (copy) v_u_17, (copy) v_u_11
		for _, v122 in v_u_65 do
			v122:Destroy()
		end
		table.clear(v_u_65)
		for v123 = 1, 3 do
			local v124 = v_u_10.new("Frame", {
				["Name"] = "Skeleton" .. v123,
				["Size"] = UDim2.new(1, -4, 0, v_u_18.rowH),
				["BackgroundColor3"] = v_u_13.PanelHi,
				["BackgroundTransparency"] = 0.5,
				["LayoutOrder"] = v123,
				v_u_10.Corner(12),
				["Parent"] = v_u_57
			})
			local v125 = v_u_18.thumbW * 9 / 16
			local v126 = math.floor(v125)
			local v127 = v_u_10.new
			local v128 = {}
			local v129 = v_u_17
			local v130 = (v_u_18.rowH - v126) / 2
			v128.Position = v129(10, (math.floor(v130)))
			v128.Size = v_u_17(v_u_18.thumbW, v126)
			v128.BackgroundColor3 = v_u_13.Raised
			v128.BackgroundTransparency = 0.3
			__set_list(v128, 1, {(v_u_10.Corner(8))})
			v128.Parent = v124
			v127("Frame", v128)
			local v131 = v_u_10.new
			local v132 = {}
			local v133 = v_u_17
			local v134 = v_u_18.thumbW + 24
			local v135 = v_u_18.rowH / 2
			v132.Position = v133(v134, math.floor(v135) - 20)
			v132.Size = v_u_17(200, 14)
			v132.BackgroundColor3 = v_u_13.Raised
			v132.BackgroundTransparency = 0.3
			__set_list(v132, 1, {(v_u_10.Corner(v_u_11.Radius.Pill))})
			v132.Parent = v124
			v131("Frame", v132)
			local v136 = v_u_10.new
			local v137 = {}
			local v138 = v_u_17
			local v139 = v_u_18.thumbW + 24
			local v140 = v_u_18.rowH / 2
			v137.Position = v138(v139, math.floor(v140) + 6)
			v137.Size = v_u_17(130, 10)
			v137.BackgroundColor3 = v_u_13.Raised
			v137.BackgroundTransparency = 0.5
			__set_list(v137, 1, {(v_u_10.Corner(v_u_11.Radius.Pill))})
			v137.Parent = v124
			v136("Frame", v137)
			v_u_10.Tween(v124, TweenInfo.new(0.8, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true, v123 * 0.12), {
				["BackgroundTransparency"] = 0.72
			})
			local v141 = v_u_65
			table.insert(v141, v124)
		end
	end
	local function v_u_163(p143, p144) -- name: renderList
		-- upvalues: (ref) v_u_121, (copy) v_u_65, (copy) v_u_64, (copy) v_u_83, (copy) v_u_108, (ref) v_u_119, (copy) v_u_118, (copy) v_u_10, (copy) v_u_51, (copy) v_u_60, (ref) v_u_120, (copy) v_u_61, (copy) v_u_62, (copy) v_u_63, (copy) v_u_54, (copy) v_u_53, (copy) v_u_13, (copy) v_u_59
		v_u_121 = p143
		for _, v145 in v_u_65 do
			v145:Destroy()
		end
		table.clear(v_u_65)
		local v146 = {}
		for v147, v148 in p143 do
			if type(v148) ~= "table" then
				continue
			end
			local v149 = v148.code
			if type(v149) ~= "string" then
				continue
			end
			v146[v148.code] = true
			local v150 = v_u_64[v148.code]
			local v151
			if v150 then
				v151 = false
			else
				v150 = v_u_83(v148)
				v_u_64[v148.code] = v150
				v151 = true
			end
			v_u_108(v150, v_u_119)
			v_u_118(v150, v148, v147)
			if not (v151 and p144) then
				continue
			end
			local v152 = v_u_10.Enter
			local v153 = v150.frame
			local v154 = Vector2.new(0, 12)
			local v155 = v147 * 0.035
			v152(v153, v154, math.min(v155, 0.25), UDim2.new())
		end
		for v156, v157 in v_u_64 do
			if v146[v156] then
				continue
			end
			v157.frame:Destroy()
			v_u_64[v156] = nil
		end
		local v158 = 0
		for _ in v_u_64 do
			v158 = v158 + 1
		end
		v_u_51.Text.Text = v158 <= 0 and "PUBLIC MATCHES" or string.format("PUBLIC MATCHES  \194\183  %d", v158)
		local v159 = v_u_60
		local v160
		if v158 == 0 then
			v160 = v_u_120 ~= "loading"
		else
			v160 = false
		end
		v159.Visible = v160
		v_u_61.Text = v_u_120 == "error" and "Couldn\'t load public matches" or "No public matches right now"
		v_u_62.Text = v_u_120 == "error" and "Check your connection and try again. Joining with a code still works." or "Create one and it shows up here for everyone. Private matches only take a code."
		v_u_63.Instance.Visible = v_u_120 == "error"
		v_u_54.Text = v_u_120 == "error" and "OFFLINE" or "LIVE"
		local v161 = v_u_53
		local v162
		if v_u_120 == "error" then
			v162 = v_u_13.TextMuted
		else
			v162 = v_u_13.Success
		end
		v161.BackgroundColor3 = v162
		task.defer(v_u_59)
	end
	local v_u_164 = false
	local v_u_165 = 0
	local function v_u_171(p166) -- name: refresh
		-- upvalues: (ref) v_u_164, (ref) v_u_165, (copy) v_u_56, (copy) v_u_10, (copy) v_u_15, (copy) v_u_19, (ref) v_u_120, (copy) v_u_163, (copy) v_u_64, (ref) v_u_121
		if v_u_164 or not p166 and os.clock() - v_u_165 < 2 then
			return
		else
			v_u_164 = true
			v_u_165 = os.clock()
			os.clock()
			v_u_56.Rotation = 0
			v_u_10.Tween(v_u_56, TweenInfo.new(0.5, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
				["Rotation"] = 360
			})
			local v167, v168 = v_u_15.Action("List")
			v_u_164 = false
			if v_u_19.IsOpen then
				if v167 and type(v168) == "table" then
					local v169 = v168.list
					if type(v169) == "table" then
						local v170 = v_u_120 ~= "ok"
						v_u_120 = "ok"
						v_u_163(v168.list, v170)
						return
					end
				end
				v_u_120 = next(v_u_64) and "ok" or "error"
				v_u_163(v_u_121, false)
			end
		end
	end
	v55.Activated:Connect(function()
		-- upvalues: (copy) v_u_171
		v_u_171(true)
	end)
	v_u_63.Activated:Connect(function()
		-- upvalues: (ref) v_u_120, (copy) v_u_60, (copy) v_u_142, (copy) v_u_171
		v_u_120 = "loading"
		v_u_60.Visible = false
		v_u_142()
		v_u_171(true)
	end)
	local v_u_172 = false
	local v_u_173 = 0
	local function v_u_186() -- name: paintSlots
		-- upvalues: (copy) v_u_47, (copy) v_u_42, (ref) v_u_172, (ref) v_u_3, (copy) v_u_13, (copy) v_u_48, (ref) v_u_66
		local v174 = v_u_47.Text
		local v175 = #v174
		for v176, v177 in v_u_42 do
			local v178 = string.sub(v174, v176, v176)
			v177.label.Text = v178
			local v179 = v_u_172
			if v179 then
				if v176 == v175 + 1 then
					v179 = true
				elseif v175 == v_u_3.CODE_LEN then
					v179 = v176 == v175
				else
					v179 = false
				end
			end
			local v180 = v177.caret
			local v181 = v_u_172
			if v181 then
				v181 = v176 == v175 + 1
			end
			v180.Visible = v181
			local v182 = v177.stroke
			local v183
			if v179 then
				v183 = v_u_13.Accent
			elseif v178 == "" then
				v183 = v_u_13.Stroke
			else
				v183 = v_u_13.Stroke
			end
			v182.Color = v183
			v177.stroke.Transparency = v179 and 0.1 or (v178 == "" and 0.86 or 0.7)
		end
		local v184 = v_u_48
		local v185
		if v175 == v_u_3.CODE_LEN then
			v185 = v_u_66 == nil
		else
			v185 = false
		end
		v184:SetEnabled(v185)
	end
	local v_u_187 = false
	v_u_47:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (ref) v_u_187, (ref) v_u_3, (copy) v_u_47, (copy) v_u_49, (ref) v_u_7, (copy) v_u_42, (copy) v_u_10, (copy) v_u_186
		if not v_u_187 then
			local v188 = v_u_3.CleanCode(v_u_47.Text)
			if v188 ~= v_u_47.Text then
				v_u_187 = true
				v_u_47.Text = v188
				v_u_47.CursorPosition = #v188 + 1
				v_u_187 = false
			end
			if v_u_49.Text ~= "Ask the host for their code" then
				v_u_49.Text = ""
				if v_u_49.Text == "" or v_u_49.Text == "Ask the host for their code" then
					v_u_49.Text = "Ask the host for their code"
					v_u_49.TextColor3 = v_u_7
				end
			end
			local v189 = #v188
			local v190 = v_u_42[v189]
			if v190 and v189 > 0 then
				v_u_10.Bump(v190.label, 0.18)
			end
			v_u_186()
		end
	end)
	v_u_47.Focused:Connect(function()
		-- upvalues: (ref) v_u_172, (copy) v_u_186
		v_u_172 = true
		v_u_186()
	end)
	v_u_47.FocusLost:Connect(function(p191)
		-- upvalues: (ref) v_u_172, (copy) v_u_186, (copy) v_u_47, (ref) v_u_3, (ref) v_u_69
		v_u_172 = false
		v_u_186()
		if p191 and #v_u_47.Text == v_u_3.CODE_LEN then
			v_u_69(v_u_47.Text, nil)
		end
	end)
	v_u_10.Every(v_u_19.Root, 0.5, function()
		-- upvalues: (ref) v_u_172, (copy) v_u_47, (copy) v_u_42
		local v192 = v_u_172 and v_u_42[#v_u_47.Text + 1]
		if v192 then
			v192.caret.BackgroundTransparency = v192.caret.BackgroundTransparency < 0.5 and 1 or 0
		end
	end)
	local function v_u_196(p193) -- name: showCodeError
		-- upvalues: (ref) v_u_173, (copy) v_u_49, (copy) v_u_11, (copy) v_u_13, (copy) v_u_10, (copy) v_u_41, (copy) p_u_9, (copy) v_u_42, (copy) v_u_186
		v_u_173 = v_u_173 + 1
		local v_u_194 = v_u_173
		v_u_49.Text = p193
		v_u_49.TextColor3 = v_u_11.Lighten(v_u_13.Danger, 0.15)
		v_u_10.Shake(v_u_41, 8)
		p_u_9.Sounds.Play("Error")
		for _, v195 in v_u_42 do
			v195.stroke.Color = v_u_13.Danger
			v195.stroke.Transparency = 0.15
		end
		task.delay(1.2, function()
			-- upvalues: (copy) v_u_194, (ref) v_u_173, (ref) v_u_186
			if v_u_194 == v_u_173 then
				v_u_186()
			end
		end)
	end
	local v_u_197 = false
	local function v_u_203() -- name: paintBusy
		-- upvalues: (copy) v_u_38, (ref) v_u_197, (ref) v_u_66, (copy) v_u_48, (copy) v_u_47, (copy) v_u_186, (copy) v_u_64, (ref) v_u_121, (copy) v_u_118
		v_u_38:SetText(v_u_197 and "CREATING..." or "CREATE MATCH")
		local v198 = v_u_38
		local v199 = not v_u_197
		if v199 then
			v199 = v_u_66 == nil
		end
		v198:SetEnabled(v199)
		v_u_48:SetText((v_u_66 == nil or v_u_66 ~= v_u_47.Text) and "JOIN" or "...")
		v_u_186()
		for v200, v201 in v_u_64 do
			for _, v202 in v_u_121 do
				if v202.code ~= v200 then
					continue
				end
				v_u_118(v201, v202, v201.frame.LayoutOrder)
			end
		end
	end
	v_u_69 = function(p204, p205)
		-- upvalues: (ref) v_u_66, (ref) v_u_197, (ref) v_u_3, (copy) v_u_196, (copy) v_u_203, (copy) v_u_15, (copy) p_u_9, (copy) v_u_10, (copy) v_u_171
		if v_u_66 or v_u_197 then
			return
		else
			local v206 = v_u_3.ValidCode(p204)
			if v206 then
				v_u_66 = v206
				v_u_203()
				local v207, v208 = v_u_15.Action("Join", v206)
				v_u_66 = nil
				v_u_203()
				if v207 then
					p_u_9.Sounds.Play("Queue_Join")
					p_u_9.MenuManager.Close("CustomMatches")
					return
				else
					local v209 = tostring(v208 or "Couldn\'t join that match")
					if p205 then
						p_u_9.Toast(v209, "error")
						v_u_10.Shake(p205.frame, 6)
						v_u_171(true)
					else
						v_u_196(v209)
					end
				end
			else
				v_u_196(string.format("Codes have %d letters and numbers", v_u_3.CODE_LEN))
				return
			end
		end
	end
	v_u_48.Activated:Connect(function()
		-- upvalues: (ref) v_u_69, (copy) v_u_47
		v_u_69(v_u_47.Text, nil)
	end)
	v_u_41.Activated:Connect(function()
		-- upvalues: (copy) v_u_47
		v_u_47:CaptureFocus()
	end)
	local function v_u_212() -- name: create
		-- upvalues: (ref) v_u_197, (ref) v_u_66, (copy) v_u_203, (copy) v_u_15, (copy) v_u_30, (ref) v_u_43, (copy) p_u_9, (copy) v_u_10, (copy) v_u_38, (copy) v_u_29, (copy) v_u_13
		if v_u_197 or v_u_66 then
			return
		else
			v_u_197 = true
			v_u_203()
			local v210, v211 = v_u_15.Action("Create", {
				["name"] = v_u_30.Text,
				["public"] = v_u_43
			})
			v_u_197 = false
			v_u_203()
			if v210 then
				p_u_9.Sounds.Play("Queue_Join")
				p_u_9.MenuManager.Close("CustomMatches")
			else
				p_u_9.Toast(tostring(v211 or "Couldn\'t create the match"), "error")
				v_u_10.Shake(v_u_38.Instance, 6)
				if type(v211) == "string" and (string.find(v211, "name", 1, true) or string.find(v211, "Name", 1, true)) then
					v_u_29.Color = v_u_13.Danger
					v_u_29.Transparency = 0.15
					task.delay(1.4, function()
						-- upvalues: (ref) v_u_29, (ref) v_u_13
						v_u_29.Color = v_u_13.Stroke
						v_u_29.Transparency = 0.88
					end)
				end
			end
		end
	end
	v_u_38.Activated:Connect(v_u_212)
	v_u_32.Activated:Connect(function()
		-- upvalues: (ref) v_u_43, (copy) p_u_9, (copy) v_u_37, (copy) v_u_35, (copy) v_u_36, (copy) v_u_34
		v_u_43 = not v_u_43
		local v213 = {
			["pitch"] = v_u_43 and 1.08 or 0.94
		}
		p_u_9.Sounds.Play("Click", v213)
		v_u_37:Set(v_u_43, nil)
		v_u_35.Text = v_u_43 and "PUBLIC" or "PRIVATE"
		v_u_36.Text = v_u_43 and "Anyone in a lobby can find and join it" or "Only people with your code can join"
		v_u_34.Text = v_u_43 and "globe-simplified" or "lock-closed"
	end)
	v_u_32.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_10, (copy) v_u_33, (copy) v_u_11
		if not v_u_10.Touch then
			v_u_10.Tween(v_u_33, v_u_11.Tween.Fast, {
				["BackgroundTransparency"] = 0.955
			})
		end
	end)
	v_u_32.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_10, (copy) v_u_33, (copy) v_u_11
		v_u_10.Tween(v_u_33, v_u_11.Tween.Fast, {
			["BackgroundTransparency"] = 1
		})
	end)
	local function v_u_220() -- name: capName
		-- upvalues: (copy) v_u_30, (ref) v_u_3, (copy) v_u_31, (copy) v_u_13
		local v214 = v_u_30.Text
		local v215 = utf8.len(v214) or #v214
		if v_u_3.NAME_MAX < v215 then
			local v216 = v_u_30
			local v217 = (utf8.offset(v214, v_u_3.NAME_MAX + 1) or #v214 + 1) - 1
			v216.Text = string.sub(v214, 1, v217)
		else
			v_u_31.Text = string.format("%d/%d", v215, v_u_3.NAME_MAX)
			local v218 = v_u_31
			local v219
			if v_u_3.NAME_MAX <= v215 then
				v219 = v_u_13.Warning
			else
				v219 = v_u_13.TextMuted
			end
			v218.TextColor3 = v219
		end
	end
	v_u_30:GetPropertyChangedSignal("Text"):Connect(v_u_220)
	v_u_30.Focused:Connect(function()
		-- upvalues: (copy) v_u_10, (copy) v_u_29, (copy) v_u_11, (copy) v_u_13
		v_u_10.Tween(v_u_29, v_u_11.Tween.Fast, {
			["Color"] = nil,
			["Transparency"] = 0.2,
			["Color"] = v_u_13.Accent
		})
	end)
	v_u_30.FocusLost:Connect(function(p221)
		-- upvalues: (copy) v_u_10, (copy) v_u_29, (copy) v_u_11, (copy) v_u_13, (copy) v_u_212
		v_u_10.Tween(v_u_29, v_u_11.Tween.Fast, {
			["Color"] = nil,
			["Transparency"] = 0.88,
			["Color"] = v_u_13.Stroke
		})
		if p221 then
			v_u_212()
		end
	end)
	local function v_u_275() -- name: layout
		-- upvalues: (ref) v_u_18, (copy) v_u_10, (ref) v_u_6, (ref) v_u_5, (copy) v_u_19, (copy) v_u_17, (copy) v_u_24, (copy) v_u_50, (copy) v_u_25, (copy) v_u_27, (copy) v_u_28, (copy) v_u_30, (copy) v_u_32, (copy) v_u_34, (copy) v_u_35, (copy) v_u_36, (copy) v_u_37, (copy) v_u_38, (copy) v_u_26, (copy) v_u_39, (ref) v_u_3, (copy) v_u_41, (copy) v_u_42, (copy) v_u_48, (copy) v_u_49, (copy) v_u_40, (copy) v_u_51, (copy) v_u_52, (copy) v_u_57, (ref) v_u_119, (copy) v_u_64, (copy) v_u_108, (copy) v_u_65, (copy) v_u_60
		local v222
		if v_u_10.Compact then
			v222 = v_u_6
		else
			v222 = v_u_5
		end
		v_u_18 = v222
		local v223 = v_u_10.CanvasSize()
		local v224 = v_u_10.TopInset()
		if v_u_10.Compact then
			local v225 = v_u_19.Holder
			local v226 = v_u_17
			local v227 = v_u_18.W
			local v228 = v223.X - 24
			local v229 = math.min(v227, v228)
			local v230 = math.floor(v229)
			local v231 = v_u_18.H
			local v232 = v223.Y - v224 - 12
			local v233 = math.min(v231, v232)
			v225.Size = v226(v230, (math.floor(v233)))
		else
			local v234 = v_u_19.Holder
			local v235 = v_u_17
			local v236 = v223.X - 240
			local v237 = v_u_18.W
			local v238 = math.clamp(v236, v237, 1240)
			local v239 = math.floor(v238)
			local v240 = v223.Y - v224 - 110
			local v241 = math.clamp(v240, 620, 680)
			v234.Size = v235(v239, (math.floor(v241)))
		end
		v_u_19.Subtitle.TextSize = v_u_10.Compact and 15 or 17
		local v242 = v_u_19.Holder.Size.X.Offset - 44
		local v243 = v_u_19.Holder.Size.Y.Offset - 80 - 32
		local v244 = v_u_18.left
		v_u_24.Size = v_u_17(v244, v243)
		v_u_50.Position = v_u_17(v244 + v_u_18.gap, 0)
		local v245 = v242 - v244 - v_u_18.gap
		v_u_50.Size = v_u_17(v245, v243)
		local v246 = v_u_18.pad
		local v247 = v244 - v246 * 2
		v_u_25.Size = UDim2.new(1, 0, 0, v_u_18.sectionH)
		v_u_25.Position = v_u_17(0, 0)
		v_u_27.Visible = v_u_18.label
		local v248
		if v_u_18.label then
			v_u_27.Position = v_u_17(v246 + 2, v246)
			v_u_27.Size = v_u_17(v247, 16)
			v248 = v246 + 22
		else
			v248 = v246
		end
		v_u_28.Position = v_u_17(v246, v248)
		v_u_28.Size = v_u_17(v247, v_u_18.box)
		v_u_30.Size = UDim2.new(1, -84, 1, 0)
		v_u_30.TextSize = v_u_18.text
		local v249 = v248 + (v_u_18.box + 10)
		v_u_32.Position = v_u_17(v246 - 6, v249)
		v_u_32.Size = v_u_17(v247 + 12, v_u_18.switchRow)
		v_u_34.Position = UDim2.new(0, 8, 0.5, 0)
		local v250 = v_u_35
		local v251 = v_u_17
		local v252 = v_u_18.switchRow / 2
		v250.Position = v251(42, math.floor(v252) - v_u_18.text - 1)
		v_u_35.Size = v_u_17(v247 - 110, v_u_18.text + 2)
		v_u_35.TextSize = v_u_18.text
		local v253 = v_u_36
		local v254 = v_u_17
		local v255 = v_u_18.switchRow / 2
		v253.Position = v254(42, math.floor(v255) + 2)
		v_u_36.Size = v_u_17(v247 - 110, v_u_18.desc + 2)
		v_u_36.TextSize = v_u_18.desc
		v_u_37.Instance.Position = UDim2.new(1, -8, 0.5, 0)
		local v256 = v249 + (v_u_18.switchRow + 10)
		v_u_38.Instance.Position = v_u_17(v246, v256)
		v_u_38.Instance.Size = v_u_17(v247, v_u_18.button)
		v_u_38.Label.TextSize = v_u_10.Compact and 22 or 24
		local v257 = v256 + (v_u_18.button + v246)
		local v258 = v_u_18.sectionH + v_u_18.sectionGap
		v_u_26.Position = v_u_17(0, v258)
		v_u_26.Size = v_u_17(v244, v257)
		local v259 = v258 + v257 + v_u_18.cardGap
		v_u_39.Position = v_u_17(0, v259)
		v_u_39.Size = UDim2.new(1, 0, 0, v_u_18.sectionH)
		local v260 = v259 + v_u_18.sectionH + v_u_18.sectionGap
		local v261 = v247 - v_u_18.joinW - 12
		local v262 = v_u_3.CODE_LEN // 2
		local v263 = (v261 - 5 * (v_u_3.CODE_LEN - 2) - 14) / v_u_3.CODE_LEN
		local v264 = math.floor(v263)
		v_u_41.Position = v_u_17(v246, v246)
		v_u_41.Size = v_u_17(v264 * v_u_3.CODE_LEN + 5 * (v_u_3.CODE_LEN - 2) + 14, v_u_18.slotH)
		for v265, v266 in v_u_42 do
			local v267 = (v265 - 1) * (v264 + 5) + (v262 < v265 and 9 or 0)
			v266.frame.Position = v_u_17(v267, 0)
			v266.frame.Size = v_u_17(v264, v_u_18.slotH)
			v266.label.TextSize = v_u_10.Compact and 26 or 28
		end
		v_u_48.Instance.Position = UDim2.new(1, -v246, 0, v246)
		v_u_48.Instance.AnchorPoint = Vector2.new(1, 0)
		v_u_48.Instance.Size = v_u_17(v_u_18.joinW, v_u_18.slotH)
		v_u_48.Label.TextSize = 20
		v_u_49.Position = v_u_17(v246 + 2, v246 + v_u_18.slotH + 7)
		v_u_49.Size = v_u_17(v247, v_u_18.errH)
		v_u_40.Position = v_u_17(0, v260)
		v_u_40.Size = v_u_17(v244, v246 + v_u_18.slotH + 7 + v_u_18.errH + 10)
		v_u_24.CanvasSize = v_u_17(0, v260 + v_u_40.Size.Y.Offset + 2)
		v_u_51.Size = UDim2.new(1, -210, 0, v_u_18.sectionH)
		v_u_52.Position = UDim2.new(1, -4, 0, v_u_10.Compact and 0 or -5)
		v_u_57.Position = v_u_17(0, v_u_18.sectionH + v_u_18.sectionGap)
		v_u_57.Size = UDim2.new(1, 0, 1, -(v_u_18.sectionH + v_u_18.sectionGap))
		v_u_57:FindFirstChildOfClass("UIListLayout").Padding = UDim.new(0, v_u_18.rowGap)
		v_u_119 = v245 - 14
		for _, v268 in v_u_64 do
			v_u_108(v268, v_u_119)
		end
		for _, v269 in v_u_65 do
			v269.Size = UDim2.new(1, -4, 0, v_u_18.rowH)
		end
		local v270 = v_u_60
		local v271 = v_u_17
		local v272 = v_u_18.sectionH + v_u_18.sectionGap
		local v273 = v243 * 0.18
		local v274 = math.floor(v273)
		v270.Position = v271(0, v272 + math.max(24, v274))
		v_u_60.Size = UDim2.new(1, 0, 0, 220)
		v_u_19.Refit()
	end
	v_u_10.LayoutChanged:Connect(function()
		-- upvalues: (copy) v_u_19, (copy) v_u_275
		if v_u_19.IsOpen then
			v_u_275()
		end
	end)
	v_u_10.ScaleChanged:Connect(function()
		-- upvalues: (copy) v_u_19, (copy) v_u_275
		if v_u_19.IsOpen then
			v_u_275()
		end
	end)
	v_u_10.Every(v_u_19.Root, 0.9, function()
		-- upvalues: (copy) v_u_19, (copy) v_u_10, (copy) v_u_53
		if v_u_19.IsOpen then
			v_u_10.Tween(v_u_53, TweenInfo.new(0.45, Enum.EasingStyle.Sine), {
				["BackgroundTransparency"] = v_u_53.BackgroundTransparency < 0.3 and 0.6 or 0
			})
		end
	end)
	local v_u_276 = 0
	local v280 = {
		["open"] = function() -- name: open
			-- upvalues: (copy) p_u_9, (copy) v_u_275, (copy) v_u_30, (ref) v_u_3, (copy) v_u_16, (copy) v_u_49, (ref) v_u_7, (copy) v_u_37, (ref) v_u_43, (copy) v_u_35, (copy) v_u_36, (copy) v_u_34, (copy) v_u_220, (copy) v_u_203, (ref) v_u_120, (copy) v_u_60, (copy) v_u_142, (copy) v_u_19, (copy) v_u_57, (copy) v_u_10, (copy) v_u_24, (copy) v_u_50, (copy) v_u_17, (ref) v_u_18, (ref) v_u_276, (copy) v_u_171, (ref) v_u_2, (copy) v_u_38
			p_u_9.SetHudHidden("CustomMatches", true)
			v_u_275()
			v_u_30.PlaceholderText = v_u_3.DefaultName(v_u_16.DisplayName)
			v_u_49.Text = ""
			if v_u_49.Text == "" or v_u_49.Text == "Ask the host for their code" then
				v_u_49.Text = "Ask the host for their code"
				v_u_49.TextColor3 = v_u_7
			end
			v_u_37:Set(v_u_43, true)
			v_u_35.Text = v_u_43 and "PUBLIC" or "PRIVATE"
			v_u_36.Text = v_u_43 and "Anyone in a lobby can find and join it" or "Only people with your code can join"
			v_u_34.Text = v_u_43 and "globe-simplified" or "lock-closed"
			v_u_220()
			v_u_203()
			if v_u_120 ~= "ok" then
				v_u_120 = "loading"
				v_u_60.Visible = false
				v_u_142()
			end
			v_u_19:Open()
			v_u_57.CanvasPosition = Vector2.zero
			v_u_10.SlideIn(v_u_24, Vector2.new(-18, 0), TweenInfo.new(0.38, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), UDim2.new())
			v_u_10.SlideIn(v_u_50, Vector2.new(18, 0), TweenInfo.new(0.38, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), v_u_17(v_u_18.left + v_u_18.gap, 0))
			v_u_276 = v_u_276 + 1
			local v_u_277 = v_u_276
			task.spawn(function()
				-- upvalues: (copy) v_u_277, (ref) v_u_276, (ref) v_u_19, (ref) v_u_171, (ref) v_u_3
				while v_u_277 == v_u_276 and v_u_19.IsOpen do
					v_u_171(false)
					task.wait(v_u_3.LIST_REFRESH)
				end
			end)
			if v_u_10.Gamepad then
				v_u_2.SelectedObject = v_u_38.Instance
			end
		end,
		["close"] = function(p278) -- name: close
			-- upvalues: (copy) p_u_9, (ref) v_u_276, (ref) v_u_172, (copy) v_u_47, (copy) v_u_30, (ref) v_u_2, (copy) v_u_19
			p_u_9.SetHudHidden("CustomMatches", false)
			v_u_276 = v_u_276 + 1
			if v_u_172 then
				v_u_47:ReleaseFocus()
			end
			v_u_30:ReleaseFocus()
			local v279 = v_u_2.SelectedObject
			if v279 and v279:IsDescendantOf(v_u_19.Root) then
				v_u_2.SelectedObject = nil
			end
			v_u_19:Close(p278)
		end
	}
	p_u_9.MenuManager.Register("CustomMatches", v280)
	v12.PlayerStateChanged:Connect(function(p281)
		-- upvalues: (copy) p_u_9
		if p281 == "Match" and p_u_9.MenuManager.IsOpen("CustomMatches") then
			p_u_9.MenuManager.Close("CustomMatches", true)
		end
	end)
	function p_u_9.Debug.customMatches(p282, p283)
		-- upvalues: (copy) p_u_9, (ref) v_u_276, (ref) v_u_120, (copy) v_u_163, (copy) v_u_64, (copy) v_u_60, (copy) v_u_142, (copy) v_u_47, (copy) v_u_196, (ref) v_u_43, (copy) v_u_37, (copy) v_u_35, (copy) v_u_36, (copy) v_u_34, (copy) v_u_30, (copy) v_u_212, (ref) v_u_69, (copy) v_u_171, (copy) v_u_19, (copy) v_u_49, (ref) v_u_197, (ref) v_u_66
		if p282 == "open" then
			p_u_9.MenuManager.Open("CustomMatches")
		elseif p282 == "list" and type(p283) == "table" then
			v_u_276 = v_u_276 + 1
			v_u_120 = "ok"
			v_u_163(p283, true)
		elseif p282 == "error" then
			v_u_276 = v_u_276 + 1
			for v284, v285 in v_u_64 do
				v285.frame:Destroy()
				v_u_64[v284] = nil
			end
			v_u_120 = "error"
			v_u_163({}, false)
		elseif p282 == "loading" then
			v_u_276 = v_u_276 + 1
			for v286, v287 in v_u_64 do
				v287.frame:Destroy()
				v_u_64[v286] = nil
			end
			v_u_120 = "loading"
			v_u_60.Visible = false
			v_u_142()
		elseif p282 == "code" then
			v_u_47.Text = tostring(p283 or "")
		elseif p282 == "codeError" then
			v_u_196((tostring(p283 or "No custom match has that code")))
		elseif p282 == "focusCode" then
			v_u_47:CaptureFocus()
		elseif p282 == "public" then
			v_u_43 = p283 ~= false
			v_u_37:Set(v_u_43, nil)
			v_u_35.Text = v_u_43 and "PUBLIC" or "PRIVATE"
			v_u_36.Text = v_u_43 and "Anyone in a lobby can find and join it" or "Only people with your code can join"
			v_u_34.Text = v_u_43 and "globe-simplified" or "lock-closed"
		elseif p282 == "name" then
			v_u_30.Text = tostring(p283 or "")
		elseif p282 == "create" then
			task.spawn(v_u_212)
		elseif p282 == "join" then
			task.spawn(v_u_69, v_u_47.Text, nil)
		elseif p282 == "refresh" then
			task.spawn(v_u_171, true)
		end
		local v288 = 0
		for _ in v_u_64 do
			v288 = v288 + 1
		end
		return {
			["open"] = v_u_19.IsOpen,
			["rows"] = v288,
			["listState"] = v_u_120,
			["code"] = v_u_47.Text,
			["codeError"] = v_u_49.Text,
			["public"] = v_u_43,
			["name"] = v_u_30.Text,
			["creating"] = v_u_197,
			["joining"] = v_u_66 or false,
			["empty"] = v_u_60.Visible,
			["size"] = string.format("%dx%d", v_u_19.Holder.Size.X.Offset, v_u_19.Holder.Size.Y.Offset)
		}
	end
end
return v4