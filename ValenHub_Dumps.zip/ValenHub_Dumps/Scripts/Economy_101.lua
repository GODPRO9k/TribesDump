local v1 = {}
local v_u_2 = Color3.fromRGB
function v1.Init(p_u_3) -- name: Init
	-- upvalues: (copy) v_u_2
	local v_u_4 = p_u_3.UI
	local v_u_5 = p_u_3.Theme
	local v_u_6 = p_u_3.State
	local v_u_7 = p_u_3.WeaponInfo
	local v_u_8 = p_u_3.WeaponIcon
	local v_u_9 = p_u_3.Economy
	local v_u_10 = v_u_5.Colors
	local v11 = v_u_5.Fonts
	local v_u_12 = v_u_10.Success
	local v_u_13 = v_u_4.new("Frame", {
		["Name"] = "Economy",
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = p_u_3.Canvas.HUD
	})
	local v_u_14 = v_u_4.new("Frame", {
		["Name"] = "Collection",
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(340, 70),
		["Parent"] = v_u_13
	})
	local v_u_15 = nil
	local v_u_16 = v_u_4.Button({
		["Name"] = "Button",
		["Text"] = "COLLECTION",
		["TextSize"] = 26,
		["Style"] = "Dark",
		["Size"] = nil,
		["Icon"] = nil,
		["Gap"] = 6,
		["Parent"] = nil,
		["OnClick"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Icon"] = v_u_4.Image(v_u_4.Assets.Icons.CollectionGem or v_u_4.Assets.Fx.Gem, {
			["Name"] = "Icon",
			["Size"] = nil,
			["ScaleType"] = nil,
			["Size"] = UDim2.fromOffset(38, 38),
			["ScaleType"] = Enum.ScaleType.Fit
		}),
		["Parent"] = v_u_14,
		["OnClick"] = function() -- name: OnClick
			-- upvalues: (copy) p_u_3, (ref) v_u_15
			p_u_3.MenuManager.Open("Collection", v_u_15 and {
				["focus"] = v_u_15
			} or nil)
		end
	}).Label
	v_u_16.RichText = true
	v_u_16.LineHeight = 0.92
	local v_u_17 = v_u_4.new("Frame", {
		["Name"] = "Ready",
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(1, -8, 0, 8),
		["Size"] = UDim2.fromOffset(28, 28),
		["BackgroundColor3"] = v_u_12,
		["Visible"] = false,
		["ZIndex"] = 6,
		v_u_4.Corner(v_u_5.Radius.Pill),
		v_u_4.Stroke(v_u_10.Void, 2, 0.15),
		["Parent"] = v_u_14
	})
	local v_u_18 = v_u_4.new("TextLabel", {
		["Name"] = "Count",
		["Size"] = nil,
		["Text"] = "1",
		["FontFace"] = nil,
		["TextSize"] = 17,
		["TextColor3"] = nil,
		["ZIndex"] = 6,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["FontFace"] = v11.Display,
		["TextColor3"] = v_u_10.Text,
		["Parent"] = v_u_17
	})
	local v_u_19 = v_u_4.GetScaleObj(v_u_17, "Pulse")
	local v_u_20 = -1
	local function v_u_28() -- name: paintCard
		-- upvalues: (copy) v_u_14, (copy) v_u_9, (ref) v_u_15, (copy) v_u_5, (copy) v_u_12, (copy) v_u_16, (copy) v_u_17, (copy) v_u_18, (ref) v_u_20, (copy) v_u_4
		v_u_14.Visible = v_u_9.HasData()
		if v_u_14.Visible then
			local v21 = v_u_9.ReadyList()
			v_u_15 = v21[1]
			local v22 = 0
			local v23 = 0
			for _, v24 in v_u_9.Unlocks.AllIds() do
				v22 = v22 + 1
				if not v_u_9.Owns(v24) then
					continue
				end
				v23 = v23 + 1
			end
			local v25
			if #v21 > 0 then
				v25 = string.format("<font size=\"14\" color=\"#%s\">%s</font>", v_u_5.Lighten(v_u_12, 0.2):ToHex(), #v21 == 1 and "1 UPGRADE READY" or string.format("%d UPGRADES READY", #v21))
			else
				v25 = v22 <= v23 and v22 > 0 and "<font size=\"14\" color=\"#BAC0CE\">EVERY ITEM FOUND</font>" or string.format("<font size=\"14\" color=\"#BAC0CE\">%d / %d ITEMS</font>", v23, v22)
			end
			v_u_16.Text = "COLLECTION\n" .. v25
			v_u_17.Visible = #v21 > 0
			local v26 = v_u_18
			local v27 = #v21
			v26.Text = tostring(v27)
			if v_u_20 < #v21 and v_u_20 >= 0 then
				v_u_4.Pop(v_u_17, 0.6)
			end
			v_u_20 = #v21
		end
	end
	v_u_4.Every(v_u_17, 0.03333333333333333, function()
		-- upvalues: (copy) v_u_17, (copy) v_u_14, (copy) v_u_19
		if v_u_17.Visible and v_u_14.Visible then
			local v29 = v_u_19
			local v30 = os.clock() * 4.2
			v29.Scale = (math.sin(v30) * 0.5 + 0.5) * 0.1 + 1
		end
	end)
	local v_u_31 = v_u_4.new("Frame", {
		["Name"] = "StreakBadge",
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundColor3"] = v_u_5.Colors.Inset,
		["BackgroundTransparency"] = 0.15,
		["Visible"] = false,
		["ZIndex"] = 3,
		v_u_4.Corner(v_u_5.Radius.Pill),
		v_u_4.Stroke(v_u_2(255, 150, 60), 1, 0.45),
		v_u_4.List(Enum.FillDirection.Horizontal, 3, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center)
	})
	v_u_4.Image(v_u_4.Assets.Icons.Fire, {
		["Name"] = "Flame",
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(17, 17),
		["Parent"] = v_u_31
	})
	local v_u_32 = v_u_4.new("TextLabel", {
		["Name"] = "Streak",
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Text"] = "0",
		["FontFace"] = nil,
		["TextSize"] = 16,
		["TextColor3"] = nil,
		["LayoutOrder"] = 2,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(0, 1),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["FontFace"] = v11.Display,
		["TextColor3"] = v_u_2(255, 196, 120),
		["Parent"] = v_u_31
	})
	local v_u_33 = -1
	local function v_u_40() -- name: paintBadge
		-- upvalues: (copy) p_u_3, (copy) v_u_31, (copy) v_u_6, (copy) v_u_32, (ref) v_u_33, (copy) v_u_4
		local v34 = p_u_3.LobbyHud
		if v34 then
			v34 = p_u_3.LobbyHud.StreakSlot
		end
		if v34 then
			if v_u_31.Parent ~= v34 then
				v_u_31.Parent = v34
			end
			local v35 = v_u_6.Get("Streak")
			if type(v35) ~= "number" then
				local v36 = v_u_6.Profile.stats
				v35 = type(v36) == "table" and v36.streak or 0
			end
			local v37 = math.floor(v35)
			local v38 = math.max(0, v37)
			local v39 = v38 >= 2
			v_u_31.Visible = v39
			v_u_32.Text = tostring(v38)
			if v39 and (v_u_33 >= 0 and v_u_33 < v38) then
				v_u_4.Pop(v_u_31, 1.4)
			end
			v_u_33 = v38
		end
	end
	local v_u_41 = v_u_4.new("Frame", {
		["Name"] = "StreakRestore",
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(340, 50),
		["Parent"] = v_u_13
	})
	local v_u_42 = v_u_4.Button({
		["Name"] = "Restore",
		["Text"] = "RESTORE",
		["TextSize"] = 20,
		["Style"] = "Dark",
		["Size"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Radius"] = 12,
		["Icon"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, -58, 1, 0),
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, -29, 0.5, 0),
		["Icon"] = v_u_4.Image(v_u_4.Assets.Icons.Fire, {
			["Size"] = UDim2.fromOffset(26, 26)
		}),
		["Parent"] = v_u_41
	})
	v_u_42.Instance.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_42.Instance.Position = UDim2.new(0.5, -29, 0.5, 0)
	v_u_42.Label.RichText = true
	local v_u_43 = v_u_4.Pill("", v_u_10.SuccessDark, {
		["Name"] = "Price",
		["Height"] = 26,
		["TextSize"] = 15,
		["LayoutOrder"] = 3,
		["Transparency"] = 0
	})
	v_u_43.Parent = v_u_42.Content
	local v44 = v_u_4.IconButton({
		["Name"] = "Dismiss",
		["IconName"] = "cross",
		["IconScale"] = 0.36,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Color"] = nil,
		["Transparency"] = 0.35,
		["Sound"] = "Close",
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, 0, 0.5, -1),
		["Size"] = UDim2.fromOffset(42, 42),
		["Color"] = v_u_10.Raised,
		["Parent"] = v_u_41
	})
	local v_u_45 = nil
	local function v_u_49() -- name: paintRestore
		-- upvalues: (copy) v_u_9, (ref) v_u_45, (copy) v_u_41, (copy) v_u_42, (copy) v_u_43
		local v46 = v_u_9.StreakOffer()
		local v47
		if v46 == false then
			v47 = false
		else
			v47 = v_u_45 ~= v46.expiresAt
		end
		v_u_41.Visible = v47
		if v47 then
			local v48 = v_u_9.Pending(v46.key)
			v_u_42:SetText(v48 and "RESTORING\226\128\166" or string.format("RESTORE <font color=\"#FFC478\">%d</font>", v46.lost))
			v_u_43.Visible = not v48
			v_u_43:FindFirstChild("Text").Text = v_u_9.PriceText(v46.key)
			v_u_42:SetEnabled(not v48)
		end
	end
	v_u_42.Activated:Connect(function()
		-- upvalues: (copy) v_u_9
		local v50 = v_u_9.StreakOffer()
		if v50 then
			v_u_9.Buy(v50.key)
		end
	end)
	v44.Activated:Connect(function()
		-- upvalues: (copy) v_u_9, (ref) v_u_45, (copy) v_u_49
		local v51 = v_u_9.StreakOffer()
		local v52
		if v51 then
			v52 = v51.expiresAt
		else
			v52 = nil
		end
		v_u_45 = v52
		v_u_49()
	end)
	local v53 = v_u_2(245, 52, 64)
	local v_u_54 = v_u_4.new("Frame", {
		["Name"] = "GoldenOffer",
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(340, 60),
		["Parent"] = v_u_13
	})
	local v55 = v_u_4.new("Frame", {
		["Name"] = "Body",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_54
	})
	local v56 = v_u_4.new("TextButton", {
		["Name"] = "Button",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["ClipsDescendants"] = true,
		v_u_4.Corner(12),
		v_u_4.Gradient(v_u_2(178, 106, 14), v_u_2(98, 52, 6), 90),
		v_u_4.Stroke(v_u_2(255, 204, 90), 2, 0.15),
		["Parent"] = v55
	})
	local v_u_57 = v_u_4.new("Frame", {
		["Name"] = "Sweep",
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(-0.4, 0.5),
		["Size"] = UDim2.new(0, 70, 2, 0),
		["Rotation"] = 20,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["BackgroundTransparency"] = 0,
		v_u_4.Gradient(Color3.new(1, 1, 1), Color3.new(1, 1, 1), 0, NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0.72), NumberSequenceKeypoint.new(1, 1) })),
		["Parent"] = v56
	})
	local v_u_58 = v_u_4.Image(v_u_4.Assets.Icons.CollectionGem or v_u_4.Assets.Fx.Gem, {
		["Name"] = "Icon",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ScaleType"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 10, 0.5, 0),
		["Size"] = UDim2.fromOffset(40, 40),
		["ScaleType"] = Enum.ScaleType.Fit,
		["Parent"] = v56
	})
	local v_u_59 = v_u_4.new("TextLabel", {
		["Name"] = "Title",
		["Text"] = "GOLDEN DROP",
		["FontFace"] = v11.Heavy,
		["TextSize"] = 20,
		["TextColor3"] = v_u_2(255, 226, 150),
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(58, 7),
		["Size"] = UDim2.new(1, -150, 0, 24),
		v_u_4.TextStroke(v_u_2(70, 36, 2), 1.5, 0.3),
		["Parent"] = v56
	})
	local v_u_60 = v_u_4.new("TextLabel", {
		["Name"] = "Left",
		["Text"] = "",
		["RichText"] = true,
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v11.Heavy,
		["TextColor3"] = v_u_10.Text,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(58, 31),
		["Size"] = UDim2.new(1, -150, 0, 20),
		["Parent"] = v56
	})
	local v_u_61 = v_u_4.new("TextLabel", {
		["Name"] = "Was",
		["Text"] = "",
		["RichText"] = true,
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v11.Heavy,
		["TextColor3"] = v_u_2(236, 206, 150),
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -12, 0, 8),
		["Size"] = UDim2.fromOffset(90, 18),
		["Parent"] = v56
	})
	local v_u_62 = v_u_4.new("TextLabel", {
		["Name"] = "Now",
		["Text"] = "",
		["FontFace"] = v11.Display,
		["TextSize"] = 24,
		["TextColor3"] = v_u_10.Text,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -12, 0, 26),
		["Size"] = UDim2.fromOffset(90, 26),
		v_u_4.TextStroke(v_u_2(70, 36, 2), 1.5, 0.3),
		["Parent"] = v56
	})
	local v_u_63 = v_u_4.Pill("", v53, {
		["Name"] = "Tag",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Height"] = 28,
		["TextSize"] = 16,
		["Transparency"] = 0,
		["PadX"] = 9,
		["ZIndex"] = 4,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0, 16, 0, 2)
	})
	v_u_63.Rotation = -10
	v_u_63.Parent = v55
	v_u_4.new("Frame", {
		["Name"] = "Slash",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = -14,
		["BackgroundColor3"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(1, -22, 0.5, 0),
		["Size"] = UDim2.fromOffset(46, 2),
		["BackgroundColor3"] = v53,
		["Parent"] = v_u_61
	})
	local v_u_64 = v_u_4.new("UIScale", {
		["Parent"] = v55
	})
	local v_u_65 = v_u_4.new("UIScale", {
		["Parent"] = v_u_63
	})
	v56.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_4, (copy) v_u_64, (copy) v_u_5
		if not v_u_4.Touch then
			v_u_4.Tween(v_u_64, v_u_5.Tween.Fast, {
				["Scale"] = 1.03
			})
		end
	end)
	v56.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_4, (copy) v_u_64, (copy) v_u_5
		v_u_4.Tween(v_u_64, v_u_5.Tween.Fast, {
			["Scale"] = 1
		})
	end)
	v56.Activated:Connect(function()
		-- upvalues: (copy) p_u_3
		p_u_3.Sounds.Play("Click")
		p_u_3.MenuManager.Open("GoldenOffer")
	end)
	local function v_u_74() -- name: paintSale
		-- upvalues: (copy) v_u_9, (copy) v_u_54, (copy) v_u_60, (copy) v_u_61, (copy) v_u_62, (copy) v_u_63
		local v66 = v_u_9.GoldenOffer()
		local v67 = v_u_9.OfferLeft()
		local v68
		if v66 == false or v66.state ~= "active" then
			v68 = false
		else
			v68 = v67 ~= nil
		end
		v_u_54.Visible = v68
		if v68 then
			v_u_60.Text = string.format("<font color=\"#FFB4B8\">ENDS IN</font>  %s", v_u_9.FormatLeft(v67))
			local v69 = v_u_9.Price("drop_golden")
			local v70 = v_u_9.Price(v66.key)
			v_u_61.Text = not v69 and "" or string.format("<s>%s %d</s>", v_u_9.ROBUX, v69)
			local v71 = v_u_62
			local v72
			if v70 then
				v72 = string.format("%s %d", v_u_9.ROBUX, v70)
			else
				v72 = v_u_9.ROBUX .. " \226\128\166"
			end
			v71.Text = v72
			local v73 = v_u_9.OfferDiscount()
			v_u_63.Visible = v73 ~= nil
			if v73 then
				v_u_63:FindFirstChild("Text").Text = string.format("-%d%%", v73)
			end
		end
	end
	task.spawn(function()
		-- upvalues: (copy) v_u_13, (copy) v_u_54, (copy) v_u_57, (copy) v_u_4, (copy) v_u_65
		while v_u_13.Parent do
			task.wait(3.2)
			if not (v_u_54.Visible and v_u_13.Visible) then
				continue
			end
			v_u_57.Position = UDim2.fromScale(-0.4, 0.5)
			v_u_4.Tween(v_u_57, TweenInfo.new(0.75, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
				["Position"] = UDim2.fromScale(1.4, 0.5)
			})
			task.delay(0.45, function()
				-- upvalues: (ref) v_u_65, (ref) v_u_4
				v_u_65.Scale = 1.18
				v_u_4.Tween(v_u_65, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
					["Scale"] = 1
				})
			end)
		end
	end)
	local function v_u_87() -- name: layout
		-- upvalues: (copy) v_u_4, (copy) p_u_3, (copy) v_u_14, (copy) v_u_41, (copy) v_u_16, (copy) v_u_42, (copy) v_u_54, (copy) v_u_58, (copy) v_u_59, (copy) v_u_60, (copy) v_u_61, (copy) v_u_62, (copy) v_u_40
		local v75 = v_u_4.TopInset()
		local v76 = p_u_3.LobbyColumn
		local v77
		if v_u_4.Compact and (v76 and v76.Row) then
			v77 = v76.Row()
		else
			v77 = nil
		end
		local v78, v79
		if v77 then
			v_u_14.AnchorPoint = Vector2.new(0, 0.5)
			v78 = UDim2.fromOffset(v77.cardX, v77.y)
			v_u_14.Size = UDim2.fromOffset(v77.cardW, v77.h)
			v_u_41.AnchorPoint = Vector2.new(0, 0)
			v79 = UDim2.fromOffset(v77.restoreX, v77.restoreY)
			v_u_41.Size = UDim2.fromOffset(v77.restoreW, 46)
			v_u_16.TextSize = 24
			v_u_42.Label.TextSize = 17
		elseif v_u_4.Compact then
			v_u_14.AnchorPoint = Vector2.new(0, 0)
			v78 = UDim2.fromOffset(16, v75 + 158)
			v_u_14.Size = UDim2.fromOffset(254, 62)
			v_u_41.AnchorPoint = Vector2.new(0, 0)
			v79 = UDim2.fromOffset(16, v75 + 228)
			v_u_41.Size = UDim2.fromOffset(254, 46)
			v_u_16.TextSize = 24
			v_u_42.Label.TextSize = 17
		else
			v_u_14.AnchorPoint = Vector2.new(0, 1)
			v78 = UDim2.new(0, 24, 1, -192)
			v_u_14.Size = UDim2.fromOffset(340, 70)
			v_u_41.AnchorPoint = Vector2.new(0, 1)
			v79 = UDim2.new(0, 24, 1, -274)
			v_u_41.Size = UDim2.fromOffset(340, 50)
			v_u_16.TextSize = 26
			v_u_42.Label.TextSize = 20
		end
		local v80 = v_u_4.Touch and 58 or 70
		v_u_42.Instance.Size = UDim2.new(1, -v80, 1, 0)
		v_u_42.Instance.Position = UDim2.new(0.5, -v80 / 2, 0.5, 0)
		if not v_u_14.Visible then
			v_u_41.AnchorPoint = v_u_14.AnchorPoint
			v79 = v78
		end
		v_u_54.AnchorPoint = v_u_41.AnchorPoint
		local v81 = v_u_41.AnchorPoint.Y > 0.5
		local v82 = v_u_4.Compact and 48 or 60
		v_u_54.Size = UDim2.fromOffset(v_u_41.Size.X.Offset, v82)
		local v83
		if v_u_41.Visible then
			local v84 = v_u_41.Size.Y.Offset + 10
			local v85 = UDim2.fromOffset
			local v86 = 0
			if v81 then
				v84 = -v84
			end
			v83 = v79 + v85(v86, v84)
		else
			v83 = v79
		end
		v_u_58.Size = UDim2.fromOffset(v_u_4.Compact and 32 or 40, v_u_4.Compact and 32 or 40)
		v_u_59.TextSize = v_u_4.Compact and 16 or 20
		v_u_59.Position = UDim2.fromOffset(v_u_4.Compact and 48 or 58, v_u_4.Compact and 4 or 7)
		v_u_60.TextSize = v_u_4.Compact and 12 or 14
		v_u_60.Position = UDim2.fromOffset(v_u_4.Compact and 48 or 58, v_u_4.Compact and 25 or 31)
		v_u_61.Position = UDim2.new(1, -12, 0, v_u_4.Compact and 4 or 8)
		v_u_62.TextSize = v_u_4.Compact and 20 or 24
		v_u_62.Position = UDim2.new(1, -12, 0, v_u_4.Compact and 20 or 26)
		if v76 then
			v76.Place(v_u_14, v78)
			v76.Place(v_u_41, v79)
			v76.Place(v_u_54, v83)
		else
			v_u_14.Position = v78
			v_u_41.Position = v79
			v_u_54.Position = v83
		end
		v_u_40()
	end
	local function v88() -- name: refresh
		-- upvalues: (copy) v_u_28, (copy) v_u_49, (copy) v_u_74, (copy) v_u_87
		v_u_28()
		v_u_49()
		v_u_74()
		v_u_87()
	end
	v_u_28()
	v_u_49()
	v_u_74()
	v_u_87()
	v_u_9.Changed:Connect(v88)
	v_u_4.LayoutChanged:Connect(v88)
	v_u_4.TopInsetChanged:Connect(v_u_87)
	if p_u_3.LobbyColumn and p_u_3.LobbyColumn.RowChanged then
		p_u_3.LobbyColumn.RowChanged:Connect(v_u_87)
	end
	v_u_6.AttrChanged:Connect(function(p89)
		-- upvalues: (copy) v_u_40
		if p89 == "Streak" then
			v_u_40()
		end
	end)
	v_u_4.Every(v_u_13, 1, function()
		-- upvalues: (copy) v_u_41, (copy) v_u_9, (copy) v_u_28, (copy) v_u_49, (copy) v_u_74, (copy) v_u_87, (copy) v_u_54, (copy) v_u_31, (copy) v_u_40
		if v_u_41.Visible and not v_u_9.StreakOffer() then
			v_u_28()
			v_u_49()
			v_u_74()
			v_u_87()
		end
		if v_u_54.Visible or v_u_9.OfferLeft() then
			local v90 = v_u_54.Visible
			v_u_74()
			if v_u_54.Visible ~= v90 then
				v_u_87()
			end
		end
		if not v_u_31.Parent then
			v_u_40()
		end
	end)
	local function v93() -- name: refreshVisible
		-- upvalues: (copy) v_u_13, (copy) v_u_6, (copy) p_u_3
		local v91 = v_u_13
		local v92 = not v_u_6.SeesMatch()
		if v92 then
			v92 = not p_u_3.HudHidden
		end
		v91.Visible = v92
	end
	local v94 = not v_u_6.SeesMatch()
	if v94 then
		v94 = not p_u_3.HudHidden
	end
	v_u_13.Visible = v94
	v_u_6.PlayerStateChanged:Connect(v93)
	v_u_6.WatchChanged:Connect(v93)
	p_u_3.HudHiddenChanged:Connect(v93)
	v_u_9.Event:Connect(function(p95, p96)
		-- upvalues: (copy) p_u_3, (ref) v_u_33, (copy) v_u_40, (copy) v_u_7
		if p95 == "StreakRestored" then
			p_u_3.Sounds.Play("Reward")
			local v97 = p_u_3.Toast
			local v98 = string.format
			local v99 = p96.streak
			v97(v98("Win streak restored: \240\159\148\165 %d", tonumber(v99) or 0), "success")
			task.defer(function()
				-- upvalues: (ref) v_u_33, (ref) v_u_40
				v_u_33 = 0
				v_u_40()
			end)
			return
		elseif p95 == "StreakCredit" then
			p_u_3.Toast("Streak restore saved: it protects your next win streak", "info")
		elseif p95 == "Credit" then
			local v100 = p96.item
			if type(v100) == "string" then
				local v101 = p96.target
				local v102
				if type(v101) == "string" then
					v102 = p96.target
				else
					v102 = p96.item
				end
				local v103 = p96.shards
				local v104 = tonumber(v103)
				if v102 ~= p96.item then
					p_u_3.Toast(string.format("You already own the %s: %s shards went to your %s", v_u_7.Name(p96.item), not v104 and "its" or tostring(v104), v_u_7.Name(v102)), "info")
					return
				end
				p_u_3.Toast(string.format("You already own the %s: %s shards went toward its next upgrade", v_u_7.Name(p96.item), not v104 and "its" or tostring(v104)), "info")
			end
		end
	end)
	local v105 = p_u_3.Canvas.Overlay
	local v_u_106 = v_u_4.new("Frame", {
		["Name"] = "UnlockDim",
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["Visible"] = false,
		["ZIndex"] = 29,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundColor3"] = v_u_10.Void,
		["Parent"] = v105
	})
	local v_u_107 = v_u_4.new("TextButton", {
		["Name"] = "UnlockMoment",
		["Selectable"] = false,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 30,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.45),
		["Size"] = UDim2.fromOffset(560, 320),
		["Parent"] = v105
	})
	local v_u_108 = v_u_4.GetScaleObj(v_u_107, "FitScale")
	v_u_4.Panel({
		["Name"] = "Card",
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundTransparency"] = 0.06,
		["StrokeColor"] = nil,
		["StrokeTransparency"] = 0.55,
		["ZIndex"] = 29,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 18),
		["Size"] = UDim2.new(1, 0, 1, -18),
		["StrokeColor"] = v_u_10.Gold,
		["Parent"] = v_u_107
	})
	local v_u_109 = v_u_4.Image(v_u_4.Assets.Icons.Glow, {
		["Name"] = "Glow",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ImageColor3"] = nil,
		["ImageTransparency"] = 0.45,
		["ZIndex"] = 30,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0, 125),
		["Size"] = UDim2.fromOffset(460, 400),
		["ImageColor3"] = v_u_10.Accent,
		["Parent"] = v_u_107
	})
	local v_u_110 = v_u_4.Image(v_u_4.Assets.Fx.Ring, {
		["Name"] = "Ring",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ImageTransparency"] = 1,
		["ZIndex"] = 31,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0, 125),
		["Size"] = UDim2.fromOffset(120, 120),
		["Parent"] = v_u_107
	})
	local v_u_111 = v_u_4.new("Frame", {
		["Name"] = "Icon",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 32,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0, 125),
		["Size"] = UDim2.fromOffset(170, 170),
		["Parent"] = v_u_107
	})
	local v_u_112 = v_u_4.DisplayText({
		["Name"] = "Title",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "NEW ITEM UNLOCKED",
		["TextSize"] = 26,
		["TextColor3"] = nil,
		["StrokeThickness"] = 2,
		["ZIndex"] = 33,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 0),
		["Size"] = UDim2.fromOffset(520, 36),
		["TextColor3"] = v_u_10.Gold,
		["Parent"] = v_u_107
	})
	local v_u_113 = v_u_4.DisplayText({
		["Name"] = "ItemName",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["TextSize"] = 44,
		["StrokeThickness"] = 2,
		["ZIndex"] = 33,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 210),
		["Size"] = UDim2.fromOffset(520, 46),
		["Parent"] = v_u_107
	})
	local v_u_114 = v_u_4.new("TextLabel", {
		["Name"] = "Sub",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["RichText"] = true,
		["FontFace"] = nil,
		["TextSize"] = 16,
		["TextColor3"] = nil,
		["ZIndex"] = 33,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 258),
		["Size"] = UDim2.fromOffset(520, 20),
		["FontFace"] = v11.Heavy,
		["TextColor3"] = v_u_10.TextDim,
		["Parent"] = v_u_107
	})
	v_u_4.TextStroke(v_u_10.Void, 1.5, 0.35).Parent = v_u_114
	local v_u_115 = v_u_4.new("TextLabel", {
		["Name"] = "Next",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["ZIndex"] = 33,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 284),
		["Size"] = UDim2.fromOffset(520, 20),
		["FontFace"] = v11.Bold,
		["TextColor3"] = v_u_10.TextMuted,
		["Parent"] = v_u_107
	})
	v_u_4.TextStroke(v_u_10.Void, 1.5, 0.35).Parent = v_u_115
	local v_u_116 = 0
	local v_u_117 = false
	local v_u_118 = false
	local function v_u_120() -- name: hideCelebration
		-- upvalues: (ref) v_u_118, (ref) v_u_116, (copy) v_u_107, (copy) v_u_4, (copy) v_u_106, (ref) v_u_117, (copy) p_u_3, (copy) v_u_9, (copy) v_u_8, (copy) v_u_111
		if v_u_118 then
			return
		else
			v_u_116 = v_u_116 + 1
			if v_u_107.Visible then
				v_u_118 = true
				local v_u_119 = v_u_116
				v_u_4.FadeOut(v_u_107, TweenInfo.new(0.25))
				v_u_4.Tween(v_u_106, TweenInfo.new(0.25), {
					["BackgroundTransparency"] = 1
				})
				task.delay(0.27, function()
					-- upvalues: (ref) v_u_118, (copy) v_u_119, (ref) v_u_116, (ref) v_u_107, (ref) v_u_106, (ref) v_u_117, (ref) p_u_3, (ref) v_u_9, (ref) v_u_4, (ref) v_u_8, (ref) v_u_111
					v_u_118 = false
					if v_u_119 == v_u_116 then
						v_u_107.Visible = false
						v_u_106.Visible = false
						if v_u_117 ~= false then
							v_u_117 = false
							p_u_3.SetHudHidden("Unlock", false)
							if p_u_3.TopbarSettings and p_u_3.TopbarSettings.SetHidden then
								p_u_3.TopbarSettings.SetHidden("Unlock", false)
							end
							v_u_9.CelebrationChanged:Fire(false)
						end
						v_u_4.Unfade(v_u_107)
						v_u_8.Set(v_u_111, nil)
					end
				end)
			end
		end
	end
	local function v_u_130(p121) -- name: showCelebration
		-- upvalues: (ref) v_u_118, (ref) v_u_116, (copy) v_u_4, (copy) v_u_108, (copy) v_u_9, (copy) v_u_7, (copy) v_u_113, (copy) v_u_114, (copy) v_u_115, (copy) v_u_109, (copy) v_u_107, (ref) v_u_117, (copy) p_u_3, (copy) v_u_106, (copy) v_u_8, (copy) v_u_111, (copy) v_u_5, (copy) v_u_112, (copy) v_u_110, (copy) v_u_10, (copy) v_u_120
		v_u_118 = false
		v_u_116 = v_u_116 + 1
		local v_u_122 = v_u_116
		local v123 = v_u_4.CanvasSize()
		local v124 = v_u_108
		local v125 = (v123.X - 32) / 560
		local v126 = (v123.Y - 40) / 340
		v124.Scale = math.min(1, v125, v126)
		local v127 = v_u_9.CategoryColor(p121)
		local v128 = v_u_7.Get(p121)
		local v129 = v128 and (v_u_7.CATEGORY_SINGULAR[v128.category] or "") or ""
		v_u_113.Text = string.upper(v_u_7.Name(p121))
		v_u_114.Text = string.format("%s  \194\183  EQUIP IT IN YOUR LOADOUT", string.upper(v129))
		v_u_115.Text = "LEVEL 1  \194\183  SHARDS FROM DROPS LEVEL IT UP"
		v_u_109.ImageColor3 = v_u_9.CategoryColor(p121)
		v_u_4.Unfade(v_u_107)
		if v_u_117 ~= true then
			v_u_117 = true
			p_u_3.SetHudHidden("Unlock", true)
			if p_u_3.TopbarSettings and p_u_3.TopbarSettings.SetHidden then
				p_u_3.TopbarSettings.SetHidden("Unlock", true)
			end
			v_u_9.CelebrationChanged:Fire(true)
		end
		v_u_107.Visible = true
		v_u_106.Visible = true
		v_u_106.BackgroundTransparency = 1
		v_u_4.Tween(v_u_106, TweenInfo.new(0.3), {
			["BackgroundTransparency"] = 0.45
		})
		v_u_8.Set(v_u_111, p121, {
			["spin"] = true,
			["outline"] = true,
			["glow"] = false,
			["outlineColor"] = nil,
			["outlineScale"] = 1.04,
			["outlineTransparency"] = 0.45,
			["outlineColor"] = v127:Lerp(Color3.new(1, 1, 1), 0.5)
		})
		p_u_3.Sounds.Play("Unlock")
		v_u_4.Pop(v_u_111, 0.3, v_u_5.Tween.Slam)
		v_u_4.Pop(v_u_112, 1.6, v_u_5.Tween.Slam)
		v_u_4.Enter(v_u_113, Vector2.new(0, 16), 0.12)
		v_u_4.Enter(v_u_114, Vector2.new(0, 12), 0.2)
		v_u_4.Enter(v_u_115, Vector2.new(0, 12), 0.28)
		v_u_109.ImageTransparency = 1
		v_u_4.Tween(v_u_109, TweenInfo.new(0.5, Enum.EasingStyle.Quint), {
			["ImageTransparency"] = 0.5
		})
		v_u_110.Size = UDim2.fromOffset(120, 120)
		v_u_110.ImageTransparency = 0.2
		v_u_110.ImageColor3 = v_u_10.Accent
		v_u_4.Tween(v_u_110, TweenInfo.new(0.7, Enum.EasingStyle.Quint), {
			["Size"] = nil,
			["ImageTransparency"] = 1,
			["Size"] = UDim2.fromOffset(520, 520)
		})
		task.delay(4.2, function()
			-- upvalues: (copy) v_u_122, (ref) v_u_116, (ref) v_u_120
			if v_u_122 == v_u_116 then
				v_u_120()
			end
		end)
	end
	v_u_107.Activated:Connect(v_u_120)
	local v_u_131 = game:GetService("Players").LocalPlayer
	local v_u_132 = nil
	local function v_u_133() -- name: canShow
		-- upvalues: (copy) v_u_131, (copy) p_u_3, (copy) v_u_6
		if v_u_131:GetAttribute("ReplayPlaying") == true or (p_u_3.IsHudHiddenFor("Intro") or p_u_3.IsHudHiddenFor("Celebrate")) then
			return false
		else
			return not v_u_6.InMatch() or p_u_3.IsHudHiddenFor("MatchEnd")
		end
	end
	v_u_9.Celebrate:Connect(function(p134)
		-- upvalues: (ref) v_u_132, (copy) v_u_133, (copy) v_u_130
		if type(p134) == "string" then
			v_u_132 = {
				["id"] = p134
			}
			local v135 = v_u_132
			if v135 and v_u_133() then
				v_u_132 = nil
				v_u_130(v135.id)
			end
		end
	end)
	v_u_4.Every(v_u_107, 0.25, function()
		-- upvalues: (ref) v_u_117, (copy) v_u_107, (copy) v_u_133, (copy) v_u_120, (ref) v_u_132, (copy) v_u_130
		if v_u_117 and (v_u_107.Visible and not v_u_133()) then
			v_u_120()
		end
		local v136 = v_u_132
		if v136 and v_u_133() then
			v_u_132 = nil
			v_u_130(v136.id)
		end
	end)
	local v137, v138 = pcall(function()
		-- upvalues: (copy) p_u_3
		require(script.Parent.Parent.ContractPodium).Init(p_u_3)
	end)
	if not v137 then
		warn("[UI] contract podium failed: " .. tostring(v138))
	end
	function p_u_3.Debug.unlockEvent(p139)
		-- upvalues: (copy) v_u_9, (ref) v_u_132, (ref) v_u_117
		v_u_9.Celebrate:Fire(type(p139) ~= "string" and "crossbow" or p139)
		return {
			["pending"] = v_u_132 ~= nil,
			["showing"] = v_u_117
		}
	end
	function p_u_3.Debug.unlockMoment(p140)
		-- upvalues: (copy) v_u_130
		v_u_130(type(p140) ~= "string" and "crossbow" or p140)
		return true
	end
	function p_u_3.Debug.collectionCard()
		-- upvalues: (copy) v_u_14, (copy) v_u_16, (ref) v_u_15, (copy) v_u_9, (copy) v_u_17
		return {
			["visible"] = v_u_14.Visible,
			["label"] = v_u_16.Text,
			["focus"] = v_u_15 or false,
			["ready"] = v_u_9.UpgradesReady(),
			["badge"] = v_u_17.Visible
		}
	end
end
return v1