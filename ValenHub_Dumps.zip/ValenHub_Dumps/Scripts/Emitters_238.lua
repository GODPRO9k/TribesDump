local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("Workspace")
local v3 = {}
local v_u_4 = {
	"torch",
	"brazier",
	"campfire",
	"bonfire",
	"firepit",
	"fire_pit",
	"hearth"
}
local v_u_5 = {}
local v_u_6 = {}
local v_u_7 = nil
local v_u_8 = {}
local v_u_9 = 0
local function v_u_16(p10) -- name: anchorOf
	-- upvalues: (copy) v_u_4
	if p10:IsA("Fire") then
		local v11 = p10.Parent
		if v11 and (v11:IsA("BasePart") or v11:IsA("Attachment")) then
			return v11
		else
			return nil
		end
	elseif p10:IsA("ParticleEmitter") then
		local v12 = string.lower(p10.Name)
		if string.find(v12, "fire", 1, true) or string.find(v12, "flame", 1, true) then
			local v13 = p10.Parent
			if v13 and (v13:IsA("BasePart") or v13:IsA("Attachment")) then
				return v13
			else
				return nil
			end
		else
			return nil
		end
	else
		if p10:IsA("BasePart") then
			local v14 = string.lower(p10.Name)
			for _, v15 in v_u_4 do
				if not string.find(v14, v15, 1, true) then
					continue
				end
				return p10
			end
		end
		return nil
	end
end
local function v_u_19(p17) -- name: consider
	-- upvalues: (copy) v_u_16, (copy) v_u_5
	local v18 = v_u_16(p17)
	if v18 and not v_u_5[v18] then
		v_u_5[v18] = {
			["sound"] = "Ambience/Fire_Emitter",
			["volume"] = 1
		}
	end
end
local function v_u_23(p20) -- name: addTagged
	-- upvalues: (copy) v_u_5
	if p20:IsA("BasePart") or p20:IsA("Attachment") then
		local v21 = p20:GetAttribute("Sound")
		if type(v21) == "string" then
			local v22 = p20:GetAttribute("Volume")
			v_u_5[p20] = {
				["sound"] = v21,
				["volume"] = type(v22) ~= "number" and 1 or v22
			}
		end
	else
		return
	end
end
function v3.Watch(p_u_24) -- name: Watch
	-- upvalues: (copy) v_u_8, (copy) v_u_19, (copy) v_u_16, (copy) v_u_5
	if not v_u_8[p_u_24] then
		v_u_8[p_u_24] = p_u_24.DescendantAdded:Connect(v_u_19)
		task.spawn(function()
			-- upvalues: (copy) p_u_24, (ref) v_u_16, (ref) v_u_5
			for v25, v26 in p_u_24:GetDescendants() do
				local v27 = v_u_16(v26)
				if v27 and not v_u_5[v27] then
					v_u_5[v27] = {
						["sound"] = "Ambience/Fire_Emitter",
						["volume"] = 1
					}
				end
				if v25 % 500 ~= 0 then
					continue
				end
				task.wait()
			end
		end)
	end
end
function v3.Unwatch(p28) -- name: Unwatch
	-- upvalues: (copy) v_u_8, (copy) v_u_5
	local v29 = v_u_8[p28]
	if v29 then
		v29:Disconnect()
		v_u_8[p28] = nil
	end
	for v30 in v_u_5 do
		if not v30:IsDescendantOf(p28) then
			continue
		end
		v_u_5[v30] = nil
	end
end
function v3.Update() -- name: Update
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_6, (ref) v_u_9, (ref) v_u_7
	local v31 = v_u_2.CurrentCamera
	if v31 then
		local v32 = v31.CFrame.Position
		local v33 = {}
		for v34, _ in v_u_5 do
			if v34.Parent then
				local v35
				if v34:IsA("BasePart") then
					v35 = v34.Position
				elseif v34:IsA("Attachment") then
					v35 = v34.WorldPosition
				else
					v35 = nil
				end
				local v36 = not v35 and (1 / 0) or (v35 - v32).Magnitude
				if v36 >= 42 and (not v_u_6[v34] or v36 >= 55) then
					continue
				end
				table.insert(v33, {
					["inst"] = v34,
					["d"] = v36
				})
			else
				v_u_5[v34] = nil
				local v37 = v_u_6[v34]
				if not v37 then
					continue
				end
				v37:Destroy()
				v_u_6[v34] = nil
			end
		end
		table.sort(v33, function(p38, p39)
			return p38.d < p39.d
		end)
		v_u_9 = #v33
		local v40 = #v33
		local v41 = {}
		for v42 = 1, math.min(v40, 6) do
			local v43 = v33[v42].inst
			v41[v43] = true
			if v_u_6[v43] then
				continue
			end
			local v44 = v_u_5[v43]
			local v45 = v_u_7.Clone(v44.sound)
			if not v45 then
				continue
			end
			v45.Looped = true
			v45.Volume = v45.Volume * v44.volume
			v45.PlaybackSpeed = v45.PlaybackSpeed * (0.94 + math.random() * 0.12)
			v45.Parent = v43
			v45.TimePosition = math.random() * 20
			v45:Play()
			v_u_6[v43] = v45
		end
		for v46 in v_u_6 do
			if v41[v46] then
				continue
			end
			local v47 = v_u_6[v46]
			if not v47 then
				continue
			end
			v47:Destroy()
			v_u_6[v46] = nil
		end
	end
end
function v3.Count() -- name: Count
	-- upvalues: (copy) v_u_6, (copy) v_u_5, (ref) v_u_9
	local v48 = 0
	local v49 = 0
	for _ in v_u_6 do
		v48 = v48 + 1
	end
	for _ in v_u_5 do
		v49 = v49 + 1
	end
	return v48 .. "/" .. v49 .. " near=" .. v_u_9
end
function v3.Init(p50) -- name: Init
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (copy) v_u_23, (copy) v_u_5, (copy) v_u_6
	v_u_7 = p50
	v_u_1:GetInstanceAddedSignal("AmbientSound"):Connect(v_u_23)
	v_u_1:GetInstanceRemovedSignal("AmbientSound"):Connect(function(p51)
		-- upvalues: (ref) v_u_5, (ref) v_u_6
		v_u_5[p51] = nil
		local v52 = v_u_6[p51]
		if v52 then
			v52:Destroy()
			v_u_6[p51] = nil
		end
	end)
	for _, v53 in v_u_1:GetTagged("AmbientSound") do
		v_u_23(v53)
	end
end
return v3