local v_u_1 = {}
v_u_1.__index = v_u_1
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("GuiService")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = game:GetService("StarterPlayer")
local v_u_8 = UserSettings():GetService("UserGameSettings")
local v_u_9 = game:GetService("VRService")
local v_u_10 = game:GetService("ContextActionService")
local v11 = require(script.Parent:WaitForChild("CommonUtils"))
local v12 = v11.get("FlagUtil")
local v_u_13 = v12.getUserFlag("UserVRFixCameraCloseArticulation")
local v_u_14 = v12.getUserFlag("UserPlayerScriptsCCLIntegrationD")
local v_u_15 = v12.getUserFlag("UserPlayerScriptsBindActivateOnIAS")
local v_u_16 = v12.getUserFlag("UserPlayerScriptsPlayerControlState2")
local v_u_17 = v12.getUserFlag("UserPlayerScriptsTaskDeferSimulation")
local v_u_18 = v12.getUserFlag("UserPlayerScriptsFixSAuthRenderStepMove")
local v_u_19 = v12.getUserFlag("UserPlayerScriptsSupportMicroGamepad")
local v_u_20 = v12.getUserFlag("UserAbilitiesUserInterfaceC")
local v_u_21 = v12.getUserFlag("UserControlModuleEnabledAPI")
local v_u_22 = v12.getUserFlag("UserPSUseBindToAnimation")
local v_u_23 = require(script:WaitForChild("ActionController"))
local v_u_24
if v_u_14 or v_u_16 then
	v_u_24 = require(script:WaitForChild("InputReplication"))
else
	v_u_24 = nil
end
local v_u_25
if v_u_14 then
	v_u_25 = require(script:WaitForChild("InputSlots"))
else
	v_u_25 = nil
end
local v_u_26
if v_u_3:IsClient() then
	v_u_26 = require(script:WaitForChild("DynamicThumbstick"))
else
	v_u_26 = nil
end
local v_u_27 = require(script:WaitForChild("ClassicThumbstick"))
local v_u_28 = require(script:WaitForChild("ClickToMoveController"))
local v_u_29 = require(script:WaitForChild("TouchJump"))
local v_u_30
if v_u_14 then
	v_u_30 = require(script:WaitForChild("TouchAbilities"))
else
	v_u_30 = nil
end
local v_u_31 = require(script:WaitForChild("VehicleController"))
local v_u_32, v_u_33
if v_u_14 then
	v_u_32 = require(script:WaitForChild("AvatarAbilitiesInterface"))
	v_u_33 = v_u_32.get(v_u_2.LocalPlayer)
else
	v_u_33 = nil
	v_u_32 = nil
end
local v_u_34 = script.Parent:WaitForChild("InputContexts"):WaitForChild("CameraContext"):WaitForChild("CameraRotationAction")
local _ = Enum.ContextActionPriority.Medium.Value
local v_u_35 = v11.get("VRFirstPersonState")
local v_u_36 = {
	[Enum.TouchMovementMode.DPad] = v_u_26,
	[Enum.DevTouchMovementMode.DPad] = v_u_26,
	[Enum.TouchMovementMode.Thumbpad] = v_u_26,
	[Enum.DevTouchMovementMode.Thumbpad] = v_u_26,
	[Enum.TouchMovementMode.Thumbstick] = v_u_27,
	[Enum.DevTouchMovementMode.Thumbstick] = v_u_27,
	[Enum.TouchMovementMode.DynamicThumbstick] = v_u_26,
	[Enum.DevTouchMovementMode.DynamicThumbstick] = v_u_26,
	[Enum.TouchMovementMode.ClickToMove] = v_u_28,
	[Enum.DevTouchMovementMode.ClickToMove] = v_u_28,
	[Enum.TouchMovementMode.Default] = v_u_26,
	[Enum.ComputerMovementMode.Default] = v_u_23,
	[Enum.ComputerMovementMode.KeyboardMouse] = v_u_23,
	[Enum.DevComputerMovementMode.KeyboardMouse] = v_u_23,
	[Enum.DevComputerMovementMode.Scriptable] = nil,
	[Enum.ComputerMovementMode.ClickToMove] = v_u_28,
	[Enum.DevComputerMovementMode.ClickToMove] = v_u_28
}
function v_u_1.new() -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_2, (copy) v_u_31, (copy) v_u_8, (copy) v_u_14, (ref) v_u_33, (copy) v_u_5, (copy) v_u_4, (copy) v_u_15, (copy) v_u_10
	local v37 = v_u_1
	local v_u_38 = setmetatable({}, v37)
	if v_u_3:IsServer() then
		return v_u_38
	end
	v_u_38.controllers = {}
	v_u_38.activeControlModule = nil
	v_u_38.activeController = nil
	v_u_38.touchJumpController = nil
	v_u_38.touchAbilitiesController = nil
	v_u_38.moveFunction = v_u_2.LocalPlayer.Move
	v_u_38.humanoid = nil
	v_u_38.controlsEnabled = true
	v_u_38.enabled = false
	v_u_38.humanoidSeatedConn = nil
	v_u_38.vehicleController = nil
	v_u_38.touchControlFrame = nil
	v_u_38.currentTorsoAngle = 0
	v_u_38.inputMoveVector = Vector3.new(0, 0, 0)
	v_u_38.vehicleController = v_u_31.new()
	v_u_2.LocalPlayer.CharacterAdded:Connect(function(p39)
		-- upvalues: (copy) v_u_38
		v_u_38:OnCharacterAdded(p39)
	end)
	v_u_2.LocalPlayer.CharacterRemoving:Connect(function(p40)
		-- upvalues: (copy) v_u_38
		v_u_38:OnCharacterRemoving(p40)
	end)
	if v_u_2.LocalPlayer.Character then
		v_u_38:OnCharacterAdded(v_u_2.LocalPlayer.Character)
	end
	v_u_8:GetPropertyChangedSignal("TouchMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_38
		v_u_38:UpdateMovementMode()
	end)
	v_u_2.LocalPlayer:GetPropertyChangedSignal("DevTouchMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_38
		v_u_38:UpdateMovementMode()
	end)
	v_u_8:GetPropertyChangedSignal("ComputerMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_38
		v_u_38:UpdateMovementMode()
	end)
	v_u_2.LocalPlayer:GetPropertyChangedSignal("DevComputerMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_38
		v_u_38:UpdateMovementMode()
	end)
	if v_u_14 then
		v_u_33:GetEnabledChangedSignal():Connect(function()
			-- upvalues: (copy) v_u_38
			v_u_38:UpdateAbilitiesControllers()
		end)
	end
	v_u_38.playerGui = nil
	v_u_38.touchGui = nil
	v_u_38.playerGuiAddedConn = nil
	v_u_5:GetPropertyChangedSignal("TouchControlsEnabled"):Connect(function()
		-- upvalues: (copy) v_u_38
		v_u_38:UpdateMovementMode()
		v_u_38:UpdateActiveControlModuleEnabled()
	end)
	v_u_4:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		-- upvalues: (copy) v_u_38
		v_u_38:UpdateMovementMode()
	end)
	v_u_38.playerGui = v_u_2.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if not v_u_38.playerGui then
		v_u_38.playerGuiAddedConn = v_u_2.LocalPlayer.ChildAdded:Connect(function(p41)
			-- upvalues: (copy) v_u_38
			if p41:IsA("PlayerGui") then
				v_u_38.playerGui = p41
				v_u_38.playerGuiAddedConn:Disconnect()
				v_u_38.playerGuiAddedConn = nil
				v_u_38:UpdateMovementMode()
			end
		end)
	end
	if v_u_15 then
		v_u_10:BindActivate(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonR2)
	end
	return v_u_38
end
local function v_u_47(p42) -- name: _fireCustomInputs
	-- upvalues: (copy) v_u_8
	local v43 = p42:FindFirstChild("InputContexts")
	if v43 == nil then
		return
	else
		local v44 = v43:FindFirstChild("CharacterContext")
		if v44 ~= nil then
			local v45 = v44:FindFirstChild("RotationAction")
			local v46 = v45 and v45:FindFirstChild("RotationScriptableBinding")
			if v46 then
				v46:Fire(v_u_8.RotationType == Enum.RotationType.CameraRelative)
			end
		end
	end
end
local function v_u_50(p48) -- name: _cloneInputs
	-- upvalues: (copy) v_u_7
	local v49 = v_u_7.PlayerModule.InputContexts:Clone()
	v49.CharacterContext.Enabled = true
	v49.CameraContext.Enabled = true
	v49.Parent = p48
end
function v_u_1.InitializeServerAuthority(p_u_51) -- name: InitializeServerAuthority
	-- upvalues: (copy) v_u_3, (copy) v_u_14, (copy) v_u_2, (copy) v_u_24, (copy) v_u_7, (copy) v_u_50, (copy) v_u_16, (copy) v_u_17, (ref) v_u_32, (copy) v_u_22, (copy) v_u_47
	if v_u_3:IsServer() then
		if v_u_14 then
			for _, v52 in v_u_2:GetPlayers() do
				v_u_24.CloneInputsIfAbsent(v52)
			end
			v_u_2.PlayerAdded:Connect(v_u_24.CloneInputsIfAbsent)
		else
			for _, v53 in v_u_2:GetPlayers() do
				local v54 = v_u_7.PlayerModule.InputContexts:Clone()
				v54.CharacterContext.Enabled = true
				v54.CameraContext.Enabled = true
				v54.Parent = v53
			end
			v_u_2.PlayerAdded:Connect(v_u_50)
		end
		if v_u_16 then
			for _, v55 in v_u_2:GetPlayers() do
				v_u_24.createPlayerControlState(v55)
			end
			v_u_2.PlayerAdded:Connect(v_u_24.createPlayerControlState)
		end
		if v_u_14 and v_u_17 then
			for _, v56 in v_u_2:GetPlayers() do
				v_u_32.get(v56)
			end
			v_u_2.PlayerAdded:Connect(function(p57)
				-- upvalues: (ref) v_u_32
				v_u_32.get(p57)
			end)
		end
		if v_u_22 then
			v_u_3:BindToAnimation(function(p58)
				-- upvalues: (ref) v_u_2, (copy) p_u_51
				for _, v59 in v_u_2:GetPlayers() do
					p_u_51:ProcessInputs(v59, p58)
				end
			end, Enum.StepFrequency.Hz60)
		else
			v_u_3:BindToSimulation(function(p60)
				-- upvalues: (ref) v_u_2, (copy) p_u_51
				for _, v61 in v_u_2:GetPlayers() do
					p_u_51:ProcessInputs(v61, p60)
				end
			end, Enum.StepFrequency.Hz60)
		end
	else
		if v_u_16 then
			v_u_24.watchForPlayerControlState(v_u_2.LocalPlayer)
		end
		v_u_3:BindToRenderStep("CameraInput", Enum.RenderPriority.Last.Value, function()
			-- upvalues: (ref) v_u_16, (ref) v_u_24, (ref) v_u_2, (copy) p_u_51, (ref) v_u_14, (ref) v_u_47
			if v_u_16 then
				v_u_24.writeInputToPCS(v_u_2.LocalPlayer, p_u_51, true)
				return
			elseif v_u_14 then
				v_u_24.FireCustomInputs(v_u_2.LocalPlayer)
			else
				v_u_47(v_u_2.LocalPlayer)
			end
		end)
		if v_u_22 then
			v_u_3:BindToAnimation(function(p62)
				-- upvalues: (copy) p_u_51, (ref) v_u_2
				p_u_51:ProcessInputs(v_u_2.LocalPlayer, p62)
			end, Enum.StepFrequency.Hz60)
		else
			v_u_3:BindToSimulation(function(p63)
				-- upvalues: (copy) p_u_51, (ref) v_u_2
				p_u_51:ProcessInputs(v_u_2.LocalPlayer, p63)
			end, Enum.StepFrequency.Hz60)
		end
	end
	if p_u_51.data and p_u_51.data.eventBus then
		p_u_51.data.isServerAuthority = true
		p_u_51.data.eventBus:publish("SERVER_AUTHORITY_CHANGED", true)
	end
end
function v_u_1.GetEstimatedVRTorsoFrame(p64) -- name: GetEstimatedVRTorsoFrame
	-- upvalues: (copy) v_u_9
	local v65 = v_u_9:GetUserCFrame(Enum.UserCFrame.Head)
	local _, v66, _ = v65:ToEulerAnglesYXZ()
	local v67 = -v66
	if v_u_9:GetUserCFrameEnabled(Enum.UserCFrame.RightHand) and v_u_9:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand) then
		local v68 = v_u_9:GetUserCFrame(Enum.UserCFrame.LeftHand)
		local v69 = v_u_9:GetUserCFrame(Enum.UserCFrame.RightHand)
		local v70 = v65.Position - v68.Position
		local v71 = v65.Position - v69.Position
		local v72 = v70.X
		local v73 = v70.Z
		local v74 = -math.atan2(v72, v73)
		local v75 = v71.X
		local v76 = v71.Z
		local v77 = (-math.atan2(v75, v76) - v74 + 12.566370614359172) % 6.283185307179586
		if v77 > 3.141592653589793 then
			v77 = v77 - 6.283185307179586
		end
		local v78 = (v74 + v77 / 2 + 12.566370614359172) % 6.283185307179586
		if v78 > 3.141592653589793 then
			v78 = v78 - 6.283185307179586
		end
		local v79 = (v67 - p64.currentTorsoAngle + 12.566370614359172) % 6.283185307179586
		if v79 > 3.141592653589793 then
			v79 = v79 - 6.283185307179586
		end
		local v80 = (v78 - p64.currentTorsoAngle + 12.566370614359172) % 6.283185307179586
		if v80 > 3.141592653589793 then
			v80 = v80 - 6.283185307179586
		end
		local v81
		if v80 > -1.5707963267948966 then
			v81 = v80 < 1.5707963267948966
		else
			v81 = false
		end
		if not v81 then
			v80 = v79
		end
		local v82 = math.min(v80, v79)
		local v83 = math.max(v80, v79)
		local v84 = 0
		if v82 > 0 then
			v83 = v82
		elseif v83 >= 0 then
			v83 = v84
		end
		p64.currentTorsoAngle = v83 + p64.currentTorsoAngle
	else
		p64.currentTorsoAngle = v67
	end
	return CFrame.new(v65.Position) * CFrame.fromEulerAnglesYXZ(0, -p64.currentTorsoAngle, 0)
end
function v_u_1.GetActiveController(p85) -- name: GetActiveController
	return p85.activeController
end
function v_u_1.UpdateAbilitiesControllers(p86) -- name: UpdateAbilitiesControllers
	-- upvalues: (copy) v_u_4, (copy) v_u_28, (copy) v_u_27, (ref) v_u_26, (ref) v_u_33, (copy) v_u_29, (copy) v_u_30
	local v87 = p86.enabled and p86.touchControlFrame
	if v87 then
		if v_u_4.PreferredInput == Enum.PreferredInput.Touch then
			v87 = (p86.activeControlModule == v_u_28 or p86.activeControlModule == v_u_27) and true or p86.activeControlModule == v_u_26
		else
			v87 = false
		end
	end
	local v88
	if v87 then
		v88 = not v_u_33:isEnabled()
	else
		v88 = v87
	end
	if v87 then
		v87 = v_u_33:isEnabled()
	end
	if v88 then
		if not p86.controllers[v_u_29] then
			p86.controllers[v_u_29] = v_u_29.new(p86.data, p86.playerData)
		end
		p86.touchJumpController = p86.controllers[v_u_29]
		p86.touchJumpController:Enable(true, p86.touchControlFrame)
	elseif p86.touchJumpController then
		p86.touchJumpController:Enable(false)
	end
	if v87 then
		if not p86.controllers[v_u_30] then
			p86.controllers[v_u_30] = v_u_30.new(p86.touchControlFrame)
		end
		p86.touchAbilitiesController = p86.controllers[v_u_30]
		p86.touchAbilitiesController:Enable(true)
	elseif p86.touchAbilitiesController then
		p86.touchAbilitiesController:Enable(false)
	end
end
function v_u_1.UpdateActiveControlModuleEnabled(p_u_89) -- name: UpdateActiveControlModuleEnabled
	-- upvalues: (copy) v_u_14, (ref) v_u_33, (copy) v_u_2, (copy) v_u_4, (copy) v_u_28, (copy) v_u_27, (ref) v_u_26, (copy) v_u_29, (copy) v_u_5
	local function v90()
		-- upvalues: (ref) v_u_14, (copy) p_u_89, (ref) v_u_33, (ref) v_u_2
		if v_u_14 then
			p_u_89.enabled = false
		end
		p_u_89.activeController:Enable(false)
		if v_u_14 then
			p_u_89:UpdateAbilitiesControllers()
		elseif p_u_89.touchJumpController then
			p_u_89.touchJumpController:Enable(false)
		end
		if p_u_89.moveFunction and not (v_u_14 and v_u_33:isEnabled()) then
			p_u_89.moveFunction(v_u_2.LocalPlayer, Vector3.new(0, 0, 0), true)
		end
	end
	local function v91()
		-- upvalues: (ref) v_u_14, (copy) p_u_89, (ref) v_u_4, (ref) v_u_28, (ref) v_u_27, (ref) v_u_26, (ref) v_u_29, (ref) v_u_2
		if v_u_14 then
			p_u_89.enabled = true
			p_u_89:UpdateAbilitiesControllers()
		elseif p_u_89.touchControlFrame and (v_u_4.PreferredInput == Enum.PreferredInput.Touch and (p_u_89.activeControlModule == v_u_28 or (p_u_89.activeControlModule == v_u_27 or p_u_89.activeControlModule == v_u_26))) then
			if not p_u_89.controllers[v_u_29] then
				p_u_89.controllers[v_u_29] = v_u_29.new(p_u_89.data, p_u_89.playerData)
			end
			p_u_89.touchJumpController = p_u_89.controllers[v_u_29]
			p_u_89.touchJumpController:Enable(true, p_u_89.touchControlFrame)
		elseif p_u_89.touchJumpController then
			p_u_89.touchJumpController:Enable(false)
		end
		if p_u_89.activeControlModule == v_u_28 then
			p_u_89.activeController:Enable(true, v_u_2.LocalPlayer.DevComputerMovementMode == Enum.DevComputerMovementMode.UserChoice, p_u_89.touchJumpController)
			return
		elseif p_u_89.touchControlFrame then
			p_u_89.activeController:Enable(true, p_u_89.touchControlFrame)
		else
			p_u_89.activeController:Enable(true)
		end
	end
	if p_u_89.activeController then
		if p_u_89.controlsEnabled then
			if v_u_5.TouchControlsEnabled or (v_u_4.PreferredInput ~= Enum.PreferredInput.Touch or p_u_89.activeControlModule ~= v_u_28 and (p_u_89.activeControlModule ~= v_u_27 and p_u_89.activeControlModule ~= v_u_26)) then
				v91()
			else
				v90()
			end
		else
			v90()
			return
		end
	else
		return
	end
end
function v_u_1.Enable(p92, p93) -- name: Enable
	local v94 = p93 == nil and true or p93
	if p92.controlsEnabled == v94 then
		return
	else
		p92.controlsEnabled = v94
		if p92.activeController then
			p92:UpdateActiveControlModuleEnabled()
		end
	end
end
function v_u_1.Disable(p95) -- name: Disable
	p95:Enable(false)
end
function v_u_1.SelectComputerMovementModule(_) -- name: SelectComputerMovementModule
	-- upvalues: (copy) v_u_19, (copy) v_u_4, (copy) v_u_23, (copy) v_u_2, (copy) v_u_8, (copy) v_u_28, (copy) v_u_36
	local v_u_96 = false
	if v_u_19 then
		local function v97()
			-- upvalues: (ref) v_u_96, (ref) v_u_4
			v_u_96 = v_u_4.PreferredInput == Enum.PreferredInput.MicroGamepad
		end
		pcall(v97)
	end
	if v_u_4.PreferredInput == Enum.PreferredInput.KeyboardAndMouse or (v_u_4.PreferredInput == Enum.PreferredInput.Gamepad or v_u_96) then
		local v98 = v_u_23
		local v99 = v_u_2.LocalPlayer.DevComputerMovementMode
		if v99 == Enum.DevComputerMovementMode.UserChoice then
			if v_u_8.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove then
				v98 = v_u_28
			end
		else
			v98 = v_u_36[v99]
			if not v98 and v99 ~= Enum.DevComputerMovementMode.Scriptable then
				warn("No character control module is associated with DevComputerMovementMode ", v99)
			end
		end
		if v98 then
			return v98, true
		elseif v99 == Enum.DevComputerMovementMode.Scriptable then
			return nil, true
		else
			return nil, false
		end
	else
		return nil, false
	end
end
function v_u_1.SelectTouchModule(_) -- name: SelectTouchModule
	-- upvalues: (copy) v_u_2, (copy) v_u_36, (copy) v_u_8
	local v100 = v_u_2.LocalPlayer.DevTouchMovementMode
	local v101
	if v100 == Enum.DevTouchMovementMode.UserChoice then
		v101 = v_u_36[v_u_8.TouchMovementMode]
	else
		if v100 == Enum.DevTouchMovementMode.Scriptable then
			return nil, true
		end
		v101 = v_u_36[v100]
	end
	return v101, true
end
function v_u_1.calculateRawMoveVector(p102, p103, p104) -- name: calculateRawMoveVector
	-- upvalues: (copy) v_u_6, (copy) v_u_9, (copy) v_u_34
	local v105 = v_u_6.CurrentCamera
	if not v105 then
		return p104
	end
	local v106 = v105.CFrame
	if v_u_9.VREnabled and p103.RootPart then
		local v107 = p102:GetEstimatedVRTorsoFrame()
		if (v105.Focus.Position - v106.Position).Magnitude < 3 then
			v106 = v106 * v107
		else
			v106 = v105.CFrame * (v107.Rotation + v107.Position * v105.HeadScale)
		end
	end
	if p103:GetState() ~= Enum.HumanoidStateType.Swimming then
		local _, _, _, v112, v109, v110, _, _, v111, _, _, v112 = v106:GetComponents()
		if v111 >= 1 or v111 <= -1 then
			v110 = -v109 * math.sign(v111)
		end
		local v113 = v112 * v112 + v110 * v110
		local v114 = math.sqrt(v113)
		local v115 = (v112 * p104.X + v110 * p104.Z) / v114
		local v116 = (v112 * p104.Z - v110 * p104.X) / v114
		return Vector3.new(v115, 0, v116)
	end
	if not v_u_9.VREnabled then
		return v106:VectorToWorldSpace(p104)
	end
	local v117 = p104.X
	local v118 = p104.Z
	local v119 = Vector3.new(v117, 0, v118)
	if v119.Magnitude < 0.01 then
		return Vector3.new(0, 0, 0)
	end
	local v120 = not (v_u_34 and v_u_34.Enabled) and 0 or -v_u_34:GetState().Y / 2.31
	local v121 = -v119.X
	local v122 = -v119.Z
	local v123 = math.atan2(v121, v122)
	local _, v124, _ = v106:ToEulerAnglesYXZ()
	local v125 = v123 + v124
	return CFrame.fromEulerAnglesYXZ(v120, v125, 0).LookVector
end
function v_u_1.initialize(p126, p127, p128) -- name: initialize
	-- upvalues: (copy) v_u_23, (copy) v_u_14, (copy) v_u_25
	p126.data = p127
	p126.playerData = p128
	p126:UpdateMovementMode()
	v_u_23.initializeActions(p126.data, p126.playerData)
	if v_u_14 then
		v_u_25.setupSlotActions(p126.playerData.player, p126.data.isServerAuthority)
	end
end
function v_u_1.Update(p129, p130, p131, p132) -- name: Update
	-- upvalues: (copy) v_u_21, (copy) v_u_23, (copy) v_u_9, (copy) v_u_16, (copy) v_u_14, (ref) v_u_33, (copy) v_u_24, (copy) v_u_2, (copy) v_u_18
	local v133 = p131.player
	assert(v133)
	local v134 = p131.character
	assert(v134)
	if v_u_21 then
		if not p129.humanoid then
			return
		end
		if not p131.playerModule.ControlModule.Enabled then
			p131.isJumping = false
			p131.moveVector = Vector2.new()
			p131.worldMoveVector = Vector3.new()
			v_u_23.update(p131)
			p129.inputMoveVector = Vector3.new()
			if p129.vehicleController then
				p129.vehicleController:Update(Vector3.new(), true)
			end
			p129:characterMove(p130, p131)
			return
		end
	end
	v_u_23.initializeActions(p130, p131)
	if v_u_21 or p131.actions.MoveAction and p131.actions.JumpAction then
		if p129.activeController and (p129.activeController.enabled and p129.humanoid) then
			v_u_23.update(p131)
			p129:GetClickToMoveController():Update(p131, p132)
			local v135 = p131.moveVector.X
			local v136 = -p131.moveVector.Y
			local v137 = Vector3.new(v135, 0, v136)
			if p129.vehicleController then
				local v138
				v137, v138 = p129.vehicleController:Update(v137, true)
				_ = v138
			end
			local v139 = p129:calculateRawMoveVector(p129.humanoid, v137)
			p129.inputMoveVector = v139
			if v_u_9.VREnabled then
				v139 = p129:updateVRMoveVector(v139)
			end
			if v_u_21 then
				p131.worldMoveVector = v139
				p129:characterMove(p130, p131)
				return
			end
			if v_u_16 then
				if not p130.isServerAuthority then
					if v_u_14 and v_u_33:isEnabled() then
						v_u_24.writeInputToPCS(v_u_2.LocalPlayer, p129, false)
					else
						p129.moveFunction(v_u_2.LocalPlayer, v139, false)
						p129.humanoid.Jump = p131.isJumping
					end
				end
			elseif not (v_u_18 and p130.isServerAuthority or v_u_14 and v_u_33:isEnabled()) then
				p129.moveFunction(v_u_2.LocalPlayer, v139, false)
				p129.humanoid.Jump = p131.isJumping
			end
		end
	end
end
function v_u_1.characterMove(p140, p141, p142) -- name: characterMove
	-- upvalues: (copy) v_u_16, (copy) v_u_14, (ref) v_u_33, (copy) v_u_24, (copy) v_u_2, (copy) v_u_18
	if v_u_16 then
		if not p141.isServerAuthority then
			if v_u_14 and v_u_33:isEnabled() then
				v_u_24.writeInputToPCS(v_u_2.LocalPlayer, p140, false)
			else
				p140.moveFunction(v_u_2.LocalPlayer, p142.worldMoveVector, false)
				p140.humanoid.Jump = p142.isJumping
			end
		end
	elseif not (v_u_18 and p141.isServerAuthority or v_u_14 and v_u_33:isEnabled()) then
		p140.moveFunction(v_u_2.LocalPlayer, p142.worldMoveVector, false)
		p140.humanoid.Jump = p142.isJumping
	end
end
function v_u_1.updateVRMoveVector(p143, p144) -- name: updateVRMoveVector
	-- upvalues: (copy) v_u_13, (copy) v_u_35, (copy) v_u_9
	local v145 = workspace.CurrentCamera
	local v146 = v145.Focus.Position - v145.CFrame.Position
	local v147
	if v_u_13 then
		v147 = v_u_35.inFirstPerson
	else
		v147 = v146.Magnitude < 5
	end
	if p144.Magnitude ~= 0 or (not v147 or (not v_u_9.AvatarGestures or (not p143.humanoid or p143.humanoid.Sit))) then
		return p144
	end
	local v148 = v_u_9:GetUserCFrame(Enum.UserCFrame.Head)
	local v149 = v148.Rotation + v148.Position * v145.HeadScale
	local v150 = -0.7 * p143.humanoid.RootPart.Size.Y / 2
	local v151 = (v145.CFrame * v149 * CFrame.new(0, v150, 0)).Position - p143.humanoid.RootPart.CFrame.Position
	local v152 = v151.x
	local v153 = v151.z
	local v154 = Vector3.new(v152, 0, v153)
	if v_u_13 then
		local v155 = (v145.Focus.Position - v145.CFrame.Position).Magnitude
		local v156 = 4 * v145.HeadScale
		if math.max(v156, 1) < v155 then
			return p144
		end
	end
	return v154
end
function v_u_1.OnHumanoidSeated(p157, p158, p159) -- name: OnHumanoidSeated
	if p158 then
		if p159 and p159:IsA("VehicleSeat") then
			if not p157.vehicleController then
				p157.vehicleController = p157.vehicleController.new()
			end
			p157.vehicleController:Enable(true, p159)
			return
		end
	elseif p157.vehicleController then
		p157.vehicleController:Enable(false, p159)
	end
end
function v_u_1.OnCharacterAdded(p_u_160, p161) -- name: OnCharacterAdded
	p_u_160.humanoid = p161:FindFirstChildOfClass("Humanoid")
	while not p_u_160.humanoid do
		p161.ChildAdded:wait()
		p_u_160.humanoid = p161:FindFirstChildOfClass("Humanoid")
	end
	if p_u_160.humanoidSeatedConn then
		p_u_160.humanoidSeatedConn:Disconnect()
		p_u_160.humanoidSeatedConn = nil
	end
	p_u_160.humanoidSeatedConn = p_u_160.humanoid.Seated:Connect(function(p162, p163)
		-- upvalues: (copy) p_u_160
		p_u_160:OnHumanoidSeated(p162, p163)
	end)
	p_u_160:UpdateMovementMode()
end
function v_u_1.OnCharacterRemoving(p164, _) -- name: OnCharacterRemoving
	p164.humanoid = nil
	p164:UpdateMovementMode()
end
function v_u_1.UpdateTouchGuiVisibility(p165) -- name: UpdateTouchGuiVisibility
	-- upvalues: (copy) v_u_5, (copy) v_u_4
	local v166 = p165.humanoid and v_u_5.TouchControlsEnabled
	if v166 then
		v166 = v_u_4.PreferredInput == Enum.PreferredInput.Touch
	end
	if v166 and not p165.touchGui then
		p165:CreateTouchGuiContainer()
	end
	if p165.touchGui then
		p165.touchGui.Enabled = v166 and true or false
	end
end
function v_u_1.SwitchToController(p167, p168) -- name: SwitchToController
	if p168 then
		if not p167.controllers[p168] then
			p167.controllers[p168] = p168.new(p167.playerData)
		end
		if p167.activeController ~= p167.controllers[p168] then
			if p167.activeController then
				p167.activeController:Enable(false)
			end
			p167.activeController = p167.controllers[p168]
			p167.activeControlModule = p168
			p167:UpdateActiveControlModuleEnabled()
		end
	else
		if p167.activeController then
			p167.activeController:Enable(false)
		end
		p167.activeController = nil
		p167.activeControlModule = nil
	end
end
function v_u_1.UpdateMovementMode(p169) -- name: UpdateMovementMode
	-- upvalues: (copy) v_u_4
	p169:UpdateTouchGuiVisibility()
	if v_u_4.PreferredInput == Enum.PreferredInput.Touch then
		local v170, v171 = p169:SelectTouchModule()
		if v171 and p169.touchControlFrame then
			p169:SwitchToController(v170)
			return
		end
	else
		p169:SwitchToController((p169:SelectComputerMovementModule()))
	end
end
function v_u_1.CreateTouchGuiContainer(p172) -- name: CreateTouchGuiContainer
	-- upvalues: (copy) v_u_14, (copy) v_u_20
	if p172.playerGui then
		if p172.touchGui then
			p172.touchGui:Destroy()
		end
		p172.touchGui = Instance.new("ScreenGui")
		p172.touchGui.Name = "TouchGui"
		p172.touchGui.ResetOnSpawn = false
		p172.touchGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		if v_u_14 and v_u_20 then
			p172.touchGui.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
		end
		p172.touchGui.ClipToDeviceSafeArea = false
		p172.touchControlFrame = Instance.new("Frame")
		p172.touchControlFrame.Name = "TouchControlFrame"
		p172.touchControlFrame.Size = UDim2.new(1, 0, 1, 0)
		p172.touchControlFrame.BackgroundTransparency = 1
		p172.touchControlFrame.Parent = p172.touchGui
		p172.touchGui.Parent = p172.playerGui
	end
end
function v_u_1.GetClickToMoveController(p173) -- name: GetClickToMoveController
	-- upvalues: (copy) v_u_28
	if not p173.controllers[v_u_28] then
		p173.controllers[v_u_28] = v_u_28.new()
	end
	return p173.controllers[v_u_28]
end
function v_u_1.ProcessInputs(_, p174, _) -- name: ProcessInputs
	-- upvalues: (copy) v_u_14, (ref) v_u_32, (copy) v_u_16, (copy) v_u_24
	if v_u_14 then
		if not v_u_32.get(p174):isEnabled() then
			if v_u_16 then
				v_u_24.processPCSInputs(p174)
			else
				v_u_24.SendInputToHumanoidForServerAuth(p174)
			end
		end
	else
		if v_u_16 then
			v_u_24.processPCSInputs(p174)
			return
		end
		local v175 = p174.Character
		if v175 == nil then
			return
		end
		local v176 = v175:FindFirstChild("Humanoid")
		if v176 == nil then
			return
		end
		local v177 = p174:FindFirstChild("InputContexts")
		if v177 == nil then
			return
		end
		local v178 = v177:FindFirstChild("CharacterContext")
		if v178 == nil then
			return
		end
		local v179 = v178.MoveAction
		local v180 = v178.RotationAction
		local v181 = v178.JumpAction
		local v182
		if v179 == nil then
			v182 = Vector2.new(0, 0)
		else
			v182 = v179:GetState()
		end
		local v183 = p174:GetCameraState().CFrame.LookVector
		if v182.X == v182.X and (v182.Y == v182.Y and v182.X ~= (1 / 0)) and v182.Y ~= (1 / 0) and (v183.X == v183.X and (v183.Y == v183.Y and (v183.Z == v183.Z and (v183.X ~= (1 / 0) and v183.Y ~= (1 / 0)))) and v183.Z ~= (1 / 0) and v183.Magnitude > 0) then
			if v176:GetState() ~= Enum.HumanoidStateType.Swimming then
				local v184 = v183.X
				local v185 = v183.Z
				v183 = Vector3.new(v184, 0, v185).Unit
			end
			local v186 = v183:Cross(Vector3.new(0, 1, 0)).Unit
			v176:Move(v183 * v182.Y + v186 * v182.X)
			if v180:GetState() then
				v176.AutoRotate = false
				if v176.SeatPart == nil and (v176.RootPart ~= nil and not (v176.Sit or v176.RootPart:IsGrounded())) then
					v176.RootPart.CFrame = CFrame.new(v176.RootPart.CFrame.Position, v176.RootPart.CFrame.Position + v183)
				end
			else
				v176.AutoRotate = true
			end
		end
		local v187
		if v181 == nil then
			v187 = false
		else
			v187 = v181:GetState()
		end
		v176.Jump = v187
	end
end
if v_u_3:IsClient() then
	return v_u_1.new()
else
	return v_u_1
end