local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ContentProvider")
local v_u_3 = {}
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = {}
local v_u_7 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_8 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_9 = {
	["Head"] = true,
	["UpperTorso"] = true,
	["Torso"] = true
}
local function v_u_13(p10) -- name: stripPart
	p10.LocalTransparencyModifier = 0
	for _, v11 in p10:GetDescendants() do
		if v11:IsA("BasePart") then
			v11.LocalTransparencyModifier = 0
		else
			if not v11:IsA("Decal") then
				continue
			end
			v11.LocalTransparencyModifier = 0
		end
	end
	for _, v12 in p10:GetDescendants() do
		if not (v12:IsA("JointInstance") or (v12:IsA("Constraint") or (v12:IsA("LuaSourceContainer") or (v12:IsA("Sound") or (v12:IsA("ParticleEmitter") or (v12:IsA("Light") or (v12:IsA("Trail") or (v12:IsA("Beam") or (v12:IsA("BillboardGui") or (v12:IsA("ProximityPrompt") or v12:IsA("Highlight"))))))))))) then
			continue
		end
		v12:Destroy()
	end
	p10.Anchored = true
	p10.CanCollide = false
	p10.CanQuery = false
	p10.CanTouch = false
end
local v_u_14 = nil
local v_u_15 = nil
local function v_u_46(p_u_16, p_u_17) -- name: capture
	-- upvalues: (copy) v_u_9, (copy) v_u_13, (copy) v_u_6, (ref) v_u_15, (ref) v_u_14, (ref) v_u_5, (ref) v_u_46
	local v18 = p_u_17:FindFirstChild("Head")
	local v19 = p_u_17:FindFirstChild("UpperTorso") or p_u_17:FindFirstChild("Torso")
	if v18 and (v18:IsA("BasePart") and (v19 and v19:IsA("BasePart"))) then
		if v18.Transparency >= 0.9 or v19.Transparency >= 0.9 then
			return nil
		else
			local v20 = Instance.new("Model")
			v20.Name = "Portrait"
			local v21 = v19.CFrame.LookVector
			local v22 = v21.X
			local v23 = v21.Z
			local v24 = Vector3.new(v22, 0, v23)
			local v25 = v24.Magnitude <= 0.01 and Vector3.new(0, 0, -1) or v24.Unit
			local v26 = CFrame.lookAt(v18.Position, v18.Position + v25)
			for _, v_u_27 in p_u_17:GetChildren() do
				if v_u_27:IsA("BasePart") and v_u_9[v_u_27.Name] then
					local v30, v31 = pcall(function()
						-- upvalues: (copy) v_u_27
						local v28 = v_u_27.Archivable
						v_u_27.Archivable = true
						local v29 = v_u_27:Clone()
						v_u_27.Archivable = v28
						return v29
					end)
					if not v30 then
						v31 = nil
					end
					if not v31 then
						continue
					end
					v_u_13(v31)
					v31.CFrame = v_u_27.CFrame
					v31.Parent = v20
				elseif v_u_27:IsA("Accessory") or v_u_27:IsA("Accoutrement") then
					local v32 = v_u_27:FindFirstChild("Handle")
					if not v32 or (not v32:IsA("BasePart") or (v32.Position - v26.Position).Magnitude >= 3.2) then
						continue
					end
					local v35, v36 = pcall(function()
						-- upvalues: (copy) v_u_27
						local v33 = v_u_27.Archivable
						v_u_27.Archivable = true
						local v34 = v_u_27:Clone()
						v_u_27.Archivable = v33
						return v34
					end)
					if not v35 then
						v36 = nil
					end
					if not v36 then
						continue
					end
					local v37 = v36:FindFirstChild("Handle")
					if v37 then
						v_u_13(v37)
						v37.CFrame = v32.CFrame
					end
					v36.Parent = v20
				else
					if not (v_u_27:IsA("Shirt") or (v_u_27:IsA("Pants") or (v_u_27:IsA("ShirtGraphic") or (v_u_27:IsA("BodyColors") or v_u_27:IsA("CharacterMesh"))))) then
						continue
					end
					local v40, v41 = pcall(function()
						-- upvalues: (copy) v_u_27
						local v38 = v_u_27.Archivable
						v_u_27.Archivable = true
						local v39 = v_u_27:Clone()
						v_u_27.Archivable = v38
						return v39
					end)
					if not v40 then
						v41 = nil
					end
					if not v41 then
						continue
					end
					v41.Parent = v20
				end
			end
			local v42 = Instance.new("Humanoid")
			v42.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
			v42.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
			v42.Parent = v20
			local v_u_43 = {
				["model"] = nil,
				["head"] = nil,
				["at"] = nil,
				["rig"] = nil,
				["ready"] = false,
				["readyAt"] = 0,
				["model"] = v20,
				["head"] = v26,
				["at"] = os.clock(),
				["rig"] = p_u_17
			}
			local v44 = v_u_6[p_u_16]
			v_u_6[p_u_16] = v_u_43
			if v44 then
				v44.model:Destroy()
			end
			v_u_15(p_u_16, v_u_43)
			if v44 then
				v_u_14(p_u_16)
				return v_u_43
			else
				task.delay(2.5, function()
					-- upvalues: (ref) v_u_6, (copy) p_u_16, (copy) v_u_43, (ref) v_u_5, (copy) p_u_17, (ref) v_u_46
					if v_u_6[p_u_16] == v_u_43 then
						local v45 = v_u_5.Find(p_u_16) or p_u_17
						if v45 and v45.Parent then
							v_u_46(p_u_16, v45)
						end
					end
				end)
				return v_u_43
			end
		end
	else
		return nil
	end
end
local function v_u_50(p47) -- name: clearRender
	for _, v48 in { "RigHead", "RigBack" } do
		local v49 = p47:FindFirstChild(v48)
		if not v49 then
			continue
		end
		v49:Destroy()
	end
end
local function v_u_55(p51, p52) -- name: silhouette
	-- upvalues: (copy) v_u_50, (ref) v_u_4
	if not p52 then
		v_u_50(p51)
	end
	local v53 = v_u_4.new("Frame", {
		["Name"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Name"] = p52 and "RigBack" or "RigHead",
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundColor3"] = Color3.fromRGB(44, 48, 60),
		["ZIndex"] = p51.ZIndex,
		["Parent"] = p51
	})
	local v54 = p51:FindFirstChildOfClass("UICorner")
	if v54 then
		v54:Clone().Parent = v53
	end
	v_u_4.Icon("person", 0, Color3.fromRGB(110, 118, 136), {
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.fromScale(0.5, 1),
		["ZIndex"] = p51.ZIndex,
		["Parent"] = v53
	}).Size = UDim2.fromScale(0.72, 0.8)
end
local function v_u_69(p_u_56, p_u_57) -- name: renderTemplate
	-- upvalues: (copy) v_u_50, (copy) v_u_55, (ref) v_u_4
	v_u_50(p_u_56)
	v_u_55(p_u_56, true)
	local v_u_58 = v_u_4.new("ViewportFrame", {
		["Name"] = "RigHead",
		["Size"] = nil,
		["Ambient"] = nil,
		["LightColor"] = nil,
		["ZIndex"] = nil,
		["ImageColor3"] = nil,
		["ImageTransparency"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Ambient"] = Color3.fromRGB(150, 150, 150),
		["LightColor"] = Color3.fromRGB(235, 232, 226),
		["ZIndex"] = p_u_56.ZIndex,
		["ImageColor3"] = p_u_56:GetAttribute("PortraitTint") or Color3.new(1, 1, 1),
		["ImageTransparency"] = p_u_56:GetAttribute("PortraitFade") or 0,
		["Parent"] = p_u_56
	})
	local v59 = p_u_56:FindFirstChildOfClass("UICorner")
	if v59 then
		v59:Clone().Parent = v_u_58
	end
	p_u_57.model:Clone().Parent = v_u_58
	local v60 = p_u_57.head
	local v61 = v60.Position - v60.UpVector * 0.15
	local v62 = v60.Position + v60.LookVector * 3.9 + v60.RightVector * 0.8 + v60.UpVector * 0.35
	local v_u_63 = Instance.new("Camera")
	v_u_63.FieldOfView = 30
	v_u_63.CFrame = CFrame.lookAt(v62, v61)
	v_u_63.Parent = v_u_58
	v_u_58.CurrentCamera = v_u_63
	v_u_58.LightDirection = (v61 - v62).Unit + Vector3.new(0, -0.6, 0)
	local v_u_64 = v_u_63.CFrame
	task.spawn(function()
		-- upvalues: (copy) v_u_58, (copy) p_u_56, (copy) v_u_63, (copy) v_u_64, (copy) p_u_57
		local v65 = os.clock()
		local v66 = 0
		while v_u_58.Parent == p_u_56 and v_u_63.Parent == v_u_58 do
			v66 = v66 + 1
			v_u_63.CFrame = v_u_64 * CFrame.new(0, 0, v66 % 2 == 0 and 0 or 0.0004)
			if p_u_57.ready and (os.clock() - p_u_57.readyAt > 0.5 and os.clock() - v65 > 0.5) then
				local v67 = p_u_56:FindFirstChild("RigBack")
				if v67 then
					v67:Destroy()
				end
				for v68 = 1, 4 do
					task.wait(0.5)
					if v_u_58.Parent ~= p_u_56 then
						continue
					end
					v_u_63.CFrame = v_u_64 * CFrame.new(0, 0, v68 % 2 == 0 and 0 or 0.0004)
				end
				return
			end
			if os.clock() - v65 > 15 then
				return
			end
			task.wait(0.2)
		end
	end)
end
v_u_14 = function(p70) -- name: rerender
	-- upvalues: (copy) v_u_6, (copy) v_u_8, (ref) v_u_69
	local v71 = v_u_6[p70]
	if v71 then
		local v72 = "rig:" .. p70
		for v73, v74 in v_u_8 do
			if v74 ~= v72 or not v73.Parent then
				continue
			end
			v_u_69(v73, v71)
		end
	end
end
local function v_u_95(p75) -- name: contentIds
	local v_u_76 = {}
	local v_u_77 = {}
	for _, v_u_78 in p75:GetDescendants() do
		pcall(function()
			-- upvalues: (copy) v_u_78, (copy) v_u_76, (copy) v_u_77
			if v_u_78:IsA("MeshPart") then
				local v79 = v_u_78.MeshId
				if type(v79) == "string" and (v79 ~= "" and not v_u_76[v79]) then
					v_u_76[v79] = true
					local v80 = v_u_77
					table.insert(v80, v79)
				end
				local v81 = v_u_78.TextureID
				if type(v81) == "string" and (v81 ~= "" and not v_u_76[v81]) then
					v_u_76[v81] = true
					local v82 = v_u_77
					table.insert(v82, v81)
					return
				end
			elseif v_u_78:IsA("SpecialMesh") then
				local v83 = v_u_78.MeshId
				if type(v83) == "string" and (v83 ~= "" and not v_u_76[v83]) then
					v_u_76[v83] = true
					local v84 = v_u_77
					table.insert(v84, v83)
				end
				local v85 = v_u_78.TextureId
				if type(v85) == "string" and (v85 ~= "" and not v_u_76[v85]) then
					v_u_76[v85] = true
					local v86 = v_u_77
					table.insert(v86, v85)
					return
				end
			elseif v_u_78:IsA("Decal") then
				local v87 = v_u_78.Texture
				if type(v87) == "string" and (v87 ~= "" and not v_u_76[v87]) then
					v_u_76[v87] = true
					local v88 = v_u_77
					table.insert(v88, v87)
					return
				end
			elseif v_u_78:IsA("Shirt") then
				local v89 = v_u_78.ShirtTemplate
				if type(v89) == "string" and (v89 ~= "" and not v_u_76[v89]) then
					v_u_76[v89] = true
					local v90 = v_u_77
					table.insert(v90, v89)
					return
				end
			elseif v_u_78:IsA("Pants") then
				local v91 = v_u_78.PantsTemplate
				if type(v91) == "string" and (v91 ~= "" and not v_u_76[v91]) then
					v_u_76[v91] = true
					local v92 = v_u_77
					table.insert(v92, v91)
					return
				end
			elseif v_u_78:IsA("ShirtGraphic") then
				local v93 = v_u_78.Graphic
				if type(v93) == "string" and (v93 ~= "" and not v_u_76[v93]) then
					v_u_76[v93] = true
					local v94 = v_u_77
					table.insert(v94, v93)
				end
			end
		end)
	end
	return v_u_77
end
local v_u_96 = {
	[Enum.AssetFetchStatus.Success] = true,
	[Enum.AssetFetchStatus.Failure] = true,
	[Enum.AssetFetchStatus.TimedOut] = true
}
v_u_15 = function(_, p_u_97) -- name: prepare
	-- upvalues: (copy) v_u_95, (copy) v_u_2, (copy) v_u_96
	task.spawn(function()
		-- upvalues: (ref) v_u_95, (copy) p_u_97, (ref) v_u_2, (ref) v_u_96
		local v_u_98 = v_u_95(p_u_97.model)
		if #v_u_98 > 0 then
			task.spawn(function()
				-- upvalues: (ref) v_u_2, (copy) v_u_98
				local function v99()
					-- upvalues: (ref) v_u_2, (ref) v_u_98
					v_u_2:PreloadAsync(v_u_98)
				end
				pcall(v99)
			end)
			local v100 = os.clock()
			while os.clock() - v100 < 8 do
				local v101 = true
				for _, v_u_102 in v_u_98 do
					local function v103()
						-- upvalues: (ref) v_u_2, (copy) v_u_102
						return v_u_2:GetAssetFetchStatus(v_u_102)
					end
					local v104, v105 = pcall(v103)
					if not v104 or v_u_96[v105] then
						continue
					end
					v101 = false
				end
				if v101 then
					break
				end
				task.wait(0.15)
			end
		end
		p_u_97.ready = true
		p_u_97.readyAt = os.clock()
	end)
end
function v_u_3.SetTint(p106, p107, p108) -- name: SetTint
	p106:SetAttribute("PortraitTint", p107)
	p106:SetAttribute("PortraitFade", p108)
	p106.ImageColor3 = p107
	p106.ImageTransparency = p108
	local v109 = p106:FindFirstChild("RigHead")
	if v109 and v109:IsA("ViewportFrame") then
		v109.ImageColor3 = p107
		v109.ImageTransparency = p108
	end
end
function v_u_3.ThumbFor(p110, p111) -- name: ThumbFor
	-- upvalues: (ref) v_u_5
	if type(p110) == "table" then
		p110 = p110.userId
	end
	if not v_u_5.IsRealUserId(p110) and (not v_u_5.TrustAllUserIds or (type(p110) ~= "number" or p110 <= 0)) then
		return ""
	end
	local v112 = p111 or 150
	local v113 = v112 <= 48 and 48 or (v112 <= 60 and 60 or (v112 <= 150 and 150 or 420))
	return string.format("rbxthumb://type=AvatarHeadShot&id=%d&w=%d&h=%d", p110, v113, v113)
end
function v_u_3.ImageFor(p114, p115) -- name: ImageFor
	-- upvalues: (copy) v_u_3
	return v_u_3.ThumbFor(p114, p115)
end
function v_u_3.Apply(p116, p117, p118) -- name: Apply
	-- upvalues: (copy) v_u_3, (copy) v_u_8, (copy) v_u_7, (copy) v_u_50, (copy) v_u_55, (copy) v_u_6, (ref) v_u_5, (ref) v_u_46, (ref) v_u_69
	local v119 = v_u_3.ThumbFor(p117, p118)
	local v120
	if type(p117) == "table" then
		v120 = p117.id or nil
	else
		v120 = nil
	end
	local v121
	if v119 == "" then
		v121 = "rig:" .. tostring(v120)
	else
		v121 = v119
	end
	if v_u_8[p116] == v121 then
		if v119 ~= "" then
			return
		end
		if p116:FindFirstChild("RigHead") and not v_u_7[p116] then
			return
		end
	end
	v_u_8[p116] = v121
	v_u_7[p116] = nil
	p116.ScaleType = Enum.ScaleType.Crop
	if v119 == "" then
		p116.Image = ""
		if type(v120) == "string" then
			local v122 = v_u_6[v120]
			if not v122 then
				local v123 = v_u_5.Find(v120)
				if v123 then
					v122 = v_u_46(v120, v123)
				end
			end
			if v122 then
				v_u_69(p116, v122)
			else
				v_u_55(p116)
				v_u_7[p116] = p117
			end
		else
			v_u_55(p116)
			return
		end
	else
		v_u_50(p116)
		p116.Image = v119
		return
	end
end
function v_u_3.Reset() -- name: Reset
	-- upvalues: (copy) v_u_6, (copy) v_u_8
	for _, v124 in v_u_6 do
		v124.model:Destroy()
	end
	table.clear(v_u_6)
	local v125 = {}
	for v126, v127 in v_u_8 do
		if string.sub(v127, 1, 4) ~= "rig:" then
			continue
		end
		table.insert(v125, v126)
	end
	for _, v128 in v125 do
		v_u_8[v128] = nil
	end
end
function v_u_3.Init(p129, p130) -- name: Init
	-- upvalues: (ref) v_u_4, (ref) v_u_5, (copy) v_u_7, (copy) v_u_3, (copy) v_u_6, (ref) v_u_46, (copy) v_u_8, (copy) v_u_1
	v_u_4 = p129
	v_u_5 = p130
	task.spawn(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_3
		while true do
			repeat
				task.wait(1)
			until next(v_u_7)
			local v131 = {}
			for v132, v133 in v_u_7 do
				table.insert(v131, { v132, v133 })
			end
			for _, v134 in v131 do
				if v134[1].Parent then
					v_u_3.Apply(v134[1], v134[2])
				else
					v_u_7[v134[1]] = nil
				end
			end
		end
	end)
	v_u_5.Added:Connect(function(p_u_135, p_u_136)
		-- upvalues: (ref) v_u_6, (ref) v_u_46, (ref) v_u_7, (ref) v_u_8, (ref) v_u_3
		local v_u_137 = v_u_6[p_u_135]
		if v_u_137 and v_u_137.rig ~= p_u_136 then
			task.delay(0.6, function()
				-- upvalues: (ref) v_u_6, (copy) p_u_135, (copy) v_u_137, (copy) p_u_136, (ref) v_u_46
				if v_u_6[p_u_135] == v_u_137 and p_u_136.Parent then
					v_u_46(p_u_135, p_u_136)
				end
			end)
		end
		local v138 = false
		for _, v139 in v_u_7 do
			if type(v139) ~= "table" or v139.id ~= p_u_135 then
				continue
			end
			v138 = true
		end
		if v138 then
			task.delay(0.4, function()
				-- upvalues: (ref) v_u_6, (copy) p_u_135, (copy) p_u_136, (ref) v_u_46, (ref) v_u_7, (ref) v_u_8, (ref) v_u_3
				if not v_u_6[p_u_135] and p_u_136.Parent then
					v_u_46(p_u_135, p_u_136)
				end
				local v140 = {}
				for v141, v142 in v_u_7 do
					if type(v142) ~= "table" or (v142.id ~= p_u_135 or not v141.Parent) then
						continue
					end
					table.insert(v140, { v141, v142 })
				end
				for _, v143 in v140 do
					v_u_7[v143[1]] = nil
					v_u_8[v143[1]] = nil
					v_u_3.Apply(v143[1], v143[2])
				end
			end)
		end
	end)
end
return v_u_3