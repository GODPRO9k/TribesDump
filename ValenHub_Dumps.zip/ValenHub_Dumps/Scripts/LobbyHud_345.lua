local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Signal"))
local v_u_6 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Keybinds"))
return {
	["Init"] = function(p_u_7) -- name: Init
		-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_3, (copy) v_u_1, (copy) v_u_6, (copy) v_u_4
		local v_u_8 = p_u_7.UI
		local v_u_9 = p_u_7.Theme
		local v_u_10 = p_u_7.State
		local v_u_11 = v_u_9.Colors
		local v12 = v_u_9.Fonts
		local v13 = v_u_2.LocalPlayer
		local v_u_14 = v_u_8.new("Frame", {
			["Name"] = "LobbyHud",
			["Size"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = p_u_7.Canvas.HUD
		})
		local v_u_15 = v_u_8.Panel({
			["Name"] = "PlayerChip",
			["Size"] = nil,
			["BackgroundTransparency"] = 0.22,
			["Trim"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(340, 78),
			["Trim"] = v_u_11.Accent,
			["Parent"] = v_u_14
		})
		local v_u_16 = require(script.Parent.Parent.RankArt)
		local v_u_17 = v_u_16.Ranks
		local v18 = v_u_16.Emblem
		local v19 = v_u_17.RankOf
		local v20 = v_u_10.Get
		local v21 = tonumber(v20("Trophies"))
		if not v21 then
			if v_u_10.Profile then
				local v22 = v_u_10.Profile.trophies
				v21 = tonumber(v22) or 0
			else
				v21 = 0
			end
		end
		local v_u_23 = v18(v19(v21), 64, {
			["Name"] = "RankEmblem",
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Parent"] = v_u_15
		})
		local v_u_24 = v_u_8.new("TextLabel", {
			["Name"] = "PlayerName",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 22,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Text"] = v13.DisplayName,
			["FontFace"] = v12.Heavy,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v_u_15
		})
		v_u_8.TextStroke(v_u_11.Void, 1.5, 0.4).Parent = v_u_24
		local v_u_25 = v_u_8.new("Frame", {
			["Name"] = "StreakSlot",
			["AnchorPoint"] = nil,
			["BackgroundTransparency"] = 1,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Parent"] = v_u_15
		})
		local v_u_26 = v_u_8.new("Frame", {
			["Name"] = "RankRow",
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["BackgroundTransparency"] = 1,
			["ZIndex"] = 3,
			v_u_8.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
			["Parent"] = v_u_15
		})
		local v_u_27 = v_u_8.new("TextLabel", {
			["Name"] = "RankName",
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 16,
			["LayoutOrder"] = 1,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromScale(0, 1),
			["FontFace"] = v12.Heavy,
			["Parent"] = v_u_26
		})
		v_u_8.TextStroke(v_u_11.Void, 1.5, 0.35).Parent = v_u_27
		v_u_16.Trophy(16, {
			["LayoutOrder"] = 2,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Parent"] = v_u_26
		})
		local v_u_28 = v_u_8.new("TextLabel", {
			["Name"] = "Trophies",
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["Text"] = "0",
			["FontFace"] = nil,
			["TextSize"] = 17,
			["TextColor3"] = nil,
			["LayoutOrder"] = 3,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromScale(0, 1),
			["FontFace"] = v12.Display,
			["TextColor3"] = v_u_11.Text,
			["Parent"] = v_u_26
		})
		v_u_8.TextStroke(v_u_11.Void, 1.5, 0.35).Parent = v_u_28
		local v_u_29 = v_u_8.new("Frame", {
			["Name"] = "LevelPill",
			["AnchorPoint"] = Vector2.new(1, 0),
			["BackgroundColor3"] = v_u_11.Inset,
			["BackgroundTransparency"] = 0.15,
			["ClipsDescendants"] = true,
			["ZIndex"] = 3,
			v_u_8.Corner(v_u_9.Radius.Pill),
			["Parent"] = v_u_15
		})
		v_u_8.Stroke(v_u_11.Xp, 1, 0.55).Parent = v_u_29
		local v30 = v_u_8.new("Frame", {
			["Name"] = "Fill",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["ZIndex"] = 3,
			v_u_8.Corner(v_u_9.Radius.Pill),
			["Parent"] = v_u_29
		})
		local v_u_31 = v_u_8.Gradient(v_u_9.Lighten(v_u_11.Xp, 0.2), v_u_11.Xp, 0)
		v_u_31.Parent = v30
		local v_u_32 = Instance.new("NumberValue")
		local function v43() -- name: paintLevelFill
			-- upvalues: (copy) v_u_32, (copy) v_u_31
			local v33 = v_u_32.Value
			local v34 = math.clamp(v33, 0, 1)
			local v35 = v_u_31
			local v36
			if v34 <= 0.002 then
				v36 = NumberSequence.new(1)
			elseif v34 >= 0.998 then
				v36 = NumberSequence.new(0)
			else
				local v37 = NumberSequence.new
				local v38 = {}
				local v39 = NumberSequenceKeypoint.new(0, 0)
				local v40 = NumberSequenceKeypoint.new(v34, 0)
				local v41 = NumberSequenceKeypoint.new
				local v42 = v34 + 0.002
				__set_list(v38, 1, {v39, v40, v41(math.min(v42, 1), 1), NumberSequenceKeypoint.new(1, 1)})
				v36 = v37(v38)
			end
			v35.Transparency = v36
		end
		v_u_32.Changed:Connect(v43)
		v43()
		local v_u_44 = v_u_8.new("TextLabel", {
			["Name"] = "Level",
			["Size"] = nil,
			["Text"] = "LV 1",
			["FontFace"] = nil,
			["TextSize"] = 15,
			["TextColor3"] = nil,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["FontFace"] = v12.Display,
			["TextColor3"] = v_u_11.Text,
			["Parent"] = v_u_29
		})
		v_u_8.TextStroke(v_u_11.Void, 1.5, 0.3).Parent = v_u_44
		local v_u_45 = v_u_8.Bar({
			["Name"] = "RankBar",
			["Color"] = nil,
			["Parent"] = nil,
			["Color"] = v_u_11.Accent,
			["Parent"] = v_u_15
		})
		v_u_45.Frame.ZIndex = 3
		v_u_45.Fill.ZIndex = 3
		local function v_u_47() -- name: streakShown
			-- upvalues: (copy) v_u_25
			for _, v46 in v_u_25:GetChildren() do
				if not (v46:IsA("GuiObject") and v46.Visible) then
					continue
				end
				return true
			end
			return false
		end
		local v_u_48 = game:GetService("TextService")
		local v_u_49 = {
			["name"] = 16,
			["trophies"] = 17
		}
		local v_u_50 = 0
		local v_u_51 = 0
		local function v_u_93(p52) -- name: layoutChip
			-- upvalues: (copy) v_u_23, (copy) v_u_24, (copy) v_u_26, (copy) v_u_49, (copy) v_u_47, (copy) v_u_25, (copy) v_u_29, (copy) v_u_44, (ref) v_u_50, (ref) v_u_51, (copy) v_u_48, (copy) v_u_15, (copy) v_u_27, (copy) v_u_28, (copy) v_u_45
			local v53, v54, v55, v56, v57, v58, v59, v60, v61, v62, v63, v64, v65, v66
			if p52 then
				v53 = 56
				v54 = 6
				v55 = 58
				v56 = 25
				v57 = 69
				v58 = 5
				v59 = 31
				v60 = 18
				v61 = 72
				v62 = 55
				v63 = 8
				v64 = 5
				v65 = 10
				v66 = 24
			else
				v53 = 64
				v54 = 7
				v55 = 66
				v56 = 27
				v57 = 80
				v58 = 7
				v59 = 35
				v60 = 20
				v61 = 78
				v62 = 61
				v63 = 9
				v64 = 6
				v65 = 12
				v66 = 26
			end
			v_u_23.Size = UDim2.fromOffset(v53, v53)
			v_u_23.AnchorPoint = Vector2.new(0, 0.5)
			v_u_23.Position = UDim2.new(0, v54, 0.5, 0)
			v_u_24.TextSize = p52 and 20 or 22
			v_u_24.Position = UDim2.fromOffset(v57, v58)
			v_u_26.Position = UDim2.fromOffset(v57, v59)
			v_u_26.Size = UDim2.fromOffset(0, v60)
			v_u_49.name = p52 and 15 or 16
			v_u_49.trophies = p52 and 16 or 17
			local v67 = v_u_47()
			v_u_25.Visible = v67
			v_u_25.Size = UDim2.fromOffset(v55, v56)
			v_u_29.Size = UDim2.fromOffset(v55, v56)
			v_u_44.TextSize = p52 and 14 or 15
			if v67 then
				local v68 = (v61 - v56 * 2 - v64) / 2
				local v69 = math.floor(v68)
				v_u_25.Position = UDim2.new(1, -v65, 0, v69)
				v_u_29.Position = UDim2.new(1, -v65, 0, v69 + v56 + v64)
			else
				local v70 = v_u_29
				local v71 = UDim2.new
				local v72 = -v65
				local v73 = (v61 - v56) / 2
				v70.Position = v71(1, v72, 0, (math.floor(v73)))
			end
			local v74 = v65 + v55 + 12
			v_u_50 = v57 + v74
			v_u_51 = v_u_51 + 1
			local v_u_75 = v_u_51
			task.spawn(function()
				-- upvalues: (ref) v_u_48, (ref) v_u_15, (ref) v_u_50, (ref) v_u_49, (ref) v_u_27, (ref) v_u_28, (copy) v_u_75, (ref) v_u_51
				local v76 = v_u_15.Size.X.Offset - v_u_50
				local v77 = v_u_49.name
				local v78 = v_u_49.trophies
				while v77 > 11 do
					local v79 = v_u_27
					local v80 = Instance.new("GetTextBoundsParams")
					v80.Text = v79.Text
					v80.Font = v79.FontFace
					v80.Size = v77
					v80.Width = 1000
					local v81 = v_u_48.GetTextBoundsAsync
					local v82 = v_u_48
					local v83, v84 = pcall(v81, v82, v80)
					local v85 = not v83 and 0 or v84.X
					local v86 = v_u_28
					local v87 = Instance.new("GetTextBoundsParams")
					v87.Text = v86.Text
					v87.Font = v86.FontFace
					v87.Size = v78
					v87.Width = 1000
					local v88 = v_u_48.GetTextBoundsAsync
					local v89 = v_u_48
					local v90, v91 = pcall(v88, v89, v87)
					if v76 >= v85 + (not v90 and 0 or v91.X) + 16 + 12 then
						break
					end
					v77 = v77 - 1
					v78 = v78 - 1
				end
				if v_u_75 == v_u_51 then
					local v92 = v_u_28
					v_u_27.TextSize = v77
					v92.TextSize = v78
				end
			end)
			v_u_24.Size = UDim2.new(1, -v57 - v74, 0, v66)
			v_u_45.Frame.Position = UDim2.fromOffset(v57, v62)
			v_u_45.Frame.Size = UDim2.new(1, -v57 - v74, 0, v63)
		end
		local v_u_94 = false
		local function v96(p95) -- name: watchStreak
			-- upvalues: (copy) v_u_93, (ref) v_u_94
			if p95:IsA("GuiObject") then
				p95:GetPropertyChangedSignal("Visible"):Connect(function()
					-- upvalues: (ref) v_u_93, (ref) v_u_94
					v_u_93(v_u_94)
				end)
				v_u_93(v_u_94)
			end
		end
		v_u_25.ChildAdded:Connect(v96)
		local v_u_97 = v_u_94
		local v_u_98 = v_u_51
		local v_u_99 = v_u_50
		for _, v100 in v_u_25:GetChildren() do
			v96(v100)
		end
		local v101 = v_u_8.new("TextButton", {
			["Name"] = "OpenCard",
			["Size"] = nil,
			["BackgroundTransparency"] = 1,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["ZIndex"] = 6,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v_u_15
		})
		local v_u_102 = v_u_15:FindFirstChildOfClass("UIStroke")
		local v_u_103 = not v_u_102 and 0.9 or v_u_102.Transparency
		local v_u_104
		if v_u_102 then
			v_u_104 = v_u_102.Color
		else
			v_u_104 = v_u_11.Stroke
		end
		local v_u_105 = false
		local function v_u_113(p106) -- name: paintHover
			-- upvalues: (copy) v_u_102, (copy) v_u_8, (copy) v_u_9, (ref) v_u_105, (copy) v_u_11, (copy) v_u_104, (copy) v_u_103, (copy) v_u_15
			if v_u_102 then
				local v107 = v_u_8.Tween
				local v108 = v_u_102
				local v109 = v_u_9.Tween.Fast
				local v110 = {}
				local v111
				if v_u_105 or p106 then
					v111 = v_u_11.Accent
				else
					v111 = v_u_104
				end
				v110.Color = v111
				v110.Transparency = p106 and 0.1 or (v_u_105 and 0.35 or v_u_103)
				v107(v108, v109, v110)
			end
			local v112 = {
				["BackgroundTransparency"] = p106 and 0.3 or (v_u_105 and 0.12 or 0.22)
			}
			v_u_8.Tween(v_u_15, v_u_9.Tween.Fast, v112)
		end
		v101.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_105, (copy) v_u_8, (copy) p_u_7, (copy) v_u_113
			v_u_105 = true
			if not v_u_8.Touch then
				p_u_7.Sounds.Play("Hover")
			end
			v_u_113()
		end)
		v101.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_105, (copy) v_u_113
			v_u_105 = false
			v_u_113()
		end)
		v101.MouseButton1Down:Connect(function()
			-- upvalues: (copy) v_u_113
			v_u_113(true)
		end)
		v101.MouseButton1Up:Connect(function()
			-- upvalues: (copy) v_u_113
			v_u_113()
		end)
		v101.Activated:Connect(function()
			-- upvalues: (ref) v_u_105, (copy) v_u_113, (copy) p_u_7
			v_u_105 = false
			v_u_113()
			p_u_7.Sounds.Play("Click")
			p_u_7.MenuManager.Toggle("Ranks")
		end)
		local v_u_114 = -1
		local v_u_115 = -1
		local function v_u_145() -- name: refreshRank
			-- upvalues: (copy) v_u_10, (ref) v_u_114, (copy) v_u_17, (copy) v_u_16, (copy) v_u_23, (copy) v_u_27, (copy) v_u_28, (copy) v_u_8, (ref) v_u_98, (copy) v_u_48, (copy) v_u_15, (ref) v_u_99, (copy) v_u_49, (copy) v_u_45, (copy) v_u_9, (ref) v_u_115
			local v116 = 0
			local v117 = v_u_10.Get
			local v118 = tonumber(v117("Trophies"))
			if not v118 then
				if v_u_10.Profile then
					local v119 = v_u_10.Profile.trophies
					v118 = tonumber(v119) or 0
				else
					v118 = 0
				end
			end
			local v120 = math.floor(v118)
			local v121 = math.max(v116, v120)
			if v121 ~= v_u_114 then
				local v122, v123, v124 = v_u_17.Progress(v121)
				local v125 = v_u_16.Color(v122)
				v_u_16.SetEmblem(v_u_23, v122)
				v_u_27.Text = string.upper(v_u_17.Get(v122).name)
				v_u_27.TextColor3 = v125
				v_u_28.Text = v_u_8.FormatNumber(v121)
				v_u_98 = v_u_98 + 1
				local v_u_126 = v_u_98
				task.spawn(function()
					-- upvalues: (ref) v_u_48, (ref) v_u_15, (ref) v_u_99, (ref) v_u_49, (ref) v_u_27, (ref) v_u_28, (copy) v_u_126, (ref) v_u_98
					local v127 = v_u_15.Size.X.Offset - v_u_99
					local v128 = v_u_49.name
					local v129 = v_u_49.trophies
					while v128 > 11 do
						local v130 = v_u_27
						local v131 = Instance.new("GetTextBoundsParams")
						v131.Text = v130.Text
						v131.Font = v130.FontFace
						v131.Size = v128
						v131.Width = 1000
						local v132 = v_u_48.GetTextBoundsAsync
						local v133 = v_u_48
						local v134, v135 = pcall(v132, v133, v131)
						local v136 = not v134 and 0 or v135.X
						local v137 = v_u_28
						local v138 = Instance.new("GetTextBoundsParams")
						v138.Text = v137.Text
						v138.Font = v137.FontFace
						v138.Size = v129
						v138.Width = 1000
						local v139 = v_u_48.GetTextBoundsAsync
						local v140 = v_u_48
						local v141, v142 = pcall(v139, v140, v138)
						if v127 >= v136 + (not v141 and 0 or v142.X) + 16 + 12 then
							break
						end
						v128 = v128 - 1
						v129 = v129 - 1
					end
					if v_u_126 == v_u_98 then
						local v143 = v_u_28
						v_u_27.TextSize = v128
						v143.TextSize = v129
					end
				end)
				local v144 = v_u_45.Fill:FindFirstChildOfClass("UIGradient")
				if v144 then
					v144.Color = ColorSequence.new(v_u_9.Lighten(v125, 0.2), v125)
				end
				v_u_45.Set((not v124 or v124 <= 0) and 1 or v123 / v124, v_u_114 < 0)
				if v_u_114 >= 0 then
					if v_u_115 < v122 then
						v_u_8.Pop(v_u_23, 1.4)
					else
						v_u_8.Bump(v_u_28, 0.12)
					end
				end
				v_u_114 = v121
				v_u_115 = v122
			end
		end
		v_u_145()
		v_u_10.AttrChanged:Connect(function(p146)
			-- upvalues: (copy) v_u_145
			if p146 == "Trophies" then
				v_u_145()
			end
		end)
		v_u_10.ProfileChanged:Connect(v_u_145)
		local v_u_147 = v_u_8.Panel({
			["Name"] = "ShellsPill",
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Radius"] = nil,
			["BackgroundTransparency"] = 0.22,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Size"] = UDim2.fromOffset(0, 48),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Radius"] = v_u_9.Radius.Pill,
			["Parent"] = v_u_14
		})
		v_u_8.Padding(0, 18, 0, 10).Parent = v_u_147
		local v_u_148, v149 = v_u_8.ShellAmount(v_u_10.Shells(), {
			["TextSize"] = 28,
			["Parent"] = nil,
			["Parent"] = v_u_147
		})
		v_u_148.AnchorPoint = Vector2.new(0, 0.5)
		v_u_148.Position = UDim2.fromScale(0, 0.5)
		local v_u_150 = v_u_8.CountUp(v149)
		v_u_150(v_u_10.Shells(), true)
		v_u_147.Visible = v_u_9.ShowCurrency
		local v_u_151 = v_u_10.Shells()
		local v_u_152 = v_u_8.Button({
			["Name"] = "Play",
			["Text"] = "PLAY",
			["TextSize"] = 46,
			["Style"] = "Primary",
			["Size"] = nil,
			["AnchorPoint"] = nil,
			["Radius"] = 16,
			["Icon"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(300, 96),
			["AnchorPoint"] = Vector2.new(1, 1),
			["Icon"] = v_u_8.Image(v_u_8.Assets.Icons.CrossedArrows, {
				["Size"] = UDim2.fromOffset(36, 34),
				["ImageColor3"] = v_u_11.Text
			}),
			["Parent"] = v_u_14
		})
		local v_u_153 = v_u_8.new("TextLabel", {
			["Name"] = "Sub",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "3V3  \194\183  BEST OF 5",
			["FontFace"] = nil,
			["TextSize"] = 15,
			["TextColor3"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 1, 2),
			["Size"] = UDim2.new(1, 0, 0, 18),
			["FontFace"] = v12.Heavy,
			["TextColor3"] = v_u_11.TextDim,
			["Parent"] = v_u_152.Instance
		})
		v_u_8.TextStroke(v_u_11.Void, 1.5, 0.3).Parent = v_u_153
		local v_u_154 = 2
		local function v156()
			-- upvalues: (ref) v_u_154
			local v155 = require(game:GetService("ReplicatedStorage").Shared.Config).FIRST_MATCH_ROUNDS_TO_WIN
			v_u_154 = tonumber(v155) or v_u_154
		end
		pcall(v156)
		local v_u_157 = v_u_8.new("Frame", {
			["Name"] = "Pad",
			["Size"] = nil,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v_u_152.Face
		})
		v_u_8.PadActionCap("Play", {
			["Height"] = 28,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, -8, 0, 8),
			["Parent"] = v_u_157
		})
		local function v162() -- name: refreshPlaySub
			-- upvalues: (copy) v_u_10, (ref) v_u_154, (copy) v_u_153
			local v158 = v_u_10.Profile
			local v159 = v_u_10.HasProfile
			if v159 then
				if type(v158) == "table" then
					local v160 = v158.stats
					if type(v160) == "table" then
						v159 = v158.stats.matches == 0
					else
						v159 = false
					end
				else
					v159 = false
				end
			end
			local v161
			if v159 then
				v161 = v_u_154
			else
				v161 = v_u_10.DEFAULT_ROUNDS_TO_WIN
			end
			v_u_153.Text = string.format("3V3  \194\183  BEST OF %d", v161 * 2 - 1)
		end
		local v163 = v_u_10.Profile
		local v164 = v_u_10.HasProfile
		if v164 then
			if type(v163) == "table" then
				local v165 = v163.stats
				if type(v165) == "table" then
					v164 = v163.stats.matches == 0
				else
					v164 = false
				end
			else
				v164 = false
			end
		end
		local v166
		if v164 then
			v166 = v_u_154
		else
			v166 = v_u_10.DEFAULT_ROUNDS_TO_WIN
		end
		v_u_153.Text = string.format("3V3  \194\183  BEST OF %d", v166 * 2 - 1)
		v_u_10.ProfileChanged:Connect(v162)
		local v_u_167 = v_u_8.Button({
			["Name"] = "Loadout",
			["Text"] = "LOADOUT",
			["TextSize"] = 26,
			["Style"] = "Dark",
			["Size"] = nil,
			["Icon"] = nil,
			["Gap"] = 6,
			["Parent"] = nil,
			["OnClick"] = nil,
			["Size"] = UDim2.fromOffset(200, 66),
			["Icon"] = v_u_8.Image(v_u_8.Assets.Icons.LoadoutSword or v_u_8.Assets.Icons.Sword, {
				["Name"] = "Icon",
				["Size"] = nil,
				["ScaleType"] = nil,
				["Size"] = UDim2.fromOffset(40, 40),
				["ScaleType"] = Enum.ScaleType.Fit
			}),
			["Parent"] = v_u_14,
			["OnClick"] = function() -- name: OnClick
				-- upvalues: (copy) p_u_7
				p_u_7.MenuManager.Toggle("Loadout")
			end
		})
		v_u_8.PadCap(Enum.KeyCode.DPadLeft, {
			["Height"] = 24,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -10, 0.5, 0),
			["Parent"] = v_u_167.Face
		})
		local v_u_168 = v_u_167.Label
		v_u_168.RichText = true
		v_u_168.LineHeight = 0.92
		local function v171() -- name: refreshLoadoutLabel
			-- upvalues: (copy) v_u_10, (copy) v_u_168
			if v_u_10.HasLoadoutSlots() and v_u_10.LoadoutSlotCount() > 1 then
				local v169 = string.upper(v_u_10.LoadoutName(v_u_10.ActiveLoadout()))
				local v170 = string.gsub(string.gsub(string.gsub(v169, "&", "&amp;"), "<", "&lt;"), ">", "&gt;")
				v_u_168.Text = string.format("LOADOUT\n<font size=\"14\" color=\"#BAC0CE\">%s</font>", v170)
			else
				v_u_168.Text = "LOADOUT"
			end
		end
		v171()
		v_u_10.ProfileChanged:Connect(v171)
		local v_u_172 = game:GetService("GuiService")
		local v_u_173 = Instance.new("ScreenGui")
		v_u_173.Name = "TR_TopbarSettings"
		v_u_173.ResetOnSpawn = false
		v_u_173.IgnoreGuiInset = true
		v_u_173.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
		v_u_173.DisplayOrder = 8
		v_u_173.Parent = p_u_7.PlayerGui
		local v_u_174 = Instance.new("TextButton")
		v_u_174.Name = "Settings"
		v_u_174.Text = ""
		v_u_174.AutoButtonColor = false
		v_u_174.BackgroundColor3 = Color3.fromRGB(18, 18, 21)
		v_u_174.BackgroundTransparency = 0.08
		v_u_174.Size = UDim2.fromOffset(44, 44)
		v_u_174.Parent = v_u_173
		v_u_8.Corner(v_u_9.Radius.Pill).Parent = v_u_174
		local v_u_175 = v_u_8.new("Frame", {
			["Name"] = "State",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["BackgroundTransparency"] = 1,
			v_u_8.Corner(v_u_9.Radius.Pill),
			["Parent"] = v_u_174
		})
		local v_u_176 = v_u_8.new("TextLabel", {
			["Name"] = "Icon",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "gear",
			["FontFace"] = nil,
			["TextSize"] = 24,
			["TextColor3"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(24, 24),
			["FontFace"] = Font.new("rbxasset://LuaPackages/Packages/_Index/BuilderIcons/BuilderIcons/BuilderIcons.json", Enum.FontWeight.Regular),
			["TextColor3"] = Color3.fromRGB(247, 247, 248),
			["Parent"] = v_u_174
		})
		task.delay(3, function()
			-- upvalues: (copy) v_u_176, (copy) v_u_8, (copy) v_u_174
			local v177 = v_u_176.TextBounds.X
			if v177 < 1 or v177 > 32 then
				v_u_176.Visible = false
				v_u_8.Icon("gear", 24, Color3.fromRGB(247, 247, 248), {
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["HoleColor"] = Color3.fromRGB(18, 18, 21),
					["Parent"] = v_u_174
				})
			end
		end)
		v_u_8.KeyCap("M", {
			["Gamepad"] = nil,
			["Height"] = 17,
			["TextSize"] = 11,
			["Color"] = nil,
			["Transparency"] = 0.05,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Gamepad"] = Enum.KeyCode.ButtonSelect,
			["Color"] = Color3.fromRGB(18, 18, 21),
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(1, 5, 1, 1),
			["Parent"] = v_u_174
		})
		local v_u_178 = Instance.new("TextButton")
		v_u_178.Name = "News"
		v_u_178.Text = ""
		v_u_178.AutoButtonColor = false
		v_u_178.BackgroundColor3 = Color3.fromRGB(18, 18, 21)
		v_u_178.BackgroundTransparency = 0.08
		v_u_178.Size = UDim2.fromOffset(44, 44)
		v_u_178.Parent = v_u_173
		v_u_8.Corner(v_u_9.Radius.Pill).Parent = v_u_178
		local v_u_179 = v_u_8.new("Frame", {
			["Name"] = "State",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["BackgroundTransparency"] = 1,
			v_u_8.Corner(v_u_9.Radius.Pill),
			["Parent"] = v_u_178
		})
		v_u_8.Glyph("megaphone", 24, Color3.fromRGB(247, 247, 248), {
			["Name"] = "Icon",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Parent"] = v_u_178
		})
		local v_u_180 = false
		local v_u_181 = false
		local v_u_182 = Instance.new("TextButton")
		v_u_182.Name = "CustomHost"
		v_u_182.Text = ""
		v_u_182.AutoButtonColor = false
		v_u_182.BackgroundColor3 = Color3.fromRGB(18, 18, 21)
		v_u_182.BackgroundTransparency = 0.08
		v_u_182.Size = UDim2.fromOffset(44, 44)
		v_u_182.Visible = false
		v_u_182.Parent = v_u_173
		v_u_8.Corner(v_u_9.Radius.Pill).Parent = v_u_182
		local v_u_183 = v_u_8.new("Frame", {
			["Name"] = "State",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["BackgroundTransparency"] = 1,
			v_u_8.Corner(v_u_9.Radius.Pill),
			["Parent"] = v_u_182
		})
		v_u_8.Glyph("crown", 24, Color3.fromRGB(247, 247, 248), {
			["Name"] = "Icon",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Parent"] = v_u_182
		})
		v_u_8.ActionCap("CustomMenu", {
			["Gamepad"] = nil,
			["Height"] = 17,
			["TextSize"] = 11,
			["Color"] = nil,
			["Transparency"] = 0.05,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Gamepad"] = Enum.KeyCode.DPadDown,
			["Color"] = Color3.fromRGB(18, 18, 21),
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(1, 5, 1, 1),
			["Parent"] = v_u_182
		})
		local v_u_184 = v_u_5.new()
		local v_u_185 = false
		local v_u_186 = false
		local v_u_187 = false
		local v_u_188 = false
		local v_u_189 = {}
		local v_u_190 = game:GetService("UserInputService")
		local function v_u_191() -- name: paint
			-- upvalues: (copy) v_u_190, (ref) v_u_185, (ref) v_u_186, (ref) v_u_187, (ref) v_u_188, (ref) v_u_180, (ref) v_u_181, (copy) p_u_7, (copy) v_u_175, (copy) v_u_183, (copy) v_u_179
			if v_u_190.MouseBehavior ~= Enum.MouseBehavior.Default then
				v_u_185 = false
				v_u_186 = false
				v_u_187 = false
				v_u_188 = false
				v_u_180 = false
				v_u_181 = false
			end
			v_u_175.BackgroundTransparency = v_u_186 and 0.8 or ((v_u_185 or p_u_7.MenuManager.IsOpen("Settings")) and 0.9 or 1)
			v_u_183.BackgroundTransparency = v_u_188 and 0.8 or ((v_u_187 or p_u_7.MenuManager.IsOpen("CustomHost")) and 0.9 or 1)
			v_u_179.BackgroundTransparency = v_u_181 and 0.8 or (v_u_180 and 0.9 or 1)
		end
		v_u_190:GetPropertyChangedSignal("MouseBehavior"):Connect(v_u_191)
		local function v_u_208() -- name: place
			-- upvalues: (copy) v_u_172, (copy) v_u_174, (copy) v_u_178, (copy) v_u_182, (copy) v_u_8
			local v192 = v_u_172.TopbarInset
			local v193 = v192.Height
			local v194 = v193 - 14
			local v195 = math.clamp(v194, 28, 44)
			v_u_174.Size = UDim2.fromOffset(v195, v195)
			local v196 = v_u_174
			local v197 = UDim2.fromOffset
			local v198 = v192.Min.X + 8
			local v199 = v193 - 2 - v195
			v196.Position = v197(v198, (math.max(0, v199)))
			local v200 = v192.Min.X + 8 + v195 + 12
			v_u_178.Size = UDim2.fromOffset(v195, v195)
			local v201 = v_u_178
			local v202 = UDim2.fromOffset
			local v203 = v193 - 2 - v195
			v201.Position = v202(v200, (math.max(0, v203)))
			if v_u_178.Visible then
				v200 = v200 + (v195 + 12)
			end
			v_u_182.Size = UDim2.fromOffset(v195, v195)
			local v204 = v_u_182
			local v205 = UDim2.fromOffset
			local v206 = v193 - 2 - v195
			v204.Position = v205(v200, (math.max(0, v206)))
			local v207 = v195 + 8 + (not v_u_178.Visible and 0 or v195 + 12) + (not v_u_182.Visible and 0 or v195 + 12)
			if v_u_8.TopbarReserved ~= v207 then
				v_u_8.TopbarReserved = v207
				v_u_8.TopInsetChanged:Fire()
			end
		end
		v_u_208()
		v_u_172:GetPropertyChangedSignal("TopbarInset"):Connect(v_u_208)
		local v_u_209 = v_u_8.new("TextLabel", {
			["Name"] = "Text",
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 14,
			["TextColor3"] = nil,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromScale(0, 1),
			["FontFace"] = v12.SemiBold,
			["TextColor3"] = Color3.fromRGB(247, 247, 248)
		})
		local v_u_210 = v_u_8.new("Frame", {
			["Name"] = "Tooltip",
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromOffset(0, 30),
			["BackgroundColor3"] = Color3.fromRGB(18, 18, 21),
			["BackgroundTransparency"] = 0.08,
			["Visible"] = false,
			["ZIndex"] = 10,
			v_u_8.Corner(v_u_9.Radius.Pill),
			v_u_8.new("UIPadding", {
				["PaddingLeft"] = UDim.new(0, 12),
				["PaddingRight"] = UDim.new(0, 12)
			}),
			v_u_209,
			["Parent"] = v_u_173
		})
		v_u_209.ZIndex = 11
		local v_u_211 = {}
		local v_u_212 = nil
		local v_u_213 = false
		local v_u_214 = 0
		local function v225(p_u_215, p216) -- name: tooltip
			-- upvalues: (copy) v_u_211, (copy) v_u_8, (copy) v_u_190, (ref) v_u_214, (ref) v_u_212, (ref) v_u_213, (copy) v_u_173, (copy) v_u_209, (copy) v_u_210, (ref) v_u_3
			v_u_211[p_u_215] = p216
			p_u_215.MouseEnter:Connect(function()
				-- upvalues: (ref) v_u_8, (ref) v_u_190, (copy) p_u_215, (ref) v_u_214, (ref) v_u_212, (ref) v_u_213, (ref) v_u_173, (ref) v_u_209, (ref) v_u_211, (ref) v_u_210, (ref) v_u_3
				if not v_u_8.Touch and v_u_190.MouseBehavior == Enum.MouseBehavior.Default then
					local v_u_217 = p_u_215
					v_u_214 = v_u_214 + 1
					local v_u_218 = v_u_214
					v_u_212 = v_u_217
					v_u_213 = false
					task.delay(0.3, function()
						-- upvalues: (copy) v_u_218, (ref) v_u_214, (copy) v_u_217, (ref) v_u_173, (ref) v_u_209, (ref) v_u_211, (ref) v_u_210, (ref) v_u_3
						if v_u_218 == v_u_214 and (v_u_217.Visible and v_u_173.Enabled) then
							v_u_209.Text = v_u_211[v_u_217]
							local v219 = v_u_217.Position.X.Offset + v_u_217.Size.X.Offset / 2
							local v220 = v_u_217.Position.Y.Offset + v_u_217.Size.Y.Offset + 8
							v_u_210.Position = UDim2.fromOffset(v219, v220 - 4)
							local v221 = v_u_209
							v_u_210.BackgroundTransparency = 1
							v221.TextTransparency = 1
							v_u_210.Visible = true
							local v222 = TweenInfo.new(0.14, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
							v_u_3:Create(v_u_210, v222, {
								["Position"] = nil,
								["BackgroundTransparency"] = 0.08,
								["Position"] = UDim2.fromOffset(v219, v220)
							}):Play()
							v_u_3:Create(v_u_209, v222, {
								["TextTransparency"] = 0
							}):Play()
						end
					end)
				end
			end)
			p_u_215.MouseLeave:Connect(function()
				-- upvalues: (copy) p_u_215, (ref) v_u_212, (ref) v_u_214, (ref) v_u_213, (ref) v_u_210
				local v223 = p_u_215
				if not v223 or v_u_212 == v223 then
					v_u_214 = v_u_214 + 1
					v_u_212 = nil
					v_u_213 = false
					v_u_210.Visible = false
				end
			end)
			p_u_215.MouseButton1Down:Connect(function()
				-- upvalues: (ref) v_u_214, (ref) v_u_212, (ref) v_u_213, (ref) v_u_210
				v_u_214 = v_u_214 + 1
				v_u_212 = nil
				v_u_213 = false
				v_u_210.Visible = false
			end)
			p_u_215.Activated:Connect(function()
				-- upvalues: (ref) v_u_214, (ref) v_u_212, (ref) v_u_213, (ref) v_u_210
				v_u_214 = v_u_214 + 1
				v_u_212 = nil
				v_u_213 = false
				v_u_210.Visible = false
			end)
			p_u_215:GetPropertyChangedSignal("Visible"):Connect(function()
				-- upvalues: (copy) p_u_215, (ref) v_u_212, (ref) v_u_214, (ref) v_u_213, (ref) v_u_210
				if not p_u_215.Visible then
					local v224 = p_u_215
					if v224 and v_u_212 ~= v224 then
						return
					end
					v_u_214 = v_u_214 + 1
					v_u_212 = nil
					v_u_213 = false
					v_u_210.Visible = false
				end
			end)
		end
		v225(v_u_174, "Settings")
		v225(v_u_178, "What\'s New")
		v225(v_u_182, "Host Menu")
		v_u_172:GetPropertyChangedSignal("SelectedObject"):Connect(function()
			-- upvalues: (copy) v_u_172, (copy) v_u_211, (ref) v_u_214, (ref) v_u_212, (ref) v_u_213, (copy) v_u_173, (copy) v_u_209, (copy) v_u_210, (ref) v_u_3
			local v_u_226 = v_u_172.SelectedObject
			if v_u_226 and v_u_211[v_u_226] then
				v_u_214 = v_u_214 + 1
				local v_u_227 = v_u_214
				v_u_212 = v_u_226
				v_u_213 = true
				task.delay(0.1, function()
					-- upvalues: (copy) v_u_227, (ref) v_u_214, (copy) v_u_226, (ref) v_u_173, (ref) v_u_209, (ref) v_u_211, (ref) v_u_210, (ref) v_u_3
					if v_u_227 == v_u_214 and (v_u_226.Visible and v_u_173.Enabled) then
						v_u_209.Text = v_u_211[v_u_226]
						local v228 = v_u_226.Position.X.Offset + v_u_226.Size.X.Offset / 2
						local v229 = v_u_226.Position.Y.Offset + v_u_226.Size.Y.Offset + 8
						v_u_210.Position = UDim2.fromOffset(v228, v229 - 4)
						local v230 = v_u_209
						v_u_210.BackgroundTransparency = 1
						v230.TextTransparency = 1
						v_u_210.Visible = true
						local v231 = TweenInfo.new(0.14, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
						v_u_3:Create(v_u_210, v231, {
							["Position"] = nil,
							["BackgroundTransparency"] = 0.08,
							["Position"] = UDim2.fromOffset(v228, v229)
						}):Play()
						v_u_3:Create(v_u_209, v231, {
							["TextTransparency"] = 0
						}):Play()
					end
				end)
			elseif v_u_213 then
				v_u_214 = v_u_214 + 1
				v_u_212 = nil
				v_u_213 = false
				v_u_210.Visible = false
			end
		end)
		v_u_190:GetPropertyChangedSignal("MouseBehavior"):Connect(function()
			-- upvalues: (copy) v_u_190, (ref) v_u_214, (ref) v_u_212, (ref) v_u_213, (copy) v_u_210
			if v_u_190.MouseBehavior ~= Enum.MouseBehavior.Default then
				v_u_214 = v_u_214 + 1
				v_u_212 = nil
				v_u_213 = false
				v_u_210.Visible = false
			end
		end)
		p_u_7.MenuManager.Changed:Connect(function()
			-- upvalues: (ref) v_u_214, (ref) v_u_212, (ref) v_u_213, (copy) v_u_210
			v_u_214 = v_u_214 + 1
			v_u_212 = nil
			v_u_213 = false
			v_u_210.Visible = false
		end)
		v_u_174.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_185, (copy) v_u_191
			v_u_185 = true
			v_u_191()
		end)
		v_u_174.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_185, (ref) v_u_186, (copy) v_u_191
			v_u_185 = false
			v_u_186 = false
			v_u_191()
		end)
		v_u_174.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_186, (copy) v_u_191
			v_u_186 = true
			v_u_191()
		end)
		v_u_174.MouseButton1Up:Connect(function()
			-- upvalues: (ref) v_u_186, (copy) v_u_191
			v_u_186 = false
			v_u_191()
		end)
		v_u_174.Activated:Connect(function()
			-- upvalues: (copy) p_u_7
			p_u_7.Sounds.Play("Click")
			p_u_7.MenuManager.Toggle("Settings")
		end)
		v_u_178.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_180, (copy) v_u_191
			v_u_180 = true
			v_u_191()
		end)
		v_u_178.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_180, (ref) v_u_181, (copy) v_u_191
			v_u_180 = false
			v_u_181 = false
			v_u_191()
		end)
		v_u_178.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_181, (copy) v_u_191
			v_u_181 = true
			v_u_191()
		end)
		v_u_178.MouseButton1Up:Connect(function()
			-- upvalues: (ref) v_u_181, (copy) v_u_191
			v_u_181 = false
			v_u_191()
		end)
		v_u_178.Activated:Connect(function()
			-- upvalues: (copy) p_u_7
			p_u_7.Sounds.Play("Click")
			p_u_7.MenuManager.Open("News")
		end)
		v_u_182.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_187, (copy) v_u_191
			v_u_187 = true
			v_u_191()
		end)
		v_u_182.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_187, (ref) v_u_188, (copy) v_u_191
			v_u_187 = false
			v_u_188 = false
			v_u_191()
		end)
		v_u_182.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_188, (copy) v_u_191
			v_u_188 = true
			v_u_191()
		end)
		v_u_182.MouseButton1Up:Connect(function()
			-- upvalues: (ref) v_u_188, (copy) v_u_191
			v_u_188 = false
			v_u_191()
		end)
		v_u_182.Activated:Connect(function()
			-- upvalues: (copy) p_u_7, (copy) v_u_184
			p_u_7.Sounds.Play("Click")
			v_u_184:Fire()
		end)
		p_u_7.MenuManager.Changed:Connect(v_u_191)
		local v_u_236 = {
			["Button"] = v_u_174,
			["HostButton"] = v_u_182,
			["HostActivated"] = v_u_184,
			["SetHostVisible"] = function(p232) -- name: SetHostVisible
				-- upvalues: (copy) v_u_182, (copy) v_u_208, (copy) v_u_8
				if v_u_182.Visible ~= p232 then
					v_u_182.Visible = p232
					v_u_208()
					if p232 then
						v_u_8.Pop(v_u_182, 0.6)
					end
				end
			end,
			["NewsButton"] = v_u_178,
			["SetNewsVisible"] = function(p233) -- name: SetNewsVisible
				-- upvalues: (copy) v_u_178, (copy) v_u_208
				if v_u_178.Visible ~= p233 then
					v_u_178.Visible = p233
					v_u_208()
				end
			end,
			["Last"] = function() -- name: Last
				-- upvalues: (copy) v_u_182, (copy) v_u_178, (copy) v_u_174
				if v_u_182.Visible then
					return v_u_182
				elseif v_u_178.Visible then
					return v_u_178
				else
					return v_u_174
				end
			end,
			["SetHidden"] = function(p234, p235) -- name: SetHidden
				-- upvalues: (copy) v_u_189, (copy) v_u_173
				v_u_189[p234] = p235 and true or nil
				v_u_173.Enabled = next(v_u_189) == nil
			end
		}
		p_u_7.TopbarSettings = v_u_236
		local v_u_237 = v_u_8.Panel({
			["Name"] = "TrainingBanner",
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["BackgroundTransparency"] = 0.15,
			["Trim"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Size"] = UDim2.fromOffset(440, 64),
			["Trim"] = v_u_11.Accent,
			["Parent"] = v_u_14
		})
		local v_u_238 = v_u_8.Image(v_u_8.Assets.Icons.Sword, {
			["Name"] = "Icon",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ImageColor3"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 18, 0.5, 2),
			["Size"] = UDim2.fromOffset(34, 34),
			["ImageColor3"] = v_u_11.Accent,
			["Parent"] = v_u_237
		})
		local v_u_239 = v_u_8.new("TextLabel", {
			["Name"] = "Title",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "TRAINING",
			["FontFace"] = nil,
			["TextSize"] = 28,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(66, 8),
			["Size"] = UDim2.new(1, -82, 0, 30),
			["FontFace"] = v12.Display,
			["TextColor3"] = v_u_11.Accent,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v_u_237
		})
		v_u_8.TextStroke(v_u_11.Void, 2, 0.2).Parent = v_u_239
		local v_u_240 = v_u_8.new("TextLabel", {
			["Name"] = "Sub",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 15,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(66, 38),
			["Size"] = UDim2.new(1, -82, 0, 18),
			["FontFace"] = v12.Bold,
			["TextColor3"] = v_u_11.TextDim,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v_u_237
		})
		local v_u_241 = v_u_8.Panel({
			["Name"] = "Matchmaking",
			["Size"] = nil,
			["Radius"] = nil,
			["BackgroundTransparency"] = 0.06,
			["StrokeColor"] = nil,
			["StrokeTransparency"] = 0.3,
			["StrokeThickness"] = 2,
			["Visible"] = false,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(300, 96),
			["Radius"] = UDim.new(0, 16),
			["StrokeColor"] = v_u_11.Accent,
			["Parent"] = v_u_14
		})
		local v_u_242 = v_u_241:FindFirstChildOfClass("UIGradient")
		local v_u_243 = v_u_241:FindFirstChildOfClass("UIStroke")
		local v_u_244 = v_u_8.new("TextLabel", {
			["Name"] = "Title",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "FINDING MATCH",
			["FontFace"] = nil,
			["TextSize"] = 24,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(18, 12),
			["Size"] = UDim2.new(1, -120, 0, 28),
			["FontFace"] = v12.Heavy,
			["TextColor3"] = v_u_11.Text,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v_u_241
		})
		local v_u_245 = v_u_8.new("TextLabel", {
			["Name"] = "Timer",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "0:00",
			["FontFace"] = nil,
			["TextSize"] = 30,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, -18, 0, 9),
			["Size"] = UDim2.fromOffset(96, 34),
			["FontFace"] = v12.Display,
			["TextColor3"] = v_u_11.Accent,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["Parent"] = v_u_241
		})
		local v_u_246 = v_u_8.new("TextLabel", {
			["Name"] = "Found",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "MATCH FOUND",
			["FontFace"] = nil,
			["TextSize"] = 36,
			["TextColor3"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 8),
			["Size"] = UDim2.new(1, -24, 0, 40),
			["FontFace"] = v12.Display,
			["TextColor3"] = v_u_11.Text,
			["Parent"] = v_u_241
		})
		local v_u_247 = v_u_8.new("Frame", {
			["Name"] = "Seats",
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 18, 1, -20),
			["Size"] = UDim2.fromOffset(0, 16),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			v_u_8.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
			["Parent"] = v_u_241
		})
		local v_u_248 = Color3.fromRGB(58, 63, 78)
		local v_u_249 = {}
		for v250 = 1, 6 do
			v_u_249[v250] = v_u_8.new("Frame", {
				["Name"] = "Seat" .. v250,
				["Size"] = UDim2.fromOffset(16, 16),
				["BackgroundColor3"] = v_u_248,
				["LayoutOrder"] = v250,
				v_u_8.Corner(v_u_9.Radius.Pill),
				["Parent"] = v_u_247
			})
		end
		local v_u_251 = v_u_8.new("TextLabel", {
			["Name"] = "Count",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "1/6 PLAYERS",
			["FontFace"] = nil,
			["TextSize"] = 18,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(1, -18, 1, -16),
			["Size"] = UDim2.fromOffset(140, 24),
			["FontFace"] = v12.Bold,
			["TextColor3"] = v_u_11.TextDim,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["Parent"] = v_u_241
		})
		local v_u_252 = v_u_8.new("Frame", {
			["Name"] = "Scan",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ClipsDescendants"] = true,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, -5),
			["Size"] = UDim2.new(1, -32, 0, 3),
			["Parent"] = v_u_241
		})
		local v_u_253 = v_u_8.new("Frame", {
			["Name"] = "Bar",
			["BackgroundColor3"] = v_u_11.Accent,
			["Size"] = UDim2.fromScale(0.3, 1),
			["Position"] = UDim2.fromScale(-0.3, 0),
			v_u_8.Corner(v_u_9.Radius.Pill),
			["Parent"] = v_u_252
		})
		local v_u_254 = v_u_8.Button({
			["Name"] = "Cancel",
			["Text"] = "CANCEL",
			["TextSize"] = 22,
			["Style"] = "Dark",
			["Size"] = nil,
			["Icon"] = nil,
			["Visible"] = false,
			["Sound"] = false,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(300, 54),
			["Icon"] = v_u_8.Icon("cross", 18, v_u_11.TextDim),
			["Parent"] = v_u_14
		})
		local v_u_255 = v_u_8.new("Frame", {
			["Name"] = "Pad",
			["Size"] = nil,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v_u_254.Face
		})
		v_u_8.PadActionCap("Play", {
			["Height"] = 24,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -10, 0.5, 0),
			["Parent"] = v_u_255
		})
		local v_u_256 = {}
		local v_u_257 = {}
		local v_u_258 = Vector2.zero
		local v_u_259 = TweenInfo.new(0.28, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
		local function v_u_267(p260, p261, p262, p263) -- name: homeRect
			local v264 = p260.AbsoluteSize / p262
			local v265 = p261.X.Scale * p263.X + p261.X.Offset - p260.AnchorPoint.X * v264.X
			local v266 = p261.Y.Scale * p263.Y + p261.Y.Offset - p260.AnchorPoint.Y * v264.Y
			return Rect.new(v265, v266, v265 + v264.X, v266 + v264.Y)
		end
		local function v_u_296() -- name: computeShift
			-- upvalues: (copy) v_u_8, (copy) v_u_14, (copy) v_u_256, (copy) v_u_267, (copy) v_u_152, (copy) v_u_241, (copy) v_u_254
			local v268 = v_u_8.ChatRectIn(v_u_14)
			if not v268 or (not v_u_14.Visible or v_u_8.Compact) then
				return Vector2.zero
			end
			local v269 = v_u_8.Scale
			local v270 = math.max(v269, 0.01)
			local v271 = v_u_14.AbsoluteSize / v270
			local v272 = nil
			for v273, v274 in v_u_256 do
				if not (v273.Visible and v273.Parent) then
					continue
				end
				local v275 = v_u_267(v273, v274, v270, v271)
				if v272 then
					local v276 = Rect.new
					local v277 = v272.Min.X
					local v278 = v275.Min.X
					local v279 = math.min(v277, v278)
					local v280 = v272.Min.Y
					local v281 = v275.Min.Y
					local v282 = math.min(v280, v281)
					local v283 = v272.Max.X
					local v284 = v275.Max.X
					local v285 = math.max(v283, v284)
					local v286 = v272.Max.Y
					local v287 = v275.Max.Y
					v272 = v276(v279, v282, v285, (math.max(v286, v287)))
				else
					v272 = v275
				end
			end
			if not v272 then
				return Vector2.zero
			end
			if v268.Max.X + 12 <= v272.Min.X or (v268.Min.X >= v272.Max.X + 12 or (v268.Max.Y + 12 <= v272.Min.Y or v268.Min.Y >= v272.Max.Y + 12)) then
				return Vector2.zero
			end
			local v288 = v271.X - 16
			for _, v289 in { v_u_152.Instance, v_u_241, v_u_254.Instance } do
				if not v289.Visible then
					continue
				end
				local v290 = (v289.AbsolutePosition.X - v_u_14.AbsolutePosition.X) / v270 - 12
				v288 = math.min(v288, v290)
			end
			local v291 = v268.Max.X + 12 - v272.Min.X
			if v272.Max.X + v291 <= v288 then
				return Vector2.new(v291, 0)
			end
			local v292
			if v_u_8.Touch then
				v292 = v271.Y * 0.62
			else
				v292 = v271.Y - 16
			end
			local v293 = v268.Max.Y + 12 - v272.Min.Y
			if v272.Max.Y + v293 <= v292 then
				return Vector2.new(0, v293)
			end
			local v294 = Vector2.new
			local v295 = v288 - v272.Max.X
			return v294(math.max(0, v295), 0)
		end
		local function v_u_303(p297) -- name: applyShift
			-- upvalues: (copy) v_u_256, (ref) v_u_258, (copy) v_u_257, (copy) v_u_14, (ref) v_u_3, (copy) v_u_259
			for v298, v299 in v_u_256 do
				local v300 = v299 + UDim2.fromOffset(v_u_258.X, v_u_258.Y)
				local v301 = v_u_257[v298]
				if v301 then
					v301:Cancel()
					v_u_257[v298] = nil
				end
				if p297 and (v298.Visible and v_u_14.Visible) then
					local v302 = v_u_3:Create(v298, v_u_259, {
						["Position"] = v300
					})
					v_u_257[v298] = v302
					v302:Play()
				else
					v298.Position = v300
				end
			end
		end
		local v_u_304 = false
		local function v306() -- name: queueRedodge
			-- upvalues: (ref) v_u_304, (copy) v_u_296, (ref) v_u_258, (copy) v_u_303
			if not v_u_304 then
				v_u_304 = true
				task.defer(function()
					-- upvalues: (ref) v_u_304, (ref) v_u_296, (ref) v_u_258, (ref) v_u_303
					v_u_304 = false
					local v305 = v_u_296()
					if (v305 - v_u_258).Magnitude > 1 then
						v_u_258 = v305
						v_u_303(true)
					end
				end)
			end
		end
		local function v311(p307, p308) -- name: place
			-- upvalues: (copy) v_u_256, (copy) v_u_257, (ref) v_u_258, (ref) v_u_304, (copy) v_u_296, (copy) v_u_303
			v_u_256[p307] = p308
			local v309 = v_u_257[p307]
			if v309 then
				v309:Cancel()
				v_u_257[p307] = nil
			end
			p307.Position = p308 + UDim2.fromOffset(v_u_258.X, v_u_258.Y)
			if not v_u_304 then
				v_u_304 = true
				task.defer(function()
					-- upvalues: (ref) v_u_304, (ref) v_u_296, (ref) v_u_258, (ref) v_u_303
					v_u_304 = false
					local v310 = v_u_296()
					if (v310 - v_u_258).Magnitude > 1 then
						v_u_258 = v310
						v_u_303(true)
					end
				end)
			end
		end
		local v_u_312 = nil
		local v_u_313 = v_u_5.new()
		local function v_u_344() -- name: phoneRow
			-- upvalues: (copy) v_u_8, (copy) v_u_14, (copy) v_u_236, (ref) v_u_1
			local v314 = v_u_8.Scale
			local v315 = math.max(v314, 0.01)
			local v316 = v_u_14.AbsoluteSize / v315
			local v317 = v_u_14.AbsolutePosition
			local v318 = v_u_236.Last()
			local v319 = v318:FindFirstAncestorOfClass("ScreenGui")
			local v320, v321, v322
			if v_u_8.DebugDevice or (not v319 or v318.AbsoluteSize.X < 1) then
				local v323 = v_u_8.TopInset() - 4
				local v324 = v_u_236.Button
				local v325
				if v318 == v324 or (v318.AbsoluteSize.X <= 0 or v324.AbsoluteSize.X <= 0) then
					v325 = 0
				else
					local v326 = v318.AbsolutePosition.X + v318.AbsoluteSize.X - (v324.AbsolutePosition.X + v324.AbsoluteSize.X)
					v325 = math.max(0, v326) / v315
				end
				local v327 = v323 * 6 + v325
				v320 = math.floor(v327)
				local v328 = v323 / 2
				v321 = math.floor(v328)
				v322 = v316.X - 16
			else
				v320 = (v318.AbsolutePosition.X + v318.AbsoluteSize.X - v317.X) / v315 + 10
				v321 = (v318.AbsolutePosition.Y + v318.AbsoluteSize.Y / 2 - v317.Y) / v315
				local v329 = v_u_1.TopbarInset
				if v329.Width > 0 then
					v322 = (v319.AbsolutePosition.X + v329.Max.X - v317.X) / v315 - 8
				else
					v322 = v316.X - 16
				end
			end
			local v330 = math.floor(v320)
			local v331 = math.max(v321, 38)
			local v332 = math.floor(v331)
			local v333 = v316.X - 16
			local v334 = (math.min(v322, v333) - v330 - 280 - 20) / 440
			local v335 = math.clamp(v334, 0.7, 1)
			local v336 = v330 + 280 + 10
			local v337 = v335 * 196
			local v338 = math.floor(v337)
			local v339 = v335 * 244
			local v340 = math.floor(v339)
			local v341 = v316.X - 16 - 272 - 44 - 10 - 254
			local v342 = math.min(v336, v341)
			local v343 = math.max(v330, v342)
			return {
				["x"] = nil,
				["y"] = nil,
				["h"] = 72,
				["chipW"] = 280,
				["loadoutX"] = nil,
				["loadoutW"] = nil,
				["cardX"] = nil,
				["cardW"] = nil,
				["restoreX"] = nil,
				["restoreY"] = nil,
				["restoreW"] = 254,
				["x"] = v330,
				["y"] = v332,
				["loadoutX"] = v336,
				["loadoutW"] = v338,
				["cardX"] = v336 + v338 + 10,
				["cardW"] = v340,
				["restoreX"] = v343,
				["restoreY"] = v332 + 36 + 8
			}
		end
		p_u_7.LobbyColumn = {
			["Place"] = v311,
			["Shift"] = function() -- name: Shift
				-- upvalues: (ref) v_u_258
				return v_u_258
			end,
			["Row"] = function() -- name: Row
				-- upvalues: (ref) v_u_312
				return v_u_312
			end,
			["RowChanged"] = v_u_313
		}
		v_u_8.ChatChanged:Connect(v306)
		v_u_14:GetPropertyChangedSignal("Visible"):Connect(function()
			-- upvalues: (copy) v_u_296, (ref) v_u_258, (copy) v_u_256, (copy) v_u_257
			local v345 = v_u_296()
			if (v345 - v_u_258).Magnitude > 1 then
				v_u_258 = v345
				for v346, v347 in v_u_256 do
					local v348 = v347 + UDim2.fromOffset(v_u_258.X, v_u_258.Y)
					local v349 = v_u_257[v346]
					if v349 then
						v349:Cancel()
						v_u_257[v346] = nil
					end
					v346.Position = v348
				end
			end
		end)
		local v_u_350 = "idle"
		local function v_u_380() -- name: layout
			-- upvalues: (copy) v_u_8, (copy) v_u_344, (ref) v_u_312, (copy) v_u_15, (ref) v_u_97, (copy) v_u_93, (copy) v_u_256, (copy) v_u_257, (ref) v_u_258, (ref) v_u_304, (copy) v_u_296, (copy) v_u_303, (copy) v_u_167, (copy) v_u_147, (copy) v_u_9, (copy) v_u_152, (copy) v_u_237, (copy) v_u_241, (copy) v_u_254, (copy) v_u_244, (copy) v_u_245, (copy) v_u_246, (copy) v_u_251, (copy) v_u_247, (copy) v_u_249, (ref) v_u_350
			local v351 = v_u_8.TopInset()
			if v_u_8.Compact then
				local v352 = v_u_344()
				v_u_312 = v352
				v_u_15.AnchorPoint = Vector2.new(0, 0.5)
				v_u_15.Size = UDim2.fromOffset(v352.chipW, v352.h)
				v_u_97 = true
				v_u_93(true)
				local v353 = v_u_15
				local v354 = UDim2.fromOffset(v352.x, v352.y)
				v_u_256[v353] = v354
				local v355 = v_u_257[v353]
				if v355 then
					v355:Cancel()
					v_u_257[v353] = nil
				end
				v353.Position = v354 + UDim2.fromOffset(v_u_258.X, v_u_258.Y)
				if not v_u_304 then
					v_u_304 = true
					task.defer(function()
						-- upvalues: (ref) v_u_304, (ref) v_u_296, (ref) v_u_258, (ref) v_u_303
						v_u_304 = false
						local v356 = v_u_296()
						if (v356 - v_u_258).Magnitude > 1 then
							v_u_258 = v356
							v_u_303(true)
						end
					end)
				end
				v_u_167.Instance.AnchorPoint = Vector2.new(0, 0.5)
				v_u_167.Instance.Size = UDim2.fromOffset(v352.loadoutW, v352.h)
				local v357 = v_u_167.Instance
				local v358 = UDim2.fromOffset(v352.loadoutX, v352.y)
				v_u_256[v357] = v358
				local v359 = v_u_257[v357]
				if v359 then
					v359:Cancel()
					v_u_257[v357] = nil
				end
				v357.Position = v358 + UDim2.fromOffset(v_u_258.X, v_u_258.Y)
				if not v_u_304 then
					v_u_304 = true
					task.defer(function()
						-- upvalues: (ref) v_u_304, (ref) v_u_296, (ref) v_u_258, (ref) v_u_303
						v_u_304 = false
						local v360 = v_u_296()
						if (v360 - v_u_258).Magnitude > 1 then
							v_u_258 = v360
							v_u_303(true)
						end
					end)
				end
				v_u_147.Position = UDim2.new(1, -16, 0, v351)
				local v361
				if v_u_9.ShowCurrency then
					v361 = v351 + 60
				else
					v361 = v351
				end
				local v362 = v352.y + v352.h / 2 + 8
				local v363 = math.max(v361, v362)
				v_u_152.Instance.AnchorPoint = Vector2.new(1, 0)
				v_u_152.Instance.Position = UDim2.new(1, -16, 0, v363)
				v_u_152.Instance.Size = UDim2.fromOffset(240, 84)
				v_u_237.Position = UDim2.new(0.5, 0, 0, v351)
				v_u_241.AnchorPoint = Vector2.new(1, 0)
				v_u_241.Position = UDim2.new(1, -16, 0, v363)
				v_u_241.Size = UDim2.fromOffset(272, 84)
				v_u_254.Instance.AnchorPoint = Vector2.new(1, 0)
				v_u_254.Instance.Position = UDim2.new(1, -16, 0, v363 + 94)
				v_u_254.Instance.Size = UDim2.fromOffset(272, 52)
				local v364 = v_u_245
				local v365 = v_u_246
				local v366 = v_u_251
				v_u_244.TextSize = 20
				v364.TextSize = 26
				v365.TextSize = 30
				v366.TextSize = 17
				v_u_244.Position = UDim2.fromOffset(16, 11)
				v_u_244.Size = UDim2.new(1, -96, 0, 28)
				v_u_245.Position = UDim2.new(1, -16, 0, 7)
				v_u_245.Size = UDim2.fromOffset(76, 34)
				v_u_247.Position = UDim2.new(0, 16, 1, -18)
				v_u_251.Position = UDim2.new(1, -16, 1, -14)
				for _, v367 in v_u_249 do
					v367.Size = UDim2.fromOffset(14, 14)
				end
				v_u_247:FindFirstChildOfClass("UIListLayout").Padding = UDim.new(0, 5)
			else
				v_u_312 = nil
				v_u_15.AnchorPoint = Vector2.new(0, 1)
				v_u_15.Size = UDim2.fromOffset(340, 78)
				v_u_97 = false
				v_u_93(false)
				local v368 = v_u_15
				local v369 = UDim2.new(0, 24, 1, -24)
				v_u_256[v368] = v369
				local v370 = v_u_257[v368]
				if v370 then
					v370:Cancel()
					v_u_257[v368] = nil
				end
				v368.Position = v369 + UDim2.fromOffset(v_u_258.X, v_u_258.Y)
				if not v_u_304 then
					v_u_304 = true
					task.defer(function()
						-- upvalues: (ref) v_u_304, (ref) v_u_296, (ref) v_u_258, (ref) v_u_303
						v_u_304 = false
						local v371 = v_u_296()
						if (v371 - v_u_258).Magnitude > 1 then
							v_u_258 = v371
							v_u_303(true)
						end
					end)
				end
				v_u_167.Instance.AnchorPoint = Vector2.new(0, 1)
				v_u_167.Instance.Size = UDim2.fromOffset(340, 66)
				local v372 = v_u_167.Instance
				local v373 = UDim2.new(0, 24, 1, -114)
				v_u_256[v372] = v373
				local v374 = v_u_257[v372]
				if v374 then
					v374:Cancel()
					v_u_257[v372] = nil
				end
				v372.Position = v373 + UDim2.fromOffset(v_u_258.X, v_u_258.Y)
				if not v_u_304 then
					v_u_304 = true
					task.defer(function()
						-- upvalues: (ref) v_u_304, (ref) v_u_296, (ref) v_u_258, (ref) v_u_303
						v_u_304 = false
						local v375 = v_u_296()
						if (v375 - v_u_258).Magnitude > 1 then
							v_u_258 = v375
							v_u_303(true)
						end
					end)
				end
				v_u_147.Position = UDim2.new(1, -24, 0, v351)
				v_u_152.Instance.AnchorPoint = Vector2.new(1, 1)
				v_u_152.Instance.Position = UDim2.new(1, -28, 1, -44)
				v_u_152.Instance.Size = UDim2.fromOffset(300, 96)
				v_u_237.Position = UDim2.new(0.5, 0, 0, v351)
				v_u_241.AnchorPoint = Vector2.new(1, 1)
				v_u_241.Position = UDim2.new(1, -28, 1, v_u_350 == "search" and -104 or -44)
				v_u_241.Size = UDim2.fromOffset(300, 96)
				v_u_254.Instance.AnchorPoint = Vector2.new(1, 1)
				v_u_254.Instance.Position = UDim2.new(1, -28, 1, -40)
				v_u_254.Instance.Size = UDim2.fromOffset(300, 54)
				local v376 = v_u_245
				local v377 = v_u_246
				local v378 = v_u_251
				v_u_244.TextSize = 24
				v376.TextSize = 30
				v377.TextSize = 36
				v378.TextSize = 18
				v_u_244.Position = UDim2.fromOffset(18, 12)
				v_u_244.Size = UDim2.new(1, -120, 0, 28)
				v_u_245.Position = UDim2.new(1, -18, 0, 9)
				v_u_245.Size = UDim2.fromOffset(96, 34)
				v_u_247.Position = UDim2.new(0, 18, 1, -20)
				v_u_251.Position = UDim2.new(1, -18, 1, -16)
				for _, v379 in v_u_249 do
					v379.Size = UDim2.fromOffset(16, 16)
				end
				v_u_247:FindFirstChildOfClass("UIListLayout").Padding = UDim.new(0, 6)
			end
		end
		local v_u_381 = false
		local function v382() -- name: relayout
			-- upvalues: (copy) v_u_380, (copy) v_u_313, (ref) v_u_312
			v_u_380()
			v_u_313:Fire(v_u_312)
		end
		local function v383() -- name: queueLayout
			-- upvalues: (ref) v_u_381, (copy) v_u_380, (copy) v_u_313, (ref) v_u_312
			if not v_u_381 then
				v_u_381 = true
				task.defer(function()
					-- upvalues: (ref) v_u_381, (ref) v_u_380, (ref) v_u_313, (ref) v_u_312
					v_u_381 = false
					v_u_380()
					v_u_313:Fire(v_u_312)
				end)
			end
		end
		v_u_380()
		v_u_313:Fire(v_u_312)
		v_u_8.LayoutChanged:Connect(v382)
		v_u_8.TopInsetChanged:Connect(v382)
		v_u_8.ScaleChanged:Connect(v383)
		v_u_236.Button:GetPropertyChangedSignal("AbsolutePosition"):Connect(v383)
		v_u_236.Button:GetPropertyChangedSignal("AbsoluteSize"):Connect(v383)
		v_u_236.HostButton:GetPropertyChangedSignal("Visible"):Connect(v383)
		v_u_236.NewsButton:GetPropertyChangedSignal("Visible"):Connect(v383)
		v_u_236.HostButton:GetPropertyChangedSignal("AbsolutePosition"):Connect(v383)
		v_u_14:GetPropertyChangedSignal("AbsoluteSize"):Connect(v383)
		if p_u_7.ToastAvoid then
			p_u_7.ToastAvoid("TrainingBanner", v_u_237)
		end
		local v_u_384 = v_u_10.Level()
		local function v_u_395() -- name: refreshProfile
			-- upvalues: (copy) v_u_10, (copy) v_u_44, (ref) v_u_384, (copy) v_u_8, (copy) v_u_29, (copy) p_u_7, (copy) v_u_32, (copy) v_u_9, (ref) v_u_151, (copy) v_u_150, (copy) v_u_148
			local v385 = v_u_10.Level()
			local v386 = v_u_10.Xp()
			local v387 = v_u_10.XpToNext()
			v_u_44.Text = "LV " .. tostring(v385)
			if v_u_384 < v385 then
				v_u_8.Pop(v_u_29, 1.5)
				p_u_7.Sounds.Play("LevelUp")
			end
			v_u_384 = v385
			local v388 = v_u_8.Tween
			local v389 = v_u_32
			local v390 = v_u_9.Tween.Slow
			local v391 = {}
			local v392
			if v387 > 0 then
				local v393 = v386 / v387
				v392 = math.clamp(v393, 0, 1)
			else
				v392 = 0
			end
			v391.Value = v392
			v388(v389, v390, v391)
			local v394 = v_u_10.Shells()
			if v394 ~= v_u_151 and v_u_9.ShowCurrency then
				v_u_150(v394)
				v_u_8.Bump(v_u_148, 0.12)
				if v_u_151 < v394 then
					p_u_7.Sounds.Play("Coin")
				end
				v_u_151 = v394
			end
		end
		v_u_395()
		v_u_10.ProfileChanged:Connect(v_u_395)
		v_u_10.AttrChanged:Connect(function(p396)
			-- upvalues: (copy) v_u_395
			if p396 == "Level" or (p396 == "XP" or p396 == "Shells") then
				v_u_395()
			end
		end)
		local v_u_397 = {}
		local v_u_398 = false
		local v_u_399 = 0
		local v_u_400 = 0
		local v_u_401 = false
		local v_u_402 = 0
		local v_u_403 = false
		local function v_u_411(p404, p405) -- name: seatsFilled
			-- upvalues: (copy) v_u_10
			local v406 = v_u_10.Get("QueueFilled")
			if v_u_10.Get("Queued") == true and (type(v406) == "number" and v406 >= 1) then
				local v407 = math.floor(v406)
				return math.clamp(v407, 1, 6)
			end
			local v408 = Random.new(p405)
			local v409 = 1
			local v410 = 0
			while v409 < 5 do
				v410 = v410 + v408:NextNumber(0.35, 0.95) * ((v409 - 1) * 0.45 + 1)
				if p404 < v410 then
					break
				end
				v409 = v409 + 1
			end
			return v409
		end
		local v_u_412 = 0
		local function v_u_421(p413, p414) -- name: paintSeats
			-- upvalues: (copy) v_u_249, (ref) v_u_350, (copy) v_u_11, (copy) v_u_248, (ref) v_u_412, (copy) v_u_8, (copy) v_u_9, (copy) p_u_7, (copy) v_u_251
			for v415, v416 in v_u_249 do
				local v417 = v415 <= p413
				local v418
				if v_u_350 == "found" then
					v418 = v_u_11.Text
				elseif v417 then
					v418 = v_u_11.Accent
				else
					v418 = v_u_248
				end
				if p414 and (v417 and v_u_412 < v415) then
					v416.BackgroundColor3 = v_u_11.Text
					v_u_8.Tween(v416, v_u_9.Tween.Smooth, {
						["BackgroundColor3"] = v418
					})
					v_u_8.Pop(v416, 1.8)
				else
					v416.BackgroundColor3 = v418
				end
			end
			if p414 and (v_u_412 < p413 and v_u_350 == "search") then
				p_u_7.Sounds.Play("Tick", {
					["pitch"] = p413 * 0.06 + 0.9
				})
			end
			v_u_412 = p413
			local v419 = v_u_251
			local v420
			if v_u_8.Compact then
				v420 = string.format("%d/%d", p413, 6)
			else
				v420 = string.format("%d/%d PLAYERS", p413, 6)
			end
			v419.Text = v420
		end
		local v_u_422 = nil
		local function v_u_425(p423) -- name: setScan
			-- upvalues: (ref) v_u_422, (copy) v_u_253, (copy) v_u_252
			if p423 and not v_u_422 then
				v_u_253.Position = UDim2.fromScale(-0.3, 0)
				local v424 = game:GetService("TweenService"):Create(v_u_253, TweenInfo.new(1.1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, false, 0.15), {
					["Position"] = UDim2.fromScale(1, 0)
				})
				v424:Play()
				v_u_422 = v424
			elseif not p423 and v_u_422 then
				v_u_422:Cancel()
				v_u_422 = nil
			end
			v_u_252.Visible = p423
		end
		local function v_u_433() -- name: paintCard
			-- upvalues: (ref) v_u_350, (copy) v_u_242, (copy) v_u_11, (copy) v_u_243, (copy) v_u_244, (copy) v_u_245, (copy) v_u_246, (copy) v_u_251
			local v426 = v_u_350 == "found"
			local v427 = v_u_242
			local v428
			if v426 then
				v428 = ColorSequence.new(Color3.fromRGB(64, 168, 255), Color3.fromRGB(28, 132, 246))
			else
				v428 = ColorSequence.new(v_u_11.Panel, v_u_11.PanelLo)
			end
			v427.Color = v428
			local v429 = v_u_243
			local v430
			if v426 then
				v430 = Color3.fromRGB(150, 210, 255)
			else
				v430 = v_u_11.Accent
			end
			v429.Color = v430
			v_u_243.Transparency = v426 and 0.4 or 0.3
			v_u_244.Visible = not v426
			v_u_245.Visible = not v426
			v_u_246.Visible = v426
			local v431 = v_u_251
			local v432
			if v426 then
				v432 = v_u_11.Text
			else
				v432 = v_u_11.TextDim
			end
			v431.TextColor3 = v432
		end
		local function v_u_440() -- name: tick
			-- upvalues: (ref) v_u_350, (copy) v_u_10, (ref) v_u_399, (copy) v_u_245, (copy) v_u_411, (ref) v_u_412, (copy) v_u_421
			if v_u_350 ~= "idle" then
				local v434 = v_u_10.Get("QueuedAt")
				if v_u_10.Get("Queued") ~= true or (type(v434) ~= "number" or v434 <= 0) then
					v434 = v_u_399
				end
				local v435 = v_u_10.Now() - v434
				local v436 = math.max(0, v435)
				v_u_245.Text = string.format("%d:%02d", v436 // 60, math.floor(v436) % 60)
				if v_u_350 == "search" then
					local v437 = v_u_411
					local v438 = v434 * 1000
					local v439 = v437(v436, math.floor(v438) % 2147483647)
					if v439 ~= v_u_412 then
						v_u_421(v439, true)
					end
				end
			end
		end
		local function v_u_459(p441) -- name: applyMode
			-- upvalues: (copy) v_u_10, (ref) v_u_401, (ref) v_u_398, (ref) v_u_350, (copy) v_u_380, (copy) v_u_152, (copy) v_u_397, (copy) v_u_241, (copy) v_u_254, (copy) v_u_425, (copy) v_u_433, (ref) v_u_412, (copy) v_u_249, (copy) v_u_11, (copy) v_u_248, (copy) v_u_251, (copy) v_u_8, (copy) v_u_9, (copy) v_u_440, (copy) v_u_246, (copy) p_u_7
			local v442 = (v_u_10.InMatch() or v_u_401) and "idle" or (v_u_10.Get("QueueFound") == true and (v_u_10.Get("Queued") == true or v_u_398) and "found" or ((v_u_10.Get("Queued") == true or v_u_398) and "search" or "idle"))
			if v442 == v_u_350 then
				return
			else
				local v443 = v_u_350
				v_u_350 = v442
				v_u_380()
				local v444 = v_u_152.Instance
				local v445
				if v_u_350 == "idle" then
					v445 = next(v_u_397) == nil
				else
					v445 = false
				end
				v444.Visible = v445
				v_u_241.Visible = v_u_350 ~= "idle"
				v_u_254.Instance.Visible = v_u_350 == "search"
				v_u_425(v_u_350 == "search")
				v_u_433()
				if v_u_350 == "search" then
					if v443 == "idle" then
						v_u_412 = 0
						for v446, v447 in v_u_249 do
							local v448 = v446 <= 1
							local v449
							if v_u_350 == "found" then
								v449 = v_u_11.Text
							elseif v448 then
								v449 = v_u_11.Accent
							else
								v449 = v_u_248
							end
							v447.BackgroundColor3 = v449
						end
						v_u_412 = 1
						local v450 = v_u_251
						local v451
						if v_u_8.Compact then
							v451 = string.format("%d/%d", 1, 6)
						else
							v451 = string.format("%d/%d PLAYERS", 1, 6)
						end
						v450.Text = v451
						if p441 then
							local v452 = v_u_241.Position
							if not v_u_8.Compact then
								v_u_241.Position = v_u_152.Instance.Position
							end
							v_u_8.Pop(v_u_241, 0.92)
							v_u_8.Tween(v_u_241, v_u_9.Tween.Smooth, {
								["Position"] = v452
							})
							v_u_8.Enter(v_u_254.Instance, Vector2.new(0, 16), 0.08, v_u_254.Instance.Position)
						end
					end
					v_u_440()
					return
				elseif v_u_350 == "found" then
					v_u_440()
					if not v_u_8.Compact and v443 == "search" then
						local v453 = v_u_241.Position
						v_u_241.Position = UDim2.new(1, -28, 1, -104)
						v_u_8.Tween(v_u_241, v_u_9.Tween.Smooth, {
							["Position"] = v453
						})
					end
					local v454 = v_u_412
					v_u_412 = 6
					for v455, v_u_456 in v_u_249 do
						if v454 < v455 then
							v_u_456.BackgroundColor3 = v_u_248
							task.delay((v455 - v454) * 0.06, function()
								-- upvalues: (ref) v_u_350, (copy) v_u_456, (ref) v_u_11, (ref) v_u_8
								if v_u_350 == "found" then
									v_u_456.BackgroundColor3 = v_u_11.Text
									v_u_8.Pop(v_u_456, 1.8)
								end
							end)
						else
							v_u_456.BackgroundColor3 = v_u_11.Text
						end
					end
					local v457 = v_u_251
					local v458
					if v_u_8.Compact then
						v458 = string.format("%d/%d", 6, 6)
					else
						v458 = string.format("%d/%d PLAYERS", 6, 6)
					end
					v457.Text = v458
					v_u_8.Pop(v_u_241, 1.12)
					v_u_8.Pop(v_u_246, 1.3)
					p_u_7.Sounds.Play("Match_Found")
					if p_u_7.MenuManager.IsOpen() then
						p_u_7.MenuManager.CloseAll()
					end
					p_u_7.MenuManager.EndHudFocus()
				elseif v443 ~= "idle" and (p441 and not v_u_10.InMatch()) then
					v_u_8.Pop(v_u_152.Instance, 0.92)
				end
			end
		end
		local function v_u_463() -- name: queue
			-- upvalues: (ref) v_u_403, (ref) v_u_350, (copy) v_u_397, (ref) v_u_398, (ref) v_u_399, (ref) v_u_400, (copy) v_u_10, (ref) v_u_401, (copy) p_u_7, (copy) v_u_459
			if not v_u_403 and (v_u_350 == "idle" and next(v_u_397) == nil) then
				v_u_403 = true
				local v460 = v_u_10.Now()
				local v461 = os.clock()
				v_u_398 = true
				v_u_399 = v460
				v_u_400 = v461
				v_u_401 = false
				p_u_7.Sounds.Play("Queue_Join")
				v_u_459(true)
				local v462 = p_u_7.QueueAction("Queue")
				v_u_403 = false
				if not v462 then
					v_u_398 = false
					v_u_459(true)
				end
			end
		end
		local function v_u_465() -- name: cancel
			-- upvalues: (ref) v_u_350, (ref) v_u_401, (ref) v_u_402, (ref) v_u_398, (copy) p_u_7, (copy) v_u_459
			if v_u_350 == "search" then
				local v464 = os.clock()
				v_u_401 = true
				v_u_402 = v464
				v_u_398 = false
				p_u_7.Sounds.Play("Queue_Leave")
				v_u_459(true)
				if not p_u_7.QueueAction("Cancel") then
					v_u_401 = false
					v_u_459(true)
				end
			end
		end
		v_u_152.Activated:Connect(v_u_463)
		v_u_254.Activated:Connect(v_u_465)
		v_u_6.OnInput("Began", function(p466)
			-- upvalues: (ref) v_u_6, (copy) p_u_7, (copy) v_u_14, (ref) v_u_4, (copy) v_u_10, (ref) v_u_350, (copy) v_u_465, (copy) v_u_152, (copy) v_u_463, (copy) v_u_254, (copy) v_u_167
			local v467 = p466.KeyCode
			local v468 = v_u_6.IsPad(p466, "Play")
			if not v468 and (v467 ~= Enum.KeyCode.DPadLeft and v467 ~= Enum.KeyCode.DPadRight) then
				return
			end
			local v469 = p_u_7.MenuManager
			if not v_u_14.Visible or (v469.IsOpen() or (v469.HasFocus() or v_u_4:GetFocusedTextBox())) then
				return
			end
			if not v468 or v_u_10.Get("CombatMode") == true then
				if v467 == Enum.KeyCode.DPadLeft or v467 == Enum.KeyCode.DPadRight then
					if v469.HudFocused() then
						return
					elseif not v_u_6.PadUsedIn(p466, v_u_10.Get("CombatMode") == true and "training" or "lobby") then
						local v470
						if v_u_254.Instance.Visible then
							v470 = v_u_254.Instance
						elseif v_u_152.Instance.Visible then
							v470 = v_u_152.Instance
						else
							v470 = v_u_167.Instance
						end
						local v471 = p_u_7.Party and p_u_7.Party.PadTarget
						if v471 then
							v471 = p_u_7.Party.PadTarget()
						end
						local v472 = v469.HudFocus
						local v473
						if v467 == Enum.KeyCode.DPadLeft then
							v473 = v_u_167.Instance
						else
							v473 = v471 or v470
						end
						v472(v473)
					end
				else
					return
				end
			end
			if v469.HudFocused() then
				if v467 == Enum.KeyCode.ButtonA or v467 == Enum.KeyCode.ButtonB then
					return
				else
					local v474 = v467.Name
					if string.sub(v474, 1, 4) == "DPad" then
						return
					elseif v_u_350 == "search" then
						task.spawn(v_u_465)
					elseif v_u_350 == "idle" and v_u_152.Instance.Visible then
						task.spawn(v_u_463)
					end
				end
			elseif v_u_350 == "search" then
				task.spawn(v_u_465)
			elseif v_u_350 == "idle" and v_u_152.Instance.Visible then
				task.spawn(v_u_463)
			end
		end)
		local v475 = v_u_10.Get("CombatMode") ~= true
		v_u_157.Visible = v475
		v_u_255.Visible = v475
		v_u_10.AttrChanged:Connect(function(p476)
			-- upvalues: (copy) v_u_10, (ref) v_u_398, (ref) v_u_401, (copy) v_u_459, (copy) v_u_440
			if p476 == "Queued" then
				if v_u_10.Get("Queued") == true then
					v_u_398 = false
				else
					v_u_401 = false
				end
			elseif p476 ~= "QueueFound" and (p476 ~= "QueuedAt" and (p476 ~= "QueueFilled" and p476 ~= "State")) then
				return
			end
			v_u_459(true)
			v_u_440()
		end)
		v_u_8.LayoutChanged:Connect(function()
			-- upvalues: (ref) v_u_412, (copy) v_u_249, (ref) v_u_350, (copy) v_u_11, (copy) v_u_248, (copy) v_u_251, (copy) v_u_8
			local v477 = v_u_412
			for v478, v479 in v_u_249 do
				local v480 = v478 <= v477
				local v481
				if v_u_350 == "found" then
					v481 = v_u_11.Text
				elseif v480 then
					v481 = v_u_11.Accent
				else
					v481 = v_u_248
				end
				v479.BackgroundColor3 = v481
			end
			v_u_412 = v477
			local v482 = v_u_251
			local v483
			if v_u_8.Compact then
				v483 = string.format("%d/%d", v477, 6)
			else
				v483 = string.format("%d/%d PLAYERS", v477, 6)
			end
			v482.Text = v483
		end)
		v_u_8.Every(v_u_14, 0.1, function()
			-- upvalues: (ref) v_u_398, (copy) v_u_10, (ref) v_u_403, (ref) v_u_400, (ref) v_u_401, (ref) v_u_402, (copy) v_u_459, (copy) v_u_440
			if v_u_398 and (v_u_10.Get("Queued") ~= true and (not v_u_403 and os.clock() - v_u_400 > 3)) then
				v_u_398 = false
			end
			if v_u_401 and os.clock() - v_u_402 > 2 then
				v_u_401 = false
			end
			v_u_459(true)
			v_u_440()
		end)
		function p_u_7.Debug.queue(p484)
			-- upvalues: (copy) v_u_463, (copy) v_u_465, (ref) v_u_350, (copy) v_u_10, (ref) v_u_412, (ref) v_u_398, (ref) v_u_401
			if p484 == "play" then
				task.spawn(v_u_463)
			elseif p484 == "cancel" then
				task.spawn(v_u_465)
			end
			return {
				["mode"] = v_u_350,
				["queued"] = v_u_10.Get("Queued"),
				["queuedAt"] = v_u_10.Get("QueuedAt"),
				["found"] = v_u_10.Get("QueueFound"),
				["seats"] = v_u_412,
				["localQueued"] = v_u_398,
				["cancelling"] = v_u_401
			}
		end
		local v_u_485
		if v_u_10.Get("CombatMode") == true then
			v_u_485 = not v_u_10.InMatch()
		else
			v_u_485 = false
		end
		local v_u_486 = 0
		local function v_u_493(p487) -- name: showZoneBanner
			-- upvalues: (ref) v_u_486, (copy) v_u_239, (copy) v_u_11, (copy) v_u_240, (copy) v_u_238, (copy) v_u_8, (copy) v_u_237, (copy) p_u_7
			v_u_486 = v_u_486 + 1
			local v_u_488 = v_u_486
			v_u_239.Text = p487 and "TRAINING" or "LEFT TRAINING"
			local v489 = v_u_239
			local v490
			if p487 then
				v490 = v_u_11.Accent
			else
				v490 = v_u_11.Text
			end
			v489.TextColor3 = v490
			v_u_240.Text = p487 and "COMBAT MODE  \194\183  WEAPONS OUT" or "WEAPONS STOWED"
			local v491 = v_u_238
			local v492
			if p487 then
				v492 = v_u_11.Accent
			else
				v492 = v_u_11.TextDim
			end
			v491.ImageColor3 = v492
			v_u_8.Unfade(v_u_237)
			v_u_237.Visible = true
			v_u_8.Enter(v_u_237, Vector2.new(0, -16))
			v_u_8.Pop(v_u_238, 0.5)
			p_u_7.Sounds.Play(p487 and "Select" or "Close")
			task.delay(p487 and 2.6 or 1.8, function()
				-- upvalues: (copy) v_u_488, (ref) v_u_486, (ref) v_u_8, (ref) v_u_237
				if v_u_488 == v_u_486 then
					v_u_8.FadeOut(v_u_237)
					task.delay(0.3, function()
						-- upvalues: (ref) v_u_488, (ref) v_u_486, (ref) v_u_237, (ref) v_u_8
						if v_u_488 == v_u_486 then
							v_u_237.Visible = false
							v_u_8.Unfade(v_u_237)
						end
					end)
				end
			end)
		end
		function p_u_7.Debug.trainingBanner(p494)
			-- upvalues: (copy) v_u_493
			v_u_493(p494 ~= false)
			return true
		end
		v_u_10.AttrChanged:Connect(function(p495)
			-- upvalues: (copy) v_u_10, (copy) v_u_157, (copy) v_u_255, (ref) v_u_485, (copy) v_u_493
			if p495 == "CombatMode" or p495 == "State" then
				local v496 = v_u_10.Get("CombatMode") ~= true
				local v497 = v_u_255
				v_u_157.Visible = v496
				v497.Visible = v496
				local v498
				if v_u_10.Get("CombatMode") == true then
					v498 = not v_u_10.InMatch()
				else
					v498 = false
				end
				if v498 ~= v_u_485 then
					v_u_485 = v498
					if not v_u_10.InMatch() then
						v_u_493(v498)
					end
				end
			end
		end)
		local function v501() -- name: refreshVisible
			-- upvalues: (copy) v_u_14, (copy) v_u_10, (copy) p_u_7, (copy) v_u_236
			local v499 = v_u_14
			local v500 = not v_u_10.SeesMatch()
			if v500 then
				v500 = not p_u_7.HudHidden
			end
			v499.Visible = v500
			v_u_236.SetNewsVisible(not v_u_10.SeesMatch())
			if not v_u_14.Visible then
				p_u_7.MenuManager.EndHudFocus()
			end
		end
		local v502 = not v_u_10.SeesMatch()
		if v502 then
			v502 = not p_u_7.HudHidden
		end
		v_u_14.Visible = v502
		v_u_236.SetNewsVisible(not v_u_10.SeesMatch())
		if not v_u_14.Visible then
			p_u_7.MenuManager.EndHudFocus()
		end
		v_u_10.PlayerStateChanged:Connect(v501)
		v_u_10.WatchChanged:Connect(v501)
		p_u_7.HudHiddenChanged:Connect(v501)
		p_u_7.LobbyHud = {
			["Root"] = v_u_14,
			["PlayButton"] = v_u_152,
			["Chip"] = v_u_15,
			["StreakSlot"] = v_u_25,
			["SetPlayHidden"] = function(p503, p504) -- name: SetPlayHidden
				-- upvalues: (copy) v_u_397, (copy) v_u_152, (ref) v_u_350
				v_u_397[p503] = p504 and true or nil
				local v505 = v_u_152.Instance
				local v506
				if v_u_350 == "idle" then
					v506 = next(v_u_397) == nil
				else
					v506 = false
				end
				v505.Visible = v506
			end
		}
	end
}