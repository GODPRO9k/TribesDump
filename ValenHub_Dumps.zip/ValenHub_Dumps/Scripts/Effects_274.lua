local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("TweenService")
local v6 = v3:WaitForChild("Shared")
local v_u_7 = require(v6.Combat)
local v_u_8 = require(v6.Weapons)
local v_u_9 = v_u_7.Ballistics
local v_u_10 = require(script.Parent.Util)
local v_u_11 = require(script.Parent.Metrics)
local v_u_12 = require(script.Parent.Quality)
local v_u_13 = require(script.Parent.Presentation)
local v_u_14 = {}
local v_u_15 = v_u_2.LocalPlayer
local v_u_16 = v_u_10.Assets:WaitForChild("VFX", 10)
local v_u_17 = workspace:FindFirstChild("FX")
if not v_u_17 then
	v_u_17 = Instance.new("Folder")
	v_u_17.Name = "FX"
	v_u_17.Parent = workspace
end
local function v_u_21(p18) -- name: template
	-- upvalues: (copy) v_u_16
	if not v_u_16 then
		return nil
	end
	local v19 = v_u_16
	for v20 in string.gmatch(p18, "[^/]+") do
		if not v19 then
			continue
		end
		v19 = v19:FindFirstChild(v20)
	end
	return v19
end
local function v_u_25(p22) -- name: prep
	local v23 = p22:GetDescendants()
	table.insert(v23, p22)
	for _, v24 in v23 do
		if not v24:IsA("BasePart") then
			continue
		end
		v24.Anchored = true
		v24.CanCollide = false
		v24.CanQuery = false
		v24.CanTouch = false
		v24.CastShadow = false
	end
end
local v_u_26 = {}
local v_u_27 = {}
local v_u_28 = 0
v_u_14.NEAR = v_u_12.nearRadius
v_u_12.OnChanged(function()
	-- upvalues: (copy) v_u_14, (copy) v_u_12
	v_u_14.NEAR = v_u_12.nearRadius
end)
local function v_u_37(p_u_29) -- name: snapshot
	-- upvalues: (copy) v_u_27
	local v30 = p_u_29:GetDescendants()
	table.insert(v30, p_u_29)
	local v31 = {}
	for _, v32 in v30 do
		if v32:IsA("BasePart") then
			local v33 = { v32, v32.Transparency }
			table.insert(v31, v33)
		elseif v32:IsA("ParticleEmitter") then
			local v34 = {
				v32,
				{ v32.Enabled, v32.Color, v32.LightEmission }
			}
			table.insert(v31, v34)
		elseif v32:IsA("Trail") or v32:IsA("Beam") then
			local v35 = { v32, v32.Enabled }
			table.insert(v31, v35)
		else
			if not (v32:IsA("PointLight") or (v32:IsA("SpotLight") or v32:IsA("SurfaceLight"))) then
				continue
			end
			local v36 = { v32, v32.Brightness }
			table.insert(v31, v36)
		end
	end
	v_u_27[p_u_29] = v31
	p_u_29.Destroying:Connect(function()
		-- upvalues: (ref) v_u_27, (copy) p_u_29
		v_u_27[p_u_29] = nil
	end)
end
local function v_u_47(p38) -- name: restore
	-- upvalues: (copy) v_u_27
	local v39 = {}
	for _, v40 in v_u_27[p38] or {} do
		v39[v40[1]] = v40[2]
	end
	local v41 = p38:GetDescendants()
	table.insert(v41, p38)
	for _, v42 in v41 do
		local v43 = v39[v42]
		if v42:IsA("BasePart") then
			v42.Anchored = true
			if type(v43) ~= "number" then
				continue
			end
			v42.Transparency = v43
		elseif v42:IsA("ParticleEmitter") and type(v43) == "table" then
			local v44 = v43[1]
			local v45 = v43[2]
			local v46 = v43[3]
			v42.Enabled = v44
			v42.Color = v45
			v42.LightEmission = v46
			v42:Clear()
		elseif v42:IsA("Trail") and type(v43) == "boolean" then
			v42.Enabled = v43
			v42:Clear()
		elseif v42:IsA("Beam") and type(v43) == "boolean" then
			v42.Enabled = v43
		elseif (v42:IsA("PointLight") or (v42:IsA("SpotLight") or v42:IsA("SurfaceLight"))) and type(v43) == "number" then
			v42.Brightness = v43
		else
			if not v42:IsA("WeldConstraint") or v42.Name ~= "StickWeld" then
				continue
			end
			v42:Destroy()
		end
	end
end
local function v_u_51(p48, p49) -- name: takeFromPool
	-- upvalues: (copy) v_u_26, (copy) v_u_47, (copy) v_u_25, (copy) v_u_37
	local v50 = v_u_26[p48]
	if v50 then
		v50 = table.remove(v50)
	end
	if v50 then
		v_u_47(v50)
	else
		v50 = p49:Clone()
		v_u_25(v50)
		v_u_37(v50)
		v50:SetAttribute("PoolKey", p48)
	end
	v50:SetAttribute("Released", nil)
	return v50
end
local function v_u_55(p52) -- name: release
	-- upvalues: (copy) v_u_26
	if p52 and not p52:GetAttribute("Released") then
		local v53 = p52:GetAttribute("PoolKey")
		local v54 = type(v53) == "string" and (v_u_26[v53] or {}) or nil
		if v54 and #v54 < 12 then
			v_u_26[v53] = v54
			p52.Parent = nil
			p52:SetAttribute("Released", true)
			table.insert(v54, p52)
		else
			p52:Destroy()
		end
	else
		return
	end
end
local v_u_56 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_66(p57) -- name: bodyOf
	-- upvalues: (copy) v_u_56
	local v58 = v_u_56[p57]
	if v58 then
		return v58
	end
	local v59
	if p57:IsA("Model") then
		v59 = p57:GetPivot()
	elseif p57:IsA("BasePart") then
		v59 = p57.CFrame
	else
		v59 = CFrame.identity
	end
	local v60 = p57:GetDescendants()
	table.insert(v60, p57)
	local v61 = {}
	local v62 = {}
	for _, v63 in v60 do
		if not v63:IsA("BasePart") then
			continue
		end
		table.insert(v61, v63)
		local v64 = v63.CFrame
		table.insert(v62, v59:ToObjectSpace(v64))
	end
	local v65 = {
		["parts"] = v61,
		["rels"] = v62
	}
	v_u_56[p57] = v65
	return v65
end
function v_u_14.CamDistance(p67) -- name: camDistance
	local v68 = workspace.CurrentCamera
	return not v68 and 0 or (v68.CFrame.Position - p67).Magnitude
end
function v_u_14.WeaponColor(p69) -- name: WeaponColor
	-- upvalues: (copy) v_u_8, (copy) v_u_13
	if p69 then
		p69 = p69:GetAttribute("WeaponId")
	end
	local v70 = v_u_8.Get(p69)
	if v70 then
		v70 = v_u_13.Kind(v70.kind)
	end
	return v70 and (v70.slashColor or v70.glow) or Color3.fromRGB(226, 170, 100)
end
function v_u_14.GroundAt(p71, p72) -- name: groundAt
	-- upvalues: (copy) v_u_10
	local v73 = v_u_10.WorldParams(v_u_10.Targets())
	local v74 = workspace
	local v75 = p71 + Vector3.new(0, 1.5, 0)
	local v76 = -(p72 + 1.5)
	local v77 = v74:Raycast(v75, Vector3.new(0, v76, 0), v73)
	if v77 then
		return v77.Position, v77.Normal
	else
		return nil, nil
	end
end
local function v_u_98(p78, p79, p80, p81, p82, p83, p_u_84, p85, p_u_86) -- name: groundDecal
	-- upvalues: (copy) v_u_12, (ref) v_u_17, (copy) v_u_5, (copy) v_u_1
	if v_u_12.decals then
		local v87 = p79.Unit
		local v88 = v87:Cross(Vector3.new(0, 0, 1))
		if v88.Magnitude < 0.1 then
			v88 = v87:Cross(Vector3.new(1, 0, 0))
		end
		local v89 = v88.Unit
		local v90 = v89:Cross(v87).Unit
		local v91 = CFrame.fromMatrix(p78 + v87 * 0.06, v89, v87, -v90)
		local v92 = Vector3.new(p82, 0.05, p82)
		local v93 = Enum.Material.SmoothPlastic
		local v94 = Instance.new("Part")
		v94.Name = "GroundFX"
		v94.Anchored = true
		v94.CanCollide = false
		v94.CanQuery = false
		v94.CanTouch = false
		v94.CastShadow = false
		v94.Size = v92
		v94.CFrame = v91
		v94.Color = p81
		v94.Material = v93 or Enum.Material.SmoothPlastic
		v94.Transparency = 1
		local v95 = workspace:FindFirstChild("FX")
		if v95 then
			v_u_17 = v95
		end
		v94.Parent = v_u_17
		local v96 = Instance.new("SurfaceGui")
		v96.Face = Enum.NormalId.Top
		v96.SizingMode = Enum.SurfaceGuiSizingMode.FixedSize
		v96.CanvasSize = Vector2.new(256, 256)
		v96.LightInfluence = 1
		v96.Parent = v94
		local v_u_97 = Instance.new("ImageLabel")
		v_u_97.Size = UDim2.fromScale(1, 1)
		v_u_97.BackgroundTransparency = 1
		v_u_97.Image = p80
		v_u_97.ImageColor3 = p81
		v_u_97.ImageTransparency = p85
		v_u_97.Parent = v96
		v_u_5:Create(v94, TweenInfo.new(p_u_84, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), {
			["Size"] = Vector3.new(p83, 0.05, p83)
		}):Play()
		task.delay(p_u_86 or 0, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_97, (copy) p_u_86, (copy) p_u_84
			v_u_5:Create(v_u_97, TweenInfo.new(p_u_86 and 1.2 or p_u_84, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				["ImageTransparency"] = 1
			}):Play()
		end)
		v_u_1:AddItem(v94, (p_u_86 or 0) + p_u_84 + 1.3)
	end
end
local function v_u_111(p99, p100) -- name: emitAll
	-- upvalues: (copy) v_u_12, (copy) v_u_5
	local v101 = p99:GetDescendants()
	table.insert(v101, p99)
	local v102 = 0.5
	for _, v_u_103 in v101 do
		if v_u_103:IsA("ParticleEmitter") then
			local v104 = v_u_103:GetAttribute("EmitCount")
			local v105 = (type(v104) ~= "number" and 12 or v104) * (p100 or 1) * v_u_12.particleScale + 0.5
			local v106 = math.floor(v105)
			local v_u_107 = math.max(1, v106)
			local v108 = v_u_103:GetAttribute("EmitDelay")
			if type(v108) == "number" and v108 > 0 then
				task.delay(v108, function()
					-- upvalues: (copy) v_u_103, (ref) v_u_107
					if v_u_103.Parent then
						v_u_103:Emit(v_u_107)
					end
				end)
				local v109 = v108 + v_u_103.Lifetime.Max
				v102 = math.max(v102, v109)
			else
				v_u_103:Emit(v_u_107)
				local v110 = v_u_103.Lifetime.Max
				v102 = math.max(v102, v110)
			end
		else
			if not (v_u_103:IsA("PointLight") or v_u_103:IsA("SpotLight")) then
				continue
			end
			v_u_103.Enabled = true
			v_u_5:Create(v_u_103, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Brightness"] = 0
			}):Play()
		end
	end
	return v102
end
function v_u_14.Burst(p112, p113, p114, p115, p116) -- name: Burst
	-- upvalues: (copy) v_u_21, (ref) v_u_28, (copy) v_u_12, (copy) v_u_51, (ref) v_u_17, (copy) v_u_111, (copy) v_u_55
	local v117 = v_u_21(p112)
	if not v117 then
		return false
	end
	if v_u_28 >= v_u_12.maxBursts then
		local v118 = p113.Position
		local v119 = workspace.CurrentCamera
		if (not v119 and 0 or (v119.CFrame.Position - v118).Magnitude) > 40 then
			return true
		end
	end
	local v_u_120 = v_u_51(p112, v117)
	if v_u_120:IsA("BasePart") then
		v_u_120.Transparency = 1
		v_u_120.CFrame = p113
		local v121 = workspace:FindFirstChild("FX")
		if v121 then
			v_u_17 = v121
		end
		v_u_120.Parent = v_u_17
	elseif v_u_120:IsA("Model") then
		v_u_120:PivotTo(p113)
		local v122 = workspace:FindFirstChild("FX")
		if v122 then
			v_u_17 = v122
		end
		v_u_120.Parent = v_u_17
	else
		if not v_u_120:IsA("Attachment") then
			v_u_120:Destroy()
			return false
		end
		v_u_120.Parent = workspace.Terrain
		v_u_120.WorldCFrame = p113
	end
	if p115 then
		for _, v123 in v_u_120:GetDescendants() do
			if not (v123:IsA("ParticleEmitter") and (v123:GetAttribute("Tint") or p116)) then
				continue
			end
			v123.Color = ColorSequence.new(p115)
			local v124 = v123.LightEmission
			v123.LightEmission = math.min(v124, 0.35)
		end
	end
	local v125 = v_u_111(v_u_120, p114)
	v_u_28 = v_u_28 + 1
	task.delay(v125 + 0.3, function()
		-- upvalues: (ref) v_u_28, (ref) v_u_55, (copy) v_u_120
		v_u_28 = v_u_28 - 1
		v_u_55(v_u_120)
	end)
	return true
end
function v_u_14.Puff(p126, p127, p128, p129, p130, p131, p132) -- name: Puff
	-- upvalues: (ref) v_u_17, (copy) v_u_12, (copy) v_u_1
	local v133 = CFrame.new(p126)
	local v134 = Color3.new()
	local v135 = Enum.Material.SmoothPlastic
	local v136 = Instance.new("Part")
	v136.Name = "PuffFX"
	v136.Anchored = true
	v136.CanCollide = false
	v136.CanQuery = false
	v136.CanTouch = false
	v136.CastShadow = false
	v136.Size = Vector3.new(1, 1, 1)
	v136.CFrame = v133
	v136.Color = v134
	v136.Material = v135 or Enum.Material.SmoothPlastic
	v136.Transparency = 1
	local v137 = workspace:FindFirstChild("FX")
	if v137 then
		v_u_17 = v137
	end
	v136.Parent = v_u_17
	if p132 then
		v136.CFrame = CFrame.lookAt(p126, p126 + p132)
	end
	local v138 = Instance.new("ParticleEmitter")
	v138.Texture = "rbxasset://textures/particles/smoke_main.dds"
	v138.Color = ColorSequence.new(p127)
	v138.LightEmission = 0
	v138.LightInfluence = 1
	v138.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p129 * 0.5), NumberSequenceKeypoint.new(1, p129 * 1.6) })
	v138.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(0.6, 0.55), NumberSequenceKeypoint.new(1, 1) })
	v138.Lifetime = NumberRange.new(p131 * 0.7, p131)
	v138.Speed = NumberRange.new(p130 * 0.4, p130)
	local v139
	if p132 then
		v139 = Vector2.new(22, 22)
	else
		v139 = Vector2.new(180, 180)
	end
	v138.SpreadAngle = v139
	v138.EmissionDirection = Enum.NormalId.Front
	v138.Rotation = NumberRange.new(0, 360)
	v138.RotSpeed = NumberRange.new(-40, 40)
	v138.Drag = 3
	v138.Acceleration = Vector3.new(0, 1.5, 0)
	v138.Rate = 0
	v138.Parent = v136
	local v140 = p128 * v_u_12.particleScale + 0.5
	local v141 = math.floor(v140)
	v138:Emit((math.max(1, v141)))
	v_u_1:AddItem(v136, p131 + 0.3)
end
function v_u_14.HitFlash(p142, p143) -- name: HitFlash
	-- upvalues: (copy) v_u_12, (copy) v_u_5
	if p142 and (p142:IsA("Model") and v_u_12.highlights) then
		local v_u_144 = p142:FindFirstChild("CombatHitFlash")
		if not v_u_144 then
			v_u_144 = Instance.new("Highlight")
			v_u_144.Name = "CombatHitFlash"
			v_u_144.DepthMode = Enum.HighlightDepthMode.Occluded
			v_u_144.Adornee = p142
			v_u_144.Parent = p142
		end
		v_u_144.FillColor = p143 or Color3.fromRGB(255, 70, 60)
		v_u_144.OutlineColor = p143 or Color3.fromRGB(255, 70, 60)
		v_u_144.FillTransparency = 1
		v_u_144.OutlineTransparency = 0.05
		v_u_5:Create(v_u_144, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["OutlineTransparency"] = 1
		}):Play()
		local v_u_145 = (v_u_144:GetAttribute("Tok") or 0) + 1
		v_u_144:SetAttribute("Tok", v_u_145)
		task.delay(0.3, function()
			-- upvalues: (copy) v_u_144, (copy) v_u_145
			if v_u_144.Parent and v_u_144:GetAttribute("Tok") == v_u_145 then
				v_u_144:Destroy()
			end
		end)
	end
end
local v_u_146 = {}
function v_u_14.PredictHit(p147, p148, p149, _, _, _) -- name: PredictHit
	-- upvalues: (copy) v_u_10, (copy) v_u_146
	if v_u_10.CanPredictHit(p147) then
		v_u_146[p147] = os.clock()
		if p148 then
			v_u_10.Sound(p148, p149)
		end
	end
end
function v_u_14.ConsumePrediction(p150) -- name: ConsumePrediction
	-- upvalues: (copy) v_u_146
	if not p150 then
		return false
	end
	local v151 = v_u_146[p150]
	v_u_146[p150] = nil
	local v152
	if v151 == nil then
		v152 = false
	else
		v152 = os.clock() - v151 < 0.8
	end
	return v152
end
task.spawn(function()
	-- upvalues: (copy) v_u_146
	while true do
		task.wait(5)
		local v153 = os.clock()
		for v154, v155 in v_u_146 do
			if v153 - v155 <= 2 then
				continue
			end
			v_u_146[v154] = nil
		end
	end
end)
local v_u_156 = {
	["Grass"] = "Impact_Dust",
	["LeafyGrass"] = "Impact_Dust",
	["Ground"] = "Impact_Dust",
	["Mud"] = "Impact_Dust",
	["Sand"] = "Impact_Dust",
	["Snow"] = "Impact_Dust",
	["Salt"] = "Impact_Dust",
	["Wood"] = "Impact_Wood",
	["WoodPlanks"] = "Impact_Wood",
	["Metal"] = "Impact_Sparks",
	["DiamondPlate"] = "Impact_Sparks",
	["CorrodedMetal"] = "Impact_Sparks",
	["Foil"] = "Impact_Sparks"
}
local v_u_157 = {
	["Impact_Dust"] = "Impact_Dirt",
	["Impact_Wood"] = "Impact_Wood",
	["Impact_Sparks"] = "Impact_Metal",
	["Impact_Stone"] = "Impact_Stone"
}
function v_u_14.Impact(p158, p159, p160, p161, p162) -- name: Impact
	-- upvalues: (copy) v_u_156, (copy) v_u_14, (copy) v_u_10, (copy) v_u_157
	local v163 = v_u_156[p160 or ""] or "Impact_Stone"
	local v164 = CFrame.lookAt(p158, p158 + (p159 or Vector3.new(0, 1, 0)))
	if not v_u_14.Burst(v163, v164, p162) then
		v_u_14.Burst("Impact_Stone", v164, p162)
	end
	if p161 ~= false then
		v_u_10.Sound(v_u_157[v163] or "Impact_Stone", p158)
	end
end
local v_u_165 = {
	["health"] = Color3.fromRGB(235, 110, 50),
	["headshot"] = Color3.fromRGB(245, 190, 40),
	["blocked"] = Color3.fromRGB(120, 190, 245)
}
function v_u_14.ArmorHit(p166, p167) -- name: ArmorHit
	-- upvalues: (copy) v_u_14, (copy) v_u_10
	local v168 = workspace.CurrentCamera
	if (not v168 and 0 or (v168.CFrame.Position - p166).Magnitude) <= v_u_14.NEAR then
		v_u_14.Burst("Block_Spark", CFrame.new(p166), p167 and 1.2 or 0.7, Color3.fromRGB(205, 210, 220), true)
		v_u_10.Sound(p167 and "Shield_Break" or "Impact_Metal", p166, {
			["Volume"] = p167 and 0.9 or 0.5
		})
	end
end
function v_u_14.CharacterImpact(p169, p170, p171, p172) -- name: CharacterImpact
	-- upvalues: (copy) v_u_165, (copy) v_u_14
	local v173 = CFrame.lookAt(p169, p169 - (p170 or Vector3.new(0, 0, 1)))
	local v174
	if p172 then
		v174 = v_u_165[p172]
	else
		v174 = p172
	end
	v_u_14.Burst("Impact_Hit", v173, p171 and 1.6 or (p172 and 1.15 or 0.7), v174, v174 ~= nil)
	if p172 == "headshot" then
		v_u_14.CritStar(p169)
	end
end
function v_u_14.CritStar(p_u_175) -- name: CritStar
	-- upvalues: (copy) v_u_21, (copy) v_u_25, (ref) v_u_17, (copy) v_u_4
	local v176 = v_u_21("CritStar")
	if v176 then
		local v_u_177 = v176:Clone()
		v_u_25(v_u_177)
		v_u_177:ScaleTo(0.25)
		v_u_177:PivotTo(CFrame.lookAt(p_u_175 + Vector3.new(0, 1.2, 0), workspace.CurrentCamera.CFrame.Position))
		local v178 = workspace:FindFirstChild("FX")
		if v178 then
			v_u_17 = v178
		end
		v_u_177.Parent = v_u_17
		local v_u_179 = os.clock()
		local v_u_180 = nil
		v_u_180 = v_u_4.RenderStepped:Connect(function()
			-- upvalues: (copy) v_u_179, (copy) v_u_177, (ref) v_u_180, (copy) p_u_175
			local v181 = (os.clock() - v_u_179) / 0.45
			if v181 >= 1 or not v_u_177.Parent then
				v_u_180:Disconnect()
				v_u_177:Destroy()
			else
				local v182
				if v181 < 0.3 then
					v182 = 0.25 + 0.65 * (v181 / 0.3)
				else
					v182 = 0.9 - 0.2 * (v181 - 0.3)
				end
				v_u_177:ScaleTo((math.max(0.05, v182)))
				local v183 = v_u_177
				local v184 = CFrame.lookAt
				local v185 = p_u_175
				local v186 = 1.2 + v181 * 1.2
				v183:PivotTo(v184(v185 + Vector3.new(0, v186, 0), workspace.CurrentCamera.CFrame.Position) * CFrame.Angles(0, 0, v181 * 2))
				for _, v187 in v_u_177:GetDescendants() do
					if not v187:IsA("BasePart") then
						continue
					end
					local v188 = (v181 - 0.55) / 0.45
					v187.Transparency = math.clamp(v188, 0, 1)
				end
			end
		end)
	end
end
function v_u_14.Trail(p189, p190) -- name: Trail
	-- upvalues: (copy) v_u_14, (copy) v_u_10
	if p189 then
		local v191 = v_u_14.WeaponColor(p189)
		for _, v_u_192 in v_u_10.Drawn(p189):GetDescendants() do
			if not v_u_192:IsA("Trail") then
				continue
			end
			v_u_192.Lifetime = 0.18
			v_u_192.LightEmission = 0.25
			v_u_192.LightInfluence = 0.5
			v_u_192.Color = ColorSequence.new(v191)
			v_u_192.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(1, 1) })
			v_u_192.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
			v_u_192.Enabled = true
			local v_u_193 = (v_u_192:GetAttribute("Tok") or 0) + 1
			v_u_192:SetAttribute("Tok", v_u_193)
			task.delay(p190, function()
				-- upvalues: (copy) v_u_192, (copy) v_u_193
				if v_u_192:GetAttribute("Tok") == v_u_193 then
					v_u_192.Enabled = false
				end
			end)
		end
	end
end
local v_u_194 = nil
function v_u_14.DashLines(p195) -- name: DashLines
	-- upvalues: (copy) v_u_2, (ref) v_u_194, (copy) v_u_5
	local v196 = v_u_2.LocalPlayer
	if v196 then
		v196 = v196:FindFirstChildOfClass("PlayerGui")
	end
	if v196 then
		local v197 = v_u_194
		if not v197 or v197.Parent ~= v196 then
			v197 = Instance.new("ScreenGui")
			v197.Name = "TribesDashLines"
			v197.IgnoreGuiInset = true
			v197.ResetOnSpawn = false
			v197.DisplayOrder = 3
			v197.Parent = v196
			v_u_194 = v197
		end
		local v198 = Random.new()
		local v199 = TweenInfo.new(p195, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		for v200 = 1, 16 do
			local v201 = v200 / 16 * 3.141592653589793 * 2 + v198:NextNumber(-0.12, 0.12)
			local v202 = Vector2.new(math.cos(v201), (math.sin(v201)))
			local v203 = v198:NextNumber(0.36, 0.44)
			local v_u_204 = Instance.new("Frame")
			v_u_204.Name = "Line"
			v_u_204.AnchorPoint = Vector2.new(0.5, 0.5)
			v_u_204.BorderSizePixel = 0
			v_u_204.BackgroundColor3 = Color3.fromRGB(236, 240, 248)
			v_u_204.BackgroundTransparency = 0.76
			v_u_204.Size = UDim2.new(v198:NextNumber(0.07, 0.13), 0, 0, 2)
			v_u_204.Rotation = math.deg(v201)
			v_u_204.Position = UDim2.fromScale(0.5 + v202.X * v203, 0.5 + v202.Y * v203)
			v_u_204.Parent = v197
			local v205 = v203 + v198:NextNumber(0.12, 0.2)
			v_u_5:Create(v_u_204, v199, {
				["Position"] = nil,
				["BackgroundTransparency"] = 1,
				["Position"] = UDim2.fromScale(0.5 + v202.X * v205, 0.5 + v202.Y * v205)
			}):Play()
			task.delay(p195 + 0.05, function()
				-- upvalues: (copy) v_u_204
				v_u_204:Destroy()
			end)
		end
	end
end
function v_u_14.Slash(p206, p207, p208, p209, p210) -- name: Slash
	-- upvalues: (copy) v_u_10, (ref) v_u_17, (copy) v_u_12, (copy) v_u_4
	if p206 then
		local v211 = v_u_10.Drawn(p206:FindFirstChild("HumanoidRootPart"))
		if v211 then
			local v212 = p209 or Color3.fromRGB(226, 170, 100)
			local v213 = p208 and 90 or ({
				-32,
				212,
				38,
				148
			})[(p207 - 1) % 4 + 1]
			local v_u_214 = p207 % 2 == 0 and -1 or 1
			local v215 = (p210 or 9) * 0.42
			local v_u_216 = math.clamp(v215, 3, 5.5) * (p208 and 1.2 or 1)
			local v217 = v211.CFrame * CFrame.new(0, 0.6, -0.6) * CFrame.Angles(math.rad(p208 and 0 or 22), 0, 0) * CFrame.Angles(0, 0, (math.rad(v213)))
			local v_u_218 = math.rad(p208 and 150 or 130)
			local v_u_219 = -v_u_214 * v_u_218 / 2
			local v220 = Enum.Material.SmoothPlastic
			local v_u_221 = Instance.new("Part")
			v_u_221.Name = "SlashArc"
			v_u_221.Anchored = true
			v_u_221.CanCollide = false
			v_u_221.CanQuery = false
			v_u_221.CanTouch = false
			v_u_221.CastShadow = false
			v_u_221.Size = Vector3.new(0.2, 0.2, 0.2)
			v_u_221.CFrame = v217
			v_u_221.Color = v212
			v_u_221.Material = v220 or Enum.Material.SmoothPlastic
			v_u_221.Transparency = 1
			local v222 = workspace:FindFirstChild("FX")
			if v222 then
				v_u_17 = v222
			end
			v_u_221.Parent = v_u_17
			local v_u_223 = Instance.new("Attachment")
			v_u_223.Parent = v_u_221
			local v_u_224 = Instance.new("Attachment")
			v_u_224.Parent = v_u_221
			local v_u_225 = p208 and 1.35 or 1
			local v226 = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.55, 0.55),
				NumberSequenceKeypoint.new(0.92, 0.05),
				NumberSequenceKeypoint.new(1, 0.15)
			})
			local v227 = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.6, 0.65), NumberSequenceKeypoint.new(1, 0.35) })
			local v228 = v_u_225 * 0.9
			local v229 = ColorSequence.new(v212, v212:Lerp(Color3.new(1, 1, 1), 0.15))
			local v_u_230 = Instance.new("Beam")
			v_u_230.Attachment0 = v_u_223
			v_u_230.Attachment1 = v_u_224
			v_u_230.FaceCamera = true
			v_u_230.Segments = 24
			v_u_230.LightEmission = 0.25
			v_u_230.LightInfluence = 0.35
			v_u_230.Width0 = v228 * 0.15
			v_u_230.Width1 = v228
			v_u_230.Color = v229
			v_u_230.Transparency = v226
			v_u_230.Parent = v_u_221
			local v231 = v_u_225 * 2.8
			local v232 = ColorSequence.new(v212)
			local v_u_233 = Instance.new("Beam")
			v_u_233.Attachment0 = v_u_223
			v_u_233.Attachment1 = v_u_224
			v_u_233.FaceCamera = true
			v_u_233.Segments = 24
			v_u_233.LightEmission = 0.25
			v_u_233.LightInfluence = 0.35
			v_u_233.Width0 = v231 * 0.15
			v_u_233.Width1 = v231
			v_u_233.Color = v232
			v_u_233.Transparency = v227
			v_u_233.Texture = "rbxassetid://10525777446"
			v_u_233.TextureMode = Enum.TextureMode.Stretch
			v_u_233.Parent = v_u_221
			local v234 = v_u_225 * 1.6
			local v235 = ColorSequence.new(v212)
			local v_u_236 = Instance.new("Beam")
			v_u_236.Attachment0 = v_u_223
			v_u_236.Attachment1 = v_u_224
			v_u_236.FaceCamera = true
			v_u_236.Segments = 24
			v_u_236.LightEmission = 0.25
			v_u_236.LightInfluence = 0.35
			v_u_236.Width0 = v234 * 0.15
			v_u_236.Width1 = v234
			v_u_236.Color = v235
			v_u_236.Transparency = v227
			v_u_236.Parent = v_u_221
			if not v_u_12.layers then
				v_u_236.Enabled = false
			end
			local v_u_237 = p208 and 0.16 or 0.12
			local v_u_238 = v_u_218 * 0.8
			local v_u_239 = os.clock()
			local function v_u_270() -- name: update
				-- upvalues: (copy) v_u_239, (copy) v_u_237, (copy) v_u_219, (copy) v_u_214, (copy) v_u_218, (copy) v_u_238, (copy) v_u_223, (copy) v_u_216, (copy) v_u_224, (copy) v_u_230, (copy) v_u_233, (copy) v_u_236, (copy) v_u_225
				local v240 = os.clock() - v_u_239
				local v241 = v240 / v_u_237
				local v242 = math.min(1, v241)
				local v243 = 1 - (1 - v242) ^ 2
				local v244 = v_u_219 + v_u_214 * v_u_218 * v243
				local v245 = (v240 - v_u_237) / 0.14
				local v246 = math.clamp(v245, 0, 1)
				local v247 = v_u_218 * v243 - v_u_238 * (1 - v246)
				local v248 = v_u_219 + v_u_214 * math.max(0, v247)
				local v249 = v244 - v248
				local v250 = math.abs(v249)
				if v246 >= 1 or v250 < 0.02 and v242 >= 1 then
					return false
				end
				local v251 = v_u_223
				local v252 = -v_u_216 * math.sin(v248)
				local v253 = -v_u_216 * math.cos(v248)
				local v254 = Vector3.new(v252, 0, v253)
				local v255 = -math.cos(v248)
				local v256 = math.sin(v248)
				local v257 = Vector3.new(v255, 0, v256) * v_u_214
				v251.CFrame = CFrame.fromMatrix(v254, v257, Vector3.new(0, 1, 0))
				local v258 = v_u_224
				local v259 = -v_u_216 * math.sin(v244)
				local v260 = -v_u_216 * math.cos(v244)
				local v261 = Vector3.new(v259, 0, v260)
				local v262 = -math.cos(v244)
				local v263 = math.sin(v244)
				local v264 = Vector3.new(v262, 0, v263) * v_u_214
				v258.CFrame = CFrame.fromMatrix(v261, v264, Vector3.new(0, 1, 0))
				local v265 = v250 / 4
				local v266 = math.tan(v265) * 1.3333333333333333 * v_u_216
				local v267 = v_u_230
				v_u_230.CurveSize0 = v266
				v267.CurveSize1 = v266
				local v268 = v_u_233
				v_u_233.CurveSize0 = v266
				v268.CurveSize1 = v266
				local v269 = v_u_236
				v_u_236.CurveSize0 = v266
				v269.CurveSize1 = v266
				v_u_230.Width1 = v_u_225 * 0.9 * (1 - v246 * 0.6)
				v_u_233.Width1 = v_u_225 * 2.8 * (1 - v246 * 0.4)
				v_u_236.Width1 = v_u_225 * 1.6 * (1 - v246 * 0.5)
				return true
			end
			local v271 = -v_u_216 * math.sin(v_u_219)
			local v272 = -v_u_216 * math.cos(v_u_219)
			local v273 = Vector3.new(v271, 0, v272)
			local v274 = -math.cos(v_u_219)
			local v275 = math.sin(v_u_219)
			local v276 = Vector3.new(v274, 0, v275) * v_u_214
			v_u_223.CFrame = CFrame.fromMatrix(v273, v276, Vector3.new(0, 1, 0))
			local v277 = -v_u_216 * math.sin(v_u_219)
			local v278 = -v_u_216 * math.cos(v_u_219)
			local v279 = Vector3.new(v277, 0, v278)
			local v280 = -math.cos(v_u_219)
			local v281 = math.sin(v_u_219)
			local v282 = Vector3.new(v280, 0, v281) * v_u_214
			v_u_224.CFrame = CFrame.fromMatrix(v279, v282, Vector3.new(0, 1, 0))
			v_u_270()
			local v_u_283 = nil
			v_u_283 = v_u_4.RenderStepped:Connect(function()
				-- upvalues: (copy) v_u_221, (copy) v_u_270, (ref) v_u_283
				if not (v_u_221.Parent and v_u_270()) then
					v_u_283:Disconnect()
					v_u_221:Destroy()
				end
			end)
		end
	else
		return
	end
end
function v_u_14.GroundScuff(p284) -- name: GroundScuff
	-- upvalues: (copy) v_u_10, (copy) v_u_98
	local v285 = p284 + Vector3.new(0, 2, 0)
	local v286 = v_u_10.WorldParams(v_u_10.Targets())
	local v287 = workspace:Raycast(v285 + Vector3.new(0, 1.5, 0), Vector3.new(0, -7.5, 0), v286)
	local v288, v289
	if v287 then
		v288 = v287.Position
		v289 = v287.Normal
	else
		v288 = nil
		v289 = nil
	end
	if v288 and v289 then
		v_u_98(v288, v289, "rbxassetid://10430755572", Color3.fromRGB(70, 55, 40), 3, 4.2, 0.15, 0.35, 1.2)
		v_u_98(v288, v289, "rbxassetid://10871117278", Color3.fromRGB(190, 165, 130), 1.5, 8, 0.25, 0.35)
	end
end
function v_u_14.Muzzle(p290, p291, p292, p293) -- name: Muzzle
	-- upvalues: (copy) v_u_14, (ref) v_u_17, (copy) v_u_5, (copy) v_u_1
	local v294 = p290.Position
	local v295 = workspace.CurrentCamera
	local v296 = (not v295 and 0 or (v295.CFrame.Position - v294).Magnitude) > v_u_14.NEAR
	local v297 = p291 and 1.4 or 1
	if not (v296 or p293) then
		local v298 = Vector3.new(0.5, 0.5, 1.4) * v297
		local v299 = p290 * CFrame.new(0, 0, v297 * -0.7)
		local v300 = Color3.fromRGB(255, 170, 70)
		local v301 = Enum.Material.SmoothPlastic
		local v302 = Instance.new("Part")
		v302.Name = "MuzzleFlash"
		v302.Anchored = true
		v302.CanCollide = false
		v302.CanQuery = false
		v302.CanTouch = false
		v302.CastShadow = false
		v302.Size = v298
		v302.CFrame = v299
		v302.Color = v300
		v302.Material = v301 or Enum.Material.SmoothPlastic
		v302.Transparency = 0.2
		local v303 = workspace:FindFirstChild("FX")
		if v303 then
			v_u_17 = v303
		end
		v302.Parent = v_u_17
		local v304 = Instance.new("SpecialMesh")
		v304.MeshType = Enum.MeshType.Sphere
		v304.Parent = v302
		local v305 = Instance.new("PointLight")
		v305.Color = Color3.fromRGB(255, 160, 80)
		v305.Brightness = 1
		v305.Range = v297 * 10
		v305.Shadows = false
		v305.Parent = v302
		v_u_5:Create(v302, TweenInfo.new(0.07), {
			["Transparency"] = 1,
			["Size"] = nil,
			["Size"] = Vector3.new(0.9, 0.9, 2.2) * v297
		}):Play()
		v_u_5:Create(v305, TweenInfo.new(0.09), {
			["Brightness"] = 0
		}):Play()
		v_u_1:AddItem(v302, 0.12)
		v_u_14.Puff(p290.Position, Color3.fromRGB(255, 190, 110), 5, v297 * 0.35, 18, 0.12, p290.LookVector)
	end
	if p292 ~= false then
		v_u_14.Puff(p290.Position, Color3.fromRGB(196, 192, 184), v296 and 4 or 9, v297 * 1.1, 7, 1.7, p290.LookVector)
		v_u_14.Puff(p290.Position, Color3.fromRGB(170, 166, 160), v296 and 2 or 5, v297 * 1.5, 1.5, 2.4)
	end
end
local v_u_306 = {
	["Arrow"] = true,
	["Bolt"] = true,
	["Javelin"] = true,
	["Knife"] = true,
	["Harpoon"] = true,
	["FireArrow"] = true,
	["FireBolt"] = true
}
local v_u_307 = {
	["Arrow"] = { "Arrow_Flesh", "Arrow_Thunk" },
	["Bolt"] = { "Arrow_Flesh", "Arrow_Thunk" },
	["Ball"] = { "Hit_Melee_Heavy", "Impact_Dirt" },
	["Pellet"] = { "Hit_Melee", "Impact_Dirt" },
	["Knife"] = { "Knife_Hit", "Knife_Thunk" },
	["Javelin"] = { "Spear_Hit", "Javelin_Hit" },
	["Stone"] = { "Stone_Hit", "Impact_Stone" },
	["FireArrow"] = { "Arrow_Flesh", "Arrow_Thunk" },
	["FireBolt"] = { "Arrow_Flesh", "Arrow_Thunk" },
	["Bolas"] = { "Stone_Hit", "Impact_Stone" },
	["Harpoon"] = { "Harpoon_Hit", "Harpoon_Thunk" },
	["Hatchet"] = { "Hatchet_Hit", "Hatchet_Thunk" }
}
local v_u_308 = {
	["Knife"] = 24,
	["Stone"] = 10,
	["FireBomb"] = 6,
	["SmokeBomb"] = 6,
	["Bolas"] = 16,
	["Flask"] = 6,
	["Chakram"] = 30,
	["Caltrops"] = 7,
	["Hatchet"] = 20,
	["Beehive"] = 5
}
local v_u_309 = {
	["Bolas"] = true,
	["Chakram"] = true
}
local v_u_310 = {}
local v_u_311 = {
	["Knife"] = 4,
	["Bolas"] = 4,
	["Chakram"] = 4,
	["Stone"] = 5,
	["FireBomb"] = 3.6,
	["SmokeBomb"] = 3.6,
	["Flask"] = 3.6,
	["Caltrops"] = 3.6,
	["Javelin"] = 7,
	["Harpoon"] = 7,
	["Hatchet"] = 4.5,
	["Beehive"] = 3.6,
	["Arrow"] = 6,
	["FireArrow"] = 6,
	["Bolt"] = 5,
	["FireBolt"] = 5
}
local v_u_312 = {
	["Knife"] = 0.1
}
local v_u_313 = nil
local v_u_314 = nil
function v_u_14.SetViewHandOff(p315, p316) -- name: SetViewHandOff
	-- upvalues: (ref) v_u_313, (ref) v_u_314
	v_u_313 = p315
	v_u_314 = p316
end
local function v_u_321(p_u_317, p318, p319) -- name: fadeOut
	-- upvalues: (copy) v_u_5, (copy) v_u_55
	for _, v320 in p_u_317:GetDescendants() do
		if v320:IsA("ParticleEmitter") or (v320:IsA("Trail") or v320:IsA("Beam")) then
			v320.Enabled = false
		else
			if not v320:IsA("PointLight") then
				continue
			end
			v_u_5:Create(v320, TweenInfo.new(p318), {
				["Brightness"] = 0
			}):Play()
		end
	end
	task.delay(p319 or p318 + 0.6, function()
		-- upvalues: (ref) v_u_55, (copy) p_u_317
		v_u_55(p_u_317)
	end)
end
local function v_u_324(p322) -- name: lowDetail
	for _, v323 in p322:GetDescendants() do
		if not (v323:IsA("ParticleEmitter") or (v323:IsA("Trail") or (v323:IsA("Beam") or v323:IsA("PointLight")))) then
			continue
		end
		v323.Enabled = false
	end
end
local function v_u_327(p325) -- name: hideBody
	for _, v326 in p325:GetDescendants() do
		if not v326:IsA("BasePart") then
			continue
		end
		v326.Transparency = 1
	end
	if p325:IsA("BasePart") then
		p325.Transparency = 1
	end
end
function v_u_14.MyKey(p328) -- name: MyKey
	-- upvalues: (copy) v_u_15
	return ("p%*:%*"):format(v_u_15.UserId, p328)
end
local v_u_329 = {}
local v_u_330 = {}
local function v_u_344(p331) -- name: paramsFor
	-- upvalues: (copy) v_u_330, (copy) v_u_329, (copy) v_u_10, (copy) v_u_15
	local v332 = p331 or v_u_330
	local v333 = v_u_329[v332]
	local v334 = os.clock()
	if v333 and v334 - v333.t < 1 then
		return v333.p
	end
	local v335 = {}
	if p331 then
		table.insert(v335, p331)
		local v336 = p331:GetAttribute("MatchId")
		local v337 = p331:GetAttribute("Team")
		if type(v336) == "string" and v336 ~= "" then
			for _, v338 in v_u_10.Targets() do
				if v338:GetAttribute("MatchId") ~= v336 or v338:GetAttribute("Team") ~= v337 then
					continue
				end
				table.insert(v335, v338)
			end
			local v339 = v_u_15.Character
			if v339 and (p331 ~= v339 and (v339:GetAttribute("MatchId") == v336 and v339:GetAttribute("Team") == v337)) then
				table.insert(v335, v339)
			end
		end
	end
	local v340 = RaycastParams.new()
	v340.FilterType = Enum.RaycastFilterType.Exclude
	local v341 = {}
	for _, v342 in { workspace:FindFirstChild("FX"), workspace:FindFirstChild("Projectiles") } do
		if not v342 then
			continue
		end
		table.insert(v341, v342)
	end
	for _, v343 in v335 do
		table.insert(v341, v343)
	end
	v340.FilterDescendantsInstances = v341
	v340.IgnoreWater = true
	v_u_329[v332] = {
		["p"] = v340,
		["t"] = v334
	}
	return v340
end
task.spawn(function()
	-- upvalues: (copy) v_u_329
	while true do
		task.wait(3)
		local v345 = os.clock()
		for v346, v347 in v_u_329 do
			if v345 - v347.t <= 2 then
				continue
			end
			v_u_329[v346] = nil
		end
	end
end)
local v_u_348 = 0
local function v_u_351(p349) -- name: fallbackModel
	-- upvalues: (copy) v_u_25
	local v350 = Instance.new("Part")
	v350.Size = (p349 == "Ball" or (p349 == "Pellet" or p349 == "Stone")) and Vector3.new(0.3, 0.3, 0.3) or Vector3.new(0.2, 0.2, 2)
	v350.Material = Enum.Material.SmoothPlastic
	v350.Color = Color3.fromRGB(90, 85, 80)
	v_u_25(v350)
	return v350
end
local v_u_352 = {}
local v_u_353 = 0
local v_u_354 = nil
local v_u_355 = nil
local function v_u_360() -- name: viewLineHand
	-- upvalues: (ref) v_u_354, (ref) v_u_355, (copy) v_u_4
	local v356 = workspace.CurrentCamera
	if not v356 then
		return nil
	end
	local v357 = v_u_354
	if not (v357 and v357.Parent) then
		v357 = Instance.new("Part")
		v357.Name = "TribesViewLineAnchor"
		v357.Anchored = true
		v357.CanCollide = false
		v357.CanQuery = false
		v357.CanTouch = false
		v357.CastShadow = false
		v357.Transparency = 1
		v357.Size = Vector3.new(0.05, 0.05, 0.05)
		v357.Parent = v356
		v_u_354 = v357
	end
	if not v_u_355 then
		v_u_355 = v_u_4.RenderStepped:Connect(function()
			-- upvalues: (ref) v_u_354
			local v358 = v_u_354
			local v359 = workspace.CurrentCamera
			if v358 and v359 then
				v358.CFrame = v359.CFrame * CFrame.new(0.3, -0.36, -0.7)
			end
		end)
	end
	return v357
end
local function v_u_374(p_u_361, p362, p363) -- name: addLine
	-- upvalues: (copy) v_u_10, (copy) v_u_15, (copy) v_u_360, (copy) v_u_352, (ref) v_u_353, (copy) v_u_5, (copy) v_u_1
	if p363 then
		local v364 = v_u_10.Drawn(p363)
		if v364 then
			if not v364:IsA("Model") then
				v364 = p363
			end
		else
			v364 = p363
		end
		local v365 = v364:FindFirstChild("RightHand") or p363:FindFirstChild("RightHand")
		if p363 == v_u_15.Character and v_u_10.InFirstPerson() then
			v365 = v_u_360() or v365
		end
		if p362:IsA("Model") then
			p362 = p362.PrimaryPart
		elseif not p362:IsA("BasePart") then
			p362 = nil
		end
		if v365 and (v365:IsA("BasePart") and p362) then
			local v366 = v_u_352[p_u_361]
			if v366 then
				v366.beam:Destroy()
				v366.a0:Destroy()
				v366.a1:Destroy()
			end
			local v367 = Instance.new("Attachment")
			v367.Name = "HarpoonLineHand"
			v367.Parent = v365
			local v368 = Instance.new("Attachment")
			v368.Name = "HarpoonLineEnd"
			v368.Position = Vector3.new(0, 0, 4.6)
			v368.Parent = p362
			local v369 = Instance.new("Beam")
			v369.Name = "HarpoonLine"
			v369.Attachment0 = v367
			v369.Attachment1 = v368
			v369.FaceCamera = true
			v369.Width0 = 0.14
			v369.Width1 = 0.14
			v369.Segments = 1
			v369.Color = ColorSequence.new(Color3.fromRGB(196, 164, 112))
			v369.Transparency = NumberSequence.new(0)
			v369.LightEmission = 0
			v369.LightInfluence = 1
			v369.Parent = p362
			v_u_353 = v_u_353 + 1
			local v370 = {
				["a0"] = v367,
				["a1"] = v368,
				["beam"] = v369,
				["token"] = v_u_353
			}
			v_u_352[p_u_361] = v370
			local v_u_371 = v_u_352[p_u_361]
			if v_u_371 then
				local v_u_372 = v_u_371.token
				task.delay(3, function()
					-- upvalues: (ref) v_u_352, (copy) p_u_361, (copy) v_u_372, (copy) v_u_371, (ref) v_u_5, (ref) v_u_1
					local v373 = v_u_352[p_u_361]
					if v373 and v373.token == v_u_372 then
						v_u_352[p_u_361] = nil
					end
					if v_u_371.beam.Parent then
						v_u_5:Create(v_u_371.beam, TweenInfo.new(0.15), {
							["Width0"] = 0,
							["Width1"] = 0
						}):Play()
					end
					v_u_1:AddItem(v_u_371.beam, 0.2)
					v_u_1:AddItem(v_u_371.a0, 0.2)
					v_u_1:AddItem(v_u_371.a1, 0.2)
				end)
			end
			v_u_352[p_u_361] = v370
		end
	else
		return
	end
end
v_u_14.ParamsOverride = nil
function v_u_14.Projectile(p375, p376, p377, p378, p379, p380, p381) -- name: Projectile
	-- upvalues: (copy) v_u_15, (copy) v_u_14, (ref) v_u_348, (copy) v_u_12, (copy) v_u_21, (copy) v_u_51, (copy) v_u_351, (copy) v_u_324, (ref) v_u_17, (copy) v_u_9, (copy) v_u_344, (copy) v_u_308, (ref) v_u_313, (copy) v_u_10, (ref) v_u_314, (copy) v_u_312, (copy) v_u_310, (copy) v_u_55, (copy) v_u_374
	local v382
	if p380 == nil then
		v382 = false
	else
		v382 = p380 == v_u_15.Character
	end
	local v383 = not v382
	if v383 then
		local v384 = workspace.CurrentCamera
		v383 = (not v384 and 0 or (v384.CFrame.Position - p377).Magnitude) > v_u_14.NEAR
	end
	if not v382 and v_u_348 >= v_u_12.maxFlying then
		return nil
	end
	local v385 = v_u_21("Projectiles/" .. p376)
	local v386
	if v385 then
		v386 = v_u_51("Projectiles/" .. p376, v385)
	else
		v386 = v_u_351(p376)
	end
	local v387 = CFrame.lookAt(p377, p377 + p378)
	if v386:IsA("Model") then
		v386:PivotTo(v387)
	elseif v386:IsA("BasePart") then
		v386.CFrame = v387
	end
	if v383 or not (v382 or v_u_12.layers) then
		v_u_324(v386)
	end
	v386:SetAttribute("CosKey", p375)
	local v388 = workspace:FindFirstChild("FX")
	if v388 then
		v_u_17 = v388
	end
	v386.Parent = v_u_17
	local v389 = {
		["key"] = nil,
		["kind"] = nil,
		["model"] = nil,
		["shot"] = nil,
		["params"] = nil,
		["landed"] = false,
		["impactPlayed"] = false,
		["born"] = nil,
		["mine"] = nil,
		["far"] = nil,
		["spin"] = nil,
		["predict"] = nil,
		["origin"] = nil,
		["view"] = nil,
		["key"] = p375,
		["kind"] = p376,
		["model"] = v386,
		["shot"] = v_u_9.new(p377, p378, p379, 0),
		["params"] = v_u_14.ParamsOverride and v_u_14.ParamsOverride(p380) or v_u_344(p380),
		["born"] = os.clock(),
		["mine"] = v382,
		["far"] = v383,
		["spin"] = v_u_308[p376] or 0,
		["predict"] = p381,
		["origin"] = p377
	}
	local v390
	if v382 and (v_u_313 and v_u_10.InFirstPerson()) then
		v390 = {
			["at"] = nil,
			["t0"] = 0,
			["dur"] = nil,
			["trails"] = nil
		}
		local v391 = os.clock()
		local v392 = not v_u_314 and 0 or v_u_314()
		v390.at = v391 + math.clamp(v392, 0, 0.3)
		v390.dur = v_u_312[p376] or 0.12
		v390.trails = {}
	else
		v390 = nil
	end
	v389.view = v390
	local v393 = v389.view
	if v393 then
		for _, v394 in v386:GetDescendants() do
			if not (v394:IsA("Trail") and v394.Enabled) then
				continue
			end
			v394.Enabled = false
			local v395 = v393.trails
			table.insert(v395, v394)
		end
	end
	local v396 = v_u_310[p375]
	if v396 then
		if not v396.landed then
			v_u_348 = v_u_348 - 1
		end
		if v396.stopLoop then
			v396.stopLoop(0)
		end
		v_u_55(v396.model)
	end
	local v397 = p376 == "FireBomb" and "FireBomb_Fuse" or (p376 == "Beehive" and "Bees_Loop" or (p376 == "Hatchet" and "Hatchet_Spin" or nil))
	if v397 and not v383 then
		local v398
		if v386:IsA("Model") then
			v398 = v386.PrimaryPart
		elseif v386:IsA("BasePart") then
			v398 = v386
		else
			v398 = nil
		end
		if v398 then
			v389.stopLoop = v_u_10.Loop(v397, v398)
		end
	end
	v_u_310[p375] = v389
	v_u_348 = v_u_348 + 1
	if p376 == "Harpoon" and not v383 then
		v_u_374(p375, v386, p380)
	end
	return v389
end
function v_u_14.Pellets(p399, p400, p401, p402, p403, p404, p405, p406, p407, p408, p409) -- name: Pellets
	-- upvalues: (copy) v_u_7, (copy) v_u_14
	for v410, v411 in v_u_7.PelletDirs(p402, p405, p406, p407) do
		v_u_14.Projectile(("%*/%*"):format(p399, v410), p400, p401, v411 * p403, p404, p408, p409)
	end
end
local v_u_412 = {}
local function v_u_421(p413, p414, p415) -- name: hitSound
	-- upvalues: (copy) v_u_307, (copy) v_u_412, (copy) v_u_10
	local v416 = v_u_307[p413]
	if v416 then
		local v417 = p413 .. (p414 and "b" or "w")
		local v418 = os.clock()
		if p413 ~= "Pellet" or v418 - (v_u_412[v417] or 0) >= 0.06 then
			v_u_412[v417] = v418
			local v419 = v_u_10.Sound
			local v420
			if p414 then
				v420 = v416[1]
			else
				v420 = v416[2]
			end
			v419(v420, p415)
		end
	else
		return
	end
end
local function v_u_445(p422, p423, p424, p425, p426, p427, p428) -- name: landCosmetic
	-- upvalues: (ref) v_u_348, (copy) v_u_352, (ref) v_u_353, (copy) v_u_5, (copy) v_u_1, (copy) v_u_7, (copy) v_u_14, (copy) v_u_306, (copy) v_u_321, (copy) v_u_421, (copy) v_u_327
	if not p422.landed then
		v_u_348 = v_u_348 - 1
	end
	p422.landed = true
	if p422.stopLoop then
		p422.stopLoop(0.1)
		p422.stopLoop = nil
	end
	if p422.kind == "Harpoon" and v_u_352[p422.key] then
		v_u_353 = v_u_353 + 1
		v_u_352[p422.key].token = v_u_353
		local v_u_429 = p422.key
		local v430 = p426 and 0.75 or 0.2
		local v_u_431 = v_u_352[v_u_429]
		if v_u_431 then
			local v_u_432 = v_u_431.token
			task.delay(v430, function()
				-- upvalues: (ref) v_u_352, (copy) v_u_429, (copy) v_u_432, (copy) v_u_431, (ref) v_u_5, (ref) v_u_1
				local v433 = v_u_352[v_u_429]
				if v433 and v433.token == v_u_432 then
					v_u_352[v_u_429] = nil
				end
				if v_u_431.beam.Parent then
					v_u_5:Create(v_u_431.beam, TweenInfo.new(0.15), {
						["Width0"] = 0,
						["Width1"] = 0
					}):Play()
				end
				v_u_1:AddItem(v_u_431.beam, 0.2)
				v_u_1:AddItem(v_u_431.a0, 0.2)
				v_u_1:AddItem(v_u_431.a1, 0.2)
			end)
		end
	end
	if p426 and (p422.mine and (p427 and not p422.impactPlayed)) then
		local v434 = nil
		local v435 = false
		local v436 = p422.predict
		if v436 then
			local v437 = v436.damage
			if type(v437) == "number" then
				local v438 = v436.tuning or {}
				v435 = v_u_7.IsHeadPart(p428)
				v434 = v436.damage * v_u_7.Falloff(v438, (p423 - p422.origin).Magnitude) * (v435 and (v438.headshotMult or 1.5) or 1)
			end
		end
		v_u_14.PredictHit(p427, nil, p423, true, v434, v435)
	end
	local v439 = p422.shot.vel.Magnitude <= 0 and Vector3.new(0, 0, 1) or p422.shot.vel.Unit
	local v440 = not p422.far
	if not v440 then
		local v441 = workspace.CurrentCamera
		v440 = (not v441 and 0 or (v441.CFrame.Position - p423).Magnitude) <= v_u_14.NEAR
	end
	if v_u_306[p422.kind] then
		local v442 = p422.model
		local v443 = CFrame.lookAt(p423 - v439 * 0.6, p423 - v439 * 0.6 + v439)
		if v442:IsA("Model") then
			v442:PivotTo(v443)
		elseif v442:IsA("BasePart") then
			v442.CFrame = v443
		end
		v_u_321(p422.model, 0.2, 4)
		if not p422.impactPlayed and v440 then
			p422.impactPlayed = true
			if not p426 then
				v_u_14.Impact(p423, p424, p425, false, p422.kind == "Javelin" and 1.3 or 0.8)
			end
			v_u_421(p422.kind, p426, p423)
			return
		end
	elseif p422.kind == "Ball" or (p422.kind == "Pellet" or (p422.kind == "Stone" or (p422.kind == "Bolas" or p422.kind == "Hatchet"))) then
		v_u_327(p422.model)
		v_u_321(p422.model, 0.08)
		if not p422.impactPlayed and v440 then
			p422.impactPlayed = true
			local v444 = p422.kind == "Pellet"
			if not p426 then
				v_u_14.Impact(p423, p424, p425, false, v444 and 0.45 or (p422.kind == "Stone" and 0.9 or 0.8))
			end
			v_u_421(p422.kind, p426, p423)
			return
		end
	else
		v_u_327(p422.model)
		v_u_321(p422.model, 0.15)
	end
end
local v_u_446 = false
local v_u_447 = {}
local v_u_448 = {}
v_u_4.Heartbeat:Connect(function(p449)
	-- upvalues: (ref) v_u_446, (copy) v_u_447, (copy) v_u_448, (copy) v_u_310, (ref) v_u_348, (copy) v_u_9, (copy) v_u_7, (copy) v_u_445, (copy) v_u_55, (ref) v_u_313, (copy) v_u_311, (copy) v_u_309, (copy) v_u_66, (copy) v_u_11
	local v450 = os.clock()
	v_u_446 = not v_u_446
	table.clear(v_u_447)
	table.clear(v_u_448)
	for v451, v452 in v_u_310 do
		if v452.landed then
			if os.clock() - v452.born <= 10 then
				continue
			end
			v_u_310[v451] = nil
		elseif v452.model.Parent then
			local v453, v454 = v_u_9.Advance(v452.shot, p449)
			local v455 = nil
			if not v452.far then
				if v452.mine then
					v455 = workspace:Raycast(v453, v454, v452.params)
				else
					local v456 = v452.castFrom or v453
					if v_u_446 or (v452.shot.pos - v456).Magnitude > 30 then
						v455 = workspace:Raycast(v456, v452.shot.pos - v456, v452.params)
						v452.castFrom = v452.shot.pos
					elseif not v452.castFrom then
						v452.castFrom = v453
					end
				end
			end
			if v455 then
				local v457 = v_u_7.FindCharacter(v455.Instance)
				v_u_445(v452, v455.Position, v455.Normal, v455.Material.Name, v457 ~= nil, v457, v455.Instance)
			elseif v_u_9.Expired(v452.shot) then
				if v452.stopLoop then
					v452.stopLoop(0)
					v452.stopLoop = nil
				end
				v_u_55(v452.model)
				v_u_310[v451] = nil
				v_u_348 = v_u_348 - 1
			else
				if v452.far and not v_u_446 then
					continue
				end
				local v458 = v452.shot.vel
				local v459 = v452.shot.pos
				local v460 = v452.view
				if v460 then
					local v461 = os.clock()
					local v462 = workspace.CurrentCamera
					if v461 < v460.at then
						v459 = v452.shot.pos - Vector3.new(0, 10000, 0)
					else
						if v460.t0 == 0 then
							v460.t0 = v461
							v452.spinT0 = v461
							local v463 = v_u_313
							if v463 then
								v463 = v_u_313()
							end
							if v463 and v462 then
								local v464 = v462.CFrame
								v460.p0 = v464:PointToObjectSpace(v464.Position + (v463 - v464.Position) * (v_u_311[v452.kind] or 4))
							end
							for _, v465 in v460.trails do
								v465:Clear()
								v465.Enabled = true
							end
						end
						local v466 = (v461 - v460.t0) / v460.dur
						local v467 = math.clamp(v466, 0, 1)
						local v468 = 1 - (1 - v467) * (1 - v467)
						local v469 = v460.p0
						if v469 and v462 then
							local v470 = v462.CFrame
							local v471 = v470:PointToObjectSpace(v452.shot.pos)
							if v471.Z < -0.05 and v469.Z < -0.05 then
								local v472 = -v469.Z
								local v473 = -v471.Z
								local v474 = v472 + (v473 - v472) * v468
								local v475 = v469.X / v472 + (v471.X / v473 - v469.X / v472) * v468
								local v476 = v469.Y / v472 + (v471.Y / v473 - v469.Y / v472) * v468
								local v477 = v475 * v474
								local v478 = v476 * v474
								local v479 = -v474
								v459 = v470:PointToWorldSpace((Vector3.new(v477, v478, v479)))
							end
						end
						if v467 >= 1 then
							v452.view = nil
						end
					end
				end
				if v458.Magnitude <= 0.01 then
					continue
				end
				local v480 = CFrame.lookAt(v459, v459 + v458)
				if v452.spin > 0 then
					local v481 = (os.clock() - (v452.spinT0 or v452.born)) * v452.spin
					local v482
					if v_u_309[v452.kind] then
						v482 = CFrame.Angles(0, v481, 0)
					else
						v482 = CFrame.Angles(-v481, 0, 0)
					end
					v480 = v480 * v482
				end
				local v483 = v_u_66(v452.model)
				for v484, v485 in v483.parts do
					local v486 = v_u_447
					table.insert(v486, v485)
					local v487 = v_u_448
					local v488 = v480 * v483.rels[v484]
					table.insert(v487, v488)
				end
			end
		else
			v_u_310[v451] = nil
			v_u_348 = v_u_348 - 1
		end
	end
	if #v_u_447 > 0 then
		workspace:BulkMoveTo(v_u_447, v_u_448, Enum.BulkMoveMode.FireCFrameChanged)
	end
	v_u_11.AddProj(os.clock() - v450, v_u_348)
end)
function v_u_14.ResolveProjectile(p489) -- name: ResolveProjectile
	-- upvalues: (copy) v_u_310, (copy) v_u_55, (ref) v_u_348, (copy) v_u_445, (copy) v_u_306, (copy) v_u_14
	local v490 = p489.key
	if type(v490) == "string" then
		local v491 = v_u_310[v490]
		if p489.expired then
			if v491 and not v491.landed then
				if v491.stopLoop then
					v491.stopLoop(0)
					v491.stopLoop = nil
				end
				v_u_55(v491.model)
				v_u_310[v490] = nil
				v_u_348 = v_u_348 - 1
			end
			return
		else
			local v492 = p489.position
			if typeof(v492) == "Vector3" then
				local v493 = p489.character ~= nil
				if v491 then
					if not v491.landed then
						v_u_445(v491, v492, p489.normal, p489.material, v493)
					end
					local v494 = p489.part
					local v495 = p489.rel
					if v491.model:GetAttribute("CosKey") == v490 and (v_u_306[v491.kind] and (typeof(v494) == "Instance" and (v494:IsA("BasePart") and (typeof(v495) == "CFrame" and v491.model.Parent)))) then
						local v496 = v491.model
						local v497 = v494.CFrame * v495
						if v496:IsA("Model") then
							v496:PivotTo(v497)
						elseif v496:IsA("BasePart") then
							v496.CFrame = v497
						end
						local v498
						if v491.model:IsA("Model") then
							v498 = v491.model.PrimaryPart
						elseif v491.model:IsA("BasePart") then
							v498 = v491.model
						else
							v498 = nil
						end
						if v498 and not v494.Anchored then
							for _, v499 in v491.model:GetDescendants() do
								if not v499:IsA("BasePart") then
									continue
								end
								v499.Anchored = false
								v499.Massless = true
							end
							if v491.model:IsA("BasePart") then
								v491.model.Anchored = false
							end
							local v500 = Instance.new("WeldConstraint")
							v500.Name = "StickWeld"
							v500.Part0 = v494
							v500.Part1 = v498
							v500.Parent = v498
							return
						end
					end
				else
					local v501 = workspace.CurrentCamera
					if (not v501 and 0 or (v501.CFrame.Position - v492).Magnitude) <= v_u_14.NEAR then
						if v493 then
							v_u_14.CharacterImpact(v492, nil, false)
							return
						end
						if p489.kind ~= "FireBomb" and (p489.kind ~= "SmokeBomb" and (p489.kind ~= "Flask" and (p489.kind ~= "Caltrops" and p489.kind ~= "Beehive"))) then
							v_u_14.Impact(v492, p489.normal, p489.material, p489.kind ~= "Pellet", p489.kind == "Pellet" and 0.45 or 0.8)
						end
					end
				end
			end
		end
	else
		return
	end
end
function v_u_14.Explosion(p502, p503, p504, p505) -- name: Explosion
	-- upvalues: (copy) v_u_14, (copy) v_u_10, (ref) v_u_17, (copy) v_u_5, (copy) v_u_1, (copy) v_u_12, (copy) v_u_98, (copy) v_u_15
	local v506 = workspace.CurrentCamera
	local v507 = (not v506 and 0 or (v506.CFrame.Position - p502).Magnitude) > v_u_14.NEAR
	v_u_14.Burst("Explosion_Fire", CFrame.new(p502), p503 / 9 * (v507 and 0.5 or 1), Color3.fromRGB(245, 140, 50), true)
	v_u_10.Sound("FireBomb_Explode", p502)
	local v508 = p504 or p503 * 0.8
	local v509 = p505 or 2.2
	local v510 = v_u_10.WorldParams(v_u_10.Targets())
	local v511 = workspace
	local v512 = p502 + Vector3.new(0, 1.5, 0)
	local v513 = -(p503 + 1.5)
	local v514 = v511:Raycast(v512, Vector3.new(0, v513, 0), v510)
	local v515, v516
	if v514 then
		v515 = v514.Position
		v516 = v514.Normal
	else
		v515 = nil
		v516 = nil
	end
	if not v507 then
		local v517 = CFrame.new(p502)
		local v518, v519, v520 = Color3.fromRGB(245, 125, 40)
		local v521 = Instance.new("Part")
		v521.Name = "ExplosionCore"
		v521.Anchored = true
		v521.CanCollide = false
		v521.CanQuery = false
		v521.CanTouch = false
		v521.CastShadow = false
		v521.Size = Vector3.new(1.5, 1.5, 1.5)
		v521.CFrame = v517
		v521.Color = v518
		v521.Material = v519 or Enum.Material.SmoothPlastic
		v521.Transparency = v520 or 0
		local v522 = workspace:FindFirstChild("FX")
		if v522 then
			v_u_17 = v522
		end
		v521.Parent = v_u_17
		v521.Shape = Enum.PartType.Ball
		v521.Transparency = 0.3
		v_u_5:Create(v521, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Size"] = nil,
			["Transparency"] = 1,
			["Color"] = nil,
			["Size"] = Vector3.new(1, 1, 1) * p503 * 0.7,
			["Color"] = Color3.fromRGB(200, 70, 25)
		}):Play()
		v_u_1:AddItem(v521, 0.25)
		local v523 = Instance.new("PointLight")
		v523.Color = Color3.fromRGB(255, 140, 60)
		v523.Range = 16
		v523.Brightness = 1
		v523.Parent = v521
		local v524 = CFrame.new(p502)
		local v525 = Color3.new()
		local v526 = Enum.Material.SmoothPlastic
		local v527 = Instance.new("Part")
		v527.Name = "PuffFX"
		v527.Anchored = true
		v527.CanCollide = false
		v527.CanQuery = false
		v527.CanTouch = false
		v527.CastShadow = false
		v527.Size = Vector3.new(1, 1, 1)
		v527.CFrame = v524
		v527.Color = v525
		v527.Material = v526 or Enum.Material.SmoothPlastic
		v527.Transparency = 1
		local v528 = workspace:FindFirstChild("FX")
		if v528 then
			v_u_17 = v528
		end
		v527.Parent = v_u_17
		local v529 = Instance.new("ParticleEmitter")
		v529.Texture = "rbxasset://textures/particles/sparkles_main.dds"
		v529.Color = ColorSequence.new(Color3.fromRGB(255, 170, 70), Color3.fromRGB(230, 90, 30))
		v529.LightEmission = 0.35
		v529.LightInfluence = 0.4
		v529.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(1, 0) })
		v529.Lifetime = NumberRange.new(0.6, 1.1)
		v529.Speed = NumberRange.new(10, 22)
		v529.SpreadAngle = Vector2.new(70, 70)
		v529.EmissionDirection = Enum.NormalId.Top
		v529.Acceleration = Vector3.new(0, -24, 0)
		v529.Rate = 0
		v529.Parent = v527
		local v530 = 20 * v_u_12.particleScale + 0.5
		v529:Emit((math.floor(v530)))
		v_u_1:AddItem(v527, 1.3)
	end
	if v515 and v516 then
		if not v507 then
			v_u_98(v515, v516, "rbxassetid://10871117278", Color3.fromRGB(235, 140, 70), 2, p503 * 2.4, 0.26, 0.3)
		end
		v_u_98(v515, v516, "rbxassetid://10430755572", Color3.fromRGB(60, 32, 22), v508 * 2, v508 * 2.1, 0.15, 0.25, v509)
		local v531 = v507 and 5 or 10
		for v532 = 1, v531 do
			local v533 = v532 / v531 * 3.141592653589793 * 2 + math.random() * 0.5
			local v534
			if v532 == 1 then
				v534 = 0
			else
				local v535 = math.random()
				v534 = v508 * (math.sqrt(v535) * 0.65 + 0.25)
			end
			local v536 = math.cos(v533) * v534
			local v537 = math.sin(v533) * v534
			local v538 = v515 + Vector3.new(v536, 0.4, v537)
			local v539 = CFrame.new(v538)
			local v540 = Color3.new()
			local v541 = Enum.Material.SmoothPlastic
			local v542 = Instance.new("Part")
			v542.Name = "PuffFX"
			v542.Anchored = true
			v542.CanCollide = false
			v542.CanQuery = false
			v542.CanTouch = false
			v542.CastShadow = false
			v542.Size = Vector3.new(2, 0.5, 2)
			v542.CFrame = v539
			v542.Color = v540
			v542.Material = v541 or Enum.Material.SmoothPlastic
			v542.Transparency = 1
			local v543 = workspace:FindFirstChild("FX")
			if v543 then
				v_u_17 = v543
			end
			v542.Parent = v_u_17
			local v_u_544 = Instance.new("ParticleEmitter")
			v_u_544.Texture = "rbxasset://textures/particles/fire_main.dds"
			v_u_544.Color = ColorSequence.new(Color3.fromRGB(255, 190, 80), Color3.fromRGB(235, 90, 30))
			v_u_544.LightEmission = 0.35
			v_u_544.LightInfluence = 0.3
			v_u_544.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 2.5), NumberSequenceKeypoint.new(0.4, 4.5), NumberSequenceKeypoint.new(1, 0) })
			v_u_544.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(1, 1) })
			v_u_544.Lifetime = NumberRange.new(0.6, 0.9)
			v_u_544.Speed = NumberRange.new(3, 5)
			v_u_544.SpreadAngle = Vector2.new(10, 10)
			v_u_544.EmissionDirection = Enum.NormalId.Top
			v_u_544.Rotation = NumberRange.new(-20, 20)
			v_u_544.Rate = (v507 and 0.6 or 1) * 14
			v_u_544.Shape = Enum.ParticleEmitterShape.Box
			v_u_544.Parent = v542
			task.delay(v509, function()
				-- upvalues: (copy) v_u_544
				v_u_544.Enabled = false
			end)
			v_u_1:AddItem(v542, v509 + 1)
		end
		local v545 = v515 + Vector3.new(0, 1.5, 0)
		local v546 = Vector3.new(v508, 1, v508)
		local v547 = CFrame.new(v545)
		local v548 = Color3.new()
		local v549 = Enum.Material.SmoothPlastic
		local v550 = Instance.new("Part")
		v550.Name = "PuffFX"
		v550.Anchored = true
		v550.CanCollide = false
		v550.CanQuery = false
		v550.CanTouch = false
		v550.CastShadow = false
		v550.Size = v546
		v550.CFrame = v547
		v550.Color = v548
		v550.Material = v549 or Enum.Material.SmoothPlastic
		v550.Transparency = 1
		local v551 = workspace:FindFirstChild("FX")
		if v551 then
			v_u_17 = v551
		end
		v550.Parent = v_u_17
		local v_u_552 = Instance.new("ParticleEmitter")
		v_u_552.Texture = "rbxasset://textures/particles/smoke_main.dds"
		v_u_552.Color = ColorSequence.new(Color3.fromRGB(80, 55, 45))
		v_u_552.LightEmission = 0
		v_u_552.LightInfluence = 1
		v_u_552.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 2), NumberSequenceKeypoint.new(1, 5) })
		v_u_552.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.6), NumberSequenceKeypoint.new(1, 1) })
		v_u_552.Lifetime = NumberRange.new(1.5, 2.2)
		v_u_552.Speed = NumberRange.new(3, 5)
		v_u_552.EmissionDirection = Enum.NormalId.Top
		v_u_552.SpreadAngle = Vector2.new(8, 8)
		v_u_552.Rate = 6
		v_u_552.Parent = v550
		task.delay(v509, function()
			-- upvalues: (copy) v_u_552
			v_u_552.Enabled = false
		end)
		v_u_1:AddItem(v550, v509 + 2.5)
	end
	local v553 = v_u_15.Character
	if v553 then
		v553 = v553:FindFirstChild("HumanoidRootPart")
	end
	if v553 then
		local v554 = (v553.Position - p502).Magnitude
		if v554 < p503 * 4 then
			local v555 = v_u_10.Shake
			local v556 = 1.4 * (1 - v554 / (p503 * 4))
			v555(math.clamp(v556, 0.2, 1.4), 0.45)
		end
	end
end
function v_u_14.SmokeCloud(p557, p558, p559) -- name: SmokeCloud
	-- upvalues: (copy) v_u_7, (ref) v_u_17, (copy) v_u_14, (copy) v_u_10
	v_u_7.AddSmoke(p557, p558, p559)
	local v560 = p558 * 1.5
	local v561 = p558 * 0.9
	local v562 = p558 * 1.5
	local v563 = Vector3.new(v560, v561, v562)
	local v564 = CFrame.new(p557)
	local v565 = Color3.new()
	local v566 = Enum.Material.SmoothPlastic
	local v_u_567 = Instance.new("Part")
	v_u_567.Name = "PuffFX"
	v_u_567.Anchored = true
	v_u_567.CanCollide = false
	v_u_567.CanQuery = false
	v_u_567.CanTouch = false
	v_u_567.CastShadow = false
	v_u_567.Size = v563
	v_u_567.CFrame = v564
	v_u_567.Color = v565
	v_u_567.Material = v566 or Enum.Material.SmoothPlastic
	v_u_567.Transparency = 1
	local v568 = workspace:FindFirstChild("FX")
	if v568 then
		v_u_17 = v568
	end
	v_u_567.Parent = v_u_17
	local v_u_569 = Color3.fromRGB(176, 180, 186)
	local function v576(p570, p571, p572, p573, p574) -- name: emitter
		-- upvalues: (copy) v_u_569, (copy) v_u_567
		local v575 = Instance.new("ParticleEmitter")
		v575.Name = p570
		v575.Texture = "rbxasset://textures/particles/smoke_main.dds"
		v575.Color = ColorSequence.new(v_u_569)
		v575.LightEmission = 0
		v575.LightInfluence = 1
		v575.Shape = Enum.ParticleEmitterShape.Sphere
		v575.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
		v575.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p571), NumberSequenceKeypoint.new(1, p572) })
		v575.Transparency = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.15, 0.06),
			NumberSequenceKeypoint.new(0.75, 0.12),
			NumberSequenceKeypoint.new(1, 1)
		})
		v575.Lifetime = NumberRange.new(p573 * 0.8, p573)
		v575.Rate = p574
		v575.Speed = NumberRange.new(0.4, 1.4)
		v575.SpreadAngle = Vector2.new(180, 180)
		v575.Rotation = NumberRange.new(0, 360)
		v575.RotSpeed = NumberRange.new(-12, 12)
		v575.Drag = 1
		v575.Parent = v_u_567
		return v575
	end
	local v_u_577 = v576("Body", p558 * 0.7, p558 * 0.95, 3.2, 34)
	local v_u_578 = v576("Low", p558 * 0.5, p558 * 0.7, 2.6, 16)
	v_u_578.Acceleration = Vector3.new(0, -0.6, 0)
	v_u_577:Emit(30)
	v_u_578:Emit(10)
	v_u_14.Puff(p557, v_u_569, 14, p558 * 0.4, 16, 0.8)
	v_u_10.Sound("Smoke_Pop", p557)
	local v579 = task.delay
	local v580 = p559 - 2.6
	v579(math.max(0.5, v580), function()
		-- upvalues: (copy) v_u_577, (copy) v_u_578
		v_u_577.Enabled = false
		v_u_578.Enabled = false
	end)
	task.delay(p559 + 1.5, function()
		-- upvalues: (copy) v_u_567
		v_u_567:Destroy()
	end)
end
function v_u_14.TrapSnap(p581) -- name: TrapSnap
	-- upvalues: (copy) v_u_14, (copy) v_u_10
	v_u_14.Burst("Impact_Sparks", CFrame.new(p581 + Vector3.new(0, 0.5, 0)), 1.4)
	v_u_14.Burst("Impact_Dust", CFrame.lookAt(p581, p581 + Vector3.new(0, 1, 0)), 1.2)
	v_u_10.Sound("Trap_Snap", p581)
end
function v_u_14.ChargeGlow(p582, p583, p584) -- name: ChargeGlow
	-- upvalues: (copy) v_u_10, (copy) v_u_14, (copy) v_u_12
	if p582 then
		local v585 = v_u_10.Drawn(p582) or p582
		local v586 = p584 or v_u_14.WeaponColor(p582)
		if p583 <= 0.01 then
			for _, v587 in { p582, v585 } do
				local v588 = v587:FindFirstChild("CombatChargeHL")
				if v588 then
					v588:Destroy()
				end
				local v589 = v587:FindFirstChild("Muzzle", true)
				if v589 then
					v589 = v589:FindFirstChild("CombatGlow")
				end
				if not v589 then
					continue
				end
				v589:Destroy()
			end
		else
			local v590 = v585:FindFirstChild("CombatChargeHL")
			local v591 = v585:FindFirstChild("Muzzle", true)
			local v592
			if v591 then
				v592 = v591:FindFirstChild("CombatGlow")
			else
				v592 = v591
			end
			if not v590 and v_u_12.highlights then
				v590 = Instance.new("Highlight")
				v590.Name = "CombatChargeHL"
				v590.DepthMode = Enum.HighlightDepthMode.Occluded
				v590.Adornee = v585
				v590.FillTransparency = 1
				v590.Parent = v585
			end
			if v590 then
				v590.OutlineColor = v586
				v590.OutlineTransparency = 1 - p583 * (p583 >= 1 and 0.9 or 0.6)
			end
			if v591 and v591:IsA("Attachment") then
				if not v592 then
					v592 = Instance.new("PointLight")
					v592.Name = "CombatGlow"
					v592.Range = 5
					v592.Shadows = false
					v592.Parent = v591
				end
				v592.Color = v586
				local v593 = p583 * 0.8
				v592.Brightness = math.min(1, v593)
			end
		end
	else
		return
	end
end
function v_u_14.ChargePing(p594, p595) -- name: ChargePing
	-- upvalues: (copy) v_u_10, (ref) v_u_17, (copy) v_u_5, (copy) v_u_1, (copy) v_u_14
	local v596 = v_u_10.Drawn(p594)
	if v596 then
		v596 = v596:FindFirstChild("Muzzle", true) or v596:FindFirstChild("Tip", true)
	end
	if v596 and v596:IsA("Attachment") then
		local v597 = v596.WorldCFrame
		local v598 = p595 or Color3.fromRGB(245, 175, 60)
		local v599 = Enum.Material.ForceField
		local v600 = Instance.new("Part")
		v600.Name = "ChargePing"
		v600.Anchored = true
		v600.CanCollide = false
		v600.CanQuery = false
		v600.CanTouch = false
		v600.CastShadow = false
		v600.Size = Vector3.new(0.3, 0.3, 0.3)
		v600.CFrame = v597
		v600.Color = v598
		v600.Material = v599 or Enum.Material.SmoothPlastic
		v600.Transparency = 0
		local v601 = workspace:FindFirstChild("FX")
		if v601 then
			v_u_17 = v601
		end
		v600.Parent = v_u_17
		v600.Shape = Enum.PartType.Ball
		v_u_5:Create(v600, TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Size"] = Vector3.new(1.8, 1.8, 1.8),
			["Transparency"] = 1
		}):Play()
		v_u_1:AddItem(v600, 0.25)
		v_u_14.Burst("Charge_Sparkle", v596.WorldCFrame, 1, p595, p595 ~= nil)
	end
end
function v_u_14.Heal(p602, p603) -- name: Heal
	-- upvalues: (copy) v_u_10, (copy) v_u_14, (copy) v_u_12, (copy) v_u_1
	if p602 and p602:IsA("Model") then
		local v604 = v_u_10.Drawn(p602)
		if v604 then
			if not v604:IsA("Model") then
				v604 = p602
			end
		else
			v604 = p602
		end
		local v605 = v604:FindFirstChild("UpperTorso") or (v604:FindFirstChild("Torso") or v604:FindFirstChild("HumanoidRootPart"))
		if not (v605 and v605:IsA("BasePart")) then
			v605 = nil
		end
		if v605 then
			v_u_14.Burst("Heal_Health", v605.CFrame)
			v_u_10.Sound("Herbs_Heal", v605)
			local v606 = Instance.new("Attachment")
			v606.Name = "CombatHealFX"
			v606.Parent = v605
			local v_u_607 = Instance.new("ParticleEmitter")
			v_u_607.Texture = "rbxasset://textures/particles/sparkles_main.dds"
			v_u_607.Color = ColorSequence.new(Color3.fromRGB(120, 220, 110))
			v_u_607.LightEmission = 0.3
			v_u_607.LightInfluence = 0.5
			v_u_607.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(1, 0) })
			v_u_607.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 1) })
			v_u_607.Lifetime = NumberRange.new(0.6, 1)
			v_u_607.Speed = NumberRange.new(1.5, 3)
			v_u_607.SpreadAngle = Vector2.new(40, 40)
			v_u_607.EmissionDirection = Enum.NormalId.Top
			v_u_607.Shape = Enum.ParticleEmitterShape.Cylinder
			v_u_607.Rate = 16 * v_u_12.particleScale
			v_u_607.Parent = v606
			task.delay(p603, function()
				-- upvalues: (copy) v_u_607
				v_u_607.Enabled = false
			end)
			v_u_1:AddItem(v606, p603 + 1.2)
		end
	else
		return
	end
end
local v_u_608 = {}
function v_u_14.Status(p_u_609, p_u_610, p611) -- name: Status
	-- upvalues: (copy) v_u_10, (copy) v_u_14, (copy) v_u_608, (copy) v_u_21, (copy) v_u_1
	if p_u_609 and p_u_609:IsA("Model") then
		local v612 = v_u_10.Drawn(p_u_609)
		local v613
		if v612 and v612:IsA("Model") then
			v613 = v612
		else
			v613 = p_u_609
		end
		local v614 = v613:FindFirstChild("UpperTorso") or (v613:FindFirstChild("Torso") or v613:FindFirstChild("HumanoidRootPart"))
		if not (v614 and v614:IsA("BasePart")) then
			v614 = nil
		end
		if v614 then
			if p_u_610 == "Snare" then
				local v615 = v_u_14.Snare
				if v612 then
					if not v612:IsA("Model") then
						v612 = p_u_609
					end
				else
					v612 = p_u_609
				end
				v615(v612, p611)
				return
			elseif p_u_610 == "Burn" then
				local v_u_616 = v_u_608[p_u_609]
				if not v_u_616 then
					v_u_616 = {}
					v_u_608[p_u_609] = v_u_616
					p_u_609.Destroying:Once(function()
						-- upvalues: (ref) v_u_608, (copy) p_u_609
						v_u_608[p_u_609] = nil
					end)
				end
				local v_u_617 = v_u_616[p_u_610]
				if not (v_u_617 and v_u_617.inst.Parent) then
					local v618 = v_u_21("Status_Burn")
					if not v618 then
						return
					end
					local v619 = v618:Clone()
					if not v619:IsA("Attachment") then
						v619:Destroy()
						return
					end
					v619.Parent = v614
					v_u_617 = {
						["inst"] = nil,
						["token"] = 0,
						["inst"] = v619
					}
					v_u_616[p_u_610] = v_u_617
				end
				v_u_617.token = v_u_617.token + 1
				local v_u_620 = v_u_617.token
				task.delay(p611, function()
					-- upvalues: (copy) v_u_617, (copy) v_u_620, (ref) v_u_1, (ref) v_u_616, (copy) p_u_610
					if v_u_617.token == v_u_620 then
						for _, v621 in v_u_617.inst:GetDescendants() do
							if not v621:IsA("ParticleEmitter") then
								continue
							end
							v621.Enabled = false
						end
						v_u_1:AddItem(v_u_617.inst, 1)
						if v_u_616[p_u_610] == v_u_617 then
							v_u_616[p_u_610] = nil
						end
					end
				end)
			end
		else
			return
		end
	else
		return
	end
end
local v_u_622 = {}
function v_u_14.Snare(p_u_623, p624) -- name: Snare
	-- upvalues: (copy) v_u_622, (copy) v_u_10
	local v_u_625 = (v_u_622[p_u_623] or 0) + 1
	v_u_622[p_u_623] = v_u_625
	local v626 = p_u_623:FindFirstChild("CombatSnareFX")
	if v626 then
		v626:Destroy()
	end
	local v_u_627 = p_u_623:FindFirstChild("LeftLowerLeg")
	local v628 = p_u_623:FindFirstChild("RightLowerLeg")
	if not (v_u_627 and v_u_627:IsA("BasePart")) then
		v_u_627 = nil
	end
	if not (v628 and v628:IsA("BasePart")) then
		v628 = nil
	end
	if v_u_627 and v628 then
		local v_u_629 = Instance.new("Model")
		v_u_629.Name = "CombatSnareFX"
		local v630 = v_u_627.CFrame:PointToObjectSpace(v628.Position)
		local v631 = CFrame.new(v630 / 2)
		local v632 = v630.X
		local v633 = math.abs(v632) + v_u_627.Size.X + 0.16
		local v634 = v_u_627.Size.Z + 0.16
		local v635 = Color3.fromRGB(196, 164, 112)
		local function v643(p636, p637, p638, p639, p640) -- name: piece
			-- upvalues: (copy) v_u_627, (copy) v_u_629
			local v641 = Instance.new("Part")
			v641.Name = p636
			v641.Size = p637
			v641.Color = p639
			v641.Material = Enum.Material.SmoothPlastic
			if p640 then
				v641.Shape = Enum.PartType.Ball
			end
			v641.CanCollide = false
			v641.CanQuery = false
			v641.CanTouch = false
			v641.Massless = true
			v641.CastShadow = false
			v641.CFrame = v_u_627.CFrame * p638
			local v642 = Instance.new("WeldConstraint")
			v642.Part0 = v_u_627
			v642.Part1 = v641
			v642.Parent = v641
			v641.Parent = v_u_629
		end
		for v644, v645 in { 0.28, 0.05, -0.2 } do
			local v646 = "Wrap" .. v644
			local v647 = Vector3.new(v633, 0.1, v634)
			local v648 = v631 * CFrame.new(0, v645, 0)
			local v649 = CFrame.Angles
			local v650 = v644 == 2 and -6 or 5
			local v651 = v648 * v649(0, 0, (math.rad(v650)))
			local v652 = Instance.new("Part")
			v652.Name = v646
			v652.Size = v647
			v652.Color = v635
			v652.Material = Enum.Material.SmoothPlastic
			v652.CanCollide = false
			v652.CanQuery = false
			v652.CanTouch = false
			v652.Massless = true
			v652.CastShadow = false
			v652.CFrame = v_u_627.CFrame * v651
			local v653 = Instance.new("WeldConstraint")
			v653.Part0 = v_u_627
			v653.Part1 = v652
			v653.Parent = v652
			v652.Parent = v_u_629
		end
		v643("StoneA", Vector3.new(0.46, 0.46, 0.46), v631 * CFrame.new(v633 / 2 + 0.05, -0.05, 0.2), Color3.fromRGB(128, 124, 118), true)
		v643("StoneB", Vector3.new(0.46, 0.46, 0.46), v631 * CFrame.new(-v633 / 2 - 0.05, 0.2, -0.2), Color3.fromRGB(96, 92, 88), true)
		v_u_629.Parent = p_u_623
		v_u_10.Sound("Stone_Hit", v_u_627)
		task.delay(p624, function()
			-- upvalues: (ref) v_u_622, (copy) p_u_623, (copy) v_u_625, (copy) v_u_629
			if v_u_622[p_u_623] == v_u_625 then
				v_u_622[p_u_623] = nil
				v_u_629:Destroy()
			end
		end)
		p_u_623.Destroying:Once(function()
			-- upvalues: (ref) v_u_622, (copy) p_u_623
			v_u_622[p_u_623] = nil
		end)
	end
end
local v_u_654 = {}
function v_u_14.Reveal(p_u_655, p656) -- name: Reveal
	-- upvalues: (copy) v_u_654, (copy) v_u_12, (ref) v_u_17
	local v_u_657 = (v_u_654[p_u_655] or 0) + 1
	v_u_654[p_u_655] = v_u_657
	local v658 = Color3.fromRGB(240, 170, 60)
	local v_u_659 = Instance.new("Folder")
	v_u_659.Name = "CombatReveal"
	if v_u_12.highlights then
		local v660 = Instance.new("Highlight")
		v660.Name = "Mark"
		v660.Adornee = p_u_655
		v660.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
		v660.FillColor = v658
		v660.FillTransparency = 0.78
		v660.OutlineColor = v658
		v660.OutlineTransparency = 0.1
		v660.Parent = v_u_659
	end
	local v661 = p_u_655:FindFirstChild("Head")
	if v661 and v661:IsA("BasePart") then
		local v662 = Instance.new("BillboardGui")
		v662.Name = "Pin"
		v662.Adornee = v661
		v662.AlwaysOnTop = true
		v662.Size = UDim2.fromOffset(18, 18)
		v662.StudsOffsetWorldSpace = Vector3.new(0, 2.6, 0)
		v662.LightInfluence = 0
		local v663 = Instance.new("Frame")
		v663.AnchorPoint = Vector2.new(0.5, 0.5)
		v663.Position = UDim2.fromScale(0.5, 0.5)
		v663.Size = UDim2.fromOffset(11, 11)
		v663.Rotation = 45
		v663.BackgroundColor3 = v658
		v663.BorderSizePixel = 0
		local v664 = Instance.new("UIStroke")
		v664.Thickness = 1.5
		v664.Color = Color3.fromRGB(60, 40, 10)
		v664.Parent = v663
		v663.Parent = v662
		v662.Parent = v_u_659
	end
	local v665 = workspace:FindFirstChild("FX")
	if v665 then
		v_u_17 = v665
	end
	v_u_659.Parent = v_u_17
	task.delay(p656, function()
		-- upvalues: (copy) v_u_659, (ref) v_u_654, (copy) p_u_655, (copy) v_u_657
		v_u_659:Destroy()
		if v_u_654[p_u_655] == v_u_657 then
			v_u_654[p_u_655] = nil
		end
	end)
	p_u_655.Destroying:Once(function()
		-- upvalues: (copy) v_u_659
		v_u_659:Destroy()
	end)
end
function v_u_14.HornBlast(p666) -- name: HornBlast
	-- upvalues: (copy) v_u_14, (copy) v_u_10, (ref) v_u_17, (copy) v_u_5, (copy) v_u_1
	local v667 = workspace.CurrentCamera
	if (not v667 and 0 or (v667.CFrame.Position - p666).Magnitude) <= v_u_14.NEAR then
		local v668 = v_u_10.WorldParams(v_u_10.Targets())
		local v669 = workspace:Raycast(p666 + Vector3.new(0, 1.5, 0), Vector3.new(0, -9.5, 0), v668)
		local v670, v671
		if v669 then
			v670 = v669.Position
			v671 = v669.Normal
		else
			v670 = nil
			v671 = nil
		end
		local v672 = v670 or p666 - Vector3.new(0, 2.8, 0)
		local v673 = v671 or Vector3.new(0, 1, 0)
		local v674 = CFrame.lookAt(v672 + v673 * 0.15, v672 + v673 * 1.15) * CFrame.Angles(0, 1.5707963267948966, 0)
		local v675 = Color3.fromRGB(226, 190, 110)
		local v676 = Enum.Material.SmoothPlastic
		local v677 = Instance.new("Part")
		v677.Name = "HornRing"
		v677.Anchored = true
		v677.CanCollide = false
		v677.CanQuery = false
		v677.CanTouch = false
		v677.CastShadow = false
		v677.Size = Vector3.new(0.06, 3, 3)
		v677.CFrame = v674
		v677.Color = v675
		v677.Material = v676 or Enum.Material.SmoothPlastic
		v677.Transparency = 0.45
		local v678 = workspace:FindFirstChild("FX")
		if v678 then
			v_u_17 = v678
		end
		v677.Parent = v_u_17
		v677.Shape = Enum.PartType.Cylinder
		v_u_5:Create(v677, TweenInfo.new(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Size"] = Vector3.new(0.06, 34, 34),
			["Transparency"] = 1
		}):Play()
		v_u_1:AddItem(v677, 0.8)
	end
end
local v_u_679 = {}
local v_u_680 = nil
local function v_u_687(p681, p682, p683) -- name: endRing
	-- upvalues: (copy) v_u_679, (copy) v_u_10, (copy) v_u_321, (copy) v_u_1
	local v684 = v_u_679[p681]
	if v684 then
		v_u_679[p681] = nil
		if p682 then
			if v684.mine and not v_u_10.InFirstPerson() then
				v_u_10.Sound("Knife_Ready", p683 or v684.pos)
			end
			v684.model:Destroy()
		else
			if p683 then
				local v685 = v684.model
				local v686 = CFrame.new(p683)
				if v685:IsA("Model") then
					v685:PivotTo(v686)
				elseif v685:IsA("BasePart") then
					v685.CFrame = v686
				end
				v_u_10.Sound("Knife_Thunk", p683)
			end
			v_u_321(v684.model, 0.3, 1.2)
			v_u_1:AddItem(v684.model, 2)
		end
	else
		return
	end
end
local function v_u_733(p688) -- name: stepRings
	-- upvalues: (copy) v_u_679, (copy) v_u_10, (copy) v_u_321, (copy) v_u_1, (ref) v_u_313, (ref) v_u_680
	local v689 = os.clock()
	for v690, v691 in v_u_679 do
		if v691.model.Parent and v689 - v691.born <= 9 then
			local v692 = v691.speed * p688
			if not v691.back then
				v691.pos = v691.pos + v691.dir * v692
				v691.traveled = v691.traveled + v692
				if v691.traveled >= v691.range then
					v691.back = true
				end
				goto l31
			end
			local v693 = v691.shooter
			if v693 then
				v693 = v691.shooter:FindFirstChild("HumanoidRootPart")
			end
			if v693 and v693:IsA("BasePart") then
				local v694 = v693.Position + Vector3.new(0, 0.6, 0) - v691.pos
				if v694.Magnitude <= v691.catch + v692 then
					local v695 = v693.Position
					local v696 = v_u_679[v690]
					if not v696 then
						continue
					end
					v_u_679[v690] = nil
					if v696.mine and not v_u_10.InFirstPerson() then
						v_u_10.Sound("Knife_Ready", v695 or v696.pos)
					end
					v696.model:Destroy()
				else
					v691.pos = v691.pos + v694.Unit * v692
					::l31::
					local v697 = v691.pos
					local v698 = v691.view
					if v698 then
						local v699 = workspace.CurrentCamera
						if v689 < v698.at then
							v697 = v691.pos - Vector3.new(0, 10000, 0)
						else
							if v698.t0 == 0 then
								v698.t0 = v689
								v691.spinT0 = v689
								local v700 = v_u_313
								if v700 then
									v700 = v_u_313()
								end
								if v700 and v699 then
									local v701 = v699.CFrame
									v698.p0 = v701:PointToObjectSpace(v701.Position + (v700 - v701.Position) * 4)
								end
							end
							local v702 = (v689 - v698.t0) / 0.12
							local v703 = math.clamp(v702, 0, 1)
							local v704 = 1 - (1 - v703) * (1 - v703)
							local v705 = v698.p0
							if v705 and v699 then
								local v706 = v699.CFrame
								local v707 = v706:PointToObjectSpace(v691.pos)
								if v707.Z < -0.05 and v705.Z < -0.05 then
									local v708 = -v705.Z
									local v709 = -v707.Z
									local v710 = v708 + (v709 - v708) * v704
									local v711 = v705.X / v708 + (v707.X / v709 - v705.X / v708) * v704
									local v712 = v705.Y / v708 + (v707.Y / v709 - v705.Y / v708) * v704
									local v713 = v711 * v710
									local v714 = v712 * v710
									local v715 = -v710
									v697 = v706:PointToWorldSpace((Vector3.new(v713, v714, v715)))
								end
							end
							if v703 >= 1 then
								v691.view = nil
							end
						end
					end
					local v716 = v691.spinA or 0
					local v717 = p688 * 30
					v691.spinA = (v716 + math.min(v717, 0.3490658503988659)) % 6.283185307179586
					local v718 = CFrame.Angles(0, v691.spinA, 0)
					local v719 = v691.view
					local v720
					if v719 and v719.t0 > 0 then
						local v721 = (v689 - v719.t0) / 0.12
						v720 = (1 - math.clamp(v721, 0, 1)) * 1.3089969389957472
					else
						v720 = 0
					end
					local v722 = v691.dir.X
					local v723 = v691.dir.Z
					local v724 = Vector3.new(v722, 0, v723)
					if v720 > 0 and v724.Magnitude > 0.001 then
						local v725 = v691.model
						local v726 = CFrame.lookAt(v697, v697 + v724) * CFrame.Angles(v720, 0, 0) * v718
						if v725:IsA("Model") then
							v725:PivotTo(v726)
						else
							if not v725:IsA("BasePart") then
								continue
							end
							v725.CFrame = v726
						end
					else
						local v727 = v691.model
						local v728 = CFrame.new(v697) * v718
						if v727:IsA("Model") then
							v727:PivotTo(v728)
						else
							if not v727:IsA("BasePart") then
								continue
							end
							v727.CFrame = v728
						end
					end
				end
			else
				local v729 = v691.pos
				local v730 = v_u_679[v690]
				if not v730 then
					continue
				end
				v_u_679[v690] = nil
				if v729 then
					local v731 = v730.model
					local v732 = CFrame.new(v729)
					if v731:IsA("Model") then
						v731:PivotTo(v732)
					elseif v731:IsA("BasePart") then
						v731.CFrame = v732
					end
					v_u_10.Sound("Knife_Thunk", v729)
				end
				v_u_321(v730.model, 0.3, 1.2)
				v_u_1:AddItem(v730.model, 2)
			end
		else
			v_u_679[v690] = nil
			if not v691.model.Parent then
				continue
			end
			v691.model:Destroy()
		end
	end
	if next(v_u_679) == nil and v_u_680 then
		v_u_680:Disconnect()
		v_u_680 = nil
	end
end
function v_u_14.Chakram(p734, p735, p736, p737, p738, p739, p740) -- name: Chakram
	-- upvalues: (copy) v_u_15, (copy) v_u_14, (copy) v_u_21, (copy) v_u_25, (ref) v_u_17, (copy) v_u_679, (ref) v_u_313, (copy) v_u_10, (ref) v_u_314, (ref) v_u_680, (copy) v_u_4, (copy) v_u_733
	local v741
	if p740 == nil then
		v741 = false
	else
		v741 = p740 == v_u_15.Character
	end
	if not v741 then
		local v742 = workspace.CurrentCamera
		if (not v742 and 0 or (v742.CFrame.Position - p735).Magnitude) > v_u_14.NEAR * 2 then
			return
		end
	end
	local v743 = v_u_21("Projectiles/Chakram")
	local v744
	if v743 then
		v744 = v743:Clone()
	else
		v744 = Instance.new("Part")
		v744.Size = Vector3.new(0.2, 0.2, 2)
		v744.Material = Enum.Material.SmoothPlastic
		v744.Color = Color3.fromRGB(90, 85, 80)
		v_u_25(v744)
	end
	v_u_25(v744)
	local v745 = CFrame.new(p735)
	if v744:IsA("Model") then
		v744:PivotTo(v745)
	elseif v744:IsA("BasePart") then
		v744.CFrame = v745
	end
	local v746 = workspace:FindFirstChild("FX")
	if v746 then
		v_u_17 = v746
	end
	v744.Parent = v_u_17
	local v747 = v_u_679[p734]
	if v747 then
		v747.model:Destroy()
	end
	local v748 = v_u_679
	local v749 = {
		["model"] = nil,
		["shooter"] = nil,
		["pos"] = nil,
		["dir"] = nil,
		["speed"] = nil,
		["range"] = nil,
		["catch"] = nil,
		["traveled"] = 0,
		["back"] = false,
		["born"] = nil,
		["mine"] = nil,
		["view"] = nil,
		["model"] = v744,
		["shooter"] = p740,
		["pos"] = p735,
		["dir"] = p736.Unit,
		["speed"] = p737,
		["range"] = p738,
		["catch"] = p739,
		["born"] = os.clock(),
		["mine"] = v741
	}
	local v750
	if v741 and (v_u_313 and v_u_10.InFirstPerson()) then
		v750 = {
			["at"] = nil,
			["t0"] = 0
		}
		local v751 = os.clock()
		local v752 = not v_u_314 and 0 or v_u_314()
		v750.at = v751 + math.clamp(v752, 0, 0.3)
	else
		v750 = nil
	end
	v749.view = v750
	v748[p734] = v749
	if not v_u_680 then
		v_u_680 = v_u_4.Heartbeat:Connect(v_u_733)
	end
end
function v_u_14.ChakramTurn(p753, p754) -- name: ChakramTurn
	-- upvalues: (copy) v_u_679
	local v755 = v_u_679[p753]
	if v755 then
		v755.back = true
		if (v755.pos - p754).Magnitude > 3 then
			v755.pos = p754
		end
	end
end
function v_u_14.ChakramEnd(p756, p757, p758) -- name: ChakramEnd
	-- upvalues: (copy) v_u_687
	v_u_687(p756, p757, p758)
end
function v_u_14.FirePatch(p759, p760, p761) -- name: FirePatch
	-- upvalues: (copy) v_u_14, (copy) v_u_12, (ref) v_u_17, (copy) v_u_1, (copy) v_u_10
	local v762 = workspace.CurrentCamera
	if (not v762 and 0 or (v762.CFrame.Position - p759).Magnitude) <= v_u_14.NEAR * 1.5 then
		local v763 = v_u_12.layers and 3 or 2
		for v764 = 1, v763 do
			local v765 = v764 / v763 * 3.141592653589793 * 2 + math.random()
			local v766 = v764 == 1 and 0 or p760 * (0.3 + 0.4 * math.random())
			local v767 = math.cos(v765) * v766
			local v768 = math.sin(v765) * v766
			local v769 = p759 + Vector3.new(v767, 0.3, v768)
			local v770 = CFrame.new(v769)
			local v771 = Color3.new()
			local v772 = Enum.Material.SmoothPlastic
			local v773 = Instance.new("Part")
			v773.Name = "PuffFX"
			v773.Anchored = true
			v773.CanCollide = false
			v773.CanQuery = false
			v773.CanTouch = false
			v773.CastShadow = false
			v773.Size = Vector3.new(1.2, 0.4, 1.2)
			v773.CFrame = v770
			v773.Color = v771
			v773.Material = v772 or Enum.Material.SmoothPlastic
			v773.Transparency = 1
			local v774 = workspace:FindFirstChild("FX")
			if v774 then
				v_u_17 = v774
			end
			v773.Parent = v_u_17
			local v_u_775 = Instance.new("ParticleEmitter")
			v_u_775.Texture = "rbxasset://textures/particles/fire_main.dds"
			v_u_775.Color = ColorSequence.new(Color3.fromRGB(255, 190, 80), Color3.fromRGB(235, 90, 30))
			v_u_775.LightEmission = 0.35
			v_u_775.LightInfluence = 0.3
			v_u_775.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1.2), NumberSequenceKeypoint.new(0.4, 2.2), NumberSequenceKeypoint.new(1, 0) })
			v_u_775.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(1, 1) })
			v_u_775.Lifetime = NumberRange.new(0.5, 0.8)
			v_u_775.Speed = NumberRange.new(2, 4)
			v_u_775.SpreadAngle = Vector2.new(10, 10)
			v_u_775.EmissionDirection = Enum.NormalId.Top
			v_u_775.Rotation = NumberRange.new(-20, 20)
			v_u_775.Rate = 12 * v_u_12.particleScale
			v_u_775.Shape = Enum.ParticleEmitterShape.Box
			v_u_775.Parent = v773
			task.delay(p761, function()
				-- upvalues: (copy) v_u_775
				v_u_775.Enabled = false
			end)
			v_u_1:AddItem(v773, p761 + 1)
		end
		v_u_10.Sound("FireBomb_Fuse", p759)
	end
end
function v_u_14.Wall(p776, p777, _, p778) -- name: Wall
	-- upvalues: (copy) v_u_14, (copy) v_u_10
	local v779 = workspace.CurrentCamera
	if (not v779 and 0 or (v779.CFrame.Position - p776).Magnitude) > v_u_14.NEAR * 1.5 then
		return
	else
		local v780 = Color3.fromRGB(150, 108, 68)
		if p777 == "Hit" then
			v_u_10.Sound("Impact_Wood", p776)
			v_u_14.Puff(p776, v780, 5, 0.5, 6, 0.4)
			return
		else
			local v781 = p778 / 2 - 0.3
			local v782 = p776 - Vector3.new(0, v781, 0)
			if p777 == "Place" then
				v_u_10.Sound("Impact_Wood", p776)
				v_u_10.Sound("Trap_Set", p776)
				v_u_14.Puff(v782, Color3.fromRGB(170, 150, 120), 12, 1.1, 7, 0.6)
			else
				v_u_10.Sound("Impact_Wood", p776)
				if p777 == "Break" then
					v_u_10.Sound("Hit_Melee_Heavy", p776)
				end
				v_u_14.Puff(v782, Color3.fromRGB(170, 150, 120), 10, 1.2, 6, 0.7)
				v_u_14.Puff(p776, v780, p777 == "Break" and 16 or 8, 0.6, 11, 0.7)
			end
		end
	end
end
function v_u_14.HealPool(p783, p784, p_u_785) -- name: HealPool
	-- upvalues: (copy) v_u_14, (copy) v_u_10, (ref) v_u_17, (copy) v_u_5, (copy) v_u_1, (copy) v_u_12
	local v786 = workspace.CurrentCamera
	local v787 = (not v786 and 0 or (v786.CFrame.Position - p783).Magnitude) > v_u_14.NEAR
	local v788 = v_u_10.WorldParams(v_u_10.Targets())
	local v789 = workspace
	local v790 = p783 + Vector3.new(0, 1.5, 0)
	local v791 = -(p784 + 1.5)
	local v792 = v789:Raycast(v790, Vector3.new(0, v791, 0), v788)
	local v793, v794
	if v792 then
		v793 = v792.Position
		v794 = v792.Normal
	else
		v793 = nil
		v794 = nil
	end
	local v795 = v793 or p783
	v_u_10.Sound("FireBomb_Shatter", v795)
	v_u_14.Burst("Heal_Health", CFrame.new(v795 + Vector3.new(0, 1, 0)), 1.6)
	local v796 = v794 or Vector3.new(0, 1, 0)
	local v_u_797 = CFrame.lookAt(v795 + v796 * 0.12, v795 + v796 * 1.12) * CFrame.Angles(0, 1.5707963267948966, 0)
	local function v813(p798, p799, p800, p801, p802) -- name: disc
		-- upvalues: (copy) v_u_797, (ref) v_u_17, (ref) v_u_5, (copy) p_u_785, (ref) v_u_1
		local v803 = Vector3.new(0.08, p799, p799)
		local v804 = v_u_797 * CFrame.new(p802, 0, 0)
		local v805 = Enum.Material.SmoothPlastic
		local v806 = Instance.new("Part")
		v806.Name = p798
		v806.Anchored = true
		v806.CanCollide = false
		v806.CanQuery = false
		v806.CanTouch = false
		v806.CastShadow = false
		v806.Size = v803
		v806.CFrame = v804
		v806.Color = p800
		v806.Material = v805 or Enum.Material.SmoothPlastic
		v806.Transparency = p801 or 0
		local v807 = workspace:FindFirstChild("FX")
		if v807 then
			v_u_17 = v807
		end
		v806.Parent = v_u_17
		v806.Shape = Enum.PartType.Cylinder
		local v808 = v_u_5
		local v809 = TweenInfo.new
		local v810 = Enum.EasingStyle.Quad
		local v811 = Enum.EasingDirection.In
		local v812 = p_u_785 - 0.3
		v808:Create(v806, v809(0.5, v810, v811, 0, false, (math.max(0, v812))), {
			["Transparency"] = 1
		}):Play()
		v_u_1:AddItem(v806, p_u_785 + 0.4)
		return v806
	end
	v813("HealPoolRim", p784 * 2, Color3.fromRGB(58, 132, 70), 0.55, 0)
	v813("HealPool", p784 * 2 - 0.9, Color3.fromRGB(96, 178, 96), 0.72, 0.02)
	if not v787 then
		local v814 = v795 + Vector3.new(0, 0.6, 0)
		local v815 = p784 * 1.5
		local v816 = p784 * 1.5
		local v817 = Vector3.new(v815, 0.4, v816)
		local v818 = CFrame.new(v814)
		local v819 = Color3.new()
		local v820 = Enum.Material.SmoothPlastic
		local v821 = Instance.new("Part")
		v821.Name = "PuffFX"
		v821.Anchored = true
		v821.CanCollide = false
		v821.CanQuery = false
		v821.CanTouch = false
		v821.CastShadow = false
		v821.Size = v817
		v821.CFrame = v818
		v821.Color = v819
		v821.Material = v820 or Enum.Material.SmoothPlastic
		v821.Transparency = 1
		local v822 = workspace:FindFirstChild("FX")
		if v822 then
			v_u_17 = v822
		end
		v821.Parent = v_u_17
		local v_u_823 = Instance.new("ParticleEmitter")
		v_u_823.Texture = "rbxasset://textures/particles/sparkles_main.dds"
		v_u_823.Color = ColorSequence.new(Color3.fromRGB(120, 220, 110))
		v_u_823.LightEmission = 0.3
		v_u_823.LightInfluence = 0.5
		v_u_823.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.34), NumberSequenceKeypoint.new(1, 0) })
		v_u_823.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(1, 1) })
		v_u_823.Lifetime = NumberRange.new(0.8, 1.3)
		v_u_823.Speed = NumberRange.new(2, 4)
		v_u_823.SpreadAngle = Vector2.new(12, 12)
		v_u_823.EmissionDirection = Enum.NormalId.Top
		v_u_823.Shape = Enum.ParticleEmitterShape.Box
		v_u_823.Rate = 34 * v_u_12.particleScale
		v_u_823.Parent = v821
		task.delay(p_u_785, function()
			-- upvalues: (copy) v_u_823
			v_u_823.Enabled = false
		end)
		v_u_1:AddItem(v821, p_u_785 + 1.5)
	end
end
local v_u_824 = {}
local v_u_825 = {}
local v_u_826 = nil
local v_u_827 = Color3.fromRGB(122, 104, 84)
local function v_u_844() -- name: caltropModel
	-- upvalues: (copy) v_u_21, (copy) v_u_25, (ref) v_u_17
	local v828 = v_u_21("Caltrop")
	if v828 then
		local v829 = v828:Clone()
		v_u_25(v829)
		return v829
	end
	local v830 = Instance.new("Model")
	local v831 = CFrame.new(0, 0.12, 0)
	local v832 = Color3.fromRGB(70, 68, 66)
	local v833 = Enum.Material.Metal
	local v834 = Instance.new("Part")
	v834.Name = "Root"
	v834.Anchored = true
	v834.CanCollide = false
	v834.CanQuery = false
	v834.CanTouch = false
	v834.CastShadow = false
	v834.Size = Vector3.new(0.2, 0.2, 0.2)
	v834.CFrame = v831
	v834.Color = v832
	v834.Material = v833 or Enum.Material.SmoothPlastic
	v834.Transparency = 0
	local v835 = workspace:FindFirstChild("FX")
	if v835 then
		v_u_17 = v835
	end
	v834.Parent = v_u_17
	v834.Parent = v830
	v830.PrimaryPart = v834
	for v836, v837 in {
		Vector3.new(0, 1, 0),
		Vector3.new(0.94, -0.33, 0),
		Vector3.new(-0.47, -0.33, 0.82),
		Vector3.new(-0.47, -0.33, -0.82)
	} do
		local v838 = "Point" .. v836
		local v839 = CFrame.lookAt(v834.Position + v837 * 0.18, v834.Position + v837)
		local v840 = Color3.fromRGB(86, 84, 82)
		local v841 = Enum.Material.Metal
		local v842 = Instance.new("Part")
		v842.Name = v838
		v842.Anchored = true
		v842.CanCollide = false
		v842.CanQuery = false
		v842.CanTouch = false
		v842.CastShadow = false
		v842.Size = Vector3.new(0.07, 0.07, 0.42)
		v842.CFrame = v839
		v842.Color = v840
		v842.Material = v841 or Enum.Material.SmoothPlastic
		v842.Transparency = 0
		local v843 = workspace:FindFirstChild("FX")
		if v843 then
			v_u_17 = v843
		end
		v842.Parent = v_u_17
		v842.Parent = v830
	end
	return v830
end
local function v_u_856() -- name: stepCaltrops
	-- upvalues: (copy) v_u_825, (ref) v_u_826
	local v845 = os.clock()
	for v846 = #v_u_825, 1, -1 do
		local v847 = v_u_825[v846]
		if v847.model.Parent then
			local v848 = (v845 - v847.t0) / v847.dur
			local v849 = math.clamp(v848, 0, 1)
			local v850 = 1 - (1 - v849) * (1 - v849)
			local v851 = v847.from:Lerp(v847.to.Position, v850)
			local v852 = v847.hop * 4 * v849 * (1 - v849)
			local v853 = v851 + Vector3.new(0, v852, 0)
			local v854 = 1 - v850
			local v855 = CFrame.new(v853) * v847.to.Rotation * CFrame.Angles(v847.tumble.X * v854, v847.tumble.Y * v854, v847.tumble.Z * v854)
			v847.model:PivotTo(v855)
			if v849 < 1 then
				continue
			end
			table.remove(v_u_825, v846)
		else
			table.remove(v_u_825, v846)
		end
	end
	if #v_u_825 == 0 and v_u_826 then
		v_u_826:Disconnect()
		v_u_826 = nil
	end
end
local function v_u_862(p857, p858) -- name: caltropsGone
	-- upvalues: (copy) v_u_824, (copy) v_u_5, (copy) v_u_1
	local v859 = v_u_824[p857]
	if v859 then
		v_u_824[p857] = nil
		for _, v860 in v859.items do
			if not v860.Parent then
				continue
			end
			for _, v861 in v860:IsA("BasePart") and { v860 } or v860:GetDescendants() do
				if v861:IsA("BasePart") then
					v_u_5:Create(v861, TweenInfo.new(p858, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["Transparency"] = 1,
						["CFrame"] = nil,
						["CFrame"] = v861.CFrame - Vector3.new(0, 0.25, 0)
					}):Play()
				else
					if not v861:IsA("SurfaceGui") then
						continue
					end
					v861.Enabled = false
				end
			end
			v_u_1:AddItem(v860, p858 + 0.1)
		end
	end
end
function v_u_14.Caltrops(p863) -- name: Caltrops
	-- upvalues: (copy) v_u_14, (copy) v_u_824, (copy) v_u_862, (copy) v_u_10, (ref) v_u_17, (copy) v_u_5, (copy) v_u_827, (copy) v_u_12, (copy) v_u_844, (copy) v_u_825, (ref) v_u_826, (copy) v_u_4, (copy) v_u_856
	local v864 = p863.id
	local v_u_865 = tonumber(v864)
	local v866 = p863.position
	if v_u_865 and typeof(v866) == "Vector3" then
		local v867 = p863.radius
		local v868 = tonumber(v867) or 3.5
		local v869 = p863.duration
		local v870 = tonumber(v869) or 15
		local v871 = p863.from
		local v872
		if typeof(v871) == "Vector3" then
			v872 = p863.from
		else
			v872 = v866
		end
		local v873 = Random.new
		local v874 = p863.seed
		local v875 = v873(tonumber(v874) or v_u_865)
		local v876 = workspace.CurrentCamera
		local v877 = (not v876 and 0 or (v876.CFrame.Position - v866).Magnitude) > v_u_14.NEAR
		if v_u_824[v_u_865] then
			v_u_862(v_u_865, 0)
		end
		local v_u_878 = {}
		v_u_824[v_u_865] = {
			["items"] = v_u_878,
			["token"] = v_u_865
		}
		local v879 = p863.attacker
		local v880
		if typeof(v879) == "Instance" then
			v880 = v_u_10.IsEnemy(v879)
		else
			v880 = false
		end
		local v881
		if v880 then
			v881 = Color3.fromRGB(196, 70, 64)
		else
			v881 = Color3.fromRGB(70, 132, 196)
		end
		local v882 = v866 + Vector3.new(0, 0.5, 0)
		local v883 = v_u_10.WorldParams(v_u_10.Targets())
		local v884 = workspace:Raycast(v882 + Vector3.new(0, 1.5, 0), Vector3.new(0, -4.5, 0), v883)
		local v885, v886
		if v884 then
			v885 = v884.Position
			v886 = v884.Normal
		else
			v885 = nil
			v886 = nil
		end
		local v_u_887 = v885 or v866
		local v_u_888 = v886 or Vector3.new(0, 1, 0)
		local v_u_889 = CFrame.lookAt(v_u_887 + v_u_888 * 0.06, v_u_887 + v_u_888 * 1.06) * CFrame.Angles(0, 1.5707963267948966, 0)
		local function v901(p890, p891, p892, p893, p894) -- name: disc
			-- upvalues: (copy) v_u_889, (ref) v_u_17, (ref) v_u_5, (copy) v_u_878
			local v895 = Vector3.new(0.05, p891, p891)
			local v896 = v_u_889 * CFrame.new(p894, 0, 0)
			local v897 = Enum.Material.SmoothPlastic
			local v898 = Instance.new("Part")
			v898.Name = p890
			v898.Anchored = true
			v898.CanCollide = false
			v898.CanQuery = false
			v898.CanTouch = false
			v898.CastShadow = false
			v898.Size = v895
			v898.CFrame = v896
			v898.Color = p892
			v898.Material = v897 or Enum.Material.SmoothPlastic
			v898.Transparency = 1
			local v899 = workspace:FindFirstChild("FX")
			if v899 then
				v_u_17 = v899
			end
			v898.Parent = v_u_17
			v898.Shape = Enum.PartType.Cylinder
			v_u_5:Create(v898, TweenInfo.new(0.25), {
				["Transparency"] = p893
			}):Play()
			local v900 = v_u_878
			table.insert(v900, v898)
		end
		v901("CaltropsRing", v868 * 2, v881, 0.72, 0)
		v901("CaltropsDirt", v868 * 2 - 0.5, v_u_827, 0.82, 0.01)
		local v902 = v877 and 10 or (v_u_12.layers and 18 or 13)
		local v903 = os.clock()
		for v904 = 1, v902 do
			local v905 = v904 * 2.39996 + v875:NextNumber(-0.35, 0.35)
			local v906 = v868 * 0.92
			local v907 = (v904 - 0.4) / v902
			local v908 = v906 * math.sqrt(v907) * v875:NextNumber(0.88, 1.04)
			local v909 = math.cos(v905) * v908
			local v910 = math.sin(v905) * v908
			local v911 = v_u_887 + Vector3.new(v909, 0, v910)
			local v912 = v911 + Vector3.new(0, 1, 0)
			local v913 = v_u_10.WorldParams(v_u_10.Targets())
			local v914 = workspace:Raycast(v912 + Vector3.new(0, 1.5, 0), Vector3.new(0, -4.5, 0), v913)
			local v915, v916
			if v914 then
				v915 = v914.Position
				v916 = v914.Normal
			else
				v915 = nil
				v916 = nil
			end
			local v917 = v915 or v911
			local v918 = v916 or v_u_888
			local v919 = v875:NextNumber(0, 6.283185307179586)
			local v920 = math.cos(v919)
			local v921 = math.sin(v919)
			local v922 = Vector3.new(v920, 0, v921)
			local v923 = v922 - v918 * v922:Dot(v918)
			local v924 = v923.Magnitude < 0.05 and Vector3.new(1, 0, 0) or v923
			local v925 = CFrame.lookAt(v917, v917 + v924.Unit, v918)
			local v926 = CFrame.Angles
			local v927 = v875:NextNumber(-8, 8)
			local v928 = v925 * v926(0, 0, (math.rad(v927)))
			local v929 = v_u_844()
			local v930 = v875:NextNumber(0.9, 1.12)
			if v929:IsA("Model") and v930 ~= 1 then
				v929:ScaleTo(v930)
			end
			v929:PivotTo(CFrame.new(v872) * v928.Rotation)
			local v931 = workspace:FindFirstChild("FX")
			if v931 then
				v_u_17 = v931
			end
			v929.Parent = v_u_17
			table.insert(v_u_878, v929)
			if v877 then
				v929:PivotTo(v928)
			else
				local v932 = v_u_825
				local v933 = {
					["model"] = v929,
					["from"] = v872,
					["to"] = v928,
					["t0"] = v903 + v875:NextNumber(0, 0.03),
					["dur"] = 0.14 + 0.16 * (v908 / math.max(v868, 0.1)) + v875:NextNumber(0, 0.04),
					["hop"] = 0.5 + v875:NextNumber(0, 0.9)
				}
				local v934 = v875:NextNumber(-7, 7)
				local v935 = v875:NextNumber(-5, 5)
				v933.tumble = Vector3.new(v934, v935, v875:NextNumber(-7, 7))
				table.insert(v932, v933)
			end
		end
		if not v877 then
			if not v_u_826 then
				v_u_826 = v_u_4.Heartbeat:Connect(v_u_856)
			end
			v_u_10.Sound("Caltrops_Scatter", v872)
			v_u_14.Puff(v872, Color3.fromRGB(150, 132, 108), 7, 0.7, 7, 0.45)
			task.delay(0.22, function()
				-- upvalues: (ref) v_u_824, (copy) v_u_865, (copy) v_u_865, (ref) v_u_14, (copy) v_u_887, (copy) v_u_888
				if v_u_824[v_u_865] and v_u_824[v_u_865].token == v_u_865 then
					v_u_14.Puff(v_u_887 + v_u_888 * 0.3, Color3.fromRGB(150, 132, 108), 9, 1.1, 4, 0.55)
				end
			end)
		end
		task.delay(v870, function()
			-- upvalues: (ref) v_u_824, (copy) v_u_865, (copy) v_u_865, (ref) v_u_862
			local v936 = v_u_824[v_u_865]
			if v936 and v936.token == v_u_865 then
				v_u_862(v_u_865, 0.45)
			end
		end)
	end
end
function v_u_14.CaltropsEnd(p937) -- name: CaltropsEnd
	-- upvalues: (copy) v_u_862
	v_u_862(p937, 0.35)
end
function v_u_14.CaltropStep(p938) -- name: CaltropStep
	-- upvalues: (copy) v_u_10, (copy) v_u_14
	local v939 = v_u_10.Drawn(p938)
	if v939 then
		if not v939:IsA("Model") then
			v939 = p938
		end
	else
		v939 = p938
	end
	local v940 = v939:FindFirstChild("RightFoot") or (v939:FindFirstChild("LeftFoot") or v939:FindFirstChild("HumanoidRootPart"))
	if v940 and v940:IsA("BasePart") then
		v_u_10.Sound("Caltrops_Step", v940)
		local v941 = v940.Position
		local v942 = workspace.CurrentCamera
		if (not v942 and 0 or (v942.CFrame.Position - v941).Magnitude) <= v_u_14.NEAR then
			v_u_14.Burst("Block_Spark", CFrame.new(v940.Position - Vector3.new(0, 0.3, 0)), 0.45, Color3.fromRGB(196, 150, 110))
		end
	end
end
function v_u_14.Death(p943, p944, p945, p946) -- name: Death
	-- upvalues: (copy) v_u_14, (copy) v_u_10
	v_u_14.Burst("Death_Burst", CFrame.new(p943))
	v_u_10.Sound("Death_Poof", p943)
	v_u_14.KillFlourish(p943, p945, p944 == true, p946 == true)
	if p944 then
		v_u_10.Shake(0.5, 0.25)
	end
end
local function v_u_974(p_u_947, p_u_948, p949, p950, p_u_951, p_u_952) -- name: fling
	-- upvalues: (ref) v_u_17, (copy) v_u_4
	local v_u_953 = {}
	for v954, v955 in p_u_948 do
		local v956 = math.random() - 0.5
		local v957 = math.random() - 0.5
		local v958 = Vector3.new(v956, 0, v957)
		local v959 = (v958.Magnitude <= 0.01 and Vector3.new(1, 0, 0) or v958.Unit) * p949 * (0.6 + math.random() * 0.6)
		local v960 = p950 * (0.7 + math.random() * 0.6)
		v_u_953[v954] = v959 + Vector3.new(0, v960, 0)
		v955.CFrame = CFrame.new(p_u_947) * CFrame.Angles(math.random() * 6, math.random() * 6, math.random() * 6)
		local v961 = workspace:FindFirstChild("FX")
		if v961 then
			v_u_17 = v961
		end
		v955.Parent = v_u_17
	end
	local v_u_962 = os.clock()
	local v_u_963 = nil
	v_u_963 = v_u_4.RenderStepped:Connect(function()
		-- upvalues: (copy) v_u_962, (copy) p_u_951, (ref) v_u_963, (copy) p_u_948, (copy) p_u_947, (copy) v_u_953, (copy) p_u_952
		local v964 = os.clock() - v_u_962
		if p_u_951 <= v964 then
			v_u_963:Disconnect()
			for _, v965 in p_u_948 do
				v965:Destroy()
			end
		else
			local v966 = v964 / p_u_951
			for v967, v968 in p_u_948 do
				local v969 = p_u_947 + v_u_953[v967] * v964
				local v970 = -30 * v964 * v964
				local v971 = v969 + Vector3.new(0, v970, 0)
				local v972
				if p_u_952 then
					v972 = CFrame.Angles(v964 * 9 + v967, v964 * 7, 0)
				else
					v972 = v968.CFrame.Rotation
				end
				v968.CFrame = CFrame.new(v971) * v972
				local v973 = (v966 - 0.5) / 0.5
				v968.Transparency = math.clamp(v973, 0, 1)
			end
		end
	end)
end
local v_u_975 = {
	["Bow"] = "feathers",
	["Crossbow"] = "feathers",
	["Javelin"] = "feathers",
	["Knives"] = "feathers",
	["Musket"] = "powder",
	["Pistol"] = "powder",
	["Blunderbuss"] = "powder",
	["Axe"] = "stars",
	["Club"] = "stars",
	["Fists"] = "stars",
	["Gauntlets"] = "stars",
	["Hatchets"] = "stars",
	["Sword"] = "slash",
	["Dagger"] = "slash",
	["Spear"] = "slash",
	["Scythe"] = "slash",
	["Katana"] = "slash",
	["Sling"] = "chips",
	["Bomb"] = "embers",
	["Trap"] = "sparks"
}
function v_u_14.KillFlourish(p976, p977, p978, p979) -- name: KillFlourish
	-- upvalues: (copy) v_u_14, (copy) v_u_975, (copy) v_u_7, (ref) v_u_17, (copy) v_u_974, (copy) v_u_10, (copy) v_u_98, (copy) v_u_4, (copy) v_u_5, (copy) v_u_1
	local v980 = workspace.CurrentCamera
	if (not v980 and 0 or (v980.CFrame.Position - p976).Magnitude) <= v_u_14.NEAR then
		local v981 = v_u_975[v_u_7.Kind(p977) or ""] or "none"
		local v982 = p976 + Vector3.new(0, 1.5, 0)
		local v983 = p978 and 1.25 or 1
		if v981 == "feathers" then
			local v984 = {}
			for v985 = 1, 7 do
				local v986
				if v985 % 3 == 0 then
					v986 = Color3.fromRGB(220, 208, 186)
				else
					v986 = Color3.fromRGB(178, 58, 44)
				end
				local v987 = Vector3.new(0.06, 0.7, 0.22) * v983
				local v988 = CFrame.new(v982)
				local v989 = Enum.Material.SmoothPlastic
				local v990 = Instance.new("Part")
				v990.Name = "KillFeather"
				v990.Anchored = true
				v990.CanCollide = false
				v990.CanQuery = false
				v990.CanTouch = false
				v990.CastShadow = false
				v990.Size = v987
				v990.CFrame = v988
				v990.Color = v986
				v990.Material = v989 or Enum.Material.SmoothPlastic
				v990.Transparency = 0
				local v991 = workspace:FindFirstChild("FX")
				if v991 then
					v_u_17 = v991
				end
				v990.Parent = v_u_17
				table.insert(v984, v990)
			end
			v_u_974(v982, v984, 9, 10, 0.9, true)
			v_u_10.Sound("Arrow_Flesh", p976, {
				["Volume"] = 0.6,
				["PlaybackSpeed"] = 0.8
			})
		elseif v981 == "powder" then
			v_u_14.Puff(v982, Color3.fromRGB(70, 64, 60), 14, v983 * 1.6, 14, 1.1)
			v_u_14.Burst("Impact_Sparks", CFrame.new(v982), v983 * 1.3, Color3.fromRGB(255, 150, 60), true)
			v_u_98(p976 - Vector3.new(0, 2.8, 0), Vector3.new(0, 1, 0), "rbxassetid://10871117278", Color3.fromRGB(60, 50, 44), 2, v983 * 9, 0.3, 0.3)
		elseif v981 == "stars" then
			local v_u_992 = {}
			for _ = 1, 4 do
				local v993 = Vector3.new(0.5, 0.5, 0.12) * v983
				local v994 = CFrame.new(v982)
				local v995 = Color3.fromRGB(250, 205, 70)
				local v996 = Enum.Material.SmoothPlastic
				local v997 = Instance.new("Part")
				v997.Name = "BonkStar"
				v997.Anchored = true
				v997.CanCollide = false
				v997.CanQuery = false
				v997.CanTouch = false
				v997.CastShadow = false
				v997.Size = v993
				v997.CFrame = v994
				v997.Color = v995
				v997.Material = v996 or Enum.Material.SmoothPlastic
				v997.Transparency = 0
				local v998 = workspace:FindFirstChild("FX")
				if v998 then
					v_u_17 = v998
				end
				v997.Parent = v_u_17
				v997.Shape = Enum.PartType.Block
				table.insert(v_u_992, v997)
			end
			local v_u_999 = p976 + Vector3.new(0, 2.6, 0)
			local v_u_1000 = os.clock()
			local v_u_1001 = nil
			v_u_1001 = v_u_4.RenderStepped:Connect(function()
				-- upvalues: (copy) v_u_1000, (ref) v_u_1001, (copy) v_u_992, (copy) v_u_999
				local v1002 = os.clock() - v_u_1000
				if v1002 > 0.9 then
					v_u_1001:Disconnect()
					for _, v1003 in v_u_992 do
						v1003:Destroy()
					end
				else
					for v1004, v1005 in v_u_992 do
						local v1006 = v1002 * 9 + v1004 * 3.141592653589793 / 2
						local v1007 = CFrame.new
						local v1008 = v_u_999
						local v1009 = math.cos(v1006) * 1.3
						local v1010 = v1002 * 12 + v1004
						local v1011 = math.sin(v1010) * 0.15 + 0.2
						local v1012 = math.sin(v1006) * 1.3
						v1005.CFrame = v1007(v1008 + Vector3.new(v1009, v1011, v1012)) * CFrame.Angles(0, 0, v1006 * 2)
						local v1013 = (v1002 - 0.6) / 0.3
						v1005.Transparency = math.clamp(v1013, 0, 1)
					end
				end
			end)
			v_u_10.Sound("Hit_Punch", p976, {
				["PlaybackSpeed"] = 0.75
			})
		elseif v981 == "slash" then
			for v1014 = -1, 1, 2 do
				local v1015 = v983 * 4.5
				local v1016 = Vector3.new(0.25, v1015, 0.1)
				local v1017 = CFrame.lookAt(v982, workspace.CurrentCamera.CFrame.Position)
				local v1018 = CFrame.Angles
				local v1019 = v1014 * 40
				local v1020 = v1017 * v1018(0, 0, (math.rad(v1019)))
				local v1021 = Color3.fromRGB(215, 70, 50)
				local v1022 = Enum.Material.SmoothPlastic
				local v1023 = Instance.new("Part")
				v1023.Name = "KillSlash"
				v1023.Anchored = true
				v1023.CanCollide = false
				v1023.CanQuery = false
				v1023.CanTouch = false
				v1023.CastShadow = false
				v1023.Size = v1016
				v1023.CFrame = v1020
				v1023.Color = v1021
				v1023.Material = v1022 or Enum.Material.SmoothPlastic
				v1023.Transparency = 0
				local v1024 = workspace:FindFirstChild("FX")
				if v1024 then
					v_u_17 = v1024
				end
				v1023.Parent = v_u_17
				v1023.Transparency = 0.1
				local v1025 = v_u_5
				local v1026 = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
				local v1027 = {
					["Size"] = nil,
					["Transparency"] = 1
				}
				local v1028 = v983 * 6
				v1027.Size = Vector3.new(0.05, v1028, 0.1)
				v1025:Create(v1023, v1026, v1027):Play()
				v_u_1:AddItem(v1023, 0.4)
			end
		elseif v981 == "chips" then
			local v1029 = {}
			for _ = 1, 6 do
				local v1030 = Vector3.new(0.3, 0.3, 0.3) * v983
				local v1031 = CFrame.new(v982)
				local v1032 = Color3.fromRGB(128, 124, 118)
				local v1033 = Enum.Material.Slate
				local v1034 = Instance.new("Part")
				v1034.Name = "KillChip"
				v1034.Anchored = true
				v1034.CanCollide = false
				v1034.CanQuery = false
				v1034.CanTouch = false
				v1034.CastShadow = false
				v1034.Size = v1030
				v1034.CFrame = v1031
				v1034.Color = v1032
				v1034.Material = v1033 or Enum.Material.SmoothPlastic
				v1034.Transparency = 0
				local v1035 = workspace:FindFirstChild("FX")
				if v1035 then
					v_u_17 = v1035
				end
				v1034.Parent = v_u_17
				table.insert(v1029, v1034)
			end
			v_u_974(v982, v1029, 8, 9, 0.8, true)
		elseif v981 == "embers" then
			v_u_14.Burst("Impact_Sparks", CFrame.new(v982), v983 * 1.5, Color3.fromRGB(255, 140, 50), true)
		elseif v981 == "sparks" then
			v_u_14.Burst("Impact_Sparks", CFrame.new(p976), v983 * 1.2)
		end
		if p979 then
			v_u_14.CritStar(p976 + Vector3.new(0, 1.5, 0))
		end
	end
end
local v_u_1036 = nil
local v_u_1037 = nil
local v_u_1038 = nil
local v_u_1039 = nil
local function v_u_1057(p1040, p1041, p1042, p1043) -- name: beamProjectile
	local v1044 = p1040 * 0.5 * p1043 * p1043 + p1041 * p1043 + p1042
	local v1045 = v1044 - (p1040 * p1043 * p1043 + p1041 * p1043) / 3
	local v1046 = (p1040 * 0.125 * p1043 * p1043 + p1041 * 0.5 * p1043 + p1042 - (p1042 + v1044) * 0.125) / 0.375 - v1045
	local v1047 = (v1046 - p1042).Magnitude
	local v1048 = (v1045 - v1044).Magnitude
	local v1049 = (p1042 - v1044).Unit
	local v1050 = (v1046 - p1042).Unit
	local v1051 = v1050:Cross(v1049).Unit
	local v1052 = (v1045 - v1044).Unit
	local v1053 = v1052:Cross(v1049).Unit
	local v1054 = v1051:Cross(v1050).Unit
	local v1055 = CFrame.fromMatrix(p1042, v1050, v1051, v1054)
	local v1056 = CFrame.fromMatrix(v1044, v1052, v1053, v1054)
	return v1047, -v1048, v1055, v1056
end
function v_u_14.Trajectory(p1058, p1059, p1060, p1061, p1062) -- name: Trajectory
	-- upvalues: (ref) v_u_1036, (ref) v_u_1037, (ref) v_u_17, (ref) v_u_1038, (ref) v_u_1039, (copy) v_u_9, (copy) v_u_10, (copy) v_u_1057
	if p1058 and (p1059 and p1060) then
		if not v_u_1036 then
			local v1063 = Instance.new("Attachment")
			v1063.Name = "CombatTrajA"
			v1063.Parent = workspace.Terrain
			local v1064 = Instance.new("Attachment")
			v1064.Name = "CombatTrajB"
			v1064.Parent = workspace.Terrain
			local v1065 = Instance.new("Beam")
			v1065.Attachment0 = v1063
			v1065.Attachment1 = v1064
			v1065.Width0 = 0.2
			v1065.Width1 = 0.2
			v1065.Segments = 48
			v1065.FaceCamera = true
			v1065.LightEmission = 0.2
			v1065.LightInfluence = 0.4
			v1065.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.9), NumberSequenceKeypoint.new(0.15, 0.3), NumberSequenceKeypoint.new(1, 0.2) })
			v1065.Parent = workspace.Terrain
			local v1066 = Instance.new("Part")
			v1066.Name = "CombatTrajLanding"
			v1066.Shape = Enum.PartType.Cylinder
			v1066.Size = Vector3.new(0.12, 3, 3)
			v1066.Material = Enum.Material.SmoothPlastic
			v1066.Transparency = 0.5
			v1066.Anchored = true
			v1066.CanCollide = false
			v1066.CanQuery = false
			v1066.CanTouch = false
			v1066.CastShadow = false
			local v1067 = workspace:FindFirstChild("FX")
			if v1067 then
				v_u_17 = v1067
			end
			v1066.Parent = v_u_17
			v_u_1037 = v1066
			v_u_1036 = v1065
			v_u_1038 = v1063
			v_u_1039 = v1064
		end
		local v1068 = v_u_9.new(p1058, p1059, p1060, 0)
		local v1069 = v_u_10.WorldParams(v_u_10.Teammates())
		local v1070 = 0
		local v1071 = 3
		local v1072 = nil
		for _ = 1, 90 do
			local v1073, v1074 = v_u_9.Advance(v1068, 0.03333333333333333)
			v1070 = v1070 + 0.03333333333333333
			local v1075 = workspace:Raycast(v1073, v1074, v1069)
			if not v1075 then
				continue
			end
			local v1076 = (v1075.Position - v1073).Magnitude
			local v1077 = v1074.Magnitude
			v1071 = v1070 - 0.03333333333333333 * (1 - v1076 / math.max(0.001, v1077))
			v1072 = v1075.Position
		end
		local v1078 = -p1060
		local v1079 = Vector3.new(0, v1078, 0)
		local v1080 = v_u_1057
		local v1081 = math.max(0.05, v1071)
		local v1082, v1083, v1084, v1085, v1086 = pcall(v1080, v1079, p1059, p1058, v1081)
		local v1087 = v_u_1036
		if v1082 then
			local v1088 = v_u_1039
			v_u_1038.WorldCFrame = v1085
			v1088.WorldCFrame = v1086
			v1087.CurveSize0 = v1083
			v1087.CurveSize1 = v1084
			v1087.Color = ColorSequence.new(p1061 or Color3.fromRGB(255, 190, 90))
			v1087.Enabled = true
			local v1089 = v_u_1037
			if v1089 then
				if not v1089.Parent then
					local v1090 = workspace:FindFirstChild("FX")
					if v1090 then
						v_u_17 = v1090
					end
					v1089.Parent = v_u_17
				end
				if v1072 then
					local v1091 = p1062 or 3
					v1089.Size = Vector3.new(0.12, v1091, v1091)
					v1089.Color = p1061 or Color3.fromRGB(255, 190, 90)
					v1089.Transparency = 0.5
					v1089.CFrame = CFrame.new(v1072 + Vector3.new(0, 0.08, 0)) * CFrame.Angles(0, 0, 1.5707963267948966)
					return
				end
				v1089.Transparency = 1
			end
		else
			v1087.Enabled = false
		end
	else
		if v_u_1036 then
			v_u_1036.Enabled = false
		end
		if v_u_1037 then
			v_u_1037.Transparency = 1
		end
		return
	end
end
return v_u_14