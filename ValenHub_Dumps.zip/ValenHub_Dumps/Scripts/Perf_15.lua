local v1 = game:GetService("Players")
local v2 = {}
local v_u_3 = game:GetService("RunService"):IsStudio()
local v_u_4 = {}
local v_u_5 = {}
local v_u_6 = os.clock()
function v2.Begin() -- name: Begin
	-- upvalues: (copy) v_u_3
	return not v_u_3 and 0 or os.clock()
end
function v2.End(p7, p8) -- name: End
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5
	if v_u_3 then
		local v9 = os.clock() - p8
		v_u_4[p7] = (v_u_4[p7] or 0) + v9
		if (v_u_5[p7] or 0) < v9 then
			v_u_5[p7] = v9
		end
	end
end
if v_u_3 and v1.LocalPlayer then
	local v10 = Instance.new("BindableFunction")
	v10.Name = "CharacterPerf"
	function v10.OnInvoke()
		-- upvalues: (ref) v_u_6, (copy) v_u_4, (copy) v_u_5
		local v11 = os.clock() - v_u_6
		local v12 = math.max(0.001, v11)
		local v13 = {}
		for v14, v15 in v_u_4 do
			v13[v14] = string.format("%.3f ms/s (max %.3f ms)", v15 * 1000 / v12, (v_u_5[v14] or 0) * 1000)
		end
		table.clear(v_u_4)
		table.clear(v_u_5)
		v_u_6 = os.clock()
		return v13
	end
	v10.Parent = v1.LocalPlayer
end
return v2