local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("TeleportService")
local v3 = {}
local function v_u_12(p4, p5) -- name: teleportGui
	local v6 = Instance.new("ScreenGui")
	v6.Name = "TR_Teleport"
	v6.IgnoreGuiInset = true
	v6.DisplayOrder = 100
	local v7 = Instance.new("Frame")
	v7.Size = UDim2.fromScale(1, 1)
	v7.BackgroundColor3 = Color3.fromRGB(10, 11, 15)
	v7.BorderSizePixel = 0
	v7.Parent = v6
	local v8 = Instance.new("TextLabel")
	v8.AnchorPoint = Vector2.new(0.5, 0.5)
	v8.Position = UDim2.fromScale(0.5, 0.46)
	v8.Size = UDim2.fromScale(0.8, 0.09)
	v8.BackgroundTransparency = 1
	v8.Text = p4
	v8.TextScaled = true
	v8.FontFace = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Heavy)
	v8.TextColor3 = Color3.new(1, 1, 1)
	v8.Parent = v7
	local v9 = Instance.new("TextLabel")
	v9.AnchorPoint = Vector2.new(0.5, 0)
	v9.Position = UDim2.fromScale(0.5, 0.53)
	v9.Size = UDim2.fromScale(0.8, 0.035)
	v9.BackgroundTransparency = 1
	v9.Text = p5
	v9.TextScaled = true
	v9.FontFace = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.SemiBold)
	v9.TextColor3 = Color3.fromRGB(186, 192, 206)
	v9.Parent = v7
	local v10 = Instance.new("Frame")
	v10.AnchorPoint = Vector2.new(0.5, 0)
	v10.Position = UDim2.fromScale(0.5, 0.6)
	v10.Size = UDim2.new(0.12, 0, 0, 4)
	v10.BackgroundColor3 = Color3.fromRGB(40, 150, 255)
	v10.BorderSizePixel = 0
	local v11 = Instance.new("UICorner")
	v11.CornerRadius = UDim.new(1, 0)
	v11.Parent = v10
	v10.Parent = v7
	return v6
end
function v3.Init(p_u_13) -- name: Init
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_12
	local v_u_14 = p_u_13.UI
	local v15 = p_u_13.Theme
	local v_u_16 = p_u_13.State
	local v17 = v15.Colors
	local v18 = v15.Fonts
	local v_u_19 = v_u_1.LocalPlayer
	local v_u_20 = v_u_14.new("Frame", {
		["Name"] = "Joining",
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 12),
		["Size"] = UDim2.fromOffset(340, 62),
		["BackgroundColor3"] = v17.Panel,
		["BackgroundTransparency"] = 0.08,
		["Visible"] = false,
		["Active"] = false,
		v_u_14.Corner(v15.Radius.Pill),
		v_u_14.Stroke(v17.Stroke, 1, 0.85),
		["Parent"] = p_u_13.Canvas.Top
	})
	local v_u_21 = v_u_14.new("TextLabel", {
		["Name"] = "Title",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "JOINING MATCH",
		["FontFace"] = nil,
		["TextSize"] = 22,
		["TextColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 9),
		["Size"] = UDim2.new(1, -40, 0, 24),
		["FontFace"] = v18.Display,
		["TextColor3"] = v17.Text,
		["Parent"] = v_u_20
	})
	local v_u_22 = v_u_14.new("TextLabel", {
		["Name"] = "Sub",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 33),
		["Size"] = UDim2.new(1, -40, 0, 16),
		["FontFace"] = v18.SemiBold,
		["TextColor3"] = v17.TextDim,
		["Parent"] = v_u_20
	})
	local v23 = v_u_14.new("Frame", {
		["Name"] = "Scan",
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -6),
		["Size"] = UDim2.new(1, -64, 0, 3),
		["BackgroundColor3"] = v17.Raised,
		["ClipsDescendants"] = true,
		v_u_14.Corner(v15.Radius.Pill),
		["Parent"] = v_u_20
	})
	local v_u_24 = v_u_14.new("Frame", {
		["Name"] = "Bar",
		["Size"] = UDim2.fromScale(0.35, 1),
		["Position"] = UDim2.fromScale(-0.35, 0),
		["BackgroundColor3"] = v17.Accent,
		v_u_14.Corner(v15.Radius.Pill),
		["Parent"] = v23
	})
	v_u_20.Position = UDim2.new(0.5, 0, 0, v_u_14.TopInset() + (v_u_14.Compact and 6 or 12))
	v_u_14.LayoutChanged:Connect(function() -- name: place
		-- upvalues: (copy) v_u_20, (copy) v_u_14
		v_u_20.Position = UDim2.new(0.5, 0, 0, v_u_14.TopInset() + (v_u_14.Compact and 6 or 12))
	end)
	local v_u_25 = nil
	local v_u_26 = nil
	local v_u_27 = false
	local v_u_28 = 0
	local function v_u_29() -- name: want
		-- upvalues: (copy) v_u_19, (ref) v_u_27, (copy) v_u_16
		if v_u_19:GetAttribute("Teleporting") == true then
			if v_u_27 then
				return nil, "", ""
			elseif v_u_19:GetAttribute("TeleportKind") == "Lobby" then
				return "lobby", "RETURNING TO LOBBY", "Taking you back to the lobby..."
			elseif v_u_19:GetAttribute("TeleportKind") == "Party" then
				return "party", "JOINING YOUR FRIEND", "Heading to their lobby..."
			elseif v_u_19:GetAttribute("TeleportKind") == "CustomCreate" then
				return "custom", "CREATING YOUR MATCH", "Setting up your server..."
			elseif v_u_19:GetAttribute("TeleportKind") == "Custom" then
				return "custom", "JOINING CUSTOM MATCH", "Heading to the host\'s server..."
			else
				return "match", "JOINING MATCH", "Heading to the arena..."
			end
		elseif v_u_19:GetAttribute("MMJoining") == true and not v_u_16.InMatch() then
			return "wait", "JOINING MATCH", "Waiting for the other players..."
		else
			return nil, "", ""
		end
	end
	local function v_u_34() -- name: refresh
		-- upvalues: (copy) v_u_29, (ref) v_u_26, (ref) v_u_28, (copy) v_u_21, (copy) v_u_22, (copy) v_u_20, (copy) v_u_14, (ref) v_u_25, (copy) v_u_24, (ref) v_u_2, (ref) v_u_12
		local v30, v_u_31, v_u_32 = v_u_29()
		if v30 ~= v_u_26 then
			v_u_26 = v30
			if v30 then
				v_u_28 = os.clock()
				v_u_21.Text = v_u_31
				v_u_22.Text = v_u_32
				if not v_u_20.Visible then
					v_u_20.Visible = true
					v_u_14.Enter(v_u_20, Vector2.new(0, -12))
				end
				if not v_u_25 then
					v_u_24.Position = UDim2.fromScale(-0.35, 0)
					v_u_25 = game:GetService("TweenService"):Create(v_u_24, TweenInfo.new(1.1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1), {
						["Position"] = UDim2.fromScale(1, 0)
					})
					v_u_25:Play()
				end
				if v30 ~= "wait" then
					local function v33()
						-- upvalues: (ref) v_u_2, (ref) v_u_12, (copy) v_u_31, (copy) v_u_32
						v_u_2:SetTeleportGui((v_u_12(v_u_31, v_u_32)))
					end
					pcall(v33)
					return
				end
			else
				v_u_20.Visible = false
				if v_u_25 then
					v_u_25:Cancel()
					v_u_25 = nil
				end
			end
		end
	end
	v_u_19:GetAttributeChangedSignal("Teleporting"):Connect(function()
		-- upvalues: (copy) v_u_19, (ref) v_u_27
		if v_u_19:GetAttribute("Teleporting") ~= true then
			v_u_27 = false
		end
	end)
	v_u_2.TeleportInitFailed:Connect(function(p35, p36)
		-- upvalues: (copy) v_u_19, (ref) v_u_26, (ref) v_u_27, (copy) p_u_13, (copy) v_u_34
		if p35 == v_u_19 and p36 ~= Enum.TeleportResult.IsTeleporting then
			if v_u_26 and (v_u_26 ~= "wait" and not v_u_27) then
				v_u_27 = true
				p_u_13.Toast(v_u_26 == "custom" and "Couldn\'t reach that server. You can keep playing here." or "Couldn\'t reach the match server. You can keep playing here.", "warning")
				v_u_34()
			end
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_26, (ref) v_u_28, (ref) v_u_27, (copy) v_u_34
		while true do
			repeat
				task.wait(1)
			until v_u_26 and (v_u_26 ~= "wait" and os.clock() - v_u_28 > 32)
			v_u_27 = true
			v_u_34()
		end
	end)
	local v_u_37 = v_u_26
	for _, v38 in { "Teleporting", "TeleportKind", "MMJoining" } do
		v_u_19:GetAttributeChangedSignal(v38):Connect(v_u_34)
	end
	v_u_16.PlayerStateChanged:Connect(v_u_34)
	v_u_34()
	function p_u_13.Debug.joining(p39)
		-- upvalues: (copy) v_u_16, (copy) v_u_19, (copy) v_u_34, (ref) v_u_37
		if v_u_16.Mock or p39 then
			if p39 == "match" or p39 == "lobby" then
				v_u_19:SetAttribute("TeleportKind", p39 == "lobby" and "Lobby" or "Match")
				v_u_19:SetAttribute("Teleporting", true)
			elseif p39 == "wait" then
				v_u_19:SetAttribute("MMJoining", true)
			else
				v_u_19:SetAttribute("Teleporting", nil)
				v_u_19:SetAttribute("MMJoining", nil)
			end
		end
		v_u_34()
		return {
			["shown"] = v_u_37 or false
		}
	end
end
return v3