local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = v2:WaitForChild("Shared")
local v_u_6 = require(v_u_5:WaitForChild("ReplayCodec"))
local v_u_7 = require(v_u_5:WaitForChild("Net"))
local v8 = {}
local v_u_9 = v1.LocalPlayer
local v_u_10 = 1 / v_u_6.VIEW_HZ
local v_u_11 = nil
task.spawn(function()
	-- upvalues: (copy) v_u_5, (ref) v_u_11
	local v12 = v_u_5:WaitForChild("Camera", 20)
	if v12 and v12:IsA("ModuleScript") then
		local v13 = require
		local v14, v15 = pcall(v13, v12)
		if v14 and type(v15) == "table" then
			v_u_11 = v15
		end
	end
end)
local v_u_16 = buffer.create(v_u_6.VIEW_FORMAT_BYTES)
local v_u_17 = 0
local v_u_18 = 0
local v_u_19 = 0
local v_u_20 = 0
local v_u_21 = -1
local v_u_22 = (-1 / 0)
local v_u_23 = 0
local function v_u_26() -- name: live
	-- upvalues: (copy) v_u_9, (copy) v_u_3, (copy) v_u_4, (ref) v_u_11
	if v_u_9:GetAttribute("State") == "Match" and v_u_9:GetAttribute("ReplayPlaying") ~= true then
		if v_u_3:IsStudio() and v_u_4:GetAttribute("ReplayViewOff") == true then
			return false
		else
			local v24 = v_u_9.Character
			if v24 then
				v24 = v24:FindFirstChildOfClass("Humanoid")
			end
			if v24 and (v24.Health > 0 and v_u_9:GetAttribute("CombatMode") ~= false) then
				local v25 = v_u_11
				if v25 then
					if v25.IsEnabled and not v25.IsEnabled() then
						return false
					else
						return (not v25.GetSpectateMode or v25.GetSpectateMode() == "none") and true or false
					end
				else
					return false
				end
			else
				return false
			end
		end
	else
		return false
	end
end
function v8.Start() -- name: Start
	-- upvalues: (copy) v_u_7, (copy) v_u_3, (ref) v_u_23, (copy) v_u_10, (copy) v_u_26, (ref) v_u_21, (copy) v_u_4, (ref) v_u_11, (copy) v_u_6, (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (ref) v_u_22, (copy) v_u_16, (ref) v_u_17
	local v_u_27 = v_u_7.UnreliableEvent("ReplayView")
	v_u_3.Heartbeat:Connect(function(p28)
		-- upvalues: (ref) v_u_23, (ref) v_u_10, (ref) v_u_26, (ref) v_u_21, (ref) v_u_4, (ref) v_u_11, (ref) v_u_6, (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (ref) v_u_22, (ref) v_u_16, (copy) v_u_27, (ref) v_u_17
		v_u_23 = v_u_23 + p28
		if v_u_23 < v_u_10 then
			return
		else
			v_u_23 = 0
			if v_u_26() then
				local v29 = v_u_4.CurrentCamera
				if v29 then
					local v30 = v29.CFrame.LookVector
					local v31 = -v30.X
					local v32 = -v30.Z
					local v33 = math.atan2(v31, v32)
					local v34 = v30.Y
					local v35 = math.clamp(v34, -1, 1)
					local v36 = math.asin(v35)
					local v37 = v29.FieldOfView + 0.5
					local v38 = math.floor(v37)
					local v39 = math.clamp(v38, 20, 120)
					if v_u_11.GetViewBobbing and v_u_11.GetViewBobbing() == true then
						v39 = v39 + 128
					end
					local v40 = 0
					if v_u_11.InFirstPerson and v_u_11.InFirstPerson() == true then
						v40 = v40 + v_u_6.F_FIRST
					end
					if v_u_11.IsAiming and v_u_11.IsAiming() == true then
						v40 = v40 + v_u_6.F_AIMCAM
					end
					if v_u_11.GetShoulderSide and v_u_11.GetShoulderSide() < 0 then
						v40 = v40 + v_u_6.V_LEFT
					end
					local v41 = os.clock()
					local v42 = (v33 - v_u_18 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
					if math.abs(v42) < 0.004363323129985824 then
						local v43 = v36 - v_u_19
						if math.abs(v43) < 0.004363323129985824 and (v39 == v_u_20 and (v40 == v_u_21 and v41 - v_u_22 < 0.4)) then
							return
						end
					end
					v_u_18 = v33
					v_u_19 = v36
					v_u_20 = v39
					v_u_21 = v40
					v_u_22 = v41
					local v44 = v_u_16
					local v45 = v_u_6.Q16
					local v46 = v_u_6.ROT_Q
					buffer.writei16(v44, 0, v45(v33, v46))
					local v47 = v_u_16
					local v48 = v_u_6.Q16
					local v49 = v_u_6.ROT_Q
					buffer.writei16(v47, 2, v48(v36, v49))
					local v50 = v_u_16
					buffer.writeu8(v50, 4, v39)
					local v51 = v_u_16
					buffer.writeu8(v51, 5, v40)
					v_u_27:FireServer(v_u_16)
					v_u_17 = v_u_17 + 1
				end
			else
				v_u_21 = -1
				return
			end
		end
	end)
end
function v8.Sent() -- name: Sent
	-- upvalues: (ref) v_u_17
	return v_u_17
end
return v8