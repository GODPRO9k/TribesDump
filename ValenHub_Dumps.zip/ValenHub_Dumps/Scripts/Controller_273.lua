local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
game:GetService("UserInputService")
local v4 = v2:WaitForChild("Shared")
local v_u_5 = require(v4.Net)
local v_u_6 = require(v4:WaitForChild("Simulation"))
local v_u_7 = require(v4.Weapons)
local v_u_8 = require(v4.Combat)
local v_u_9 = require(v4:WaitForChild("Keybinds"))
local v_u_10 = require(script.Parent.Util)
local v_u_11 = require(script.Parent.Hud)
local v_u_12 = require(script.Parent.Effects)
local v_u_13 = require(script.Parent.Presentation)
local v_u_14 = require(script.Parent.Guard)
local v_u_15 = require(script.Parent.Poses)
local v_u_16 = require(script.Parent.Metrics)
local v_u_17 = require(script.Parent.Touch)
local v_u_18 = require(script.Parent.Quality)
local v_u_19 = require(script.Parent.World)
local v_u_20 = require(script.Parent.RankFx)
local v_u_21 = {
	["Melee"] = require(script.Parent.Handlers.Melee),
	["Bow"] = require(script.Parent.Handlers.Bow),
	["Gun"] = require(script.Parent.Handlers.Gun),
	["Throw"] = require(script.Parent.Handlers.Throw),
	["Use"] = require(script.Parent.Handlers.Use)
}
local v_u_22 = {
	["Fists"] = "Melee",
	["Sword"] = "Melee",
	["Axe"] = "Melee",
	["Spear"] = "Melee",
	["Dagger"] = "Melee",
	["Club"] = "Melee",
	["Shield"] = "Melee",
	["Gauntlets"] = "Melee",
	["Scythe"] = "Melee",
	["Katana"] = "Melee",
	["Hatchets"] = "Melee",
	["Bow"] = "Bow",
	["Crossbow"] = "Gun",
	["Musket"] = "Gun",
	["Pistol"] = "Gun",
	["Blunderbuss"] = "Gun",
	["Knives"] = "Throw",
	["Javelin"] = "Throw",
	["Sling"] = "Throw",
	["Bomb"] = "Throw",
	["Herbs"] = "Use",
	["Trap"] = "Use",
	["Horn"] = "Use"
}
local v_u_23 = {}
local v_u_24 = v_u_1.LocalPlayer
local v_u_25 = nil
local v_u_26 = {
	["char"] = nil,
	["hum"] = nil,
	["root"] = nil,
	["animator"] = nil,
	["handler"] = nil,
	["tool"] = nil,
	["kind"] = nil,
	["pressed"] = nil,
	["speed"] = nil,
	["baseSpeed"] = 1,
	["conns"] = nil,
	["shotId"] = 0,
	["lastSpeed"] = -1,
	["killStreak"] = 0,
	["lastKillAt"] = 0,
	["pressed"] = {},
	["speed"] = {},
	["conns"] = {}
}
local function v_u_28() -- name: alive
	-- upvalues: (copy) v_u_26
	local v27
	if v_u_26.hum == nil or (v_u_26.hum.Health <= 0 or v_u_26.char == nil) then
		v27 = false
	else
		v27 = v_u_26.char.Parent ~= nil
	end
	return v27
end
local v_u_29 = nil
local v_u_30 = 0
local v_u_31 = 0
local v_u_32 = 0
local v_u_33 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_34 = {
	["requests"] = 0,
	["stale"] = 0,
	["adopted"] = 0,
	["resent"] = 0,
	["reasked"] = 0,
	["denied"] = 0
}
local v_u_35 = (-1 / 0)
local function v_u_39(p36, p37) -- name: send
	-- upvalues: (copy) v_u_33, (ref) v_u_25
	local v38 = p37.tool
	if v38 and v_u_33[v38] then
		p37.eq = v_u_33[v38]
	end
	p37.ct = os.clock()
	v_u_25:FireServer(p36, p37)
end
local function v_u_41() -- name: nextId
	-- upvalues: (copy) v_u_26
	local v40 = v_u_26
	v40.shotId = v40.shotId + 1
	return v_u_26.shotId
end
local v_u_42 = {
	["Aim"] = "Aim",
	["Draw"] = "Charge",
	["Throw"] = "Charge",
	["Charge"] = "Charge",
	["Block"] = "Block",
	["Reload"] = "Reload",
	["Use"] = "Use"
}
local function v_u_48() -- name: applySpeed
	-- upvalues: (copy) v_u_26, (copy) v_u_42, (copy) v_u_6
	local v43 = {
		["Aim"] = false,
		["Charge"] = false,
		["Block"] = false,
		["Reload"] = false,
		["Use"] = false
	}
	for v44 in v_u_26.speed do
		local v45 = v_u_42[v44]
		if not v45 then
			continue
		end
		v43[v45] = true
	end
	for v46, v47 in v43 do
		v_u_6.SetInput(v46, v47)
	end
end
local function v_u_51(p49, p50) -- name: setSpeed
	-- upvalues: (copy) v_u_26, (copy) v_u_48
	v_u_26.speed[p49] = p50
	v_u_48()
end
local v_u_52 = {}
local function v_u_58(p53, p54) -- name: emitView
	-- upvalues: (copy) v_u_52
	for _, v55 in v_u_52 do
		local v56, v57 = pcall(v55, p53, p54)
		if v56 then
			continue
		end
		warn("[Combat] view event listener error:", v57)
	end
end
function v_u_23.OnViewEvent(p_u_59) -- name: OnViewEvent
	-- upvalues: (copy) v_u_52
	local v60 = v_u_52
	table.insert(v60, p_u_59)
	return function()
		-- upvalues: (ref) v_u_52, (copy) p_u_59
		local v61 = table.find(v_u_52, p_u_59)
		if v61 then
			table.remove(v_u_52, v61)
		end
	end
end
local function v_u_65(p62) -- name: nameOf
	-- upvalues: (copy) v_u_1
	if p62 then
		local v63 = p62:GetAttribute("DisplayName")
		if type(v63) == "string" and v63 ~= "" then
			return v63
		else
			local v64 = v_u_1:GetPlayerFromCharacter(p62)
			if v64 then
				return v64.DisplayName
			else
				return p62:HasTag("TrainingDummy") and "Dummy" or p62.Name
			end
		end
	else
		return nil
	end
end
local function v_u_67() -- name: dropHandler
	-- upvalues: (copy) v_u_26, (copy) v_u_48
	local v_u_66 = v_u_26.handler
	if v_u_66 then
		v_u_26.handler = nil
		pcall(function()
			-- upvalues: (copy) v_u_66
			v_u_66:Unequip()
		end)
	end
	table.clear(v_u_26.pressed)
	table.clear(v_u_26.speed)
	v_u_48()
end
local function v_u_83() -- name: refreshEquipped
	-- upvalues: (copy) v_u_26, (copy) v_u_24, (copy) v_u_67, (copy) v_u_11, (copy) v_u_17, (ref) v_u_29, (copy) v_u_8, (copy) v_u_7, (copy) v_u_48, (copy) v_u_21, (copy) v_u_22, (copy) v_u_13, (copy) v_u_39, (copy) v_u_41, (copy) v_u_51, (copy) v_u_28, (copy) v_u_58
	local v68 = v_u_26.char
	if v68 then
		local v69
		if v_u_26.hum == nil or (v_u_26.hum.Health <= 0 or v_u_26.char == nil) then
			v69 = false
		else
			v69 = v_u_26.char.Parent ~= nil
		end
		if v69 then
			local v70 = v_u_24:GetAttribute("CombatMode")
			local v71
			if v70 == nil then
				v71 = v_u_24:GetAttribute("State") == "Match"
			else
				v71 = v70 == true
			end
			if v71 then
				local v72
				if v_u_29 and v_u_29.Parent == v68 then
					v72 = v_u_29
				else
					v72 = v68:FindFirstChildOfClass("Tool")
				end
				if v72 == v_u_26.tool and v_u_26.handler then
					return
				else
					v_u_67()
					v_u_26.tool = v72
					local v73 = v_u_8.FISTS_ID
					if v72 then
						v73 = v72:GetAttribute("WeaponId")
						if type(v73) ~= "string" or not v_u_7.Get(v73) then
							v_u_11.SetStyle("Dot")
							return
						end
					end
					local v74 = v_u_7.Get(v73)
					local v75 = v_u_8.Tuning(v73)
					local v76 = v_u_8.Kind(v73) or "Fists"
					v_u_26.kind = v76
					v_u_26.baseSpeed = v75.speedMult or 1
					v_u_48()
					local v77 = v_u_21[v_u_22[v76] or ""]
					if v77 then
						local v78 = {
							["player"] = v_u_24,
							["char"] = v68,
							["hum"] = v_u_26.hum,
							["root"] = v_u_26.root,
							["animator"] = v_u_26.animator,
							["tool"] = v72,
							["weaponId"] = v73,
							["def"] = v74,
							["tuning"] = v75,
							["kind"] = v76,
							["preset"] = v_u_13.For(v73, v76),
							["send"] = v_u_39,
							["nextId"] = v_u_41,
							["setSpeed"] = v_u_51,
							["alive"] = v_u_28,
							["emit"] = v_u_58
						}
						local v_u_79 = v77.new(v78)
						v_u_26.handler = v_u_79
						v_u_11.SetPips(0, 0)
						v_u_11.SetArc(nil)
						local v80 = v_u_17.SetWeapon
						if not v72 then
							v76 = nil
						end
						v80(v76, v75)
						local v81, v82 = pcall(function()
							-- upvalues: (copy) v_u_79
							v_u_79:Equip()
						end)
						if not v81 then
							warn("[Combat] equip error:", v82)
						end
					else
						v_u_11.SetStyle("Dot")
					end
				end
			end
		end
	end
	v_u_26.baseSpeed = 1
	v_u_67()
	v_u_26.tool = nil
	v_u_26.kind = nil
	v_u_11.SetStyle("Dot")
	v_u_11.SetPips(0, 0)
	v_u_11.SetArc(nil)
	v_u_17.SetWeapon(nil)
end
local function v_u_88() -- name: backpack
	-- upvalues: (copy) v_u_24
	local v84 = v_u_24:GetAttribute("CombatDrawToken")
	local v85 = nil
	for _, v86 in v_u_24:GetChildren() do
		if not v86:IsA("Backpack") then
			continue
		end
		v85 = v85 or v86
		for _, v87 in v86:GetChildren() do
			if v87:GetAttribute("DrawToken") ~= v84 then
				continue
			end
			return v86
		end
	end
	return v85
end
local function v_u_93(p89) -- name: toolInSlot
	-- upvalues: (copy) v_u_26, (copy) v_u_88
	for _, v90 in { v_u_26.char, (v_u_88()) } do
		if not v90 then
			continue
		end
		for _, v91 in v90:GetChildren() do
			local v92 = v91 ~= nil and v91:IsA("Tool")
			if v92 then
				v92 = type(v91:GetAttribute("WeaponId")) == "string"
			end
			if not v92 or v91:GetAttribute("SlotIndex") ~= p89 then
				continue
			end
			return v91
		end
	end
	return nil
end
local function v_u_100() -- name: enforceWant
	-- upvalues: (copy) v_u_26, (ref) v_u_29, (copy) v_u_88
	local v94 = v_u_26.char
	local v95 = v_u_26.hum
	local v96 = v_u_29
	if v94 and (v95 and (v95.Health > 0 and v96)) then
		local v97 = v_u_88()
		if v96.Parent == v94 or v96.Parent == v97 then
			if v96.Parent ~= v94 then
				v95:EquipTool(v96)
			end
			if v97 then
				for _, v98 in v94:GetChildren() do
					if v98 == v96 then
						continue
					end
					local v99 = v98 ~= nil and v98:IsA("Tool")
					if v99 then
						v99 = type(v98:GetAttribute("WeaponId")) == "string"
					end
					if not v99 then
						continue
					end
					v98.Parent = v97
				end
			end
		else
			v_u_29 = nil
		end
	else
		return
	end
end
local function v_u_115() -- name: reconcileEquip
	-- upvalues: (copy) v_u_26, (copy) v_u_88, (ref) v_u_29, (copy) v_u_24, (ref) v_u_30, (ref) v_u_31, (copy) v_u_100, (copy) v_u_93, (copy) v_u_34, (copy) v_u_33, (ref) v_u_35, (ref) v_u_25, (ref) v_u_32
	local v101 = v_u_26.char
	local v102 = v_u_26.hum
	if v101 and (v102 and v102.Health > 0) then
		local v103 = v_u_88()
		if v_u_29 and (v_u_29.Parent ~= v101 and v_u_29.Parent ~= v103) then
			v_u_29 = nil
		end
		local v104 = v_u_24:GetAttribute("EquipAck")
		local v105
		if (type(v104) ~= "number" and 0 or v104) < v_u_30 then
			v105 = os.clock() - v_u_31 < 4
		else
			v105 = false
		end
		if v105 then
			v_u_100()
			return
		else
			local v106 = v_u_24:GetAttribute("EquipSlot")
			local v107
			if type(v106) == "number" and v106 > 0 then
				v107 = v_u_93(v106)
			else
				v107 = nil
			end
			if v107 then
				if v_u_29 ~= v107 then
					if v_u_29 ~= nil then
						local v108 = v_u_34
						v108.adopted = v108.adopted + 1
					end
					v_u_29 = v107
					v_u_33[v107] = v_u_33[v107] or v_u_30
				end
				v_u_100()
			elseif v_u_29 and os.clock() - v_u_35 > 2 then
				v_u_35 = os.clock()
				local v109 = v_u_34
				v109.reasked = v109.reasked + 1
				local v110 = v_u_29
				v_u_29 = v110
				v_u_30 = v_u_30 + 1
				v_u_33[v110] = v_u_30
				v_u_31 = os.clock()
				local v111 = v_u_34
				v111.requests = v111.requests + 1
				v_u_100()
				local v112 = v_u_29
				if v112 and v_u_25 then
					v_u_32 = os.clock()
					local v113 = {
						["tool"] = v112,
						["seq"] = v_u_30
					}
					local v114 = v113.tool
					if v114 and v_u_33[v114] then
						v113.eq = v_u_33[v114]
					end
					v113.ct = os.clock()
					v_u_25:FireServer("Equip", v113)
				end
			end
		end
	else
		return
	end
end
local v_u_116 = false
local function v_u_117() -- name: queueReconcile
	-- upvalues: (ref) v_u_116, (copy) v_u_115, (copy) v_u_83
	if not v_u_116 then
		v_u_116 = true
		task.defer(function()
			-- upvalues: (ref) v_u_116, (ref) v_u_115, (ref) v_u_83
			v_u_116 = false
			v_u_115()
			v_u_83()
		end)
	end
end
function v_u_23.Equip(p118) -- name: Equip
	-- upvalues: (copy) v_u_26, (copy) v_u_88, (ref) v_u_29, (ref) v_u_30, (copy) v_u_33, (ref) v_u_31, (copy) v_u_34, (copy) v_u_100, (ref) v_u_25, (ref) v_u_32, (copy) v_u_83
	local v119 = v_u_26.char
	local v120 = v_u_26.hum
	if p118 and (v119 and (v120 and v120.Health > 0)) then
		local v121 = p118 ~= nil and p118:IsA("Tool")
		if v121 then
			v121 = type(p118:GetAttribute("WeaponId")) == "string"
		end
		if v121 then
			local v122 = v_u_88()
			if p118.Parent ~= v119 and p118.Parent ~= v122 then
				return false
			end
			if p118 == v_u_29 and p118.Parent == v119 then
				return true
			end
			v_u_29 = p118
			v_u_30 = v_u_30 + 1
			v_u_33[p118] = v_u_30
			v_u_31 = os.clock()
			local v123 = v_u_34
			v123.requests = v123.requests + 1
			v_u_100()
			local v124 = v_u_29
			if v124 and v_u_25 then
				v_u_32 = os.clock()
				local v125 = {
					["tool"] = v124,
					["seq"] = v_u_30
				}
				local v126 = v125.tool
				if v126 and v_u_33[v126] then
					v125.eq = v_u_33[v126]
				end
				v125.ct = os.clock()
				v_u_25:FireServer("Equip", v125)
			end
			v_u_83()
			return true
		end
	end
	return false
end
function v_u_23.Wanted() -- name: Wanted
	-- upvalues: (ref) v_u_29
	return v_u_29
end
local function v_u_151(p_u_127) -- name: onCharacter
	-- upvalues: (copy) v_u_26, (copy) v_u_67, (ref) v_u_29, (copy) v_u_10, (copy) v_u_8, (ref) v_u_25, (copy) v_u_34, (ref) v_u_116, (copy) v_u_115, (copy) v_u_83, (copy) v_u_11, (copy) v_u_17, (copy) v_u_48
	for _, v128 in v_u_26.conns do
		v128:Disconnect()
	end
	table.clear(v_u_26.conns)
	v_u_67()
	v_u_26.char = p_u_127
	v_u_29 = nil
	v_u_26.tool = nil
	v_u_26.lastSpeed = -1
	v_u_26.killStreak = 0
	local v129 = p_u_127:WaitForChild("Humanoid", 10)
	local v130 = p_u_127:WaitForChild("HumanoidRootPart", 10)
	if v129 and v130 then
		v_u_26.hum = v129
		v_u_26.root = v130
		local v131 = v129:FindFirstChildOfClass("Animator") or v129:WaitForChild("Animator", 5)
		local v132 = v_u_26
		if not (v131 and v131:IsA("Animator")) then
			v131 = nil
		end
		v132.animator = v131
		if v_u_26.animator then
			task.spawn(v_u_10.Preload, v_u_26.animator)
		end
		local v133 = v_u_26.conns
		local v134 = p_u_127.ChildAdded
		local function v139(p135)
			-- upvalues: (ref) v_u_8, (copy) p_u_127, (ref) v_u_25, (ref) v_u_29, (ref) v_u_26, (ref) v_u_34, (ref) v_u_116, (ref) v_u_115, (ref) v_u_83
			if p135:IsA("Tool") then
				v_u_8.BindOffHand(p135, p_u_127)
				if v_u_25 then
					local v136 = p135 ~= nil and p135:IsA("Tool")
					if v136 then
						v136 = type(p135:GetAttribute("WeaponId")) == "string"
					end
					if v136 and (p135 ~= v_u_29 and p135.Parent == v_u_26.char) then
						local v137 = p135 ~= nil and p135:IsA("Tool")
						if v137 then
							v137 = type(p135:GetAttribute("WeaponId")) == "string"
						end
						if v137 then
							local v138 = v_u_34
							v138.stale = v138.stale + 1
							if not v_u_116 then
								v_u_116 = true
								task.defer(function()
									-- upvalues: (ref) v_u_116, (ref) v_u_115, (ref) v_u_83
									v_u_116 = false
									v_u_115()
									v_u_83()
								end)
							end
						end
					end
				end
				task.defer(v_u_83)
			end
		end
		table.insert(v133, v134:Connect(v139))
		local v140 = v_u_26.conns
		local v141 = p_u_127.ChildRemoved
		local function v143(p142)
			-- upvalues: (ref) v_u_29, (ref) v_u_116, (ref) v_u_115, (ref) v_u_83
			if p142:IsA("Tool") then
				if p142 == v_u_29 and not v_u_116 then
					v_u_116 = true
					task.defer(function()
						-- upvalues: (ref) v_u_116, (ref) v_u_115, (ref) v_u_83
						v_u_116 = false
						v_u_115()
						v_u_83()
					end)
				end
				task.defer(v_u_83)
			end
		end
		table.insert(v140, v141:Connect(v143))
		local v144 = v_u_26.conns
		local v145 = v129.Died
		local function v146()
			-- upvalues: (ref) v_u_67, (ref) v_u_11, (ref) v_u_17
			v_u_67()
			v_u_11.SetStyle("Dot")
			v_u_11.SetPips(0, 0)
			v_u_11.SetArc(nil)
			v_u_17.SetWeapon(nil)
		end
		table.insert(v144, v145:Connect(v146))
		v_u_48()
		local v147 = p_u_127:FindFirstChildOfClass("Tool")
		if v147 and v_u_25 then
			local v148 = v147 ~= nil and v147:IsA("Tool")
			if v148 then
				v148 = type(v147:GetAttribute("WeaponId")) == "string"
			end
			if v148 and (v147 ~= v_u_29 and v147.Parent == v_u_26.char) then
				local v149 = v147 ~= nil and v147:IsA("Tool")
				if v149 then
					v149 = type(v147:GetAttribute("WeaponId")) == "string"
				end
				if v149 then
					local v150 = v_u_34
					v150.stale = v150.stale + 1
					if not v_u_116 then
						v_u_116 = true
						task.defer(function()
							-- upvalues: (ref) v_u_116, (ref) v_u_115, (ref) v_u_83
							v_u_116 = false
							v_u_115()
							v_u_83()
						end)
					end
				end
			end
		end
		v_u_83()
	end
end
local v_u_152 = nil
local function v_u_161(p153, p154) -- name: drawTool
	-- upvalues: (copy) v_u_26, (copy) v_u_88
	local v155 = nil
	for _, v156 in { v_u_26.char, (v_u_88()) } do
		if not v156 then
			continue
		end
		for _, v157 in v156:GetChildren() do
			local v158 = v157 ~= nil and v157:IsA("Tool")
			if v158 then
				v158 = type(v157:GetAttribute("WeaponId")) == "string"
			end
			if not v158 or v157:GetAttribute("DrawToken") ~= p154 then
				continue
			end
			if type(p153) == "string" and v157:GetAttribute("Slot") == p153 or type(p153) == "number" and v157:GetAttribute("SlotIndex") == p153 then
				return v157
			end
			local v159 = v157:GetAttribute("SlotIndex")
			local v160
			if v155 then
				v160 = v155:GetAttribute("SlotIndex")
			else
				v160 = v155
			end
			if v155 and (type(v159) ~= "number" or (type(v160) ~= "number" or v159 >= v160)) then
				continue
			end
			v155 = v157
		end
	end
	return v155
end
local function v_u_178() -- name: autoDraw
	-- upvalues: (copy) v_u_24, (ref) v_u_152, (copy) v_u_26, (ref) v_u_30, (ref) v_u_31, (ref) v_u_29, (copy) v_u_33, (copy) v_u_34, (copy) v_u_100, (ref) v_u_25, (ref) v_u_32, (copy) v_u_161, (copy) v_u_23
	local v_u_162 = v_u_24:GetAttribute("CombatDrawToken")
	if type(v_u_162) == "number" and v_u_162 ~= v_u_152 then
		v_u_152 = v_u_162
		task.spawn(function()
			-- upvalues: (ref) v_u_24, (copy) v_u_162, (ref) v_u_26, (ref) v_u_30, (ref) v_u_31, (ref) v_u_29, (ref) v_u_33, (ref) v_u_34, (ref) v_u_100, (ref) v_u_25, (ref) v_u_32, (ref) v_u_161, (ref) v_u_23
			local v163 = os.clock()
			local v164 = (-1 / 0)
			while os.clock() - v163 < 10 do
				if v_u_24:GetAttribute("CombatDrawToken") ~= v_u_162 then
					return
				end
				local v165 = v_u_24:GetAttribute("CombatDrawSlot")
				if v165 == 0 then
					return
				end
				local v166 = v_u_26.char
				local v167 = v_u_26.hum
				if v166 and (v167 and (v167.Health > 0 and (v166 == v_u_24.Character and v166:IsDescendantOf(workspace)))) then
					local v168 = v166:FindFirstChildOfClass("Tool")
					local v169
					if v168 == nil then
						v169 = false
					else
						v169 = v168 ~= nil and v168:IsA("Tool")
						if v169 then
							v169 = type(v168:GetAttribute("WeaponId")) == "string"
						end
						if v169 then
							v169 = v168:GetAttribute("DrawToken") == v_u_162
						end
					end
					if v169 then
						local v170 = v_u_24:GetAttribute("EquipAck")
						local v171
						if (type(v170) ~= "number" and 0 or v170) < v_u_30 then
							v171 = os.clock() - v_u_31 < 4
						else
							v171 = false
						end
						if not v171 then
							local v172 = v_u_24:GetAttribute("EquipSlot")
							if type(v172) == "number" and v172 > 0 then
								return
							end
							if os.clock() - v164 > 0.5 then
								v164 = os.clock()
								v_u_29 = v168
								v_u_30 = v_u_30 + 1
								v_u_33[v168] = v_u_30
								v_u_31 = os.clock()
								local v173 = v_u_34
								v173.requests = v173.requests + 1
								v_u_100()
								local v174 = v_u_29
								if v174 and v_u_25 then
									v_u_32 = os.clock()
									local v175 = {
										["tool"] = v174,
										["seq"] = v_u_30
									}
									local v176 = v175.tool
									if v176 and v_u_33[v176] then
										v175.eq = v_u_33[v176]
									end
									v175.ct = os.clock()
									v_u_25:FireServer("Equip", v175)
								end
							end
						end
					end
					if not v169 then
						local v177 = v_u_161(type(v165) ~= "number" and type(v165) ~= "string" and 1 or v165, v_u_162)
						if v177 then
							v_u_23.Equip(v177)
						end
					end
				end
				task.wait(0.1)
			end
		end)
	end
end
local v_u_179 = {
	["Attack"] = "Primary",
	["Aim"] = "Secondary",
	["Reload"] = "Reload"
}
local function v_u_185(p180) -- name: mapInput
	-- upvalues: (copy) v_u_9, (copy) v_u_179
	for _, v181 in v_u_9.PadActionsOf(p180) do
		local v182 = v_u_179[v181]
		if not v182 then
			continue
		end
		return v182
	end
	local v183 = p180.UserInputType
	if v183 == Enum.UserInputType.Keyboard or (v183 == Enum.UserInputType.MouseButton1 or (v183 == Enum.UserInputType.MouseButton2 or v183 == Enum.UserInputType.MouseButton3)) then
		local v184 = v_u_9.ActionOf(p180)
		if v184 then
			return v_u_179[v184]
		else
			return nil
		end
	else
		return nil
	end
end
local v_u_186 = {
	["n"] = 0,
	["last"] = ""
}
local function v_u_193(p_u_187, p_u_188) -- name: handlerInput
	-- upvalues: (copy) v_u_26, (copy) v_u_186
	local v_u_189 = v_u_26.handler
	if v_u_189 then
		local v190 = v_u_186
		v190.n = v190.n + 1
		v_u_186.last = p_u_187 .. (p_u_188 and "+" or "-")
		local v191, v192 = pcall(function()
			-- upvalues: (copy) v_u_189, (copy) p_u_187, (copy) p_u_188
			v_u_189:Input(p_u_187, p_u_188)
		end)
		if not v191 then
			warn("[Combat] input error:", v192)
		end
	end
end
local function v_u_198(p194, p195) -- name: onInputBegan
	-- upvalues: (copy) v_u_185, (copy) v_u_26, (copy) v_u_10, (copy) v_u_9, (copy) v_u_193
	if not p195 then
		local v196 = v_u_185(p194)
		if v196 and v_u_26.handler then
			local v197
			if v_u_26.hum == nil or (v_u_26.hum.Health <= 0 or v_u_26.char == nil) then
				v197 = false
			else
				v197 = v_u_26.char.Parent ~= nil
			end
			if v197 and not v_u_10.IsMouseUnlocked() then
				if not v_u_9.PadBlocked() or #v_u_9.PadActionsOf(p194) <= 0 then
					v_u_26.pressed[v196] = true
					v_u_193(v196, true)
				end
			end
		end
	end
end
local function v_u_201(p199, _) -- name: onInputEnded
	-- upvalues: (copy) v_u_185, (copy) v_u_26, (copy) v_u_193
	local v200 = v_u_185(p199)
	if v200 and v_u_26.pressed[v200] then
		v_u_26.pressed[v200] = nil
		v_u_193(v200, false)
	end
end
local function v_u_205(p202, p203) -- name: dispatch
	-- upvalues: (copy) v_u_26, (copy) v_u_10, (copy) v_u_193
	if p203 then
		if v_u_26.handler then
			local v204
			if v_u_26.hum == nil or (v_u_26.hum.Health <= 0 or v_u_26.char == nil) then
				v204 = false
			else
				v204 = v_u_26.char.Parent ~= nil
			end
			if v204 and not v_u_10.IsMouseUnlocked() then
				v_u_26.pressed[p202] = true
				v_u_193(p202, p203)
			end
		else
			return
		end
	else
		if not v_u_26.pressed[p202] then
			return
		end
		v_u_26.pressed[p202] = nil
		v_u_193(p202, p203)
		return
	end
end
v_u_23.Dispatch = v_u_205
local v_u_206 = false
local v_u_207 = 0
local function v_u_231(p208) -- name: onHitConfirm
	-- upvalues: (copy) v_u_10, (copy) v_u_11, (copy) v_u_12, (copy) v_u_8, (copy) v_u_26, (copy) v_u_65, (copy) v_u_13, (ref) v_u_207
	if type(p208) == "table" then
		local v209 = p208.position
		local v210
		if typeof(v209) == "Vector3" then
			v210 = p208.position
		else
			v210 = nil
		end
		local v211 = p208.amount
		local v212 = tonumber(v211) or 0
		local v213 = p208.headshot == true and true or p208.crit == true
		local v214 = p208.victim
		local v215 = p208.armor
		local v216 = tonumber(v215) or 0
		if p208.armorBroken then
			v_u_10.Sound("Shield_Break")
		end
		if v210 and v212 > 0 then
			local v217 = p208.dot and "dot" or (p208.killed and "kill" or (v213 and "crit" or (p208.blocked and "blocked" or (v216 > 0 and v212 - v216 < 0.5 and "armor" or "health"))))
			local v218
			if p208.dot then
				v218 = nil
			else
				v218 = p208.headshot and "HEADSHOT" or (p208.crit and "BACKSTAB" or (p208.blocked and "BLOCKED" or (p208.armorBroken and "ARMOR BROKEN" or nil)))
			end
			v_u_11.DamageNumber(v210, v212, v217, v214, v218)
		end
		if not p208.dot then
			local v219 = v_u_12.ConsumePrediction(v214)
			local v220 = os.clock()
			local v221 = v_u_8.Kind(p208.weaponId)
			local v222 = v_u_8.IsMelee(v221)
			if p208.killed then
				v_u_11.Hitmarker("kill")
				v_u_10.Sound(p208.headshot and "Kill_Confirm_Headshot" or "Kill_Confirm")
				v_u_26.killStreak = v220 - v_u_26.lastKillAt > 4 and 1 or v_u_26.killStreak + 1
				v_u_26.lastKillAt = v220
				local v223 = v_u_65(v214)
				local v224
				if v223 then
					v224 = string.upper(v223)
				else
					v224 = nil
				end
				if v_u_26.killStreak >= 2 then
					local v225 = v_u_26.killStreak == 2 and "DOUBLE ELIMINATION" or "TRIPLE ELIMINATION"
					local v226
					if v224 and p208.headshot then
						v226 = ("%* \194\183 HEADSHOT"):format(v224)
					else
						v226 = v224 or (p208.headshot and "HEADSHOT" or nil)
					end
					v_u_11.KillBanner(v225, v226)
				else
					v_u_11.KillBanner(not v224 and "ELIMINATED" or ("ELIMINATED %*"):format(v224), p208.headshot and "HEADSHOT" or nil)
				end
				v_u_10.Shake(0.35, 0.18)
			else
				v_u_11.Hitmarker(v213 and "crit" or "hit")
				if p208.headshot then
					v_u_10.Sound("Hitmarker_Headshot")
				elseif p208.crit then
					local v227 = v_u_10.Sound
					local v228 = p208.weaponId
					v227(v_u_13.For(v228, v221).critSound or "Hitmarker_Crit")
				elseif v220 - v_u_207 > 0.06 then
					v_u_207 = v220
					v_u_10.Sound(v222 and "Hitmarker" or "Hitmarker_Ranged")
				end
			end
			if v210 and (v222 and not v219) then
				local v229 = p208.weaponId
				local v230 = v_u_13.For(v229, v221)
				v_u_10.Sound(v230.hitSound or "Hit_Melee", v210)
			end
		end
	else
		return
	end
end
local function v_u_257(p232) -- name: onDamageTaken
	-- upvalues: (copy) v_u_11, (copy) v_u_20, (copy) v_u_10, (ref) v_u_206, (copy) v_u_26, (copy) v_u_58, (copy) v_u_14
	if type(p232) == "table" then
		local v233 = p232.amount
		local v234 = tonumber(v233) or 0
		local v235 = p232.fromPosition
		if p232.damageType == "Burn" then
			v_u_11.Hurt(0.2, Color3.fromRGB(255, 120, 40))
			return
		elseif p232.damageType == "World" or p232.weaponId == "ring" then
			v_u_11.Hurt(0.25, Color3.fromRGB(255, 110, 40))
			return
		elseif p232.damageType == "Sting" then
			v_u_11.Hurt(0.18, Color3.fromRGB(220, 160, 40))
			v_u_20.Stung()
			v_u_10.Sound("Damage_Receive", nil, {
				["Volume"] = 0.6,
				["PlaybackSpeed"] = 1.18
			})
			if p232.interrupted then
				local v_u_236 = not v_u_206 and v_u_26.handler
				if v_u_236 then
					local v237 = v_u_236.Interrupt
					if type(v237) == "function" then
						pcall(function()
							-- upvalues: (copy) v_u_236
							v_u_236:Interrupt()
						end)
					end
				end
				v_u_11.Toast("INTERRUPTED", Color3.fromRGB(255, 150, 90), 0.9)
			end
		else
			if typeof(v235) == "Vector3" then
				v_u_11.DamageFrom(v235, v234 >= 40)
			end
			local v238 = p232.armor
			local v239 = tonumber(v238) or 0
			if not v_u_206 then
				v_u_58("Hurt", {
					["amount"] = v234,
					["blocked"] = p232.blocked == true
				})
			end
			if p232.interrupted then
				local v_u_240 = not v_u_206 and v_u_26.handler
				if v_u_240 then
					local v241 = v_u_240.Interrupt
					if type(v241) == "function" then
						pcall(function()
							-- upvalues: (copy) v_u_240
							v_u_240:Interrupt()
						end)
					end
				end
				v_u_11.Toast("INTERRUPTED", Color3.fromRGB(255, 150, 90), 0.9)
			end
			if p232.armorBroken then
				v_u_10.Sound("Shield_Break")
				v_u_11.Toast("ARMOR BROKEN", Color3.fromRGB(200, 210, 225), 1.1)
			end
			if p232.blocked then
				local v242 = v_u_11.Hurt
				local v243 = v234 / 60
				v242(math.min(0.35, v243), Color3.fromRGB(110, 190, 255))
				v_u_11.BlockPulse()
				if not v_u_206 then
					v_u_14.Impact(v_u_26.char, true)
				end
			elseif v239 > 0 and v234 - v239 < 0.5 then
				local v244 = v_u_11.Hurt
				local v245 = v234 / 70
				v244(math.min(0.3, v245), Color3.fromRGB(170, 185, 205))
				local v246 = v_u_10.Shake
				local v247 = v234 / 70
				v246(math.clamp(v247, 0.15, 0.6), 0.2)
				v_u_10.Sound("Impact_Metal")
			else
				v_u_11.Hurt(v234 / 35, nil)
				local v248 = v_u_10.Shake
				local v249 = v234 / 45
				v248(math.clamp(v249, 0.2, 1.1), 0.28)
				local v250 = v_u_10.Recoil
				local v251 = v234 / 12
				v250(math.clamp(v251, 0.5, 4), (math.random() - 0.5) * 3)
				v_u_10.Sound(v234 >= 30 and "Damage_Receive_Heavy" or "Damage_Receive")
			end
			local v252 = p232.stagger
			if type(v252) == "number" and p232.stagger > 0 then
				local v_u_253 = not v_u_206 and v_u_26.handler
				if v_u_253 then
					local v254 = v_u_253.Interrupt
					if type(v254) == "function" then
						pcall(function()
							-- upvalues: (copy) v_u_253
							v_u_253:Interrupt()
						end)
					end
				end
				v_u_11.Toast("STAGGERED", Color3.fromRGB(255, 170, 90), p232.stagger + 0.2)
			end
			if p232.damageType == "Trap" then
				local v_u_255 = not v_u_206 and v_u_26.handler
				if v_u_255 then
					local v256 = v_u_255.Interrupt
					if type(v256) == "function" then
						pcall(function()
							-- upvalues: (copy) v_u_255
							v_u_255:Interrupt()
						end)
					end
				end
				v_u_11.Toast("TRAPPED!", Color3.fromRGB(255, 120, 90), 1.4)
			end
		end
	else
		return
	end
end
local v_u_258 = {}
local v_u_259 = {}
task.spawn(function()
	-- upvalues: (copy) v_u_258, (copy) v_u_259
	while true do
		task.wait(10)
		for v260 in v_u_258 do
			if v260.Parent then
				continue
			end
			v_u_258[v260] = nil
		end
		for v261 in v_u_259 do
			if v261.Parent then
				continue
			end
			v_u_259[v261] = nil
		end
	end
end)
local function v_u_459(p262, p263) -- name: onCombatFX
	-- upvalues: (copy) v_u_26, (copy) v_u_12, (copy) v_u_8, (copy) v_u_13, (copy) v_u_10, (copy) v_u_18, (copy) v_u_15, (copy) v_u_258, (copy) v_u_11, (copy) v_u_20, (ref) v_u_206, (copy) v_u_58, (copy) v_u_14, (copy) v_u_259, (copy) v_u_34, (ref) v_u_29, (copy) v_u_24, (ref) v_u_30, (ref) v_u_31, (copy) v_u_33, (copy) v_u_100, (ref) v_u_25, (ref) v_u_32
	if type(p262) ~= "string" or type(p263) ~= "table" then
		return
	end
	local v264 = v_u_26.char
	if p262 == "Swing" then
		local v265 = p263.attacker
		if typeof(v265) == "Instance" then
			if v265:IsA("Player") then
				v265 = v265.Character
			elseif not v265:IsA("Model") then
				v265 = nil
			end
		else
			v265 = nil
		end
		if not v265 or v265 == v264 then
			return
		end
		local v266
		if typeof(v265) == "Instance" then
			if v265:IsA("Player") then
				v266 = v265.Character
			elseif v265:IsA("Model") then
				v266 = v265
			else
				v266 = nil
			end
		else
			v266 = nil
		end
		if v266 then
			v266 = v266:FindFirstChild("HumanoidRootPart")
		end
		if not (v266 and v266:IsA("BasePart")) then
			v266 = nil
		end
		if v266 then
			local v267 = v266.Position
			local v268
			if v267 == nil then
				v268 = false
			else
				v268 = v_u_12.CamDistance(v267) > v_u_12.NEAR
			end
			if not v268 then
				local v269 = v_u_8.Kind(p263.weaponId) or "Fists"
				local v270 = p263.weaponId
				local v271 = v_u_13.For(v270, v269)
				local v272
				if p263.heavy == true then
					v272 = v271.heavySound or v271.swingSound
				elseif p263.lunge == true then
					v272 = v271.lungeSound or v271.swingSound
				else
					v272 = v271.swingSound
				end
				v_u_10.Sound(v272 or "Swing_Sword", v266)
				if v271.trail and (v271.trail > 0 and v_u_18.layers) then
					local v273 = v_u_12.Trail
					local v274
					if v265 then
						v274 = v265:FindFirstChildOfClass("Tool") or nil
					else
						v274 = nil
					end
					v273(v274, v271.trail)
				end
				if not v271.noSlash then
					local v275 = v_u_12.Slash
					local v276 = p263.step
					v275(v265, tonumber(v276) or 1, p263.heavy == true, v271.slashColor)
					if p263.heavy == true then
						v_u_12.GroundScuff(v266.Position + v266.CFrame.LookVector * 4 - Vector3.new(0, 2.8, 0))
						return
					end
				end
			end
		else
			return
		end
	elseif p262 == "Projectile" then
		local v277 = p263.shooter
		if typeof(v277) == "Instance" then
			if v277:IsA("Player") then
				v277 = v277.Character
			elseif not v277:IsA("Model") then
				v277 = nil
			end
		else
			v277 = nil
		end
		if v277 and (v277 == v264 and p263.deflected ~= true) then
			return
		end
		local v278 = p263.origin
		if typeof(v278) == "Vector3" then
			local v279 = p263.velocity
			if typeof(v279) == "Vector3" then
				local v280 = p263.key
				if type(v280) == "string" then
					local v281 = p263.gravity
					local v282 = tonumber(v281) or 0
					local v283 = p263.pellets
					local v284 = tonumber(v283)
					if v284 and v284 > 1 then
						local v285 = p263.velocity
						local v286 = v_u_12.Pellets
						local v287 = p263.key
						local v288 = p263.kind
						local v289 = p263.origin
						local v290 = v285.Unit
						local v291 = v285.Magnitude
						local v292 = p263.spread
						local v293 = tonumber(v292) or 6
						local v294 = p263.seed
						v286(v287, v288, v289, v290, v291, v282, v284, v293, tonumber(v294) or 0, v277)
					else
						v_u_12.Projectile(p263.key, p263.kind, p263.origin, p263.velocity, v282, v277)
					end
					local v295 = v_u_8.Kind(p263.weaponId)
					local v296 = p263.weaponId
					local v297 = v_u_13.For(v296, v295 or "Bow")
					local v298 = p263.origin
					local v299
					if v298 == nil then
						v299 = false
					else
						v299 = v_u_12.CamDistance(v298) > v_u_12.NEAR
					end
					local v300 = not v299
					if v300 and (v297.flash or v297.puff) then
						v_u_12.Muzzle(CFrame.lookAt(p263.origin, p263.origin + p263.velocity), v295 ~= "Pistol", v297.puff ~= false)
					end
					if v277 and v297.kick then
						v_u_15.Kick(v277, v297.kick * 5)
					end
					local v301 = os.clock()
					local v302 = v277 or workspace
					if v301 - (v_u_258[v302] or 0) > 0.08 then
						v_u_258[v302] = v301
						local v303 = v297.fireSound or (v297.throwSound or "Bow_Release")
						if v300 or v297.flash then
							v_u_10.Sound(v303, p263.origin)
							return
						end
					end
				end
			else
				return
			end
		else
			return
		end
	else
		if p262 == "ProjectileHit" then
			v_u_12.ResolveProjectile(p263)
			return
		end
		if p262 == "Explosion" then
			local v304 = p263.position
			if typeof(v304) == "Vector3" then
				local v305 = v_u_12.Explosion
				local v306 = p263.position
				local v307 = p263.radius
				local v308 = tonumber(v307) or 10
				local v309 = p263.zoneRadius
				local v310 = tonumber(v309)
				local v311 = p263.zoneTime
				v305(v306, v308, v310, (tonumber(v311)))
				return
			end
			return
		elseif p262 == "Smoke" then
			local v312 = p263.position
			if typeof(v312) == "Vector3" then
				local v313 = p263.duration
				local v314 = tonumber(v313) or 7
				local v315 = v_u_12.SmokeCloud
				local v316 = p263.position
				local v317 = p263.radius
				v315(v316, tonumber(v317) or 13, v314)
				if p263.hiss == true then
					local v_u_318 = Instance.new("Part")
					v_u_318.Name = "SmokeHiss"
					v_u_318.Anchored = true
					v_u_318.CanCollide = false
					v_u_318.CanQuery = false
					v_u_318.CanTouch = false
					v_u_318.Transparency = 1
					v_u_318.Size = Vector3.new(1, 1, 1)
					v_u_318.CFrame = CFrame.new(p263.position)
					v_u_318.Parent = workspace
					local v_u_319 = v_u_10.Loop("Smoke_Hiss_Loop", v_u_318)
					task.delay(v314, function()
						-- upvalues: (copy) v_u_319, (copy) v_u_318
						local v320 = v_u_319
						pcall(v320, 1)
						task.delay(1.2, function()
							-- upvalues: (ref) v_u_318
							v_u_318:Destroy()
						end)
					end)
					return
				end
			end
			return
		elseif p262 == "Horn" then
			local v321 = p263.attacker
			if typeof(v321) == "Instance" then
				if v321:IsA("Player") then
					v321 = v321.Character
				elseif not v321:IsA("Model") then
					v321 = nil
				end
			else
				v321 = nil
			end
			local v322 = p263.position
			local v323
			if typeof(v322) == "Vector3" then
				v323 = p263.position
			else
				v323 = nil
			end
			if not v323 then
				return
			end
			v_u_10.Sound("War_Horn", v323)
			v_u_12.HornBlast(v323)
			if v321 == nil or v321 ~= v264 and not v_u_10.IsTeammate(v321) then
				if v321 ~= nil and (v264 ~= nil and v_u_10.IsEnemy(v321)) then
					local v324 = v_u_11.DamageFrom
					local v325 = Color3.fromRGB(240, 180, 70)
					local v326 = p263.reveal
					v324(v323, true, v325, tonumber(v326) or 3)
					v_u_11.Toast("ENEMY HORN", Color3.fromRGB(240, 180, 70), 1.6)
					return
				end
			else
				local v327 = p263.enemies
				if type(v327) == "table" then
					for _, v329 in p263.enemies do
						local v329
						if typeof(v329) == "Instance" then
							if v329:IsA("Player") then
								v329 = v329.Character
							elseif not v329:IsA("Model") then
								v329 = nil
							end
						else
							v329 = nil
						end
						if not v329 then
							continue
						end
						local v330 = v_u_12.Reveal
						local v331 = p263.reveal
						v330(v329, tonumber(v331) or 3)
					end
				end
				if v_u_10.InMatch() then
					v_u_11.Toast("TRIBE RALLIED", Color3.fromRGB(226, 190, 110), 1.6)
					return
				end
			end
			return
		elseif p262 == "Chakram" then
			local v332 = p263.shooter
			if typeof(v332) == "Instance" then
				if v332:IsA("Player") then
					v332 = v332.Character
				elseif not v332:IsA("Model") then
					v332 = nil
				end
			else
				v332 = nil
			end
			if v332 == v264 then
				return
			else
				local v333 = p263.origin
				if typeof(v333) == "Vector3" then
					local v334 = p263.dir
					if typeof(v334) == "Vector3" then
						local v335 = p263.key
						if type(v335) == "string" then
							local v336 = v_u_12.Chakram
							local v337 = p263.key
							local v338 = p263.origin
							local v339 = p263.dir
							local v340 = p263.speed
							local v341 = tonumber(v340) or 110
							local v342 = p263.range
							local v343 = tonumber(v342) or 45
							local v344 = p263.catch
							v336(v337, v338, v339, v341, v343, tonumber(v344) or 4.5, v332)
							local v345 = p263.origin
							local v346
							if v345 == nil then
								v346 = false
							else
								v346 = v_u_12.CamDistance(v345) > v_u_12.NEAR
							end
							if not v346 then
								v_u_10.Sound("Knife_Throw", p263.origin)
								return
							end
						end
					else
						return
					end
				else
					return
				end
			end
		elseif p262 == "ChakramTurn" then
			local v347 = p263.key
			if type(v347) == "string" then
				local v348 = p263.position
				if typeof(v348) == "Vector3" then
					v_u_12.ChakramTurn(p263.key, p263.position)
					return
				end
			end
			return
		elseif p262 == "ChakramEnd" then
			local v349 = p263.key
			if type(v349) == "string" then
				local v350 = v_u_12.ChakramEnd
				local v351 = p263.key
				local v352 = p263.caught == true
				local v353 = p263.position
				local v354
				if typeof(v353) == "Vector3" then
					v354 = p263.position
				else
					v354 = nil
				end
				v350(v351, v352, v354)
				return
			end
			return
		elseif p262 == "FirePatch" then
			local v355 = p263.position
			if typeof(v355) == "Vector3" then
				local v356 = v_u_12.FirePatch
				local v357 = p263.position
				local v358 = p263.radius
				local v359 = tonumber(v358) or 3.5
				local v360 = p263.duration
				v356(v357, v359, tonumber(v360) or 1.5)
				return
			end
			return
		elseif p262 == "Wall" then
			local v361 = p263.position
			if typeof(v361) == "Vector3" then
				local v362 = v_u_12.Wall
				local v363 = p263.position
				local v364 = p263.op
				local v365 = tostring(v364)
				local v366 = p263.width
				local v367 = tonumber(v366) or 6
				local v368 = p263.height
				v362(v363, v365, v367, tonumber(v368) or 5)
				return
			end
			return
		elseif p262 == "HealPool" then
			local v369 = p263.position
			if typeof(v369) == "Vector3" then
				local v370 = v_u_12.HealPool
				local v371 = p263.position
				local v372 = p263.radius
				local v373 = tonumber(v372) or 10
				local v374 = p263.duration
				v370(v371, v373, tonumber(v374) or 3)
				return
			end
			return
		else
			if p262 == "Caltrops" then
				v_u_12.Caltrops(p263)
				return
			end
			if p262 == "CaltropsEnd" then
				local v375 = p263.id
				local v376 = tonumber(v375)
				if v376 then
					v_u_12.CaltropsEnd(v376)
					return
				end
				return
			else
				if p262 == "Swarm" then
					v_u_20.Swarm(p263)
					return
				end
				if p262 == "SwarmTarget" then
					v_u_20.SwarmTarget(p263)
					return
				end
				if p262 == "SwarmSync" then
					v_u_20.SwarmSync(p263)
					return
				end
				if p262 == "SwarmEnd" then
					v_u_20.SwarmEnd(p263)
					return
				end
				if p262 == "HatchetDrop" then
					v_u_20.HatchetDrop(p263)
					return
				end
				if p262 == "HatchetEnd" then
					v_u_20.HatchetEnd(p263)
					return
				end
				if p262 == "ParryStart" then
					v_u_20.ParryStart(p263)
					return
				end
				if p262 == "Parry" then
					v_u_20.Parried(p263)
					local v377 = p263.target
					if typeof(v377) == "Instance" then
						if v377:IsA("Player") then
							v377 = v377.Character
						elseif not v377:IsA("Model") then
							v377 = nil
						end
					else
						v377 = nil
					end
					local v378 = p263.attacker
					if typeof(v378) == "Instance" then
						if v378:IsA("Player") then
							v378 = v378.Character
						elseif not v378:IsA("Model") then
							v378 = nil
						end
					else
						v378 = nil
					end
					if v377 == nil or (v377 ~= v264 or v_u_206) then
						if v378 ~= nil and (v378 == v264 and not v_u_206) then
							if p263.staggered then
								local v_u_379 = not v_u_206 and v_u_26.handler
								if v_u_379 then
									local v380 = v_u_379.Interrupt
									if type(v380) == "function" then
										pcall(function()
											-- upvalues: (copy) v_u_379
											v_u_379:Interrupt()
										end)
									end
								end
								local v381 = v_u_11.Toast
								local v382 = Color3.fromRGB(255, 170, 90)
								local v383 = p263.stagger
								v381("PARRIED \194\183 STAGGERED", v382, (tonumber(v383) or 0.5) + 0.3)
								v_u_10.Shake(0.4, 0.18)
							else
								v_u_11.Toast("PARRIED", Color3.fromRGB(255, 170, 90), 0.9)
							end
						end
					else
						v_u_11.Flash(Color3.fromRGB(150, 196, 236), 0.5, 0.25)
						v_u_11.Toast(p263.ranged and "DEFLECTED" or "PARRIED", Color3.fromRGB(170, 214, 245), 0.9)
						v_u_10.Shake(0.25, 0.12)
						v_u_58("Parried", {
							["ranged"] = p263.ranged == true
						})
						local v_u_384 = v_u_26.handler
						if v_u_384 then
							local v385 = v_u_384.ParryUsed
							if type(v385) == "function" then
								pcall(function()
									-- upvalues: (copy) v_u_384
									v_u_384:ParryUsed()
								end)
								return
							end
						end
					end
					return
				elseif p262 == "TrapSnap" then
					local v386 = p263.position
					if typeof(v386) == "Vector3" then
						v_u_12.TrapSnap(p263.position)
						return
					end
					return
				elseif p262 == "Hit" then
					local v387 = p263.target
					if typeof(v387) == "Instance" then
						if v387:IsA("Player") then
							v387 = v387.Character
						elseif not v387:IsA("Model") then
							v387 = nil
						end
					else
						v387 = nil
					end
					local v388 = p263.position
					local v389
					if typeof(v388) == "Vector3" then
						v389 = p263.position
					else
						v389 = nil
					end
					local v390 = p263.attacker
					if typeof(v390) == "Instance" then
						if v390:IsA("Player") then
							v390 = v390.Character
						elseif not v390:IsA("Model") then
							v390 = nil
						end
					else
						v390 = nil
					end
					local v391
					if v390 == nil or v390 ~= v264 then
						if v387 == nil then
							v391 = false
						else
							v391 = v387 == v264
						end
					else
						v391 = true
					end
					if not v391 then
						local v392
						if v389 == nil then
							v392 = false
						else
							v392 = v_u_12.CamDistance(v389) > v_u_12.NEAR
						end
						if v392 then
							return
						end
					end
					if p263.damageType ~= "Burn" and v387 ~= v264 then
						local v393 = v_u_12.HitFlash
						local v394
						if p263.blocked then
							v394 = Color3.fromRGB(110, 190, 255)
						else
							v394 = nil
						end
						v393(v387, v394)
					end
					if v389 and p263.damageType ~= "Burn" then
						local v395 = p263.source
						local v396
						if typeof(v395) == "Vector3" and (v389 - p263.source).Magnitude > 0.1 then
							v396 = (v389 - p263.source).Unit
						else
							v396 = nil
						end
						local v397 = p263.blocked and "blocked" or ((p263.headshot or p263.crit) and "headshot" or "health")
						v_u_12.CharacterImpact(v389, v396, p263.headshot == true and true or p263.killed == true, v397)
					end
					if p263.blocked and (v387 and v387 ~= v264) then
						v_u_14.Impact(v387, false)
					end
					if v389 and p263.armor then
						v_u_12.ArmorHit(v389, p263.armorBroken == true)
					end
					if v389 and (v390 ~= v264 and (v387 ~= v264 and p263.damageType == "Melee")) then
						local v398 = v_u_8.Kind(p263.weaponId) or "Sword"
						local v399 = p263.weaponId
						local v400 = v_u_13.For(v399, v398)
						v_u_10.Sound(v400.hitSound or "Hit_Melee", v389)
						return
					end
					return
				elseif p262 == "Death" then
					local v401 = p263.position
					if typeof(v401) == "Vector3" then
						local v402 = v_u_12.Death
						local v403 = p263.position
						local v404 = false
						local v405 = p263.killer
						if typeof(v405) == "Instance" then
							if v405:IsA("Player") then
								v405 = v405.Character
							elseif not v405:IsA("Model") then
								v405 = nil
							end
						else
							v405 = nil
						end
						if v405 == v264 then
							v404 = v264 ~= nil
						end
						local v406 = p263.weaponId
						local v407
						if type(v406) == "string" then
							v407 = p263.weaponId
						else
							v407 = nil
						end
						v402(v403, v404, v407, p263.headshot == true)
						return
					end
					return
				elseif p262 == "Heal" then
					local v408 = p263.target
					if typeof(v408) == "Instance" then
						if v408:IsA("Player") then
							v408 = v408.Character
						elseif not v408:IsA("Model") then
							v408 = nil
						end
					else
						v408 = nil
					end
					local v409
					if typeof(v408) == "Instance" then
						if v408:IsA("Player") then
							v409 = v408.Character
						elseif v408:IsA("Model") then
							v409 = v408
						else
							v409 = nil
						end
					else
						v409 = nil
					end
					if v409 then
						v409 = v409:FindFirstChild("HumanoidRootPart")
					end
					if not (v409 and v409:IsA("BasePart")) then
						v409 = nil
					end
					local v410, v411
					if v408 == v264 then
						v410 = v_u_12.Heal
						v411 = p263.duration
						v410(v408, tonumber(v411) or 3)
						return
					elseif v409 then
						local v412 = v409.Position
						local v413
						if v412 == nil then
							v413 = false
						else
							v413 = v_u_12.CamDistance(v412) > v_u_12.NEAR
						end
						if not v413 then
							v410 = v_u_12.Heal
							v411 = p263.duration
							v410(v408, tonumber(v411) or 3)
						end
					else
						return
					end
				elseif p262 == "Status" then
					local v414 = p263.target
					if typeof(v414) == "Instance" then
						if v414:IsA("Player") then
							v414 = v414.Character
						elseif not v414:IsA("Model") then
							v414 = nil
						end
					else
						v414 = nil
					end
					local v415
					if typeof(v414) == "Instance" then
						if v414:IsA("Player") then
							v415 = v414.Character
						elseif v414:IsA("Model") then
							v415 = v414
						else
							v415 = nil
						end
					else
						v415 = nil
					end
					if v415 then
						v415 = v415:FindFirstChild("HumanoidRootPart")
					end
					if not (v415 and v415:IsA("BasePart")) then
						v415 = nil
					end
					local v416, v417, v418
					if v414 == v264 then
						if p263.status == "Caltrops" then
							if v414 and v414:IsA("Model") then
								v_u_12.CaltropStep(v414)
							end
							if v414 == v264 then
								v_u_11.Toast("CALTROPS", Color3.fromRGB(214, 180, 140), 0.9)
							end
							return
						end
						v416 = v_u_12.Status
						v417 = p263.status
						v418 = p263.duration
						v416(v414, v417, tonumber(v418) or 1)
						if v414 == v264 and p263.status == "Burn" then
							v_u_11.Toast("BURNING", Color3.fromRGB(255, 140, 60), 1)
							return
						end
						if v414 == v264 and p263.status == "Snare" then
							v_u_11.Toast("SNARED", Color3.fromRGB(226, 196, 140), 1.2)
							return
						end
					else
						if not v415 then
							return
						end
						local v419 = v415.Position
						local v420
						if v419 == nil then
							v420 = false
						else
							v420 = v_u_12.CamDistance(v419) > v_u_12.NEAR
						end
						if v420 then
							return
						end
						if p263.status == "Caltrops" then
							if v414 and v414:IsA("Model") then
								v_u_12.CaltropStep(v414)
							end
							if v414 == v264 then
								v_u_11.Toast("CALTROPS", Color3.fromRGB(214, 180, 140), 0.9)
							end
							return
						end
						v416 = v_u_12.Status
						v417 = p263.status
						v418 = p263.duration
						v416(v414, v417, tonumber(v418) or 1)
						if v414 == v264 and p263.status == "Burn" then
							v_u_11.Toast("BURNING", Color3.fromRGB(255, 140, 60), 1)
							return
						end
						if v414 == v264 and p263.status == "Snare" then
							v_u_11.Toast("SNARED", Color3.fromRGB(226, 196, 140), 1.2)
							return
						end
					end
				elseif p262 == "Charge" then
					local v421 = p263.attacker
					if typeof(v421) == "Instance" then
						if v421:IsA("Player") then
							v421 = v421.Character
						elseif not v421:IsA("Model") then
							v421 = nil
						end
					else
						v421 = nil
					end
					if v421 and (v421 ~= v264 and p263.on) then
						if typeof(v421) == "Instance" then
							if v421:IsA("Player") then
								v421 = v421.Character
							elseif not v421:IsA("Model") then
								v421 = nil
							end
						else
							v421 = nil
						end
						if v421 then
							v421 = v421:FindFirstChild("HumanoidRootPart")
						end
						if not (v421 and v421:IsA("BasePart")) then
							v421 = nil
						end
						local v422 = v_u_8.Kind(p263.weaponId)
						local v423 = p263.weaponId
						local v424 = v_u_13.For(v423, v422)
						if p263.kind == "Draw" then
							v_u_10.Sound(v424.drawSound or "Bow_Draw", v421)
							return
						end
						if p263.kind == "Heavy" or p263.kind == "Lunge" then
							v_u_10.Sound(v424.chargeSound or "Charge_Up", v421)
							return
						end
						if p263.kind == "Throw" then
							v_u_10.Sound(v424.windupSound or "Throw_Windup", v421)
							return
						end
					end
				elseif p262 == "Reload" then
					local v_u_425 = p263.attacker
					if typeof(v_u_425) == "Instance" then
						if v_u_425:IsA("Player") then
							v_u_425 = v_u_425.Character
						elseif not v_u_425:IsA("Model") then
							v_u_425 = nil
						end
					else
						v_u_425 = nil
					end
					if v_u_425 and v_u_425 ~= v264 then
						local v426 = v_u_8.Kind(p263.weaponId) or "Crossbow"
						local v427 = p263.weaponId
						local v_u_428 = v_u_13.For(v427, v426)
						task.delay(0.5, function()
							-- upvalues: (ref) v_u_10, (copy) v_u_428, (copy) v_u_425
							local v429 = v_u_10.Sound
							local v430 = v_u_428.reloadSound or "Crossbow_Reload"
							local v431 = v_u_425
							if typeof(v431) == "Instance" then
								if v431:IsA("Player") then
									v431 = v431.Character
								elseif not v431:IsA("Model") then
									v431 = nil
								end
							else
								v431 = nil
							end
							if v431 then
								v431 = v431:FindFirstChild("HumanoidRootPart")
							end
							if not (v431 and v431:IsA("BasePart")) then
								v431 = nil
							end
							v429(v430, v431)
						end)
						return
					end
				elseif p262 == "Block" then
					local v432 = p263.attacker
					if typeof(v432) == "Instance" then
						if v432:IsA("Player") then
							v432 = v432.Character
						elseif not v432:IsA("Model") then
							v432 = nil
						end
					else
						v432 = nil
					end
					if v432 and (v432 ~= v264 and p263.on) then
						local v433 = os.clock()
						if v433 - (v_u_259[v432] or (-1 / 0)) >= 0.5 then
							v_u_259[v432] = v433
							local v434 = v_u_10.Sound
							local v435 = "Block_Up"
							if typeof(v432) == "Instance" then
								if v432:IsA("Player") then
									v432 = v432.Character
								elseif not v432:IsA("Model") then
									v432 = nil
								end
							else
								v432 = nil
							end
							if v432 then
								v432 = v432:FindFirstChild("HumanoidRootPart")
							end
							if not (v432 and v432:IsA("BasePart")) then
								v432 = nil
							end
							v434(v435, v432)
							return
						end
					end
				elseif p262 == "Use" then
					local v436 = p263.attacker
					if typeof(v436) == "Instance" then
						if v436:IsA("Player") then
							v436 = v436.Character
						elseif not v436:IsA("Model") then
							v436 = nil
						end
					else
						v436 = nil
					end
					if v436 and v436 ~= v264 then
						local v437 = v_u_8.Kind(p263.weaponId) or "Herbs"
						local v438 = p263.weaponId
						local v439 = v_u_13.For(v438, v437)
						if v437 ~= "Trap" or v_u_10.IsTeammate(v436) then
							local v440 = v_u_10.Sound
							local v441 = v439.useSound or "Bandage_Wrap"
							local v442 = p263.position
							if typeof(v442) == "Vector3" then
								v436 = p263.position
							else
								if typeof(v436) == "Instance" then
									if v436:IsA("Player") then
										v436 = v436.Character
									elseif not v436:IsA("Model") then
										v436 = nil
									end
								else
									v436 = nil
								end
								if v436 then
									v436 = v436:FindFirstChild("HumanoidRootPart")
								end
								if not (v436 and v436:IsA("BasePart")) then
									v436 = nil
								end
							end
							v440(v441, v436)
							return
						end
					end
				elseif p262 == "Equip" then
					local v443 = p263.attacker
					if typeof(v443) == "Instance" then
						if v443:IsA("Player") then
							v443 = v443.Character
						elseif not v443:IsA("Model") then
							v443 = nil
						end
					else
						v443 = nil
					end
					if v443 and v443 ~= v264 then
						local v444 = v_u_8.Kind(p263.weaponId) or "Sword"
						local v445 = p263.weaponId
						local v446 = v_u_13.For(v445, v444)
						local v447 = v_u_10.Sound
						local v448 = v446.equip or "Equip_Item"
						if typeof(v443) == "Instance" then
							if v443:IsA("Player") then
								v443 = v443.Character
							elseif not v443:IsA("Model") then
								v443 = nil
							end
						else
							v443 = nil
						end
						if v443 then
							v443 = v443:FindFirstChild("HumanoidRootPart")
						end
						if not (v443 and v443:IsA("BasePart")) then
							v443 = nil
						end
						v447(v448, v443, {
							["Volume"] = 0.7
						})
						return
					end
				elseif p262 == "Denied" then
					if p263.reason == "NotEquipped" then
						local v449 = v_u_34
						v449.denied = v449.denied + 1
						local v450 = v_u_29
						if v450 and v450.Parent == v_u_26.char then
							local v451 = v_u_24:GetAttribute("EquipAck")
							local v452
							if (type(v451) ~= "number" and 0 or v451) < v_u_30 then
								v452 = os.clock() - v_u_31 < 4
							else
								v452 = false
							end
							if not v452 then
								v_u_29 = v450
								v_u_30 = v_u_30 + 1
								v_u_33[v450] = v_u_30
								v_u_31 = os.clock()
								local v453 = v_u_34
								v453.requests = v453.requests + 1
								v_u_100()
								local v454 = v_u_29
								if v454 and v_u_25 then
									v_u_32 = os.clock()
									local v455 = {
										["tool"] = v454,
										["seq"] = v_u_30
									}
									local v456 = v455.tool
									if v456 and v_u_33[v456] then
										v455.eq = v_u_33[v456]
									end
									v455.ct = os.clock()
									v_u_25:FireServer("Equip", v455)
								end
							end
						end
						return
					end
					local v457 = v_u_26.handler
					if v457 then
						local v458 = v457.OnDenied
						if type(v458) == "function" then
							v457:OnDenied(p263.reason)
							return
						end
					end
					if p263.reason == "NoCharges" then
						v_u_11.Toast("NONE LEFT THIS ROUND", Color3.fromRGB(255, 120, 90))
					end
				end
			end
		end
	end
end
function v_u_23.Start() -- name: Start
	-- upvalues: (copy) v_u_5, (ref) v_u_25, (copy) v_u_26, (copy) v_u_11, (copy) v_u_14, (copy) v_u_15, (copy) v_u_19, (copy) v_u_18, (copy) v_u_17, (copy) v_u_205, (copy) v_u_231, (copy) v_u_257, (copy) v_u_459, (copy) v_u_16, (copy) v_u_10, (copy) v_u_1, (copy) v_u_24, (copy) v_u_8, (copy) v_u_13, (copy) v_u_9, (copy) v_u_198, (copy) v_u_201, (copy) v_u_3, (ref) v_u_30, (ref) v_u_31, (ref) v_u_116, (copy) v_u_115, (copy) v_u_83, (ref) v_u_32, (ref) v_u_29, (copy) v_u_34, (copy) v_u_33, (copy) v_u_117, (ref) v_u_206, (copy) v_u_151, (copy) v_u_178, (ref) v_u_152, (copy) v_u_100, (copy) v_u_161, (copy) v_u_23
	local v_u_460 = false
	local v_u_461 = nil
	v_u_5.UnreliableEvent("CombatFXU").OnClientEvent:Connect(function(p462, p463)
		-- upvalues: (ref) v_u_460, (ref) v_u_461
		if v_u_460 and v_u_461 then
			v_u_461(p462, p463)
		end
	end)
	v_u_25 = v_u_5.Event("WeaponAction")
	local v464 = v_u_5.Event("HitConfirm")
	local v465 = v_u_5.Event("DamageTaken")
	local v466 = v_u_5.Event("CombatFX")
	local v467 = v_u_26
	local v468 = workspace:GetServerTimeNow() % 100000 * 10
	v467.shotId = math.floor(v468)
	v_u_11.Init()
	v_u_14.Init()
	v_u_15.Init()
	v_u_19.Init()
	v_u_18.Start()
	v_u_17.Start(v_u_205)
	v464.OnClientEvent:Connect(function(p469)
		-- upvalues: (ref) v_u_231
		local v470 = v_u_231
		local v471, v472 = pcall(v470, p469)
		if not v471 then
			warn("[Combat] HitConfirm error:", v472)
		end
	end)
	v465.OnClientEvent:Connect(function(p473)
		-- upvalues: (ref) v_u_257
		local v474 = v_u_257
		local v475, v476 = pcall(v474, p473)
		if not v475 then
			warn("[Combat] DamageTaken error:", v476)
		end
	end)
	local function v486(p477, p478) -- name: fx
		-- upvalues: (ref) v_u_459, (ref) v_u_16
		local v479 = os.clock()
		local v480 = v_u_459
		local v481, v482 = pcall(v480, p477, p478)
		local v483 = v_u_16.AddFx
		local v484 = os.clock() - v479
		local v485
		if type(p477) == "string" then
			v485 = p477
		else
			v485 = nil
		end
		v483(v484, v485)
		if not v481 then
			warn("[Combat] CombatFX error:", p477, v482)
		end
	end
	v466.OnClientEvent:Connect(v486)
	v_u_461 = v486
	v_u_460 = true
	local v487 = v_u_5.Event("AnimRelay")
	v_u_10.SetAnimRelay(v487)
	v487.OnClientEvent:Connect(function(p488, p489, p490, p491, p492, p493)
		-- upvalues: (ref) v_u_26, (ref) v_u_10
		if typeof(p488) == "Instance" and (p488:IsA("Model") and (p488 ~= v_u_26.char and type(p490) == "string")) then
			local v494 = p488:FindFirstChildOfClass("Humanoid")
			if v494 then
				v494 = v494:FindFirstChildOfClass("Animator")
			end
			if v494 and p488:IsDescendantOf(workspace) then
				local v495 = type(p491) ~= "number" and 1 or p491
				if p489 == "Play" then
					v_u_10.PlayAnim(v494, p490, v495, tonumber(p492), (tonumber(p493)))
					return
				elseif p489 == "Hold" then
					v_u_10.PlayHold(v494, p490, v495)
				elseif p489 == "Stop" then
					v_u_10.StopAnim(v494, p490, (tonumber(p492)))
				end
			else
				return
			end
		else
			return
		end
	end)
	local v_u_496 = {}
	task.spawn(function()
		-- upvalues: (ref) v_u_1, (ref) v_u_24, (ref) v_u_8, (ref) v_u_13, (copy) v_u_496, (ref) v_u_10
		while true do
			task.wait(0.5)
			local v497 = workspace.CurrentCamera
			local v498 = not v497 and Vector3.new(0, 0, 0) or v497.CFrame.Position
			for _, v499 in v_u_1:GetPlayers() do
				local v500 = v499.Character
				if v499 == v_u_24 or not v500 then
					continue
				end
				local v501 = v500:FindFirstChild("HumanoidRootPart")
				local v502 = v500:FindFirstChildOfClass("Humanoid")
				local v503
				if v502 then
					v503 = v502:FindFirstChildOfClass("Animator")
				else
					v503 = v502
				end
				if not v501 or (not v501:IsA("BasePart") or (not v503 or (v501.Position - v498).Magnitude > 160)) then
					continue
				end
				local v504
				if v500 then
					v504 = v500:FindFirstChildOfClass("Tool") or nil
				else
					v504 = nil
				end
				if v504 then
					v504 = v504:GetAttribute("WeaponId")
				end
				local v505
				if type(v504) == "string" and v502.Health > 0 then
					local v506 = v_u_8.Kind(v504)
					v505 = v_u_13.For(v504, v506).hold
				else
					v505 = nil
				end
				local v507 = v_u_496[v500]
				if v507 and v507 ~= v505 then
					v_u_10.StopAnim(v503, v507, 0.15)
					v_u_496[v500] = nil
				end
				if not v505 then
					continue
				end
				local v508 = v_u_10.GetTrack(v503, v505)
				if v508 and not v508.IsPlaying then
					v_u_10.PlayAnim(v503, v505, 1, 0.2)
				end
				v_u_496[v500] = v505
			end
			for v509 in v_u_496 do
				if v509.Parent then
					continue
				end
				v_u_496[v509] = nil
			end
		end
	end)
	v_u_9.OnInput("Began", v_u_198)
	v_u_9.OnInput("Ended", v_u_201)
	local v_u_510 = 0
	v_u_3.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_30, (ref) v_u_24, (ref) v_u_510, (ref) v_u_31, (ref) v_u_116, (ref) v_u_115, (ref) v_u_83, (ref) v_u_32, (ref) v_u_29, (ref) v_u_26, (ref) v_u_34, (ref) v_u_25, (ref) v_u_33
		if v_u_30 ~= 0 then
			local v511 = v_u_24:GetAttribute("EquipAck")
			if v_u_30 > (type(v511) ~= "number" and 0 or v511) and v_u_510 ~= v_u_30 then
				local v512 = os.clock()
				if v512 - v_u_31 >= 4 then
					v_u_510 = v_u_30
					if not v_u_116 then
						v_u_116 = true
						task.defer(function()
							-- upvalues: (ref) v_u_116, (ref) v_u_115, (ref) v_u_83
							v_u_116 = false
							v_u_115()
							v_u_83()
						end)
					end
				else
					if v512 - v_u_32 >= 1 and v_u_29 then
						local v513
						if v_u_26.hum == nil or (v_u_26.hum.Health <= 0 or v_u_26.char == nil) then
							v513 = false
						else
							v513 = v_u_26.char.Parent ~= nil
						end
						if v513 then
							local v514 = v_u_34
							v514.resent = v514.resent + 1
							local v515 = v_u_29
							if v515 and v_u_25 then
								v_u_32 = os.clock()
								local v516 = {
									["tool"] = v515,
									["seq"] = v_u_30
								}
								local v517 = v516.tool
								if v517 and v_u_33[v517] then
									v516.eq = v_u_33[v517]
								end
								v516.ct = os.clock()
								v_u_25:FireServer("Equip", v516)
							end
						end
					end
					return
				end
			end
		end
	end)
	for _, v518 in { "EquipAck", "EquipSlot" } do
		v_u_24:GetAttributeChangedSignal(v518):Connect(v_u_117)
	end
	local v_u_519 = false
	v_u_3.RenderStepped:Connect(function(p_u_520)
		-- upvalues: (ref) v_u_206, (ref) v_u_26, (ref) v_u_10, (ref) v_u_519, (ref) v_u_11, (ref) v_u_24, (ref) v_u_17
		if not v_u_206 then
			local v_u_521 = v_u_26.handler
			if v_u_521 then
				local v522
				if v_u_26.hum == nil or (v_u_26.hum.Health <= 0 or v_u_26.char == nil) then
					v522 = false
				else
					v522 = v_u_26.char.Parent ~= nil
				end
				if v522 then
					local v523, v524 = pcall(function()
						-- upvalues: (copy) v_u_521, (copy) p_u_520
						v_u_521:Update(p_u_520)
					end)
					if not v523 then
						warn("[Combat] update error:", v524)
					end
				end
			end
			local v525 = not v_u_10.CanAct()
			if v525 ~= v_u_519 then
				v_u_519 = v525
				v_u_11.SetFrozen(v525)
				local v_u_526 = v525 and (not v_u_206 and v_u_26.handler)
				if v_u_526 then
					local v527 = v_u_526.Interrupt
					if type(v527) == "function" then
						pcall(function()
							-- upvalues: (copy) v_u_526
							v_u_526:Interrupt()
						end)
					end
				end
			end
			local v528 = v_u_24:GetAttribute("CombatMode")
			local v529
			if v528 == nil then
				v529 = v_u_24:GetAttribute("State") == "Match"
			else
				v529 = v528 == true
			end
			local v530 = not v_u_10.IsMouseUnlocked()
			if v530 then
				v530 = v_u_24:GetAttribute("MenuOpen") ~= true
			end
			local v531 = v_u_11.SetVisible
			local v532
			if v530 then
				if v_u_26.hum == nil or (v_u_26.hum.Health <= 0 or v_u_26.char == nil) then
					v532 = false
				else
					v532 = v_u_26.char.Parent ~= nil
				end
				if v532 then
					v532 = v529
				end
			else
				v532 = v530
			end
			v531(v532)
			v_u_17.SetVisible(v530 and v529)
		end
	end)
	v_u_24.CharacterAdded:Connect(v_u_151)
	if v_u_24.Character then
		task.spawn(v_u_151, v_u_24.Character)
	end
	v_u_24:GetAttributeChangedSignal("CombatDrawToken"):Connect(v_u_178)
	local v_u_533 = v_u_24:GetAttribute("CombatDrawToken")
	if type(v_u_533) == "number" and v_u_533 ~= v_u_152 then
		v_u_152 = v_u_533
		task.spawn(function()
			-- upvalues: (ref) v_u_24, (copy) v_u_533, (ref) v_u_26, (ref) v_u_30, (ref) v_u_31, (ref) v_u_29, (ref) v_u_33, (ref) v_u_34, (ref) v_u_100, (ref) v_u_25, (ref) v_u_32, (ref) v_u_161, (ref) v_u_23
			local v534 = os.clock()
			local v535 = (-1 / 0)
			while os.clock() - v534 < 10 do
				if v_u_24:GetAttribute("CombatDrawToken") ~= v_u_533 then
					return
				end
				local v536 = v_u_24:GetAttribute("CombatDrawSlot")
				if v536 == 0 then
					return
				end
				local v537 = v_u_26.char
				local v538 = v_u_26.hum
				if v537 and (v538 and (v538.Health > 0 and (v537 == v_u_24.Character and v537:IsDescendantOf(workspace)))) then
					local v539 = v537:FindFirstChildOfClass("Tool")
					local v540
					if v539 == nil then
						v540 = false
					else
						v540 = v539 ~= nil and v539:IsA("Tool")
						if v540 then
							v540 = type(v539:GetAttribute("WeaponId")) == "string"
						end
						if v540 then
							v540 = v539:GetAttribute("DrawToken") == v_u_533
						end
					end
					if v540 then
						local v541 = v_u_24:GetAttribute("EquipAck")
						local v542
						if (type(v541) ~= "number" and 0 or v541) < v_u_30 then
							v542 = os.clock() - v_u_31 < 4
						else
							v542 = false
						end
						if not v542 then
							local v543 = v_u_24:GetAttribute("EquipSlot")
							if type(v543) == "number" and v543 > 0 then
								return
							end
							if os.clock() - v535 > 0.5 then
								v535 = os.clock()
								v_u_29 = v539
								v_u_30 = v_u_30 + 1
								v_u_33[v539] = v_u_30
								v_u_31 = os.clock()
								local v544 = v_u_34
								v544.requests = v544.requests + 1
								v_u_100()
								local v545 = v_u_29
								if v545 and v_u_25 then
									v_u_32 = os.clock()
									local v546 = {
										["tool"] = v545,
										["seq"] = v_u_30
									}
									local v547 = v546.tool
									if v547 and v_u_33[v547] then
										v546.eq = v_u_33[v547]
									end
									v546.ct = os.clock()
									v_u_25:FireServer("Equip", v546)
								end
							end
						end
					end
					if not v540 then
						local v548 = v_u_161(type(v536) ~= "number" and type(v536) ~= "string" and 1 or v536, v_u_533)
						if v548 then
							v_u_23.Equip(v548)
						end
					end
				end
				task.wait(0.1)
			end
		end)
	end
	for _, v549 in { "CombatMode", "State" } do
		v_u_24:GetAttributeChangedSignal(v549):Connect(function()
			-- upvalues: (ref) v_u_83
			task.defer(v_u_83)
		end)
	end
end
function v_u_23.PlayFX(p550, p551) -- name: PlayFX
	-- upvalues: (copy) v_u_459
	local v552 = v_u_459
	local v553, v554 = pcall(v552, p550, p551)
	if not v553 then
		warn("[Combat] replay FX error:", p550, v554)
	end
end
function v_u_23.SetReplayHud(p555) -- name: SetReplayHud
	-- upvalues: (ref) v_u_206, (copy) v_u_17, (copy) v_u_67, (copy) v_u_26, (copy) v_u_83
	if v_u_206 == p555 then
		return
	else
		v_u_206 = p555
		if p555 then
			v_u_17.SetVisible(false)
		else
			local v556 = v_u_67
			pcall(v556)
			v_u_26.tool = nil
			local v557 = v_u_83
			pcall(v557)
		end
	end
end
function v_u_23.ReplayHitConfirm(p558) -- name: ReplayHitConfirm
	-- upvalues: (copy) v_u_231
	local v559 = v_u_231
	local v560, v561 = pcall(v559, p558)
	if not v560 then
		warn("[Combat] replay HitConfirm error:", v561)
	end
end
function v_u_23.ReplayDamageTaken(p562) -- name: ReplayDamageTaken
	-- upvalues: (copy) v_u_257
	local v563 = v_u_257
	local v564, v565 = pcall(v563, p562)
	if not v564 then
		warn("[Combat] replay DamageTaken error:", v565)
	end
end
function v_u_23.State() -- name: State
	-- upvalues: (ref) v_u_29, (copy) v_u_26, (ref) v_u_30, (copy) v_u_24, (ref) v_u_31, (copy) v_u_34, (copy) v_u_186
	local v566 = v_u_29
	local v567 = {
		["kind"] = v_u_26.kind,
		["tool"] = v_u_26.tool and v_u_26.tool.Name or nil
	}
	local v568
	if v_u_26.hum then
		v568 = v_u_26.hum.WalkSpeed
	else
		v568 = nil
	end
	v567.speed = v568
	v567.shotId = v_u_26.shotId
	v567.wantSlot = not v566 and 0 or v566:GetAttribute("SlotIndex")
	v567.equipSeq = v_u_30
	local v569 = v_u_24:GetAttribute("EquipAck")
	v567.equipAck = type(v569) ~= "number" and 0 or v569
	local v570 = v_u_24:GetAttribute("EquipAck")
	local v571
	if (type(v570) ~= "number" and 0 or v570) < v_u_30 then
		v571 = os.clock() - v_u_31 < 4
	else
		v571 = false
	end
	v567.equipPending = v571
	v567.equipStats = table.clone(v_u_34)
	v567.inputs = v_u_186.n
	v567.lastInput = v_u_186.last
	return v567
end
return v_u_23