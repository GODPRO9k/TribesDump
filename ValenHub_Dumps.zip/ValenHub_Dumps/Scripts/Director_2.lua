local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v5 = v_u_2:WaitForChild("Shared")
local v_u_6 = require(v5:WaitForChild("Sounds"))
local v_u_7 = require(script.Parent:WaitForChild("Layers"))
local v_u_8 = require(script.Parent:WaitForChild("Emitters"))
local v9 = {}
local v_u_10 = v1.LocalPlayer
local v_u_11 = nil
local v_u_12 = {
	["inMatch"] = false,
	["arena"] = nil,
	["map"] = nil,
	["phase"] = "",
	["theme"] = "Lobby",
	["music"] = nil,
	["final"] = false
}
local function v_u_19(p13, p14) -- name: themeFor
	-- upvalues: (copy) v_u_6
	if p14 then
		p14 = p14:GetAttribute("Ambience")
	end
	if type(p14) == "string" and v_u_6.THEMES[p14] then
		return p14
	end
	local v15 = p13:GetAttribute("MapId")
	if type(v15) == "string" and v_u_6.MAP_THEMES[v15] then
		return v_u_6.MAP_THEMES[v15]
	end
	local v16 = p13:GetAttribute("MapName")
	local v17 = string.lower(tostring(v15 or "") .. " " .. tostring(v16 or ""))
	for _, v18 in v_u_6.THEME_KEYWORDS do
		if not string.find(v17, v18[1], 1, true) then
			continue
		end
		return v18[2]
	end
	return "Default"
end
local v_u_20 = 0
local v_u_21 = {}
local v_u_22 = Random.new()
local function v_u_35() -- name: nextLobbyIndex
	-- upvalues: (copy) v_u_21, (copy) v_u_6, (copy) v_u_22, (ref) v_u_20
	if #v_u_21 == 0 then
		for v23 = 1, #v_u_6.LOBBY_PLAYLIST do
			v_u_21[v23] = v23
		end
		for v24 = #v_u_21, 2, -1 do
			local v25 = v_u_22:NextInteger(1, v24)
			local v26 = v_u_21
			local v27 = v_u_21
			local v28 = v_u_21[v25]
			local v29 = v_u_21[v24]
			v26[v24] = v28
			v27[v25] = v29
		end
		if #v_u_21 > 1 and v_u_21[#v_u_21] == v_u_20 then
			local v30 = v_u_21
			local v31 = #v_u_21
			local v32 = v_u_21
			local v33 = v_u_21[1]
			local v34 = v_u_21[#v_u_21]
			v30[v31] = v33
			v32[1] = v34
		end
	end
	return table.remove(v_u_21)
end
local v_u_36 = nil
local v_u_37 = 0
local function v_u_41() -- name: nextLobbyTrack
	-- upvalues: (ref) v_u_20, (copy) v_u_35, (copy) v_u_6, (copy) v_u_7, (ref) v_u_36, (ref) v_u_37
	v_u_20 = v_u_35()
	local v38 = v_u_6.LOBBY_PLAYLIST[v_u_20]
	local v39 = "Music/Lobby" .. v_u_20
	local v40 = v_u_7.Get(v39, v38, 0.5)
	if v40 then
		v40.sound.Looped = false
		v_u_7.Restart(v39, 1)
		v_u_36 = v39
		v_u_37 = os.clock()
	end
end
local v_u_42 = {
	["Loading"] = 0.5,
	["Intro"] = 0.55,
	["PreRound"] = 0.7,
	["Live"] = 1,
	["Overtime"] = 0,
	["RoundEnd"] = 0.6,
	["MatchEnd"] = 0
}
local v_u_43 = {
	["PreRound"] = 0.8,
	["Live"] = 1
}
local function v_u_51() -- name: updateMusic
	-- upvalues: (copy) v_u_12, (ref) v_u_36, (copy) v_u_7, (ref) v_u_37, (copy) v_u_41, (copy) v_u_42, (copy) v_u_43, (ref) v_u_11
	if v_u_12.inMatch then
		v_u_7.FadeAll("Music/Lobby")
		local v44 = v_u_42[v_u_12.phase] or 0.8
		local v45
		if v_u_12.final then
			v45 = v_u_43[v_u_12.phase]
		else
			v45 = nil
		end
		if v45 and not v_u_11.Has("Music/Final_Round") then
			v45 = nil
		end
		local v46 = v_u_12.music and v_u_7.Get("Music/Match", v_u_12.music, 0.6)
		if v46 then
			v46.sound.Looped = true
			v_u_7.SetTarget("Music/Match", v45 and 0 or v44, v_u_12.phase == "Overtime" and 1.5 or (v45 and 1 or 0.6))
		end
		local v47
		if v45 then
			v47 = v_u_7.Get("Music/Final", "Music/Final_Round", 0.9)
		else
			v47 = v_u_7.Find("Music/Final")
		end
		if v47 then
			v47.sound.Looped = true
			if v45 then
				if v47.target == 0 then
					v_u_7.Restart("Music/Final", v45)
				end
				v_u_7.SetTarget("Music/Final", v45, 0.9)
			else
				v_u_7.SetTarget("Music/Final", 0, v_u_12.phase == "Overtime" and 1.5 or 0.6)
			end
		end
		local v48 = v_u_7.Get("Music/Overtime", "Music/Overtime", 2)
		if v48 then
			v48.sound.Looped = false
			if v_u_12.phase == "Overtime" then
				if v48.target == 0 then
					v_u_7.Restart("Music/Overtime", 1)
					return
				end
			else
				v_u_7.SetTarget("Music/Overtime", 0, 0.8)
			end
		end
	else
		local v49 = v_u_36
		if v49 then
			v49 = v_u_7.Find(v_u_36)
		end
		if v49 and (not v49.ended and (os.clock() - v_u_37 > 8 and v49.sound.TimeLength <= 0)) then
			v49.ended = true
		end
		if v49 and not v49.ended then
			if v49.target == 0 then
				v_u_7.Restart(v49.key, 1)
			end
		else
			v_u_41()
		end
		local v50 = {
			[v_u_36 or ""] = true
		}
		v_u_7.FadeAll("Music/", v50)
		if v_u_36 then
			v_u_7.SetTarget(v_u_36, 1, 0.5)
		end
	end
end
local v_u_52 = 0
local function v_u_61() -- name: ringLevel
	-- upvalues: (copy) v_u_12, (copy) v_u_4
	local v53 = v_u_12.arena
	if not v53 or v_u_12.phase ~= "Overtime" then
		return 0
	end
	local v54 = v53:GetAttribute("RingRadius")
	local v55 = v53:GetAttribute("RingCenterX")
	local v56 = v53:GetAttribute("RingCenterZ")
	local v57 = v_u_4.CurrentCamera
	if type(v54) ~= "number" or (v54 <= 0 or (type(v55) ~= "number" or (type(v56) ~= "number" or not v57))) then
		return 0.35
	end
	local v58 = v57.Focus.Position
	local v59 = Vector2.new(v58.X - v55, v58.Z - v56).Magnitude
	if v54 <= v59 then
		return 1
	end
	local v60 = 1 - (v54 - v59) / 45
	return math.clamp(v60, 0.25, 1)
end
local function v_u_81() -- name: updateAmbience
	-- upvalues: (copy) v_u_6, (copy) v_u_12, (copy) v_u_7, (copy) v_u_61, (ref) v_u_52, (copy) v_u_4, (ref) v_u_11
	local v62 = v_u_6.THEMES[v_u_12.theme] or v_u_6.THEMES.Default
	local v63 = v_u_12.phase == "MatchEnd" and 0.6 or 1
	local v64 = {}
	for _, v65 in v62.beds do
		local v66 = "Amb/" .. v65[1]
		local v67 = v_u_7.Get(v66, v65[1], 0.5)
		if not v67 then
			continue
		end
		v67.sound.Looped = true
		v_u_7.SetTarget(v66, v65[2] * v63, 0.5)
		v64[v66] = true
	end
	local v68 = v_u_61()
	local v69 = v68 > 0 and v_u_7.Get("Amb/Ring", "Match/Ring_Fire_Loop", 1.5)
	if v69 then
		v69.sound.Looped = true
		v_u_7.SetTarget("Amb/Ring", v68, 1.5)
		v64["Amb/Ring"] = true
	end
	v_u_7.FadeAll("Amb/", v64)
	local v70 = os.clock()
	if v_u_52 <= v70 then
		local v71 = v62.every or { 8, 16 }
		v_u_52 = v70 + v71[1] + math.random() * (v71[2] - v71[1])
		local v72 = v62.sweeteners
		local v73 = v_u_4.CurrentCamera
		if v72 and (#v72 > 0 and (v73 and v_u_12.phase ~= "MatchEnd")) then
			local v74 = math.random() * 3.141592653589793 * 2
			local v75 = 25 + math.random() * 35
			local v76 = v73.Focus.Position
			local v77 = math.cos(v74) * v75
			local v78 = 6 + math.random() * 14
			local v79 = math.sin(v74) * v75
			local v80 = v76 + Vector3.new(v77, v78, v79)
			v_u_11.Play(v72[math.random(1, #v72)], v80)
		end
	end
end
local v_u_82 = 0
local v_u_83 = 0
local function v_u_93(p84, p85) -- name: onPhase
	-- upvalues: (ref) v_u_83, (copy) v_u_12, (ref) v_u_11, (ref) v_u_82, (copy) v_u_4
	v_u_83 = v_u_83 + 1
	local v_u_86 = v_u_83
	local v87 = v_u_12.arena
	if p84 == "Intro" then
		v_u_11.Play("Match/Intro")
		v_u_11.Duck("Music", 0.35, 3)
		v_u_11.Duck("Ambient", 0.6, 3)
	elseif p84 == "PreRound" then
		v_u_82 = 0
		v_u_11.Play("Match/Spawn")
		if v87 then
			v87 = v87:GetAttribute("PhaseEndsAt")
		end
		if type(v87) == "number" then
			local v88 = v_u_4:GetServerTimeNow()
			for v_u_89 = 3, 1, -1 do
				local v90 = v87 - v_u_89
				if v88 - 0.1 >= v90 then
					continue
				end
				local v91 = task.delay
				local v92 = v90 - v88
				v91(math.max(0, v92), function()
					-- upvalues: (ref) v_u_83, (copy) v_u_86, (ref) v_u_11, (copy) v_u_89
					if v_u_83 == v_u_86 then
						v_u_11.Play("Match/Countdown_" .. v_u_89)
					end
				end)
			end
			return
		end
	else
		if p84 == "Live" and p85 == "PreRound" then
			v_u_11.Play("Match/Fight")
			v_u_11.Duck("Music", 0.35, 2.5)
			v_u_11.Duck("Ambient", 0.6, 2.5)
			return
		end
		if p84 == "Overtime" then
			v_u_11.Play("Match/Overtime_Warning")
			v_u_11.Duck("Music", 0.35, 3)
			v_u_11.Duck("Ambient", 0.6, 3)
		end
	end
end
local function v_u_106(p94, p95) -- name: onMatchEvent
	-- upvalues: (copy) v_u_10, (ref) v_u_11, (ref) v_u_82
	if type(p95) == "table" then
		if p94 == "Elimination" then
			local v96 = "p" .. v_u_10.UserId
			local v97 = v_u_10:GetAttribute("Team")
			local v98 = type(v97) ~= "number" and 0 or v97
			if p95.victimId == v96 then
				v_u_11.Play("Death")
				v_u_11.Duck("Music", 0.35, 3)
				v_u_11.Duck("Ambient", 0.6, 3)
				return
			end
			if p95.killerId == v96 then
				v_u_82 = v_u_82 + 1
				v_u_11.Play("Match/Elimination")
				if v_u_82 == 2 then
					task.delay(0.35, v_u_11.Play, "Kill_Double")
					return
				end
				if v_u_82 >= 3 then
					task.delay(0.35, v_u_11.Play, "Kill_Triple")
					return
				end
			else
				if v98 ~= 0 and p95.victimTeam == v98 then
					v_u_11.Play("Teammate_Down")
					return
				end
				if v98 ~= 0 and p95.killerTeam == v98 then
					v_u_11.Play("Kill_Ally")
					return
				end
			end
		else
			if p94 == "RoundEnd" then
				local v99 = p95.winnerTeam
				local v100 = v_u_10:GetAttribute("Team")
				local v101 = type(v100) ~= "number" and 0 or v100
				if v99 == 0 then
					v_u_11.Play("Match/Round_Draw")
				elseif v99 == v101 then
					v_u_11.Play("Match/Round_Win")
				else
					v_u_11.Play("Match/Round_Lose")
				end
				v_u_11.Duck("Music", 0.35, 4)
				v_u_11.Duck("Ambient", 0.6, 4)
				return
			end
			if p94 == "MatchEnd" then
				local v102 = p95.you
				local v103
				if type(v102) == "table" and p95.you.won == true then
					v103 = true
				elseif p95.winnerTeam == nil then
					v103 = false
				else
					local v104 = p95.winnerTeam
					local v105 = v_u_10:GetAttribute("Team")
					v103 = v104 == (type(v105) ~= "number" and 0 or v105)
				end
				v_u_11.Play(v103 and "Match/Victory" or "Match/Defeat")
				v_u_11.Duck("Ambient", 0.5, 6)
			end
		end
	end
end
local v_u_107 = nil
local v_u_108 = nil
local function v_u_114(p109, p110) -- name: setHeart
	-- upvalues: (ref) v_u_107, (ref) v_u_108, (ref) v_u_11
	local v111
	if p109 > 0 and p109 < 35 then
		v111 = p110 > 0
	else
		v111 = false
	end
	if v111 then
		if not v_u_107 then
			local v112, v113 = v_u_11.Loop("LowHealth_Heartbeat", nil, {
				["fadeIn"] = 0.4
			})
			v_u_107 = v112
			v_u_108 = v113
		end
		if v_u_108 then
			v_u_108.PlaybackSpeed = (1 - p109 / 35) * 0.25 + 1
			return
		end
	elseif v_u_107 then
		v_u_107(0.6)
		v_u_107 = nil
		v_u_108 = nil
	end
end
local function v_u_118(p115) -- name: watchCharacter
	-- upvalues: (copy) v_u_114, (ref) v_u_107, (ref) v_u_108
	local v_u_116 = p115:WaitForChild("Humanoid", 10)
	if v_u_116 and v_u_116:IsA("Humanoid") then
		v_u_114(v_u_116.Health, v_u_116.MaxHealth)
		v_u_116.HealthChanged:Connect(function(p117)
			-- upvalues: (ref) v_u_114, (copy) v_u_116
			v_u_114(p117, v_u_116.MaxHealth)
		end)
		v_u_116.Died:Connect(function()
			-- upvalues: (ref) v_u_107, (ref) v_u_108
			if v_u_107 then
				v_u_107(0.6)
				v_u_107 = nil
				v_u_108 = nil
			end
		end)
	end
end
local v_u_119 = ""
local v_u_120 = nil
local v_u_121 = 0
local function v_u_131() -- name: refreshContext
	-- upvalues: (copy) v_u_10, (copy) v_u_4, (copy) v_u_12, (copy) v_u_19, (ref) v_u_11, (copy) v_u_6, (ref) v_u_120, (copy) v_u_8, (ref) v_u_119, (copy) v_u_93
	local v122
	if v_u_10:GetAttribute("State") == "Match" then
		local v123 = v_u_10:GetAttribute("MatchId")
		v122 = type(v123) == "string" and v123 ~= "" and v_u_4:FindFirstChild("Arenas")
		if v122 then
			v122 = v122:FindFirstChild(v123)
		end
	else
		v122 = nil
	end
	v_u_12.inMatch = v122 ~= nil
	v_u_12.arena = v122
	if v122 then
		local v124 = v122:FindFirstChild("Map")
		v_u_12.map = v124
		local v125 = v122:GetAttribute("Phase")
		v_u_12.phase = type(v125) ~= "string" and "" or v125
		v_u_12.theme = v_u_19(v122, v124)
		local v126 = v_u_12
		local v127 = v_u_12.theme
		local v128
		if v124 then
			v128 = v124:GetAttribute("Music")
		else
			v128 = v124
		end
		local v129 = ((type(v128) ~= "string" or (v128 == "" or not v_u_11.Has(v128))) and true or false) and v_u_6.THEMES[v127]
		if v129 then
			v129 = v129.music
		end
		v126.music = v129
		v_u_12.final = v_u_10:GetAttribute("FinalRound") == true
		if v124 ~= v_u_120 then
			if v_u_120 then
				v_u_8.Unwatch(v_u_120)
			end
			v_u_120 = v124
			if v124 then
				v_u_8.Watch(v124)
			end
		end
	else
		v_u_12.map = nil
		v_u_12.phase = ""
		v_u_12.theme = "Lobby"
		v_u_12.music = nil
		v_u_12.final = false
		if v_u_120 then
			v_u_8.Unwatch(v_u_120)
			v_u_120 = nil
		end
	end
	if v_u_12.phase ~= v_u_119 then
		local v130 = v_u_119
		v_u_119 = v_u_12.phase
		if v_u_12.inMatch then
			v_u_93(v_u_12.phase, v130)
		end
	end
end
function v9.State() -- name: State
	-- upvalues: (copy) v_u_12, (copy) v_u_8, (ref) v_u_121, (ref) v_u_107, (copy) v_u_7
	local v132 = {}
	local v133 = string.format
	local v134 = v_u_12.inMatch
	local v135 = tostring(v134)
	local v136 = v_u_12.phase
	local v137 = v_u_12.theme
	local v138 = v_u_12.music
	local v139 = tostring(v138)
	local v140 = v_u_12.final
	local v141 = v133("inMatch=%s phase=%s theme=%s music=%s final=%s", v135, v136, v137, v139, (tostring(v140)))
	local v142 = "emitters=" .. v_u_8.Count() .. " ticks=" .. v_u_121
	local v143 = v_u_107 ~= nil
	__set_list(v132, 1, {v141, v142, "heart=" .. tostring(v143)})
	for _, v144 in v_u_7.Debug() do
		table.insert(v132, v144)
	end
	return table.concat(v132, "\n")
end
function v9.NowPlaying() -- name: NowPlaying
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	local v145 = {}
	for _, v146 in v_u_7.Audible("Music/") do
		local v147 = v_u_6.Get(v146.name)
		local v148 = {
			["name"] = v146.name
		}
		local v149
		if v147 then
			v149 = v147.src
		else
			v149 = v147
		end
		v148.src = v149
		if v147 then
			local v150 = v147.id
			v147 = tonumber(v150)
		end
		v148.id = v147
		v148.at = v146.sound.TimePosition
		v148.length = v146.sound.TimeLength
		table.insert(v145, v148)
	end
	return v145
end
function v9.Start(p151) -- name: Start
	-- upvalues: (ref) v_u_11, (copy) v_u_7, (copy) v_u_8, (copy) v_u_4, (copy) v_u_2, (copy) v_u_106, (copy) v_u_10, (ref) v_u_107, (ref) v_u_108, (copy) v_u_118, (copy) v_u_3, (copy) v_u_12, (ref) v_u_119, (copy) v_u_131, (ref) v_u_121, (copy) v_u_51, (copy) v_u_81
	v_u_11 = p151
	v_u_7.Init(p151)
	v_u_8.Init(p151)
	local function v153(p152) -- name: maybeLobby
		-- upvalues: (ref) v_u_8
		if p152.Name == "Lobby" then
			v_u_8.Watch(p152)
		end
	end
	v_u_4.ChildAdded:Connect(v153)
	local v154 = v_u_4:FindFirstChild("Lobby")
	if v154 and v154.Name == "Lobby" then
		v_u_8.Watch(v154)
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_2, (ref) v_u_106
		local v155 = v_u_2:WaitForChild("Remotes", 60)
		if v155 then
			v155 = v155:WaitForChild("MatchEvent", 60)
		end
		if v155 and v155:IsA("RemoteEvent") then
			v155.OnClientEvent:Connect(function(p156, p157)
				-- upvalues: (ref) v_u_106
				local v158 = v_u_106
				local v159, v160 = pcall(v158, p156, p157)
				if not v159 then
					warn("[Audio] MatchEvent cue failed:", v160)
				end
			end)
		end
	end)
	v_u_10.CharacterAdded:Connect(function(p161)
		-- upvalues: (ref) v_u_107, (ref) v_u_108, (ref) v_u_118
		if v_u_107 then
			v_u_107(0.6)
			v_u_107 = nil
			v_u_108 = nil
		end
		task.spawn(v_u_118, p161)
	end)
	if v_u_10.Character then
		task.spawn(v_u_118, v_u_10.Character)
	end
	v_u_3.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_12, (ref) v_u_119, (ref) v_u_131
		local v162 = v_u_12.arena
		if v162 then
			local v163 = v162:GetAttribute("Phase")
			if type(v163) == "string" and v163 ~= v_u_119 then
				v_u_131()
			end
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_121, (ref) v_u_131, (ref) v_u_51, (ref) v_u_81, (ref) v_u_8
		while true do
			v_u_121 = v_u_121 + 1
			local function v164()
				-- upvalues: (ref) v_u_131, (ref) v_u_51, (ref) v_u_81, (ref) v_u_8
				v_u_131()
				v_u_51()
				v_u_81()
				v_u_8.Update()
			end
			local v165, v166 = pcall(v164)
			if not v165 then
				warn("[Audio] director update failed:", v166)
			end
			task.wait(0.25)
		end
	end)
end
return v9