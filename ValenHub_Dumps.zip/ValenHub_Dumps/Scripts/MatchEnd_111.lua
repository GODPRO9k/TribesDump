local v_u_1 = game:GetService("Players")
local v_u_2 = require(script.Parent.Parent.RankArt)
return {
	["Init"] = function(p_u_3) -- name: Init
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		local v_u_4 = p_u_3.UI
		local v_u_5 = p_u_3.Theme
		local v_u_6 = p_u_3.State
		local v_u_7 = p_u_3.Portraits
		local v_u_8 = p_u_3.WeaponIcon
		local v_u_9 = v_u_5.Colors
		local v_u_10 = v_u_5.Fonts
		local v_u_11 = v_u_1.LocalPlayer
		local v_u_12 = v_u_4.new("TextButton", {
			["Name"] = "MatchEndDim",
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 1,
			["Visible"] = false,
			["Modal"] = true,
			["Selectable"] = false,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = v_u_9.Void,
			["Parent"] = p_u_3.Canvas.Backdrop
		})
		local v_u_13 = v_u_4.new("Frame", {
			["Name"] = "MatchEnd",
			["Size"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = p_u_3.Canvas.Menus
		})
		local v_u_14 = v_u_4.new("Frame", {
			["Name"] = "Content",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(1200, 744),
			["Parent"] = v_u_13
		})
		local v_u_15 = v_u_4.GetScaleObj(v_u_14, "FitScale")
		local v16 = v_u_4.CanvasSize()
		local v17 = (v16.X - 24) / 1200
		local v18 = (v16.Y - 12) / 744
		v_u_15.Scale = math.min(1, v17, v18)
		v_u_4.ScaleChanged:Connect(function() -- name: applyFit
			-- upvalues: (copy) v_u_4, (copy) v_u_15
			local v19 = v_u_4.CanvasSize()
			local v20 = v_u_15
			local v21 = (v19.X - 24) / 1200
			local v22 = (v19.Y - 12) / 744
			v20.Scale = math.min(1, v21, v22)
		end)
		local v_u_23 = v_u_4.DisplayText({
			["Name"] = "Title",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "VICTORY",
			["TextSize"] = 110,
			["TextColor3"] = nil,
			["StrokeThickness"] = 5,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 0),
			["Size"] = UDim2.fromOffset(900, 110),
			["TextColor3"] = v_u_9.Accent,
			["Parent"] = v_u_14
		})
		local v_u_24 = v_u_4.new("TextLabel", {
			["Name"] = "Score",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 30,
			["TextColor3"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 108),
			["Size"] = UDim2.fromOffset(900, 36),
			["FontFace"] = v_u_10.Title,
			["TextColor3"] = v_u_9.Text,
			["Parent"] = v_u_14
		})
		v_u_4.TextStroke(v_u_9.Void, 2.5, 0.1).Parent = v_u_24
		local v_u_25 = v_u_4.new("Frame", {
			["Name"] = "RoundPips",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 144),
			["Size"] = UDim2.fromOffset(300, 10),
			["Parent"] = v_u_14
		})
		local v_u_26 = v_u_4.Panel({
			["Name"] = "Board",
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundTransparency"] = 0.1,
			["Trim"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(0, 160),
			["Size"] = UDim2.fromOffset(700, 420),
			["Trim"] = v_u_9.Accent,
			["Parent"] = v_u_14
		})
		local v27 = v_u_4.new("Frame", {
			["Name"] = "Header",
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(20, 12),
			["Size"] = UDim2.new(1, -40, 0, 22),
			["Parent"] = v_u_26
		})
		local v28 = {
			{ "K", 400 },
			{ "D", 470 },
			{ "A", 530 },
			{ "DMG", 600 }
		}
		v_u_4.new("TextLabel", {
			["Size"] = nil,
			["Text"] = "FIGHTER",
			["FontFace"] = nil,
			["TextSize"] = 15,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(300, 22),
			["FontFace"] = v_u_10.Heavy,
			["TextColor3"] = v_u_9.TextMuted,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v27
		})
		local function v_u_43(p29, p30, p31) -- name: paintPips
			-- upvalues: (copy) v_u_25, (copy) v_u_9, (copy) v_u_4
			v_u_25:ClearAllChildren()
			for v32 = 1, 2 do
				local v33
				if v32 == 1 then
					v33 = p29
				else
					v33 = p30
				end
				local v34
				if v32 == 1 then
					v34 = v_u_9.Ally
				else
					v34 = v_u_9.Enemy
				end
				for v35 = 1, p31 do
					local v36 = v_u_4.new
					local v37 = "Frame"
					local v38 = {
						["AnchorPoint"] = Vector2.new(0.5, 0)
					}
					local v39 = UDim2.new
					local v40 = 0.5
					local v41
					if v32 == 1 then
						v41 = -30 - (v35 - 1) * 22
					else
						v41 = (v35 - 1) * 22 + 30
					end
					v38.Position = v39(v40, v41, 0, 0)
					v38.Size = UDim2.fromOffset(18, 10)
					local v42
					if v35 <= v33 then
						v42 = v34
					else
						v42 = Color3.fromRGB(52, 56, 68)
					end
					v38.BackgroundColor3 = v42
					__set_list(v38, 1, {(v_u_4.Corner(3))})
					v38.Parent = v_u_25
					v36(v37, v38)
				end
			end
		end
		for _, v44 in v28 do
			v_u_4.new("TextLabel", {
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 15,
				["TextColor3"] = nil,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(v44[2] - 20, 0),
				["Size"] = UDim2.fromOffset(70, 22),
				["Text"] = v44[1],
				["FontFace"] = v_u_10.Heavy,
				["TextColor3"] = v_u_9.TextMuted,
				["Parent"] = v27
			})
		end
		local v_u_45 = {}
		for v46 = 1, 6 do
			local v47 = (v46 - 1) * 60 + 42 + (v46 > 3 and 10 or 0)
			local v48 = v_u_4.new("Frame", {
				["Name"] = "Row" .. v46,
				["Position"] = UDim2.fromOffset(12, v47),
				["Size"] = UDim2.new(1, -24, 0, 54),
				["Parent"] = v_u_26
			})
			local v49 = v_u_4.new("Frame", {
				["Name"] = "Inner",
				["Size"] = UDim2.fromScale(1, 1),
				["BackgroundColor3"] = v_u_9.Void,
				["BackgroundTransparency"] = 0.45,
				v_u_4.Corner(10),
				["Parent"] = v48
			})
			local v50 = v_u_4.Stroke(v_u_9.Accent, 2.5, 0)
			v50.Parent = v49
			local v51 = v_u_4.new("ImageLabel", {
				["Name"] = "Img",
				["Position"] = UDim2.fromOffset(6, 5),
				["Size"] = UDim2.fromOffset(44, 44),
				["BackgroundColor3"] = v_u_9.Raised,
				["ScaleType"] = Enum.ScaleType.Crop,
				v_u_4.Corner(v_u_5.Radius.Pill),
				["Parent"] = v49
			})
			local v52 = v_u_4.new("TextLabel", {
				["Name"] = "Name",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 22,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(60, 0),
				["Size"] = UDim2.fromOffset(250, 54),
				["FontFace"] = v_u_10.Heavy,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v49
			})
			local v53 = v_u_4.Image(v_u_4.Assets.Icons.Star, {
				["Name"] = "Mvp",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ImageColor3"] = nil,
				["Visible"] = false,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 318, 0.5, 0),
				["Size"] = UDim2.fromOffset(26, 26),
				["ImageColor3"] = v_u_9.Gold,
				["Parent"] = v49
			})
			local v54 = {}
			for v55, v56 in v28 do
				v54[v55] = v_u_4.new("TextLabel", {
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "0",
					["FontFace"] = nil,
					["TextSize"] = 24,
					["TextColor3"] = nil,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(v56[2] - 32, 0),
					["Size"] = UDim2.fromOffset(70, 54),
					["FontFace"] = v_u_10.Display,
					["TextColor3"] = v_u_9.Text,
					["Parent"] = v49
				})
			end
			v_u_45[v46] = {
				["frame"] = v48,
				["inner"] = v49,
				["stroke"] = v50,
				["img"] = v51,
				["name"] = v52,
				["star"] = v53,
				["cells"] = v54,
				["rankPip"] = v_u_2.Emblem(1, 24, {
					["Position"] = nil,
					["ZIndex"] = 3,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(32, 30),
					["Parent"] = v49
				})
			}
		end
		local v57 = v_u_4.new("Frame", {
			["Name"] = "Right",
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(720, 160),
			["Size"] = UDim2.fromOffset(480, 420),
			["Parent"] = v_u_14
		})
		local v_u_58 = v_u_4.Panel({
			["Name"] = "Mvp",
			["Size"] = nil,
			["BackgroundTransparency"] = 0.1,
			["StrokeColor"] = nil,
			["StrokeTransparency"] = 0.4,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(480, 118),
			["StrokeColor"] = v_u_9.Gold,
			["Parent"] = v57
		})
		local v_u_59 = v_u_4.new("ImageLabel", {
			["Name"] = "Img",
			["Position"] = UDim2.fromOffset(12, 12),
			["Size"] = UDim2.fromOffset(94, 94),
			["BackgroundColor3"] = v_u_9.Raised,
			["ScaleType"] = Enum.ScaleType.Crop,
			v_u_4.Corner(v_u_5.Radius.Pill),
			v_u_4.Stroke(v_u_9.Gold, 3, 0.1),
			["Parent"] = v_u_58
		})
		v_u_4.Image(v_u_4.Assets.Icons.Star, {
			["Position"] = UDim2.fromOffset(122, 12),
			["Size"] = UDim2.fromOffset(28, 28),
			["ImageColor3"] = v_u_9.Gold,
			["Parent"] = v_u_58
		})
		v_u_4.DisplayText({
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "MVP",
			["TextSize"] = 30,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["StrokeThickness"] = 2,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(156, 10),
			["Size"] = UDim2.fromOffset(200, 32),
			["TextColor3"] = v_u_9.Gold,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v_u_58
		})
		local v_u_60 = v_u_4.new("TextLabel", {
			["Name"] = "Name",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 28,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(122, 44),
			["Size"] = UDim2.fromOffset(340, 32),
			["FontFace"] = v_u_10.Heavy,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v_u_58
		})
		v_u_4.TextStroke(v_u_9.Void, 1.5, 0.3).Parent = v_u_60
		local v_u_61 = v_u_4.new("TextLabel", {
			["Name"] = "Stats",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 18,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(122, 78),
			["Size"] = UDim2.fromOffset(340, 24),
			["FontFace"] = v_u_10.Bold,
			["TextColor3"] = v_u_9.TextDim,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v_u_58
		})
		local v_u_62 = v_u_4.Panel({
			["Name"] = "Rewards",
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundTransparency"] = 0.1,
			["Trim"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(0, 130),
			["Size"] = UDim2.fromOffset(480, 290),
			["Trim"] = v_u_9.Accent,
			["Parent"] = v57
		})
		local v_u_63, v_u_64 = v_u_4.LevelBadge(1, 78, {
			["Position"] = UDim2.fromOffset(12, 14),
			["Parent"] = v_u_62
		})
		local v_u_65 = v_u_4.DisplayText({
			["Name"] = "LevelWord",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "LEVEL 1",
			["TextSize"] = 28,
			["TextXAlignment"] = nil,
			["StrokeThickness"] = 2,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(100, 14),
			["Size"] = UDim2.fromOffset(260, 32),
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v_u_62
		})
		local v_u_66 = v_u_4.DisplayText({
			["Name"] = "XpGain",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "+0 XP",
			["TextSize"] = 26,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["StrokeThickness"] = 2,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, -16, 0, 16),
			["Size"] = UDim2.fromOffset(160, 30),
			["TextColor3"] = v_u_9.Xp,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["Parent"] = v_u_62
		})
		local v_u_67 = v_u_4.Bar({
			["Name"] = "XpBar",
			["Position"] = nil,
			["Size"] = nil,
			["Color"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(100, 54),
			["Size"] = UDim2.new(1, -116, 0, 18),
			["Color"] = v_u_9.Xp,
			["Parent"] = v_u_62
		})
		local v_u_68 = v_u_4.new("TextLabel", {
			["Name"] = "XpText",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 15,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(100, 74),
			["Size"] = UDim2.new(1, -116, 0, 18),
			["FontFace"] = v_u_10.Bold,
			["TextColor3"] = v_u_9.TextDim,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v_u_62
		})
		local v_u_69 = v_u_4.DisplayText({
			["Name"] = "LevelUp",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "LEVEL UP!",
			["TextSize"] = 44,
			["TextColor3"] = nil,
			["StrokeThickness"] = 3,
			["Visible"] = false,
			["ZIndex"] = 5,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(240, 62),
			["Size"] = UDim2.fromOffset(300, 50),
			["TextColor3"] = v_u_9.Accent,
			["Parent"] = v_u_62
		})
		local v_u_70, v71 = v_u_4.ShellAmount(0, {
			["TextSize"] = 34,
			["Position"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(16, 110),
			["Parent"] = v_u_62
		})
		v_u_70.Visible = v_u_5.ShowCurrency
		local v_u_73 = v_u_4.CountUp(v71, function(p72)
			-- upvalues: (copy) v_u_4
			return "+" .. v_u_4.FormatNumber(p72)
		end, 1.1)
		local v74 = v_u_4.new
		local v75 = "Frame"
		local v76 = {
			["Name"] = "Streak",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(v_u_5.ShowCurrency and 1 or 0, 0)
		}
		local v77
		if v_u_5.ShowCurrency then
			v77 = UDim2.new(1, -16, 0, 108)
		else
			v77 = UDim2.fromOffset(16, 108)
		end
		v76.Position = v77
		v76.Size = UDim2.fromOffset(220, 44)
		v76.Parent = v_u_62
		local v_u_78 = v74(v75, v76)
		v_u_4.Image(v_u_4.Assets.Icons.Fire, {
			["Size"] = UDim2.fromOffset(40, 40),
			["Parent"] = v_u_78
		})
		local v_u_79 = v_u_4.DisplayText({
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "3 WIN STREAK",
			["TextSize"] = 26,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["StrokeThickness"] = 2,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(44, 4),
			["Size"] = UDim2.new(1, -44, 0, 36),
			["TextColor3"] = v_u_9.Warning,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v_u_78
		})
		local v_u_80 = v_u_4.new("TextLabel", {
			["Name"] = "Glory",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 16,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextWrapped"] = true,
			["Visible"] = false,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, -16, 0, 108),
			["Size"] = UDim2.fromOffset(220, 40),
			["FontFace"] = v_u_10.Bold,
			["TextColor3"] = Color3.fromRGB(255, 196, 80),
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["Parent"] = v_u_62
		})
		local v_u_81 = v_u_4.new("Frame", {
			["Name"] = "Lines",
			["Position"] = UDim2.fromOffset(16, 162),
			["Size"] = UDim2.new(1, -32, 0, 104),
			v_u_4.new("UIGridLayout", {
				["Name"] = "Grid",
				["CellSize"] = nil,
				["CellPadding"] = nil,
				["SortOrder"] = nil,
				["CellSize"] = UDim2.new(0.5, -6, 0, 22),
				["CellPadding"] = UDim2.fromOffset(12, 3),
				["SortOrder"] = Enum.SortOrder.LayoutOrder
			}),
			["Parent"] = v_u_62
		})
		local v_u_82 = require(script.Parent.Parent.RankArt)
		local v_u_83 = v_u_82.Ranks
		local v_u_84 = v_u_4.new("Frame", {
			["Name"] = "Trophies",
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(16, 102),
			["Size"] = UDim2.new(1, -32, 0, 44),
			["Parent"] = v_u_62
		})
		local v_u_85 = v_u_82.Emblem(1, 44, {
			["Parent"] = v_u_84
		})
		local v_u_86 = v_u_4.new("TextLabel", {
			["Name"] = "Rank",
			["Position"] = UDim2.fromOffset(54, 0),
			["Size"] = UDim2.fromOffset(230, 22),
			["Text"] = "",
			["FontFace"] = v_u_10.Display,
			["TextSize"] = 20,
			["TextColor3"] = v_u_9.Text,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			v_u_4.TextStroke(v_u_9.Void, 1.5, 0.4),
			["Parent"] = v_u_84
		})
		local v_u_87 = v_u_4.Bar({
			["Name"] = "Bar",
			["Position"] = nil,
			["Size"] = nil,
			["Color"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(54, 24),
			["Size"] = UDim2.fromOffset(220, 9),
			["Color"] = v_u_9.Gold,
			["Parent"] = v_u_84
		})
		local v_u_88 = v_u_4.new("TextLabel", {
			["Name"] = "Next",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 12,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(54, 33),
			["Size"] = UDim2.fromOffset(220, 14),
			["FontFace"] = v_u_10.SemiBold,
			["TextColor3"] = v_u_9.TextMuted,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v_u_84
		})
		local v_u_89 = v_u_4.DisplayText({
			["Name"] = "Delta",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "+0",
			["TextSize"] = 26,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["StrokeThickness"] = 2,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, 0, 0, -3),
			["Size"] = UDim2.fromOffset(120, 28),
			["TextColor3"] = v_u_9.Success,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["Parent"] = v_u_84
		})
		local v90 = v_u_4.new("Frame", {
			["Name"] = "Count",
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, 0, 0, 24),
			["Size"] = UDim2.fromOffset(150, 20),
			v_u_4.List(Enum.FillDirection.Horizontal, 4, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
			["Parent"] = v_u_84
		})
		v_u_82.Trophy(20, {
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Parent"] = v90
		})
		local v91 = v_u_4.new("TextLabel", {
			["Name"] = "N",
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["Text"] = "0",
			["FontFace"] = nil,
			["TextSize"] = 20,
			["TextColor3"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromOffset(0, 22),
			["FontFace"] = v_u_10.Display,
			["TextColor3"] = v_u_9.Text,
			["Parent"] = v90
		})
		local v_u_93 = v_u_4.CountUp(v91, function(p92)
			-- upvalues: (copy) v_u_4
			return v_u_4.FormatNumber(p92)
		end, 1)
		local function v_u_100(p94, p95) -- name: paintRank
			-- upvalues: (copy) v_u_83, (copy) v_u_82, (copy) v_u_85, (copy) v_u_86, (copy) v_u_87, (copy) v_u_88, (copy) v_u_4
			local v96, v97, v98 = v_u_83.Progress(p94)
			local v99 = v_u_82.Color(v96)
			v_u_82.SetEmblem(v_u_85, v96)
			v_u_86.Text = string.upper(v_u_83.Get(v96).name)
			v_u_86.TextColor3 = v99
			v_u_87.SetColor(v99)
			v_u_87.Set(not v98 and 1 or v97 / v98, p95, TweenInfo.new(0.9, Enum.EasingStyle.Quad))
			v_u_88.Text = not v98 and "TOP RANK" or string.format("%s / %s to %s", v_u_4.FormatNumber(v97), v_u_4.FormatNumber(v98), string.upper(v_u_83.Get(v96 + 1).name))
		end
		local v_u_101 = p_u_3.Economy
		local v_u_102 = v_u_4.new("Frame", {
			["Name"] = "Economy",
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(0, 592),
			["Size"] = UDim2.fromOffset(1200, 58),
			["Parent"] = v_u_14
		})
		local v_u_103 = v_u_4.new("TextButton", {
			["Name"] = "Drop",
			["Size"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(700, 58),
			["Parent"] = v_u_102
		})
		v_u_4.Panel({
			["Name"] = "Bg",
			["Size"] = nil,
			["BackgroundTransparency"] = 0.1,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v_u_103
		})
		local v_u_104 = v_u_4.GetScaleObj(v_u_103, "HoverScale")
		local v_u_105 = v_u_4.Image(v_u_4.Assets.Fx.Gem, {
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 12, 0.5, 0),
			["Size"] = UDim2.fromOffset(34, 34),
			["ImageColor3"] = v_u_9.Accent,
			["Parent"] = v_u_103
		})
		local v_u_106 = v_u_4.new("TextLabel", {
			["Name"] = "Title",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "DROP",
			["FontFace"] = nil,
			["TextSize"] = 18,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(54, 8),
			["Size"] = UDim2.fromOffset(170, 22),
			["FontFace"] = v_u_10.Heavy,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v_u_103
		})
		local v_u_107 = v_u_4.new("TextLabel", {
			["Name"] = "Sub",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 14,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(54, 30),
			["Size"] = UDim2.fromOffset(170, 18),
			["FontFace"] = v_u_10.Bold,
			["TextColor3"] = v_u_9.TextDim,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v_u_103
		})
		local v_u_108 = v_u_4.new("Frame", {
			["Name"] = "Cards",
			["Position"] = UDim2.fromOffset(222, 5),
			["Size"] = UDim2.new(1, -230, 0, 48),
			v_u_4.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
			["Parent"] = v_u_103
		})
		local v_u_109 = {}
		local function v_u_116(p110) -- name: dTile
			-- upvalues: (copy) v_u_109, (copy) v_u_4, (copy) v_u_108, (copy) v_u_9, (copy) v_u_10
			local v111 = v_u_109[p110]
			if v111 then
				return v111
			end
			local v112 = v_u_4.new("Frame", {
				["Name"] = "Card" .. p110,
				["Size"] = UDim2.fromOffset(92, 48),
				["LayoutOrder"] = p110,
				["Parent"] = v_u_108
			})
			local v113 = v_u_4.new("Frame", {
				["Name"] = "Tile",
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 0, 0.5, 0),
				["Size"] = UDim2.fromOffset(44, 44),
				["BackgroundColor3"] = Color3.new(1, 1, 1),
				v_u_4.Corner(9),
				["Parent"] = v112
			})
			local v114 = v_u_4.Gradient(v_u_9.Accent, v_u_9.Panel, 115)
			v114.Parent = v113
			local v115 = {
				["frame"] = v112,
				["grad"] = v114,
				["icon"] = v_u_4.new("Frame", {
					["Name"] = "Icon",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 2,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Size"] = UDim2.fromScale(0.94, 0.94),
					["Parent"] = v113
				}),
				["count"] = v_u_4.new("TextLabel", {
					["Name"] = "N",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "x0",
					["FontFace"] = nil,
					["TextSize"] = 20,
					["TextXAlignment"] = nil,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(49, 2),
					["Size"] = UDim2.fromOffset(44, 24),
					["FontFace"] = v_u_10.Display,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Parent"] = v112
				}),
				["tag"] = v_u_4.new("TextLabel", {
					["Name"] = "Tag",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["FontFace"] = nil,
					["TextSize"] = 12,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(49, 26),
					["Size"] = UDim2.fromOffset(50, 16),
					["FontFace"] = v_u_10.Heavy,
					["TextColor3"] = v_u_9.TextDim,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Parent"] = v112
				})
			}
			v_u_109[p110] = v115
			return v115
		end
		local v_u_117 = nil
		local function v_u_133(p118) -- name: paintDrop
			-- upvalues: (ref) v_u_117, (copy) p_u_3, (copy) v_u_103, (copy) v_u_9, (copy) v_u_105, (copy) v_u_106, (copy) v_u_107, (copy) v_u_109, (copy) v_u_8, (copy) v_u_116, (copy) v_u_101, (copy) v_u_5
			v_u_117 = p118
			local v119 = p_u_3.DropReveal
			local v120
			if v119 and v119.Normalize then
				v120 = v119.Normalize(p118)
			else
				v120 = nil
			end
			local v121 = v_u_103
			local v122
			if v120 == nil then
				v122 = false
			else
				v122 = #v120.stacks > 0
			end
			v121.Visible = v122
			if v120 then
				local v123
				if v120.kind == "golden" then
					v123 = v_u_9.Gold
				elseif v120.kind == "victory" then
					v123 = v_u_9.Accent
				else
					v123 = Color3.fromRGB(150, 180, 226)
				end
				v_u_105.ImageColor3 = v123
				v_u_106.Text = v120.kind == "golden" and "GOLDEN DROP" or (v120.kind == "victory" and "VICTORY DROP" or "DROP")
				v_u_106.TextColor3 = v123:Lerp(Color3.new(1, 1, 1), 0.35)
				local v124 = 0
				for _, v125 in v120.stacks do
					v124 = v124 + v125.shards
				end
				v_u_107.Text = string.format("+%d shards", v124)
				local v126 = #v120.stacks
				local v127 = #v_u_109
				for v128 = 1, math.max(v126, v127) do
					local v129 = v120.stacks[v128]
					if v128 > 5 or not v129 then
						local v130 = v_u_109[v128]
						if not v130 then
							continue
						end
						v130.frame.Visible = false
						v_u_8.Set(v130.icon, nil)
					else
						local v131 = v_u_116(v128)
						local v132
						if v_u_101 and v_u_101.CategoryColor then
							v132 = v_u_101.CategoryColor(v129.item)
						else
							v132 = v_u_9.Accent
						end
						v131.frame.Visible = true
						v131.grad.Color = ColorSequence.new(v132:Lerp(v_u_9.Panel, 0.5), v_u_9.PanelHi:Lerp(v_u_9.Panel, 0.6))
						v_u_8.Set(v131.icon, v129.item, {
							["outline"] = false,
							["glow"] = false
						})
						v131.count.Text = "x" .. v129.shards
						if v129.unlocked then
							v131.tag.Text = "NEW"
							v131.tag.TextColor3 = v_u_9.Gold
						elseif v129.ready then
							v131.tag.Text = "UPGRADE"
							v131.tag.TextColor3 = v_u_5.Lighten(v_u_9.Success, 0.15)
						elseif v129.levelBefore <= 0 then
							v131.tag.Text = string.format("%d/%d", v129.total, v129.need or 0)
							v131.tag.TextColor3 = v_u_9.TextMuted
						else
							v131.tag.Text = "LV " .. v129.levelBefore
							v131.tag.TextColor3 = v_u_9.TextDim
						end
					end
				end
			end
		end
		v_u_103.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_4, (copy) v_u_104, (copy) v_u_5
			if not v_u_4.Touch then
				v_u_4.Tween(v_u_104, v_u_5.Tween.PopSmall, {
					["Scale"] = 1.02
				})
			end
		end)
		v_u_103.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_4, (copy) v_u_104, (copy) v_u_5
			v_u_4.Tween(v_u_104, v_u_5.Tween.Fast, {
				["Scale"] = 1
			})
		end)
		v_u_103.Activated:Connect(function()
			-- upvalues: (copy) p_u_3, (ref) v_u_117
			local v134 = p_u_3.DropReveal
			if v_u_117 and (v134 and not v134.IsPlaying()) then
				p_u_3.Sounds.Play("Click")
				v134.ShowSummary(v_u_117, {
					["source"] = "match"
				})
			end
		end)
		local v_u_135 = v_u_4.Panel({
			["Name"] = "StreakLost",
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundTransparency"] = 0.1,
			["StrokeColor"] = nil,
			["StrokeTransparency"] = 0.6,
			["Visible"] = false,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(720, 0),
			["Size"] = UDim2.fromOffset(480, 58),
			["StrokeColor"] = Color3.fromRGB(255, 150, 60),
			["Parent"] = v_u_102
		})
		v_u_4.Image(v_u_4.Assets.Icons.Fire, {
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 12, 0.5, 0),
			["Size"] = UDim2.fromOffset(34, 34),
			["Parent"] = v_u_135
		})
		local v_u_136 = v_u_4.new("TextLabel", {
			["Name"] = "Text",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["RichText"] = true,
			["FontFace"] = nil,
			["TextSize"] = 17,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextWrapped"] = true,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(52, 0),
			["Size"] = UDim2.new(1, -250, 1, 0),
			["FontFace"] = v_u_10.Heavy,
			["TextColor3"] = v_u_9.Text,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v_u_135
		})
		local v_u_137 = v_u_4.Button({
			["Name"] = "Restore",
			["Text"] = "RESTORE",
			["TextSize"] = 17,
			["Style"] = "Success",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -8, 0.5, 0),
			["Size"] = UDim2.fromOffset(186, 44),
			["Parent"] = v_u_135
		})
		local v_u_138 = nil
		local v_u_139 = nil
		local function v_u_141() -- name: paintRestore
			-- upvalues: (copy) v_u_135, (ref) v_u_138, (ref) v_u_139, (copy) v_u_136, (copy) v_u_137, (copy) v_u_101
			if v_u_135.Visible and v_u_138 then
				if v_u_139 then
					v_u_136.Text = string.format("<font color=\"#FFC478\">%d</font> WIN STREAK RESTORED", v_u_139)
					v_u_137:SetStyle("Dark")
					v_u_137:SetEnabled(false)
					v_u_137:SetText("\226\156\147 RESTORED")
				else
					local v140 = v_u_101.Pending(v_u_138.key)
					v_u_136.Text = string.format("<font color=\"#FFC478\">%d</font> WIN STREAK LOST<br/><font size=\"13\" color=\"#8C93A5\">Bring it back: the offer lasts 24 hours</font>", v_u_138.lost)
					v_u_137:SetStyle("Success")
					v_u_137:SetEnabled(not v140)
					v_u_137:SetText(v140 and "RESTORING\226\128\166" or "RESTORE  " .. v_u_101.PriceText(v_u_138.key))
				end
			else
				return
			end
		end
		local v_u_142 = v_u_4.new("Frame", {
			["Name"] = "Buttons",
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, 0),
			["Size"] = UDim2.fromOffset(800, 84),
			v_u_4.List(Enum.FillDirection.Horizontal, 20, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
			["Parent"] = v_u_14
		})
		local v_u_143 = v_u_4.Button({
			["Name"] = "PlayAgain",
			["Text"] = "PLAY AGAIN",
			["TextSize"] = 32,
			["Style"] = "Primary",
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(320, 80),
			["Parent"] = v_u_142
		})
		local v_u_144 = v_u_4.Button({
			["Name"] = "CancelAgain",
			["Text"] = "CANCEL",
			["TextSize"] = 24,
			["Style"] = "Dark",
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Visible"] = false,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(160, 80),
			["Parent"] = v_u_142
		})
		local v_u_145 = v_u_4.Button({
			["Name"] = "Lobby",
			["Text"] = "LOBBY",
			["TextSize"] = 28,
			["Style"] = "Dark",
			["Size"] = nil,
			["LayoutOrder"] = 3,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(220, 80),
			["Parent"] = v_u_142
		})
		local v_u_146 = v_u_138
		local v_u_147 = v_u_139
		local v_u_148 = v_u_117
		local v_u_149 = false
		local v_u_150 = false
		local v_u_151 = nil
		local function v_u_153() -- name: padDefault
			-- upvalues: (copy) v_u_143, (copy) v_u_144, (copy) v_u_145
			for _, v152 in { v_u_143, v_u_144, v_u_145 } do
				if not v152.Instance.Visible then
					continue
				end
				return v152.Instance
			end
			return nil
		end
		for _, v154 in { v_u_143, v_u_144, v_u_145 } do
			v154.Instance:GetPropertyChangedSignal("Visible"):Connect(function()
				-- upvalues: (ref) v_u_149, (copy) p_u_3
				if v_u_149 then
					task.defer(p_u_3.MenuManager.Reselect)
				end
			end)
		end
		local v_u_155 = 0
		local v_u_156 = 0
		local v_u_157 = false
		local function v_u_166() -- name: paintSearch
			-- upvalues: (ref) v_u_149, (ref) v_u_156, (copy) v_u_6, (ref) v_u_157, (ref) v_u_155, (copy) v_u_144, (copy) v_u_143, (copy) v_u_11
			if v_u_149 then
				v_u_156 = v_u_156 + 1
				local v_u_158 = v_u_156
				if v_u_6.Get("Queued") == true then
					if not v_u_157 then
						v_u_155 = v_u_155 + 1
						v_u_157 = true
					end
					local v159 = v_u_6.Get("QueueFound") == true
					v_u_144.Instance.Visible = not v159
					if v159 then
						v_u_143:SetText("MATCH FOUND")
					else
						task.spawn(function()
							-- upvalues: (copy) v_u_158, (ref) v_u_156, (ref) v_u_149, (ref) v_u_6, (ref) v_u_143
							local v160 = -1
							while v_u_158 == v_u_156 and v_u_149 and v_u_6.Get("Queued") == true do
								local v161 = v_u_6.Get
								local v162 = tonumber(v161("QueuedAt")) or v_u_6.Now()
								local v163 = v_u_6.Now() - v162
								local v164 = math.floor(v163)
								local v165 = math.max(0, v164)
								if v165 == v160 then
									v165 = v160
								else
									v_u_143:SetText(string.format("SEARCHING  %d:%02d", v165 // 60, v165 % 60))
								end
								task.wait(0.2)
								v160 = v165
							end
						end)
					end
				else
					if v_u_157 then
						task.delay(2, function()
							-- upvalues: (copy) v_u_158, (ref) v_u_156, (ref) v_u_149, (ref) v_u_157, (ref) v_u_6, (ref) v_u_11, (ref) v_u_143, (ref) v_u_144
							if v_u_158 == v_u_156 and (v_u_149 and v_u_157) and (v_u_6.Get("Queued") ~= true and v_u_11:GetAttribute("Teleporting") ~= true) then
								v_u_157 = false
								v_u_143:SetText("PLAY AGAIN")
								v_u_144.Instance.Visible = false
							end
						end)
					end
					return
				end
			else
				return
			end
		end
		v_u_6.AttrChanged:Connect(function(p167)
			-- upvalues: (copy) v_u_166
			if p167 == "Queued" or p167 == "QueueFound" then
				v_u_166()
			end
		end)
		local function v_u_169() -- name: playAgain
			-- upvalues: (ref) v_u_150, (ref) v_u_157, (ref) v_u_155, (copy) v_u_144, (copy) v_u_143, (copy) p_u_3, (ref) v_u_149, (copy) v_u_6, (copy) v_u_11, (ref) v_u_151
			if v_u_150 or v_u_157 then
				return
			else
				v_u_155 = v_u_155 + 1
				v_u_144.Instance.Visible = v_u_157
				v_u_150 = true
				v_u_143:SetText("JOINING\226\128\166")
				local v168 = p_u_3.QueueAction("PlayAgain")
				v_u_150 = false
				if v168 then
					v_u_157 = true
					v_u_144.Instance.Visible = true
					task.delay(10, function()
						-- upvalues: (ref) v_u_157, (ref) v_u_149, (ref) v_u_6, (ref) v_u_11, (ref) v_u_151
						if v_u_157 and v_u_149 and (v_u_6.Get("Queued") ~= true and v_u_11:GetAttribute("Teleporting") ~= true) then
							v_u_157 = false
							v_u_151()
						end
					end)
				else
					v_u_143:SetText("PLAY AGAIN")
				end
			end
		end
		local function v_u_175(p_u_170) -- name: startCountdown
			-- upvalues: (ref) v_u_155, (copy) v_u_144, (ref) v_u_157, (copy) v_u_6, (copy) v_u_169, (copy) v_u_143, (copy) v_u_4
			v_u_155 = v_u_155 + 1
			v_u_144.Instance.Visible = v_u_157
			if type(p_u_170) ~= "number" then
				p_u_170 = v_u_6.Now() + 12
			end
			local v_u_171 = v_u_155
			v_u_144.Instance.Visible = true
			task.spawn(function()
				-- upvalues: (copy) v_u_171, (ref) v_u_155, (ref) p_u_170, (ref) v_u_6, (ref) v_u_169, (ref) v_u_143, (ref) v_u_4
				local v172 = -1
				while v_u_171 == v_u_155 do
					local v173 = p_u_170 - v_u_6.Now()
					local v174 = math.ceil(v173)
					if v174 <= 0 then
						v_u_169()
						return
					end
					if v174 == v172 then
						v174 = v172
					else
						v_u_143:SetText("PLAY AGAIN  " .. v174)
						if v174 <= 3 then
							v_u_4.Bump(v_u_143.Label, 0.12)
						end
					end
					task.wait(0.1)
					v172 = v174
				end
			end)
		end
		v_u_143.Activated:Connect(v_u_169)
		local function v_u_178() -- name: onCancel
			-- upvalues: (ref) v_u_150, (ref) v_u_157, (copy) p_u_3, (copy) v_u_143, (copy) v_u_144, (ref) v_u_155
			if v_u_150 then
				return
			elseif v_u_157 then
				v_u_150 = true
				local v176, v177 = p_u_3.QueueAction("CancelPlayAgain")
				v_u_150 = false
				if v176 then
					v_u_157 = false
					v_u_143:SetText("PLAY AGAIN")
					v_u_144.Instance.Visible = false
				else
					p_u_3.Toast(type(v177) ~= "string" and "Too late: the next match is starting" or v177, "info")
				end
			else
				v_u_155 = v_u_155 + 1
				v_u_144.Instance.Visible = v_u_157
				v_u_143:SetText("PLAY AGAIN")
				v_u_144.Instance.Visible = false
				return
			end
		end
		v_u_144.Activated:Connect(v_u_178)
		v_u_137.Activated:Connect(function()
			-- upvalues: (ref) v_u_146, (ref) v_u_147, (ref) v_u_155, (copy) v_u_144, (ref) v_u_157, (copy) v_u_143, (copy) v_u_101, (copy) v_u_141
			if v_u_146 and not v_u_147 then
				v_u_155 = v_u_155 + 1
				v_u_144.Instance.Visible = v_u_157
				v_u_143:SetText("PLAY AGAIN")
				v_u_101.Buy(v_u_146.key)
				v_u_141()
			end
		end)
		v_u_101.Changed:Connect(v_u_141)
		v_u_101.Event:Connect(function(p179, p180)
			-- upvalues: (ref) v_u_146, (ref) v_u_147, (copy) v_u_141, (copy) v_u_4, (copy) v_u_137
			if p179 == "StreakRestored" and v_u_146 then
				local v181 = p180.streak
				v_u_147 = tonumber(v181) or v_u_146.lost
				v_u_141()
				v_u_4.Pop(v_u_137.Instance, 1.1)
			end
		end)
		v_u_145.Activated:Connect(function()
			-- upvalues: (ref) v_u_150, (ref) v_u_155, (copy) v_u_144, (ref) v_u_157, (copy) v_u_6, (copy) p_u_3, (ref) v_u_151
			if not v_u_150 then
				v_u_155 = v_u_155 + 1
				v_u_144.Instance.Visible = v_u_157
				if v_u_6.InMatch() then
					v_u_150 = true
					p_u_3.QueueAction("LeaveMatch")
					v_u_150 = false
				end
				v_u_151()
			end
		end)
		local function v_u_205(p182, p183, p184, p185) -- name: memberRow
			-- upvalues: (copy) v_u_7, (ref) v_u_2, (copy) v_u_6, (copy) v_u_9, (copy) v_u_5, (copy) v_u_4
			p182.frame.Visible = p183 ~= nil
			if p183 then
				v_u_7.Apply(p182.img, p183, 60)
				local v186 = v_u_2.SetEmblem
				local v187 = p182.rankPip
				local v188 = v_u_2.Ranks.RankOf
				local v189 = p183.trophies
				v186(v187, v188(tonumber(v189) or 0))
				local v190 = p182.name
				local v191 = p183.tribe
				local v192
				if type(v191) == "table" then
					local v193 = p183.tribe.tag
					v192 = type(v193) ~= "string" and "" or "[" .. p183.tribe.tag .. "] "
				else
					v192 = ""
				end
				local v194 = p183.name or "?"
				v190.Text = v192 .. tostring(v194)
				local v195 = p183.id == v_u_6.MyId()
				local v196 = p182.name
				local v197
				if v195 then
					v197 = v_u_9.Accent
				elseif p184 then
					v197 = v_u_5.Lighten(v_u_9.Ally, 0.2)
				else
					v197 = v_u_5.Lighten(v_u_9.Enemy, 0.15)
				end
				v196.TextColor3 = v197
				p182.stroke.Enabled = v195
				p182.inner.BackgroundTransparency = v195 and 0.25 or 0.45
				local v198
				if p185 == false or p185 == nil then
					v198 = false
				else
					v198 = p183.id == p185
				end
				p182.star.Visible = v198
				local v199 = p182.cells[1]
				local v200 = p183.kills or 0
				v199.Text = tostring(v200)
				local v201 = p182.cells[2]
				local v202 = p183.deaths or 0
				v201.Text = tostring(v202)
				local v203 = p182.cells[3]
				local v204 = p183.assists or 0
				v203.Text = tostring(v204)
				p182.cells[4].Text = v_u_4.FormatNumber(p183.damage or 0)
			end
		end
		local v_u_206 = 0
		local function v_u_221(p_u_207, p_u_208) -- name: animateXp
			-- upvalues: (copy) v_u_6, (copy) v_u_64, (copy) v_u_65, (copy) v_u_67, (copy) v_u_68, (copy) v_u_4, (ref) v_u_206, (copy) p_u_3, (copy) v_u_63, (copy) v_u_69
			local v209 = p_u_207.levelBefore
			local v_u_210 = tonumber(v209) or v_u_6.Level()
			local v211 = p_u_207.levelAfter
			local v_u_212 = tonumber(v211) or v_u_210
			local v213 = p_u_207.xpBefore
			local v214 = tonumber(v213) or 0
			local v215 = p_u_207.xpAfter
			local v216 = tonumber(v215) or 0
			local function v220(p217) -- name: need
				-- upvalues: (copy) v_u_210, (copy) p_u_207, (copy) v_u_212, (ref) v_u_6
				if p217 == v_u_210 then
					local v218 = p_u_207.xpToNextBefore
					if tonumber(v218) then
						return p_u_207.xpToNextBefore
					end
				end
				if p217 == v_u_212 then
					local v219 = p_u_207.xpToNextAfter
					if tonumber(v219) then
						return p_u_207.xpToNextAfter
					end
				end
				return v_u_6.XpToNext(p217)
			end
			v_u_64.Text = tostring(v_u_210)
			v_u_65.Text = "LEVEL " .. v_u_210
			v_u_67.Set(v214 / math.max(1, v220(v_u_210)), true)
			v_u_68.Text = string.format("%s / %s XP", v_u_4.FormatNumber(v214), v_u_4.FormatNumber(v220(v_u_210)))
			task.wait(0.4)
			while v_u_210 < v_u_212 and p_u_208 == v_u_206 do
				v_u_67.Set(1, false, TweenInfo.new(0.7, Enum.EasingStyle.Quad))
				v_u_68.Text = string.format("%s / %s XP", v_u_4.FormatNumber(v220(v_u_210)), v_u_4.FormatNumber(v220(v_u_210)))
				p_u_3.Sounds.Play("XP_Tick")
				task.wait(0.72)
				if p_u_208 ~= v_u_206 then
					return
				end
				v_u_210 = v_u_210 + 1
				v_u_64.Text = tostring(v_u_210)
				v_u_65.Text = "LEVEL " .. v_u_210
				v_u_68.Text = string.format("0 / %s XP", v_u_4.FormatNumber(v220(v_u_210)))
				v_u_4.Pop(v_u_63, 1.7)
				v_u_69.Visible = true
				v_u_4.Pop(v_u_69, 2)
				p_u_3.Sounds.Play("LevelUp")
				task.delay(1.1, function()
					-- upvalues: (copy) p_u_208, (ref) v_u_206, (ref) v_u_69
					if p_u_208 == v_u_206 then
						v_u_69.Visible = false
					end
				end)
				v_u_67.Set(0, true)
				task.wait(0.35)
			end
			if p_u_208 == v_u_206 then
				v_u_67.Set(v216 / math.max(1, v220(v_u_212)), false, TweenInfo.new(0.8, Enum.EasingStyle.Quad))
				p_u_3.Sounds.Play("XP_Tick")
				v_u_68.Text = string.format("%s / %s XP", v_u_4.FormatNumber(v216), v_u_4.FormatNumber(v220(v_u_212)))
			end
		end
		local function v_u_234(p222, p_u_223) -- name: animateTrophies
			-- upvalues: (copy) v_u_100, (copy) v_u_93, (copy) v_u_89, (copy) v_u_9, (ref) v_u_206, (copy) v_u_4, (copy) v_u_83, (copy) v_u_87, (copy) v_u_85, (copy) p_u_3
			local v224 = p222.before
			local v_u_225 = tonumber(v224) or 0
			local v226 = p222.after
			local v_u_227 = tonumber(v226) or 0
			v_u_100(v_u_225, true)
			v_u_93(v_u_225, true)
			local v228 = p222.delta
			local v_u_229 = tonumber(v228) or v_u_227 - v_u_225
			local v230 = v_u_89
			local v231
			if p222.floor == true and v_u_229 == 0 then
				v231 = "SAFE"
			elseif v_u_229 >= 0 then
				v231 = "+" .. v_u_229
			else
				v231 = tostring(v_u_229)
			end
			v230.Text = v231
			local v232 = v_u_89
			local v233
			if v_u_229 > 0 then
				v233 = v_u_9.Success
			elseif v_u_229 < 0 then
				v233 = v_u_9.Danger
			else
				v233 = v_u_9.TextDim
			end
			v232.TextColor3 = v233
			v_u_89.TextTransparency = 1
			task.delay(1.15, function()
				-- upvalues: (copy) p_u_223, (ref) v_u_206, (ref) v_u_89, (ref) v_u_4, (ref) v_u_93, (copy) v_u_227, (ref) v_u_83, (copy) v_u_225, (ref) v_u_87, (ref) v_u_100, (ref) v_u_85, (copy) v_u_229, (ref) p_u_3
				if p_u_223 == v_u_206 then
					v_u_89.TextTransparency = 0
					v_u_4.Pop(v_u_89, 1.6)
					v_u_93(v_u_227)
					if v_u_83.RankOf(v_u_227) == v_u_83.RankOf(v_u_225) then
						v_u_100(v_u_227, false)
					else
						v_u_87.Set(v_u_225 < v_u_227 and 1 or 0, false, TweenInfo.new(0.5, Enum.EasingStyle.Quad))
						task.delay(0.55, function()
							-- upvalues: (ref) p_u_223, (ref) v_u_206, (ref) v_u_100, (ref) v_u_227, (ref) v_u_87, (ref) v_u_4, (ref) v_u_85
							if p_u_223 == v_u_206 then
								v_u_100(v_u_227, true)
								v_u_87.Set(0, true)
								v_u_100(v_u_227, false)
								v_u_4.Pop(v_u_85, 1.4)
							end
						end)
					end
					if v_u_229 > 0 then
						p_u_3.Sounds.Play("Coin")
					end
				end
			end)
		end
		local v_u_235 = 0
		local function v_u_363(p_u_236) -- name: show
			-- upvalues: (copy) v_u_6, (copy) v_u_23, (copy) v_u_9, (copy) v_u_24, (copy) v_u_43, (copy) v_u_205, (copy) v_u_45, (copy) v_u_58, (copy) v_u_7, (copy) v_u_59, (copy) v_u_60, (copy) v_u_5, (copy) v_u_61, (copy) v_u_4, (copy) v_u_62, (ref) v_u_146, (ref) v_u_147, (copy) v_u_135, (copy) v_u_136, (copy) v_u_137, (copy) v_u_141, (copy) v_u_133, (ref) v_u_148, (copy) v_u_103, (copy) v_u_102, (copy) v_u_66, (copy) v_u_73, (copy) v_u_78, (copy) v_u_79, (copy) v_u_81, (copy) v_u_10, (copy) v_u_80, (ref) v_u_149, (ref) v_u_206, (copy) p_u_3, (ref) v_u_150, (ref) v_u_157, (copy) v_u_143, (copy) v_u_144, (copy) v_u_166, (copy) v_u_145, (ref) v_u_235, (copy) v_u_84, (copy) v_u_70, (copy) v_u_67, (copy) v_u_68, (copy) v_u_64, (copy) v_u_65, (copy) v_u_13, (copy) v_u_12, (copy) v_u_153, (copy) v_u_175, (copy) v_u_14, (copy) v_u_26, (copy) v_u_142, (copy) v_u_221, (copy) v_u_234, (copy) v_u_109
			local v237 = v_u_6.Match
			local v238 = p_u_236.you
			local v_u_239 = type(v238) == "table" and (p_u_236.you or {}) or {}
			local v_u_240 = p_u_236.custom == true and true or v_u_239.custom == true
			local v_u_241 = v_u_240 or p_u_236.lobbyOnly == true
			local v242 = v_u_6.MyTeam()
			local v243
			if v_u_239.won == nil then
				v243 = p_u_236.winnerTeam == v242
			else
				v243 = v_u_239.won == true
			end
			local v244 = p_u_236.winnerTeam == 0
			v_u_23.Text = v244 and "DRAW" or (v243 and "VICTORY" or "DEFEAT")
			local v245 = v_u_23
			local v246
			if v244 then
				v246 = v_u_9.Bone
			elseif v243 then
				v246 = v_u_9.Accent
			else
				v246 = v_u_9.Enemy
			end
			v245.TextColor3 = v246
			if v237 then
				local v247 = v237.teams[v242]
				local v248 = v237.teams[3 - v242]
				v_u_24.Text = string.format("YOUR TEAM   %d  -  %d   ENEMY TEAM", v247.score or 0, v248.score or 0)
				local v249 = v_u_43
				local v250 = v247.score or 0
				local v251 = v248.score or 0
				local v252 = v237.roundsToWin or v_u_6.DEFAULT_ROUNDS_TO_WIN
				v249(v250, v251, (math.clamp(v252, 1, 9)))
			else
				v_u_24.Text = ""
			end
			for v253, v254 in { v242, 3 - v242 } do
				local v255 = {}
				if v237 then
					for _, v256 in v237.teams[v254].members do
						table.insert(v255, v256)
					end
				end
				table.sort(v255, function(p257, p258)
					if (p257.kills or 0) == (p258.kills or 0) then
						return (p257.damage or 0) > (p258.damage or 0)
					else
						return (p257.kills or 0) > (p258.kills or 0)
					end
				end)
				for v259 = 1, 3 do
					v_u_205(v_u_45[(v253 - 1) * 3 + v259], v255[v259], v253 == 1, p_u_236.mvpId)
				end
			end
			local v260, v261 = v_u_6.FindMember(p_u_236.mvpId)
			v_u_58.Visible = v260 ~= nil
			if v260 then
				v_u_7.Apply(v_u_59, v260, 150)
				local v262 = v_u_60
				local v263 = v260.name
				v262.Text = tostring(v263)
				local v264 = v_u_60
				local v265
				if v260.id == v_u_6.MyId() then
					v265 = v_u_9.Accent
				elseif v_u_6.IsAllyTeam(v261) then
					v265 = v_u_5.Lighten(v_u_9.Ally, 0.2)
				else
					v265 = v_u_5.Lighten(v_u_9.Enemy, 0.15)
				end
				v264.TextColor3 = v265
				v_u_61.Text = string.format("%d ELIMS  \194\183  %d DEATHS  \194\183  %s DMG", v260.kills or 0, v260.deaths or 0, v_u_4.FormatNumber(v260.damage or 0))
			end
			v_u_62.Position = UDim2.fromOffset(0, v260 and 130 or 0)
			local v266 = v_u_239.drop
			local v_u_267
			if type(v266) == "table" then
				local v268 = v_u_239.drop.stacks
				if type(v268) == "table" then
					v_u_267 = v_u_239.drop or nil
				else
					v_u_267 = nil
				end
			else
				v_u_267 = nil
			end
			local v269 = v_u_239.streakLost
			local v270
			if type(v269) == "table" then
				v270 = v_u_239.streakLost or nil
			else
				v270 = nil
			end
			local v271
			if v270 then
				local v272 = v270.lost
				if type(v272) == "number" then
					local v273 = v270.key
					if type(v273) == "string" then
						v271 = v270
					else
						v271 = nil
					end
				else
					v271 = nil
				end
			else
				v271 = nil
			end
			v_u_146 = v271
			v_u_147 = nil
			local v274 = v_u_135
			local v275
			if v_u_146 == nil then
				if v270 == nil then
					v275 = false
				else
					local v276 = v270.credited
					v275 = type(v276) == "number"
				end
			else
				v275 = true
			end
			v274.Visible = v275
			if v270 then
				local v277 = v270.credited
				if type(v277) == "number" then
					v_u_136.Text = string.format("<font color=\"#FFC478\">%d</font> WIN STREAK KEPT<br/><font size=\"13\" color=\"#8C93A5\">Your saved streak restore was used</font>", v270.credited)
					v_u_137.Instance.Visible = false
				else
					v_u_137.Instance.Visible = true
				end
			else
				v_u_137.Instance.Visible = true
			end
			v_u_141()
			if v_u_267 then
				v_u_133(v_u_267)
			else
				v_u_148 = nil
				v_u_103.Visible = false
			end
			v_u_103.Size = UDim2.fromOffset(v_u_135.Visible and 700 or 1200, 58)
			v_u_102.Visible = v_u_103.Visible or v_u_135.Visible
			local v278 = v_u_66
			local v279
			if v_u_240 then
				v279 = ""
			else
				local v280 = v_u_4.FormatNumber
				local v281 = v_u_239.xp
				v279 = "+" .. v280(tonumber(v281) or 0) .. " XP"
			end
			v278.Text = v279
			v_u_73(0, true)
			local v282 = v_u_239.streak
			local v283 = tonumber(v282) or 0
			v_u_78.Visible = v283 >= 2
			v_u_79.Text = v283 .. " WIN STREAK"
			for _, v284 in v_u_81:GetChildren() do
				if not v284:IsA("GuiObject") then
					continue
				end
				v284:Destroy()
			end
			local v285 = v_u_239.lines
			if type(v285) == "table" then
				for v286, v287 in v_u_239.lines do
					if v286 > 8 then
						break
					end
					if type(v287) ~= "table" then
						continue
					end
					local v288 = v_u_4.new
					local v289 = "TextLabel"
					local v290 = {
						["Text"] = nil,
						["FontFace"] = nil,
						["TextSize"] = 15,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["TextTruncate"] = nil,
						["LayoutOrder"] = nil,
						["Parent"] = nil
					}
					local v291 = string.format
					local v292 = "%s  +%d XP%s"
					local v293 = v287.label or ""
					local v294 = tostring(v293)
					local v295 = v287.xp
					local v296 = tonumber(v295) or 0
					local v297
					if v_u_5.ShowCurrency then
						local v298 = v287.shells
						v297 = (tonumber(v298) or 0) <= 0 and "" or "  +" .. v287.shells
					else
						v297 = ""
					end
					v290.Text = v291(v292, v294, v296, v297)
					v290.FontFace = v_u_10.SemiBold
					v290.TextColor3 = v_u_9.TextDim
					v290.TextXAlignment = Enum.TextXAlignment.Left
					v290.TextTruncate = Enum.TextTruncate.AtEnd
					v290.LayoutOrder = v286
					v290.Parent = v_u_81
					v288(v289, v290)
				end
			end
			local v299 = v_u_239.tribe
			v_u_80.Visible = false
			if type(v299) == "table" then
				local v300 = v299.tag
				if type(v300) == "string" then
					local v301
					if v299.split then
						v301 = string.format("[%s]  no Glory: tribemates on both teams", v299.tag)
					else
						local v302 = string.format
						local v303 = v299.tag
						local v304 = v299.renown
						local v305 = tonumber(v304) or 0
						local v306 = v299.mates
						v301 = v302("[%s]  +%d Glory%s", v303, v305, (tonumber(v306) or 1) <= 1 and "" or string.format("  (x%s with tribemates)", v299.mates >= 3 and "2" or "1.5"))
					end
					if v_u_5.ShowCurrency then
						v_u_4.new("TextLabel", {
							["Text"] = nil,
							["FontFace"] = nil,
							["TextSize"] = 15,
							["TextColor3"] = nil,
							["TextXAlignment"] = nil,
							["TextTruncate"] = nil,
							["LayoutOrder"] = 98,
							["Parent"] = nil,
							["Text"] = v301,
							["FontFace"] = v_u_10.Bold,
							["TextColor3"] = Color3.fromRGB(255, 196, 80),
							["TextXAlignment"] = Enum.TextXAlignment.Left,
							["TextTruncate"] = Enum.TextTruncate.AtEnd,
							["Parent"] = v_u_81
						})
					else
						v_u_80.Text = v301
						v_u_80.Visible = not v_u_240
					end
				end
			end
			if v_u_5.ShowCurrency then
				local v307 = v_u_239.levelShells
				if tonumber(v307) and v_u_239.levelShells > 0 then
					v_u_4.new("TextLabel", {
						["Text"] = nil,
						["FontFace"] = nil,
						["TextSize"] = 15,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["LayoutOrder"] = 99,
						["Parent"] = nil,
						["Text"] = string.format("Level up  +%d", v_u_239.levelShells),
						["FontFace"] = v_u_10.SemiBold,
						["TextColor3"] = v_u_9.Shell,
						["TextXAlignment"] = Enum.TextXAlignment.Left,
						["Parent"] = v_u_81
					})
				end
			end
			v_u_149 = true
			v_u_206 = v_u_206 + 1
			local v_u_308 = v_u_206
			p_u_3.SetHudHidden("MatchEnd", true)
			p_u_3.MenuManager.PushMouse("MatchEnd")
			v_u_150 = false
			v_u_157 = false
			v_u_143:SetText("PLAY AGAIN")
			v_u_144.Instance.Visible = false
			v_u_143.Instance.Visible = not v_u_241
			if v_u_6.Get("Queued") == true then
				v_u_166()
			end
			v_u_145:SetStyle(v_u_241 and "Primary" or "Dark")
			v_u_145.Instance.Size = UDim2.fromOffset(v_u_241 and 320 or 220, 80)
			v_u_145:SetText("LOBBY")
			v_u_235 = v_u_235 + 1
			local v_u_309
			if v_u_240 then
				v_u_309 = nil
			else
				local v310 = v_u_239.trophies
				if type(v310) == "table" then
					v_u_309 = v_u_239.trophies
				else
					v_u_309 = nil
				end
			end
			v_u_84.Visible = v_u_309 ~= nil
			local v311 = 98
			if v_u_309 then
				v_u_84.Position = UDim2.fromOffset(16, v311)
				v311 = v311 + 44
			end
			v_u_70.Position = UDim2.fromOffset(16, v311 + 6)
			local v312 = v_u_78
			local v313
			if v_u_5.ShowCurrency then
				v313 = UDim2.new(1, -16, 0, v311 + 2)
			else
				v313 = UDim2.fromOffset(16, v311 + 2)
			end
			v312.Position = v313
			v_u_80.Position = UDim2.new(1, -16, 0, v311 + 4)
			if v_u_78.Visible or (v_u_80.Visible or v_u_5.ShowCurrency and v_u_70.Visible) then
				v311 = v311 + 46
			end
			local v314 = v311 + 4
			v_u_81.Position = UDim2.fromOffset(16, v314)
			local v315 = 0
			for _, v316 in v_u_81:GetChildren() do
				if not v316:IsA("TextLabel") then
					continue
				end
				v315 = v315 + 1
			end
			local v317 = v315 / 2
			local v318 = math.ceil(v317)
			local v319 = math.max(1, v318)
			local v320 = (290 - v314 - 10 - (v319 - 1) * 3) / v319
			local v321 = math.floor(v320)
			local v322 = math.clamp(v321, 16, 22)
			local v323 = v322 >= 20 and 3 or 2
			local v324 = v_u_81:FindFirstChild("Grid")
			if v324 then
				v324.CellSize = UDim2.new(0.5, -6, 0, v322)
				v324.CellPadding = UDim2.fromOffset(12, v323)
			end
			for _, v325 in v_u_81:GetChildren() do
				if not v325:IsA("TextLabel") then
					continue
				end
				local v326 = v322 - 3
				v325.TextSize = math.min(15, v326)
			end
			v_u_81.Size = UDim2.new(1, -32, 0, v319 * (v322 + v323))
			v_u_62.Size = UDim2.fromOffset(480, v_u_240 and 106 or 290)
			v_u_67.Frame.Visible = not v_u_240
			v_u_68.Position = UDim2.fromOffset(100, v_u_240 and 52 or 74)
			v_u_68.TextSize = v_u_240 and 16 or 15
			if v_u_240 then
				local v327 = v_u_239.levelAfter
				local v328 = tonumber(v327) or v_u_6.Level()
				v_u_64.Text = tostring(v328)
				v_u_65.Text = "CUSTOM MATCH"
				local v329 = p_u_3.Custom
				if v329 then
					v329 = p_u_3.Custom.State()
				end
				local v330 = v_u_68
				local v331
				if type(v329) == "table" then
					local v332 = v329.name
					v331 = type(v332) ~= "string" and "" or v329.name
				else
					v331 = ""
				end
				v330.Text = v331
			end
			local function v_u_353(p333) -- name: openResults
				-- upvalues: (copy) v_u_308, (ref) v_u_206, (ref) v_u_149, (ref) v_u_13, (ref) v_u_12, (ref) v_u_4, (ref) v_u_5, (ref) p_u_3, (ref) v_u_153, (copy) v_u_241, (ref) v_u_235, (copy) p_u_236, (ref) v_u_6, (ref) v_u_145, (copy) v_u_239, (ref) v_u_157, (ref) v_u_175, (ref) v_u_14, (ref) v_u_23, (ref) v_u_24, (ref) v_u_26, (ref) v_u_58, (ref) v_u_62, (ref) v_u_45, (ref) v_u_142, (ref) v_u_73, (ref) v_u_70, (ref) v_u_78, (copy) v_u_240, (ref) v_u_221, (copy) v_u_309, (ref) v_u_234, (ref) v_u_102, (ref) v_u_109
				if v_u_308 == v_u_206 and v_u_149 then
					v_u_13.Visible = true
					v_u_12.Visible = true
					v_u_12.BackgroundTransparency = 1
					v_u_4.Tween(v_u_12, v_u_5.Tween.Slow, {
						["BackgroundTransparency"] = 0.25
					})
					p_u_3.MenuManager.PushFocus("MatchEnd", v_u_153)
					if v_u_241 then
						local v_u_334 = v_u_235
						local v335 = p_u_236.closesAt
						local v_u_336 = tonumber(v335)
						if v_u_336 then
							task.spawn(function()
								-- upvalues: (copy) v_u_334, (ref) v_u_235, (ref) v_u_149, (copy) v_u_336, (ref) v_u_6, (ref) v_u_145
								local v337 = -1
								while v_u_334 == v_u_235 and v_u_149 do
									local v338 = v_u_336 - v_u_6.Now()
									local v339 = math.ceil(v338)
									if v339 <= 0 then
										break
									end
									if v339 == v337 then
										v339 = v337
									else
										v_u_145:SetText("LOBBY  " .. v339)
									end
									task.wait(0.1)
									v337 = v339
								end
							end)
						end
					elseif v_u_239.inactive ~= true then
						local v340 = p_u_236.autoRequeueAt
						local v341 = tonumber(v340)
						if p333 then
							local v342 = v_u_6.Now() + 15
							v341 = math.max(v341 or 0, v342)
							local v343 = p_u_236.closesAt
							if type(v343) == "number" then
								local v344 = p_u_236.closesAt - 3
								v341 = math.min(v341, v344)
							end
						end
						if not v_u_157 then
							v_u_175(v341)
						end
					end
					v_u_4.Unfade(v_u_14)
					v_u_23.TextTransparency = 0
					v_u_4.Pop(v_u_23, 2.2, v_u_5.Tween.Slam)
					v_u_4.Enter(v_u_24, Vector2.new(0, 20), 0.25)
					v_u_4.Enter(v_u_26, Vector2.new(-40, 0), 0.35)
					v_u_4.Enter(v_u_58, Vector2.new(40, 0), 0.45)
					v_u_4.Enter(v_u_62, Vector2.new(40, 0), 0.55)
					for v345, v346 in v_u_45 do
						v_u_4.Enter(v346.inner, Vector2.new(-24, 0), v345 * 0.05 + 0.45, UDim2.new())
					end
					v_u_4.Enter(v_u_142, Vector2.new(0, 30), 0.8)
					task.delay(1, function()
						-- upvalues: (ref) v_u_308, (ref) v_u_206, (ref) v_u_73, (ref) v_u_239, (ref) v_u_5, (ref) p_u_3, (ref) v_u_4, (ref) v_u_70, (ref) v_u_78
						if v_u_308 == v_u_206 then
							local v347 = v_u_73
							local v348 = v_u_239.shells
							v347(tonumber(v348) or 0)
							if v_u_5.ShowCurrency then
								local v349 = v_u_239.shells
								if (tonumber(v349) or 0) > 0 then
									p_u_3.Sounds.Play("Reward")
									v_u_4.Bump(v_u_70, 0.2)
								end
							end
							if v_u_78.Visible then
								v_u_4.Pop(v_u_78, 1.5)
							end
						end
					end)
					task.delay(0.9, function()
						-- upvalues: (ref) v_u_308, (ref) v_u_206, (ref) v_u_240, (ref) v_u_221, (ref) v_u_239
						if v_u_308 == v_u_206 and not v_u_240 then
							v_u_221(v_u_239, v_u_308)
						end
					end)
					if v_u_309 then
						v_u_234(v_u_309, v_u_308)
					end
					if v_u_102.Visible then
						v_u_4.Enter(v_u_102, Vector2.new(0, 20), 0.7)
						for v350, v351 in v_u_109 do
							if not v351.frame.Visible then
								continue
							end
							local v352 = v_u_4.GetScaleObj(v351.frame)
							v352.Scale = 0
							v_u_4.Tween(v352, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out, 0, false, v350 * 0.06 + 0.8), {
								["Scale"] = 1
							})
						end
					end
				end
			end
			v_u_13.Visible = false
			v_u_12.Visible = false
			local v_u_354 = p_u_3.DropReveal
			local v355 = v_u_239.rankDrop
			local v356
			if type(v355) == "table" then
				local v357 = v_u_239.rankDrop.stacks
				if type(v357) == "table" then
					v356 = v_u_239.rankDrop
				else
					v356 = nil
				end
			else
				v356 = nil
			end
			local function v_u_360() -- name: playMatchDrop
				-- upvalues: (copy) v_u_267, (copy) v_u_354, (copy) v_u_353
				local v358
				if v_u_267 == nil or v_u_354 == nil then
					v358 = false
				else
					local v359 = {
						["source"] = "match",
						["onDone"] = nil,
						["onDone"] = function() -- name: onDone
							-- upvalues: (ref) v_u_353
							v_u_353(true)
						end
					}
					v358 = v_u_354.Play(v_u_267, v359)
				end
				return v358
			end
			local v361
			if v356 == nil or v_u_354 == nil then
				v361 = false
			else
				v361 = v_u_354.Play(v356, {
					["source"] = "match",
					["onDone"] = nil,
					["onDone"] = function(p362) -- name: onDone
						-- upvalues: (copy) v_u_360, (copy) v_u_353
						if p362 == "interrupted" or not v_u_360() then
							v_u_353(true)
						end
					end
				})
			end
			if not (v361 or v_u_360()) then
				v_u_353(false)
			end
		end
		local function v365(p364)
			-- upvalues: (ref) v_u_149, (ref) v_u_157, (ref) v_u_156, (ref) v_u_206, (ref) v_u_235, (ref) v_u_155, (copy) v_u_144, (copy) p_u_3, (copy) v_u_13, (copy) v_u_12, (copy) v_u_4, (copy) v_u_5, (copy) v_u_14
			if v_u_149 then
				v_u_149 = false
				v_u_157 = false
				v_u_156 = v_u_156 + 1
				v_u_206 = v_u_206 + 1
				v_u_235 = v_u_235 + 1
				v_u_155 = v_u_155 + 1
				v_u_144.Instance.Visible = v_u_157
				p_u_3.SetHudHidden("MatchEnd", false)
				p_u_3.MenuManager.PopMouse("MatchEnd")
				p_u_3.MenuManager.PopFocus("MatchEnd")
				if p364 then
					v_u_13.Visible = false
					v_u_12.Visible = false
				else
					v_u_4.Tween(v_u_12, v_u_5.Tween.Close, {
						["BackgroundTransparency"] = 1
					})
					v_u_4.FadeOut(v_u_14, TweenInfo.new(0.2))
					task.delay(0.22, function()
						-- upvalues: (ref) v_u_149, (ref) v_u_13, (ref) v_u_12
						if not v_u_149 then
							v_u_13.Visible = false
							v_u_12.Visible = false
						end
					end)
					task.delay(0.6, function()
						-- upvalues: (ref) v_u_149, (ref) v_u_4, (ref) v_u_14
						if not v_u_149 then
							v_u_4.Unfade(v_u_14)
						end
					end)
				end
			else
				return
			end
		end
		v_u_4.Unfade(v_u_14)
		local v_u_366 = v365
		local v_u_367 = v_u_157
		for _, v368 in {
			v_u_24,
			v_u_26,
			v_u_58,
			v_u_62,
			v_u_142,
			v_u_102
		} do
			v_u_4.Unfade(v368)
		end
		p_u_3.OnMatchEvent(function(p369, p_u_370)
			-- upvalues: (copy) v_u_11, (copy) v_u_363, (ref) v_u_366
			if p369 == "MatchEnd" and type(p_u_370) == "table" then
				local v_u_371 = v_u_11:GetAttribute("MatchId")
				task.delay(1.2, function()
					-- upvalues: (ref) v_u_11, (copy) v_u_371, (ref) v_u_363, (copy) p_u_370
					local v372 = 0
					while v_u_11:GetAttribute("ReplayPlaying") == true and v372 < 40 do
						v372 = v372 + task.wait(0.1)
					end
					if v372 > 0 and v_u_11:GetAttribute("State") ~= "Match" then
						return
					elseif v_u_11:GetAttribute("MatchId") == v_u_371 then
						v_u_363(p_u_370)
					end
				end)
			elseif p369 == "MatchStart" then
				v_u_366(true)
			end
		end)
		v_u_6.AttrChanged:Connect(function(p373)
			-- upvalues: (ref) v_u_149, (ref) v_u_366
			if v_u_149 and p373 == "MatchId" then
				v_u_366(true)
			end
		end)
		v_u_6.PlayerStateChanged:Connect(function(p374)
			-- upvalues: (ref) v_u_149, (ref) v_u_366
			if v_u_149 and p374 == "Lobby" then
				v_u_366()
			end
		end)
		function p_u_3.Debug.matchEndCancel()
			-- upvalues: (copy) v_u_178, (copy) v_u_143, (copy) v_u_144, (ref) v_u_367
			v_u_178()
			return {
				["again"] = v_u_143.Label.Text,
				["cancel"] = v_u_144.Instance.Visible,
				["joining"] = v_u_367
			}
		end
		function p_u_3.Debug.matchEndClose()
			-- upvalues: (ref) v_u_366
			v_u_366()
			return true
		end
	end
}