local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("SoundService")
local v3 = {}
local v_u_4 = {
	["Hover"] = 0.2,
	["Click"] = 0.45,
	["Select"] = 0.45,
	["Open"] = 0.4,
	["Close"] = 0.35,
	["Error"] = 0.5,
	["Purchase"] = 0.55,
	["Notify"] = 0.35,
	["Tick"] = 0.3,
	["Whoosh"] = 0.5,
	["Coin"] = 0.45,
	["Fanfare"] = 0.6,
	["LevelUp"] = 0.55,
	["Defeat"] = 0.5,
	["Stinger"] = 0.5
}
local v_u_5 = nil
local v_u_6 = 0
local function v_u_12() -- name: getSfx
	-- upvalues: (ref) v_u_5, (ref) v_u_6, (copy) v_u_1
	if v_u_5 then
		return v_u_5
	end
	if os.clock() - v_u_6 < 5 then
		return nil
	end
	v_u_6 = os.clock()
	local v7 = v_u_1:FindFirstChild("Shared")
	if v7 then
		v7 = v7:FindFirstChild("Sfx")
	end
	if v7 and v7:IsA("ModuleScript") then
		local v8 = require
		local v9, v10 = pcall(v8, v7)
		if v9 and type(v10) == "table" then
			local v11 = v10.PlayUI
			if type(v11) == "function" then
				v_u_5 = v10
			end
		end
	end
	return v_u_5
end
local function v_u_15(p13) -- name: template
	-- upvalues: (copy) v_u_1
	local v14 = v_u_1:FindFirstChild("Assets")
	if v14 then
		v14 = v14:FindFirstChild("Sounds")
	end
	if v14 then
		v14 = v14:FindFirstChild("UI")
	end
	if v14 then
		v14 = v14:FindFirstChild(p13)
	end
	if v14 and v14:IsA("Sound") then
		return v14
	else
		return nil
	end
end
local function v_u_18() -- name: group
	-- upvalues: (copy) v_u_2
	for _, v16 in { "UI", "SFX" } do
		local v17 = v_u_2:FindFirstChild(v16)
		if not (v17 and v17:IsA("SoundGroup")) then
			continue
		end
		return v17
	end
	return nil
end
local v_u_19 = {}
function v3.Play(p20, p21) -- name: Play
	-- upvalues: (copy) v_u_19, (copy) v_u_12, (copy) v_u_15, (copy) v_u_4, (copy) v_u_18, (copy) v_u_2
	local v22 = os.clock()
	local v23 = p21 and p21.minGap or (p20 == "Hover" and 0.05 or (p20 == "Tick" and 0.03 or 0))
	if v23 > 0 and (v_u_19[p20] and v22 - v_u_19[p20] < v23) then
		return
	end
	v_u_19[p20] = v22
	local v24 = v_u_12()
	if v24 then
		local v25, v26, v27
		if p21 and (p21.volume or p21.pitch) then
			local v28 = v24.Play
			if type(v28) == "function" then
				local v29 = v24.Play
				local v30 = "UI/" .. p20
				local v31 = {
					["volume"] = nil,
					["pitch"] = nil,
					["group"] = "UI",
					["volume"] = p21.volume,
					["pitch"] = p21.pitch
				}
				v25 = pcall(v29, v30, nil, v31)
				if v25 then
					return
				end
			else
				v26 = v24.PlayUI
				v27 = "UI/" .. p20
				v25 = pcall(v26, v27)
				if v25 then
					return
				end
			end
		else
			v26 = v24.PlayUI
			v27 = "UI/" .. p20
			v25 = pcall(v26, v27)
			if v25 then
				return
			end
		end
	end
	local v32 = v_u_15(p20)
	if v32 then
		local v_u_33 = v32:Clone()
		v_u_33.Volume = p21 and p21.volume or (v_u_4[p20] or 0.5)
		v_u_33.PlaybackSpeed = p21 and p21.pitch or 1
		v_u_33.SoundGroup = v_u_18()
		v_u_33.Parent = v_u_2
		v_u_33.Ended:Once(function()
			-- upvalues: (copy) v_u_33
			v_u_33:Destroy()
		end)
		v_u_33:Play()
		local v34 = task.delay
		local v35 = v_u_33.TimeLength
		v34(math.max(v35, 1) + 2, function()
			-- upvalues: (copy) v_u_33
			if v_u_33.Parent then
				v_u_33:Destroy()
			end
		end)
	end
end
return v3