local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("Players")
local v3 = {}
local v_u_4 = {
	["Wins"] = "MOST WINS",
	["Kills"] = "MOST ELIMINATIONS",
	["Level"] = "HIGHEST LEVEL",
	["Trophies"] = "TOP TROPHIES"
}
function v3.Init(p5) -- name: Init
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_1
	local v_u_6 = p5.UI
	local v7 = p5.Theme
	local v_u_8 = p5.State
	local _ = p5.Portraits
	local v_u_9 = v7.Colors
	local v_u_10 = v7.Fonts
	local v_u_11 = Color3.fromRGB(228, 232, 240)
	local v_u_12 = { Color3.fromRGB(214, 164, 60), Color3.fromRGB(160, 168, 180), Color3.fromRGB(176, 108, 62) }
	local v_u_13 = v_u_2.LocalPlayer
	local v_u_14 = v_u_6.new("ScreenGui", {
		["Name"] = "TR_Leaderboards",
		["ResetOnSpawn"] = false,
		["Parent"] = nil,
		["Parent"] = p5.PlayerGui
	})
	local v_u_15 = {}
	local function v_u_42(p16) -- name: build
		-- upvalues: (copy) v_u_6, (copy) v_u_14, (ref) v_u_4, (copy) v_u_10, (copy) v_u_9, (copy) v_u_12, (copy) v_u_11
		local v17 = p16:GetAttribute("Stat") or "Wins"
		local v18 = tostring(v17)
		local v_u_19 = p16:GetAttribute("Face")
		local v_u_20 = Enum.NormalId.Front
		if type(v_u_19) == "string" then
			pcall(function()
				-- upvalues: (ref) v_u_20, (copy) v_u_19
				v_u_20 = Enum.NormalId[v_u_19]
			end)
		end
		local v21 = v_u_6.new("SurfaceGui", {
			["Name"] = nil,
			["Adornee"] = nil,
			["Face"] = nil,
			["SizingMode"] = nil,
			["CanvasSize"] = nil,
			["LightInfluence"] = 0,
			["MaxDistance"] = 220,
			["ResetOnSpawn"] = false,
			["ZIndexBehavior"] = nil,
			["Parent"] = nil,
			["Name"] = "Board_" .. v18,
			["Adornee"] = p16,
			["Face"] = v_u_20,
			["SizingMode"] = Enum.SurfaceGuiSizingMode.FixedSize,
			["CanvasSize"] = Vector2.new(800, 1000),
			["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
			["Parent"] = v_u_14
		})
		local v22 = p16.Size.X
		local v23 = p16.Size.Y
		if v_u_20 == Enum.NormalId.Left or v_u_20 == Enum.NormalId.Right then
			v22 = p16.Size.Z
		elseif v_u_20 == Enum.NormalId.Top or v_u_20 == Enum.NormalId.Bottom then
			v23 = p16.Size.Z
		end
		if v22 > 0 and v23 > 0 then
			local v24 = Vector2.new
			local v25 = 800 * v23 / v22
			v21.CanvasSize = v24(800, (math.floor(v25)))
		end
		local v26 = v21.CanvasSize.Y * 0.94 * 0.85 * 0.18 * 0.42
		local v27 = math.floor(v26)
		local v28 = math.clamp(v27, 14, 72)
		local v29 = v_u_6.new("Frame", {
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.05,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.fromRGB(14, 15, 20),
			["Parent"] = v21
		})
		v_u_6.new("UIPadding", {
			["PaddingTop"] = UDim.new(0.03, 0),
			["PaddingBottom"] = UDim.new(0.03, 0),
			["PaddingLeft"] = UDim.new(0.04, 0),
			["PaddingRight"] = UDim.new(0.04, 0),
			["Parent"] = v29
		})
		local v30 = v_u_6.new("TextLabel", {
			["Size"] = nil,
			["Text"] = nil,
			["FontFace"] = nil,
			["TextScaled"] = true,
			["TextColor3"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 0.11),
			["Text"] = v_u_4[v18] or string.upper(v18),
			["FontFace"] = v_u_10.Display,
			["TextColor3"] = Color3.fromRGB(96, 172, 255),
			["Parent"] = v29
		})
		v_u_6.TextStroke(v_u_9.Void, 3, 0).Parent = v30
		v_u_6.new("Frame", {
			["Position"] = UDim2.fromScale(0, 0.125),
			["Size"] = UDim2.new(1, 0, 0, 4),
			["BackgroundColor3"] = Color3.fromRGB(40, 110, 200),
			["Parent"] = v29
		})
		local v31 = v_u_6.new("Frame", {
			["Position"] = UDim2.fromScale(0, 0.15),
			["Size"] = UDim2.fromScale(1, 0.85),
			v_u_6.new("UIListLayout", {
				["Padding"] = UDim.new(0.02, 0),
				["SortOrder"] = Enum.SortOrder.LayoutOrder
			}),
			["Parent"] = v29
		})
		local v32 = {}
		for v33 = 1, 5 do
			local v34 = v_u_6.new
			local v35 = "Frame"
			local v36 = {
				["Size"] = UDim2.fromScale(1, 0.18)
			}
			local v37
			if v33 % 2 == 1 then
				v37 = Color3.fromRGB(30, 33, 42)
			else
				v37 = Color3.fromRGB(24, 26, 34)
			end
			v36.BackgroundColor3 = v37
			v36.LayoutOrder = v33
			__set_list(v36, 1, {(v_u_6.Corner(UDim.new(0.18, 0)))})
			v36.Parent = v31
			local v38 = v34(v35, v36)
			local v39 = v_u_6.new("UIStroke", {
				["Color"] = nil,
				["Thickness"] = 4,
				["Enabled"] = false,
				["Parent"] = nil,
				["Color"] = v_u_9.Ally,
				["Parent"] = v38
			})
			local v40 = v_u_6.new("TextLabel", {
				["Position"] = UDim2.fromScale(0.01, 0),
				["Size"] = UDim2.fromScale(0.1, 1),
				["Text"] = "#" .. v33,
				["FontFace"] = v_u_10.Display,
				["TextSize"] = v28,
				["TextColor3"] = v_u_12[v33] or v_u_11,
				["Parent"] = v38
			})
			local v41 = v_u_6.new("ImageLabel", {
				["Position"] = UDim2.fromScale(0.12, 0.08),
				["Size"] = UDim2.fromScale(0.1, 0.84),
				["BackgroundColor3"] = Color3.fromRGB(44, 48, 60),
				["ScaleType"] = Enum.ScaleType.Crop,
				v_u_6.Corner(UDim.new(0.2, 0)),
				["Parent"] = v38
			})
			v_u_6.new("UIAspectRatioConstraint", {
				["AspectRatio"] = 1,
				["Parent"] = nil,
				["Parent"] = v41
			})
			v32[v33] = {
				["frame"] = v38,
				["rank"] = v40,
				["img"] = v41,
				["name"] = v_u_6.new("TextLabel", {
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "\226\128\148",
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["TextTruncate"] = nil,
					["Parent"] = nil,
					["Position"] = UDim2.fromScale(0.25, 0),
					["Size"] = UDim2.fromScale(0.5, 1),
					["FontFace"] = v_u_10.Heavy,
					["TextSize"] = v28,
					["TextColor3"] = v_u_11,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["TextTruncate"] = Enum.TextTruncate.AtEnd,
					["Parent"] = v38
				}),
				["value"] = v_u_6.new("TextLabel", {
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.fromScale(0.98, 0),
					["Size"] = UDim2.fromScale(0.22, 1),
					["FontFace"] = v_u_10.Display,
					["TextSize"] = v28,
					["TextColor3"] = Color3.fromRGB(96, 172, 255),
					["TextXAlignment"] = Enum.TextXAlignment.Right,
					["Parent"] = v38
				}),
				["stroke"] = v39
			}
		end
		return {
			["sg"] = v21,
			["part"] = p16,
			["rows"] = v32,
			["stat"] = v18
		}
	end
	local function v_u_61(p43) -- name: fill
		-- upvalues: (copy) v_u_8, (copy) v_u_6, (copy) v_u_13
		local v44 = v_u_8.Leaderboards
		local v45
		if type(v44) == "table" then
			v45 = v44[p43.stat] or nil
		else
			v45 = nil
		end
		for v46, v47 in p43.rows do
			local v48
			if type(v45) == "table" then
				v48 = v45[v46] or nil
			else
				v48 = nil
			end
			if type(v48) == "table" then
				local v49 = v47.name
				local v50 = v48.name or "?"
				v49.Text = tostring(v50)
				local v51 = v47.value
				local v52 = v_u_6.FormatCompact
				local v53 = v48.value
				v51.Text = v52(tonumber(v53) or 0)
				local v54 = v48.userId
				local v55 = tonumber(v54) or 0
				v47.img.Image = v55 <= 0 and "" or string.format("rbxthumb://type=AvatarHeadShot&id=%d&w=60&h=60", v55)
				local v56 = v47.img
				local v57 = v48.userId
				local v58
				if (tonumber(v57) or 0) > 0 then
					v58 = Enum.ScaleType.Crop
				else
					v58 = Enum.ScaleType.Fit
				end
				v56.ScaleType = v58
				local v59 = v47.stroke
				local v60 = v48.userId
				v59.Enabled = tonumber(v60) == v_u_13.UserId
				v47.name.TextTransparency = 0
			else
				v47.name.Text = "\226\128\148"
				v47.value.Text = ""
				v47.img.Image = ""
				v47.stroke.Enabled = false
				v47.name.TextTransparency = 0.5
			end
		end
	end
	local function v64(p62) -- name: add
		-- upvalues: (copy) v_u_15, (copy) v_u_42, (copy) v_u_61
		if p62:IsA("BasePart") and not v_u_15[p62] then
			local v63 = v_u_42(p62)
			v_u_15[p62] = v63
			v_u_61(v63)
		end
	end
	local function v67(p65) -- name: remove
		-- upvalues: (copy) v_u_15
		local v66 = v_u_15[p65]
		if v66 then
			v_u_15[p65] = nil
			v66.sg:Destroy()
		end
	end
	for _, v68 in v_u_1:GetTagged("LeaderboardBoard") do
		if not v68:IsA("BasePart") then
			continue
		end
		if v_u_15[v68] then
			continue
		end
		local v69 = v_u_42(v68)
		v_u_15[v68] = v69
		v_u_61(v69)
	end
	v_u_1:GetInstanceAddedSignal("LeaderboardBoard"):Connect(v64)
	v_u_1:GetInstanceRemovedSignal("LeaderboardBoard"):Connect(v67)
	v_u_8.LeaderboardsChanged:Connect(function()
		-- upvalues: (copy) v_u_15, (copy) v_u_61
		for _, v70 in v_u_15 do
			v_u_61(v70)
		end
	end)
end
return v3