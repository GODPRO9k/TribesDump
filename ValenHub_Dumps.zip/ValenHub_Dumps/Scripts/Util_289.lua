local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("SoundService")
game:GetService("UserInputService")
local v_u_6 = require(script.Parent.Metrics)
local v_u_7 = require(script.Parent.Quality)
local v_u_8 = {}
local v_u_9 = v_u_2.LocalPlayer
local v10 = v3:WaitForChild("Assets", 30)
v_u_8.Assets = v10
local v_u_11 = v3:WaitForChild("Shared")
local v_u_12 = require(v_u_11:WaitForChild("Combat"))
local v_u_13 = nil
local v_u_14 = nil
task.spawn(function()
	-- upvalues: (copy) v_u_11, (ref) v_u_13
	local v15 = v_u_11:WaitForChild("Camera", 12)
	if v15 and v15:IsA("ModuleScript") then
		local v16 = require
		local v17, v18 = pcall(v16, v15)
		if v17 and type(v18) == "table" then
			v_u_13 = v18
			return
		end
		warn("[Combat] Shared.Camera failed to load, using fallback camera helpers:", v18)
	end
end)
task.spawn(function()
	-- upvalues: (copy) v_u_11, (ref) v_u_14
	local v19 = v_u_11:WaitForChild("Sfx", 20)
	if v19 and v19:IsA("ModuleScript") then
		local v20 = require
		local v21, v22 = pcall(v20, v19)
		if v21 and type(v22) == "table" then
			local v23 = v22.Play
			if type(v23) == "function" then
				v_u_14 = v22
			end
		end
	end
end)
function v_u_8.Camera() -- name: Camera
	-- upvalues: (ref) v_u_13
	return v_u_13
end
function v_u_8.Drawn(p24) -- name: Drawn
	-- upvalues: (ref) v_u_13
	local v25 = v_u_13
	if p24 and v25 then
		local v26 = v25.Drawn
		if type(v26) == "function" then
			local v27 = v25.Drawn
			local v28, v29 = pcall(v27, p24)
			if v28 and typeof(v29) == "Instance" then
				return v29
			end
		end
	end
	return p24
end
function v_u_8.InFirstPerson() -- name: InFirstPerson
	-- upvalues: (ref) v_u_13
	local v30
	if v_u_13 == nil then
		v30 = false
	else
		local v31 = v_u_13.InFirstPerson
		if type(v31) == "function" then
			v30 = v_u_13.InFirstPerson() == true
		else
			v30 = false
		end
	end
	return v30
end
function v_u_8.GetAimRay() -- name: GetAimRay
	-- upvalues: (ref) v_u_13
	if v_u_13 then
		local v32 = v_u_13.GetAimRay
		if type(v32) == "function" then
			local v33 = v_u_13.GetAimRay
			local v34, v35 = pcall(v33)
			if v34 and typeof(v35) == "Ray" then
				return v35
			end
		end
	end
	local v36 = workspace.CurrentCamera
	local v37 = v36.ViewportSize
	return v36:ViewportPointToRay(v37.X / 2, v37.Y / 2)
end
function v_u_8.SetAiming(p38, p39) -- name: SetAiming
	-- upvalues: (ref) v_u_13
	if v_u_13 then
		local v40 = v_u_13.SetAiming
		if type(v40) == "function" then
			local v41 = v_u_13.SetAiming
			pcall(v41, p38, p39)
			return
		end
	end
	local v42 = workspace.CurrentCamera
	game:GetService("TweenService"):Create(v42, TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		["FieldOfView"] = p38 and (p39 or 55) or 70
	}):Play()
end
function v_u_8.FovKick(p43, p44, p45) -- name: FovKick
	-- upvalues: (ref) v_u_13
	if v_u_13 then
		local v46 = v_u_13.FovKick
		if type(v46) == "function" then
			local v47 = v_u_13.FovKick
			pcall(v47, p43, p44, p45)
		end
	end
end
function v_u_8.Shake(p48, p49) -- name: Shake
	-- upvalues: (ref) v_u_13
	if v_u_13 then
		local v50 = v_u_13.Shake
		if type(v50) == "function" then
			local v51 = v_u_13.Shake
			pcall(v51, p48, p49)
		end
	end
end
function v_u_8.RecoilSlow(p52, p53, p54, p55) -- name: RecoilSlow
	-- upvalues: (ref) v_u_13, (copy) v_u_8
	if v_u_13 then
		local v56 = v_u_13.RecoilSlow
		if type(v56) == "function" then
			local v57 = v_u_13.RecoilSlow
			pcall(v57, p52, p53, p54, p55)
			return
		end
	end
	v_u_8.Recoil(p52 * 5, (p53 or 0) * 5)
end
function v_u_8.Recoil(p58, p59) -- name: Recoil
	-- upvalues: (ref) v_u_13
	if v_u_13 then
		local v60 = v_u_13.Recoil
		if type(v60) == "function" then
			local v61 = v_u_13.Recoil
			pcall(v61, p58, p59)
		end
	end
end
function v_u_8.IsMouseUnlocked() -- name: IsMouseUnlocked
	-- upvalues: (ref) v_u_13
	if v_u_13 then
		local v62 = v_u_13.IsMouseUnlocked
		if type(v62) == "function" then
			local v63 = v_u_13.IsMouseUnlocked
			local v64, v65 = pcall(v63)
			if v64 then
				v64 = v65 == true
			end
			return v64
		end
	end
	return false
end
function v_u_8.FaceCamera() -- name: FaceCamera
	-- upvalues: (ref) v_u_13
	if v_u_13 then
		local v66 = v_u_13.FaceCamera
		if type(v66) == "function" then
			local v67 = v_u_13.FaceCamera
			pcall(v67)
		end
	end
end
function v_u_8.SetCameraModifier(p68, p69) -- name: SetCameraModifier
	-- upvalues: (ref) v_u_13
	if v_u_13 then
		local v70 = v_u_13.SetModifier
		if type(v70) == "function" then
			if p69 and p69.pivot then
				local v71 = v_u_13.GetShoulderSide
				if type(v71) == "function" then
					local v72 = v_u_13.GetShoulderSide
					local v73, v74 = pcall(v72)
					if v73 and type(v74) == "number" then
						local v75 = p69.pivot
						p69 = table.clone(p69)
						local v76 = v75.X * v74
						local v77 = v75.Y
						local v78 = v75.Z
						p69.pivot = Vector3.new(v76, v77, v78)
					end
				end
			end
			local v79 = v_u_13.SetModifier
			pcall(v79, p68, p69)
		end
	end
end
function v_u_8.GetFOV() -- name: GetFOV
	return workspace.CurrentCamera.FieldOfView
end
function v_u_8.InMatch() -- name: InMatch
	-- upvalues: (copy) v_u_9
	local v80 = v_u_9.Character
	if v80 then
		v80 = v80:GetAttribute("MatchId")
	end
	return (type(v80) ~= "string" and "" or v80) ~= ""
end
function v_u_8.IsEnemy(p81) -- name: IsEnemy
	-- upvalues: (copy) v_u_9
	local v82 = v_u_9.Character
	if not p81 or (not v82 or p81 == v82) then
		return false
	end
	local v83
	if v82 then
		v83 = v82:GetAttribute("MatchId")
	else
		v83 = v82
	end
	local v84 = type(v83) ~= "string" and "" or v83
	if v84 ~= "" then
		local v85
		if p81 then
			v85 = p81:GetAttribute("MatchId")
		else
			v85 = p81
		end
		if (type(v85) ~= "string" and "" or v85) == v84 then
			local v86 = v82:GetAttribute("Team")
			local v87 = p81:GetAttribute("Team")
			local v88
			if v86 == nil or v87 == nil then
				v88 = false
			else
				v88 = v86 ~= v87
			end
			return v88
		end
	end
	return false
end
function v_u_8.IsTeammate(p89) -- name: IsTeammate
	-- upvalues: (copy) v_u_9
	local v90 = v_u_9.Character
	if not p89 or (not v90 or p89 == v90) then
		return false
	end
	local v91
	if v90 then
		v91 = v90:GetAttribute("MatchId")
	else
		v91 = v90
	end
	local v92 = type(v91) ~= "string" and "" or v91
	local v93
	if v92 == "" then
		v93 = false
	else
		v93 = false
		local v94
		if p89 then
			v94 = p89:GetAttribute("MatchId")
		else
			v94 = p89
		end
		if (type(v94) ~= "string" and "" or v94) == v92 then
			v93 = p89:GetAttribute("Team") == v90:GetAttribute("Team")
		end
	end
	return v93
end
local v_u_95 = nil
function v_u_8.ItemBonus(p96) -- name: ItemBonus
	-- upvalues: (copy) v_u_9, (ref) v_u_95, (copy) v_u_11
	local v97 = v_u_9.Character
	if not v97 or type(p96) ~= "string" then
		return 1
	end
	local v98 = v97:GetAttribute("ItemLevels")
	if type(v98) ~= "string" or v98 == "" then
		return 1
	end
	if v_u_95 == nil then
		local v99 = v_u_11:FindFirstChild("Shards")
		local v100 = require
		local v101, v102 = pcall(v100, v99)
		if not v101 or type(v102) ~= "table" then
			v102 = false
		end
		v_u_95 = v102
	end
	return not v_u_95 and 1 or v_u_95.Bonus(v_u_95.DecodeLevels(v98)[p96] or 1)
end
function v_u_8.CanPredictHit(p103) -- name: CanPredictHit
	-- upvalues: (copy) v_u_9, (copy) v_u_1, (copy) v_u_8
	if not p103 then
		return false
	end
	local v104 = v_u_9.Character
	if v_u_1:HasTag(p103, "TrainingDummy") then
		if v104 then
			v104 = v104:GetAttribute("MatchId")
		end
		return (type(v104) ~= "string" and "" or v104) == ""
	end
	local v105 = v_u_8.IsEnemy(p103)
	if v105 then
		if v104 then
			v104 = v104:GetAttribute("MatchId")
		end
		local v106 = type(v104) ~= "string" and "" or v104
		local v107 = workspace:FindFirstChild("Arenas")
		if v107 then
			v107 = v107:FindFirstChild(v106)
		end
		if v107 then
			v107 = v107:GetAttribute("Phase")
		end
		v105 = v107 == "Live" and true or v107 == "Overtime"
	end
	return v105
end
function v_u_8.CanAct() -- name: CanAct
	-- upvalues: (copy) v_u_9
	if v_u_9:GetAttribute("Frozen") == true then
		return false
	end
	local v108 = v_u_9.Character
	if v108 and v108:GetAttribute("Frozen") == true then
		return false
	end
	local v109
	if v108 then
		v109 = v108:GetAttribute("StaggerUntil")
	else
		v109 = v108
	end
	if type(v109) == "number" and workspace:GetServerTimeNow() < v109 then
		return false
	end
	if v108 then
		v108 = v108:GetAttribute("MatchId")
	end
	local v110 = type(v108) ~= "string" and "" or v108
	local v111
	if v110 == "" then
		v111 = true
	else
		local v112 = workspace:FindFirstChild("Arenas")
		if v112 then
			v112 = v112:FindFirstChild(v110)
		end
		if v112 then
			v112 = v112:GetAttribute("Phase")
		end
		v111 = v112 == "Live" and true or v112 == "Overtime"
	end
	return v111
end
local function v_u_116() -- name: fxFolders
	local v113 = {}
	for _, v114 in { "FX", "Projectiles" } do
		local v115 = workspace:FindFirstChild(v114)
		if not v115 then
			continue
		end
		table.insert(v113, v115)
	end
	return v113
end
function v_u_8.Targets() -- name: Targets
	-- upvalues: (copy) v_u_9, (copy) v_u_2, (copy) v_u_1
	local v117 = v_u_9.Character
	local v118 = {}
	for _, v119 in v_u_2:GetPlayers() do
		local v120 = v119.Character
		if not v120 or (v120 == v117 or not v120:IsDescendantOf(workspace)) then
			continue
		end
		table.insert(v118, v120)
	end
	local v121 = {}
	for _, v122 in v118 do
		v121[v122] = true
	end
	for _, v123 in { "Combatant", "Bot", "TrainingDummy" } do
		for _, v124 in v_u_1:GetTagged(v123) do
			if not v124:IsA("Model") or (v124 == v117 or (v121[v124] or not v124:IsDescendantOf(workspace))) then
				continue
			end
			v121[v124] = true
			table.insert(v118, v124)
		end
	end
	return v118
end
function v_u_8.Teammates() -- name: Teammates
	-- upvalues: (copy) v_u_8
	local v125 = {}
	for _, v126 in v_u_8.Targets() do
		if not v_u_8.IsTeammate(v126) then
			continue
		end
		table.insert(v125, v126)
	end
	return v125
end
function v_u_8.WorldParams(p127) -- name: WorldParams
	-- upvalues: (copy) v_u_116, (copy) v_u_9
	local v128 = RaycastParams.new()
	v128.FilterType = Enum.RaycastFilterType.Exclude
	local v129 = v_u_116()
	local v130 = v_u_9.Character
	if v130 then
		table.insert(v129, v130)
	end
	if p127 then
		for _, v131 in p127 do
			table.insert(v129, v131)
		end
	end
	v128.FilterDescendantsInstances = v129
	v128.IgnoreWater = true
	return v128
end
function v_u_8.AimPoint(p132) -- name: AimPoint
	-- upvalues: (ref) v_u_13, (copy) v_u_116, (copy) v_u_8
	if v_u_13 then
		local v133 = v_u_13.GetAimPoint
		if type(v133) == "function" then
			local v134 = v_u_116()
			for _, v135 in v_u_8.Teammates() do
				table.insert(v134, v135)
			end
			local v136 = v_u_13.GetAimPoint
			local v137, v138, v139 = pcall(v136, p132, v134)
			if v137 and typeof(v138) == "Vector3" then
				return v138, v139
			end
		end
	end
	local v140 = v_u_8.GetAimRay()
	local v141 = p132 or 1000
	local v142 = workspace:Raycast(v140.Origin, v140.Direction.Unit * v141, v_u_8.WorldParams(v_u_8.Teammates()))
	if v142 then
		return v142.Position, v142
	else
		return v140.Origin + v140.Direction.Unit * v141, nil
	end
end
function v_u_8.AimDirection(p143) -- name: AimDirection
	-- upvalues: (copy) v_u_8
	local v144 = v_u_8.GetAimRay()
	local v145 = v_u_8.AimPoint() - p143
	if v145.Magnitude < 2 or v145.Unit:Dot(v144.Direction.Unit) < 0.2 then
		return v144.Direction.Unit
	else
		return v145.Unit
	end
end
v_u_8.ASSIST_MAGNET = {
	["touch"] = {
		["ranged"] = 2.5,
		["aimed"] = 2.5,
		["scoped"] = 1.5
	},
	["gamepad"] = {
		["ranged"] = 1.5,
		["aimed"] = 1.5,
		["scoped"] = 1.5
	}
}
v_u_8.MELEE_NUDGE = {
	["touch"] = {
		["cone"] = 50,
		["max"] = 20,
		["reach"] = 1.5
	},
	["gamepad"] = {
		["cone"] = 40,
		["max"] = 12,
		["reach"] = 1
	}
}
local function v_u_150(p146, ...) -- name: camCall
	-- upvalues: (ref) v_u_13
	local v147 = v_u_13
	if v147 then
		v147 = v_u_13[p146]
	end
	if type(v147) == "function" then
		local v148, v149 = pcall(v147, ...)
		if v148 then
			return v149
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_8.AssistActive() -- name: AssistActive
	-- upvalues: (ref) v_u_13, (copy) v_u_150
	if v_u_13 and v_u_150("GetAimAssistEnabled") ~= false then
		return v_u_150("IsAssistedInput") == true
	else
		return false
	end
end
local function v_u_179(p151, p152, p153, p154) -- name: rawHitsBody
	local v155 = p153:FindFirstChild("HumanoidRootPart") or (p153:FindFirstChild("UpperTorso") or p153:FindFirstChild("Torso"))
	local v156 = p153:FindFirstChild("Head")
	if not (v155 and v155:IsA("BasePart")) then
		return false
	end
	if p154 then
		local v157 = p152.X
		local v158 = p152.Z
		local v159 = Vector3.new(v157, 0, v158)
		if v159.Magnitude < 0.001 then
			return false
		end
		local v160 = v159.Unit
		local v161 = v155.Position.X - p151.X
		local v162 = v155.Position.Z - p151.Z
		local v163 = Vector3.new(v161, 0, v162)
		local v164 = v163:Dot(v160)
		local v165
		if v164 > 0 then
			v165 = (v163 - v160 * v164).Magnitude <= 1.1
		else
			v165 = false
		end
		return v165
	end
	local v166 = v155.Position - Vector3.new(0, 2.2, 0)
	local v167
	if v156 and v156:IsA("BasePart") then
		v167 = v156.Position + Vector3.new(0, 0.4, 0)
	else
		v167 = v155.Position + Vector3.new(0, 2.2, 0)
	end
	local v168 = p152.Unit
	local v169 = v167 - v166
	local v170 = v166 - p151
	local v171 = v169:Dot(v169)
	local v172 = v169:Dot(v168)
	local v173 = v171 - v172 * v172
	local v174
	if v173 > 1e-6 then
		local v175 = (v172 * v168:Dot(v170) - v169:Dot(v170)) / v173
		v174 = math.clamp(v175, 0, 1)
	else
		v174 = 0
	end
	local v176 = v166 + v169 * v174
	local v177 = (v176 - p151):Dot(v168)
	local v178
	if v177 > 0 then
		v178 = (v176 - p151 - v168 * v177).Magnitude <= 1.1
	else
		v178 = false
	end
	return v178
end
function v_u_8.AssistDirection(p180, p181, p182) -- name: AssistDirection
	-- upvalues: (copy) v_u_8, (copy) v_u_150, (copy) v_u_179, (copy) v_u_12, (copy) v_u_4, (copy) v_u_9
	if not v_u_8.AssistActive() then
		return p181
	end
	local v183 = v_u_150("GetAimAssistShot")
	if type(v183) == "table" and v183.torsoVisible then
		local v184 = v183.point
		if typeof(v184) == "Vector3" then
			local v185 = v183.model
			if typeof(v185) == "Instance" then
				local v186 = v183.model
				local v187 = v183.point
				local v188 = (v_u_8.ASSIST_MAGNET[v183.input] or v_u_8.ASSIST_MAGNET.touch)[v183.class]
				if type(v188) ~= "number" or v_u_179(p180, p181, v186, p182) then
					return p181
				end
				if v_u_12.SmokeBlocks(p180, v187) then
					return p181
				end
				local v189 = workspace:Raycast(p180, v187 - p180, v_u_8.WorldParams(v_u_8.Targets()))
				if v189 and not v189.Instance:IsDescendantOf(v186) then
					return p181
				end
				local v190 = (v187 - p180).Unit
				if p182 then
					local v191 = v190.X
					local v192 = v190.Z
					local v193 = Vector3.new(v191, 0, v192)
					local v194 = p181.X * p181.X + p181.Z * p181.Z
					local v195 = math.sqrt(v194)
					if v193.Magnitude < 0.001 or v195 < 0.001 then
						return p181
					end
					local v196 = v193.Unit * v195
					local v197 = v196.X
					local v198 = p181.Y
					local v199 = v196.Z
					v190 = Vector3.new(v197, v198, v199).Unit
				end
				local v200 = p181.Unit
				local v201 = v200:Dot(v190)
				local v202 = math.clamp(v201, -1, 1)
				local v203 = math.acos(v202)
				local v204 = math.rad(v188)
				if v_u_4:IsStudio() then
					local v205 = v_u_9:GetAttribute("QA_AssistBends")
					v_u_9:SetAttribute("QA_AssistBends", (type(v205) ~= "number" and 0 or v205) + 1)
				end
				if v203 <= v204 or v203 < 0.0001 then
					return v190
				end
				local v206 = v204 / v203
				local v207 = math.sin(v203)
				local v208 = (1 - v206) * v203
				local v209 = v200 * (math.sin(v208) / v207)
				local v210 = v206 * v203
				return (v209 + v190 * (math.sin(v210) / v207)).Unit
			end
		end
	end
	return p181
end
function v_u_8.MeleeAssist(p211, p212) -- name: MeleeAssist
	-- upvalues: (copy) v_u_8, (copy) v_u_150, (copy) v_u_9, (copy) v_u_12, (copy) v_u_4
	if not v_u_8.AssistActive() then
		return 0
	end
	local v213 = v_u_150("GetAimAssistInput")
	local v214 = v_u_8.MELEE_NUDGE[v213]
	local v215 = v_u_9.Character
	local v216
	if v215 then
		v216 = v215:FindFirstChild("HumanoidRootPart")
	else
		v216 = v215
	end
	if not (v214 and (v216 and v216:IsA("BasePart"))) then
		return 0
	end
	local v217 = v215:FindFirstChild("Head")
	local v218
	if v217 and v217:IsA("BasePart") then
		v218 = v217.Position
	else
		v218 = v216.Position
	end
	local v219 = v_u_8.GetAimRay()
	local v220 = v219.Direction.X
	local v221 = v219.Direction.Z
	local v222 = Vector3.new(v220, 0, v221)
	if v222.Magnitude < 0.05 then
		return 0
	end
	local v223 = v222.Unit
	local v224 = v214.cone
	local v225 = math.rad(v224)
	local v226 = math.cos(v225)
	local v227 = v_u_8.Targets()
	local v228 = nil
	local v229 = (1 / 0)
	local v230 = nil
	for _, v231 in v227 do
		if not v_u_8.CanPredictHit(v231) then
			continue
		end
		local v232 = v231:FindFirstChildOfClass("Humanoid")
		local v233 = v231:FindFirstChild("HumanoidRootPart")
		if not v232 or (v232.Health <= 0 or not (v233 and v233:IsA("BasePart"))) then
			continue
		end
		local v234 = v233.Position - v216.Position
		local v235 = v234.X
		local v236 = v234.Z
		local v237 = Vector3.new(v235, 0, v236)
		local v238 = v237.Magnitude
		if p211 + v214.reach < v238 or v238 < 0.5 then
			continue
		end
		local v239 = v234.Y
		if math.abs(v239) > 6 then
			continue
		end
		local v240 = v237.Unit:Dot(v223)
		if v240 < v226 then
			continue
		end
		local v241 = (1 - v240) * 10 + v238 * 0.05
		if v229 <= v241 or v_u_12.SmokeBlocks(v218, v233.Position) then
			continue
		end
		v228 = v228 or v_u_8.WorldParams(v227)
		if workspace:Raycast(v218, v233.Position - v218, v228) then
			continue
		end
		v230 = v233.Position
		v229 = v241
	end
	if not v230 then
		return 0
	end
	local v242 = v230.X - v216.Position.X
	local v243 = v230.Z - v216.Position.Z
	local v244 = Vector3.new(v242, 0, v243).Unit
	local v245 = -v244.X
	local v246 = -v244.Z
	local v247 = math.atan2(v245, v246)
	local v248 = -v223.X
	local v249 = -v223.Z
	local v250 = (v247 - math.atan2(v248, v249) + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
	if math.abs(v250) < 0.05235987755982989 then
		return 0
	end
	local v251 = v214.max
	local v252 = -math.rad(v251)
	local v253 = v214.max
	local v254 = math.rad(v253)
	local v255 = math.clamp(v250, v252, v254)
	v_u_150("Nudge", v255, p212 and 0 or 0.08)
	if v_u_4:IsStudio() then
		local v256 = v_u_9:GetAttribute("QA_AssistMelee")
		v_u_9:SetAttribute("QA_AssistMelee", (type(v256) ~= "number" and 0 or v256) + 1)
	end
	return math.deg(v255)
end
v_u_8.AMMO_NOUN = {
	["arrows"] = "ARROWS",
	["shot"] = "BULLETS",
	["fire_arrows"] = "FIRE ARROWS"
}
v_u_8.AMMO_OUT = {
	["arrows"] = "OUT OF ARROWS",
	["shot"] = "OUT OF BULLETS"
}
local v_u_257 = nil
local function v_u_265(p258) -- name: altAmmo
	-- upvalues: (ref) v_u_257, (copy) v_u_11
	if v_u_257 == nil then
		local v259 = require
		local v260 = v_u_11
		local v261, v262 = pcall(v259, v260:WaitForChild("Weapons"))
		if not v261 then
			v262 = false
		end
		v_u_257 = v262
	end
	local v263 = v_u_257
	if v263 then
		local v264 = v263.AltAmmo
		if type(v264) == "function" then
			return v263.AltAmmo(p258)
		end
	end
	return {}
end
function v_u_8.AmmoLeft(p266, p267) -- name: AmmoLeft
	-- upvalues: (copy) v_u_265
	if not p266 or type(p267) ~= "string" then
		return (1 / 0)
	end
	local v268 = p266:GetAttribute("Ammo_" .. p267)
	local v269 = type(v268) ~= "number" and 0 or v268
	for _, v270 in v_u_265(p267) do
		local v271 = p266:GetAttribute("Ammo_" .. v270)
		v269 = v269 + (type(v271) ~= "number" and 0 or v271)
	end
	return v269
end
function v_u_8.AmmoNext(p272, p273) -- name: AmmoNext
	-- upvalues: (copy) v_u_265
	if not p272 or type(p273) ~= "string" then
		return nil
	end
	for _, v274 in v_u_265(p273) do
		local v275 = p272:GetAttribute("Ammo_" .. v274)
		if (type(v275) ~= "number" and 0 or v275) < 1 then
			continue
		end
		return v274
	end
	return nil
end
function v_u_8.AmmoShown(p276, p277) -- name: AmmoShown
	-- upvalues: (copy) v_u_8
	local v278 = v_u_8.AmmoNext(p276, p277)
	if not (v278 and p276) then
		return v_u_8.AmmoLeft(p276, p277), v_u_8.AMMO_NOUN[p277]
	end
	local v279 = p276:GetAttribute("Ammo_" .. v278)
	return type(v279) ~= "number" and 0 or v279, v_u_8.AMMO_NOUN[v278] or v_u_8.AMMO_NOUN[p277]
end
function v_u_8.ShotKind(p280, p281, p282) -- name: ShotKind
	-- upvalues: (copy) v_u_8
	if v_u_8.AmmoNext(p280, p281) == "fire_arrows" then
		return "Fire" .. p282
	else
		return p282
	end
end
function v_u_8.WatchAmmo(p283, p284, p285) -- name: WatchAmmo
	-- upvalues: (copy) v_u_265
	local v286 = { p283:GetAttributeChangedSignal("Ammo_" .. p284):Connect(p285) }
	for _, v287 in v_u_265(p284) do
		local v288 = p283:GetAttributeChangedSignal("Ammo_" .. v287)
		table.insert(v286, v288:Connect(p285))
	end
	return v286
end
local v_u_289 = v10:WaitForChild("Sounds", 10)
local v_u_290 = {}
local function v_u_296(p291) -- name: findSound
	-- upvalues: (copy) v_u_290, (copy) v_u_289
	local v292 = v_u_290[p291]
	if v292 ~= nil then
		return v292 or nil
	end
	if not v_u_289 then
		return nil
	end
	local v293 = v_u_289
	for v294 in string.gmatch(p291, "[^/]+") do
		if not v293 then
			continue
		end
		v293 = v293:FindFirstChild(v294)
	end
	local v295 = v293 or v_u_289:FindFirstChild(p291, true)
	if not (v295 and v295:IsA("Sound")) then
		v295 = nil
	end
	v_u_290[p291] = v295 or false
	return v295
end
local v_u_297 = 0
local v_u_298 = {}
function v_u_8.Sound(p299, p300, p301) -- name: Sound
	-- upvalues: (copy) v_u_296, (copy) v_u_9, (ref) v_u_297, (copy) v_u_7, (copy) v_u_298, (copy) v_u_6, (ref) v_u_14, (copy) v_u_5
	local v302 = v_u_296(p299)
	local v303
	if typeof(p300) == "Vector3" then
		v303 = p300
	elseif typeof(p300) == "Instance" then
		if p300:IsA("BasePart") then
			v303 = p300.Position
		elseif p300:IsA("Attachment") then
			v303 = p300.WorldPosition
		else
			v303 = nil
		end
	else
		v303 = nil
	end
	if v303 then
		local v304 = workspace.CurrentCamera
		local v305 = v_u_9.Character
		local v306
		if v305 == nil or typeof(p300) ~= "Instance" then
			v306 = false
		else
			v306 = p300:IsDescendantOf(v305)
		end
		local v307 = not v304 and 0 or (v304.CFrame.Position - v303).Magnitude
		if not v306 then
			local v308
			if v302 then
				local v309 = v302.RollOffMaxDistance
				v308 = math.clamp(v309, 60, 250)
			else
				v308 = 200
			end
			if v308 < v307 then
				return nil
			end
			if v_u_297 >= v_u_7.maxSounds and v307 > 25 then
				return nil
			end
			local v310 = os.clock()
			local v311 = v_u_298[p299]
			if v311 and (v310 - v311.t < 0.035 and (v311.p - v303).Magnitude < 8) then
				return nil
			end
			v_u_298[p299] = {
				["t"] = v310,
				["p"] = v303
			}
		end
	end
	local v312 = p301 and (p301.PlaybackSpeed or 1) or 1
	local v313 = p301 and (p301.Volume or 1) or 1
	if v303 then
		v_u_297 = v_u_297 + 1
		v_u_6.sounds = v_u_297
		local v314 = (not v302 or v302.TimeLength <= 0) and 1.5 or v302.TimeLength / math.max(0.05, v312)
		local v315 = task.delay
		local v316 = v314 + 0.2
		v315(math.min(v316, 6), function()
			-- upvalues: (ref) v_u_297, (ref) v_u_6
			v_u_297 = v_u_297 - 1
			v_u_6.sounds = v_u_297
		end)
	end
	if v_u_14 then
		local v317
		if p301 then
			v317 = {
				["volume"] = v313
			}
			local v318
			if p301.PlaybackSpeed then
				v318 = v312
			else
				v318 = nil
			end
			v317.pitch = v318
		else
			v317 = nil
		end
		local v319 = v_u_14.Play
		local v320, v321 = pcall(v319, p299, p300, v317)
		if v320 then
			if typeof(v321) == "Instance" and v321:IsA("Sound") then
				return v321
			else
				return nil
			end
		end
	end
	if not v302 then
		return nil
	end
	local v322 = v302:GetAttribute("PitchVary")
	local v323 = v312 * (1 + (math.random() * 2 - 1) * (type(v322) ~= "number" and 0.05 or v322))
	local v_u_324 = v302:Clone()
	v_u_324.PlaybackSpeed = v_u_324.PlaybackSpeed * v323
	v_u_324.Volume = v_u_324.Volume * v313
	local v325 = v_u_5:FindFirstChild("SFX")
	if v325 and v325:IsA("SoundGroup") then
		v_u_324.SoundGroup = v325
	end
	local v_u_326 = nil
	if typeof(p300) == "Vector3" then
		v_u_326 = Instance.new("Attachment")
		v_u_326.WorldPosition = p300
		v_u_326.Parent = workspace.Terrain
		v_u_324.Parent = v_u_326
	elseif typeof(p300) == "Instance" and (p300:IsA("BasePart") or p300:IsA("Attachment")) then
		v_u_324.Parent = p300
	else
		v_u_324.Parent = v_u_5
	end
	v_u_324:Play()
	local v327
	if v_u_324.TimeLength > 0 then
		local v328 = v_u_324.TimeLength
		local v329 = v_u_324.PlaybackSpeed
		v327 = v328 / math.max(0.05, v329)
	else
		v327 = 3
	end
	local v330 = v327 + 0.2
	task.delay(math.min(v330, 12), function()
		-- upvalues: (copy) v_u_324, (ref) v_u_326
		v_u_324:Destroy()
		if v_u_326 then
			v_u_326:Destroy()
		end
	end)
	return v_u_324
end
function v_u_8.Loop(p331, p332) -- name: Loop
	-- upvalues: (ref) v_u_14, (copy) v_u_296, (copy) v_u_5
	if v_u_14 then
		local v333 = v_u_14.Loop
		if type(v333) == "function" then
			local v334 = v_u_14.Loop
			local v335, v_u_336 = pcall(v334, p331, p332)
			if v335 and type(v_u_336) == "function" then
				return function(p337)
					-- upvalues: (copy) v_u_336
					local v338 = v_u_336
					pcall(v338, p337)
				end
			end
		end
	end
	local v339 = v_u_296(p331)
	if not v339 then
		return function() end
	end
	local v_u_340 = v339:Clone()
	v_u_340.Looped = true
	v_u_340.Parent = p332 or v_u_5
	v_u_340:Play()
	return function()
		-- upvalues: (copy) v_u_340
		v_u_340:Destroy()
	end
end
local v_u_341 = v10:WaitForChild("Animations", 10)
local v_u_342 = {}
function v_u_8.GetTrack(p_u_343, p344) -- name: GetTrack
	-- upvalues: (copy) v_u_341, (copy) v_u_342
	if not (p_u_343 and v_u_341) then
		return nil
	end
	local v345 = v_u_342[p_u_343]
	if not v345 then
		local v_u_346 = {}
		v_u_342[p_u_343] = v_u_346
		p_u_343.Destroying:Once(function()
			-- upvalues: (ref) v_u_342, (copy) p_u_343
			v_u_342[p_u_343] = nil
		end)
		p_u_343.AncestryChanged:Connect(function()
			-- upvalues: (copy) p_u_343, (ref) v_u_342, (ref) v_u_346
			if not p_u_343:IsDescendantOf(game) and v_u_342[p_u_343] == v_u_346 then
				task.delay(20, function()
					-- upvalues: (ref) v_u_342, (ref) p_u_343, (ref) v_u_346
					if v_u_342[p_u_343] == v_u_346 and not p_u_343:IsDescendantOf(game) then
						v_u_342[p_u_343] = nil
						for _, v_u_347 in v_u_346 do
							pcall(function()
								-- upvalues: (copy) v_u_347
								v_u_347:Stop(0)
								v_u_347:Destroy()
							end)
						end
					end
				end)
			end
		end)
		v345 = v_u_346
	end
	local v348 = v345[p344]
	if v348 then
		return v348
	end
	local v_u_349 = v_u_341:FindFirstChild(p344)
	if not (v_u_349 and v_u_349:IsA("Animation")) then
		return nil
	end
	local v350, v351 = pcall(function()
		-- upvalues: (copy) p_u_343, (copy) v_u_349
		return p_u_343:LoadAnimation(v_u_349)
	end)
	if not (v350 and v351) then
		return nil
	end
	local v352 = v_u_349:GetAttribute("Priority")
	if type(v352) == "string" and Enum.AnimationPriority[v352] then
		v351.Priority = Enum.AnimationPriority[v352]
	else
		v351.Priority = Enum.AnimationPriority.Action
	end
	local v353 = v_u_349:GetAttribute("Looped")
	if type(v353) == "boolean" then
		v351.Looped = v353
	end
	v345[p344] = v351
	return v351
end
local v_u_354 = nil
function v_u_8.SetAnimRelay(p355) -- name: SetAnimRelay
	-- upvalues: (ref) v_u_354
	v_u_354 = p355
end
local function v_u_364(p356, p357, p358, p359, p360) -- name: playAnim
	-- upvalues: (copy) v_u_8, (copy) v_u_341
	if not p357 then
		return nil
	end
	local v361 = v_u_8.GetTrack(p356, p357)
	if not v361 then
		return nil
	end
	local v362 = p358 or 1
	local v363 = v_u_341
	if v363 then
		v363 = v_u_341:FindFirstChild(p357)
	end
	if v363 then
		v363 = v363:GetAttribute("Speed")
	end
	if type(v363) == "number" then
		v362 = v362 * v363
	end
	v361:Play(p359 or 0.08, p360 or 1, v362)
	return v361
end
function v_u_8.PlayAnim(p365, p366, p367, p368, p369) -- name: PlayAnim
	-- upvalues: (copy) v_u_364, (ref) v_u_354, (copy) v_u_9
	local v370 = v_u_364(p365, p366, p367, p368, p369)
	if v370 and p366 then
		local v371 = v_u_354
		local v372 = v_u_9.Character
		if v371 and (p365 and (v372 and p365:IsDescendantOf(v372))) then
			v371:FireServer("Play", p366, p367 or 1, p368 or 0.08, p369 or 1)
		end
	end
	return v370
end
function v_u_8.PlayHold(p373, p374, p375) -- name: PlayHold
	-- upvalues: (copy) v_u_364, (ref) v_u_354, (copy) v_u_9
	local v_u_376 = v_u_364(p373, p374, p375, 0.08)
	if not v_u_376 then
		return nil
	end
	local v377 = v_u_354
	local v378 = v_u_9.Character
	if v377 and (p373 and (v378 and p373:IsDescendantOf(v378))) then
		v377:FireServer("Hold", p374, p375 or 1, 0.08, 1)
	end
	task.spawn(function()
		-- upvalues: (copy) v_u_376
		local v379 = os.clock()
		while v_u_376.Length == 0 and os.clock() - v379 < 2 do
			task.wait()
		end
		local v380 = v_u_376.Speed
		local v381 = math.max(0.05, v380)
		local v382 = task.wait
		local v383 = v_u_376.Length / v381 - 0.04
		v382((math.max(0, v383)))
		if v_u_376.IsPlaying then
			local v384 = v_u_376
			local v385 = v_u_376.Length - 0.03
			v384.TimePosition = math.max(0, v385)
			v_u_376:AdjustSpeed(0)
		end
	end)
	return v_u_376
end
function v_u_8.StopAnim(p386, p387, p388) -- name: StopAnim
	-- upvalues: (copy) v_u_342, (ref) v_u_354, (copy) v_u_9
	if p386 and p387 then
		local v389 = v_u_342[p386]
		if v389 then
			v389 = v389[p387]
		end
		if v389 and v389.IsPlaying then
			v389:Stop(p388 or 0.12)
			local v390 = p388 or 0.12
			local v391 = v_u_354
			local v392 = v_u_9.Character
			if v391 and (p386 and (v392 and p386:IsDescendantOf(v392))) then
				v391:FireServer("Stop", p387, 1, v390 or 0.08, 1)
			end
		end
	end
end
function v_u_8.Preload(p393) -- name: Preload
	-- upvalues: (copy) v_u_341, (copy) v_u_8
	if v_u_341 then
		for _, v394 in v_u_341:GetChildren() do
			if not v394:IsA("Animation") then
				continue
			end
			v_u_8.GetTrack(p393, v394.Name)
		end
	end
end
function v_u_8.ToolPoint(p395, p396) -- name: ToolPoint
	if p395 then
		local v397 = p395:FindFirstChild(p396, true)
		if v397 and v397:IsA("Attachment") then
			return v397.WorldPosition
		else
			local v398 = p395:FindFirstChild("Handle")
			if v398 and v398:IsA("BasePart") then
				return v398.Position
			else
				return nil
			end
		end
	else
		return nil
	end
end
local function v_u_410(p399, p400) -- name: sightOrigin
	-- upvalues: (copy) v_u_8
	if v_u_8.InFirstPerson() then
		return p400
	else
		local v401 = v_u_8.AimPoint()
		local v402 = v401 - p400
		if v402.Magnitude < 3.5 then
			return p400
		else
			local v403 = v_u_8.WorldParams(v_u_8.Targets())
			if workspace:Raycast(p400, v402.Unit * (v402.Magnitude - 1.5), v403) then
				local v404 = v_u_8.GetAimRay()
				local v405 = v404.Direction.Unit
				local v406 = v404.Origin
				local v407 = (p399 - v404.Origin):Dot(v405)
				local v408 = v406 + v405 * math.max(v407, 0)
				local v409 = v401 - v408
				if (v408 - p399).Magnitude > 7 or (v409.Magnitude < 3.5 or v409.Unit:Dot(v405) < 0.9) then
					return p400
				elseif workspace:Raycast(p399, v408 - p399, v403) or workspace:Raycast(v408, v409.Unit * (v409.Magnitude - 1.5), v403) then
					return p400
				else
					return v408
				end
			else
				return p400
			end
		end
	end
end
function v_u_8.ShotOrigin(p411, p412) -- name: ShotOrigin
	-- upvalues: (copy) v_u_9, (copy) v_u_8, (copy) v_u_410
	local v413 = v_u_9.Character
	local v414
	if v413 then
		v414 = v413:FindFirstChild("Head")
	else
		v414 = v413
	end
	if v413 then
		v413 = v413:FindFirstChild("HumanoidRootPart")
	end
	local v415
	if v414 then
		v415 = v414.Position
	else
		v415 = not v413 and Vector3.new(0, 0, 0) or v413.Position + Vector3.new(0, 1.5, 0)
	end
	local v416 = v_u_8.ToolPoint(p411, p412 or "Muzzle")
	if v416 and (v416 - v415).Magnitude <= 7 then
		if workspace:Raycast(v415, v416 - v415, v_u_8.WorldParams(v_u_8.Targets())) then
			return v_u_410(v415, v415)
		else
			return v_u_410(v415, v416)
		end
	else
		return v415
	end
end
return v_u_8