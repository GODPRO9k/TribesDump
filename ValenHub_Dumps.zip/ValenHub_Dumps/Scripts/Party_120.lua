local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("Workspace")
return {
	["Init"] = function(p_u_4) -- name: Init
		-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_3
		local v_u_5 = p_u_4.UI
		local v_u_6 = p_u_4.Theme
		local v_u_7 = p_u_4.State
		local v_u_8 = v_u_6.Colors
		local v_u_9 = v_u_6.Fonts
		local v_u_10 = v_u_1.LocalPlayer
		local v_u_11 = {
			["enabled"] = false,
			["party"] = false,
			["invites"] = nil,
			["outgoing"] = nil,
			["max"] = 3,
			["canInvite"] = false,
			["role"] = "Hub",
			["serverNow"] = 0,
			["invites"] = {},
			["outgoing"] = {}
		}
		local v_u_12 = os.clock()
		local v_u_13 = v_u_5.new("Frame", {
			["Name"] = "PartyHud",
			["Size"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = p_u_4.Canvas.HUD
		})
		local v_u_14 = v_u_5.new("Frame", {
			["Name"] = "PartyPop",
			["Size"] = nil,
			["ZIndex"] = 10,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = p_u_4.Canvas.HUD
		})
		local v_u_15 = {}
		local function v_u_19(...) -- name: action
			-- upvalues: (copy) p_u_4
			local v16, v17, v18 = p_u_4.Remotes.Invoke("PartyAction", ...)
			if not v16 then
				p_u_4.Toast("Server unavailable", "error")
				return false
			end
			if v17 == true then
				return true
			end
			if v18 then
				p_u_4.Toast(tostring(v18), "error")
			end
			return false
		end
		local function v_u_24() -- name: members
			-- upvalues: (ref) v_u_11, (copy) v_u_10
			if v_u_11.party == false then
				return {
					{
						["userId"] = nil,
						["name"] = nil,
						["username"] = nil,
						["present"] = true,
						["userId"] = v_u_10.UserId,
						["name"] = v_u_10.DisplayName,
						["username"] = v_u_10.Name
					}
				}
			end
			local v20 = table.clone(v_u_11.party.members)
			table.sort(v20, function(p21, p22)
				-- upvalues: (ref) v_u_11
				local v23 = p21.userId == v_u_11.party.leaderId
				if v23 == (p22.userId == v_u_11.party.leaderId) then
					return false
				else
					return v23
				end
			end)
			return v20
		end
		local function v_u_27(p25, p26) -- name: crown
			-- upvalues: (copy) v_u_5
			return v_u_5.new("TextLabel", {
				["Name"] = "Crown",
				["Size"] = nil,
				["Text"] = "\240\159\145\145",
				["TextSize"] = nil,
				["TextScaled"] = false,
				["Rotation"] = -30,
				["ZIndex"] = 5,
				["Parent"] = nil,
				["Size"] = UDim2.fromOffset(p26, p26),
				["TextSize"] = p26,
				["Parent"] = p25
			})
		end
		local v_u_28 = v_u_5.new("Frame", {
			["Name"] = "PartyRow",
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 1),
			["Size"] = UDim2.fromOffset(188, 108),
			["Parent"] = v_u_13
		})
		local v_u_29 = v_u_5.new("TextLabel", {
			["Name"] = "Caption",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "PARTY",
			["FontFace"] = nil,
			["TextSize"] = 14,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, -2, 0, 0),
			["Size"] = UDim2.fromOffset(320, 16),
			["FontFace"] = v_u_9.Heavy,
			["TextColor3"] = v_u_8.TextDim,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["Parent"] = v_u_28
		})
		v_u_5.TextStroke(v_u_8.Void, 1.5, 0.35).Parent = v_u_29
		local v_u_30 = v_u_5.new("Frame", {
			["Name"] = "Seats",
			["Position"] = UDim2.fromOffset(0, 32),
			["Size"] = UDim2.new(1, 0, 0, 76),
			v_u_5.List(Enum.FillDirection.Horizontal, 10, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Top),
			["Parent"] = v_u_28
		})
		local v_u_31 = {}
		local function v40(p32) -- name: makeSeat
			-- upvalues: (copy) v_u_5, (copy) v_u_30, (copy) v_u_8, (copy) v_u_6, (copy) v_u_9, (copy) v_u_27
			local v33 = v_u_5.new("TextButton", {
				["Name"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["LayoutOrder"] = nil,
				["Parent"] = nil,
				["Name"] = "Seat" .. p32,
				["Size"] = UDim2.fromOffset(56, 76),
				["LayoutOrder"] = p32,
				["Parent"] = v_u_30
			})
			local v34 = v_u_5.new("Frame", {
				["Name"] = "Circle",
				["Size"] = UDim2.fromOffset(56, 56),
				["BackgroundColor3"] = v_u_8.Panel,
				["BackgroundTransparency"] = 0.15,
				v_u_5.Corner(v_u_6.Radius.Pill),
				["Parent"] = v33
			})
			local v35 = v_u_5.Stroke(v_u_8.Stroke, 2, 0.75)
			v35.Parent = v34
			local v36 = v_u_5.new("ImageLabel", {
				["Name"] = "Headshot",
				["Size"] = UDim2.fromScale(1, 1),
				["BackgroundTransparency"] = 1,
				["Image"] = "",
				v_u_5.Corner(v_u_6.Radius.Pill),
				["Parent"] = v34
			})
			local v37 = v_u_5.Icon("plus", 22, v_u_8.TextDim, {
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Parent"] = v34
			})
			local v38 = v_u_5.new("TextLabel", {
				["Name"] = "Name",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 13,
				["TextColor3"] = nil,
				["TextTruncate"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 59),
				["Size"] = UDim2.fromOffset(76, 16),
				["FontFace"] = v_u_9.Bold,
				["TextColor3"] = v_u_8.Text,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v33
			})
			v_u_5.TextStroke(v_u_8.Void, 1.5, 0.3).Parent = v38
			local v39 = v_u_27(v33, 28)
			v39.AnchorPoint = Vector2.new(0.5, 0.5)
			v39.Position = UDim2.new(0.13, 0, 0.12, 0)
			v39.Visible = false
			return {
				["btn"] = nil,
				["ring"] = nil,
				["img"] = nil,
				["plus"] = nil,
				["name"] = nil,
				["crown"] = nil,
				["userId"] = nil,
				["btn"] = v33,
				["ring"] = v35,
				["img"] = v36,
				["plus"] = v37,
				["name"] = v38,
				["crown"] = v39
			}
		end
		v_u_31[1] = v40(1)
		v_u_31[2] = v40(2)
		v_u_31[3] = v40(3)
		local v_u_41 = require(script.Parent.Parent:WaitForChild("SettingsStore"))
		local v_u_42 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("MatchPrefs"))
		local v_u_43 = v_u_5.new("Frame", {
			["Name"] = "PremiumPill",
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, 0, 0, 0),
			["Size"] = UDim2.fromOffset(0, 26),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["BackgroundColor3"] = v_u_8.Panel,
			["BackgroundTransparency"] = 0.1,
			["Visible"] = false,
			v_u_5.Corner(v_u_6.Radius.Pill),
			v_u_5.Padding(0, 12, 0, 5),
			v_u_5.List(Enum.FillDirection.Horizontal, 7, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
			["Parent"] = v_u_28
		})
		local v_u_44 = v_u_5.Stroke(v_u_8.Gold, 1.5, 0.15)
		v_u_44.Parent = v_u_43
		local v_u_45 = v_u_5.new("ImageLabel", {
			["Name"] = "Robux",
			["Size"] = nil,
			["BackgroundTransparency"] = 1,
			["Image"] = "rbxasset://textures/ui/common/robux@3x.png",
			["ImageColor3"] = nil,
			["ScaleType"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(18, 18),
			["ImageColor3"] = v_u_8.Gold,
			["ScaleType"] = Enum.ScaleType.Fit,
			["Parent"] = v_u_43
		})
		local v_u_46 = v_u_5.new("Frame", {
			["Name"] = "Alert",
			["Size"] = UDim2.fromOffset(18, 18),
			["BackgroundColor3"] = v_u_8.Danger,
			["LayoutOrder"] = 1,
			["Visible"] = false,
			v_u_5.Corner(18),
			["Parent"] = v_u_43
		})
		local v47 = Color3.fromRGB(255, 255, 255)
		v_u_5.new("Frame", {
			["Name"] = "Bar",
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 4),
			["Size"] = UDim2.fromOffset(3, 7),
			["BackgroundColor3"] = v47,
			v_u_5.Corner(2),
			["Parent"] = v_u_46
		})
		v_u_5.new("Frame", {
			["Name"] = "Dot",
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 12),
			["Size"] = UDim2.fromOffset(3, 3),
			["BackgroundColor3"] = v47,
			v_u_5.Corner(2),
			["Parent"] = v_u_46
		})
		local v_u_48 = v_u_5.new("TextLabel", {
			["Name"] = "Text",
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["BackgroundTransparency"] = 1,
			["Text"] = "PREMIUM ONLY QUEUE",
			["FontFace"] = nil,
			["TextSize"] = 13,
			["TextColor3"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(0, 26),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["FontFace"] = v_u_9.Heavy,
			["TextColor3"] = v_u_8.Gold,
			["Parent"] = v_u_43
		})
		local v_u_49 = {}
		local v_u_50 = {}
		local function v_u_71() -- name: paintPremium
			-- upvalues: (copy) v_u_24, (copy) v_u_41, (copy) v_u_49, (copy) v_u_10, (ref) v_u_1, (ref) v_u_50, (copy) v_u_42, (copy) v_u_43, (copy) v_u_48, (copy) v_u_8, (copy) v_u_44, (copy) v_u_45, (copy) v_u_46, (copy) v_u_29, (copy) v_u_30, (copy) v_u_28, (copy) v_u_31
			local v51 = v_u_24()
			local v52 = v_u_41.Get("mmPremium") > 0.5
			table.clear(v_u_49)
			local v53 = {}
			local v54 = true
			for _, v55 in v51 do
				local v56
				if v55.userId == v_u_10.UserId then
					v56 = v_u_10
				else
					v56 = v_u_1:GetPlayerByUserId(v55.userId)
				end
				local v57
				if v56 == nil then
					v57 = v_u_50[v55.userId]
				else
					v57 = nil
				end
				v52 = (v56 and (v56 ~= v_u_10 and v56:GetAttribute(v_u_42.PREMIUM_WANT_ATTR) == true) or v57 == "want") and true or v52
				local v58
				if v56 then
					v58 = v56:GetAttribute(v_u_42.PREMIUM_ATTR) == true
				else
					v58 = v57 ~= nil
				end
				if v58 then
					continue
				end
				v54 = false
				if v56 == v_u_10 or not v55.present then
					continue
				end
				table.insert(v53, v55)
				v_u_49[v55.userId] = true
			end
			local v59
			if v_u_41.Get("mmPremium") > 0.5 then
				v59 = v_u_10:GetAttribute(v_u_42.PREMIUM_ATTR) == true
			else
				v59 = false
			end
			local v60 = v52 and v54
			local v61 = v59 and not v54
			if v61 then
				v61 = #v53 > 0
			end
			v_u_43.Visible = v60 or v61
			if v60 then
				v_u_48.Text = "PREMIUM ONLY QUEUE"
				v_u_48.TextColor3 = v_u_8.Gold
				v_u_44.Color = v_u_8.Gold
				v_u_45.Visible = true
				v_u_46.Visible = false
			elseif v61 then
				local v62 = v_u_48
				local v63
				if #v53 == 1 then
					v63 = string.format("PREMIUM ONLY QUEUE OFF: %s ISN\'T PREMIUM", string.upper(v53[1].name or "A MEMBER"))
				else
					v63 = string.format("PREMIUM ONLY QUEUE OFF: %d MEMBERS AREN\'T PREMIUM", #v53)
				end
				v62.Text = v63
				v_u_48.TextColor3 = v_u_8.Danger
				v_u_44.Color = v_u_8.Danger
				v_u_45.Visible = false
				v_u_46.Visible = true
			end
			local v64 = v_u_43.Visible and 34 or 0
			v_u_29.Position = UDim2.new(1, -2, 0, v64)
			v_u_30.Position = UDim2.fromOffset(0, v64 + 32)
			v_u_28.Size = UDim2.fromOffset(188, v64 + 108)
			for v65, v66 in v_u_31 do
				local v67 = v51[v65]
				if not v67 then
					continue
				end
				local v68
				if v61 then
					v68 = v_u_49[v67.userId] == true
				else
					v68 = v61
				end
				local v69 = v66.ring
				local v70
				if v68 then
					v70 = v_u_8.Danger
				elseif v67.userId == v_u_10.UserId then
					v70 = v_u_8.Accent
				else
					v70 = v_u_8.Stroke
				end
				v69.Color = v70
				v66.ring.Transparency = v68 and 0 or (v67.userId == v_u_10.UserId and 0.1 or 0.6)
			end
		end
		v_u_41.Changed:Connect(function(p72)
			-- upvalues: (copy) v_u_71
			if p72 == "mmPremium" then
				v_u_71()
			end
		end)
		v_u_10:GetAttributeChangedSignal(v_u_42.PREMIUM_ATTR):Connect(v_u_71)
		local v_u_73 = nil
		local function v_u_74() -- name: closePop
			-- upvalues: (ref) v_u_73, (copy) p_u_4
			if v_u_73 then
				v_u_73:Destroy()
				v_u_73 = nil
				p_u_4.MenuManager.PopFocus("PartyPop")
			end
		end
		local function v_u_79() -- name: popDefault
			-- upvalues: (ref) v_u_73
			local v75 = v_u_73
			if not v75 then
				return nil
			end
			local v76 = nil
			local v77 = nil
			for _, v78 in v75:GetDescendants() do
				if not (v78:IsA("GuiButton") and (v78.Visible and v78.Selectable)) then
					continue
				end
				if v78.Name == "Close" then
					v77 = v78
				else
					if v76 and v78.AbsolutePosition.Y >= v76.AbsolutePosition.Y then
						continue
					end
					v76 = v78
				end
			end
			return v76 or v77
		end
		local function v_u_83(p80, p81) -- name: popPanel
			-- upvalues: (ref) v_u_73, (copy) p_u_4, (copy) v_u_5, (copy) v_u_14
			if v_u_73 then
				v_u_73:Destroy()
				v_u_73 = nil
				p_u_4.MenuManager.PopFocus("PartyPop")
			end
			local v82 = v_u_5.Panel({
				["Name"] = nil,
				["Size"] = nil,
				["BackgroundTransparency"] = 0.04,
				["StrokeTransparency"] = 0.8,
				["ZIndex"] = 20,
				["Parent"] = nil,
				["Name"] = p80,
				["Size"] = UDim2.fromOffset(p81.X, p81.Y),
				["Parent"] = v_u_14
			})
			v_u_5.DropShadow(v82, 12, 5, 0.4)
			v_u_73 = v82
			return v82
		end
		local function v_u_87(p84, p85) -- name: popTitle
			-- upvalues: (copy) v_u_5, (copy) v_u_9, (copy) v_u_8, (copy) v_u_74
			local v86 = v_u_5.new("TextLabel", {
				["Name"] = "Title",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 22,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["ZIndex"] = 21,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(16, 12),
				["Size"] = UDim2.new(1, -70, 0, 26),
				["Text"] = p85,
				["FontFace"] = v_u_9.Display,
				["TextColor3"] = v_u_8.Text,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Parent"] = p84
			})
			v_u_5.IconButton({
				["Name"] = "Close",
				["IconName"] = "cross",
				["Size"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["ZIndex"] = 22,
				["Parent"] = nil,
				["OnClick"] = nil,
				["Size"] = UDim2.fromOffset(38, 38),
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.new(1, -8, 0, 8),
				["Parent"] = p84,
				["OnClick"] = v_u_74
			})
			return v86
		end
		local function v_u_101(p88) -- name: placePop
			-- upvalues: (copy) v_u_28, (copy) p_u_4, (copy) v_u_5, (copy) v_u_79, (ref) v_u_73
			local v89 = v_u_28.AbsolutePosition
			local v90 = p_u_4.Canvas.HUD
			local v91 = v_u_5.Scale
			local v92 = math.max(v91, 0.01)
			local v93 = v90.AbsolutePosition
			local v94 = (v89.X - v93.X) / v92
			local v95 = v94 + v_u_28.AbsoluteSize.X / v92
			local v96 = (v89.Y - v93.Y) / v92
			if v_u_5.Compact then
				p88.AnchorPoint = Vector2.new(1, 0)
				local v97 = UDim2.fromOffset
				local v98 = v94 - 12
				local v99 = v_u_5.TopInset()
				local v100 = v96 - 60
				p88.Position = v97(v98, (math.max(v99, v100)))
			else
				p88.AnchorPoint = Vector2.new(1, 1)
				p88.Position = UDim2.fromOffset(v95, v96 + 24)
			end
			v_u_5.Enter(p88, Vector2.new(0, 10))
			p_u_4.MenuManager.PushFocus("PartyPop", v_u_79, function()
				-- upvalues: (ref) v_u_73, (ref) p_u_4
				if v_u_73 then
					v_u_73:Destroy()
					v_u_73 = nil
					p_u_4.MenuManager.PopFocus("PartyPop")
				end
				return true
			end)
		end
		local v_u_102 = nil
		local function v_u_109(p103) -- name: inviteStatus
			-- upvalues: (ref) v_u_11, (copy) v_u_7
			if v_u_11.party ~= false then
				for _, v104 in v_u_11.party.members do
					if v104.userId ~= p103 then
						continue
					end
					return "IN PARTY", false
				end
			end
			local v105 = v_u_11.outgoing[tostring(p103)]
			if type(v105) == "number" then
				local v106 = v105 - v_u_7.Now()
				local v107 = math.ceil(v106)
				local v108 = math.max(0, v107)
				if v108 > 0 then
					return string.format("INVITED 0:%02d", v108), false
				end
			end
			if v_u_11.canInvite then
				return "INVITE", true
			else
				return "INVITE", false
			end
		end
		local v_u_110 = {}
		local v_u_111 = 0
		local v_u_112 = nil
		local v_u_113 = {}
		local v_u_114 = {}
		local function v_u_130(p_u_115, p_u_116, p117, p118) -- name: makeRow
			-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_6, (ref) v_u_102, (copy) v_u_15, (ref) v_u_1, (copy) v_u_9, (copy) v_u_19, (copy) p_u_4
			local v119 = v_u_5.new("Frame", {
				["Name"] = "P" .. p_u_115,
				["Size"] = UDim2.new(1, -8, 0, 54),
				["BackgroundColor3"] = v_u_8.PanelHi,
				["BackgroundTransparency"] = 0.35,
				["LayoutOrder"] = p118,
				["ZIndex"] = 21,
				v_u_5.Corner(v_u_6.Radius.Medium),
				["Parent"] = v_u_102.list
			})
			local v_u_120 = v_u_5.new("ImageLabel", {
				["Position"] = UDim2.fromOffset(8, 7),
				["Size"] = UDim2.fromOffset(40, 40),
				["BackgroundColor3"] = v_u_8.Panel,
				["ZIndex"] = 22,
				v_u_5.Corner(v_u_6.Radius.Pill),
				["Parent"] = v119
			})
			local v121 = v_u_15[p_u_115]
			if v121 then
				v_u_120.Image = v121
			else
				v_u_120.Image = ""
				task.spawn(function()
					-- upvalues: (ref) v_u_1, (copy) p_u_115, (ref) v_u_15, (copy) v_u_120
					local function v122()
						-- upvalues: (ref) v_u_1, (ref) p_u_115
						return v_u_1:GetUserThumbnailAsync(p_u_115, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size150x150)
					end
					local v123, v124 = pcall(v122)
					if v123 and type(v124) == "string" then
						v_u_15[p_u_115] = v124
						if v_u_120.Parent then
							v_u_120.Image = v124
						end
					end
				end)
			end
			local v125 = v_u_5.Stroke(v_u_8.Success, 1.5, 0.15)
			v125.Enabled = false
			v125.Parent = v119
			local v126 = v_u_5.new("TextLabel", {
				["Name"] = "FriendTag",
				["Position"] = UDim2.fromOffset(58, 29),
				["Size"] = UDim2.fromOffset(54, 17),
				["Text"] = "FRIEND",
				["FontFace"] = v_u_9.Heavy,
				["TextSize"] = 11,
				["TextColor3"] = v_u_8.TextDark,
				["BackgroundColor3"] = v_u_8.Success,
				["BackgroundTransparency"] = 0,
				["Visible"] = false,
				["ZIndex"] = 22,
				v_u_5.Corner(v_u_6.Radius.Pill),
				["Parent"] = v119
			})
			v_u_5.new("TextLabel", {
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 17,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["ZIndex"] = 22,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(58, 7),
				["Size"] = UDim2.new(1, -196, 0, 22),
				["Text"] = p_u_116,
				["FontFace"] = v_u_9.Heavy,
				["TextColor3"] = v_u_8.Text,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v119
			})
			local v127 = v_u_5.new("TextLabel", {
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 13,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["ZIndex"] = 22,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(58, 28),
				["Size"] = UDim2.new(1, -196, 0, 18),
				["Text"] = p117,
				["FontFace"] = v_u_9.Medium,
				["TextColor3"] = v_u_8.TextMuted,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v119
			})
			local v128 = v_u_5.Button({
				["Name"] = "Invite",
				["Text"] = "INVITE",
				["TextSize"] = 15,
				["Style"] = "Primary",
				["Size"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["ZIndex"] = 22,
				["Parent"] = nil,
				["OnClick"] = nil,
				["Size"] = UDim2.fromOffset(122, 40),
				["AnchorPoint"] = Vector2.new(1, 0.5),
				["Position"] = UDim2.new(1, -8, 0.5, 0),
				["Parent"] = v119,
				["OnClick"] = function() -- name: OnClick
					-- upvalues: (ref) v_u_19, (copy) p_u_115, (ref) p_u_4, (copy) p_u_116
					if v_u_19("Invite", p_u_115) then
						p_u_4.Toast(("Invite sent to %*"):format(p_u_116), "success")
					end
				end
			})
			v128.Instance.ZIndex = 22
			for _, v129 in v128.Instance:GetDescendants() do
				if not v129:IsA("GuiObject") then
					continue
				end
				v129.ZIndex = 23
			end
			return {
				["frame"] = nil,
				["button"] = nil,
				["stroke"] = nil,
				["tag"] = nil,
				["sub"] = nil,
				["friend"] = false,
				["frame"] = v119,
				["button"] = v128,
				["stroke"] = v125,
				["tag"] = v126,
				["sub"] = v127
			}
		end
		local function v_u_135(p131, p132) -- name: paintFriend
			-- upvalues: (copy) v_u_8
			if p131.friend ~= p132 then
				p131.friend = p132
				p131.stroke.Enabled = p132
				p131.tag.Visible = p132
				p131.sub.Position = UDim2.fromOffset(p132 and 118 or 58, 28)
				p131.sub.Size = UDim2.new(1, p132 and -256 or -196, 0, 18)
				local v133 = p131.frame
				local v134
				if p132 then
					v134 = v_u_8.PanelHi:Lerp(v_u_8.Success, 0.14)
				else
					v134 = v_u_8.PanelHi
				end
				v133.BackgroundColor3 = v134
			end
		end
		v_u_112 = function() -- name: refreshInviteList
			-- upvalues: (ref) v_u_102, (ref) v_u_1, (copy) v_u_10, (copy) v_u_130, (copy) v_u_113, (copy) v_u_114, (ref) v_u_112, (copy) v_u_135, (copy) v_u_109, (ref) v_u_110
			if v_u_102 and v_u_102.frame.Parent then
				local v136 = {}
				local v137 = 0
				for _, v138 in v_u_1:GetPlayers() do
					if v138 == v_u_10 then
						continue
					end
					v136[v138.UserId] = true
					v137 = v137 + 1
					local v139 = v_u_102.rows[v138.UserId]
					if not v139 then
						v139 = v_u_130(v138.UserId, v138.DisplayName, "@" .. v138.Name, v137)
						v_u_102.rows[v138.UserId] = v139
					end
					local v_u_140 = v138.UserId
					local v141 = v_u_113[v_u_140]
					if v141 == nil then
						if v_u_114[v_u_140] then
							v141 = false
						else
							v_u_114[v_u_140] = true
							task.spawn(function()
								-- upvalues: (ref) v_u_10, (copy) v_u_140, (ref) v_u_113, (ref) v_u_114, (ref) v_u_112
								local function v142()
									-- upvalues: (ref) v_u_10, (ref) v_u_140
									return v_u_10:IsFriendsWith(v_u_140)
								end
								local v143, v144 = pcall(v142)
								local v145 = v_u_113
								local v146 = v_u_140
								if v143 then
									v143 = v144 == true
								end
								v145[v146] = v143
								v_u_114[v_u_140] = nil
								if v_u_113[v_u_140] then
									v_u_112()
								end
							end)
							v141 = false
						end
					end
					v139.frame.LayoutOrder = (v141 and 0 or 600) + v137
					v_u_135(v139, v141)
					local v147, v148 = v_u_109(v138.UserId)
					v139.button:SetText(v147)
					v139.button:SetEnabled(v148)
					v139.button:SetStyle(v147 == "INVITE" and v148 and "Primary" or "Dark")
				end
				for v149, v150 in v_u_110 do
					if v136[v150.userId] or v_u_1:GetPlayerByUserId(v150.userId) then
						continue
					end
					v136[v150.userId] = true
					local v151 = v_u_102.rows[v150.userId]
					if not v151 then
						v151 = v_u_130(v150.userId, v150.name or "Friend", v150.where == "lobby" and "Another lobby" or "In a match", v149 + 300)
						v_u_102.rows[v150.userId] = v151
					end
					v_u_135(v151, true)
					if v150.where == "lobby" then
						local v152, v153 = v_u_109(v150.userId)
						v151.button:SetText(v152)
						v151.button:SetEnabled(v153)
						v151.button:SetStyle(v152 == "INVITE" and v153 and "Primary" or "Dark")
					else
						v151.button:SetText("IN A MATCH")
						v151.button:SetEnabled(false)
						v151.button:SetStyle("Dark")
					end
				end
				local v154 = 0
				for v155, v156 in v_u_102.rows do
					if v136[v155] then
						v154 = v154 + 1
					else
						v156.frame:Destroy()
						v_u_102.rows[v155] = nil
					end
				end
				v_u_102.empty.Visible = v154 == 0
			else
				v_u_102 = nil
			end
		end
		local function v_u_160() -- name: fetchFriends
			-- upvalues: (ref) v_u_111, (copy) p_u_4, (ref) v_u_110, (ref) v_u_112
			if os.clock() - v_u_111 >= 12 then
				v_u_111 = os.clock()
				task.spawn(function()
					-- upvalues: (ref) p_u_4, (ref) v_u_110, (ref) v_u_112
					local v157, v158, _, v159 = p_u_4.Remotes.Invoke("PartyAction", "Friends")
					if v157 and (v158 == true and type(v159) == "table") then
						v_u_110 = v159
						v_u_112()
					end
				end)
			end
		end
		local function v_u_162() -- name: openInviteList
			-- upvalues: (ref) v_u_102, (ref) v_u_73, (copy) p_u_4, (copy) v_u_83, (copy) v_u_87, (copy) v_u_5, (copy) v_u_9, (copy) v_u_8, (ref) v_u_112, (copy) v_u_160, (copy) v_u_101
			if v_u_102 and v_u_102.frame.Parent then
				if v_u_73 then
					v_u_73:Destroy()
					v_u_73 = nil
					p_u_4.MenuManager.PopFocus("PartyPop")
				end
				v_u_102 = nil
			else
				local v161 = v_u_83("InviteList", Vector2.new(360, 360))
				v_u_87(v161, "INVITE TO PARTY")
				v_u_102 = {
					["frame"] = v161,
					["list"] = v_u_5.new("ScrollingFrame", {
						["Name"] = "List",
						["Position"] = UDim2.fromOffset(8, 54),
						["Size"] = UDim2.new(1, -16, 1, -62),
						["ScrollBarThickness"] = 4,
						["ZIndex"] = 21,
						v_u_5.List(Enum.FillDirection.Vertical, 6, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Top),
						["Parent"] = v161
					}),
					["rows"] = {},
					["empty"] = v_u_5.new("TextLabel", {
						["Name"] = "Empty",
						["Position"] = nil,
						["Size"] = nil,
						["Text"] = "Nobody else is in this lobby yet. Friends playing Tribes elsewhere show up here too.",
						["TextWrapped"] = true,
						["FontFace"] = nil,
						["TextSize"] = 15,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["TextYAlignment"] = nil,
						["ZIndex"] = 21,
						["Visible"] = false,
						["Parent"] = nil,
						["Position"] = UDim2.fromOffset(16, 70),
						["Size"] = UDim2.new(1, -32, 0, 60),
						["FontFace"] = v_u_9.SemiBold,
						["TextColor3"] = v_u_8.TextDim,
						["TextXAlignment"] = Enum.TextXAlignment.Left,
						["TextYAlignment"] = Enum.TextYAlignment.Top,
						["Parent"] = v161
					})
				}
				v_u_112()
				v_u_160()
				v_u_101(v161)
			end
		end
		local function v_u_181(p_u_163) -- name: openSeatMenu
			-- upvalues: (copy) v_u_10, (ref) v_u_11, (copy) v_u_19, (copy) v_u_83, (copy) v_u_87, (copy) v_u_5, (copy) v_u_9, (copy) v_u_8, (ref) v_u_73, (copy) p_u_4, (copy) v_u_101
			local v164 = p_u_163.userId == v_u_10.UserId
			local v165 = {}
			if v164 and v_u_11.party ~= false then
				local v166 = {
					["text"] = "LEAVE PARTY",
					["style"] = "Danger",
					["fn"] = nil,
					["fn"] = function() -- name: fn
						-- upvalues: (ref) v_u_19
						v_u_19("Leave")
					end
				}
				table.insert(v165, v166)
			elseif not v164 then
				local v167
				if v_u_11.party == false then
					v167 = false
				else
					v167 = v_u_11.party.leaderId == v_u_10.UserId
				end
				if v167 and p_u_163.present then
					local v168 = {
						["text"] = "MAKE LEADER",
						["style"] = "Dark",
						["fn"] = nil,
						["fn"] = function() -- name: fn
							-- upvalues: (ref) v_u_19, (copy) p_u_163
							v_u_19("Promote", p_u_163.userId)
						end
					}
					table.insert(v165, v168)
					local v169 = {
						["text"] = "REMOVE",
						["style"] = "Danger",
						["fn"] = nil,
						["fn"] = function() -- name: fn
							-- upvalues: (ref) v_u_19, (copy) p_u_163
							v_u_19("Kick", p_u_163.userId)
						end
					}
					table.insert(v165, v169)
				end
			end
			local v170 = #v165 * 52 + 62 + (#v165 == 0 and 30 or 0)
			local v171 = v_u_83("SeatMenu", Vector2.new(260, v170))
			v_u_87(v171, string.upper(p_u_163.name or "Player"))
			if #v165 == 0 then
				local v172 = v_u_5.new
				local v173 = "TextLabel"
				local v174 = {
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = nil,
					["FontFace"] = nil,
					["TextSize"] = 15,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["ZIndex"] = 21,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(16, 50),
					["Size"] = UDim2.new(1, -32, 0, 30)
				}
				local v175 = p_u_163.userId
				local v176 = v_u_11.party
				if v176 then
					v176 = v_u_11.party.leaderId
				end
				v174.Text = v175 == v176 and "Party leader" or (p_u_163.present and "In your party" or "Joining...")
				v174.FontFace = v_u_9.SemiBold
				v174.TextColor3 = v_u_8.TextDim
				v174.TextXAlignment = Enum.TextXAlignment.Left
				v174.Parent = v171
				v172(v173, v174)
			end
			for v177, v_u_178 in v165 do
				local v179 = v_u_5.Button({
					["Name"] = nil,
					["Text"] = nil,
					["TextSize"] = 17,
					["Style"] = nil,
					["Size"] = nil,
					["Position"] = nil,
					["Parent"] = nil,
					["OnClick"] = nil,
					["Name"] = "Item" .. v177,
					["Text"] = v_u_178.text,
					["Style"] = v_u_178.style,
					["Size"] = UDim2.new(1, -24, 0, 44),
					["Position"] = UDim2.fromOffset(12, (v177 - 1) * 52 + 50),
					["Parent"] = v171,
					["OnClick"] = function() -- name: OnClick
						-- upvalues: (ref) v_u_73, (ref) p_u_4, (copy) v_u_178
						if v_u_73 then
							v_u_73:Destroy()
							v_u_73 = nil
							p_u_4.MenuManager.PopFocus("PartyPop")
						end
						v_u_178.fn()
					end
				})
				for _, v180 in v179.Instance:GetDescendants() do
					if not v180:IsA("GuiObject") then
						continue
					end
					v180.ZIndex = 23
				end
				v179.Instance.ZIndex = 22
			end
			v_u_101(v171)
		end
		local function v_u_202() -- name: render
			-- upvalues: (copy) v_u_24, (ref) v_u_11, (copy) v_u_31, (copy) v_u_15, (ref) v_u_1, (copy) v_u_10, (copy) v_u_8, (copy) v_u_29, (ref) v_u_102, (ref) v_u_112, (copy) v_u_71
			local v182 = v_u_24()
			local v183 = v_u_11.max or 3
			for v184, v185 in v_u_31 do
				local v186 = v182[v184]
				v185.btn.Visible = v184 <= v183
				if v186 then
					v185.userId = v186.userId
					local v_u_187 = v186.userId
					local v_u_188 = v185.img
					local v189 = v_u_15[v_u_187]
					if v189 then
						v_u_188.Image = v189
					else
						v_u_188.Image = ""
						task.spawn(function()
							-- upvalues: (ref) v_u_1, (copy) v_u_187, (ref) v_u_15, (copy) v_u_188
							local function v190()
								-- upvalues: (ref) v_u_1, (ref) v_u_187
								return v_u_1:GetUserThumbnailAsync(v_u_187, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size150x150)
							end
							local v191, v192 = pcall(v190)
							if v191 and type(v192) == "string" then
								v_u_15[v_u_187] = v192
								if v_u_188.Parent then
									v_u_188.Image = v192
								end
							end
						end)
					end
					v185.img.Visible = true
					v185.img.ImageTransparency = v186.present and 0 or 0.55
					v185.plus.Visible = false
					v185.name.Text = v186.userId == v_u_10.UserId and "YOU" or string.upper(v186.name or "")
					local v193 = v185.name
					local v194
					if v186.present then
						v194 = v_u_8.Text
					else
						v194 = v_u_8.TextMuted
					end
					v193.TextColor3 = v194
					local v195 = v185.ring
					local v196
					if v186.userId == v_u_10.UserId then
						v196 = v_u_8.Accent
					else
						v196 = v_u_8.Stroke
					end
					v195.Color = v196
					v185.ring.Transparency = v186.userId == v_u_10.UserId and 0.1 or 0.6
					local v197 = v185.crown
					local v198
					if v_u_11.party == false then
						v198 = false
					else
						v198 = v186.userId == v_u_11.party.leaderId
					end
					v197.Visible = v198
				else
					v185.userId = nil
					v185.img.Visible = false
					v185.plus.Visible = v_u_11.canInvite == true
					v185.name.Text = v_u_11.canInvite and "INVITE" or ""
					v185.name.TextColor3 = v_u_8.TextMuted
					v185.ring.Color = v_u_8.TextMuted
					v185.ring.Transparency = 0.55
					v185.crown.Visible = false
				end
			end
			if v_u_11.party == false then
				v_u_29.Text = "PARTY"
			else
				local v199 = v_u_29
				local v200
				if v_u_11.party == false then
					v200 = false
				else
					v200 = v_u_11.party.leaderId == v_u_10.UserId
				end
				local v201
				if v200 then
					v201 = string.format("PARTY  %d/%d", #v182, v183)
				else
					v201 = string.format("PARTY  %d/%d  \194\183  LEADER STARTS", #v182, v183)
				end
				v199.Text = v201
			end
			if v_u_102 then
				v_u_112()
			end
			v_u_71()
		end
		local v_u_203 = v_u_111
		local v_u_204 = v_u_110
		local v_u_205 = v_u_50
		local v_u_206 = v_u_112
		local v_u_207 = v_u_102
		local v_u_208 = v_u_11
		for v_u_209, v210 in v_u_31 do
			v210.btn.Activated:Connect(function()
				-- upvalues: (copy) p_u_4, (copy) v_u_24, (copy) v_u_209, (ref) v_u_73, (copy) v_u_181, (ref) v_u_208, (copy) v_u_162
				p_u_4.Sounds.Play("Click")
				local v211 = v_u_24()[v_u_209]
				if v211 then
					if not v_u_73 or v_u_73.Name ~= "SeatMenu" then
						v_u_181(v211)
						return
					end
					if v_u_73 then
						v_u_73:Destroy()
						v_u_73 = nil
						p_u_4.MenuManager.PopFocus("PartyPop")
						return
					end
				else
					if v_u_208.canInvite then
						v_u_162()
						return
					end
					p_u_4.Toast("Only the party leader can invite", "info")
				end
			end)
		end
		local v_u_212 = v_u_5.new("Frame", {
			["Name"] = "PartyInvites",
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Size"] = UDim2.fromOffset(460, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			v_u_5.List(Enum.FillDirection.Vertical, 8, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Bottom),
			["Parent"] = p_u_4.Canvas.Overlay
		})
		local v_u_213 = {}
		local v_u_214 = {}
		local function v_u_239() -- name: renderInvites
			-- upvalues: (ref) v_u_208, (copy) v_u_214, (copy) v_u_213, (copy) v_u_5, (copy) v_u_8, (copy) v_u_212, (copy) v_u_6, (copy) v_u_15, (ref) v_u_1, (copy) v_u_9, (copy) p_u_4
			local v215 = {}
			for _, v216 in v_u_208.invites or {} do
				if type(v216) ~= "table" then
					continue
				end
				local v217 = v216.fromUserId
				if type(v217) ~= "number" or v_u_214[v216.fromUserId] == v216.expiresAt then
					continue
				end
				v215[v216.fromUserId] = v216
			end
			for v218, v219 in v_u_213 do
				if v215[v218] then
					continue
				end
				v219.frame:Destroy()
				v_u_213[v218] = nil
			end
			for v_u_220, v221 in v215 do
				local v222 = v_u_213[v_u_220]
				if not v222 then
					local v223 = v_u_5.Panel({
						["Name"] = nil,
						["Size"] = nil,
						["BackgroundTransparency"] = 0.04,
						["StrokeColor"] = nil,
						["StrokeTransparency"] = 0.35,
						["StrokeThickness"] = 2,
						["Parent"] = nil,
						["Name"] = "Invite" .. v_u_220,
						["Size"] = UDim2.fromOffset(460, 92),
						["StrokeColor"] = v_u_8.Accent,
						["Parent"] = v_u_212
					})
					local v_u_224 = v_u_5.new("ImageLabel", {
						["Position"] = UDim2.fromOffset(14, 14),
						["Size"] = UDim2.fromOffset(60, 60),
						["BackgroundColor3"] = v_u_8.PanelHi,
						v_u_5.Corner(v_u_6.Radius.Pill),
						["Parent"] = v223
					})
					local v225 = v_u_15[v_u_220]
					if v225 then
						v_u_224.Image = v225
					else
						v_u_224.Image = ""
						task.spawn(function()
							-- upvalues: (ref) v_u_1, (copy) v_u_220, (ref) v_u_15, (copy) v_u_224
							local function v226()
								-- upvalues: (ref) v_u_1, (ref) v_u_220
								return v_u_1:GetUserThumbnailAsync(v_u_220, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size150x150)
							end
							local v227, v228 = pcall(v226)
							if v227 and type(v228) == "string" then
								v_u_15[v_u_220] = v228
								if v_u_224.Parent then
									v_u_224.Image = v228
								end
							end
						end)
					end
					v_u_5.new("TextLabel", {
						["Position"] = nil,
						["Size"] = nil,
						["Text"] = nil,
						["FontFace"] = nil,
						["TextSize"] = 21,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["TextTruncate"] = nil,
						["Parent"] = nil,
						["Position"] = UDim2.fromOffset(86, 16),
						["Size"] = UDim2.new(1, -250, 0, 26),
						["Text"] = v221.fromName or "Someone",
						["FontFace"] = v_u_9.Display,
						["TextColor3"] = v_u_8.Text,
						["TextXAlignment"] = Enum.TextXAlignment.Left,
						["TextTruncate"] = Enum.TextTruncate.AtEnd,
						["Parent"] = v223
					})
					v_u_5.new("TextLabel", {
						["Position"] = nil,
						["Size"] = nil,
						["TextTruncate"] = nil,
						["Text"] = nil,
						["FontFace"] = nil,
						["TextSize"] = 15,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["Parent"] = nil,
						["Position"] = UDim2.fromOffset(86, 44),
						["Size"] = UDim2.new(1, -272, 0, 20),
						["TextTruncate"] = Enum.TextTruncate.AtEnd,
						["Text"] = v221.remote and "invite from another lobby" or "invited you to their party",
						["FontFace"] = v_u_9.SemiBold,
						["TextColor3"] = v_u_8.TextDim,
						["TextXAlignment"] = Enum.TextXAlignment.Left,
						["Parent"] = v223
					})
					local v229 = v_u_5.Button({
						["Name"] = "Accept",
						["Text"] = "ACCEPT",
						["TextSize"] = 18,
						["Style"] = "Success",
						["Size"] = nil,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Parent"] = nil,
						["Size"] = UDim2.fromOffset(112, 50),
						["AnchorPoint"] = Vector2.new(1, 0.5),
						["Position"] = UDim2.new(1, -66, 0.5, -2),
						["Parent"] = v223
					})
					local v230 = v_u_5.IconButton({
						["Name"] = "Decline",
						["IconName"] = "cross",
						["Size"] = nil,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Parent"] = nil,
						["Size"] = UDim2.fromOffset(46, 46),
						["AnchorPoint"] = Vector2.new(1, 0.5),
						["Position"] = UDim2.new(1, -12, 0.5, -2),
						["Parent"] = v223
					})
					v_u_5.PadCap(Enum.KeyCode.DPadRight, {
						["Height"] = 22,
						["Position"] = nil,
						["ZIndex"] = 5,
						["Parent"] = nil,
						["Position"] = UDim2.fromOffset(-8, -10),
						["Parent"] = v229.Instance
					})
					local v231 = v_u_5.new("Frame", {
						["Name"] = "Timer",
						["AnchorPoint"] = Vector2.new(0, 1),
						["Position"] = UDim2.new(0, 14, 1, -6),
						["Size"] = UDim2.new(1, -28, 0, 3),
						["BackgroundColor3"] = v_u_8.Accent,
						v_u_5.Corner(v_u_6.Radius.Pill),
						["Parent"] = v223
					})
					v229.Activated:Connect(function()
						-- upvalues: (ref) p_u_4, (copy) v_u_220, (ref) v_u_213, (ref) v_u_214
						local v232, v233, v234 = p_u_4.Remotes.Invoke("PartyAction", "Respond", v_u_220, true)
						if v232 and v233 == true then
							p_u_4.Sounds.Play("Select")
						else
							p_u_4.Toast(not v232 and "Server unavailable" or tostring(v234 or "That invite is gone"), "error")
							if v232 then
								local v235 = v_u_220
								local v236 = v_u_213[v235]
								if v236 then
									v_u_214[v235] = v236.expiresAt or 0
									v236.frame:Destroy()
									v_u_213[v235] = nil
								end
							end
						end
					end)
					v230.Activated:Connect(function()
						-- upvalues: (copy) v_u_220, (ref) v_u_213, (ref) v_u_214, (ref) p_u_4
						local v237 = v_u_220
						local v238 = v_u_213[v237]
						if v238 then
							v_u_214[v237] = v238.expiresAt or 0
							v238.frame:Destroy()
							v_u_213[v237] = nil
						end
						task.spawn(p_u_4.Remotes.Invoke, "PartyAction", "Respond", v_u_220, false)
					end)
					v_u_5.Enter(v223, Vector2.new(0, 16))
					p_u_4.Sounds.Play("Notify")
					v222 = {
						["frame"] = v223,
						["bar"] = v231,
						["expiresAt"] = v221.expiresAt,
						["accept"] = v229.Instance,
						["at"] = os.clock()
					}
					v_u_213[v_u_220] = v222
				end
				v222.expiresAt = v221.expiresAt
			end
		end
		local v_u_240 = {}
		local function v_u_266(p_u_241, p242) -- name: openPlayerCard
			-- upvalues: (copy) v_u_83, (copy) v_u_5, (copy) v_u_8, (copy) v_u_6, (copy) v_u_15, (ref) v_u_1, (copy) v_u_9, (copy) v_u_74, (copy) v_u_109, (ref) v_u_73, (copy) p_u_4, (copy) v_u_19
			local v_u_243 = v_u_83("PlayerCard", Vector2.new(280, 128))
			local v_u_244 = v_u_5.new("ImageLabel", {
				["Position"] = UDim2.fromOffset(14, 14),
				["Size"] = UDim2.fromOffset(46, 46),
				["BackgroundColor3"] = v_u_8.PanelHi,
				["ZIndex"] = 21,
				v_u_5.Corner(v_u_6.Radius.Pill),
				["Parent"] = v_u_243
			})
			local v_u_245 = p_u_241.UserId
			local v246 = v_u_15[v_u_245]
			if v246 then
				v_u_244.Image = v246
			else
				v_u_244.Image = ""
				task.spawn(function()
					-- upvalues: (ref) v_u_1, (copy) v_u_245, (ref) v_u_15, (copy) v_u_244
					local function v247()
						-- upvalues: (ref) v_u_1, (ref) v_u_245
						return v_u_1:GetUserThumbnailAsync(v_u_245, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size150x150)
					end
					local v248, v249 = pcall(v247)
					if v248 and type(v249) == "string" then
						v_u_15[v_u_245] = v249
						if v_u_244.Parent then
							v_u_244.Image = v249
						end
					end
				end)
			end
			v_u_5.new("TextLabel", {
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 18,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["ZIndex"] = 21,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(70, 16),
				["Size"] = UDim2.new(1, -120, 0, 22),
				["Text"] = p_u_241.DisplayName,
				["FontFace"] = v_u_9.Heavy,
				["TextColor3"] = v_u_8.Text,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v_u_243
			})
			v_u_5.new("TextLabel", {
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 13,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["ZIndex"] = 21,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(70, 38),
				["Size"] = UDim2.new(1, -120, 0, 18),
				["Text"] = "@" .. p_u_241.Name,
				["FontFace"] = v_u_9.Medium,
				["TextColor3"] = v_u_8.TextMuted,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Parent"] = v_u_243
			})
			v_u_5.IconButton({
				["Name"] = "Close",
				["IconName"] = "cross",
				["Size"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["ZIndex"] = 22,
				["Parent"] = nil,
				["OnClick"] = nil,
				["Size"] = UDim2.fromOffset(34, 34),
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.new(1, -8, 0, 8),
				["Parent"] = v_u_243,
				["OnClick"] = v_u_74
			})
			local v250, v251 = v_u_109(p_u_241.UserId)
			local v252 = v_u_5.Button({
				["Name"] = "Invite",
				["Text"] = nil,
				["TextSize"] = 16,
				["Style"] = nil,
				["Size"] = nil,
				["Position"] = nil,
				["Parent"] = nil,
				["OnClick"] = nil,
				["Text"] = v250 == "INVITE" and "INVITE TO PARTY" or v250,
				["Style"] = v251 and "Primary" or "Dark",
				["Size"] = UDim2.new(1, -24, 0, 46),
				["Position"] = UDim2.fromOffset(12, 70),
				["Parent"] = v_u_243,
				["OnClick"] = function() -- name: OnClick
					-- upvalues: (ref) v_u_73, (ref) p_u_4, (ref) v_u_19, (copy) p_u_241
					if v_u_73 then
						v_u_73:Destroy()
						v_u_73 = nil
						p_u_4.MenuManager.PopFocus("PartyPop")
					end
					if v_u_19("Invite", p_u_241.UserId) then
						p_u_4.Toast(("Invite sent to %*"):format(p_u_241.DisplayName), "success")
					end
				end
			})
			v252:SetEnabled(v251)
			for _, v253 in v252.Instance:GetDescendants() do
				if not v253:IsA("GuiObject") then
					continue
				end
				v253.ZIndex = 23
			end
			v252.Instance.ZIndex = 22
			local v254 = p_u_4.Canvas.HUD
			local v255 = v_u_5.Scale
			local v256 = math.max(v255, 0.01)
			local v257 = v254.AbsolutePosition
			local v258 = v_u_5.CanvasSize()
			local v259 = (p242.X - v257.X) / v256 + 16
			local v260 = v258.X - 290
			local v261 = math.clamp(v259, 8, v260)
			local v262 = (p242.Y - v257.Y) / v256 - 60
			local v263 = v_u_5.TopInset() + 8
			local v264 = v258.Y - 140
			local v265 = math.clamp(v262, v263, v264)
			v_u_243.Position = UDim2.fromOffset(v261, v265)
			v_u_5.Enter(v_u_243, Vector2.new(0, 8))
			task.delay(6, function()
				-- upvalues: (ref) v_u_73, (copy) v_u_243, (ref) p_u_4
				if v_u_73 == v_u_243 and v_u_73 then
					v_u_73:Destroy()
					v_u_73 = nil
					p_u_4.MenuManager.PopFocus("PartyPop")
				end
			end)
		end
		local function v_u_268() -- name: lobbyClickable
			-- upvalues: (ref) v_u_208, (copy) v_u_7, (copy) p_u_4
			local v267 = v_u_208.enabled == true and (v_u_208.role == "Hub" and not v_u_7.InMatch()) and (v_u_7.Get("CombatMode") ~= true and not p_u_4.MenuManager.IsOpen())
			if v267 then
				v267 = not p_u_4.HudHidden
			end
			return v267
		end
		v_u_2.InputBegan:Connect(function(p269, p270)
			-- upvalues: (copy) v_u_240
			if not p270 then
				local v271 = p269.UserInputType
				if v271 == Enum.UserInputType.MouseButton1 or v271 == Enum.UserInputType.Touch then
					v_u_240[p269] = {
						["pos"] = Vector2.new(p269.Position.X, p269.Position.Y),
						["t"] = os.clock()
					}
				end
			end
		end)
		v_u_2.InputEnded:Connect(function(p272, p273)
			-- upvalues: (copy) v_u_240, (copy) v_u_268, (ref) v_u_3, (copy) v_u_10, (ref) v_u_1, (copy) p_u_4, (copy) v_u_266, (ref) v_u_73
			local v274 = v_u_240[p272]
			v_u_240[p272] = nil
			if v274 and (not p273 and v_u_268()) then
				local v275 = Vector2.new(p272.Position.X, p272.Position.Y)
				if (v275 - v274.pos).Magnitude > 10 or os.clock() - v274.t > 0.45 then
					return
				else
					local v276 = v_u_3.CurrentCamera
					if v276 then
						local v277 = v276:ScreenPointToRay(v275.X, v275.Y)
						local v278 = RaycastParams.new()
						v278.FilterType = Enum.RaycastFilterType.Exclude
						v278.FilterDescendantsInstances = { v_u_10.Character }
						local v279 = v_u_3:Raycast(v277.Origin, v277.Direction * 250, v278)
						if v279 then
							v279 = v279.Instance:FindFirstAncestorOfClass("Model")
						end
						while v279 and (not v279:FindFirstChildOfClass("Humanoid") and v279.Parent) do
							v279 = v279.Parent:FindFirstAncestorOfClass("Model")
						end
						if v279 then
							v279 = v_u_1:GetPlayerFromCharacter(v279)
						end
						if v279 and v279 ~= v_u_10 then
							p_u_4.Sounds.Play("Click")
							v_u_266(v279, v275)
						elseif v_u_73 and (v_u_73.Name == "PlayerCard" and v_u_73) then
							v_u_73:Destroy()
							v_u_73 = nil
							p_u_4.MenuManager.PopFocus("PartyPop")
						end
					else
						return
					end
				end
			else
				return
			end
		end)
		local function v281() -- name: layout
			-- upvalues: (copy) v_u_5, (copy) v_u_28, (copy) v_u_6, (copy) v_u_212
			local v280 = v_u_5.TopInset()
			if v_u_5.Compact then
				v_u_28.AnchorPoint = Vector2.new(1, 0)
				v_u_28.Position = UDim2.new(1, -16, 0, v280 + (v_u_6.ShowCurrency and 60 or 0) + 160)
				v_u_212.Position = UDim2.new(0.5, 0, 1, -18)
				v_u_212.Size = UDim2.fromOffset(420, 0)
			else
				v_u_28.AnchorPoint = Vector2.new(1, 1)
				v_u_28.Position = UDim2.new(1, -28, 1, -214)
				v_u_212.Position = UDim2.new(0.5, 0, 1, -28)
				v_u_212.Size = UDim2.fromOffset(460, 0)
			end
		end
		v281()
		v_u_5.LayoutChanged:Connect(v281)
		v_u_5.TopInsetChanged:Connect(v281)
		local function v283() -- name: refreshVisible
			-- upvalues: (ref) v_u_208, (copy) v_u_7, (copy) p_u_4, (copy) v_u_13, (copy) v_u_14, (copy) v_u_212, (ref) v_u_73
			local v282 = v_u_208.enabled == true and (v_u_208.role == "Hub" and not v_u_7.InMatch())
			if v282 then
				v282 = not p_u_4.HudHidden
			end
			v_u_13.Visible = v282
			v_u_14.Visible = v282
			v_u_212.Visible = v282
			if not v282 and v_u_73 then
				v_u_73:Destroy()
				v_u_73 = nil
				p_u_4.MenuManager.PopFocus("PartyPop")
			end
		end
		local v284 = v_u_208.enabled == true and v_u_208.role == "Hub" and not v_u_7.InMatch()
		if v284 then
			v284 = not p_u_4.HudHidden
		end
		v_u_13.Visible = v284
		v_u_14.Visible = v284
		v_u_212.Visible = v284
		if not v284 and v_u_73 then
			v_u_73:Destroy()
			v_u_73 = nil
			p_u_4.MenuManager.PopFocus("PartyPop")
		end
		v_u_7.PlayerStateChanged:Connect(v283)
		p_u_4.HudHiddenChanged:Connect(v283)
		local function v_u_291(p285) -- name: apply
			-- upvalues: (ref) v_u_208, (ref) v_u_12, (copy) v_u_202, (copy) v_u_239, (copy) v_u_7, (copy) p_u_4, (copy) v_u_13, (copy) v_u_14, (copy) v_u_212, (ref) v_u_73
			if type(p285) == "table" then
				v_u_208 = p285
				local v286 = v_u_208
				local v287 = v_u_208.outgoing
				v286.outgoing = type(v287) ~= "table" and {} or v_u_208.outgoing
				local v288 = v_u_208
				local v289 = v_u_208.invites
				v288.invites = type(v289) ~= "table" and {} or v_u_208.invites
				v_u_12 = os.clock()
				v_u_202()
				v_u_239()
				local v290 = v_u_208.enabled == true and (v_u_208.role == "Hub" and not v_u_7.InMatch())
				if v290 then
					v290 = not p_u_4.HudHidden
				end
				v_u_13.Visible = v290
				v_u_14.Visible = v290
				v_u_212.Visible = v290
				if not v290 and v_u_73 then
					v_u_73:Destroy()
					v_u_73 = nil
					p_u_4.MenuManager.PopFocus("PartyPop")
				end
			end
		end
		p_u_4.Remotes.On("PartyState", v_u_291)
		task.defer(function()
			-- upvalues: (copy) p_u_4
			p_u_4.Remotes.Invoke("PartyAction", "Get")
		end)
		v_u_202()
		v_u_5.Every(v_u_13, 0.2, function()
			-- upvalues: (copy) v_u_71, (copy) v_u_7, (copy) v_u_213, (copy) v_u_214, (ref) v_u_207, (ref) v_u_206, (copy) v_u_160
			v_u_71()
			local v292 = v_u_7.Now()
			for v293, v294 in v_u_213 do
				local v295 = (v294.expiresAt or v292) - v292
				local v296 = math.max(0, v295)
				local v297 = v294.bar
				local v298 = UDim2.new
				local v299 = v296 / 30
				v297.Size = v298(math.clamp(v299, 0, 1), -28, 0, 3)
				if v296 > 0 then
					continue
				end
				local v300 = v_u_213[v293]
				if not v300 then
					continue
				end
				v_u_214[v293] = v300.expiresAt or 0
				v300.frame:Destroy()
				v_u_213[v293] = nil
			end
			if v_u_207 then
				v_u_206()
				v_u_160()
			end
		end)
		v_u_1.PlayerRemoving:Connect(function()
			-- upvalues: (ref) v_u_207, (ref) v_u_206
			task.defer(function()
				-- upvalues: (ref) v_u_207, (ref) v_u_206
				if v_u_207 then
					v_u_206()
				end
			end)
		end)
		v_u_1.PlayerAdded:Connect(function()
			-- upvalues: (ref) v_u_207, (ref) v_u_206
			if v_u_207 then
				v_u_206()
			end
		end)
		function p_u_4.Debug.party(p301, p302)
			-- upvalues: (copy) v_u_162, (ref) v_u_73, (copy) p_u_4, (copy) v_u_291, (ref) v_u_205, (copy) v_u_71, (ref) v_u_204, (ref) v_u_203, (ref) v_u_206, (ref) v_u_208, (ref) v_u_12, (copy) v_u_24
			if p301 == "open" then
				v_u_162()
			elseif p301 == "close" then
				if v_u_73 then
					v_u_73:Destroy()
					v_u_73 = nil
					p_u_4.MenuManager.PopFocus("PartyPop")
				end
			elseif p301 == "mock" then
				v_u_291(p302)
			elseif p301 == "premiumMock" then
				v_u_205 = type(p302) ~= "table" and {} or p302
				v_u_71()
			elseif p301 == "friends" then
				v_u_204 = type(p302) ~= "table" and {} or p302
				v_u_203 = os.clock()
				v_u_206()
			end
			local v303 = {
				["state"] = v_u_208,
				["age"] = os.clock() - v_u_12,
				["seats"] = #v_u_24()
			}
			local v304
			if v_u_73 then
				v304 = v_u_73.Name
			else
				v304 = false
			end
			v303.pop = v304
			return v303
		end
		p_u_4.Party = {
			["Root"] = v_u_13,
			["Row"] = v_u_28,
			["PadTarget"] = function() -- name: PadTarget
				-- upvalues: (copy) v_u_213, (copy) v_u_212
				local v305 = nil
				for _, v306 in v_u_213 do
					if not v306.frame.Parent or v305 and v306.at <= v305.at then
						continue
					end
					v305 = v306
				end
				if v305 and v_u_212.Visible then
					return v305.accept
				else
					return nil
				end
			end
		}
	end
}