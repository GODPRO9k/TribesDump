local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("TextChatService")
local v_u_3 = game:GetService("StarterGui")
local v_u_4 = game:GetService("GuiService")
local v_u_5 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Unlocks"))
local v_u_6 = require(script.Parent.Parent.RankArt)
local v7 = {}
local v_u_8 = nil
local function v_u_13() -- name: restoreChat
	-- upvalues: (ref) v_u_8, (copy) v_u_2, (copy) v_u_3
	local v_u_9 = v_u_8
	if v_u_9 then
		v_u_8 = nil
		local function v12()
			-- upvalues: (ref) v_u_2, (copy) v_u_9, (ref) v_u_3
			local v10 = v_u_2:FindFirstChildOfClass("ChatWindowConfiguration")
			local v11 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
			if v10 and v_u_9.window ~= nil then
				v10.Enabled = v_u_9.window
			end
			if v11 and v_u_9.bar ~= nil then
				v11.Enabled = v_u_9.bar
			end
			if v_u_9.core ~= nil then
				v_u_3:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, v_u_9.core)
			end
		end
		pcall(v12)
	end
end
function v7.Init(p_u_14) -- name: Init
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_6, (copy) v_u_1, (ref) v_u_8, (copy) v_u_2, (copy) v_u_3, (copy) v_u_13
	local v_u_15 = p_u_14.UI
	local v_u_16 = p_u_14.Theme
	local v_u_17 = p_u_14.State
	local v_u_18 = p_u_14.WeaponInfo
	local v_u_19 = p_u_14.WeaponIcon
	local v_u_20 = p_u_14.Economy
	local v_u_21 = v_u_16.Colors
	local v_u_22 = v_u_16.Fonts
	local v_u_23 = UDim2.fromOffset
	local v_u_24 = v_u_20.MAX_LEVEL
	local v_u_25 = v_u_21.Success
	local v_u_26 = v_u_21.Gold
	local v27 = v_u_21.TextMuted
	local v28 = string.format
	local v29 = v27.R * 255 + 0.5
	local v30 = math.floor(v29)
	local v31 = v27.G * 255 + 0.5
	local v32 = math.floor(v31)
	local v33 = v27.B * 255 + 0.5
	local v_u_34 = v28("#%02X%02X%02X", v30, v32, (math.floor(v33)))
	local v35 = v_u_16.Lighten(v_u_25, 0.15)
	local v36 = string.format
	local v37 = v35.R * 255 + 0.5
	local v38 = math.floor(v37)
	local v39 = v35.G * 255 + 0.5
	local v40 = math.floor(v39)
	local v41 = v35.B * 255 + 0.5
	local v_u_42 = v36("#%02X%02X%02X", v38, v40, (math.floor(v41)))
	local v43 = string.format
	local v44 = v_u_26.R * 255 + 0.5
	local v45 = math.floor(v44)
	local v46 = v_u_26.G * 255 + 0.5
	local v47 = math.floor(v46)
	local v48 = v_u_26.B * 255 + 0.5
	local v_u_49 = v43("#%02X%02X%02X", v45, v47, (math.floor(v48)))
	local function v_u_51(p50) -- name: pct
		return string.format("+%d%%", p50)
	end
	local v_u_52 = v_u_15.Window({
		["Name"] = "Collection",
		["Title"] = "COLLECTION",
		["Subtitle"] = nil,
		["Size"] = nil,
		["HeaderHeight"] = 80,
		["OpenSound"] = "Armory_Open",
		["Parent"] = nil,
		["OnCloseRequested"] = nil,
		["Subtitle"] = string.format("Win matches to find shards  \194\183  Shards unlock items and upgrade them (max +%d%%)", v_u_20.MaxBonusPercent()),
		["Size"] = UDim2.fromOffset(1180, 720),
		["Parent"] = p_u_14.Canvas.Menus,
		["OnCloseRequested"] = function() -- name: OnCloseRequested
			-- upvalues: (copy) p_u_14
			p_u_14.MenuManager.Close("Collection")
		end
	})
	local v53 = v_u_52.Content
	local v_u_54 = v_u_15.new("TextLabel", {
		["Name"] = "Summary",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["RichText"] = true,
		["FontFace"] = nil,
		["TextSize"] = 16,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -(v_u_15.WindowCloseSize() + 34), 0, 22),
		["Size"] = v_u_23(420, 24),
		["FontFace"] = v_u_22.Heavy,
		["TextColor3"] = v_u_21.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_52.Header
	})
	local v_u_55 = v_u_15.new("Frame", {
		["Name"] = "CollectionSelection",
		["Size"] = UDim2.fromScale(1, 1),
		v_u_15.Corner(14),
		v_u_15.Stroke(v_u_21.Accent, 3, 0)
	})
	local v_u_56 = v_u_15.Panel({
		["Name"] = "Detail",
		["Size"] = nil,
		["BackgroundTransparency"] = 0.06,
		["Radius"] = nil,
		["Parent"] = nil,
		["Size"] = v_u_23(360, 500),
		["Radius"] = UDim.new(0, 14),
		["Parent"] = v53
	})
	local v_u_57 = v_u_56:FindFirstChildOfClass("UIGradient")
	local v_u_58 = v_u_56:FindFirstChildOfClass("UIStroke")
	local v_u_59 = v_u_15.new("Frame", {
		["Name"] = "Preview",
		["Size"] = v_u_23(320, 220),
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["ClipsDescendants"] = true,
		v_u_15.Corner(12),
		["Parent"] = v_u_56
	})
	local v_u_60 = v_u_15.Gradient(v_u_21.Accent, v_u_21.Panel, 115)
	v_u_60.Parent = v_u_59
	local v_u_61 = v_u_15.Image(v_u_15.Assets.Icons.Glow, {
		["Name"] = "Glow",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ImageColor3"] = nil,
		["ImageTransparency"] = 0.5,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(1.1, 1.3),
		["ImageColor3"] = v_u_21.Accent,
		["Parent"] = v_u_59
	})
	local v_u_62 = v_u_15.new("Frame", {
		["Name"] = "Icon",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.52),
		["Size"] = UDim2.fromScale(0.86, 0.86),
		["Parent"] = v_u_59
	})
	local v_u_63 = v_u_15.new("Frame", {
		["Name"] = "Flash",
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundColor3"] = v_u_26,
		["BackgroundTransparency"] = 1,
		["ZIndex"] = 5,
		v_u_15.Corner(12),
		["Parent"] = v_u_59
	})
	local v_u_64 = v_u_15.Image(v_u_15.Assets.Fx.Ring, {
		["Name"] = "Ring",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ImageColor3"] = nil,
		["ImageTransparency"] = 1,
		["ZIndex"] = 6,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.52),
		["Size"] = v_u_23(60, 60),
		["ImageColor3"] = v_u_26,
		["Parent"] = v_u_59
	})
	local v_u_65 = v_u_15.new("Frame", {
		["Name"] = "Burst",
		["Size"] = nil,
		["ZIndex"] = 7,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_59
	})
	local v_u_66 = v_u_15.DisplayText({
		["Name"] = "LevelSlam",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["TextSize"] = 52,
		["TextColor3"] = nil,
		["StrokeThickness"] = 3,
		["ZIndex"] = 8,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.new(1, 0, 0, 60),
		["TextColor3"] = v_u_26,
		["Parent"] = v_u_59
	})
	v_u_66.Visible = false
	local v_u_67 = v_u_15.new("Frame", {
		["Name"] = "Level",
		["Position"] = v_u_23(10, 10),
		["Size"] = v_u_23(76, 34),
		["BackgroundColor3"] = v_u_21.Void,
		["BackgroundTransparency"] = 0.2,
		["ZIndex"] = 9,
		v_u_15.Corner(v_u_16.Radius.Pill),
		["Parent"] = v_u_59
	})
	local v_u_68 = v_u_15.Stroke(v_u_21.Stroke, 1, 0.8)
	v_u_68.Parent = v_u_67
	local v_u_69 = v_u_15.new("TextLabel", {
		["Name"] = "Lv",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "LV",
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["ZIndex"] = 9,
		["Parent"] = nil,
		["Position"] = v_u_23(12, 0),
		["Size"] = v_u_23(22, 34),
		["FontFace"] = v_u_22.Heavy,
		["TextColor3"] = v_u_21.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_67
	})
	local v_u_70 = v_u_15.new("Frame", {
		["Name"] = "Num",
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["ZIndex"] = 9,
		["Parent"] = nil,
		["Position"] = v_u_23(36, 2),
		["Size"] = v_u_23(30, 30),
		["Parent"] = v_u_67
	})
	local v_u_71 = v_u_15.new("TextLabel", {
		["Name"] = "A",
		["Size"] = nil,
		["Text"] = "1",
		["FontFace"] = nil,
		["TextSize"] = 24,
		["TextXAlignment"] = nil,
		["ZIndex"] = 9,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["FontFace"] = v_u_22.Display,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_70
	})
	local v_u_72 = v_u_15.new("TextLabel", {
		["Name"] = "B",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 24,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["ZIndex"] = 9,
		["Parent"] = nil,
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.fromScale(1, 1),
		["FontFace"] = v_u_22.Display,
		["TextColor3"] = v_u_26,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_70
	})
	local v_u_73 = v_u_15.new("Frame", {
		["Name"] = "Lock",
		["Position"] = v_u_23(10, 10),
		["Size"] = v_u_23(36, 36),
		["BackgroundColor3"] = v_u_21.Void,
		["BackgroundTransparency"] = 0.2,
		["ZIndex"] = 9,
		v_u_15.Corner(v_u_16.Radius.Pill),
		["Parent"] = v_u_59
	})
	v_u_15.Image(v_u_15.Assets.Icons.Lock, {
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ImageColor3"] = nil,
		["ZIndex"] = 9,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = v_u_23(18, 18),
		["ImageColor3"] = v_u_21.TextDim,
		["Parent"] = v_u_73
	})
	local v_u_74 = v_u_15.new("TextLabel", {
		["Name"] = "ItemName",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 30,
		["TextScaled"] = true,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_22.Display,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextYAlignment"] = Enum.TextYAlignment.Center,
		["Parent"] = v_u_56
	})
	local v_u_75 = v_u_15.new("UITextSizeConstraint", {
		["MaxTextSize"] = 30,
		["MinTextSize"] = 14,
		["Parent"] = nil,
		["Parent"] = v_u_74
	})
	local v_u_76 = v_u_15.new("TextLabel", {
		["Name"] = "Sub",
		["Text"] = "",
		["RichText"] = true,
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_22.Heavy,
		["TextColor3"] = v_u_21.TextMuted,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_56
	})
	local v_u_77 = v_u_15.new("TextLabel", {
		["Name"] = "BarCaption",
		["Text"] = "SHARDS",
		["FontFace"] = nil,
		["TextSize"] = 12,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_22.Heavy,
		["TextColor3"] = v_u_21.TextMuted,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_56
	})
	local v_u_78 = v_u_15.new("TextLabel", {
		["Name"] = "BarGoal",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 12,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_22.Heavy,
		["TextColor3"] = v_u_21.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_56
	})
	local v_u_79 = v_u_15.Bar({
		["Name"] = "Shards",
		["Size"] = nil,
		["Color"] = nil,
		["Stroke"] = false,
		["Parent"] = nil,
		["Size"] = v_u_23(300, 24),
		["Color"] = v_u_21.Accent,
		["Parent"] = v_u_56
	})
	local v_u_80 = v_u_15.new("TextLabel", {
		["Name"] = "Count",
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 16,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["FontFace"] = v_u_22.Display,
		["Parent"] = v_u_79.Frame
	})
	v_u_15.TextStroke(v_u_21.Void, 1.5, 0.35).Parent = v_u_80
	local v_u_81 = v_u_15.new("Frame", {
		["Name"] = "Divider",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.9,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_21.Text,
		["Size"] = v_u_23(300, 1),
		["Parent"] = v_u_56
	})
	local v_u_82 = v_u_15.new("TextLabel", {
		["Name"] = "BonusCaption",
		["Text"] = "DAMAGE BONUS",
		["FontFace"] = nil,
		["TextSize"] = 12,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_22.Heavy,
		["TextColor3"] = v_u_21.TextMuted,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_56
	})
	local v_u_83 = v_u_15.new("Frame", {
		["Name"] = "Bonus",
		["Size"] = v_u_23(300, 36),
		v_u_15.List(Enum.FillDirection.Horizontal, 10, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
		["Parent"] = v_u_56
	})
	local v_u_84 = v_u_15.new("TextLabel", {
		["Name"] = "Now",
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["Text"] = "+0%",
		["FontFace"] = nil,
		["TextSize"] = 32,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.new(0, 0, 1, 0),
		["FontFace"] = v_u_22.Display,
		["Parent"] = v_u_83
	})
	local v_u_85 = v_u_15.Icon("chevRight", 18, v_u_21.TextMuted, {
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["Parent"] = v_u_83
	})
	local v_u_86 = v_u_15.new("TextLabel", {
		["Name"] = "Next",
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["Text"] = "+2%",
		["FontFace"] = nil,
		["TextSize"] = 32,
		["TextColor3"] = nil,
		["LayoutOrder"] = 3,
		["Parent"] = nil,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.new(0, 0, 1, 0),
		["FontFace"] = v_u_22.Display,
		["TextColor3"] = v_u_16.Lighten(v_u_25, 0.15),
		["Parent"] = v_u_83
	})
	local v_u_87 = v_u_15.new("TextLabel", {
		["Name"] = "Word",
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["Text"] = "damage",
		["FontFace"] = nil,
		["TextSize"] = 16,
		["TextColor3"] = nil,
		["LayoutOrder"] = 4,
		["Parent"] = nil,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.new(0, 0, 1, 0),
		["FontFace"] = v_u_22.Bold,
		["TextColor3"] = v_u_21.TextDim,
		["Parent"] = v_u_83
	})
	local v_u_89 = v_u_15.CountUp(v_u_84, function(p88)
		-- upvalues: (copy) v_u_51
		return v_u_51(p88)
	end, 0.6)
	local v_u_91 = v_u_15.CountUp(v_u_86, function(p90)
		-- upvalues: (copy) v_u_51
		return v_u_51(p90)
	end, 0.6)
	local v_u_92 = v_u_15.new("Frame", {
		["Name"] = "Pips",
		["Size"] = v_u_23(300, 10),
		v_u_15.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
		["Parent"] = v_u_56
	})
	local v_u_93 = {}
	local function v_u_96(p94) -- name: stateOf
		-- upvalues: (copy) v_u_20
		if v_u_20.Level(p94) <= 0 then
			return "locked"
		end
		local _, _, v95 = v_u_20.Progress(p94)
		return v95 == "max" and (v_u_20.MaxLevel(p94) <= 1 and "fixed" or "max") or (v_u_20.CanUpgrade(p94) and "ready" or "owned")
	end
	for v97 = 1, v_u_24 do
		v_u_93[v97] = v_u_15.new("Frame", {
			["Name"] = "Pip" .. v97,
			["Size"] = v_u_23(40, 8),
			["BackgroundColor3"] = v_u_21.Inset,
			["LayoutOrder"] = v97,
			v_u_15.Corner(v_u_16.Radius.Pill),
			["Parent"] = v_u_92
		})
	end
	local v_u_98 = v_u_15.new("TextLabel", {
		["Name"] = "Note",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_22.SemiBold,
		["TextColor3"] = v_u_21.TextMuted,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextYAlignment"] = Enum.TextYAlignment.Top,
		["Parent"] = v_u_56
	})
	local v_u_99 = v_u_15.new("Frame", {
		["Name"] = "ActionBox",
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = v_u_23(300, 56),
		["Parent"] = v_u_56
	})
	local v_u_100 = v_u_15.GetScaleObj(v_u_99, "Pulse")
	local v_u_101 = v_u_15.Image(v_u_15.Assets.Icons.Glow, {
		["Name"] = "Glow",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ImageColor3"] = nil,
		["ImageTransparency"] = 1,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.55),
		["Size"] = UDim2.new(1, 60, 2.4, 0),
		["ImageColor3"] = v_u_25,
		["Parent"] = v_u_99
	})
	local v_u_102 = v_u_15.Button({
		["Name"] = "Action",
		["Text"] = "UPGRADE",
		["TextSize"] = 21,
		["Style"] = "Success",
		["Size"] = nil,
		["Radius"] = 12,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_99
	})
	v_u_102.Label.RichText = true
	local v_u_103 = v_u_15.new("TextLabel", {
		["Name"] = "ActionNote",
		["Text"] = "",
		["RichText"] = true,
		["FontFace"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_22.SemiBold,
		["TextColor3"] = v_u_21.TextMuted,
		["Parent"] = v_u_56
	})
	local v_u_104 = v_u_15.new("ScrollingFrame", {
		["Name"] = "Grid",
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = 5,
		["ScrollBarImageColor3"] = nil,
		["ScrollBarImageTransparency"] = 0.4,
		["Parent"] = nil,
		["AutomaticCanvasSize"] = Enum.AutomaticSize.None,
		["ScrollBarImageColor3"] = v_u_21.TextMuted,
		["Parent"] = v53
	})
	local v_u_105 = 900
	local function v110(p106, p107, p108) -- name: makeHeader
		-- upvalues: (copy) v_u_15, (copy) v_u_23, (copy) v_u_22, (copy) v_u_21
		local v109 = v_u_15.new("Frame", {
			["Name"] = p106,
			["Size"] = UDim2.new(1, -8, 0, 34),
			["Parent"] = p108
		})
		v_u_15.new("UIListLayout", {
			["FillDirection"] = Enum.FillDirection.Horizontal,
			["Padding"] = UDim.new(0, 10),
			["VerticalAlignment"] = Enum.VerticalAlignment.Center,
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v109
		})
		v_u_15.new("UIPadding", {
			["PaddingLeft"] = UDim.new(0, 4),
			["Parent"] = v109
		})
		return {
			["frame"] = v109,
			["tick"] = v_u_15.new("Frame", {
				["Name"] = "Bar",
				["BackgroundColor3"] = p107,
				["Size"] = v_u_23(4, 18),
				["LayoutOrder"] = 0,
				v_u_15.Corner(2),
				["Parent"] = v109
			}),
			["title"] = v_u_15.new("TextLabel", {
				["Name"] = "Text",
				["AutomaticSize"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["RichText"] = true,
				["FontFace"] = nil,
				["TextSize"] = 16,
				["TextColor3"] = nil,
				["LayoutOrder"] = 1,
				["Parent"] = nil,
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["Size"] = UDim2.new(0, 0, 1, 0),
				["FontFace"] = v_u_22.Heavy,
				["TextColor3"] = v_u_21.TextDim,
				["Parent"] = v109
			}),
			["sub"] = v_u_15.new("TextLabel", {
				["Name"] = "Sub",
				["AutomaticSize"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 14,
				["TextColor3"] = nil,
				["LayoutOrder"] = 2,
				["Parent"] = nil,
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["Size"] = UDim2.new(0, 0, 1, 0),
				["FontFace"] = v_u_22.SemiBold,
				["TextColor3"] = v_u_21.TextMuted,
				["Parent"] = v109
			})
		}
	end
	local v_u_111 = { "owned", "locked" }
	local v_u_112 = {
		["owned"] = v110("Section_owned", v_u_21.Accent, v_u_104),
		["locked"] = v110("Section_locked", v_u_21.TextMuted, v_u_104)
	}
	local v113 = v_u_112.owned.sub
	local v114 = string.format
	local v115 = v_u_20.BONUS_PER_LEVEL * 100 + 0.5
	v113.Text = v114("level up with shards  \194\183  +%d%% per level", (math.floor(v115)))
	v_u_112.locked.sub.Text = "find shards in drops to unlock"
	local v_u_116 = v_u_15.new("Frame", {
		["Name"] = "Shop",
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, -12, 0, 104),
		["Parent"] = v_u_104
	})
	v_u_15.Panel({
		["Name"] = "Bg",
		["Size"] = nil,
		["BackgroundTransparency"] = 0.05,
		["Radius"] = nil,
		["TopColor"] = nil,
		["BottomColor"] = nil,
		["StrokeColor"] = nil,
		["StrokeTransparency"] = 0.6,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Radius"] = UDim.new(0, 14),
		["TopColor"] = v_u_26:Lerp(v_u_21.Panel, 0.8),
		["BottomColor"] = v_u_26:Lerp(v_u_21.PanelLo, 0.92),
		["StrokeColor"] = v_u_26,
		["Parent"] = v_u_116
	})
	local v_u_117 = v_u_15.new("Frame", {
		["Name"] = "Emblem",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 14, 0.5, 0),
		["Size"] = v_u_23(76, 76),
		["Parent"] = v_u_116
	})
	v_u_15.Image(v_u_15.Assets.Icons.Glow, {
		["Name"] = "Glow",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ImageColor3"] = nil,
		["ImageTransparency"] = 0.55,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(1.7, 1.7),
		["ImageColor3"] = v_u_26,
		["Parent"] = v_u_117
	})
	local v118 = v_u_15.new("Frame", {
		["Name"] = "Gem",
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(0.66, 0.66),
		["Rotation"] = 45,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		v_u_15.Corner(10),
		v_u_15.Gradient(Color3.fromRGB(255, 214, 110), Color3.fromRGB(214, 138, 20), 90),
		v_u_15.Stroke(Color3.fromRGB(255, 230, 160), 2, 0.3),
		["Parent"] = v_u_117
	})
	v_u_15.new("Frame", {
		["Name"] = "Facet",
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(0.62, 0.62),
		["BackgroundColor3"] = Color3.fromRGB(255, 226, 150),
		["BackgroundTransparency"] = 0.55,
		v_u_15.Corner(6),
		["Parent"] = v118
	})
	v_u_15.Image(v_u_15.Assets.Icons.Star, {
		["Name"] = "Star",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ImageColor3"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = v_u_23(26, 26),
		["ImageColor3"] = Color3.fromRGB(120, 70, 8),
		["Parent"] = v_u_117
	})
	local v_u_119 = v_u_15.new("TextLabel", {
		["Name"] = "Title",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "GOLDEN DROP",
		["FontFace"] = nil,
		["TextSize"] = 24,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["Position"] = v_u_23(104, 18),
		["Size"] = v_u_23(300, 28),
		["FontFace"] = v_u_22.Display,
		["TextColor3"] = v_u_26,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_116
	})
	local v_u_120 = v_u_15.new("TextLabel", {
		["Name"] = "Line",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["Parent"] = nil,
		["Position"] = v_u_23(104, 48),
		["Size"] = v_u_23(300, 40),
		["FontFace"] = v_u_22.SemiBold,
		["TextColor3"] = v_u_21.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextYAlignment"] = Enum.TextYAlignment.Top,
		["Parent"] = v_u_116
	})
	local v_u_121 = v_u_15.new("Frame", {
		["Name"] = "Buttons",
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -14, 0.5, 0),
		["Size"] = v_u_23(470, 50),
		v_u_15.List(Enum.FillDirection.Horizontal, 10, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
		["Parent"] = v_u_116
	})
	local v_u_122 = v_u_15.Button({
		["Name"] = "Odds",
		["Text"] = "VIEW ODDS",
		["TextSize"] = 15,
		["Style"] = "Dark",
		["Size"] = nil,
		["Radius"] = 10,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["Size"] = v_u_23(122, 46),
		["Parent"] = v_u_121
	})
	local v_u_123 = v_u_15.Button({
		["Name"] = "Buy1",
		["Text"] = "",
		["TextSize"] = 16,
		["Style"] = "Success",
		["Size"] = nil,
		["Radius"] = 10,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["Size"] = v_u_23(150, 46),
		["Parent"] = v_u_121
	})
	local v_u_124 = v_u_15.Button({
		["Name"] = "Buy5",
		["Text"] = "",
		["TextSize"] = 16,
		["Style"] = "Success",
		["Size"] = nil,
		["Radius"] = 10,
		["LayoutOrder"] = 3,
		["Parent"] = nil,
		["Size"] = v_u_23(166, 46),
		["Parent"] = v_u_121
	})
	v_u_123.Label.RichText = true
	v_u_124.Label.RichText = true
	local v_u_125 = v_u_15.Pill("", v_u_26, {
		["Name"] = "Save",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Height"] = 20,
		["TextSize"] = 11,
		["TextColor"] = nil,
		["Transparency"] = 0,
		["PadX"] = 7,
		["ZIndex"] = 3,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0, -1),
		["TextColor"] = v_u_21.TextDark
	})
	v_u_125.Parent = v_u_124.Instance
	local v126 = Color3.fromRGB(245, 52, 64)
	local v_u_127 = v_u_15.Pill("", v126, {
		["Name"] = "Sale",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Height"] = 22,
		["TextSize"] = 12,
		["Transparency"] = 0,
		["PadX"] = 8,
		["ZIndex"] = 3,
		["Visible"] = false,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0, -1)
	})
	v_u_127.Parent = v_u_123.Instance
	local v_u_128 = v_u_15.new("TextButton", {
		["Name"] = "Odds",
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.35,
		["Visible"] = false,
		["Selectable"] = false,
		["ZIndex"] = 20,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundColor3"] = v_u_21.Void,
		["Parent"] = v_u_52.Body
	})
	v_u_15.Corner(UDim.new(0, 16)).Parent = v_u_128
	local v_u_129 = v_u_15.Panel({
		["Name"] = "Card",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundTransparency"] = 0.02,
		["Radius"] = nil,
		["StrokeColor"] = nil,
		["StrokeTransparency"] = 0.6,
		["ZIndex"] = 21,
		["Active"] = true,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = v_u_23(560, 420),
		["Radius"] = UDim.new(0, 16),
		["StrokeColor"] = v_u_26,
		["Parent"] = v_u_128
	})
	local v_u_130 = v_u_15.GetScaleObj(v_u_129, "FitScale")
	v_u_15.new("TextLabel", {
		["Name"] = "Title",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "GOLDEN DROP ODDS",
		["FontFace"] = nil,
		["TextSize"] = 26,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["ZIndex"] = 22,
		["Parent"] = nil,
		["Position"] = v_u_23(24, 18),
		["Size"] = UDim2.new(1, -90, 0, 30),
		["FontFace"] = v_u_22.Display,
		["TextColor3"] = v_u_26,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_129
	})
	local v_u_131 = v_u_15.new("TextLabel", {
		["Name"] = "Sub",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["ZIndex"] = 22,
		["Parent"] = nil,
		["Position"] = v_u_23(24, 50),
		["Size"] = UDim2.new(1, -48, 0, 18),
		["FontFace"] = v_u_22.SemiBold,
		["TextColor3"] = v_u_21.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_129
	})
	local v132 = v_u_15.IconButton({
		["Name"] = "Close",
		["IconName"] = "cross",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Color"] = nil,
		["HoverColor"] = nil,
		["Sound"] = "Close",
		["ZIndex"] = 23,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -14, 0, 14),
		["Size"] = v_u_23(44, 44),
		["Color"] = v_u_21.Raised,
		["HoverColor"] = v_u_21.Danger,
		["Parent"] = v_u_129
	})
	local v_u_133 = v_u_15.new("ScrollingFrame", {
		["Name"] = "List",
		["Position"] = v_u_23(24, 80),
		["Size"] = UDim2.new(1, -48, 1, -164),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollBarThickness"] = 4,
		["ScrollBarImageColor3"] = v_u_21.TextMuted,
		["ZIndex"] = 22,
		v_u_15.List(Enum.FillDirection.Vertical, 2, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Top),
		["Parent"] = v_u_129
	})
	local v134 = v_u_15.new("Frame", {
		["Name"] = "Buy",
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -18),
		["Size"] = UDim2.new(1, -48, 0, 50),
		["ZIndex"] = 22,
		v_u_15.List(Enum.FillDirection.Horizontal, 12, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
		["Parent"] = v_u_129
	})
	local v_u_135 = v_u_15.Button({
		["Name"] = "Buy1",
		["Text"] = "",
		["TextSize"] = 17,
		["Style"] = "Success",
		["Size"] = nil,
		["Radius"] = 10,
		["ZIndex"] = 23,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["Size"] = v_u_23(220, 48),
		["Parent"] = v134
	})
	local v_u_136 = v_u_15.Button({
		["Name"] = "Buy5",
		["Text"] = "",
		["TextSize"] = 17,
		["Style"] = "Success",
		["Size"] = nil,
		["Radius"] = 10,
		["ZIndex"] = 23,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["Size"] = v_u_23(220, 48),
		["Parent"] = v134
	})
	v_u_135.Label.RichText = true
	v_u_136.Label.RichText = true
	local function v_u_147(p137) -- name: oddsValue
		for _, v138 in { "value", "text" } do
			local v139 = p137[v138]
			if type(v139) ~= "string" or not string.find(p137[v138], "%%") then
				continue
			end
			return p137[v138]
		end
		local v140 = p137.chance or p137.p or (p137.probability or p137.percent or (p137.odds or p137.weight))
		if type(v140) ~= "number" then
			return nil
		end
		local v141
		if p137.percent == nil then
			v141 = false
		else
			local v142 = p137.percent
			v141 = type(v142) == "number"
		end
		if not v141 and v140 <= 1 then
			v140 = v140 * 100
		end
		if v140 > 0 and v140 < 0.1 then
			return "<0.1%"
		end
		local v143 = v140 + 0.5
		local v144 = v140 - math.floor(v143)
		if math.abs(v144) >= 0.05 then
			return string.format("%.1f%%", v140)
		end
		local v145 = string.format
		local v146 = v140 + 0.5
		return v145("%d%%", (math.floor(v146)))
	end
	local function v_u_154(p148) -- name: oddsLabel
		-- upvalues: (copy) v_u_18
		local v149 = p148.item
		local v150 = type(v149) == "string" and p148.item
		if not v150 then
			local v151 = p148.id
			if type(v151) == "string" and v_u_18.Get(p148.id) then
				v150 = p148.id or nil
			else
				v150 = nil
			end
		end
		if v150 and v_u_18.Get(v150) then
			return v_u_18.Name(v150)
		end
		for _, v152 in {
			"label",
			"name",
			"text",
			"kind",
			"title"
		} do
			local v153 = p148[v152]
			if type(v153) ~= "string" then
				continue
			end
			return p148[v152]
		end
		return "?"
	end
	local function v_u_168(p155, p156, p157, p158, p159) -- name: addOddsRow
		-- upvalues: (copy) v_u_15, (copy) v_u_133, (copy) v_u_22, (copy) v_u_21, (copy) v_u_34, (copy) v_u_26
		local v160 = p155 == "title" and 34 or (p155 == "note" and 0 or 28)
		local v161 = v_u_15.new("Frame", {
			["Name"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["ZIndex"] = 22,
			["Parent"] = nil,
			["Name"] = "Row" .. p158,
			["Size"] = UDim2.new(1, -8, 0, v160),
			["LayoutOrder"] = p158,
			["Parent"] = v_u_133
		})
		if p155 == "note" then
			v161.AutomaticSize = Enum.AutomaticSize.Y
			v_u_15.new("TextLabel", {
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 13,
				["TextColor3"] = nil,
				["TextWrapped"] = true,
				["TextXAlignment"] = nil,
				["ZIndex"] = 22,
				["Parent"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["Text"] = p156,
				["FontFace"] = v_u_22.SemiBold,
				["TextColor3"] = v_u_21.TextMuted,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Parent"] = v161
			})
		else
			local v162 = v_u_15.new
			local v163 = "TextLabel"
			local v164 = {
				["Size"] = nil,
				["Text"] = nil,
				["RichText"] = true,
				["FontFace"] = nil,
				["TextSize"] = nil,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextYAlignment"] = nil,
				["TextTruncate"] = nil,
				["ZIndex"] = 22,
				["Parent"] = nil,
				["Size"] = UDim2.new(1, -150, 1, 0)
			}
			if p155 == "title" then
				p156 = string.upper(p156)
			elseif p159 then
				p156 = string.format("%s  <font size=\"12\" color=\"%s\">%s</font>", p156, v_u_34, p159)
			end
			v164.Text = p156
			local v165
			if p155 == "title" then
				v165 = v_u_22.Heavy
			else
				v165 = v_u_22.Bold
			end
			v164.FontFace = v165
			v164.TextSize = p155 == "title" and 14 or 16
			local v166
			if p155 == "title" then
				v166 = v_u_21.TextMuted
			else
				v166 = v_u_21.Text
			end
			v164.TextColor3 = v166
			v164.TextXAlignment = Enum.TextXAlignment.Left
			local v167
			if p155 == "title" then
				v167 = Enum.TextYAlignment.Bottom
			else
				v167 = Enum.TextYAlignment.Center
			end
			v164.TextYAlignment = v167
			v164.TextTruncate = Enum.TextTruncate.AtEnd
			v164.Parent = v161
			v162(v163, v164)
			if p157 then
				v_u_15.new("TextLabel", {
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = nil,
					["FontFace"] = nil,
					["TextSize"] = 17,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["ZIndex"] = 22,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.fromScale(1, 0),
					["Size"] = UDim2.new(0, 150, 1, 0),
					["Text"] = p157,
					["FontFace"] = v_u_22.Display,
					["TextColor3"] = v_u_26,
					["TextXAlignment"] = Enum.TextXAlignment.Right,
					["Parent"] = v161
				})
			end
			if p155 == "row" then
				v_u_15.new("Frame", {
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.93,
					["ZIndex"] = 22,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0, 1),
					["Position"] = UDim2.fromScale(0, 1),
					["Size"] = UDim2.new(1, 0, 0, 1),
					["BackgroundColor3"] = v_u_21.Text,
					["Parent"] = v161
				})
			end
		end
	end
	local function v_u_194() -- name: buildOdds
		-- upvalues: (copy) v_u_133, (copy) v_u_168, (copy) v_u_154, (copy) v_u_147, (copy) v_u_20, (copy) v_u_18
		for _, v169 in v_u_133:GetChildren() do
			if not v169:IsA("Frame") then
				continue
			end
			v169:Destroy()
		end
		local v_u_170 = 0
		local v_u_171 = 0
		local function v_u_184(p172, p173) -- name: walk
			-- upvalues: (ref) v_u_170, (ref) v_u_168, (ref) v_u_154, (copy) v_u_184, (ref) v_u_147, (ref) v_u_171
			for _, v174 in p172 do
				if type(v174) ~= "table" then
					continue
				end
				local v175 = v174.rows
				local v176 = type(v175) == "table" and v174.rows
				if not v176 then
					local v177 = v174.items
					v176 = type(v177) == "table" and v174.items
					if not v176 then
						local v178 = v174.odds
						v176 = type(v178) == "table" and v174.odds
						if not v176 then
							local v179 = v174.entries
							if type(v179) == "table" then
								v176 = v174.entries or nil
							else
								v176 = nil
							end
						end
					end
				end
				if v176 and p173 < 2 then
					v_u_170 = v_u_170 + 1
					v_u_168("title", v_u_154(v174), nil, v_u_170)
					v_u_184(v176, p173 + 1)
					local v180 = v174.note
					if type(v180) ~= "string" then
						continue
					end
					v_u_170 = v_u_170 + 1
					v_u_168("note", v174.note, nil, v_u_170)
				else
					local v181 = v_u_147(v174)
					v_u_170 = v_u_170 + 1
					if v181 then
						v_u_171 = v_u_171 + 1
						v_u_168("row", v_u_154(v174), v181, v_u_170)
					else
						local v182 = v174.note
						if type(v182) ~= "string" then
							local v183 = v174.text
							if type(v183) ~= "string" then
								continue
							end
						end
						v_u_168("note", v174.note or v174.text, nil, v_u_170)
					end
				end
			end
		end
		local v185 = v_u_20.Odds("golden")
		local v186 = v_u_20.DropInfo("golden")
		if type(v185) ~= "table" then
			v_u_184(v185, 0)
			if v_u_171 == 0 then
				v_u_170 = v_u_170 + 1
				v_u_168("note", "The odds are on their way from the server. Try again in a moment.", nil, v_u_170)
			end
			return v_u_171
		end
		local v187 = v185.items
		if type(v187) ~= "table" then
			v_u_184(v185, 0)
			if v_u_171 == 0 then
				v_u_170 = v_u_170 + 1
				v_u_168("note", "The odds are on their way from the server. Try again in a moment.", nil, v_u_170)
			end
			return v_u_171
		end
		v_u_170 = v_u_170 + 1
		v_u_168("title", "Every Golden Drop", nil, v_u_170)
		local v188 = v186.stacks
		if type(v188) == "number" then
			local v189 = v186.min
			if type(v189) == "number" then
				v_u_170 = v_u_170 + 1
				v_u_168("row", "Stacks of shards", string.format("%d \195\151 %d\226\128\147%d", v186.stacks, v186.min, v186.max or v186.min), v_u_170)
			end
		end
		local v190 = v185.lockedChance
		if type(v190) == "number" then
			v_u_170 = v_u_170 + 1
			v_u_171 = v_u_171 + 1
			v_u_168("row", "An item you don\'t own yet", v_u_147({
				["chance"] = v185.lockedChance
			}) or "0%", v_u_170)
		end
		v_u_170 = v_u_170 + 1
		v_u_168("title", "Chance each item is in your drop", nil, v_u_170)
		for _, v191 in v185.items do
			if type(v191) ~= "table" then
				continue
			end
			local v192 = v191.item
			if type(v192) ~= "string" then
				continue
			end
			local v193 = v191.chance
			if type(v193) ~= "number" then
				continue
			end
			v_u_170 = v_u_170 + 1
			v_u_171 = v_u_171 + 1
			v_u_168("row", v_u_18.Name(v191.item), v_u_147({
				["chance"] = v191.chance
			}) or "0%", v_u_170, v191.locked and "LOCKED" or nil)
		end
		v_u_170 = v_u_170 + 1
		v_u_168("note", "For your collection right now: maxed items never drop, and items in the loadout you carry turn up more often. Stack sizes are random within the range above.", nil, v_u_170)
		if v_u_171 == 0 then
			v_u_170 = v_u_170 + 1
			v_u_168("note", "The odds are on their way from the server. Try again in a moment.", nil, v_u_170)
		end
		return v_u_171
	end
	local function v_u_199(p195, p196) -- name: priceLabel
		-- upvalues: (copy) v_u_20, (ref) v_u_5
		if v_u_20.Pending(p195) then
			return "\226\128\166"
		end
		local v197
		if p195 == v_u_5.FIRST_DROP.key then
			v197 = v_u_20.Price("drop_golden")
		else
			v197 = nil
		end
		local v198 = not v197 and "" or string.format("<font color=\"#C9F5D6\"><s>%d</s></font> ", v197)
		return string.format("%s  <font color=\"%s\">%s</font> %s%s", p196, "#FFFFFF", v_u_20.ROBUX, v198, v_u_20.PriceAmount(p195))
	end
	local function v_u_218() -- name: paintShop
		-- upvalues: (copy) v_u_20, (copy) v_u_120, (copy) v_u_127, (copy) v_u_131, (copy) v_u_123, (copy) v_u_199, (copy) v_u_124, (copy) v_u_135, (copy) v_u_136, (copy) v_u_125
		local v200 = v_u_20.DropInfo("golden")
		local v201 = v200.stacks
		local v202 = tonumber(v201) or 4
		local v203 = v200.min
		local v204 = tonumber(v203)
		local v205 = v200.max
		local v206 = tonumber(v205)
		local v207
		if v204 and v206 then
			local v208 = v202 * (v204 + v206) / 2 + 0.5
			v207 = math.floor(v208)
		else
			v207 = 60
		end
		local v209 = v_u_20.GoldenOffer()
		local v210 = v_u_20.OfferLeft()
		if v209 and (v209.state == "active" and v210) then
			v_u_120.RichText = true
			v_u_120.Text = string.format("<font color=\"#FF8C92\"><b>ONE-TIME OFFER</b>: ends in %s</font>\nAbout %d shards in %d big stacks.", v_u_20.FormatLeft(v210), v207, v202)
		else
			v_u_120.Text = string.format("About %d shards in %d big stacks.\nOne is always an item you don\'t own yet.", v207, v202)
		end
		local v211
		if v209 and v209.state == "active" then
			v211 = v_u_20.OfferDiscount()
		else
			v211 = nil
		end
		v_u_127.Visible = v211 ~= nil
		if v211 then
			v_u_127:FindFirstChild("Text").Text = string.format("-%d%%", v211)
		end
		v_u_131.Text = string.format("About %d shards in %d stacks. Odds for your collection, before you buy.", v207, v202)
		local v212 = v_u_20.DropKey(1)
		local v213 = v_u_20.DropKey(5)
		v_u_123:SetText(v_u_199(v212, "1 DROP"))
		v_u_124:SetText(v_u_199(v213, "5 DROPS"))
		v_u_135:SetText(v_u_199(v212, "BUY 1"))
		v_u_136:SetText(v_u_199(v213, "BUY 5"))
		v_u_123:SetEnabled(not v_u_20.Pending(v212))
		v_u_124:SetEnabled(not v_u_20.Pending(v213))
		v_u_135:SetEnabled(not v_u_20.Pending(v212))
		v_u_136:SetEnabled(not v_u_20.Pending(v213))
		local v214 = v_u_20.Price(v212) or 0
		local v215 = v_u_20.Price(v213) or 0
		local v216
		if v214 > 0 and v215 > 0 then
			local v217 = (1 - v215 / (5 * v214)) * 100 + 0.5
			v216 = math.floor(v217)
		else
			v216 = 0
		end
		v_u_125.Visible = v216 >= 5
		v_u_125:FindFirstChild("Text").Text = string.format("SAVE %d%%", v216)
	end
	local function v_u_223() -- name: openOdds
		-- upvalues: (copy) v_u_194, (copy) v_u_218, (copy) v_u_15, (copy) v_u_52, (copy) v_u_129, (copy) v_u_23, (copy) v_u_130, (copy) v_u_128, (copy) v_u_16, (copy) p_u_14, (ref) v_u_4, (copy) v_u_135
		v_u_194()
		v_u_218()
		v_u_15.CanvasSize()
		local v219 = v_u_52.Holder.Size.Y.Offset - 40
		local v220 = math.floor(v219)
		v_u_129.Size = v_u_23(560, (math.min(460, v220)))
		local v221 = v_u_130
		local v222 = (v_u_52.Holder.Size.X.Offset - 40) / 560
		v221.Scale = math.min(1, v222)
		v_u_128.Visible = true
		v_u_128.BackgroundTransparency = 1
		v_u_15.Tween(v_u_128, v_u_16.Tween.Smooth, {
			["BackgroundTransparency"] = 0.35
		})
		v_u_15.SlideIn(v_u_129, Vector2.new(0, 24), v_u_16.Tween.Pop, UDim2.fromScale(0.5, 0.5))
		p_u_14.Sounds.Play("Open")
		if v_u_15.Gamepad then
			v_u_4.SelectedObject = v_u_135.Instance
		end
	end
	local function v225() -- name: closeOdds
		-- upvalues: (copy) v_u_128, (ref) v_u_4, (copy) v_u_122
		if v_u_128.Visible then
			v_u_128.Visible = false
			local v224 = v_u_4.SelectedObject
			if v224 and v224:IsDescendantOf(v_u_128) then
				v_u_4.SelectedObject = v_u_122.Instance
			end
		end
	end
	v_u_122.Activated:Connect(v_u_223)
	v132.Activated:Connect(v225)
	v_u_128.Activated:Connect(v225)
	v_u_123.Activated:Connect(function()
		-- upvalues: (copy) v_u_20, (copy) v_u_218
		if v_u_20.DropsAllowed() then
			v_u_20.Buy(v_u_20.DropKey(1))
			v_u_218()
		end
	end)
	v_u_124.Activated:Connect(function()
		-- upvalues: (copy) v_u_20, (copy) v_u_218
		if v_u_20.DropsAllowed() then
			v_u_20.Buy(v_u_20.DropKey(5))
			v_u_218()
		end
	end)
	v_u_135.Activated:Connect(function()
		-- upvalues: (copy) v_u_20, (copy) v_u_218
		if v_u_20.DropsAllowed() then
			v_u_20.Buy(v_u_20.DropKey(1))
			v_u_218()
		end
	end)
	v_u_136.Activated:Connect(function()
		-- upvalues: (copy) v_u_20, (copy) v_u_218
		if v_u_20.DropsAllowed() then
			v_u_20.Buy(v_u_20.DropKey(5))
			v_u_218()
		end
	end)
	local v_u_226 = {}
	local v_u_227 = {}
	local v_u_228 = nil
	local v_u_229 = nil
	local v_u_230 = nil
	local v_u_231 = nil
	local function v_u_259(p_u_232) -- name: makeCard
		-- upvalues: (copy) v_u_20, (copy) v_u_15, (copy) v_u_23, (copy) v_u_104, (copy) v_u_55, (copy) v_u_21, (copy) v_u_16, (copy) v_u_22, (ref) v_u_6, (copy) v_u_25, (copy) p_u_14, (ref) v_u_229, (ref) v_u_230, (ref) v_u_228, (ref) v_u_231
		local v233 = p_u_232.id
		local v234 = v_u_20.CategoryColor(v233)
		local v235 = v_u_15.new("TextButton", {
			["Name"] = nil,
			["Size"] = nil,
			["Selectable"] = true,
			["Parent"] = nil,
			["Name"] = p_u_232.id,
			["Size"] = v_u_23(170, v_u_15.Compact and 184 or 212),
			["Parent"] = v_u_104
		})
		v235.SelectionImageObject = v_u_55
		local v_u_236 = v_u_15.GetScaleObj(v235, "HoverScale")
		local v237 = v_u_15.new("Frame", {
			["Name"] = "Inner",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["BackgroundTransparency"] = 0.08,
			["ClipsDescendants"] = true,
			v_u_15.Corner(14),
			["Parent"] = v235
		})
		local v238 = v_u_15.Gradient(v234:Lerp(v_u_21.Panel, 0.82), v_u_21.PanelHi:Lerp(v_u_21.Panel, 0.6), 115)
		v238.Parent = v237
		local v239 = v_u_15.Stroke(v_u_21.Stroke, 1, 0.9)
		v239.Parent = v237
		local v240 = v_u_15.Image(v_u_15.Assets.Icons.Glow, {
			["Name"] = "Glow",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 0.72,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(0.5, 0, 0, 64),
			["Size"] = v_u_23(190, 150),
			["ImageColor3"] = v234,
			["Parent"] = v237
		})
		local v241 = v_u_15.new("Frame", {
			["Name"] = "Icon",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 2,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 12),
			["Size"] = UDim2.new(1, -28, 1, -100),
			["Parent"] = v237
		})
		local v242 = v_u_15.new("Frame", {
			["Name"] = "Level",
			["Position"] = v_u_23(8, 8),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = v_u_23(0, 24),
			["BackgroundColor3"] = v_u_21.Void,
			["BackgroundTransparency"] = 0.25,
			["ZIndex"] = 4,
			v_u_15.Corner(v_u_16.Radius.Pill),
			v_u_15.Padding(0, 9, 0, 9),
			["Parent"] = v237
		})
		local v243 = v_u_15.new("TextLabel", {
			["Name"] = "Text",
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["Text"] = "LV 1",
			["RichText"] = true,
			["FontFace"] = nil,
			["TextSize"] = 14,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromScale(0, 1),
			["FontFace"] = v_u_22.Display,
			["Parent"] = v242
		})
		local v244 = v_u_15.new("Frame", {
			["Name"] = "Lock",
			["Position"] = v_u_23(8, 8),
			["Size"] = v_u_23(28, 28),
			["BackgroundColor3"] = v_u_21.Void,
			["BackgroundTransparency"] = 0.25,
			["ZIndex"] = 4,
			v_u_15.Corner(v_u_16.Radius.Pill),
			["Parent"] = v237
		})
		v_u_15.Image(v_u_15.Assets.Icons.Lock, {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ImageColor3"] = nil,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = v_u_23(15, 15),
			["ImageColor3"] = v_u_21.TextDim,
			["Parent"] = v244
		})
		local v245 = v_u_15.new("TextLabel", {
			["Name"] = "ItemName",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 17,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Position"] = UDim2.new(0, 12, 1, -84),
			["Size"] = UDim2.new(1, -24, 0, 22),
			["Text"] = p_u_232.name,
			["FontFace"] = v_u_22.Bold,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v237
		})
		local v246 = v_u_15.new("TextLabel", {
			["Name"] = "Sub",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 11,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Position"] = UDim2.new(0, 12, 1, -61),
			["Size"] = UDim2.new(0.62, -12, 0, 15),
			["FontFace"] = v_u_22.Heavy,
			["TextColor3"] = v_u_21.TextMuted,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v237
		})
		local v247 = v_u_15.new("TextLabel", {
			["Name"] = "Meta",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 11,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, -12, 1, -61),
			["Size"] = UDim2.new(0.38, 0, 0, 15),
			["FontFace"] = v_u_22.Heavy,
			["TextColor3"] = v_u_21.TextMuted,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["Parent"] = v237
		})
		local v248 = v_u_6.Emblem(1, 18, {
			["Name"] = "RankEmblem",
			["Position"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Position"] = UDim2.new(0, 10, 1, -62.5),
			["Parent"] = v237
		})
		v248.Visible = false
		local v249 = v_u_15.new("Frame", {
			["Name"] = "Shards",
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 10, 1, -10),
			["Size"] = UDim2.new(1, -20, 0, 22),
			["BackgroundColor3"] = v_u_21.Inset,
			["BackgroundTransparency"] = 0.1,
			["ClipsDescendants"] = true,
			["ZIndex"] = 3,
			v_u_15.Corner(v_u_16.Radius.Pill),
			["Parent"] = v237
		})
		local v250 = v_u_15.new("Frame", {
			["Name"] = "Fill",
			["Size"] = UDim2.fromScale(0, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["ZIndex"] = 3,
			v_u_15.Corner(v_u_16.Radius.Pill),
			["Parent"] = v249
		})
		local v251 = v_u_15.Gradient(v_u_16.Lighten(v_u_21.Accent, 0.2), v_u_21.Accent, 90)
		v251.Parent = v250
		local v252 = v_u_15.new("TextLabel", {
			["Name"] = "Count",
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 14,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["FontFace"] = v_u_22.Display,
			["Parent"] = v249
		})
		v_u_15.TextStroke(v_u_21.Void, 1.2, 0.35).Parent = v252
		local v253 = v_u_15.new("TextButton", {
			["Name"] = "Upgrade",
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, -8),
			["Size"] = UDim2.new(1, -16, 0, 30),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["Text"] = "",
			["Selectable"] = true,
			["Visible"] = false,
			["ZIndex"] = 6,
			v_u_15.Corner(v_u_16.Radius.Pill),
			v_u_15.Gradient(Color3.fromRGB(84, 224, 124), Color3.fromRGB(40, 184, 92), 90),
			v_u_15.Stroke(Color3.fromRGB(170, 255, 200), 1, 0.5),
			["Parent"] = v237
		})
		v253.SelectionImageObject = v_u_55
		local v254 = v_u_15.GetScaleObj(v253, "Pulse")
		local v255 = v_u_15.Image(v_u_15.Assets.Icons.Glow, {
			["Name"] = "Glow",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 0.6,
			["ZIndex"] = 5,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.new(1, 30, 2.6, 0),
			["ImageColor3"] = v_u_25,
			["Parent"] = v253
		})
		local v256 = v_u_15.new("Frame", {
			["Size"] = UDim2.fromScale(1, 1),
			["ZIndex"] = 6,
			v_u_15.List(Enum.FillDirection.Horizontal, 5, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
			["Parent"] = v253
		})
		v_u_15.Icon("chevUp", 13, v_u_21.Text, {
			["LayoutOrder"] = 1,
			["ZIndex"] = 6,
			["Parent"] = nil,
			["Parent"] = v256
		})
		v_u_15.new("TextLabel", {
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["Text"] = "UPGRADE",
			["FontFace"] = nil,
			["TextSize"] = 15,
			["LayoutOrder"] = 2,
			["ZIndex"] = 6,
			["Parent"] = nil,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromScale(0, 1),
			["FontFace"] = v_u_22.Display,
			["Parent"] = v256
		})
		local v257 = v_u_15.new("Frame", {
			["Name"] = "Flash",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = v_u_21.Accent,
			["BackgroundTransparency"] = 1,
			["ZIndex"] = 5,
			v_u_15.Corner(14),
			["Parent"] = v237
		})
		local v_u_258 = {
			["id"] = nil,
			["holder"] = nil,
			["scale"] = nil,
			["inner"] = nil,
			["grad"] = nil,
			["stroke"] = nil,
			["glow"] = nil,
			["icon"] = nil,
			["lv"] = nil,
			["lvText"] = nil,
			["lock"] = nil,
			["name"] = nil,
			["sub"] = nil,
			["meta"] = nil,
			["rankEmblem"] = nil,
			["barBg"] = nil,
			["barFill"] = nil,
			["barFillGrad"] = nil,
			["barText"] = nil,
			["up"] = nil,
			["upScale"] = nil,
			["upGlow"] = nil,
			["flash"] = nil,
			["state"] = "locked",
			["section"] = "locked",
			["rendered"] = false,
			["visible"] = true,
			["shown"] = false,
			["hover"] = false,
			["y"] = 0,
			["h"] = nil,
			["id"] = p_u_232.id,
			["holder"] = v235,
			["scale"] = v_u_236,
			["inner"] = v237,
			["grad"] = v238,
			["stroke"] = v239,
			["glow"] = v240,
			["icon"] = v241,
			["lv"] = v242,
			["lvText"] = v243,
			["lock"] = v244,
			["name"] = v245,
			["sub"] = v246,
			["meta"] = v247,
			["rankEmblem"] = v248,
			["barBg"] = v249,
			["barFill"] = v250,
			["barFillGrad"] = v251,
			["barText"] = v252,
			["up"] = v253,
			["upScale"] = v254,
			["upGlow"] = v255,
			["flash"] = v257,
			["h"] = v_u_15.Compact and 184 or 212
		}
		v235.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_15, (copy) v_u_258, (ref) p_u_14, (copy) v_u_236, (ref) v_u_16, (ref) v_u_229
			if not v_u_15.Touch then
				v_u_258.hover = true
				p_u_14.Sounds.Play("Hover")
				v_u_15.Tween(v_u_236, v_u_16.Tween.PopSmall, {
					["Scale"] = 1.03
				})
				v_u_229(v_u_258)
			end
		end)
		v235.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_258, (ref) v_u_15, (copy) v_u_236, (ref) v_u_16, (ref) v_u_229
			v_u_258.hover = false
			v_u_15.Tween(v_u_236, v_u_16.Tween.Fast, {
				["Scale"] = 1
			})
			v_u_229(v_u_258)
		end)
		v235.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_15, (copy) v_u_236, (ref) v_u_16
			v_u_15.Tween(v_u_236, v_u_16.Tween.Instant, {
				["Scale"] = 0.97
			})
		end)
		v235.MouseButton1Up:Connect(function()
			-- upvalues: (ref) v_u_15, (copy) v_u_236, (ref) v_u_16, (copy) v_u_258
			v_u_15.Tween(v_u_236, v_u_16.Tween.PopSmall, {
				["Scale"] = v_u_258.hover and 1.03 or 1
			})
		end)
		v235.Activated:Connect(function()
			-- upvalues: (ref) p_u_14, (ref) v_u_230, (copy) p_u_232
			p_u_14.Sounds.Play("Select")
			v_u_230(p_u_232.id)
		end)
		v235.SelectionGained:Connect(function()
			-- upvalues: (ref) v_u_228, (copy) p_u_232, (ref) v_u_230
			if v_u_228 ~= p_u_232.id then
				v_u_230(p_u_232.id, {
					["quiet"] = true
				})
			end
		end)
		v253.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_15, (ref) p_u_14
			if not v_u_15.Touch then
				p_u_14.Sounds.Play("Hover")
			end
		end)
		v253.Activated:Connect(function()
			-- upvalues: (ref) v_u_230, (copy) p_u_232, (ref) v_u_231
			v_u_230(p_u_232.id, {
				["quiet"] = true
			})
			v_u_231(p_u_232.id)
		end)
		return v_u_258
	end
	v_u_229 = function(p260)
		-- upvalues: (copy) v_u_96, (copy) v_u_20, (ref) v_u_228, (copy) v_u_26, (copy) v_u_21, (copy) v_u_19, (copy) v_u_25, (copy) v_u_16, (ref) v_u_6, (copy) v_u_18
		local v261 = p260.id
		local v262 = v_u_96(v261)
		p260.state = v262
		local v263 = v_u_20.Level(v261)
		local v264, v265 = v_u_20.Progress(v261)
		local v266 = v_u_20.CategoryColor(v261)
		local v267 = v_u_228 == v261
		local v268 = v262 == "locked"
		p260.lock.Visible = v268
		p260.lv.Visible = not v268
		if v262 == "max" then
			p260.lv.BackgroundColor3 = v_u_26
			p260.lv.BackgroundTransparency = 0
			p260.lvText.Text = "MAX"
			p260.lvText.TextColor3 = v_u_21.TextDark
		else
			p260.lv.BackgroundColor3 = v_u_21.Void
			p260.lv.BackgroundTransparency = 0.25
			local v269 = p260.lvText
			local v270 = string.format
			local v271 = v_u_21.TextDim
			local v272 = string.format
			local v273 = v271.R * 255 + 0.5
			local v274 = math.floor(v273)
			local v275 = v271.G * 255 + 0.5
			local v276 = math.floor(v275)
			local v277 = v271.B * 255 + 0.5
			v269.Text = v270("<font size=\"11\" color=\"%s\">LV</font> %d", v272("#%02X%02X%02X", v274, v276, (math.floor(v277))), v263)
			p260.lvText.TextColor3 = v_u_21.Text
		end
		local v278 = p260.grad
		local v279
		if v268 then
			v279 = ColorSequence.new(v_u_21.Panel, v_u_21.Panel)
		else
			local v280 = v262 == "max" and 0.22 or (p260.hover and 0.24 or 0.18)
			v279 = ColorSequence.new(v266:Lerp(v_u_21.Panel, 1 - v280), v_u_21.PanelHi:Lerp(v_u_21.Panel, 0.6))
		end
		v278.Color = v279
		p260.inner.BackgroundTransparency = v268 and 0.3 or 0.08
		p260.glow.ImageTransparency = v268 and 1 or ((p260.hover or v267) and 0.62 or 0.74)
		if p260.rendered then
			v_u_19.SetDim(p260.icon, v268)
		end
		local v281 = p260.name
		local v282
		if v268 then
			v282 = v_u_21.TextDim
		else
			v282 = v_u_21.Text
		end
		v281.TextColor3 = v282
		if v267 then
			local v283 = p260.stroke
			local v284
			if v262 == "ready" then
				v284 = v_u_25
			else
				v284 = v_u_21.Accent
			end
			v283.Color = v284
			p260.stroke.Thickness = 2
			p260.stroke.Transparency = 0
		elseif v262 == "ready" then
			p260.stroke.Color = v_u_25
			p260.stroke.Thickness = 2
		elseif v262 == "max" then
			p260.stroke.Color = v_u_26
			p260.stroke.Thickness = 1
			p260.stroke.Transparency = 0.55
		else
			p260.stroke.Color = v_u_21.Stroke
			p260.stroke.Thickness = 1
			p260.stroke.Transparency = p260.hover and 0.6 or 0.9
		end
		p260.up.Visible = v262 == "ready"
		p260.barBg.Visible = v262 ~= "ready"
		local v285
		if v265 > 0 then
			local v286 = v264 / v265
			v285 = math.clamp(v286, 0, 1)
		else
			v285 = 1
		end
		p260.barFill.Size = UDim2.fromScale(v262 == "max" and 1 or v285, 1)
		p260.barFill.Visible = v262 == "max" and true or v264 > 0
		p260.rankEmblem.Visible = false
		p260.sub.Position = UDim2.new(0, 12, 1, -61)
		p260.sub.Size = UDim2.new(0.62, -12, 0, 15)
		if v262 == "max" then
			p260.barFillGrad.Color = ColorSequence.new(v_u_16.Lighten(v_u_26, 0.15), v_u_26:Lerp(Color3.fromRGB(180, 110, 10), 0.3))
			p260.barText.Text = "MAX"
			p260.sub.Text = "MAX LEVEL"
			p260.sub.TextColor3 = v_u_26
			p260.meta.Text = string.upper(v_u_20.BonusText(v261, v263))
			p260.meta.TextColor3 = v_u_26
			return
		elseif v268 and not v_u_20.RankAllows(v261) then
			local v287 = v_u_20.ItemRank(v261)
			p260.barFillGrad.Color = ColorSequence.new(v_u_16.Lighten(v_u_21.Accent, 0.1), v_u_21.AccentDark)
			p260.barText.Text = string.format("%d / %d", v264, v265)
			v_u_6.SetEmblem(p260.rankEmblem, v287)
			p260.rankEmblem.Visible = true
			p260.sub.Position = UDim2.new(0, 32, 1, -61)
			p260.sub.Size = UDim2.new(1, -44, 0, 15)
			p260.sub.Text = "REACH " .. string.upper(v_u_6.Ranks.Get(v287).name)
			p260.sub.TextColor3 = v_u_6.Color(v287)
			p260.meta.Text = ""
			return
		elseif v268 then
			p260.barFillGrad.Color = ColorSequence.new(v_u_16.Lighten(v_u_21.Accent, 0.1), v_u_21.AccentDark)
			p260.barText.Text = string.format("%d / %d", v264, v265)
			p260.sub.Text = "LOCKED"
			p260.sub.TextColor3 = v_u_21.TextMuted
			p260.meta.Text = "TO UNLOCK"
			p260.meta.TextColor3 = v_u_21.TextMuted
			return
		elseif v262 == "ready" then
			p260.sub.Text = "UPGRADE READY"
			p260.sub.TextColor3 = v_u_16.Lighten(v_u_25, 0.15)
			p260.meta.Text = string.format("%d / %d", v264, v265)
			p260.meta.TextColor3 = v_u_21.TextDim
			return
		elseif v262 == "fixed" then
			p260.barFill.Visible = false
			p260.barText.Text = "NO LEVELS"
			local v288 = p260.sub
			local v289 = v_u_18.Get(v261)
			v288.Text = string.upper(v289 and (v_u_18.CATEGORY_SINGULAR[v289.category] or "") or "")
			p260.sub.TextColor3 = v_u_21.TextMuted
			p260.meta.Text = ""
		else
			p260.barFillGrad.Color = ColorSequence.new(v_u_16.Lighten(v_u_21.Accent, 0.2), v_u_21.Accent)
			p260.barText.Text = string.format("%d / %d", v264, v265)
			local v290 = p260.sub
			local v291
			if v263 > 1 then
				v291 = string.upper(v_u_20.BonusText(v261, v263))
			else
				local v292 = v_u_18.Get(v261)
				v291 = string.upper(v292 and (v_u_18.CATEGORY_SINGULAR[v292.category] or "") or "")
			end
			v290.Text = v291
			p260.sub.TextColor3 = v_u_21.TextMuted
			p260.meta.Text = "TO LV " .. v263 + 1
			p260.meta.TextColor3 = v_u_21.TextMuted
		end
	end
	local v_u_293 = {}
	local function v_u_303() -- name: queueVisible
		-- upvalues: (copy) v_u_104, (ref) v_u_105, (copy) v_u_226, (copy) v_u_293, (copy) v_u_19
		local v294 = v_u_105
		local v295 = v_u_104.AbsoluteSize.X / math.max(v294, 1)
		local v296 = math.max(v295, 0.01)
		local v297 = v_u_104.CanvasPosition.Y / v296
		local v298 = v297 + v_u_104.AbsoluteWindowSize.Y / v296
		for _, v299 in v_u_226 do
			local v300 = v299.visible
			if v300 then
				if v299.y + v299.h >= v297 - v299.h then
					v300 = v299.y <= v298 + v299.h
				else
					v300 = false
				end
			end
			if v300 and not v299.rendered then
				v299.rendered = true
				local v301 = v_u_293
				table.insert(v301, v299)
			else
				if not v299.rendered or v299.visible and (v299.y + v299.h >= v297 - v299.h * 2 and v299.y <= v298 + v299.h * 2) then
					continue
				end
				v299.rendered = false
				local v302 = table.find(v_u_293, v299)
				if v302 then
					table.remove(v_u_293, v302)
				end
				v_u_19.Set(v299.icon, nil)
			end
		end
	end
	v_u_1.Heartbeat:Connect(function()
		-- upvalues: (copy) v_u_293, (copy) v_u_52, (copy) v_u_15, (copy) v_u_19
		if #v_u_293 == 0 or not v_u_52.IsOpen then
			return
		end
		for _ = 1, v_u_15.Touch and 2 or 4 do
			local v304 = table.remove(v_u_293, 1)
			if not v304 then
				break
			end
			v_u_19.Set(v304.icon, v304.id, {
				["outline"] = false,
				["glow"] = false
			})
			v_u_19.SetDim(v304.icon, v304.state == "locked")
		end
	end)
	v_u_104:GetPropertyChangedSignal("CanvasPosition"):Connect(v_u_303)
	local v_u_305 = true
	local function v_u_331(p306, p307, p308) -- name: layoutPanel
		-- upvalues: (copy) v_u_56, (copy) v_u_23, (copy) v_u_59, (copy) v_u_75, (copy) v_u_74, (copy) v_u_76, (copy) v_u_15, (copy) v_u_67, (copy) v_u_73, (copy) v_u_66, (copy) v_u_77, (copy) v_u_78, (copy) v_u_79, (copy) v_u_80, (copy) v_u_81, (copy) v_u_82, (copy) v_u_93, (copy) v_u_24, (copy) v_u_92, (copy) v_u_83, (copy) v_u_84, (copy) v_u_86, (copy) v_u_87, (copy) v_u_98, (ref) v_u_305, (copy) v_u_99, (copy) v_u_102, (copy) v_u_103
		v_u_56.Size = v_u_23(p306, p307)
		local v309 = p308 and 12 or 16
		local v310 = p306 - v309 * 2
		local v311 = p308 and 48 or 56
		local v312 = p308 and 14 or 16
		local v313
		if p308 then
			v_u_59.Position = v_u_23(v309, v309)
			v_u_59.Size = v_u_23(104, 104)
			local v314 = v309 + 104 + 12
			v_u_75.MaxTextSize = 24
			v_u_74.Position = v_u_23(v314, v309 + 20)
			v_u_74.Size = v_u_23(p306 - v314 - v309, 30)
			v_u_76.Position = v_u_23(v314, v309 + 54)
			v_u_76.Size = v_u_23(p306 - v314 - v309, 16)
			v_u_76.TextSize = 12
			v313 = v309 + 104 + 12
		else
			local v315 = v311 + 16 + 4 + v312 + v309
			local v316 = p307 - v309 - 279 - v315
			local v317 = math.clamp(v316, 150, 300)
			v_u_59.Position = v_u_23(v309, v309)
			v_u_59.Size = v_u_23(v310, v317)
			v_u_75.MaxTextSize = 30
			local v318 = v309 + v317 + 14
			v_u_74.Position = v_u_23(v309, v318)
			v_u_74.Size = v_u_23(v310, 36)
			local v319 = v318 + 36
			v_u_76.Position = v_u_23(v309, v319)
			v_u_76.Size = v_u_23(v310, 20)
			v_u_76.TextSize = 15
			v313 = v319 + 38
		end
		local v320 = p308 and 0.8 or 1
		v_u_15.GetScaleObj(v_u_67, "Size").Scale = v320
		v_u_15.GetScaleObj(v_u_73, "Size").Scale = v320
		v_u_66.TextSize = p308 and 30 or 52
		v_u_77.Position = v_u_23(v309, v313)
		v_u_77.Size = v_u_23(v310, 16)
		v_u_77.TextSize = p308 and 11 or 12
		v_u_78.Position = v_u_23(v309, v313)
		v_u_78.Size = v_u_23(v310, 16)
		v_u_78.TextSize = p308 and 11 or 12
		local v321 = v313 + 18
		local v322 = p308 and 20 or 26
		v_u_79.Frame.Position = v_u_23(v309, v321)
		v_u_79.Frame.Size = v_u_23(v310, v322)
		v_u_80.TextSize = p308 and 14 or 17
		local v323 = v321 + (v322 + (p308 and 12 or 16))
		v_u_81.Position = v_u_23(v309, v323)
		v_u_81.Size = v_u_23(v310, 1)
		local v324 = v323 + ((p308 and 10 or 16) + 1)
		v_u_82.Position = v_u_23(v309, v324)
		v_u_82.Size = v_u_23(v310, 16)
		v_u_82.TextSize = p308 and 11 or 12
		local v325 = p308 and 18 or 26
		for _, v326 in v_u_93 do
			v326.Size = v_u_23(v325, p308 and 6 or 8)
		end
		local v327 = v_u_24 * v325 + (v_u_24 - 1) * 6
		v_u_92.Position = v_u_23(v309 + v310 - v327, v324 + 4)
		v_u_92.Size = v_u_23(v327, 8)
		local v328 = v324 + ((p308 and 2 or 4) + 16)
		v_u_83.Position = v_u_23(v309, v328)
		v_u_83.Size = v_u_23(v310, p308 and 30 or 40)
		v_u_84.TextSize = p308 and 24 or 34
		v_u_86.TextSize = p308 and 24 or 34
		v_u_87.TextSize = p308 and 14 or 17
		local v329 = v328 + ((p308 and 30 or 40) + (p308 and 4 or 8))
		v_u_98.Position = v_u_23(v309, v329)
		v_u_98.Size = v_u_23(v310, p308 and 34 or 40)
		v_u_98.TextSize = p308 and 13 or 14
		v_u_305 = p307 - (v329 + (p308 and 34 or 40)) - v309 - v311 - 8 >= v312 + 4
		local v330
		if v_u_305 then
			v330 = p307 - v309 - v312 - 4 - v311
		else
			v330 = p307 - v309 - v311
		end
		v_u_99.Position = v_u_23(v309, v330)
		v_u_99.Size = v_u_23(v310, v311)
		v_u_102.Label.TextSize = p308 and 18 or 21
		v_u_103.Position = v_u_23(v309, v330 + v311 + 4)
		v_u_103.Size = v_u_23(v310, v312)
		v_u_103.TextSize = p308 and 12 or 13
	end
	local v_u_332 = nil
	local v_u_333 = 0
	local v_u_334 = nil
	local v_u_335 = nil
	local function v_u_392()
		-- upvalues: (ref) v_u_228, (copy) v_u_96, (copy) v_u_20, (ref) v_u_332, (ref) v_u_334, (copy) v_u_19, (copy) v_u_62, (copy) v_u_15, (copy) v_u_16, (copy) v_u_74, (copy) v_u_18, (copy) v_u_76, (copy) v_u_34, (copy) v_u_49, (copy) v_u_21, (copy) v_u_24, (copy) v_u_25, (copy) v_u_26, (copy) v_u_60, (copy) v_u_61, (copy) v_u_57, (copy) v_u_58, (copy) v_u_73, (copy) v_u_67, (copy) v_u_69, (copy) v_u_23, (copy) v_u_70, (copy) v_u_71, (copy) v_u_72, (copy) v_u_68, (copy) v_u_79, (copy) v_u_80, (copy) v_u_78, (copy) v_u_82, (copy) v_u_87, (copy) v_u_83, (copy) v_u_92, (copy) v_u_89, (copy) v_u_91, (copy) v_u_84, (copy) v_u_85, (copy) v_u_86, (copy) v_u_93, (copy) v_u_98, (ref) v_u_6, (copy) v_u_101, (copy) v_u_102, (copy) v_u_103, (ref) v_u_335, (copy) v_u_42, (ref) v_u_305
		local v336 = v_u_228
		if v336 then
			local v337 = v_u_96(v336)
			local v338 = v_u_20.Level(v336)
			local v339, v340 = v_u_20.Progress(v336)
			local v341 = v_u_20.CategoryColor(v336)
			local v342 = v337 == "locked"
			local v343
			if v_u_332 == nil then
				v343 = false
			else
				v343 = v_u_332.id == v336
			end
			if v_u_334 ~= v336 then
				v_u_334 = v336
				v_u_19.Set(v_u_62, v336, {
					["spin"] = true,
					["outline"] = true,
					["glow"] = false,
					["outlineColor"] = nil,
					["outlineScale"] = 1.035,
					["outlineTransparency"] = 0.5,
					["outlineColor"] = v341:Lerp(Color3.new(1, 1, 1), 0.55)
				})
				v_u_15.Pop(v_u_62, 0.85, v_u_16.Tween.PopSmall)
			end
			v_u_19.SetDim(v_u_62, v342)
			v_u_74.Text = string.upper(v_u_18.Name(v336))
			local v344 = v_u_18.Get(v336)
			local v345 = string.upper(v344 and (v_u_18.CATEGORY_SINGULAR[v344.category] or "") or "")
			if v342 then
				v_u_76.Text = string.format("%s  <font color=\"%s\">\194\183  LOCKED</font>", v345, v_u_34)
			elseif v337 == "max" then
				v_u_76.Text = string.format("%s  <font color=\"%s\">\194\183  MAX LEVEL</font>", v345, v_u_49)
			elseif v337 == "fixed" then
				v_u_76.Text = string.format("%s  <font color=\"%s\">\194\183  NO LEVELS</font>", v345, v_u_34)
			else
				local v346 = v_u_76
				local v347 = string.format
				local v348 = v_u_21.TextDim
				local v349 = string.format
				local v350 = v348.R * 255 + 0.5
				local v351 = math.floor(v350)
				local v352 = v348.G * 255 + 0.5
				local v353 = math.floor(v352)
				local v354 = v348.B * 255 + 0.5
				v346.Text = v347("%s  <font color=\"%s\">\194\183  LEVEL %d OF %d</font>", v345, v349("#%02X%02X%02X", v351, v353, (math.floor(v354))), v338, v_u_24)
			end
			local v355 = v337 == "fixed"
			if v342 then
				v341 = v_u_21.TextMuted
			elseif v337 == "ready" then
				v341 = v_u_25
			elseif v337 == "max" then
				v341 = v_u_26
			end
			v_u_60.Color = ColorSequence.new(v341:Lerp(v_u_21.Panel, 1 - (v342 and 0.18 or 0.35)), v_u_21.PanelHi:Lerp(v_u_21.Panel, 0.6))
			v_u_61.ImageColor3 = v341
			v_u_61.ImageTransparency = v342 and 0.8 or 0.5
			v_u_57.Color = ColorSequence.new(v341:Lerp(v_u_21.Panel, 0.9), v_u_21.PanelLo)
			local v356 = v_u_58
			local v357
			if v337 == "ready" then
				v357 = v_u_25
			elseif v337 == "max" then
				v357 = v_u_26
			else
				v357 = v_u_21.Stroke
			end
			v356.Color = v357
			v_u_58.Transparency = (v337 == "ready" or v337 == "max") and 0.55 or 0.88
			v_u_73.Visible = v342
			v_u_67.Visible = not v342
			if not v343 then
				if v337 == "max" then
					v_u_67.BackgroundColor3 = v_u_26
					v_u_67.BackgroundTransparency = 0
					v_u_69.Text = "MAX"
					v_u_69.TextSize = 18
					v_u_69.TextColor3 = v_u_21.TextDark
					v_u_69.Size = v_u_23(52, 34)
					v_u_70.Visible = false
					v_u_67.Size = v_u_23(76, 34)
				else
					v_u_67.BackgroundColor3 = v_u_21.Void
					v_u_67.BackgroundTransparency = 0.2
					v_u_69.Text = "LV"
					v_u_69.TextSize = 14
					v_u_69.TextColor3 = v_u_21.TextDim
					v_u_69.Size = v_u_23(22, 34)
					v_u_70.Visible = true
					v_u_71.Text = tostring(v338)
					v_u_71.Position = UDim2.new()
					v_u_71.TextColor3 = v_u_21.Text
					v_u_72.Text = ""
					v_u_67.Size = v_u_23(v338 >= 10 and 90 or 70, 34)
				end
				local v358 = v_u_68
				local v359
				if v337 == "ready" then
					v359 = v_u_25
				else
					v359 = v_u_21.Stroke
				end
				v358.Color = v359
				v_u_68.Transparency = v337 == "ready" and 0.2 or 0.8
			end
			local v360
			if v340 > 0 then
				local v361 = v339 / v340
				v360 = math.clamp(v361, 0, 1)
			else
				v360 = 1
			end
			if v337 == "max" then
				v_u_79.Set(1, true)
				v_u_79.SetColor(v_u_26)
				v_u_80.Text = "MAX"
				v_u_78.Text = "MAX LEVEL"
				v_u_78.TextColor3 = v_u_26
			elseif v355 then
				v_u_79.Set(0, true)
				v_u_80.Text = "NO LEVELS"
				v_u_78.Text = ""
			else
				if not v343 then
					v_u_79.Set(v360)
					local v362 = v_u_79.SetColor
					local v363
					if v337 == "ready" then
						v363 = v_u_25
					elseif v342 then
						v363 = v_u_21.AccentDark
					else
						v363 = v_u_21.Accent
					end
					v362(v363)
					v_u_80.Text = string.format("%d / %d", v339, v340)
				end
				v_u_78.Text = v342 and "TO UNLOCK" or "TO LEVEL " .. v338 + 1
				local v364 = v_u_78
				local v365
				if v337 == "ready" then
					v365 = v_u_16.Lighten(v_u_25, 0.15)
				else
					v365 = v_u_21.TextDim
				end
				v364.TextColor3 = v365
			end
			local v366 = v_u_20.StatWord(v336) or "damage"
			v_u_82.Text = v355 and "NO LEVEL BONUS" or string.upper(v366) .. " BONUS"
			v_u_87.Text = v366
			v_u_83.Visible = not v355
			v_u_92.Visible = not v355
			local v367 = v342 and 0 or v_u_20.BonusPercent(v338)
			local v368 = v_u_20.BonusPercent
			local v369 = v_u_24
			local v370 = math.max(v338, 1) + 1
			local v371 = v368((math.min(v369, v370)))
			if not v343 then
				v_u_89(v367, true)
				v_u_91(v371, true)
			end
			local v372 = v_u_84
			local v373
			if v342 then
				v373 = v_u_21.TextMuted
			elseif v337 == "max" then
				v373 = v_u_26
			else
				v373 = v_u_21.Text
			end
			v372.TextColor3 = v373
			local v374 = v_u_85
			local v375
			if v337 == "max" then
				v375 = false
			else
				v375 = not v342
			end
			v374.Visible = v375
			local v376 = v_u_86
			local v377
			if v337 == "max" then
				v377 = false
			else
				v377 = not v342
			end
			v376.Visible = v377
			if not v343 then
				for v378, v379 in v_u_93 do
					local v380 = v378 <= v338
					local v381
					if v380 then
						if v337 == "max" then
							v381 = v_u_26
						else
							v381 = v_u_21.Accent
						end
					elseif v378 == v338 + 1 and v337 == "ready" then
						v381 = v_u_25
					else
						v381 = v_u_21.Inset
					end
					v379.BackgroundColor3 = v381
					v379.BackgroundTransparency = (v380 or v378 == v338 + 1 and v337 == "ready") and 0 or 0.1
				end
			end
			local v382 = v_u_20.BONUS_PER_LEVEL * 100 + 0.5
			local v383 = math.floor(v382)
			if v355 then
				v_u_98.Text = "Nothing on this item scales with levels: it\'s the same for everyone, and it never drops once you own it."
			elseif v342 and not v_u_20.RankAllows(v336) then
				local v384 = v_u_6.Ranks.Get(v_u_20.ItemRank(v336))
				v_u_98.Text = string.format("Joins your drops at %s (%s trophies). Win matches to climb the Rank Road.", v384.name, v_u_15.FormatNumber(v384.trophies))
			elseif v342 and v_u_20.MaxLevel(v336) <= 1 then
				v_u_98.Text = "Nothing on this item scales with levels: unlock it once and it\'s yours."
			elseif v342 then
				v_u_98.Text = string.format("Unlocks at level 1. Each level after that adds +%d%% %s, up to +%d%%.", v383, v366, v_u_20.MaxBonusPercent())
			elseif v337 == "max" then
				v_u_98.Text = string.format("Maxed out: +%d%% %s for good. The cap may rise in a later update.", v367, v366)
			elseif v338 <= 1 then
				v_u_98.Text = string.format("Level %d adds +%d%% %s.", v338 + 1, v383, v366)
			else
				v_u_98.Text = string.format("Level %d adds another +%d%% %s (max +%d%%).", v338 + 1, v383, v366, v_u_20.MaxBonusPercent())
			end
			local v385 = v340 - v339
			local v386 = math.max(0, v385)
			v_u_101.ImageTransparency = 1
			if v342 and not v_u_20.RankAllows(v336) then
				local v387 = v_u_20.ItemRank(v336)
				v_u_102:SetStyle("Dark")
				v_u_102:SetEnabled(true)
				v_u_102:SetText("UNLOCKS AT " .. string.upper(v_u_6.Ranks.Get(v387).name))
				v_u_103.Text = "See the Rank Road"
			elseif v342 then
				local v388 = v_u_20.ItemKey(v336)
				local v389 = v_u_20.CanBuy(v388)
				local v390 = v_u_20.Pending(v388)
				if v389 then
					v_u_102:SetStyle("Primary")
					v_u_102:SetEnabled(not v390)
					v_u_102:SetText(v390 and "UNLOCKING\226\128\166" or string.format("UNLOCK NOW   <font color=\"%s\">%s</font> %s", "#FFFFFF", v_u_20.ROBUX, v_u_20.PriceAmount(v388)))
					v_u_103.Text = string.format("or find %d more shard%s in drops", v386, v386 == 1 and "" or "s")
				else
					v_u_102:SetStyle("Dark")
					v_u_102:SetEnabled(false)
					v_u_102:SetText(string.format("FIND %d MORE SHARD%s", v386, v386 == 1 and "" or "S"))
					v_u_103.Text = "Win matches to find shards"
				end
			elseif v337 == "max" or v355 then
				v_u_102:SetStyle("Dark")
				v_u_102:SetEnabled(false)
				v_u_102:SetText(v355 and "NO UPGRADES" or "MAX LEVEL")
				v_u_103.Text = "It won\'t drop any more: shards go to your other items"
			elseif v337 == "ready" then
				local v391 = v_u_335 == v336 and true or v_u_20.Upgrading(v336)
				v_u_102:SetStyle("Success")
				v_u_102:SetEnabled(not v391)
				v_u_102:SetText(v391 and "UPGRADING\226\128\166" or string.format("UPGRADE TO LV %d", v338 + 1))
				v_u_103.Text = string.format("Spends %d shards  \194\183  <font color=\"%s\">%s</font>", v340, v_u_42, v_u_20.BonusText(v336, v338 + 1))
			else
				v_u_102:SetStyle("Dark")
				v_u_102:SetEnabled(false)
				v_u_102:SetText(string.format("NEED %d MORE SHARD%s", v386, v386 == 1 and "" or "S"))
				v_u_103.Text = "Win matches to find shards"
			end
			v_u_103.Visible = v_u_305
			if v343 then
				v_u_102:SetEnabled(false)
			end
		end
	end
	local function v_u_425() -- name: layoutWindow
		-- upvalues: (copy) v_u_15, (copy) v_u_52, (copy) v_u_23, (copy) v_u_54, (copy) v_u_331, (copy) v_u_56, (ref) v_u_105, (copy) v_u_104, (copy) v_u_116, (copy) v_u_117, (copy) v_u_122, (copy) v_u_123, (copy) v_u_124, (copy) v_u_121, (copy) v_u_119, (copy) v_u_120
		local v393 = v_u_15.CanvasSize()
		local v394 = v_u_15.TopInset()
		local v395 = v_u_15.Compact
		if v395 then
			local v396 = v_u_52.Holder
			local v397 = v_u_23
			local v398 = v393.X - 24
			local v399 = math.clamp(v398, 340, 1180)
			local v400 = math.floor(v399)
			local v401 = v393.Y - v394 - 12
			local v402 = math.clamp(v401, 300, 720)
			v396.Size = v397(v400, (math.floor(v402)))
		else
			local v403 = v_u_52.Holder
			local v404 = v_u_23
			local v405 = v393.X - 160
			local v406 = math.clamp(v405, 1180, 1400)
			local v407 = math.floor(v406)
			local v408 = v393.Y - v394 - 40
			local v409 = math.clamp(v408, 720, 940)
			v403.Size = v404(v407, (math.floor(v409)))
		end
		v_u_52.Subtitle.Visible = true
		v_u_52.Subtitle.TextSize = v395 and 15 or 17
		v_u_54.TextSize = v395 and 14 or 16
		v_u_54.Position = UDim2.new(1, -(v_u_15.WindowCloseSize() + 34), 0, v395 and 18 or 22)
		local v410 = v_u_52.Holder.Size.X.Offset - 44
		local v411 = v_u_52.Holder.Size.Y.Offset - 80 - 32
		local v412
		if v395 then
			v412 = 300
		else
			local v413 = v410 * 0.28
			local v414 = math.floor(v413)
			v412 = math.clamp(v414, 330, 390)
		end
		local v415 = v395 and 14 or 20
		v_u_331(v412, v411, v395)
		v_u_56.Position = v_u_23(0, 0)
		v_u_105 = v410 - v412 - v415
		v_u_104.Position = v_u_23(v412 + v415, 0)
		v_u_104.Size = UDim2.new(0, v_u_105, 1, 0)
		local v416 = v_u_105 - 12
		v_u_116.Size = UDim2.new(1, -12, 0, v395 and 92 or 104)
		v_u_117.Size = v_u_23(v395 and 64 or 76, v395 and 64 or 76)
		local v417 = v395 and 104 or 122
		local v418 = v395 and 138 or 150
		local v419 = v395 and 152 or 166
		v_u_122.Instance.Size = v_u_23(v417, 46)
		v_u_123.Instance.Size = v_u_23(v418, 46)
		v_u_124.Instance.Size = v_u_23(v419, 46)
		local v420 = v417 + v418 + v419 + 20
		v_u_121.Size = v_u_23(v420, 50)
		local v421 = (v395 and 64 or 76) + 28
		v_u_119.Position = v_u_23(v421, v395 and 12 or 18)
		v_u_119.TextSize = v395 and 21 or 24
		v_u_120.Position = v_u_23(v421, v395 and 40 or 48)
		local v422 = v_u_120
		local v423 = v_u_23
		local v424 = v416 - v421 - v420 - 28
		v422.Size = v423(math.max(160, v424), v395 and 44 or 42)
		v_u_120.TextSize = v395 and 13 or 14
	end
	local function v_u_470(p426) -- name: layoutGrid
		-- upvalues: (ref) v_u_105, (copy) v_u_15, (copy) v_u_226, (ref) v_u_229, (copy) v_u_20, (copy) v_u_116, (copy) v_u_23, (copy) v_u_111, (copy) v_u_112, (copy) v_u_34, (copy) v_u_16, (copy) v_u_104
		local v427 = v_u_105 - 12
		local v428 = (v427 + 12) / 162
		local v429 = math.floor(v428)
		local v430 = math.clamp(v429, 2, 7)
		local v431 = (v427 - (v430 - 1) * 12) / v430
		local v432 = math.floor(v431)
		local v433 = v_u_15.Compact and 30 or 34
		local v434 = v_u_15.Compact and 184 or 212
		local v_u_435 = {}
		local v436 = {
			["owned"] = {},
			["locked"] = {}
		}
		for v437, v438 in v_u_226 do
			v_u_435[v438] = v437
			v_u_229(v438)
			v438.section = v438.state == "locked" and "locked" or "owned"
			local v439 = v436[v438.section]
			table.insert(v439, v438)
		end
		table.sort(v436.owned, function(p440, p441)
			-- upvalues: (copy) v_u_435
			local v442 = p440.state == "ready"
			if v442 == (p441.state == "ready") then
				return v_u_435[p440] < v_u_435[p441]
			else
				return v442
			end
		end)
		table.sort(v436.locked, function(p443, p444)
			-- upvalues: (ref) v_u_20, (copy) v_u_435
			local v445, v446 = v_u_20.Progress(p443.id)
			local v447 = v445 / math.max(v446, 1)
			local v448, v449 = v_u_20.Progress(p444.id)
			local v450 = v448 / math.max(v449, 1)
			if v447 == v450 then
				if v446 == v449 then
					return v_u_435[p443] < v_u_435[p444]
				else
					return v446 < v449
				end
			else
				return v450 < v447
			end
		end)
		local v451 = v_u_20.DropsAllowed()
		v_u_116.Visible = v451
		local v452
		if v451 then
			v_u_116.Position = v_u_23(4, 4)
			v452 = v_u_116.Size.Y.Offset + 14
		else
			v452 = 0
		end
		for _, v453 in v_u_111 do
			local v454 = v436[v453]
			local v455 = v_u_112[v453]
			v455.frame.Visible = #v454 > 0
			if #v454 <= 0 then
				continue
			end
			local v456 = v453 == "owned" and "YOUR ITEMS" or "LOCKED"
			v455.title.Text = string.format("%s  <font color=\"%s\">\194\183  %d</font>", v456, v_u_34, #v454)
			v455.sub.TextSize = v_u_15.Compact and 13 or 14
			v455.frame.Size = UDim2.new(1, -8, 0, v433)
			v455.frame.Position = v_u_23(4, v452)
			local v457 = v452 + v433
			for v458, v459 in v454 do
				local v460 = (v458 - 1) % v430
				v459.y = v457 + (v458 - 1) // v430 * (v434 + 12)
				v459.h = v434
				v459.visible = true
				v459.holder.Visible = true
				local v461 = v_u_23(v460 * (v432 + 12) + 4, v459.y + 4)
				if p426 and (v459.shown and v459.holder.Position ~= v461) then
					v_u_15.Tween(v459.holder, v_u_16.Tween.Smooth, {
						["Position"] = v461
					})
				else
					v459.holder.Position = v461
				end
				v459.holder.Size = v_u_23(v432, v434)
				local v462 = v459.glow
				local v463 = v_u_23
				local v464 = v432 * 1.05
				v462.Size = v463(math.floor(v464), 150)
				local v465 = v459.glow
				local v466 = UDim2.new
				local v467 = (v434 - 88) / 2
				v465.Position = v466(0.5, 0, 0, math.floor(v467) + 6)
			end
			local v468 = #v454 / v430
			v452 = v457 + (math.ceil(v468) * (v434 + 12) + 12)
		end
		for _, v469 in v_u_226 do
			v469.shown = v469.visible
		end
		v_u_104.CanvasSize = v_u_23(0, v452 + 8)
	end
	local function v_u_476() -- name: paintSummary
		-- upvalues: (copy) v_u_18, (copy) v_u_20, (copy) v_u_34, (copy) v_u_42, (copy) v_u_54
		local v471 = 0
		local v472 = 0
		for _, v473 in v_u_18.AllItems() do
			v471 = v471 + 1
			if not v_u_20.Owns(v473.id) then
				continue
			end
			v472 = v472 + 1
		end
		local v474 = v_u_20.UpgradesReady()
		local v475 = string.format("%d / %d <font color=\"%s\">UNLOCKED</font>", v472, v471, v_u_34)
		if v474 > 0 then
			v475 = v475 .. string.format("   <font color=\"%s\">\194\183   %d UPGRADE%s READY</font>", v_u_42, v474, v474 == 1 and "" or "S")
		end
		v_u_54.Text = v475
	end
	local function v_u_478(p477)
		-- upvalues: (copy) v_u_470, (ref) v_u_392, (copy) v_u_218, (copy) v_u_476, (copy) v_u_303
		v_u_470(p477)
		v_u_392()
		v_u_218()
		v_u_476()
		task.defer(v_u_303)
	end
	local function v_u_481(p479, p480) -- name: flashCard
		-- upvalues: (copy) v_u_21, (copy) v_u_15
		p479.flash.BackgroundColor3 = p480 or v_u_21.Accent
		p479.flash.BackgroundTransparency = 0.65
		v_u_15.Tween(p479.flash, TweenInfo.new(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["BackgroundTransparency"] = 1
		})
	end
	v_u_230 = function(p482, p483)
		-- upvalues: (copy) v_u_227, (ref) v_u_228, (ref) v_u_229, (ref) v_u_392, (copy) v_u_15, (copy) v_u_62, (copy) v_u_16
		if v_u_227[p482] then
			local v484 = v_u_228
			if v484 then
				v484 = v_u_227[v_u_228]
			end
			v_u_228 = p482
			if v484 then
				v_u_229(v484)
			end
			v_u_229(v_u_227[p482])
			v_u_392()
			if type(p483) ~= "table" or not p483.quiet then
				v_u_15.Pop(v_u_62, 0.9, v_u_16.Tween.PopSmall)
			end
		end
	end
	local function v_u_497(p485) -- name: shardBurst
		-- upvalues: (copy) v_u_15, (copy) v_u_23, (copy) v_u_16, (copy) v_u_65
		local v486 = v_u_15.Touch and 9 or 14
		for v487 = 1, v486 do
			local v488 = v487 / v486 * 3.141592653589793 * 2 + math.random() * 0.4
			local v489 = 0.32 + math.random() * 0.22
			local v490 = math.random(12, 22)
			local v491 = v_u_15.Image
			local v492 = v_u_15.Assets.Fx.Shard
			local v493 = {
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Rotation"] = nil,
				["ImageColor3"] = nil,
				["ImageTransparency"] = 0.05,
				["ZIndex"] = 7,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.52),
				["Size"] = v_u_23(v490, v490),
				["Rotation"] = math.random(0, 360)
			}
			local v494
			if v487 % 3 == 0 then
				v494 = v_u_16.Lighten(p485, 0.25)
			else
				v494 = p485
			end
			v493.ImageColor3 = v494
			v493.Parent = v_u_65
			local v_u_495 = v491(v492, v493)
			local v496 = TweenInfo.new(0.6 + math.random() * 0.25, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
			v_u_15.Tween(v_u_495, v496, {
				["Position"] = nil,
				["Rotation"] = nil,
				["ImageTransparency"] = 1,
				["Size"] = nil,
				["Position"] = UDim2.fromScale(0.5 + math.cos(v488) * v489, 0.52 + math.sin(v488) * v489 * 0.9),
				["Rotation"] = v_u_495.Rotation + math.random(-160, 160),
				["Size"] = v_u_23(v490 * 0.5, v490 * 0.5)
			})
			task.delay(1, function()
				-- upvalues: (copy) v_u_495
				v_u_495:Destroy()
			end)
		end
	end
	local function v_u_521(p_u_498, p499, p_u_500) -- name: levelUpMoment
		-- upvalues: (ref) v_u_333, (ref) v_u_332, (copy) v_u_24, (copy) v_u_26, (copy) v_u_25, (copy) v_u_79, (copy) v_u_63, (copy) v_u_15, (copy) v_u_59, (copy) v_u_64, (copy) v_u_23, (copy) v_u_497, (copy) v_u_61, (copy) v_u_62, (copy) v_u_16, (copy) p_u_14, (copy) v_u_67, (copy) v_u_21, (copy) v_u_69, (copy) v_u_70, (copy) v_u_71, (copy) v_u_72, (copy) v_u_68, (copy) v_u_66, (copy) v_u_20, (copy) v_u_89, (copy) v_u_91, (copy) v_u_84, (copy) v_u_93, (copy) v_u_80, (copy) v_u_227, (copy) v_u_481, (ref) v_u_478
		v_u_333 = v_u_333 + 1
		local v_u_501 = v_u_333
		v_u_332 = {
			["id"] = p_u_498,
			["token"] = v_u_501
		}
		local v_u_502 = v_u_24 <= p_u_500
		local v503
		if v_u_502 then
			v503 = v_u_26
		else
			v503 = v_u_25
		end
		v_u_79.SetColor(v_u_25)
		v_u_79.Set(1, false, TweenInfo.new(0.18, Enum.EasingStyle.Quad))
		v_u_63.BackgroundColor3 = v503
		v_u_63.BackgroundTransparency = 0.55
		v_u_15.Tween(v_u_63, TweenInfo.new(0.55, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["BackgroundTransparency"] = 1
		})
		local v504 = v_u_59.Size.X.Offset
		v_u_64.ImageColor3 = v503
		v_u_64.Size = v_u_23(60, 60)
		v_u_64.ImageTransparency = 0.15
		v_u_15.Tween(v_u_64, TweenInfo.new(0.7, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			["Size"] = nil,
			["ImageTransparency"] = 1,
			["Size"] = v_u_23(v504 * 1.4, v504 * 1.4)
		})
		v_u_497(v503)
		v_u_61.ImageColor3 = v503
		v_u_61.ImageTransparency = 0.2
		v_u_15.Tween(v_u_61, TweenInfo.new(0.9, Enum.EasingStyle.Quad), {
			["ImageTransparency"] = 0.5
		})
		v_u_15.Pop(v_u_62, 0.7, v_u_16.Tween.Slam)
		p_u_14.Sounds.Play("LevelUp")
		v_u_67.BackgroundColor3 = v_u_21.Void
		v_u_67.BackgroundTransparency = 0.2
		v_u_69.Text = "LV"
		v_u_69.TextSize = 14
		v_u_69.TextColor3 = v_u_21.TextDim
		v_u_69.Size = v_u_23(22, 34)
		v_u_70.Visible = true
		v_u_67.Size = v_u_23(70, 34)
		v_u_71.Text = tostring(p499)
		v_u_71.TextColor3 = v_u_21.Text
		v_u_71.Position = UDim2.new()
		v_u_72.Text = tostring(p_u_500)
		v_u_72.TextColor3 = v_u_26
		v_u_72.Position = UDim2.fromScale(0, 1)
		v_u_68.Color = v_u_26
		v_u_68.Transparency = 0
		task.delay(0.12, function()
			-- upvalues: (copy) v_u_501, (ref) v_u_333, (ref) p_u_14, (ref) v_u_15, (ref) v_u_71, (ref) v_u_72, (ref) v_u_67, (ref) v_u_16
			if v_u_501 == v_u_333 then
				p_u_14.Sounds.Play("XP_Tick")
				local v505 = TweenInfo.new(0.34, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
				v_u_15.Tween(v_u_71, v505, {
					["Position"] = UDim2.fromScale(0, -1)
				})
				v_u_15.Tween(v_u_72, v505, {
					["Position"] = UDim2.new()
				})
				task.delay(0.3, function()
					-- upvalues: (ref) v_u_501, (ref) v_u_333, (ref) v_u_15, (ref) v_u_67, (ref) v_u_16
					if v_u_501 == v_u_333 then
						v_u_15.Pop(v_u_67, 1.45, v_u_16.Tween.Slam)
					end
				end)
			end
		end)
		v_u_66.Text = v_u_502 and "MAX LEVEL" or "LEVEL " .. p_u_500
		local v506 = v_u_66
		local v507
		if v_u_502 then
			v507 = v_u_26
		else
			v507 = v_u_16.Lighten(v_u_25, 0.2)
		end
		v506.TextColor3 = v507
		v_u_66.Visible = true
		v_u_15.Unfade(v_u_66)
		v_u_15.Pop(v_u_66, 1.9, v_u_16.Tween.Slam)
		local v_u_508 = v_u_20.BonusPercent(p_u_500)
		local v509 = v_u_20.BonusPercent
		local v510 = v_u_24
		local v511 = p_u_500 + 1
		local v_u_512 = v509((math.min(v510, v511)))
		task.delay(0.25, function()
			-- upvalues: (copy) v_u_501, (ref) v_u_333, (ref) v_u_89, (copy) v_u_508, (ref) v_u_91, (copy) v_u_512, (ref) v_u_15, (ref) v_u_84, (ref) v_u_93, (copy) p_u_500, (copy) v_u_502, (ref) v_u_26, (ref) v_u_21, (ref) v_u_16
			if v_u_501 == v_u_333 then
				v_u_89(v_u_508)
				v_u_91(v_u_512)
				v_u_15.Bump(v_u_84, 0.2)
				for v513, v514 in v_u_93 do
					if v513 ~= p_u_500 then
						continue
					end
					local v515
					if v_u_502 then
						v515 = v_u_26
					else
						v515 = v_u_21.Accent
					end
					v514.BackgroundColor3 = v515
					v514.BackgroundTransparency = 0
					v_u_15.Pop(v514, 1.8, v_u_16.Tween.Slam)
				end
			end
		end)
		task.delay(0.35, function()
			-- upvalues: (copy) v_u_501, (ref) v_u_333, (ref) v_u_20, (copy) p_u_498, (ref) v_u_79, (copy) v_u_502, (ref) v_u_26, (ref) v_u_21, (ref) v_u_80
			if v_u_501 == v_u_333 then
				local v516, v517 = v_u_20.Progress(p_u_498)
				v_u_79.Set(0, true)
				local v518 = v_u_79.SetColor
				local v519
				if v_u_502 then
					v519 = v_u_26
				else
					v519 = v_u_21.Accent
				end
				v518(v519)
				v_u_79.Set(v517 <= 0 and 1 or v516 / v517, false, TweenInfo.new(0.5, Enum.EasingStyle.Quint))
				v_u_80.Text = v_u_502 and "MAX" or string.format("%d / %d", v516, v517)
			end
		end)
		local v520 = v_u_227[p_u_498]
		if v520 then
			v_u_481(v520, v503)
			v_u_15.Pop(v520.icon, 0.8, v_u_16.Tween.PopSmall)
		end
		task.delay(1.15, function()
			-- upvalues: (copy) v_u_501, (ref) v_u_333, (ref) v_u_15, (ref) v_u_66
			if v_u_501 == v_u_333 then
				v_u_15.FadeOut(v_u_66, TweenInfo.new(0.3))
			end
		end)
		task.delay(1.5, function()
			-- upvalues: (copy) v_u_501, (ref) v_u_333, (ref) v_u_332, (ref) v_u_66, (ref) v_u_15, (ref) v_u_478
			if v_u_501 == v_u_333 then
				v_u_332 = nil
				v_u_66.Visible = false
				v_u_15.Unfade(v_u_66)
				v_u_478(true)
			end
		end)
	end
	v_u_231 = function(p_u_522)
		-- upvalues: (ref) v_u_335, (copy) v_u_20, (copy) v_u_17, (copy) p_u_14, (ref) v_u_332, (ref) v_u_333, (ref) v_u_392, (ref) v_u_228, (ref) v_u_230, (copy) v_u_521, (copy) v_u_15, (copy) v_u_99, (ref) v_u_478
		if v_u_335 or not v_u_20.CanUpgrade(p_u_522) then
			return
		elseif v_u_17.InMatch() then
			p_u_14.Toast("Upgrade in the lobby", "warning")
		else
			v_u_335 = p_u_522
			local v_u_523 = v_u_20.Level(p_u_522)
			v_u_332 = {
				["id"] = p_u_522,
				["token"] = v_u_333
			}
			v_u_392()
			task.spawn(function()
				-- upvalues: (ref) v_u_20, (copy) p_u_522, (ref) v_u_335, (ref) v_u_228, (ref) v_u_230, (ref) v_u_521, (copy) v_u_523, (ref) v_u_332, (ref) v_u_15, (ref) v_u_99, (ref) v_u_478, (ref) v_u_392
				local v524, v525 = v_u_20.Upgrade(p_u_522, "card")
				v_u_335 = nil
				if v524 then
					if v_u_228 ~= p_u_522 then
						v_u_230(p_u_522, {
							["quiet"] = true
						})
					end
					v_u_521(p_u_522, v_u_523, v525 or v_u_523 + 1)
				else
					v_u_332 = nil
					v_u_15.Shake(v_u_99, 6)
					v_u_478(true)
				end
				v_u_392()
			end)
		end
	end
	v_u_102.Activated:Connect(function()
		-- upvalues: (ref) v_u_228, (copy) v_u_96, (ref) v_u_231, (copy) v_u_20, (copy) p_u_14, (ref) v_u_392
		local v526 = v_u_228
		if v526 then
			local v527 = v_u_96(v526)
			if v527 == "ready" then
				v_u_231(v526)
				return
			elseif v527 == "locked" and not v_u_20.RankAllows(v526) then
				p_u_14.Sounds.Play("Click")
				if p_u_14.RankRoad then
					p_u_14.RankRoad.Focus(v_u_20.ItemRank(v526))
				else
					p_u_14.EnsureScreen("RankRoad")
					if p_u_14.RankRoad then
						p_u_14.RankRoad.Focus(v_u_20.ItemRank(v526))
					end
				end
				p_u_14.MenuManager.Open("Ranks")
			elseif v527 == "locked" then
				local v528 = v_u_20.ItemKey(v526)
				if v_u_20.CanBuy(v528) then
					v_u_20.Buy(v528)
					v_u_392()
				end
			end
		else
			return
		end
	end)
	v_u_1.Heartbeat:Connect(function()
		-- upvalues: (copy) v_u_52, (copy) v_u_226, (ref) v_u_228, (copy) v_u_96, (ref) v_u_332, (ref) v_u_335, (copy) v_u_100, (copy) v_u_101
		if v_u_52.IsOpen then
			local v529 = os.clock() * 4.2
			local v530 = math.sin(v529) * 0.5 + 0.5
			for _, v531 in v_u_226 do
				if v531.state ~= "ready" or not v531.visible then
					continue
				end
				if v_u_228 ~= v531.id then
					v531.stroke.Transparency = v530 * 0.45 + 0.1
				end
				v531.upScale.Scale = v530 * 0.035 + 1
				v531.upGlow.ImageTransparency = (1 - v530) * 0.35 + 0.45
			end
			local v532 = v_u_228
			if v532 and (v_u_96(v532) == "ready" and (not v_u_332 and v_u_335 == nil)) then
				v_u_100.Scale = v530 * 0.025 + 1
				v_u_101.ImageTransparency = (1 - v530) * 0.4 + 0.45
			elseif v_u_100.Scale ~= 1 then
				v_u_100.Scale = 1
				v_u_101.ImageTransparency = 1
			end
		else
			return
		end
	end)
	local v_u_533 = false
	local v_u_534 = {}
	local function v_u_540(p535, p536) -- name: stepAside
		-- upvalues: (copy) v_u_534, (copy) v_u_52, (ref) v_u_533, (ref) v_u_334, (ref) v_u_478, (ref) v_u_228, (copy) v_u_227, (copy) v_u_481
		local v537 = next(v_u_534) ~= nil
		v_u_534[p535] = p536 and true or nil
		local v538 = next(v_u_534) ~= nil
		if v538 == v537 then
			return
		elseif v538 and v_u_52.IsOpen then
			v_u_52.Holder.Visible = false
		elseif not v538 then
			v_u_52.Holder.Visible = true
			if v_u_52.IsOpen and v_u_533 then
				v_u_334 = nil
				v_u_478(true)
				local v539 = v_u_228
				if v539 then
					v539 = v_u_227[v_u_228]
				end
				if v539 then
					v_u_481(v539)
				end
			end
		end
	end
	v_u_20.Changed:Connect(function()
		-- upvalues: (copy) v_u_52, (ref) v_u_533, (ref) v_u_332, (ref) v_u_478, (copy) v_u_218
		if v_u_52.IsOpen and (v_u_533 and not v_u_332) then
			v_u_478(true)
		elseif v_u_52.IsOpen and v_u_533 then
			v_u_218()
		end
	end)
	v_u_15.Every(v_u_52.Root, 1, function()
		-- upvalues: (copy) v_u_52, (ref) v_u_533, (copy) v_u_20, (copy) v_u_218
		if v_u_52.IsOpen and (v_u_533 and v_u_20.OfferLeft()) then
			v_u_218()
		end
	end)
	v_u_20.CelebrationChanged:Connect(function(p541)
		-- upvalues: (copy) v_u_540
		v_u_540("unlock", p541)
	end)
	v_u_20.RevealChanged:Connect(function(p542)
		-- upvalues: (copy) v_u_540
		v_u_540("reveal", p542)
	end)
	v_u_20.Event:Connect(function(p543, p544)
		-- upvalues: (copy) v_u_52, (copy) v_u_227, (ref) v_u_230
		if p543 == "Unlocked" then
			local v545 = p544.item
			if type(v545) == "string" and (v_u_52.IsOpen and v_u_227[p544.item]) then
				v_u_230(p544.item, {
					["quiet"] = true
				})
			end
		end
	end)
	local function v_u_548() -- name: firstTarget
		-- upvalues: (copy) v_u_226
		local v546 = nil
		for _, v547 in v_u_226 do
			if not v547.visible or v546 and (v547.y >= v546.y and (v547.y ~= v546.y or v547.holder.Position.X.Offset >= v546.holder.Position.X.Offset)) then
				continue
			end
			v546 = v547
		end
		return v546 and v546.holder or nil
	end
	local v590 = {
		["open"] = function(p549) -- name: open
			-- upvalues: (copy) v_u_425, (ref) v_u_533, (copy) v_u_18, (copy) v_u_259, (copy) v_u_226, (copy) v_u_227, (ref) v_u_334, (copy) v_u_128, (ref) v_u_8, (ref) v_u_2, (ref) v_u_3, (copy) v_u_52, (copy) v_u_20, (copy) v_u_223, (copy) v_u_470, (ref) v_u_228, (copy) v_u_548, (ref) v_u_478, (copy) v_u_104, (ref) v_u_105, (copy) v_u_15, (copy) v_u_481, (copy) v_u_303, (copy) v_u_23, (ref) v_u_4
			v_u_425()
			if not v_u_533 then
				v_u_533 = true
				for _, v550 in v_u_18.AllItems() do
					local v551 = v_u_259(v550)
					local v552 = v_u_226
					table.insert(v552, v551)
					v_u_227[v550.id] = v551
				end
			end
			v_u_334 = nil
			v_u_128.Visible = false
			if not v_u_8 then
				local v_u_553 = {}
				local function v556()
					-- upvalues: (ref) v_u_2, (copy) v_u_553, (ref) v_u_3
					if v_u_2.ChatVersion == Enum.ChatVersion.TextChatService then
						local v554 = v_u_2:FindFirstChildOfClass("ChatWindowConfiguration")
						local v555 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
						if v554 then
							v_u_553.window = v554.Enabled
							v554.Enabled = false
						end
						if v555 then
							v_u_553.bar = v555.Enabled
							v555.Enabled = false
							return
						end
					else
						v_u_553.core = v_u_3:GetCoreGuiEnabled(Enum.CoreGuiType.Chat)
						v_u_3:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, false)
					end
				end
				pcall(v556)
				v_u_8 = v_u_553
			end
			v_u_52:Open()
			local v_u_557
			if type(p549) == "table" then
				local v558 = p549.focus
				if type(v558) == "string" and v_u_227[p549.focus] then
					v_u_557 = p549.focus or nil
				else
					v_u_557 = nil
				end
			else
				v_u_557 = nil
			end
			if type(p549) == "table" and (p549.odds == true and v_u_20.DropsAllowed()) then
				task.delay(0.15, v_u_223)
			end
			task.defer(function()
				-- upvalues: (ref) v_u_226, (ref) v_u_470, (ref) v_u_228, (copy) v_u_557, (ref) v_u_20, (ref) v_u_227, (ref) v_u_548, (ref) v_u_478, (ref) v_u_104, (ref) v_u_105, (ref) v_u_15, (ref) v_u_481, (ref) v_u_303, (ref) v_u_23, (ref) v_u_4
				for _, v559 in v_u_226 do
					v559.shown = false
				end
				v_u_470(false)
				local v560 = v_u_557
				if not v560 then
					if v_u_20.UpgradesReady() > 0 then
						v560 = nil
					else
						v560 = v_u_228
					end
					if not v560 then
						local v561 = v_u_20.ReadyList()
						if v561[1] then
							v560 = v561[1]
						else
							v560 = v_u_20.Spotlight()
							if not (v560 and v_u_227[v560]) then
								local v562 = v_u_548()
								v560 = v562 and v562.Name or nil
							end
						end
					end
				end
				v_u_228 = v560
				v_u_478(false)
				local v_u_563 = v_u_228 and v_u_227[v_u_228] or nil
				local v564
				if v_u_563 and v_u_557 then
					local v565 = v_u_105
					local v566 = v_u_104.AbsoluteSize.X / math.max(v565, 1)
					local v567 = math.max(v566, 0.01)
					local v568 = v_u_104.AbsoluteCanvasSize.Y - v_u_104.AbsoluteWindowSize.Y
					local v569 = math.max(0, v568)
					local v570 = v_u_15.Compact and 30 or 34
					local v571 = v_u_563.y - v570 - 4
					local v572 = math.max(0, v571) * v567
					v564 = math.min(v572, v569)
					task.delay(0.25, function()
						-- upvalues: (ref) v_u_481, (copy) v_u_563
						v_u_481(v_u_563)
					end)
				else
					v564 = 0
				end
				v_u_104.CanvasPosition = Vector2.new(0, v564)
				v_u_303()
				local v573 = 0
				for _, v574 in v_u_226 do
					if not v574.visible or v574.y >= 520 then
						continue
					end
					v574.inner.Position = v_u_23(0, 14)
					local v575 = v_u_15.Tween
					local v576 = v574.inner
					local v577 = TweenInfo.new
					local v578 = Enum.EasingStyle.Quint
					local v579 = Enum.EasingDirection.Out
					local v580 = v573 * 0.018
					v575(v576, v577(0.32, v578, v579, 0, false, (math.min(v580, 0.2))), {
						["Position"] = UDim2.new()
					})
					v573 = v573 + 1
				end
				if v_u_15.Gamepad then
					local v581 = v_u_4
					local v582
					if v_u_563 then
						v582 = v_u_563.holder
					else
						v582 = v_u_548()
					end
					v581.SelectedObject = v582
				end
			end)
		end,
		["close"] = function(p583) -- name: close
			-- upvalues: (ref) v_u_8, (ref) v_u_2, (ref) v_u_3, (copy) v_u_128, (ref) v_u_4, (copy) v_u_52
			local v_u_584 = v_u_8
			if v_u_584 then
				v_u_8 = nil
				local function v587()
					-- upvalues: (ref) v_u_2, (copy) v_u_584, (ref) v_u_3
					local v585 = v_u_2:FindFirstChildOfClass("ChatWindowConfiguration")
					local v586 = v_u_2:FindFirstChildOfClass("ChatInputBarConfiguration")
					if v585 and v_u_584.window ~= nil then
						v585.Enabled = v_u_584.window
					end
					if v586 and v_u_584.bar ~= nil then
						v586.Enabled = v_u_584.bar
					end
					if v_u_584.core ~= nil then
						v_u_3:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, v_u_584.core)
					end
				end
				pcall(v587)
			end
			v_u_128.Visible = false
			local v588 = v_u_4.SelectedObject
			if v588 and v588:IsDescendantOf(v_u_52.Root) then
				v_u_4.SelectedObject = nil
			end
			v_u_52:Close(p583)
		end,
		["back"] = function() -- name: back
			-- upvalues: (copy) v_u_128, (ref) v_u_4, (copy) v_u_122
			if not v_u_128.Visible then
				return false
			end
			if v_u_128.Visible then
				v_u_128.Visible = false
				local v589 = v_u_4.SelectedObject
				if v589 and v589:IsDescendantOf(v_u_128) then
					v_u_4.SelectedObject = v_u_122.Instance
				end
			end
			return true
		end
	}
	p_u_14.MenuManager.Register("Collection", v590)
	v_u_52.Closed:Connect(v_u_13)
	v_u_17.PlayerStateChanged:Connect(function(p591)
		-- upvalues: (copy) p_u_14
		if p591 == "Match" and p_u_14.MenuManager.IsOpen("Collection") then
			p_u_14.MenuManager.Close("Collection", true)
		end
	end)
	local function v592() -- name: relayout
		-- upvalues: (copy) v_u_52, (copy) v_u_425, (ref) v_u_334, (ref) v_u_478
		if v_u_52.IsOpen then
			v_u_425()
			v_u_52.Refit()
			v_u_334 = nil
			task.defer(v_u_478)
		end
	end
	v_u_15.LayoutChanged:Connect(v592)
	v_u_15.OnResize(v592)
	function p_u_14.Debug.collection(p593, p594, p595, p596)
		-- upvalues: (ref) v_u_228, (copy) p_u_14, (ref) v_u_230, (copy) v_u_102, (copy) v_u_20, (copy) v_u_218, (copy) v_u_223, (copy) v_u_128, (ref) v_u_4, (copy) v_u_122, (copy) v_u_104, (copy) v_u_227, (copy) v_u_548, (copy) v_u_521, (copy) v_u_226, (copy) v_u_52, (copy) v_u_116, (copy) v_u_133, (ref) v_u_332, (ref) v_u_105
		local v597
		if type(p594) == "string" then
			v597 = p594
		else
			v597 = v_u_228
		end
		if p593 == "open" then
			p_u_14.MenuManager.Open("Collection", type(p594) == "string" and {
				["focus"] = p594
			} or nil)
		elseif p593 == "select" and type(p594) == "string" then
			v_u_230(p594)
		elseif p593 == "upgrade" and v597 then
			if v_u_228 ~= v597 then
				v_u_230(v597, {
					["quiet"] = true
				})
			end
			v_u_102.Activated:Fire()
		elseif p593 == "unlock" and v597 then
			if v_u_228 ~= v597 then
				v_u_230(v597, {
					["quiet"] = true
				})
			end
			v_u_102.Activated:Fire()
		elseif p593 == "buy" then
			local v598 = p594 == 5 and 5 or 1
			if v_u_20.DropsAllowed() then
				v_u_20.Buy(v_u_20.DropKey(v598))
				v_u_218()
			end
		elseif p593 == "odds" then
			v_u_223()
		elseif p593 == "closeOdds" then
			if v_u_128.Visible then
				v_u_128.Visible = false
				local v599 = v_u_4.SelectedObject
				if v599 and v599:IsDescendantOf(v_u_128) then
					v_u_4.SelectedObject = v_u_122.Instance
				end
			end
		elseif p593 == "scroll" and type(p594) == "number" then
			v_u_104.CanvasPosition = Vector2.new(0, p594)
		elseif p593 == "gamepad" then
			v_u_4.SelectedObject = v_u_228 and (v_u_227[v_u_228] and v_u_227[v_u_228].holder) or v_u_548()
		elseif p593 == "mock" then
			local v600 = v_u_20.SetMock
			if p594 == false then
				p594 = nil
			end
			v600(p594)
		elseif p593 == "reveal" then
			v_u_20.SetRevealShowing(p594 == true)
		elseif p593 == "levelup" and type(p594) == "string" then
			if v_u_228 ~= p594 then
				v_u_230(p594, {
					["quiet"] = true
				})
			end
			v_u_521(p594, tonumber(p595) or 1, tonumber(p596) or 2)
		end
		local v601 = 0
		local v602 = {
			["locked"] = 0,
			["owned"] = 0,
			["ready"] = 0,
			["max"] = 0
		}
		local v603 = 0
		for _, v604 in v_u_226 do
			if v604.rendered then
				v601 = v601 + 1
			end
			v602[v604.state] = (v602[v604.state] or 0) + 1
		end
		for _, v605 in v_u_52.Root:GetDescendants() do
			if not v605:IsA("ViewportFrame") then
				continue
			end
			v603 = v603 + 1
		end
		local v606 = v_u_228
		local v607, v608, v609
		if v606 then
			v607, v608, v609 = v_u_20.Progress(v606)
		else
			v607 = 0
			v608 = 0
			v609 = "?"
		end
		local v610 = {
			["open"] = v_u_52.IsOpen,
			["selected"] = v606 or false
		}
		local v611
		if v606 then
			v611 = v_u_20.Level(v606) or false
		else
			v611 = false
		end
		v610.level = v611
		v610.progress = v606 and string.format("%d/%d %s", v607, v608, v609) or false
		v610.action = v_u_102.Label.Text
		v610.actionEnabled = v_u_102.Enabled
		v610.cards = #v_u_226
		v610.rendered = v601
		v610.viewports = v603
		v610.locked = v602.locked
		v610.owned = v602.owned
		v610.ready = v602.ready
		v610.max = v602.max
		v610.shop = v_u_116.Visible
		v610.odds = v_u_128.Visible
		v610.oddsRows = #v_u_133:GetChildren()
		v610.animating = v_u_332 ~= nil
		local v612 = string.format
		local v613 = v_u_105
		local v614 = v_u_104.AbsoluteWindowSize.Y
		local v615 = v_u_105
		local v616 = v_u_104.AbsoluteSize.X / math.max(v615, 1)
		local v617 = v614 / math.max(v616, 0.01)
		v610.grid = v612("%dx%d", v613, (math.floor(v617)))
		local v618 = v_u_104.CanvasSize.Y.Offset
		v610.canvas = math.floor(v618)
		local v619
		if v_u_4.SelectedObject then
			v619 = v_u_4.SelectedObject:GetFullName()
		else
			v619 = false
		end
		v610.gamepadSelected = v619
		v610.mock = v_u_20.Mock ~= nil
		return v610
	end
end
return v7