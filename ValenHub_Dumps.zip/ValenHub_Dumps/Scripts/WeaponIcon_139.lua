local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
local v3 = {}
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = Color3.fromRGB(128, 132, 142)
local v_u_8 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_9 = {}
local v_u_10 = {
	["ammo_arrows"] = "Arrow",
	["ammo_shot"] = "Ball",
	["ammo_fire_arrows"] = "FireArrow",
	["fire_arrows"] = "FireArrow"
}
local v_u_11 = {
	["shield"] = true,
	["palisade"] = true,
	["harpoon"] = true,
	["scythe"] = true
}
local v_u_12 = {
	["war_horn"] = true
}
local v_u_13 = {
	["bow"] = "CrossedArrows",
	["gun"] = "CrossedArrows",
	["melee"] = "Sword",
	["throwable"] = "Sword",
	["utility"] = "Fire",
	["healing"] = "Star",
	["armor"] = "Shield"
}
local function v_u_18(p14) -- name: modelSource
	-- upvalues: (ref) v_u_6, (copy) v_u_1, (copy) v_u_10
	local v15
	if v_u_6 and v_u_6.Parent then
		v15 = v_u_6
	else
		v15 = v_u_1:FindFirstChild("Assets")
		if v15 then
			v15 = v15:FindFirstChild("Weapons")
		end
		if v15 then
			v_u_6 = v15
		end
	end
	if v15 then
		v15 = v15:FindFirstChild(p14)
	end
	if not v15 then
		v15 = v_u_1:FindFirstChild("Assets")
		local v16
		if v15 then
			v16 = v15:FindFirstChild("Armor")
		else
			v16 = v15
		end
		if v16 then
			v16 = v16:FindFirstChild(p14)
		end
		local v17 = v_u_10[p14]
		if v16 or not v17 then
			v15 = v16
		else
			if v15 then
				v15 = v15:FindFirstChild("VFX")
			end
			if v15 then
				v15 = v15:FindFirstChild("Projectiles")
			end
			if v15 then
				v15 = v15:FindFirstChild(v17)
			end
		end
	end
	if v15 and (v15:IsA("Model") or (v15:IsA("Tool") or (v15:IsA("BasePart") or v15:IsA("Folder")))) then
		return v15
	else
		return nil
	end
end
local function v_u_32(p19) -- name: cloneVisual
	local v20 = p19:GetAttribute("Armor") == true
	local v_u_21 = Instance.new("Model")
	local v_u_22 = false
	local function v27(p_u_23) -- name: copyPart
		-- upvalues: (copy) v_u_21, (ref) v_u_22
		local v24, v25 = pcall(function()
			-- upvalues: (copy) p_u_23
			return p_u_23:Clone()
		end)
		if v24 and v25 then
			for _, v26 in v25:GetDescendants() do
				if v26:IsA("DataModelMesh") or (v26:IsA("Decal") or (v26:IsA("Texture") or (v26:IsA("SurfaceAppearance") or v26:IsA("Attachment")))) then
					continue
				end
				v26:Destroy()
			end
			v25.Anchored = true
			v25.CanCollide = false
			v25.CanQuery = false
			v25.CanTouch = false
			v25.Parent = v_u_21
			v_u_22 = true
		end
	end
	if p19:IsA("BasePart") then
		v27(p19)
	end
	local v28 = v_u_22
	for _, v29 in p19:GetDescendants() do
		if not v29:IsA("BasePart") or v29.Transparency >= 1 or v20 and string.find(string.lower(v29.Name), "boots", 1, true) ~= nil then
			continue
		end
		v27(v29)
	end
	if v28 then
		if v20 then
			for _, v30 in v_u_21:GetChildren() do
				if not (v30:IsA("BasePart") and string.find(string.lower(v30.Name), "shoulder", 1, true)) then
					continue
				end
				local v31 = v30.Position.X > 0 and -0.5 or 0.5
				v30.CFrame = v30.CFrame + Vector3.new(v31, -0.12, 0)
			end
		end
		return v_u_21
	else
		v_u_21:Destroy()
		return nil
	end
end
local function v_u_43(p33, p34) -- name: computeArmorFraming
	-- upvalues: (copy) v_u_9
	local v35, v36 = p34:GetBoundingBox()
	local v37 = v35.Position
	local v38 = v36.X * 0.92
	local v39 = v36.Y * 1.05
	local v40 = math.max(v38, v39) * 0.5 * 1.04 / 0.2679491924311227 + v36.Z
	local v41 = v37 + Vector3.new(0.4005574, 0.17364818, -0.89966667) * v40
	local v42 = p34:GetPivot():Inverse()
	v_u_9[p33] = {
		["cf"] = nil,
		["dist"] = nil,
		["center"] = nil,
		["pivotInv"] = nil,
		["axis"] = Vector3.new(0, 1, 0),
		["cf"] = v42 * CFrame.lookAt(v41, v37, Vector3.new(0, 1, 0)),
		["dist"] = v40,
		["center"] = v42 * v37,
		["pivotInv"] = v42
	}
end
local function v_u_64(p44, p45, p46) -- name: computeFraming
	-- upvalues: (copy) v_u_43, (copy) v_u_11, (copy) v_u_12, (copy) v_u_9
	if p46:GetAttribute("Armor") == true then
		v_u_43(p44, p45)
	else
		local v47, v48 = p45:GetBoundingBox()
		local v49 = { v47.RightVector, v47.UpVector, v47.LookVector }
		local v_u_50 = { v48.X, v48.Y, v48.Z }
		local v51 = { 1, 2, 3 }
		table.sort(v51, function(p52, p53)
			-- upvalues: (copy) v_u_50
			return v_u_50[p52] > v_u_50[p53]
		end)
		local v54 = v49[v51[1]]
		local v55 = v49[v51[2]]
		local v56 = p46:FindFirstChild("Handle", true)
		local v57
		if v_u_11[p44] and v56 then
			v57 = v56:FindFirstChild("Tip")
		else
			v57 = nil
		end
		if v57 and v57:IsA("Attachment") then
			if (v57.WorldPosition - v47.Position):Dot(v54) < 0 then
				v54 = -v54
			end
			local v58 = -v56.CFrame.LookVector
			if (v54 - v55):Cross(v54 + v55):Dot(v58) > 0 then
				v55 = -v55
			end
		elseif v56 and (v56:IsA("BasePart") and (v56.Position - v47.Position):Dot(v54) > 0) then
			v54 = -v54
		end
		local v59 = (v54 - v55).Unit
		local v60 = (v54 + v55).Unit
		if v_u_12[p44] then
			v59 = -v59
		end
		local v61 = v59:Cross(v60).Unit
		local v62 = (v_u_50[v51[1]] + v_u_50[v51[2]]) / 1.4142135623730951 * 0.5 / 0.2679491924311227 * 1 + v_u_50[v51[3]]
		local v63 = p45:GetPivot():Inverse()
		v_u_9[p44] = {
			["cf"] = v63 * CFrame.fromMatrix(v47.Position + v61 * v62, v59, v60, v61),
			["dist"] = v62,
			["center"] = v63 * v47.Position,
			["pivotInv"] = v63
		}
	end
end
local function v_u_69(p65, p66) -- name: clearHolder
	if p66.spinConn then
		p66.spinConn:Disconnect()
		p66.spinConn = nil
	end
	for _, v67 in { "WeaponIcon", "WeaponOutline", "WeaponGlow" } do
		local v68 = p65:FindFirstChild(v67)
		if not v68 then
			continue
		end
		v68:Destroy()
	end
	p66.vpf = nil
	p66.model = nil
	p66.kind = nil
	p66.outlineCam = nil
end
local function v_u_72(p70, p71) -- name: addGlow
	-- upvalues: (ref) v_u_4
	if p71.opts.glow ~= false and v_u_4.Assets.Icons.Glow then
		v_u_4.new("ImageLabel", {
			["Name"] = "WeaponGlow",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Image"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = nil,
			["ZIndex"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromScale(1.25, 1.25),
			["Image"] = v_u_4.Assets.Icons.Glow,
			["ImageColor3"] = p71.opts.glowColor or Color3.fromRGB(96, 108, 132),
			["ImageTransparency"] = p71.opts.glowTransparency or 0.25,
			["ZIndex"] = p70.ZIndex,
			["Parent"] = p70
		})
	end
end
local v_u_73 = Color3.fromRGB(226, 232, 242)
local function v_u_86(p74, p75, p76, p77) -- name: addOutline
	-- upvalues: (ref) v_u_4, (copy) v_u_73
	if p75.opts.outline ~= false then
		local v78 = p76:Clone()
		for _, v_u_79 in v78:GetDescendants() do
			if v_u_79:IsA("BasePart") then
				v_u_79.Color = Color3.new(1, 1, 1)
				v_u_79.Material = Enum.Material.SmoothPlastic
				if not v_u_79:IsA("MeshPart") then
					continue
				end
				pcall(function()
					-- upvalues: (copy) v_u_79
					v_u_79.TextureID = ""
				end)
			elseif v_u_79:IsA("SpecialMesh") then
				v_u_79.TextureId = ""
			else
				if not (v_u_79:IsA("Decal") or (v_u_79:IsA("Texture") or v_u_79:IsA("SurfaceAppearance"))) then
					continue
				end
				v_u_79:Destroy()
			end
		end
		local v80 = v_u_4.new
		local v81 = "ViewportFrame"
		local v82 = {
			["Name"] = "WeaponOutline",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Ambient"] = nil,
			["LightColor"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = nil,
			["ZIndex"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromScale(p75.opts.outlineScale or 1.06, p75.opts.outlineScale or 1.06),
			["Ambient"] = Color3.new(1, 1, 1),
			["LightColor"] = Color3.new(0, 0, 0)
		}
		local v83
		if p75.dim then
			v83 = (p75.opts.outlineColor or v_u_73):Lerp(Color3.new(0, 0, 0), 0.4)
		else
			v83 = p75.opts.outlineColor or v_u_73
		end
		v82.ImageColor3 = v83
		v82.ImageTransparency = p75.opts.outlineTransparency or 0.15
		v82.ZIndex = p74.ZIndex
		v82.Parent = p74
		local v84 = v80(v81, v82)
		local v85 = Instance.new("Camera")
		v85.FieldOfView = 30
		v85.CFrame = p77
		v85.Parent = v84
		v84.CurrentCamera = v85
		v78.Parent = v84
		p75.outlineCam = v85
	end
end
local v_u_87 = {
	0.05,
	0.2,
	0.45,
	0.8,
	1.3,
	2,
	3,
	4.5,
	6.5
}
local function v_u_93(p_u_88, p_u_89) -- name: keepRedrawing
	-- upvalues: (copy) v_u_87
	for v_u_90, v91 in v_u_87 do
		task.delay(v91, function()
			-- upvalues: (copy) p_u_88, (copy) p_u_89, (copy) v_u_90
			if p_u_88.Parent then
				for _, v92 in p_u_89 do
					if not v92.Parent then
						continue
					end
					v92.CFrame = v92.CFrame * CFrame.new(0, 0, v_u_90 % 2 == 0 and -0.0004 or 0.0004)
				end
			end
		end)
	end
end
local function v_u_121(p_u_94, p_u_95, p96, p97) -- name: renderModel
	-- upvalues: (copy) v_u_32, (copy) v_u_9, (copy) v_u_64, (copy) v_u_72, (copy) v_u_86, (ref) v_u_4, (copy) v_u_7, (copy) v_u_93, (copy) v_u_2
	local v98 = v_u_32(p97)
	if not v98 then
		return false
	end
	v98:PivotTo(CFrame.new())
	if not v_u_9[p96] then
		v_u_64(p96, v98, p97)
	end
	local v_u_99 = v_u_9[p96]
	v_u_72(p_u_94, p_u_95)
	v_u_86(p_u_94, p_u_95, v98, v_u_99.cf)
	local v100 = (v_u_99.cf.LookVector - v_u_99.cf.UpVector * 0.8 + v_u_99.cf.RightVector * 0.5).Unit
	local v101 = v_u_99.axis ~= nil
	local v102 = v_u_4.new
	local v103 = "ViewportFrame"
	local v104 = {
		["Name"] = "WeaponIcon",
		["Size"] = nil,
		["Ambient"] = nil,
		["LightColor"] = nil,
		["LightDirection"] = nil,
		["ImageTransparency"] = nil,
		["ImageColor3"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v105
	if v101 then
		v105 = Color3.fromRGB(112, 116, 128)
	else
		v105 = Color3.fromRGB(176, 180, 192)
	end
	v104.Ambient = v105
	local v106
	if v101 then
		v106 = Color3.fromRGB(255, 248, 238)
	else
		v106 = Color3.fromRGB(255, 250, 242)
	end
	v104.LightColor = v106
	v104.LightDirection = v100
	v104.ImageTransparency = p_u_95.opts.transparency or 0
	v104.ImageColor3 = p_u_95.dim and v_u_7 or Color3.new(1, 1, 1)
	v104.ZIndex = p_u_94.ZIndex
	v104.Parent = p_u_94
	local v_u_107 = v102(v103, v104)
	local v_u_108 = Instance.new("Camera")
	v_u_108.FieldOfView = 30
	v_u_108.CFrame = v_u_99.cf
	v_u_108.Parent = v_u_107
	v_u_107.CurrentCamera = v_u_108
	v98.Parent = v_u_107
	p_u_95.vpf = v_u_107
	p_u_95.model = v98
	p_u_95.kind = "model"
	if not p_u_95.opts.spin then
		local v109 = { v_u_108 }
		if p_u_95.outlineCam then
			local v110 = p_u_95.outlineCam
			table.insert(v109, v110)
		end
		v_u_93(v_u_107, v109)
	end
	if p_u_95.opts.spin then
		local v_u_111 = CFrame.new(v_u_99.center)
		local v_u_112 = 0
		p_u_95.spinConn = v_u_2.RenderStepped:Connect(function(p113)
			-- upvalues: (copy) v_u_107, (copy) p_u_94, (ref) v_u_112, (copy) v_u_111, (copy) v_u_99, (copy) v_u_108, (copy) p_u_95
			if v_u_107.Parent then
				if p_u_94.Visible and p_u_94:IsDescendantOf(game) then
					v_u_112 = v_u_112 + p113
					local v114 = v_u_111:Inverse() * v_u_99.cf
					local v115 = v_u_108
					local v116 = v_u_111
					local v117 = CFrame.fromAxisAngle
					local v118 = v_u_99.axis or v_u_99.cf.UpVector
					local v119 = v_u_112 * 0.9
					v115.CFrame = v116 * v117(v118, math.sin(v119) * (v_u_99.axis and 0.6 or 0.87)) * v114
					local v120 = p_u_95.outlineCam
					if v120 then
						v120.CFrame = v_u_108.CFrame
					end
				end
			else
				return
			end
		end)
	end
	return true
end
local function v_u_132(p122, p123, p124, p125, p126) -- name: renderImage
	-- upvalues: (ref) v_u_4
	local v127 = p126 or 0
	local v128 = v_u_4.new
	local v129 = "ImageLabel"
	local v130 = {
		["Name"] = "WeaponIcon",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Image"] = nil,
		["ImageColor3"] = nil,
		["ImageTransparency"] = nil,
		["ScaleType"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.new(1 - v127, 0, 1 - v127, 0),
		["Image"] = p124
	}
	local v131
	if p123.dim then
		v131 = (p125 or Color3.new(1, 1, 1)):Lerp(Color3.new(0, 0, 0), 0.45)
	else
		v131 = p125 or Color3.new(1, 1, 1)
	end
	v130.ImageColor3 = v131
	v130.ImageTransparency = p123.opts.transparency or 0
	v130.ScaleType = Enum.ScaleType.Fit
	v130.ZIndex = p122.ZIndex
	v130.Parent = p122
	v128(v129, v130)
end
local function v_u_141(p133, p134) -- name: render
	-- upvalues: (copy) v_u_69, (copy) v_u_18, (copy) v_u_121, (ref) v_u_5, (copy) v_u_132, (ref) v_u_4, (copy) v_u_13
	v_u_69(p133, p134)
	local v135 = p134.id
	if v135 then
		local v136 = v_u_18(v135)
		if v136 and (not p134.opts.noModel and v_u_121(p133, p134, v135, v136)) then
			return
		else
			local v137 = v_u_5.Get(v135)
			local v138
			if v137 then
				v138 = v137.icon
			else
				v138 = v137
			end
			if type(v138) == "string" and v138 ~= "" then
				v_u_132(p133, p134, v138)
				p134.kind = "icon"
				return
			else
				local v139 = v_u_4.Assets.WeaponArt
				if v139 then
					v139 = v_u_4.Assets.WeaponArt[v135]
				end
				if v139 then
					v_u_132(p133, p134, v139, nil, 0.06)
					p134.kind = "art"
				else
					local v140 = v_u_4.Assets.Icons[v_u_13[v137 and v137.category or "melee"] or "Sword"]
					if v140 then
						v_u_132(p133, p134, v140, v_u_4.Theme.Colors.TextMuted, 0.4)
					end
					p134.kind = "glyph"
				end
			end
		end
	else
		return
	end
end
function v3.Set(p_u_142, p143, p144) -- name: Set
	-- upvalues: (copy) v_u_8, (copy) v_u_141
	local v145 = v_u_8[p_u_142]
	if not v145 or (v145.id ~= p143 or (v145.kind == nil or (v145.kind == "glyph" or v145.kind == "art"))) then
		if not v145 then
			v145 = {
				["id"] = p143,
				["opts"] = p144 or {}
			}
			v_u_8[p_u_142] = v145
			p_u_142.Destroying:Connect(function()
				-- upvalues: (ref) v_u_8, (copy) p_u_142
				local v146 = v_u_8[p_u_142]
				if v146 and v146.spinConn then
					v146.spinConn:Disconnect()
				end
				v_u_8[p_u_142] = nil
			end)
		end
		v145.id = p143
		v145.opts = p144 or (v145.opts or {})
		v_u_141(p_u_142, v145)
	end
end
function v3.SetDim(p147, p148) -- name: SetDim
	-- upvalues: (copy) v_u_8, (copy) v_u_73, (copy) v_u_7
	local v149 = v_u_8[p147]
	if v149 then
		v149.dim = p148
	end
	local v150 = p147:FindFirstChild("WeaponOutline")
	if v150 and v150:IsA("ViewportFrame") then
		local v151 = v149 and (v149.opts and v149.opts.outlineColor) or v_u_73
		if p148 then
			v151 = v151:Lerp(Color3.new(0, 0, 0), 0.4)
		end
		v150.ImageColor3 = v151
	end
	local v152 = p147:FindFirstChild("WeaponIcon")
	if v152 and v152:IsA("ViewportFrame") then
		local v153
		if p148 then
			v153 = v_u_7
		else
			v153 = Color3.new(1, 1, 1)
		end
		v152.ImageColor3 = v153
	elseif v152 and v152:IsA("ImageLabel") then
		local v154 = v152:GetAttribute("BaseColor")
		if typeof(v154) ~= "Color3" then
			v154 = v152.ImageColor3
			v152:SetAttribute("BaseColor", v154)
		end
		if p148 then
			v154 = v154:Lerp(Color3.new(0, 0, 0), 0.45)
		end
		v152.ImageColor3 = v154
	end
end
function v3.SetTransparency(p155, p156) -- name: SetTransparency
	local v157 = p155:FindFirstChild("WeaponIcon")
	if v157 and (v157:IsA("ViewportFrame") or v157:IsA("ImageLabel")) then
		v157.ImageTransparency = p156
	end
end
function v3.Init(p158, p159) -- name: Init
	-- upvalues: (ref) v_u_4, (ref) v_u_5, (copy) v_u_9, (copy) v_u_8, (copy) v_u_141, (ref) v_u_6, (copy) v_u_1, (copy) v_u_18
	v_u_4 = p158
	v_u_5 = p159
	local v160
	if v_u_6 and v_u_6.Parent then
		v160 = v_u_6
	else
		v160 = v_u_1:FindFirstChild("Assets")
		if v160 then
			v160 = v160:FindFirstChild("Weapons")
		end
		if v160 then
			v_u_6 = v160
		end
	end
	if v160 then
		v160.ChildAdded:Connect(function(p161)
			-- upvalues: (ref) v_u_9, (ref) v_u_8, (ref) v_u_141
			v_u_9[p161.Name] = nil
			for v162, v163 in v_u_8 do
				if v163.id ~= p161.Name or v163.kind == "model" then
					continue
				end
				task.defer(v_u_141, v162, v163)
			end
		end)
	else
		task.spawn(function()
			-- upvalues: (ref) v_u_1, (ref) v_u_6, (ref) v_u_9, (ref) v_u_8, (ref) v_u_141, (ref) v_u_18
			local v164 = v_u_1:WaitForChild("Assets", 30)
			if v164 then
				local v165 = v164:FindFirstChild("Weapons") or v164:WaitForChild("Weapons", 120)
				if v165 then
					v_u_6 = v165
					v165.ChildAdded:Connect(function(p166)
						-- upvalues: (ref) v_u_9, (ref) v_u_8, (ref) v_u_141
						v_u_9[p166.Name] = nil
						for v167, v168 in v_u_8 do
							if v168.id ~= p166.Name or v168.kind == "model" then
								continue
							end
							task.defer(v_u_141, v167, v168)
						end
					end)
					for v169, v170 in v_u_8 do
						if v170.kind == "model" or not v_u_18(v170.id or "") then
							continue
						end
						task.defer(v_u_141, v169, v170)
					end
				end
			end
		end)
	end
end
return v3