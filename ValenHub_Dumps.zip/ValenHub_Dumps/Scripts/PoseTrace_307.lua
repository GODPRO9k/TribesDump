local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v5 = {}
local v_u_6 = {
	"Root",
	"Waist",
	"Neck",
	"RightShoulder",
	"RightElbow",
	"LeftShoulder",
	"LeftElbow",
	"RightHip",
	"RightKnee",
	"LeftHip",
	"LeftKnee"
}
local v_u_7 = {}
local v_u_8 = false
local v_u_9 = nil
local function v_u_13(p10) -- name: jointsOf
	-- upvalues: (copy) v_u_6
	local v11 = {}
	for _, v12 in p10:GetDescendants() do
		if not ((v12:IsA("Motor6D") or v12:IsA("AnimationConstraint")) and table.find(v_u_6, v12.Name)) then
			continue
		end
		v11[v12.Name] = v12
	end
	return v11
end
local v_u_14 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_21(p15) -- name: sample
	-- upvalues: (copy) v_u_14, (copy) v_u_13, (copy) v_u_6
	local v16 = v_u_14[p15]
	if not v16 then
		v16 = v_u_13(p15)
		v_u_14[p15] = v16
	end
	local v17 = table.create(#v_u_6, CFrame.identity)
	for v18, v19 in v_u_6 do
		local v20 = v16[v19]
		if not (v20 and v20.Parent) then
			continue
		end
		v17[v18] = v20.Transform
	end
	return v17
end
v5.Sample = v_u_21
local function v_u_27() -- name: fighters
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v22 = {}
	local v23 = {}
	for _, v24 in v_u_1:GetTagged("Combatant") do
		if not v24:IsA("Model") or v22[v24] then
			continue
		end
		v22[v24] = true
		table.insert(v23, v24)
	end
	for _, v25 in v_u_2:GetPlayers() do
		local v26 = v25.Character
		if not v26 or v22[v26] then
			continue
		end
		v22[v26] = true
		table.insert(v23, v26)
	end
	return v23
end
function v5.Start() -- name: Start
	-- upvalues: (ref) v_u_8, (copy) v_u_3, (copy) v_u_7, (ref) v_u_9, (copy) v_u_4, (copy) v_u_27, (copy) v_u_21
	if not v_u_8 and v_u_3:IsStudio() then
		v_u_8 = true
		table.clear(v_u_7)
		v_u_9 = v_u_3.PreRender:Connect(function()
			-- upvalues: (ref) v_u_4, (ref) v_u_27, (ref) v_u_7, (ref) v_u_21
			local v28 = v_u_4:GetServerTimeNow()
			for _, v29 in v_u_27() do
				local v30 = v29:GetAttribute("CombatantId")
				if type(v30) ~= "string" or (v30 == "" or v29:GetAttribute("ReplayPuppet") ~= nil) then
					continue
				end
				local v31 = v_u_7[v30]
				if not v31 then
					v31 = {
						["t"] = {},
						["q"] = {}
					}
					v_u_7[v30] = v31
				end
				local v32 = v31.t
				table.insert(v32, v28)
				local v33 = v31.q
				local v34 = v_u_21(v29)
				table.insert(v33, v34)
				while #v31.t > 0 and v28 - v31.t[1] > 30 do
					table.remove(v31.t, 1)
					table.remove(v31.q, 1)
				end
			end
		end)
	end
end
function v5.Stop() -- name: Stop
	-- upvalues: (ref) v_u_8, (ref) v_u_9
	v_u_8 = false
	if v_u_9 then
		v_u_9:Disconnect()
		v_u_9 = nil
	end
end
function v5.Active() -- name: Active
	-- upvalues: (ref) v_u_8
	return v_u_8
end
local function v_u_44(p35, p36) -- name: liveAt
	-- upvalues: (copy) v_u_7
	local v37 = v_u_7[p35]
	if v37 and (#v37.t ~= 0 and (p36 >= v37.t[1] and v37.t[#v37.t] >= p36)) then
		local v38 = #v37.t
		local v39 = 1
		while v38 - v39 > 1 do
			local v40 = (v39 + v38) // 2
			if v37.t[v40] <= p36 then
				v39 = v40
				v40 = v38
			end
			v38 = v40
		end
		local v41 = v37.t[v39] - p36
		local v42 = math.abs(v41)
		local v43 = v37.t[v38] - p36
		if v42 <= math.abs(v43) then
			return v37.q[v39]
		else
			return v37.q[v38]
		end
	else
		return nil
	end
end
local v_u_45 = {
	0,
	0.05,
	0.1,
	0.15,
	0.2,
	0.3
}
local v_u_46 = {}
function v5.Reset() -- name: Reset
	-- upvalues: (copy) v_u_46
	table.clear(v_u_46)
end
function v5.Compare(p47, p48, p49) -- name: Compare
	-- upvalues: (copy) v_u_21, (copy) v_u_46, (copy) v_u_45, (copy) v_u_6, (copy) v_u_44
	local v50 = v_u_21(p48)
	local v51 = v_u_46[p47]
	if not v51 then
		v51 = {}
		for v52 in v_u_45 do
			v51[v52] = {
				["n"] = 0,
				["sum"] = nil,
				["max"] = nil,
				["dead"] = nil,
				["sum"] = table.create(#v_u_6, 0),
				["max"] = table.create(#v_u_6, 0),
				["dead"] = table.create(#v_u_6, 0)
			}
		end
		v_u_46[p47] = v51
	end
	for v53, v54 in v_u_45 do
		local v55 = v_u_44(p47, p49 + v54)
		if not v55 then
			continue
		end
		local v56 = v51[v53]
		v56.n = v56.n + 1
		for v57 = 1, #v_u_6 do
			local _, v58 = (v50[v57]:Inverse() * v55[v57]):ToAxisAngle()
			local v59 = math.abs(v58)
			local v60 = math.deg(v59)
			local v61 = v56.sum
			v61[v57] = v61[v57] + v60
			local v62 = v56.max
			local v63 = v56.max[v57]
			v62[v57] = math.max(v63, v60)
			local _, v64 = v50[v57]:ToAxisAngle()
			local v65 = math.abs(v64)
			if math.deg(v65) >= 0.05 then
				continue
			end
			local _, v66 = v55[v57]:ToAxisAngle()
			local v67 = math.abs(v66)
			if math.deg(v67) <= 3 then
				continue
			end
			local v68 = v56.dead
			v68[v57] = v68[v57] + 1
		end
	end
end
function v5.BestMatch(p69, p70, p71, p72) -- name: BestMatch
	-- upvalues: (copy) v_u_7, (copy) v_u_21, (copy) v_u_6
	local v73 = v_u_7[p69]
	if not v73 then
		return nil, nil, nil
	end
	local v74 = v_u_21(p70)
	local v75 = (1 / 0)
	local v76 = nil
	local v77 = nil
	for v78, v79 in v73.t do
		if p71 > v79 or v79 > p72 then
			continue
		end
		local v80 = v73.q[v78]
		local v81 = {}
		local v82 = 0
		for v83, v84 in v_u_6 do
			local _, v85 = (v74[v83]:Inverse() * v80[v83]):ToAxisAngle()
			local v86 = math.abs(v85)
			local v87 = math.deg(v86)
			local v88 = v87 * 10 + 0.5
			v81[v84] = math.floor(v88) / 10
			v82 = v82 + v87
		end
		if v82 / #v_u_6 >= v75 then
			break
		end
		v75 = v82 / #v_u_6
		v77 = v81
		v76 = v79
	end
	if not v76 then
		v75 = nil
	end
	return v76, v75, v77
end
function v5.Report() -- name: Report
	-- upvalues: (copy) v_u_46, (copy) v_u_6, (copy) v_u_45, (copy) v_u_7
	local v89 = {}
	for v90, v91 in v_u_46 do
		local v92 = (1 / 0)
		local v93 = nil
		for v94, v95 in v91 do
			if v95.n <= 0 then
				continue
			end
			local v96 = 0
			for v97 = 1, #v_u_6 do
				v96 = v96 + v95.sum[v97] / v95.n
			end
			if v96 / #v_u_6 >= v92 then
				break
			end
			v92 = v96 / #v_u_6
			v93 = v94
		end
		if not v93 then
			break
		end
		local v98 = v91[v93]
		local v99 = {}
		for v100, v101 in v_u_6 do
			local v102 = string.format
			local v103 = v98.sum[v100] / v98.n
			local v104 = v98.max[v100]
			local v105 = v98.dead[v100] * 100 / v98.n
			v99[v101] = v102("mean %.1f max %.1f dead %d%%", v103, v104, (math.floor(v105)))
		end
		v89[v90] = {
			["frames"] = v98.n,
			["offset"] = v_u_45[v93],
			["meanDeg"] = v92,
			["joints"] = v99
		}
	end
	local v106 = {}
	for v107, v108 in v_u_7 do
		v106[v107] = #v108.t
	end
	v89._traced = v106
	return v89
end
return v5