local v_u_1 = require(script.Parent.Weapons)
local v_u_2 = {
	["DASH_GAP"] = 0.3,
	["Ballistics"] = require(script.Ballistics),
	["FISTS_ID"] = "fists",
	["FISTS"] = table.freeze({
		["damage"] = 10,
		["combo"] = nil,
		["cooldown"] = 0.38,
		["comboWindow"] = 0.8,
		["range"] = 6.5,
		["arc"] = 60,
		["maxTargets"] = 1,
		["knockback"] = 8,
		["speedMult"] = 1,
		["combo"] = { 1, 1, 1.3 }
	})
}
local v_u_3 = {
	["Sword"] = true,
	["Axe"] = true,
	["Spear"] = true,
	["Dagger"] = true,
	["Club"] = true,
	["Fists"] = true,
	["Shield"] = true,
	["Gauntlets"] = true,
	["Scythe"] = true,
	["Katana"] = true,
	["Hatchets"] = true
}
local v_u_4 = {
	["Crossbow"] = true,
	["Musket"] = true,
	["Pistol"] = true,
	["Blunderbuss"] = true
}
local v_u_5 = {
	["Bow"] = true,
	["Javelin"] = true,
	["Bomb"] = true
}
local v_u_6 = {
	["Bow"] = true,
	["Crossbow"] = true,
	["Musket"] = true,
	["Pistol"] = true,
	["Blunderbuss"] = true,
	["Knives"] = true,
	["Javelin"] = true,
	["Sling"] = true,
	["Bomb"] = true
}
function v_u_2.Tuning(p7) -- name: Tuning
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	if p7 == nil or p7 == v_u_2.FISTS_ID then
		return v_u_2.FISTS
	else
		local v8 = v_u_1.Get(p7)
		if v8 then
			return v8.tuning
		else
			return v_u_2.FISTS
		end
	end
end
function v_u_2.Kind(p9) -- name: Kind
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	if p9 == nil or p9 == v_u_2.FISTS_ID then
		return "Fists"
	end
	local v10 = v_u_1.Get(p9)
	return v10 and v10.kind or nil
end
function v_u_2.IsMelee(p11) -- name: IsMelee
	-- upvalues: (copy) v_u_3
	local v12
	if p11 == nil then
		v12 = false
	else
		v12 = v_u_3[p11] == true
	end
	return v12
end
function v_u_2.UsesAmmo(p13) -- name: UsesAmmo
	-- upvalues: (copy) v_u_4
	local v14
	if p13 == nil then
		v14 = false
	else
		v14 = v_u_4[p13] == true
	end
	return v14
end
function v_u_2.IsDrawn(p15) -- name: IsDrawn
	-- upvalues: (copy) v_u_5
	local v16
	if p15 == nil then
		v16 = false
	else
		v16 = v_u_5[p15] == true
	end
	return v16
end
function v_u_2.FiresProjectile(p17) -- name: FiresProjectile
	-- upvalues: (copy) v_u_6
	local v18
	if p17 == nil then
		v18 = false
	else
		v18 = v_u_6[p17] == true
	end
	return v18
end
function v_u_2.UsesCharges(p19) -- name: UsesCharges
	local v20 = p19.charges
	return type(v20) == "number"
end
local v_u_21 = {
	["Fists"] = "Melee",
	["Sword"] = "Melee",
	["Axe"] = "Melee",
	["Spear"] = "Melee",
	["Dagger"] = "Melee",
	["Club"] = "Melee",
	["Shield"] = "Melee",
	["Gauntlets"] = "Melee",
	["Scythe"] = "Melee",
	["Katana"] = "Melee",
	["Hatchets"] = "Melee",
	["Bow"] = "Bow",
	["Crossbow"] = "Gun",
	["Musket"] = "Gun",
	["Pistol"] = "Gun",
	["Blunderbuss"] = "Gun",
	["Knives"] = "Throw",
	["Javelin"] = "Throw",
	["Sling"] = "Throw",
	["Bomb"] = "Throw",
	["Herbs"] = "Use",
	["Trap"] = "Use",
	["Horn"] = "Use"
}
local v_u_22 = {}
function v_u_2.AddSmoke(p23, p24, p25) -- name: AddSmoke
	-- upvalues: (copy) v_u_22
	local v26 = v_u_22
	local v27 = {
		["pos"] = p23,
		["radius"] = p24,
		["untilT"] = os.clock() + p25
	}
	table.insert(v26, v27)
end
function v_u_2.SmokeBlocks(p28, p29) -- name: SmokeBlocks
	-- upvalues: (copy) v_u_22
	if #v_u_22 == 0 then
		return false
	end
	local v30 = os.clock()
	local v31 = p29 - p28
	local v32 = v31:Dot(v31)
	local v33 = false
	for v34 = #v_u_22, 1, -1 do
		local v35 = v_u_22[v34]
		if v35.untilT <= v30 then
			table.remove(v_u_22, v34)
		else
			if v33 then
				continue
			end
			local v36
			if v32 > 0 then
				local v37 = (v35.pos - p28):Dot(v31) / v32
				v36 = math.clamp(v37, 0, 1)
			else
				v36 = 0
			end
			if (p28 + v31 * v36 - v35.pos).Magnitude > v35.radius * 0.85 then
				continue
			end
			v33 = true
		end
	end
	return v33
end
function v_u_2.ArmorSpeed(p38) -- name: ArmorSpeed
	-- upvalues: (copy) v_u_1
	local v39
	if type(p38) == "string" then
		v39 = v_u_1.Get(p38)
	else
		v39 = nil
	end
	if v39 then
		if v39.category == "armor" then
			v39 = v39.tuning.speedMult
		else
			v39 = false
		end
	end
	return type(v39) ~= "number" and 1 or v39
end
function v_u_2.MoveSpeed(p40, p41, p42, p43, p44, p45) -- name: MoveSpeed
	-- upvalues: (copy) v_u_2, (copy) v_u_21
	local v46 = v_u_2.Tuning(p40)
	local v47 = v_u_21[v_u_2.Kind(p40) or "Fists"] or "Melee"
	local v48 = v46.speedMult
	local v49 = type(v48) ~= "number" and 1 or v46.speedMult
	if v47 == "Bow" then
		if p42 then
			v49 = v49 * (v46.drawSpeedMult or 0.7)
		end
		if p41 then
			v49 = v49 * 0.8
		end
	elseif v47 == "Throw" then
		if p42 then
			v49 = v49 * (v46.drawSpeedMult or 0.8)
		end
		if p41 then
			v49 = v49 * 0.85
		end
	elseif v47 == "Gun" then
		if p41 then
			v49 = v49 * (v46.aimSpeedMult or 0.8)
		end
		if p44 then
			v49 = v49 * (v46.reloadSpeedMult or 1)
		end
	elseif v47 == "Use" then
		if p45 then
			v49 = v49 * (v46.useSpeedMult or 0.6)
		end
	else
		if p43 then
			local v50 = v46.block
			if type(v50) == "table" then
				v49 = v49 * (v46.block.speedMult or 0.6)
			end
		end
		if p42 then
			local v51 = v46.heavy or v46.lunge
			v49 = v49 * (type(v51) == "table" and (v51.speedMult or 0.55) or 0.55)
		end
	end
	return math.clamp(v49, 0, 2), p42 or (p43 or (p44 or p45))
end
function v_u_2.BindOffHand(p52, p53) -- name: BindOffHand
	if p52 and p53 then
		for _, v54 in p52:GetChildren() do
			if not v54:IsA("BasePart") or v54:GetAttribute("OffHand") ~= true then
				continue
			end
			local v55 = v54:FindFirstChild("OffHandWeld")
			local v56 = p53:FindFirstChild("LeftHand")
			local v57
			if v56 then
				v57 = v56:FindFirstChild("LeftGripAttachment")
			else
				v57 = v56
			end
			if not v55 or (not v55:IsA("Weld") or (not v56 or (not v56:IsA("BasePart") or (not v57 or (not v57:IsA("Attachment") or v55.Part0 == v56))))) then
				continue
			end
			v55.Part0 = v56
			v55.C0 = v57.CFrame
		end
	end
end
function v_u_2.ShowOffHand(p58, p59) -- name: ShowOffHand
	if p58 then
		for _, v60 in p58:GetChildren() do
			if not v60:IsA("BasePart") or v60:GetAttribute("OffHand") ~= true then
				continue
			end
			v60.Transparency = p59 and 0 or 1
			for _, v61 in v60:GetDescendants() do
				if not v61:IsA("BasePart") then
					continue
				end
				v61.Transparency = p59 and 0 or 1
			end
		end
	end
end
function v_u_2.FindCharacter(p62) -- name: FindCharacter
	while p62 and p62 ~= workspace do
		local v63 = p62:IsA("Model") and p62:FindFirstChildOfClass("Humanoid")
		if v63 then
			return p62, v63
		end
		p62 = p62.Parent
	end
	return nil, nil
end
function v_u_2.IsHeadPart(p64) -- name: IsHeadPart
	if not p64 then
		return false
	end
	if p64.Name == "Head" then
		return true
	end
	local v_u_65 = p64.Parent
	if v_u_65 and v_u_65:IsA("Accessory") then
		local v66, v67 = pcall(function()
			-- upvalues: (copy) v_u_65
			return v_u_65.AccessoryType
		end)
		if v66 and (v67 == Enum.AccessoryType.Hat or (v67 == Enum.AccessoryType.Hair or v67 == Enum.AccessoryType.Face)) then
			return true
		end
		local v68 = v_u_65:FindFirstChild("Handle")
		if v68 and (v68:FindFirstChild("HatAttachment") or (v68:FindFirstChild("HairAttachment") or v68:FindFirstChild("FaceFrontAttachment"))) then
			return true
		end
	end
	for _, v69 in p64:GetChildren() do
		if not v69:IsA("WeldConstraint") and (not v69:IsA("JointInstance") or v69:IsA("Motor6D")) then
			continue
		end
		local v70 = v69.Part0
		local v71 = v69.Part1
		if v70 == p64 then
			v70 = v71
		end
		if not v70 or (v70.Name ~= "Head" or v70.Parent ~= p64.Parent) then
			continue
		end
		return true
	end
	return false
end
function v_u_2.SpreadDir(p72, p73, p74, p75) -- name: SpreadDir
	if p73 <= 0 then
		return p72
	end
	local v76 = Random.new((math.floor(p74) * 7919 + p75 * 104729) % 2147483647)
	local v77 = p72.Y
	local v78 = p72:Cross(math.abs(v77) > 0.95 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)).Unit
	local v79 = v78:Cross(p72).Unit
	local v80 = math.rad(p73)
	local v81 = v76:NextNumber()
	local v82 = v80 * math.sqrt(v81)
	local v83 = v76:NextNumber() * 3.141592653589793 * 2
	local v84 = v78 * math.cos(v83) + v79 * math.sin(v83)
	return CFrame.fromAxisAngle(v84, v82):VectorToWorldSpace(p72).Unit
end
function v_u_2.SeedFor(p85, p86) -- name: SeedFor
	return (math.floor(p85) * 40503 + math.floor(p86)) % 2147483647
end
function v_u_2.PelletDirs(p87, p88, p89, p90) -- name: PelletDirs
	-- upvalues: (copy) v_u_2
	local v91 = table.create(p88)
	v91[1] = p87
	for v92 = 2, p88 do
		v91[v92] = v_u_2.SpreadDir(p87, p89, p90, v92)
	end
	return v91
end
function v_u_2.Falloff(p93, p94) -- name: Falloff
	local v95 = p93.falloff
	if type(v95) ~= "table" then
		return 1
	end
	if p94 <= v95.start then
		return 1
	end
	if v95.finish <= p94 then
		return v95.minMult
	end
	local v96 = (p94 - v95.start) / (v95.finish - v95.start)
	return 1 + (v95.minMult - 1) * v96
end
function v_u_2.DrawnShot(p97, p98) -- name: DrawnShot
	local v99 = math.clamp(p98, 0, 1)
	local v100 = p97.damage or 0
	local v101 = p97.damageMin or v100
	local v102 = p97.speedMin or (p97.speed or 100)
	local v103 = p97.speedMax or (p97.speed or v102)
	return v101 + (v100 - v101) * v99, v102 + (v103 - v102) * v99
end
function v_u_2.ShotSpeed(p104) -- name: ShotSpeed
	return p104.speed or p104.speedMax or 200
end
return v_u_2