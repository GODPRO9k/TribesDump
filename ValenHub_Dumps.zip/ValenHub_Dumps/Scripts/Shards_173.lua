local v_u_1 = {}
local v_u_2 = require(script.Parent:WaitForChild("Unlocks"))
local v_u_3 = require(script.Parent:WaitForChild("Ranks"))
local v4, v_u_5 = pcall(function()
	return require(script.Parent:WaitForChild("Weapons"))
end)
if not v4 then
	v_u_5 = nil
end
v_u_1.MAX_LEVEL = 5
v_u_1.BONUS_PER_LEVEL = 0.02
v_u_1.BONUS_CAP = 0.08
v_u_1.SIZES = table.freeze({
	["small"] = table.freeze({
		["unlock"] = 10,
		["upgrade"] = nil,
		["upgrade"] = table.freeze({
			10,
			20,
			40,
			80
		})
	}),
	["medium"] = table.freeze({
		["unlock"] = 20,
		["upgrade"] = nil,
		["upgrade"] = table.freeze({
			20,
			40,
			80,
			160
		})
	}),
	["large"] = table.freeze({
		["unlock"] = 40,
		["upgrade"] = nil,
		["upgrade"] = table.freeze({
			40,
			80,
			160,
			320
		})
	}),
	["starter"] = table.freeze({
		["unlock"] = 0,
		["upgrade"] = nil,
		["upgrade"] = table.freeze({
			10,
			20,
			40,
			80
		})
	})
})
v_u_1.DROPS = table.freeze({
	["order"] = nil,
	["kinds"] = nil,
	["bonus"] = nil,
	["goldenChance"] = 0.05,
	["weights"] = nil,
	["pity"] = 6,
	["pityFill"] = 8,
	["first"] = nil,
	["xpPerShard"] = 5,
	["order"] = table.freeze({ "drop", "victory", "golden" }),
	["kinds"] = table.freeze({
		["drop"] = table.freeze({
			["name"] = "Drop",
			["stacks"] = 2,
			["min"] = 4,
			["max"] = 5
		}),
		["victory"] = table.freeze({
			["name"] = "Victory Drop",
			["stacks"] = 3,
			["min"] = 5,
			["max"] = 7
		}),
		["golden"] = table.freeze({
			["name"] = "Golden Drop",
			["stacks"] = 4,
			["min"] = 13,
			["max"] = 17,
			["lockedStack"] = true
		}),
		["tribe1"] = table.freeze({
			["name"] = "Tribe Chest",
			["stacks"] = 2,
			["min"] = 4,
			["max"] = 5
		}),
		["tribe2"] = table.freeze({
			["name"] = "Tribe Chest",
			["stacks"] = 3,
			["min"] = 5,
			["max"] = 7
		}),
		["tribe3"] = table.freeze({
			["name"] = "Tribe Chest",
			["stacks"] = 3,
			["min"] = 8,
			["max"] = 10
		}),
		["tribe4"] = table.freeze({
			["name"] = "Tribe Chest",
			["stacks"] = 4,
			["min"] = 9,
			["max"] = 11
		}),
		["tribe5"] = table.freeze({
			["name"] = "Tribe Chest",
			["stacks"] = 4,
			["min"] = 13,
			["max"] = 17,
			["lockedStack"] = true
		})
	}),
	["bonus"] = table.freeze({
		["min"] = 4,
		["max"] = 6
	}),
	["weights"] = table.freeze({
		["locked"] = 1.25,
		["owned"] = 1,
		["nearUnlock"] = 1.25,
		["nearAt"] = 0.5,
		["carried"] = 2
	}),
	["first"] = table.freeze({
		["item"] = "crossbow",
		["drops"] = 3
	})
})
function v_u_1.IsKnown(p6) -- name: IsKnown
	-- upvalues: (copy) v_u_2
	return v_u_2.IsKnown(p6)
end
function v_u_1.AllIds() -- name: AllIds
	-- upvalues: (copy) v_u_2
	return v_u_2.AllIds()
end
function v_u_1.Size(p7) -- name: Size
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v8 = v_u_2.SizeOf(p7)
	return not v_u_1.SIZES[v8] and "medium" or v8
end
local v_u_9 = {}
function v_u_1.Stat(p10) -- name: Stat
	-- upvalues: (copy) v_u_9, (ref) v_u_5, (copy) v_u_2
	if type(p10) ~= "string" then
		return false
	end
	local v11 = v_u_9[p10]
	if v11 ~= nil then
		return v11
	end
	local v12 = "damage"
	local v13 = v_u_5
	if v13 then
		v13 = v_u_5.Get(p10)
	end
	if v13 then
		local v14 = v13.tuning or {}
		if v13.category == "armor" then
			v12 = "armor"
		elseif v13.category == "healing" then
			v12 = "healing"
		else
			local v15 = v14.damage
			if type(v15) == "number" and v14.damage > 0 then
				v12 = "damage"
			else
				local v16 = v14.splash
				if type(v16) == "table" and (v14.splash.damage or 0) > 0 then
					v12 = "damage"
				else
					local v17 = v14.bees
					if type(v17) == "table" and (v14.bees.damage or 0) > 0 then
						v12 = "damage"
					else
						local v18 = v14.burn
						v12 = type(v18) == "table" and "damage" or false
					end
				end
			end
		end
	elseif v_u_2.IsAmmo(p10) then
		v12 = false
	end
	v_u_9[p10] = v12
	return v12
end
function v_u_1.MaxLevel(p19) -- name: MaxLevel
	-- upvalues: (copy) v_u_1
	return not v_u_1.Stat(p19) and 1 or v_u_1.MAX_LEVEL
end
function v_u_1.UnlockCost(p20) -- name: UnlockCost
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	return v_u_2.IsStarter(p20) and 0 or v_u_1.SIZES[v_u_1.Size(p20)].unlock
end
function v_u_1.UpgradeCost(p21, p22) -- name: UpgradeCost
	-- upvalues: (copy) v_u_1
	if type(p22) == "number" and (p22 >= 1 and v_u_1.MaxLevel(p21) > p22) then
		return v_u_1.SIZES[v_u_1.Size(p21)].upgrade[math.floor(p22)]
	else
		return nil
	end
end
function v_u_1.Level(p23, p24) -- name: Level
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	if type(p24) ~= "string" then
		return 0
	end
	local v25
	if type(p23) == "table" then
		v25 = p23[p24]
	else
		v25 = false
	end
	local v26
	if type(v25) == "table" then
		local v27 = v25.level
		if type(v27) == "number" then
			local v28 = v25.level
			v26 = math.floor(v28)
		else
			v26 = 0
		end
	else
		v26 = 0
	end
	local v29 = v_u_2.IsStarter(p24) and 1 or 0
	local v30 = math.max(v26, v29)
	local v31 = v_u_1.MaxLevel
	return math.clamp(v30, 0, v31(p24))
end
function v_u_1.ShardsOf(p32, p33) -- name: ShardsOf
	local v34
	if type(p32) == "table" and type(p33) == "string" then
		v34 = p32[p33]
	else
		v34 = false
	end
	local v35
	if type(v34) == "table" then
		local v36 = v34.shards
		if type(v36) == "number" and v34.shards == v34.shards then
			local v37 = v34.shards
			v35 = math.floor(v37)
		else
			v35 = 0
		end
	else
		v35 = 0
	end
	return math.max(0, v35)
end
function v_u_1.Owns(p38, p39) -- name: Owns
	-- upvalues: (copy) v_u_1
	return v_u_1.Level(p38, p39) >= 1
end
function v_u_1.Progress(p40, p41) -- name: Progress
	-- upvalues: (copy) v_u_1
	local v42 = v_u_1.Level(p40, p41)
	local v43 = v_u_1.ShardsOf(p40, p41)
	if v42 == 0 then
		return v43, v_u_1.UnlockCost(p41), "unlock"
	else
		local v44 = v_u_1.UpgradeCost(p41, v42)
		if v44 then
			return v43, v44, "upgrade"
		else
			return v43, 0, "max"
		end
	end
end
function v_u_1.CanUpgrade(p45, p46) -- name: CanUpgrade
	-- upvalues: (copy) v_u_1
	local v47, v48, v49 = v_u_1.Progress(p45, p46)
	local v50
	if v49 == "upgrade" then
		v50 = v48 <= v47
	else
		v50 = false
	end
	return v50
end
function v_u_1.ReadyCount(p51) -- name: ReadyCount
	-- upvalues: (copy) v_u_1
	local v52 = 0
	for _, v53 in v_u_1.AllIds() do
		if not v_u_1.CanUpgrade(p51, v53) then
			continue
		end
		v52 = v52 + 1
	end
	return v52
end
function v_u_1.ToMax(p54, p55) -- name: ToMax
	-- upvalues: (copy) v_u_1
	local v56 = v_u_1.Level(p54, p55)
	local v57 = v_u_1.MaxLevel(p55)
	if v57 <= v56 then
		return 0
	end
	local v58 = v56 ~= 0 and 0 or v_u_1.UnlockCost(p55)
	for v59 = math.max(v56, 1), v57 - 1 do
		v58 = v58 + (v_u_1.UpgradeCost(p55, v59) or 0)
	end
	local v60 = v58 - v_u_1.ShardsOf(p54, p55)
	return math.max(0, v60)
end
function v_u_1.Bonus(p61) -- name: Bonus
	-- upvalues: (copy) v_u_1
	if type(p61) ~= "number" or p61 <= 1 then
		return 1
	end
	local v62 = v_u_1.BONUS_PER_LEVEL * (math.floor(p61) - 1)
	local v63 = v_u_1.BONUS_CAP
	return math.min(v62, v63) + 1
end
function v_u_1.BonusText(p64, p65) -- name: BonusText
	-- upvalues: (copy) v_u_1
	local v66 = v_u_1.Stat(p64)
	if not v66 then
		return ""
	end
	local v67 = (v_u_1.Bonus(p65) - 1) * 100 + 0.5
	return ("+%*%% %*"):format(math.floor(v67), v66)
end
function v_u_1.Set(p68, p69, p70, p71) -- name: Set
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v72 = math.floor(p70)
	local v73 = math.max(0, v72)
	local v74 = math.floor(p71)
	local v75 = v_u_1.MaxLevel
	local v76 = math.clamp(v74, 0, v75(p69))
	local v77 = v_u_2.IsStarter(p69) and 1 or 0
	local v78 = math.max(v76, v77)
	if v73 == 0 and v78 == (v_u_2.IsStarter(p69) and 1 or 0) then
		p68[p69] = nil
	else
		p68[p69] = {
			["shards"] = v73,
			["level"] = v78
		}
	end
end
function v_u_1.Upgrade(p79, p80) -- name: Upgrade
	-- upvalues: (copy) v_u_1
	if type(p80) ~= "string" or not v_u_1.IsKnown(p80) then
		return false, "Unknown item", nil
	end
	local v81 = v_u_1.Level(p79, p80)
	if v81 == 0 then
		return false, "Locked", nil
	end
	local v82 = v_u_1.UpgradeCost(p80, v81)
	if not v82 then
		return false, "Max level", nil
	end
	local v83 = v_u_1.ShardsOf(p79, p80)
	if v83 < v82 then
		return false, "Not enough shards", nil
	end
	v_u_1.Set(p79, p80, v83 - v82, v81 + 1)
	return true, nil, v81 + 1
end
local function v_u_90(p84) -- name: carriedSet
	local v85 = {}
	if type(p84) == "table" then
		local v86 = p84.items
		if type(v86) == "table" then
			for v87 = 1, 16 do
				local v88 = p84.items[v87]
				if type(v88) ~= "string" then
					break
				end
				v85[v88] = true
			end
		end
		local v89 = p84.armor
		if type(v89) == "string" then
			v85[p84.armor] = true
		end
	end
	return v85
end
function v_u_1.Pool(p91, p92) -- name: Pool
	-- upvalues: (copy) v_u_1, (copy) v_u_90, (copy) v_u_3
	local v93 = v_u_1.DROPS.weights
	local v94 = v_u_90
	local v95
	if p92 then
		v95 = p92.loadout
	else
		v95 = p92
	end
	local v96 = v94(v95)
	local v97 = {}
	local v98
	if p92 then
		local v99 = p92.rankBest
		if type(v99) == "number" then
			v98 = p92.rankBest
		else
			v98 = nil
		end
	else
		v98 = nil
	end
	for _, v100 in v_u_1.AllIds() do
		local v101 = v_u_1.Level(p91, v100)
		if v_u_1.MaxLevel(v100) <= v101 or v101 == 0 and (v98 and not v_u_3.Allows(v98, v100)) then
			continue
		end
		if v101 == 0 then
			local v102 = v_u_1.UnlockCost
			local v103 = math.max(1, v102(v100))
			local v104 = v_u_1.ShardsOf(p91, v100) / v103
			local v105 = math.min(1, v104)
			local v106 = {
				["item"] = nil,
				["weight"] = nil,
				["locked"] = true,
				["frac"] = nil,
				["item"] = v100,
				["weight"] = v93.locked * (v93.nearAt > v105 and 1 or v93.nearUnlock),
				["frac"] = v105
			}
			table.insert(v97, v106)
		else
			local v107 = {
				["item"] = nil,
				["weight"] = nil,
				["locked"] = false,
				["frac"] = 0,
				["item"] = v100,
				["weight"] = v93.owned * (not v96[v100] and 1 or v93.carried)
			}
			table.insert(v97, v107)
		end
	end
	return v97
end
local function v_u_123(p108, p109, p110) -- name: forcedPick
	-- upvalues: (copy) v_u_1
	local v111 = v_u_1.DROPS
	if p110.first == true and v111.first then
		for _, v112 in p109 do
			if v112.item ~= v111.first.item or not v112.locked then
				continue
			end
			local v113 = v111.first.drops
			local v114 = p110.total
			local v115 = v113 - (tonumber(v114) or 0)
			local v116 = math.max(1, v115)
			local v117 = (v_u_1.UnlockCost(v112.item) - v_u_1.ShardsOf(p108, v112.item)) / v116
			return v112, math.ceil(v117)
		end
	end
	local v118 = p110.sinceUnlock
	if (tonumber(v118) or 0) >= v111.pity then
		local v119 = nil
		local v120 = (1 / 0)
		for _, v121 in p109 do
			if not v121.locked then
				continue
			end
			local v122 = v_u_1.UnlockCost(v121.item) - v_u_1.ShardsOf(p108, v121.item)
			if v119 and (v121.frac <= v119.frac and (v121.frac ~= v119.frac or v122 >= v120)) then
				continue
			end
			v120 = v122
			v119 = v121
		end
		if v119 then
			if v120 <= v111.pityFill then
				return v119, v120
			else
				return v119, 0
			end
		end
	end
	return nil, 0
end
local function v_u_133(p124, p125, p126, p127) -- name: weightedPick
	local v128 = 0
	for _, v129 in p124 do
		if p125[v129.item] or not v129.locked and p126 then
			continue
		end
		v128 = v128 + v129.weight
	end
	if v128 <= 0 then
		return nil
	end
	local v130 = p127:NextNumber() * v128
	local v131 = nil
	for _, v132 in p124 do
		if p125[v132.item] or not v132.locked and p126 then
			continue
		end
		v130 = v130 - v132.weight
		if v130 < 0 then
			return v132
		end
		v131 = v132
	end
	return v131
end
function v_u_1.Roll(p134, p135, p136, p137) -- name: Roll
	-- upvalues: (copy) v_u_1, (copy) v_u_123, (copy) v_u_133
	local v138 = v_u_1.DROPS
	local v139 = v138.kinds[p135] or v138.kinds.drop
	local v140 = {}
	local v141 = p136 or {}
	for _ = 1, v139.stacks do
		local v142 = {
			["n"] = nil,
			["bonus"] = false,
			["n"] = p137:NextInteger(v139.min, v139.max)
		}
		table.insert(v140, v142)
	end
	if v141.mvp == true then
		local v143 = {
			["n"] = nil,
			["bonus"] = true,
			["n"] = p137:NextInteger(v138.bonus.min, v138.bonus.max)
		}
		table.insert(v140, v143)
	end
	local v144 = v141.extra
	local v145 = tonumber(v144) or 0
	local v146 = math.floor(v145)
	for _ = 1, math.clamp(v146, 0, 5) do
		local v147 = {
			["n"] = nil,
			["bonus"] = true,
			["n"] = p137:NextInteger(v138.bonus.min, v138.bonus.max)
		}
		table.insert(v140, v147)
	end
	local v148 = v_u_1.Pool(p134, v141)
	local v149 = {}
	local v150 = {}
	local v151 = 0
	local v152 = v141.lead
	if type(v152) == "table" then
		for _, v153 in v141.lead do
			local v154
			if type(v153) == "table" then
				v154 = v153.item
			else
				v154 = false
			end
			if type(v154) ~= "string" or (not v_u_1.IsKnown(v154) or v149[v154]) then
				continue
			end
			v149[v154] = true
			local v155 = v153.shards
			local v156 = tonumber(v155) or 0
			local v157 = math.floor(v156)
			local v158 = math.max(0, v157)
			local v159 = v_u_1.ToMax
			local v160 = math.min(v158, v159(p134, v154))
			if v160 <= 0 then
				continue
			end
			table.insert(v150, {
				["item"] = v154,
				["shards"] = v160
			})
		end
	end
	for v161, v162 in v140 do
		local v163 = nil
		local v164 = v162.n
		if v161 == 1 then
			local v165, v166 = v_u_123(p134, v148, v141)
			if v165 and not v149[v165.item] then
				v164 = math.max(v164, v166)
				v163 = v165
			elseif v139.lockedStack then
				v163 = v_u_133(v148, v149, true, p137)
			end
		end
		local v167 = v163 or v_u_133(v148, v149, false, p137)
		if v167 then
			v149[v167.item] = true
			local v168 = v_u_1.ToMax(p134, v167.item)
			if v168 < v164 then
				v151 = v151 + (v164 - v168) * v138.xpPerShard
			else
				v168 = v164
			end
			if v168 <= 0 then
				continue
			end
			local v169 = {
				["item"] = v167.item,
				["shards"] = v168,
				["bonus"] = v162.bonus and true or nil
			}
			table.insert(v150, v169)
		else
			v151 = v151 + v164 * v138.xpPerShard
		end
	end
	return v150, v151
end
function v_u_1.Apply(p170, p171) -- name: Apply
	-- upvalues: (copy) v_u_1
	local v172 = {}
	for _, v173 in p171 do
		local v174 = v173.item
		local v175 = v_u_1.Level(p170, v174)
		local v176 = v_u_1.ShardsOf(p170, v174)
		local v177
		if v175 == 0 then
			v177 = v_u_1.UnlockCost(v174)
		else
			v177 = v_u_1.UpgradeCost(v174, v175) or 0
		end
		local v178 = v173.shards
		local v179 = math.floor(v178)
		local v180 = v176 + math.max(0, v179)
		local v181, v182, v183
		if v175 == 0 and v177 <= v180 then
			v181 = v180 - v177
			v182 = true
			v183 = 1
		else
			v183 = v175
			v181 = v180
			v182 = false
		end
		v_u_1.Set(p170, v174, v181, v183)
		local v184 = {
			["item"] = v174,
			["shards"] = v173.shards,
			["before"] = v176,
			["after"] = v180,
			["need"] = v177,
			["levelBefore"] = v175,
			["level"] = v183,
			["unlocked"] = v182,
			["ready"] = v_u_1.CanUpgrade(p170, v174),
			["bonus"] = v173.bonus == true
		}
		table.insert(v172, v184)
	end
	return v172
end
function v_u_1.KindFor(p185, p186) -- name: KindFor
	-- upvalues: (copy) v_u_1
	if p185 then
		if p186:NextNumber() < v_u_1.DROPS.goldenChance then
			return "golden", true
		else
			return "victory", false
		end
	else
		return "drop", false
	end
end
function v_u_1.Drop(p187, p188, p189, p190, p191) -- name: Drop
	-- upvalues: (copy) v_u_1
	local v192 = p190 or {}
	local v193 = {
		["mvp"] = v192.mvp == true,
		["total"] = p188.total or 0,
		["sinceUnlock"] = p188.sinceUnlock or 0,
		["first"] = p188.first == true,
		["loadout"] = v192.loadout,
		["extra"] = v192.extra,
		["rankBest"] = v192.rankBest,
		["lead"] = v192.lead
	}
	local v194, v195 = v_u_1.Roll(p187, p189, v193, p191)
	local v196 = v_u_1.Apply(p187, v194)
	local v_u_197 = {}
	for v198, v199 in v196 do
		v_u_197[v199] = v198
	end
	table.sort(v196, function(p200, p201)
		-- upvalues: (copy) v_u_197
		local v202 = p200.unlocked and 3 or (p200.levelBefore == 0 and 2 or (p200.ready and 1 or 0))
		local v203 = p201.unlocked and 3 or (p201.levelBefore == 0 and 2 or (p201.ready and 1 or 0))
		if v202 == v203 then
			return v_u_197[p200] < v_u_197[p201]
		else
			return v202 < v203
		end
	end)
	local v204 = false
	for _, v205 in v196 do
		v204 = v204 or v205.unlocked
	end
	p188.total = (p188.total or 0) + 1
	p188.sinceUnlock = v204 and 0 or (p188.sinceUnlock or 0) + 1
	local v206 = v_u_1.DROPS.first
	if p188.first == true and (not v206 or (not v_u_1.IsKnown(v206.item) or v_u_1.Owns(p187, v206.item))) then
		p188.first = false
	end
	return v196, v195, v204
end
local function v_u_258(p207, p208, p209) -- name: inclusion
	-- upvalues: (copy) v_u_1, (copy) v_u_123
	local v210 = v_u_1.DROPS
	local v211 = v210.kinds[p208] or v210.kinds.drop
	local v212 = v_u_1.Pool(p207, p209)
	local v213 = v211.stacks + (p209.mvp == true and 1 or 0)
	local v214 = #v212
	local v215 = table.create(v214, 0)
	local v216 = 0
	if v214 == 0 then
		return {}, 0
	end
	local v217 = v_u_123(p207, v212, p209)
	local v218 = 0
	if v217 then
		for v219, v220 in v212 do
			if v220 ~= v217 then
				continue
			end
			v218 = v219
		end
	end
	local v221 = false
	for _, v222 in v212 do
		v221 = v221 or v222.locked
	end
	if v214 > 50 then
		local v223 = Random.new(12345)
		local v224 = {}
		local v225 = 0
		for v226, v227 in v212 do
			v224[v227.item] = v226
		end
		for _ = 1, 20000 do
			local v228 = false
			for _, v229 in v_u_1.Roll(p207, p208, p209, v223) do
				local v230 = v224[v229.item]
				if not v230 then
					continue
				end
				v215[v230] = v215[v230] + 0.00005
				v228 = v228 or v212[v230].locked
			end
			if not v228 then
				break
			end
			v225 = v225 + 1
		end
		v216 = v225 / 20000
	else
		local v231 = { 1 }
		for v232 = 1, math.min(v213, v214) do
			v231 = {}
			for v233, v234 in v231 do
				local v235
				if v232 == 1 then
					if v211.lockedStack == true then
						v235 = v221
					else
						v235 = false
					end
				else
					v235 = false
				end
				if v232 == 1 and v218 > 0 then
					v231[2 ^ (v218 - 1)] = v234
				else
					local v236 = 0
					for v237, v238 in v212 do
						local v239 = v233 / 2 ^ (v237 - 1)
						if math.floor(v239) % 2 == 1 or not v238.locked and v235 then
							continue
						end
						v236 = v236 + v238.weight
					end
					if v236 <= 0 then
						break
					end
					for v240, v241 in v212 do
						local v242 = v233 / 2 ^ (v240 - 1)
						if math.floor(v242) % 2 == 1 or not v241.locked and v235 then
							continue
						end
						local v243 = v233 + 2 ^ (v240 - 1)
						v231[v243] = (v231[v243] or 0) + v234 * v241.weight / v236
					end
				end
			end
		end
		for v244, v245 in v231 do
			local v246 = false
			for v247, v248 in v212 do
				local v249 = v244 / 2 ^ (v247 - 1)
				if math.floor(v249) % 2 ~= 1 then
					continue
				end
				v215[v247] = v215[v247] + v245
				v246 = v246 or v248.locked
			end
			if not v246 then
				break
			end
			v216 = v216 + v245
		end
	end
	local v250 = {}
	for v251, v252 in v212 do
		local v253 = {
			["item"] = v252.item
		}
		local v254 = v215[v251]
		v253.chance = math.clamp(v254, 0, 1)
		v253.locked = v252.locked
		table.insert(v250, v253)
	end
	table.sort(v250, function(p255, p256)
		local v257 = p255.chance - p256.chance
		if math.abs(v257) > 1e-9 then
			return p255.chance > p256.chance
		else
			return p255.item < p256.item
		end
	end)
	return v250, math.clamp(v216, 0, 1)
end
function v_u_1.Context(p259) -- name: Context
	local v260
	if type(p259) == "table" then
		local v261 = p259.dropStats
		v260 = type(v261) ~= "table" and {} or p259.dropStats
	else
		v260 = {}
	end
	local v262 = {}
	local v263 = v260.total
	v262.total = tonumber(v263) or 0
	local v264 = v260.sinceUnlock
	v262.sinceUnlock = tonumber(v264) or 0
	v262.first = v260.first == true
	local v265
	if type(p259) == "table" then
		v265 = p259.loadout
	else
		v265 = nil
	end
	v262.loadout = v265
	local v266
	if type(p259) == "table" then
		local v267 = p259.rankBest
		if type(v267) == "number" then
			v266 = p259.rankBest
		else
			v266 = nil
		end
	else
		v266 = nil
	end
	v262.rankBest = v266
	return v262
end
function v_u_1.Odds(p268, p269, p270) -- name: Odds
	-- upvalues: (copy) v_u_1, (copy) v_u_258
	local v271 = v_u_1.DROPS
	local v272 = {}
	for _, v273 in v271.order do
		local v274 = v271.kinds[v273]
		local v275 = {
			["kind"] = v273,
			["name"] = v274.name,
			["stacks"] = v274.stacks,
			["min"] = v274.min,
			["max"] = v274.max,
			["lockedStack"] = v274.lockedStack == true
		}
		table.insert(v272, v275)
	end
	local v276 = {
		["kinds"] = v272,
		["bonus"] = {
			["min"] = v271.bonus.min,
			["max"] = v271.bonus.max
		},
		["goldenChance"] = v271.goldenChance,
		["pity"] = v271.pity
	}
	if p268 ~= nil and (type(p269) == "string" and v271.kinds[p269]) then
		local v277, v278 = v_u_258(p268, p269, p270 or {})
		v276.kind = p269
		v276.items = v277
		v276.lockedChance = v278
	end
	return v276
end
function v_u_1.LevelsFor(p279, p280) -- name: LevelsFor
	-- upvalues: (copy) v_u_90, (copy) v_u_1
	local v281 = {}
	for v282 in v_u_90(p280) do
		if not v_u_1.IsKnown(v282) then
			continue
		end
		local v283 = v_u_1.Level
		v281[v282] = math.max(1, v283(p279, v282))
	end
	return v281
end
local v_u_284 = nil
local function v_u_291() -- name: catalogue
	-- upvalues: (ref) v_u_284, (copy) v_u_1
	local v285 = v_u_284
	if v285 then
		return v285
	end
	local v286 = v_u_1.AllIds()
	local v287 = {}
	for v288, v289 in v286 do
		v287[v289] = v288
	end
	local v290 = {
		["ids"] = v286,
		["index"] = v287
	}
	v_u_284 = v290
	return v290
end
function v_u_1.EncodeLevels(p292) -- name: EncodeLevels
	-- upvalues: (copy) v_u_291, (copy) v_u_1
	local v293 = v_u_291()
	local v294 = {}
	if type(p292) == "table" then
		for v295, v296 in p292 do
			local v297
			if type(v295) == "string" then
				v297 = v293.index[v295]
			else
				v297 = false
			end
			if not v297 or (type(v296) ~= "number" or v296 < 2) then
				continue
			end
			local v298 = ""
			local v299 = "%*=%*"
			local v300 = {
				["i"] = v297
			}
			repeat
				local v301 = v297 % 36
				local v302 = v301 + 1
				local v303 = v301 + 1
				v298 = string.sub("0123456789abcdefghijklmnopqrstuvwxyz", v302, v303) .. v298
				v297 = v297 // 36
			until v297 == 0
			local v304 = math.floor(v296)
			local v305 = v_u_1.MAX_LEVEL
			v300.s = v299:format(v298, (math.clamp(v304, 2, v305)))
			table.insert(v294, v300)
		end
	end
	table.sort(v294, function(p306, p307)
		return p306.i < p307.i
	end)
	local v308 = 0
	local v309 = {}
	for _, v310 in v294 do
		if v308 + #v310.s + 1 > 51 then
			break
		end
		v308 = v308 + (#v310.s + 1)
		local v311 = v310.s
		table.insert(v309, v311)
	end
	return table.concat(v309, ",")
end
local v_u_312 = {}
local v_u_313 = 0
function v_u_1.DecodeLevels(p314) -- name: DecodeLevels
	-- upvalues: (copy) v_u_312, (copy) v_u_291, (copy) v_u_1, (ref) v_u_313
	if type(p314) ~= "string" or p314 == "" then
		return {}
	end
	local v315 = v_u_312[p314]
	if v315 then
		return v315
	end
	local v316 = v_u_291()
	local v317 = {}
	for v318, v319 in string.gmatch(p314, "(%w+)=(%d+)") do
		local v320 = tonumber(v318, 36)
		if v320 then
			v320 = v316.ids[v320]
		end
		if not v320 then
			continue
		end
		local v321 = tonumber(v319) or 1
		local v322 = v_u_1.MAX_LEVEL
		v317[v320] = math.clamp(v321, 1, v322)
	end
	table.freeze(v317)
	if v_u_313 > 256 then
		table.clear(v_u_312)
		v_u_313 = 0
	end
	v_u_312[p314] = v317
	v_u_313 = v_u_313 + 1
	return v317
end
return v_u_1