local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = require(v3:WaitForChild("Shared"):WaitForChild("Unlocks"))
local v5 = {}
local v_u_6 = Color3.fromRGB
local v_u_7 = v_u_6(255, 196, 60)
local v_u_8 = v_u_6(255, 226, 150)
local v_u_9 = v_u_6(92, 50, 4)
local v_u_10 = v_u_6(245, 52, 64)
function v5.Init(p_u_11) -- name: Init
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_6, (copy) v_u_7, (copy) v_u_9, (copy) v_u_8, (copy) v_u_10, (copy) v_u_2
	local v_u_12 = p_u_11.UI
	local v13 = p_u_11.Theme
	local v_u_14 = p_u_11.State
	local v_u_15 = v13.Colors
	local v_u_16 = v13.Fonts
	local v_u_17 = p_u_11.MenuManager
	local v_u_18 = p_u_11.Economy
	local v_u_19 = v_u_1.LocalPlayer
	local v_u_20 = UDim2.fromOffset
	local v_u_21 = v_u_4.FIRST_DROP.key
	local v_u_22 = script.Parent.Parent:FindFirstChild("DropModels")
	local v23, v_u_24 = pcall(function()
		-- upvalues: (copy) v_u_22
		return require(v_u_22)
	end)
	if not v23 or type(v_u_24) ~= "table" then
		v_u_24 = nil
	end
	local v_u_25 = nil
	local v_u_26 = {}
	local v_u_27 = 0
	local v_u_28 = false
	local v_u_29 = {}
	local v_u_30 = nil
	local function v_u_31() -- name: close
		-- upvalues: (copy) v_u_17
		v_u_17.Close("GoldenOffer")
	end
	local function v_u_47(p32) -- name: buildChest
		-- upvalues: (ref) v_u_24, (ref) v_u_6, (copy) v_u_29
		local v33 = v_u_24
		if v33 then
			v33 = v_u_24.Golden
		end
		if v33 then
			for _, v_u_34 in v33.parts do
				local v_u_35 = Instance.new("Part")
				v_u_35.Anchored = true
				v_u_35.CanCollide = false
				v_u_35.CanQuery = false
				v_u_35.CanTouch = false
				v_u_35.CastShadow = false
				local v36 = v_u_34.size[1]
				local v37 = v_u_34.size[2]
				local v38 = v_u_34.size[3]
				v_u_35.Size = Vector3.new(v36, v37, v38)
				v_u_35.Color = v_u_6(v_u_34.color[1], v_u_34.color[2], v_u_34.color[3])
				pcall(function()
					-- upvalues: (copy) v_u_35, (copy) v_u_34
					v_u_35.Material = Enum.Material[v_u_34.material]
				end)
				if v_u_34.mesh ~= "" then
					local v39 = Instance.new("SpecialMesh")
					v39.MeshType = Enum.MeshType.FileMesh
					v39.MeshId = v_u_34.mesh
					v39.TextureId = v_u_34.tex
					local v40 = v_u_34.scale[1]
					local v41 = v_u_34.scale[2]
					local v42 = v_u_34.scale[3]
					v39.Scale = Vector3.new(v40, v41, v42)
					v39.Parent = v_u_35
				end
				v_u_35.Parent = p32
				local v43 = v_u_29
				local v44 = {
					["part"] = v_u_35
				}
				local v45 = CFrame.new
				local v46 = v_u_34.cf
				v44.cf = v45(table.unpack(v46))
				table.insert(v43, v44)
			end
		end
	end
	local function v_u_59() -- name: build
		-- upvalues: (ref) v_u_25, (copy) v_u_12, (copy) v_u_20, (copy) p_u_11, (copy) v_u_31, (ref) v_u_7, (ref) v_u_6, (ref) v_u_9, (copy) v_u_26, (ref) v_u_8, (copy) v_u_47, (copy) v_u_16, (ref) v_u_10, (copy) v_u_15, (ref) v_u_27, (copy) v_u_18, (copy) v_u_21, (copy) v_u_17
		v_u_25 = v_u_12.Window({
			["Name"] = "GoldenOffer",
			["Title"] = "LIMITED-TIME OFFER",
			["Subtitle"] = "Only once, only for your first purchase",
			["Size"] = nil,
			["HeaderHeight"] = 80,
			["Parent"] = nil,
			["OnCloseRequested"] = nil,
			["Size"] = v_u_20(780, 520),
			["Parent"] = p_u_11.Canvas.Menus,
			["OnCloseRequested"] = v_u_31
		})
		v_u_25.Title.TextColor3 = v_u_7
		v_u_12.SelectionRing(v_u_25.Root)
		local v48 = v_u_25.Content
		local v49 = v_u_12.new("Frame", {
			["Name"] = "Hero",
			["Size"] = UDim2.new(0, 330, 1, 0),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["ClipsDescendants"] = true,
			v_u_12.Corner(14),
			v_u_12.Gradient(v_u_6(150, 88, 10), v_u_9, 90),
			v_u_12.Stroke(v_u_7, 2, 0.35),
			["Parent"] = v48
		})
		v_u_26.hero = v49
		v_u_26.rays = v_u_12.Image(v_u_12.Assets.Fx.Rays, {
			["Name"] = "Rays",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["SizeConstraint"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 0.62,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.48),
			["Size"] = UDim2.fromScale(1.9, 1.9),
			["SizeConstraint"] = Enum.SizeConstraint.RelativeXX,
			["ImageColor3"] = v_u_8,
			["Parent"] = v49
		})
		v_u_12.Image(v_u_12.Assets.Icons.Glow, {
			["Name"] = "Glow",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 0.35,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.52),
			["Size"] = UDim2.fromScale(1.1, 0.8),
			["ImageColor3"] = v_u_6(255, 214, 120),
			["Parent"] = v49
		})
		local v50 = v_u_12.new("ViewportFrame", {
			["Name"] = "Chest",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["SizeConstraint"] = nil,
			["BackgroundTransparency"] = 1,
			["Ambient"] = nil,
			["LightColor"] = nil,
			["LightDirection"] = Vector3.new(0.45, -1, 0.55),
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.52),
			["Size"] = UDim2.fromScale(1, 1),
			["SizeConstraint"] = Enum.SizeConstraint.RelativeXX,
			["Ambient"] = v_u_6(160, 150, 140),
			["LightColor"] = v_u_6(255, 244, 228),
			["Parent"] = v49
		})
		local v51 = Instance.new("Camera")
		v51.FieldOfView = 28
		v51.CFrame = CFrame.lookAt(Vector3.new(0, 4.6, -15.5), Vector3.new(0, 2.2, 0))
		v51.Parent = v50
		v50.CurrentCamera = v51
		v_u_47(v50)
		v_u_12.new("TextLabel", {
			["Name"] = "Caption",
			["Text"] = "1 \195\151 GOLDEN DROP",
			["FontFace"] = v_u_16.Heavy,
			["TextSize"] = 18,
			["TextColor3"] = v_u_8,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, -16),
			["Size"] = UDim2.new(1, -20, 0, 22),
			v_u_12.TextStroke(v_u_9, 2, 0.2),
			["Parent"] = v49
		})
		local v52 = v_u_12.new("Frame", {
			["Name"] = "Burst",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = -12,
			["ZIndex"] = 5,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v_u_20(70, 70),
			["Size"] = v_u_20(112, 112),
			["Parent"] = v49
		})
		for v53 = 0, 1 do
			v_u_12.new("Frame", {
				["Name"] = "Star" .. v53,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromScale(0.74, 0.74),
				["Rotation"] = v53 * 45,
				["BackgroundColor3"] = v_u_10,
				["ZIndex"] = 5,
				v_u_12.Corner(8),
				v_u_12.Stroke(v_u_6(255, 170, 176), 2, 0.25),
				["Parent"] = v52
			})
		end
		v_u_26.burstScale = v_u_12.new("UIScale", {
			["Parent"] = v52
		})
		v_u_26.burstPct = v_u_12.new("TextLabel", {
			["Name"] = "Pct",
			["Text"] = "SALE",
			["FontFace"] = v_u_16.Display,
			["TextSize"] = 30,
			["TextColor3"] = v_u_15.Text,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(0.5, 0, 0.5, -6),
			["Size"] = UDim2.fromScale(1, 0.4),
			["ZIndex"] = 6,
			v_u_12.TextStroke(v_u_6(120, 10, 20), 2, 0.2),
			["Parent"] = v52
		})
		v_u_26.burstOff = v_u_12.new("TextLabel", {
			["Name"] = "Off",
			["Text"] = "OFF",
			["FontFace"] = nil,
			["TextSize"] = 15,
			["TextColor3"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 6,
			["Parent"] = nil,
			["FontFace"] = v_u_16.Heavy,
			["TextColor3"] = v_u_15.Text,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(0.5, 0, 0.5, 18),
			["Size"] = UDim2.fromScale(1, 0.2),
			["Parent"] = v52
		})
		local v54 = v_u_12.new("Frame", {
			["Name"] = "Offer",
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Position"] = v_u_20(352, 0),
			["Size"] = UDim2.new(1, -352, 1, 0),
			["Parent"] = v48
		})
		v_u_26.col = v54
		local v55 = v_u_12.List(Enum.FillDirection.Vertical, 10)
		v55.Parent = v54
		v_u_26.list = v55
		v_u_26.tag = v_u_12.Pill("ONE-TIME OFFER", v_u_10, {
			["Name"] = "Tag",
			["Height"] = 28,
			["TextSize"] = 14,
			["Transparency"] = 0,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Parent"] = v54
		})
		v_u_26.title = v_u_12.DisplayText({
			["Name"] = "Name",
			["Text"] = "GOLDEN DROP",
			["TextSize"] = 42,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Size"] = nil,
			["StrokeThickness"] = 0,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["TextColor3"] = v_u_7,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Size"] = UDim2.new(1, 0, 0, 44),
			["Parent"] = v54
		})
		v_u_26.line = v_u_12.new("TextLabel", {
			["Name"] = "Line",
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 16,
			["TextColor3"] = nil,
			["TextWrapped"] = true,
			["TextXAlignment"] = nil,
			["TextYAlignment"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 3,
			["Parent"] = nil,
			["FontFace"] = v_u_16.SemiBold,
			["TextColor3"] = v_u_15.TextDim,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextYAlignment"] = Enum.TextYAlignment.Top,
			["Size"] = UDim2.new(1, 0, 0, 42),
			["Parent"] = v54
		})
		local v56 = v_u_12.new("Frame", {
			["Name"] = "Prices",
			["Size"] = nil,
			["LayoutOrder"] = 4,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 56),
			["Parent"] = v54
		})
		v_u_26.prices = v56
		v_u_26.was = v_u_12.new("TextLabel", {
			["Name"] = "Was",
			["Text"] = "",
			["RichText"] = true,
			["FontFace"] = nil,
			["TextSize"] = 28,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["AutomaticSize"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_16.Heavy,
			["TextColor3"] = v_u_15.TextMuted,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 0, 0.5, 2),
			["Size"] = UDim2.new(0, 0, 0, 30),
			["Parent"] = v56
		})
		v_u_26.slash = v_u_12.new("Frame", {
			["Name"] = "Slash",
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.new(1, 8, 0, 3),
			["Rotation"] = -14,
			["BackgroundColor3"] = v_u_10,
			["ZIndex"] = 3,
			v_u_12.Corner(2),
			["Parent"] = v_u_26.was
		})
		v_u_26.now = v_u_12.DisplayText({
			["Name"] = "Now",
			["Text"] = "",
			["TextSize"] = 50,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["StrokeThickness"] = 0,
			["Parent"] = nil,
			["TextColor3"] = v_u_15.Text,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 110, 0.5, 0),
			["Size"] = UDim2.new(0, 160, 0, 54),
			["Parent"] = v56
		})
		local v57 = v_u_12.new("Frame", {
			["Name"] = "Timer",
			["Size"] = UDim2.new(1, 0, 0, 64),
			["BackgroundColor3"] = v_u_10,
			["BackgroundTransparency"] = 0.86,
			["LayoutOrder"] = 5,
			v_u_12.Corner(12),
			v_u_12.Stroke(v_u_10, 1.5, 0.55),
			["Parent"] = v54
		})
		v_u_26.timer = v57
		v_u_12.Glyph("clock", 26, v_u_6(255, 140, 146), {
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 14, 0.5, 0),
			["Parent"] = v57
		})
		v_u_12.new("TextLabel", {
			["Name"] = "Ends",
			["Text"] = "ENDS IN",
			["FontFace"] = nil,
			["TextSize"] = 14,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_16.Heavy,
			["TextColor3"] = v_u_6(255, 160, 166),
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Position"] = v_u_20(50, 10),
			["Size"] = v_u_20(80, 18),
			["Parent"] = v57
		})
		v_u_26.left = v_u_12.new("TextLabel", {
			["Name"] = "Left",
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 28,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_16.Display,
			["TextColor3"] = v_u_15.Text,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Position"] = v_u_20(50, 28),
			["Size"] = v_u_20(150, 30),
			["Parent"] = v57
		})
		v_u_12.new("TextLabel", {
			["Name"] = "Gone",
			["Text"] = "Then this price is gone for good.",
			["FontFace"] = nil,
			["TextSize"] = 13,
			["TextColor3"] = nil,
			["TextWrapped"] = true,
			["TextXAlignment"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_16.SemiBold,
			["TextColor3"] = v_u_15.TextDim,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -14, 0.5, 0),
			["Size"] = UDim2.new(1, -220, 1, -12),
			["Parent"] = v57
		})
		v_u_26.buy = v_u_12.Button({
			["Name"] = "Buy",
			["Text"] = "",
			["TextSize"] = 22,
			["Style"] = "Success",
			["Size"] = nil,
			["LayoutOrder"] = 6,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 60),
			["Parent"] = v54
		})
		v_u_26.buy.Label.RichText = true
		v_u_26.buy.Activated:Connect(function()
			-- upvalues: (ref) v_u_27, (ref) v_u_18, (ref) v_u_21
			if os.clock() - v_u_27 > 0.4 then
				v_u_18.Buy(v_u_21)
			end
		end)
		local v58 = v_u_12.new("Frame", {
			["Name"] = "Row",
			["Size"] = UDim2.new(1, 0, 0, 46),
			["LayoutOrder"] = 7,
			v_u_12.List(Enum.FillDirection.Horizontal, 10),
			["Parent"] = v54
		})
		v_u_26.row = v58
		v_u_26.odds = v_u_12.Button({
			["Name"] = "Odds",
			["Text"] = "VIEW ODDS",
			["TextSize"] = 16,
			["Style"] = "Dark",
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Size"] = UDim2.new(0.5, -5, 1, 0),
			["Parent"] = v58
		})
		v_u_26.odds.Activated:Connect(function()
			-- upvalues: (ref) v_u_27, (ref) v_u_17
			if os.clock() - v_u_27 > 0.4 then
				v_u_17.Close("GoldenOffer")
				task.defer(function()
					-- upvalues: (ref) v_u_17
					v_u_17.Open("Collection", {
						["odds"] = true
					})
				end)
			end
		end)
		v_u_26.later = v_u_12.Button({
			["Name"] = "Later",
			["Text"] = "NOT NOW",
			["TextSize"] = 16,
			["Style"] = "Dark",
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["Size"] = UDim2.new(0.5, -5, 1, 0),
			["Parent"] = v58
		})
		v_u_26.later.Activated:Connect(function()
			-- upvalues: (ref) v_u_27, (ref) v_u_17
			if os.clock() - v_u_27 > 0.4 then
				v_u_17.Close("GoldenOffer")
			end
		end)
	end
	local function v_u_81() -- name: paint
		-- upvalues: (ref) v_u_25, (copy) v_u_18, (copy) v_u_26, (copy) v_u_21, (ref) v_u_4
		if v_u_25 then
			local v60 = v_u_18.DropInfo("golden")
			local v61 = v60.stacks
			local v62 = tonumber(v61) or 4
			local v63 = v60.min
			local v64 = tonumber(v63)
			local v65 = v60.max
			local v66 = tonumber(v65)
			local v67
			if v64 and v66 then
				local v68 = v62 * (v64 + v66) / 2 + 0.5
				v67 = math.floor(v68)
			else
				v67 = 60
			end
			v_u_26.line.Text = string.format("About %d item shards in %d big stacks. One is always an item you don\'t own yet.", v67, v62)
			local v69 = v_u_18.OfferDiscount()
			v_u_26.burstPct.Text = not v69 and "SALE" or string.format("-%d%%", v69)
			v_u_26.burstOff.Visible = v69 ~= nil
			local v70 = v_u_18.Price("drop_golden")
			local v71 = v_u_18.Price(v_u_21)
			v_u_26.was.Text = not v70 and "" or string.format("%s %d", v_u_18.ROBUX, v70)
			v_u_26.slash.Visible = v70 ~= nil
			local v72 = v_u_26.now
			local v73
			if v71 then
				v73 = string.format("%s %d", v_u_18.ROBUX, v71)
			else
				v73 = v_u_18.ROBUX .. " \226\128\166"
			end
			v72.Text = v73
			local v74 = v_u_26.now
			local v75 = UDim2.new
			local v76 = 0
			local v77
			if v70 then
				local v78 = v_u_26.was.TextBounds.X
				v77 = math.max(v78, 60) + 22
			else
				v77 = 0
			end
			v74.Position = v75(v76, v77, 0.5, 0)
			local v79 = v_u_18.Pending(v_u_21)
			v_u_26.buy:SetText(v79 and "\226\128\166" or string.format("BUY NOW  <font color=\"#FFFFFF\">%s</font> %s", v_u_18.ROBUX, v_u_18.PriceAmount(v_u_21)))
			v_u_26.buy:SetEnabled(not v79)
			local v80 = v_u_18.OfferLeft() or v_u_4.FIRST_DROP.duration
			v_u_26.left.Text = v_u_18.FormatLeft(v80)
		end
	end
	local function v_u_92() -- name: layout
		-- upvalues: (copy) v_u_12, (ref) v_u_25, (copy) v_u_20, (copy) v_u_26, (copy) v_u_81
		local v82 = v_u_12.CanvasSize()
		local v83 = v_u_12.TopInset()
		local v84 = v_u_12.Compact or v82.Y - v83 < 600
		local v85 = v82.X - 24
		local v86 = math.clamp(v85, 360, 780)
		local v87 = math.floor(v86)
		local v88 = v82.Y - v83 - 12
		local v89 = math.clamp(v88, 320, v84 and 440 or 520)
		local v90 = math.floor(v89)
		v_u_25.Holder.Size = v_u_20(v87, v90)
		local v91 = v84 and 270 or 330
		v_u_26.hero.Size = UDim2.new(0, v91, 1, 0)
		v_u_26.col.Position = v_u_20(v91 + 22, 0)
		v_u_26.col.Size = UDim2.new(1, -(v91 + 22), 1, 0)
		v_u_26.list.Padding = UDim.new(0, v84 and 6 or 10)
		v_u_26.title.TextSize = v84 and 34 or 42
		v_u_26.title.Size = UDim2.new(1, 0, 0, v84 and 36 or 44)
		v_u_26.line.TextSize = v84 and 14 or 16
		v_u_26.line.Size = UDim2.new(1, 0, 0, v84 and 36 or 42)
		v_u_26.prices.Size = UDim2.new(1, 0, 0, v84 and 46 or 56)
		v_u_26.now.TextSize = v84 and 40 or 50
		v_u_26.timer.Size = UDim2.new(1, 0, 0, v84 and 56 or 64)
		v_u_26.buy.Instance.Size = UDim2.new(1, 0, 0, v84 and 52 or 60)
		v_u_26.row.Size = UDim2.new(1, 0, 0, v84 and 40 or 46)
		v_u_25.Refit()
		v_u_81()
	end
	local v105 = {
		["open"] = function() -- name: open
			-- upvalues: (ref) v_u_25, (copy) v_u_59, (ref) v_u_27, (ref) v_u_28, (copy) p_u_11, (copy) v_u_92, (ref) v_u_30, (ref) v_u_2, (copy) v_u_29, (copy) v_u_26, (copy) v_u_18, (copy) v_u_12
			if not v_u_25 then
				v_u_59()
			end
			v_u_27 = os.clock()
			v_u_28 = true
			p_u_11.SetHudHidden("GoldenOffer", true)
			v_u_92()
			v_u_25:Open()
			if not v_u_30 then
				local v_u_93 = os.clock()
				v_u_30 = v_u_2.RenderStepped:Connect(function()
					-- upvalues: (copy) v_u_93, (ref) v_u_29, (ref) v_u_26
					local v94 = os.clock() - v_u_93
					local v95 = v94 * 0.9
					local v96 = math.sin(v95) * 0.4886921905584123 + 0.4188790204786391
					local v97 = v94 * 1.7
					local v98 = math.sin(v97) * 0.12
					local v99 = CFrame.new(0, v98, 0) * CFrame.Angles(0, v96, 0)
					for _, v100 in v_u_29 do
						v100.part.CFrame = v99 * v100.cf
					end
					v_u_26.rays.Rotation = v94 * 10 % 360
					local v101 = v_u_26.burstScale
					local v102 = v94 * 5
					local v103 = math.sin(v102)
					v101.Scale = math.max(0, v103) ^ 3 * 0.06 + 1
				end)
			end
			v_u_18.OfferSeen()
			p_u_11.Sounds.Play("Open")
			task.delay(0.2, function()
				-- upvalues: (ref) v_u_25, (ref) v_u_12, (ref) v_u_26
				if v_u_25.IsOpen then
					v_u_12.Pop(v_u_26.burstScale.Parent, 0.7)
				end
			end)
		end,
		["close"] = function(p104) -- name: close
			-- upvalues: (copy) p_u_11, (ref) v_u_30, (ref) v_u_25
			p_u_11.SetHudHidden("GoldenOffer", false)
			if v_u_30 then
				v_u_30:Disconnect()
				v_u_30 = nil
			end
			v_u_25:Close(p104)
		end,
		["select"] = function() -- name: select
			-- upvalues: (copy) v_u_26
			if v_u_26.buy then
				return v_u_26.buy.Instance
			else
				return nil
			end
		end
	}
	v_u_17.Register("GoldenOffer", v105)
	local function v106() -- name: relayout
		-- upvalues: (ref) v_u_25, (copy) v_u_92
		if v_u_25 and v_u_25.IsOpen then
			v_u_92()
		end
	end
	v_u_12.LayoutChanged:Connect(v106)
	v_u_12.OnResize(v106)
	v_u_18.Changed:Connect(function()
		-- upvalues: (ref) v_u_25, (copy) v_u_18, (copy) v_u_17, (copy) v_u_81
		if v_u_25 and v_u_25.IsOpen then
			if not v_u_18.GoldenOffer() then
				v_u_17.Close("GoldenOffer")
				return
			end
			v_u_81()
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_25, (copy) v_u_18, (copy) v_u_17, (copy) v_u_81
		while true do
			repeat
				task.wait(1)
			until v_u_25 and v_u_25.IsOpen
			if v_u_18.GoldenOffer() then
				v_u_81()
			else
				v_u_17.Close("GoldenOffer")
			end
		end
	end)
	local function v_u_108() -- name: lobbyQuiet
		-- upvalues: (copy) v_u_14, (copy) v_u_17, (copy) p_u_11, (copy) v_u_19
		local v107 = not (v_u_14.InMatch() or (v_u_17.IsOpen() or p_u_11.IsHudHiddenFor("Reveal")))
		if v107 then
			if v_u_19:GetAttribute("WelcomeCard") == true or (v_u_19:GetAttribute("Teleporting") == true or v_u_19:GetAttribute("Queued") == true) then
				v107 = false
			else
				v107 = v_u_19.Character ~= nil
			end
		end
		return v107
	end
	local v_u_109 = false
	local function v114() -- name: maybeShow
		-- upvalues: (ref) v_u_109, (copy) v_u_18, (ref) v_u_28, (copy) v_u_21, (copy) v_u_108, (copy) v_u_17
		if not v_u_109 then
			local v110 = v_u_18.GoldenOffer() ~= false and not v_u_28
			if v110 then
				v110 = v_u_18.CanBuy(v_u_21)
			end
			if v110 then
				v_u_109 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_18, (ref) v_u_28, (ref) v_u_21, (ref) v_u_108, (ref) v_u_17, (ref) v_u_109
					local v111 = os.clock()
					local v112 = nil
					while true do
						local v113 = v_u_18.GoldenOffer() ~= false and not v_u_28
						if v113 then
							v113 = v_u_18.CanBuy(v_u_21)
						end
						if not v113 or os.clock() - v111 >= 600 then
							break
						end
						if v_u_108() then
							v112 = v112 or os.clock()
							if os.clock() - v112 >= 1.5 then
								v_u_17.Open("GoldenOffer")
								break
							end
						else
							v112 = nil
						end
						task.wait(0.25)
					end
					v_u_109 = false
				end)
				return
			end
		end
	end
	v_u_18.Changed:Connect(v114)
	v_u_14.PlayerStateChanged:Connect(v114)
	if not v_u_109 then
		local v115 = v_u_18.GoldenOffer() ~= false and not v_u_28
		if v115 then
			v115 = v_u_18.CanBuy(v_u_21)
		end
		if v115 then
			v_u_109 = true
			task.spawn(function()
				-- upvalues: (copy) v_u_18, (ref) v_u_28, (copy) v_u_21, (copy) v_u_108, (copy) v_u_17, (ref) v_u_109
				local v116 = os.clock()
				local v117 = nil
				while true do
					local v118 = v_u_18.GoldenOffer() ~= false and not v_u_28
					if v118 then
						v118 = v_u_18.CanBuy(v_u_21)
					end
					if not v118 or os.clock() - v116 >= 600 then
						break
					end
					if v_u_108() then
						v117 = v117 or os.clock()
						if os.clock() - v117 >= 1.5 then
							v_u_17.Open("GoldenOffer")
							break
						end
					else
						v117 = nil
					end
					task.wait(0.25)
				end
				v_u_109 = false
			end)
		end
	end
	function p_u_11.Debug.goldenOffer(p119)
		-- upvalues: (copy) v_u_17, (copy) v_u_18, (ref) v_u_28, (ref) v_u_109
		if p119 == "open" then
			v_u_17.Open("GoldenOffer")
		end
		return {
			["offer"] = v_u_18.GoldenOffer(),
			["left"] = v_u_18.OfferLeft() or false,
			["discount"] = v_u_18.OfferDiscount() or false,
			["open"] = v_u_17.IsOpen("GoldenOffer"),
			["shownThisSession"] = v_u_28,
			["waiting"] = v_u_109
		}
	end
end
return v5