local v_u_1 = {
	["ID_PATTERN"] = "^[%w%-_]+$",
	["MAX_ID"] = 40,
	["REACTABLE"] = 8,
	["LIST"] = {
		{
			["id"] = "welcome-2026-09-28",
			["date"] = "2026-09-28",
			["author"] = 22641473,
			["heading"] = "Welcome to Tribes",
			["body"] = nil,
			["signature"] = "\226\128\148 SnickTrix",
			["reactions"] = true,
			["body"] = { "If you\'re reading this, you\'re here very early. This is my new team based PvP game. It\'s based on my Minecraft gamemode from 2016.", "I\'m updating the game everyday. The meta will be changing often..", "GLHF" }
		}
	}
}
local v_u_2 = {}
local v3 = 0
local v_u_4 = {}
for _, v5 in v_u_1.LIST do
	local v6 = v5.id
	local v7
	if type(v6) == "string" and #v5.id <= v_u_1.MAX_ID then
		v7 = string.match(v5.id, v_u_1.ID_PATTERN)
	else
		v7 = false
	end
	assert(v7, "bad letter id")
	local v8 = v_u_2[v5.id] == nil
	local v9 = "duplicate letter id " .. v5.id
	assert(v8, v9)
	v_u_2[v5.id] = v5
	if v5.reactions == false or v3 >= v_u_1.REACTABLE then
		continue
	end
	v_u_4[v5.id] = true
	v3 = v3 + 1
end
function v_u_1.Current() -- name: Current
	-- upvalues: (copy) v_u_1
	return v_u_1.LIST[1]
end
function v_u_1.Get(p10) -- name: Get
	-- upvalues: (copy) v_u_2
	if type(p10) == "string" then
		return v_u_2[p10]
	else
		return nil
	end
end
function v_u_1.CanReact(p11) -- name: CanReact
	-- upvalues: (copy) v_u_4
	local v12
	if type(p11) == "string" then
		v12 = v_u_4[p11] == true
	else
		v12 = false
	end
	return v12
end
function v_u_1.ReactableIds() -- name: ReactableIds
	-- upvalues: (copy) v_u_1, (copy) v_u_4
	local v13 = {}
	for _, v14 in v_u_1.LIST do
		if not v_u_4[v14.id] then
			continue
		end
		local v15 = v14.id
		table.insert(v13, v15)
	end
	return v13
end
function v_u_1.IsIdShape(p16) -- name: IsIdShape
	-- upvalues: (copy) v_u_1
	local v17
	if type(p16) == "string" and (#p16 > 0 and #p16 <= v_u_1.MAX_ID) then
		v17 = string.match(p16, v_u_1.ID_PATTERN) ~= nil
	else
		v17 = false
	end
	return v17
end
return v_u_1