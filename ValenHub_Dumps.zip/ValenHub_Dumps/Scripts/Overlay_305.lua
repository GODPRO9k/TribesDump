game:GetService("GuiService")
local v1 = game:GetService("Players")
local v_u_2 = game:GetService("TextService")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = {}
local v_u_7 = v1.LocalPlayer
local v8 = script.Parent.Parent
local v_u_9 = nil
local function v_u_16(p10) -- name: playUI
	-- upvalues: (ref) v_u_9
	if not v_u_9 then
		local v11 = game:GetService("ReplicatedStorage"):FindFirstChild("Shared")
		if v11 then
			v11 = v11:FindFirstChild("Sfx")
		end
		if v11 and v11:IsA("ModuleScript") then
			local v12 = require
			local v13, v14 = pcall(v12, v11)
			if not v13 or type(v14) ~= "table" then
				v14 = false
			end
			v_u_9 = v14
		end
	end
	if v_u_9 then
		local v15 = v_u_9.PlayUI
		pcall(v15, p10)
	end
end
local v_u_17 = Color3.fromRGB
local v_u_18 = {
	["Void"] = v_u_17(6, 7, 10),
	["Panel"] = v_u_17(18, 20, 26),
	["PanelHi"] = v_u_17(28, 31, 39),
	["Text"] = v_u_17(255, 255, 255),
	["TextDim"] = v_u_17(186, 192, 206),
	["TextMuted"] = v_u_17(124, 131, 148),
	["Accent"] = v_u_17(40, 150, 255),
	["Danger"] = v_u_17(245, 64, 72),
	["Gold"] = v_u_17(255, 200, 60),
	["Ally"] = v_u_17(70, 170, 255),
	["Enemy"] = v_u_17(255, 72, 72)
}
local v_u_19 = {
	["Display"] = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Heavy),
	["Title"] = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.ExtraBold),
	["Bold"] = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Bold),
	["SemiBold"] = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.SemiBold)
}
local v20 = v8:FindFirstChild("UI")
if v20 then
	v20 = v20:FindFirstChild("Theme")
end
if v20 and v20:IsA("ModuleScript") then
	local v21 = require
	local v22, v23 = pcall(v21, v20)
	if v22 and type(v23) == "table" then
		local v24 = v23.Colors
		if type(v24) == "table" then
			for v25 in v_u_18 do
				local v26 = v23.Colors[v25]
				if typeof(v26) ~= "Color3" then
					continue
				end
				v_u_18[v25] = v26
			end
			local v27 = v23.Fonts
			if type(v27) == "table" then
				for v28 in v_u_19 do
					local v29 = v23.Fonts[v28]
					if typeof(v29) ~= "Font" then
						continue
					end
					v_u_19[v28] = v29
				end
			end
		end
	end
end
v_u_6.Colors = v_u_18
local function v_u_37(p30, p31, p32) -- name: new
	local v33 = Instance.new(p30)
	for v34, v35 in p31 do
		if v34 == "Parent" then
			continue
		end
		v33[v34] = v35
	end
	if p32 then
		for _, v36 in p32 do
			v36.Parent = v33
		end
	end
	if p31.Parent then
		v33.Parent = p31.Parent
	end
	return v33
end
local v_u_38 = nil
local v_u_39 = {
	["TintColor"] = nil,
	["Saturation"] = -0.42,
	["Contrast"] = -0.18,
	["Brightness"] = 0.01,
	["TintColor"] = Color3.fromRGB(255, 220, 194)
}
local v_u_40 = {
	["TintColor"] = nil,
	["Saturation"] = 0,
	["Contrast"] = 0,
	["Brightness"] = 0,
	["TintColor"] = Color3.new(1, 1, 1)
}
local v_u_41 = {
	Vector2.new(0, 0),
	Vector2.new(1, 0),
	Vector2.new(0, 1),
	Vector2.new(1, 1)
}
local function v_u_217() -- name: build
	-- upvalues: (copy) v_u_7, (copy) v_u_41, (copy) v_u_18, (copy) v_u_37, (copy) v_u_19, (copy) v_u_17
	local v42 = v_u_7:WaitForChild("PlayerGui")
	local v43 = {
		["Name"] = "TR_Replay",
		["DisplayOrder"] = 60,
		["IgnoreGuiInset"] = true,
		["ResetOnSpawn"] = false,
		["ZIndexBehavior"] = nil,
		["Enabled"] = false,
		["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling
	}
	local v_u_44 = Instance.new("ScreenGui")
	for v45, v46 in v43 do
		if v45 == "Parent" then
			continue
		end
		v_u_44[v45] = v46
	end
	if v43.Parent then
		v_u_44.Parent = v43.Parent
	end
	pcall(function()
		-- upvalues: (copy) v_u_44
		v_u_44.ScreenInsets = Enum.ScreenInsets.None
	end)
	local v47 = {
		["Name"] = "TR_ReplayHud",
		["DisplayOrder"] = 61,
		["IgnoreGuiInset"] = true,
		["ResetOnSpawn"] = false,
		["ZIndexBehavior"] = nil,
		["Enabled"] = false,
		["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling
	}
	local v_u_48 = Instance.new("ScreenGui")
	for v49, v50 in v47 do
		if v49 == "Parent" then
			continue
		end
		v_u_48[v49] = v50
	end
	if v47.Parent then
		v_u_48.Parent = v47.Parent
	end
	pcall(function()
		-- upvalues: (copy) v_u_48
		v_u_48.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
	end)
	local v51 = {
		["Name"] = "TR_ReplayFrame",
		["DisplayOrder"] = 62,
		["IgnoreGuiInset"] = false,
		["ResetOnSpawn"] = false,
		["ZIndexBehavior"] = nil,
		["Enabled"] = false,
		["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling
	}
	local v_u_52 = Instance.new("ScreenGui")
	for v53, v54 in v51 do
		if v53 == "Parent" then
			continue
		end
		v_u_52[v53] = v54
	end
	if v51.Parent then
		v_u_52.Parent = v51.Parent
	end
	pcall(function()
		-- upvalues: (copy) v_u_52
		v_u_52.ScreenInsets = Enum.ScreenInsets.CoreUISafeInsets
	end)
	local v55 = {}
	local v56 = {}
	for v57, v58 in v_u_41 do
		local v59 = {
			["Name"] = nil,
			["AnchorPoint"] = nil,
			["BackgroundTransparency"] = 1,
			["Parent"] = nil,
			["Name"] = "Corner" .. v57,
			["AnchorPoint"] = v58,
			["Parent"] = v_u_52
		}
		local v60 = Instance.new("Frame")
		for v61, v62 in v59 do
			if v61 == "Parent" then
				continue
			end
			v60[v61] = v62
		end
		if v59.Parent then
			v60.Parent = v59.Parent
		end
		local v63 = {
			["Name"] = "H",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0, v58.Y),
			["Position"] = UDim2.fromScale(0, v58.Y),
			["BackgroundColor3"] = v_u_18.Text,
			["Parent"] = v60
		}
		local v64 = Instance.new("Frame")
		for v65, v66 in v63 do
			if v65 == "Parent" then
				continue
			end
			v64[v65] = v66
		end
		if v63.Parent then
			v64.Parent = v63.Parent
		end
		local v67 = {
			["Name"] = "V",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(v58.X, 0),
			["Position"] = UDim2.fromScale(v58.X, 0),
			["BackgroundColor3"] = v_u_18.Text,
			["Parent"] = v60
		}
		local v68 = Instance.new("Frame")
		for v69, v70 in v67 do
			if v69 == "Parent" then
				continue
			end
			v68[v69] = v70
		end
		if v67.Parent then
			v68.Parent = v67.Parent
		end
		table.insert(v55, v60)
		table.insert(v56, v64)
		table.insert(v56, v68)
	end
	local v71 = v_u_37
	local v72 = {
		["Name"] = "Rec",
		["AnchorPoint"] = nil,
		["BackgroundTransparency"] = 1,
		["AutomaticSize"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v_u_52
	}
	local v73 = {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["SortOrder"] = Enum.SortOrder.LayoutOrder
	}
	local v74 = Instance.new("UIListLayout")
	local v75 = {}
	local v76 = "Frame"
	for v77, v78 in v73 do
		if v77 == "Parent" then
			continue
		end
		v74[v77] = v78
	end
	if v73.Parent then
		v74.Parent = v73.Parent
	end
	__set_list(v75, 1, {v74})
	local v79 = v71(v76, v72, v75)
	local v80 = v_u_37
	local v81 = {
		["Name"] = "Dot",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_18.Danger,
		["Parent"] = v79
	}
	local v82 = {
		["CornerRadius"] = UDim.new(1, 0)
	}
	local v83 = Instance.new("UICorner")
	local v84 = {}
	local v85 = "Frame"
	for v86, v87 in v82 do
		if v86 == "Parent" then
			continue
		end
		v83[v86] = v87
	end
	if v82.Parent then
		v83.Parent = v82.Parent
	end
	__set_list(v84, 1, {v83})
	local v88 = v80(v85, v81, v84)
	local v89 = {
		["Name"] = "Text",
		["Text"] = "REC",
		["FontFace"] = nil,
		["AutomaticSize"] = nil,
		["TextStrokeColor3"] = nil,
		["TextStrokeTransparency"] = 0.85,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["FontFace"] = v_u_19.Title,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["TextStrokeColor3"] = v_u_18.Void,
		["Parent"] = v79,
		["BackgroundTransparency"] = 1
	}
	v89.TextColor3 = v89.TextColor3 or v_u_18.Text
	v89.FontFace = v89.FontFace or v_u_19.Bold
	v89.TextXAlignment = v89.TextXAlignment or Enum.TextXAlignment.Left
	local v90 = Instance.new("TextLabel")
	for v91, v92 in v89 do
		if v91 == "Parent" then
			continue
		end
		v90[v91] = v92
	end
	if v89.Parent then
		v90.Parent = v89.Parent
	end
	local v93 = {
		["Name"] = "Cover",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 10,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_18.Void,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_44
	}
	local v94 = Instance.new("Frame")
	for v95, v96 in v93 do
		if v95 == "Parent" then
			continue
		end
		v94[v95] = v96
	end
	if v93.Parent then
		v94.Parent = v93.Parent
	end
	local v97 = {
		["Rotation"] = 90,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v_u_17(22, 26, 36), v_u_18.Void),
		["Parent"] = v94
	}
	local v98 = Instance.new("UIGradient")
	for v99, v100 in v97 do
		if v99 == "Parent" then
			continue
		end
		v98[v99] = v100
	end
	if v97.Parent then
		v98.Parent = v97.Parent
	end
	local v101 = {
		["Name"] = "Card",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundTransparency"] = 1,
		["ZIndex"] = 11,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(1180, 260),
		["Parent"] = v94
	}
	local v102 = Instance.new("Frame")
	for v103, v104 in v101 do
		if v103 == "Parent" then
			continue
		end
		v102[v103] = v104
	end
	if v101.Parent then
		v102.Parent = v101.Parent
	end
	local v105 = {
		["Parent"] = v102
	}
	local v106 = Instance.new("UIScale")
	for v107, v108 in v105 do
		if v107 == "Parent" then
			continue
		end
		v106[v107] = v108
	end
	if v105.Parent then
		v106.Parent = v105.Parent
	end
	local v109 = {
		["Name"] = "Label",
		["Text"] = "PLAY OF THE GAME",
		["FontFace"] = nil,
		["TextSize"] = 30,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 12,
		["Parent"] = nil,
		["FontFace"] = v_u_19.Title,
		["TextColor3"] = v_u_18.Accent,
		["Position"] = UDim2.fromOffset(196, 8),
		["Size"] = UDim2.fromOffset(700, 34),
		["Parent"] = v102,
		["BackgroundTransparency"] = 1
	}
	v109.TextColor3 = v109.TextColor3 or v_u_18.Text
	v109.FontFace = v109.FontFace or v_u_19.Bold
	v109.TextXAlignment = v109.TextXAlignment or Enum.TextXAlignment.Left
	local v110 = Instance.new("TextLabel")
	for v111, v112 in v109 do
		if v111 == "Parent" then
			continue
		end
		v110[v111] = v112
	end
	if v109.Parent then
		v110.Parent = v109.Parent
	end
	local v113 = {
		["Name"] = "Bar",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 12,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_18.Accent,
		["Position"] = UDim2.fromOffset(198, 48),
		["Size"] = UDim2.fromOffset(0, 5),
		["Parent"] = v102
	}
	local v114 = Instance.new("Frame")
	for v115, v116 in v113 do
		if v115 == "Parent" then
			continue
		end
		v114[v115] = v116
	end
	if v113.Parent then
		v114.Parent = v113.Parent
	end
	local v117 = {
		["Name"] = "Stripe",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 12,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_18.Ally,
		["Position"] = UDim2.fromOffset(198, 66),
		["Size"] = UDim2.fromOffset(6, 104),
		["Parent"] = v102
	}
	local v118 = Instance.new("Frame")
	for v119, v120 in v117 do
		if v119 == "Parent" then
			continue
		end
		v118[v119] = v120
	end
	if v117.Parent then
		v118.Parent = v117.Parent
	end
	local v121 = {
		["Name"] = "PlayerName",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 104,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 12,
		["Parent"] = nil,
		["FontFace"] = v_u_19.Display,
		["Position"] = UDim2.fromOffset(222, 60),
		["Size"] = UDim2.fromOffset(950, 112),
		["Parent"] = v102,
		["BackgroundTransparency"] = 1
	}
	v121.TextColor3 = v121.TextColor3 or v_u_18.Text
	v121.FontFace = v121.FontFace or v_u_19.Bold
	v121.TextXAlignment = v121.TextXAlignment or Enum.TextXAlignment.Left
	local v122 = Instance.new("TextLabel")
	for v123, v124 in v121 do
		if v123 == "Parent" then
			continue
		end
		v122[v123] = v124
	end
	if v121.Parent then
		v122.Parent = v121.Parent
	end
	local v125 = {
		["Name"] = "Title",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 30,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 12,
		["Parent"] = nil,
		["FontFace"] = v_u_19.Bold,
		["TextColor3"] = v_u_18.TextDim,
		["Position"] = UDim2.fromOffset(224, 178),
		["Size"] = UDim2.fromOffset(950, 36),
		["Parent"] = v102,
		["BackgroundTransparency"] = 1
	}
	v125.TextColor3 = v125.TextColor3 or v_u_18.Text
	v125.FontFace = v125.FontFace or v_u_19.Bold
	v125.TextXAlignment = v125.TextXAlignment or Enum.TextXAlignment.Left
	local v126 = Instance.new("TextLabel")
	for v127, v128 in v125 do
		if v127 == "Parent" then
			continue
		end
		v126[v127] = v128
	end
	if v125.Parent then
		v126.Parent = v125.Parent
	end
	local v129 = v_u_37
	local v130 = {
		["Name"] = "Portrait",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Ambient"] = nil,
		["LightColor"] = nil,
		["LightDirection"] = Vector3.new(-0.6, -1, -0.8),
		["ZIndex"] = 12,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_18.PanelHi,
		["Position"] = UDim2.fromOffset(0, 40),
		["Size"] = UDim2.fromOffset(170, 170),
		["Ambient"] = v_u_17(170, 172, 182),
		["LightColor"] = v_u_17(255, 250, 240),
		["Parent"] = v102
	}
	local v131 = {
		["CornerRadius"] = UDim.new(0, 14)
	}
	local v132 = Instance.new("UICorner")
	local v133 = {}
	local v134 = "ViewportFrame"
	for v135, v136 in v131 do
		if v135 == "Parent" then
			continue
		end
		v132[v135] = v136
	end
	if v131.Parent then
		v132.Parent = v131.Parent
	end
	local v137 = {
		["Color"] = nil,
		["Transparency"] = 0.82,
		["Thickness"] = 2,
		["Color"] = v_u_18.Text
	}
	local v138 = Instance.new("UIStroke")
	for v139, v140 in v137 do
		if v139 == "Parent" then
			continue
		end
		v138[v139] = v140
	end
	if v137.Parent then
		v138.Parent = v137.Parent
	end
	__set_list(v133, 1, {v132, v138})
	local v141 = v129(v134, v130, v133)
	local v142 = {
		["Parent"] = v141
	}
	local v143 = Instance.new("UIScale")
	for v144, v145 in v142 do
		if v144 == "Parent" then
			continue
		end
		v143[v144] = v145
	end
	if v142.Parent then
		v143.Parent = v142.Parent
	end
	local v146 = {
		["Name"] = "Canvas",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_48
	}
	local v147 = Instance.new("Frame")
	for v148, v149 in v146 do
		if v148 == "Parent" then
			continue
		end
		v147[v148] = v149
	end
	if v146.Parent then
		v147.Parent = v146.Parent
	end
	local v150 = {
		["Parent"] = v147
	}
	local v151 = Instance.new("UIScale")
	for v152, v153 in v150 do
		if v152 == "Parent" then
			continue
		end
		v151[v152] = v153
	end
	if v150.Parent then
		v151.Parent = v150.Parent
	end
	local v154 = v_u_37
	local v155 = {
		["Name"] = "Tag",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.12,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 28, 1, -22),
		["Size"] = UDim2.fromOffset(0, 74),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["BackgroundColor3"] = v_u_18.Panel,
		["Parent"] = v147
	}
	local v156 = {
		["CornerRadius"] = UDim.new(0, 10)
	}
	local v157 = Instance.new("UICorner")
	local v158 = {}
	local v159 = "Frame"
	for v160, v161 in v156 do
		if v160 == "Parent" then
			continue
		end
		v157[v160] = v161
	end
	if v156.Parent then
		v157.Parent = v156.Parent
	end
	local v162 = {
		["Color"] = nil,
		["Transparency"] = 0.9,
		["Thickness"] = 1,
		["Color"] = v_u_18.Text
	}
	local v163 = Instance.new("UIStroke")
	for v164, v165 in v162 do
		if v164 == "Parent" then
			continue
		end
		v163[v164] = v165
	end
	if v162.Parent then
		v163.Parent = v162.Parent
	end
	local v166 = {
		["PaddingLeft"] = UDim.new(0, 22),
		["PaddingRight"] = UDim.new(0, 20)
	}
	local v167 = Instance.new("UIPadding")
	for v168, v169 in v166 do
		if v168 == "Parent" then
			continue
		end
		v167[v168] = v169
	end
	if v166.Parent then
		v167.Parent = v166.Parent
	end
	__set_list(v158, 1, {v157, v163, v167})
	local v170 = v154(v159, v155, v158)
	local v171 = v_u_37
	local v172 = {
		["Name"] = "Stripe",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_18.Accent,
		["Position"] = UDim2.new(0, -22, 0, 0),
		["Size"] = UDim2.new(0, 5, 1, 0),
		["Parent"] = v170
	}
	local v173 = {
		["CornerRadius"] = UDim.new(0, 3)
	}
	local v174 = Instance.new("UICorner")
	local v175 = {}
	local v176 = "Frame"
	for v177, v178 in v173 do
		if v177 == "Parent" then
			continue
		end
		v174[v177] = v178
	end
	if v173.Parent then
		v174.Parent = v173.Parent
	end
	__set_list(v175, 1, {v174})
	local v179 = v171(v176, v172, v175)
	local v180 = {
		["Name"] = "Label",
		["Text"] = "PLAY OF THE GAME",
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_19.Title,
		["TextColor3"] = v_u_18.Accent,
		["Position"] = UDim2.fromOffset(0, 9),
		["Size"] = UDim2.fromOffset(0, 16),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v170,
		["BackgroundTransparency"] = 1
	}
	v180.TextColor3 = v180.TextColor3 or v_u_18.Text
	v180.FontFace = v180.FontFace or v_u_19.Bold
	v180.TextXAlignment = v180.TextXAlignment or Enum.TextXAlignment.Left
	local v181 = Instance.new("TextLabel")
	for v182, v183 in v180 do
		if v182 == "Parent" then
			continue
		end
		v181[v182] = v183
	end
	if v180.Parent then
		v181.Parent = v180.Parent
	end
	local v184 = {
		["Name"] = "PlayerName",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 30,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_19.Display,
		["Position"] = UDim2.fromOffset(0, 26),
		["Size"] = UDim2.fromOffset(0, 30),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v170,
		["BackgroundTransparency"] = 1
	}
	v184.TextColor3 = v184.TextColor3 or v_u_18.Text
	v184.FontFace = v184.FontFace or v_u_19.Bold
	v184.TextXAlignment = v184.TextXAlignment or Enum.TextXAlignment.Left
	local v185 = Instance.new("TextLabel")
	for v186, v187 in v184 do
		if v186 == "Parent" then
			continue
		end
		v185[v186] = v187
	end
	if v184.Parent then
		v185.Parent = v184.Parent
	end
	local v188 = {
		["Name"] = "Title",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_19.Bold,
		["TextColor3"] = v_u_18.TextDim,
		["Position"] = UDim2.fromOffset(0, 55),
		["Size"] = UDim2.fromOffset(0, 14),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v170,
		["BackgroundTransparency"] = 1
	}
	v188.TextColor3 = v188.TextColor3 or v_u_18.Text
	v188.FontFace = v188.FontFace or v_u_19.Bold
	v188.TextXAlignment = v188.TextXAlignment or Enum.TextXAlignment.Left
	local v189 = Instance.new("TextLabel")
	for v190, v191 in v188 do
		if v190 == "Parent" then
			continue
		end
		v189[v190] = v191
	end
	if v188.Parent then
		v189.Parent = v188.Parent
	end
	local v192 = v_u_37
	local v193 = {
		["Name"] = "Skip",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.12,
		["AutoButtonColor"] = true,
		["Text"] = "SKIP  \226\128\186",
		["Visible"] = true,
		["FontFace"] = nil,
		["TextSize"] = 22,
		["TextColor3"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 1),
		["Position"] = UDim2.new(1, -28, 1, -26),
		["Size"] = UDim2.fromOffset(128, 52),
		["BackgroundColor3"] = v_u_18.Panel,
		["FontFace"] = v_u_19.Display,
		["TextColor3"] = v_u_18.Text,
		["Parent"] = v147
	}
	local v194 = {
		["CornerRadius"] = UDim.new(0, 10)
	}
	local v195 = Instance.new("UICorner")
	local v196 = {}
	local v197 = "TextButton"
	for v198, v199 in v194 do
		if v198 == "Parent" then
			continue
		end
		v195[v198] = v199
	end
	if v194.Parent then
		v195.Parent = v194.Parent
	end
	local v200 = {
		["Color"] = nil,
		["Transparency"] = 0.8,
		["Thickness"] = 1,
		["ApplyStrokeMode"] = nil,
		["Color"] = v_u_18.Text,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
	}
	local v201 = Instance.new("UIStroke")
	for v202, v203 in v200 do
		if v202 == "Parent" then
			continue
		end
		v201[v202] = v203
	end
	if v200.Parent then
		v201.Parent = v200.Parent
	end
	__set_list(v196, 1, {v195, v201})
	local v204 = v192(v197, v193, v196)
	local v205 = {
		["Name"] = "Pop",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundTransparency"] = 1,
		["Visible"] = false,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.22),
		["Size"] = UDim2.fromOffset(900, 90),
		["Parent"] = v147
	}
	local v206 = Instance.new("Frame")
	for v207, v208 in v205 do
		if v207 == "Parent" then
			continue
		end
		v206[v207] = v208
	end
	if v205.Parent then
		v206.Parent = v205.Parent
	end
	local v209 = {
		["Name"] = "Top",
		["Text"] = "ELIMINATED",
		["FontFace"] = nil,
		["TextSize"] = 22,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["TextStrokeTransparency"] = 0.7,
		["Parent"] = nil,
		["FontFace"] = v_u_19.Title,
		["TextColor3"] = v_u_18.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Size"] = UDim2.new(1, 0, 0, 26),
		["Parent"] = v206,
		["BackgroundTransparency"] = 1
	}
	v209.TextColor3 = v209.TextColor3 or v_u_18.Text
	v209.FontFace = v209.FontFace or v_u_19.Bold
	v209.TextXAlignment = v209.TextXAlignment or Enum.TextXAlignment.Left
	local v210 = Instance.new("TextLabel")
	for v211, v212 in v209 do
		if v211 == "Parent" then
			continue
		end
		v210[v211] = v212
	end
	if v209.Parent then
		v210.Parent = v209.Parent
	end
	local v213 = {
		["Name"] = "Name",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 44,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["TextStrokeTransparency"] = 0.6,
		["Parent"] = nil,
		["FontFace"] = v_u_19.Display,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Position"] = UDim2.fromOffset(0, 26),
		["Size"] = UDim2.new(1, 0, 0, 50),
		["Parent"] = v206,
		["BackgroundTransparency"] = 1
	}
	v213.TextColor3 = v213.TextColor3 or v_u_18.Text
	v213.FontFace = v213.FontFace or v_u_19.Bold
	v213.TextXAlignment = v213.TextXAlignment or Enum.TextXAlignment.Left
	local v214 = Instance.new("TextLabel")
	for v215, v216 in v213 do
		if v215 == "Parent" then
			continue
		end
		v214[v215] = v216
	end
	if v213.Parent then
		v214.Parent = v213.Parent
	end
	v_u_44.Parent = v42
	v_u_48.Parent = v42
	v_u_52.Parent = v42
	return {
		["gui"] = v_u_44,
		["hud"] = v_u_48,
		["frame"] = v_u_52,
		["cover"] = v94,
		["card"] = v102,
		["cardScale"] = v106,
		["cardLabel"] = v110,
		["cardBar"] = v114,
		["cardName"] = v122,
		["cardTitle"] = v126,
		["cardStripe"] = v118,
		["portrait"] = v141,
		["portraitScale"] = v143,
		["corners"] = v55,
		["cornerLines"] = v56,
		["rec"] = v79,
		["recDot"] = v88,
		["recText"] = v90,
		["hudCanvas"] = v147,
		["hudScale"] = v151,
		["tag"] = v170,
		["tagName"] = v185,
		["tagTitle"] = v189,
		["tagStripe"] = v179,
		["skip"] = v204,
		["pop"] = v206,
		["popTop"] = v210,
		["popName"] = v214
	}
end
local v_u_218 = {
	["inX"] = 24,
	["inY"] = 20,
	["arm"] = 40,
	["stroke"] = 3,
	["recX"] = 35,
	["recY"] = 48
}
local function v_u_251(p219) -- name: applyScale
	-- upvalues: (copy) v_u_5, (copy) v_u_218
	local v220 = v_u_5.CurrentCamera
	local v221
	if v220 then
		v221 = v220.ViewportSize
	else
		v221 = Vector2.new(1600, 900)
	end
	local v222 = v221.Y
	local v223
	if v222 < 560 then
		local v224 = v222 / 620
		v223 = math.clamp(v224, 0.5, 1)
	else
		local v225 = v222 / 900
		v223 = math.clamp(v225, 0.6, 1.4)
	end
	p219.cardScale.Scale = v223
	p219.hudScale.Scale = v223
	p219.hudCanvas.Size = UDim2.fromScale(1 / v223, 1 / v223)
	local v226 = v_u_218
	local v227 = v221.X * 0.0225
	local v228 = math.clamp(v227, 12, 44) + 0.5
	v226.inX = math.floor(v228)
	local v229 = v_u_218
	local v230 = v221.Y * 0.03
	local v231 = math.clamp(v230, 10, 30) + 0.5
	v229.inY = math.floor(v231)
	local v232 = v_u_218
	local v233 = v223 * 50 + 0.5
	v232.arm = math.floor(v233)
	local v234 = v_u_218
	local v235 = v223 * 4 + 0.5
	local v236 = math.floor(v235)
	v234.stroke = math.max(2, v236)
	for v237, v238 in p219.corners do
		v238.Size = UDim2.fromOffset(v_u_218.arm, v_u_218.arm)
		p219.cornerLines[v237 * 2 - 1].Size = UDim2.new(1, 0, 0, v_u_218.stroke)
		p219.cornerLines[v237 * 2].Size = UDim2.new(0, v_u_218.stroke, 1, 0)
	end
	local v239 = v223 * 34 + 0.5
	local v240 = math.floor(v239)
	p219.recDot.Size = UDim2.fromOffset(v240, v240)
	local v241 = p219.recText
	local v242 = v223 * 40 + 0.5
	v241.TextSize = math.floor(v242)
	p219.recText.Size = UDim2.fromOffset(0, v240)
	p219.rec.Size = UDim2.fromOffset(0, v240)
	local v243 = p219.rec:FindFirstChildOfClass("UIListLayout")
	if v243 then
		local v244 = UDim.new
		local v245 = v240 * 0.45 + 0.5
		v243.Padding = v244(0, (math.floor(v245)))
	end
	local v246 = v_u_218
	local v247 = v_u_218.arm * 1.2 - v240 / 2 + 0.5
	v246.recX = math.floor(v247)
	local v248 = v_u_218
	local v249 = v_u_218.arm * 1.2 + 0.5
	v248.recY = math.floor(v249)
	local v250 = v_u_218.arm * 0.5
	p219.tag.Position = UDim2.new(0, (v_u_218.inX + v250) / v223, 1, -(v_u_218.inY + v250) / v223)
	p219.skip.Position = UDim2.new(1, -(v_u_218.inX + v250) / v223, 1, -(v_u_218.inY + v250) / v223)
end
local function v_u_283(p_u_252, p253, p_u_254, p_u_255, p_u_256, p257) -- name: frameTo
	-- upvalues: (copy) v_u_41, (copy) v_u_218, (copy) v_u_3
	for v258, v259 in p_u_252.corners do
		if p_u_255 > 0 then
			local v260 = {}
			local v261 = v_u_41[v258]
			v260.Position = UDim2.new(v261.X, (v261.X == 0 and 1 or -1) * v_u_218.inX * p253, v261.Y, (v261.Y == 0 and 1 or -1) * v_u_218.inY * p253)
			local v262 = Enum.EasingStyle.Quint
			v_u_3:Create(v259, TweenInfo.new(p_u_255, v262 or Enum.EasingStyle.Quint, p_u_256 or Enum.EasingDirection.Out), v260):Play()
		else
			local v263 = v_u_41[v258]
			v259.Position = UDim2.new(v263.X, (v263.X == 0 and 1 or -1) * v_u_218.inX * p253, v263.Y, (v263.Y == 0 and 1 or -1) * v_u_218.inY * p253)
		end
	end
	for _, v264 in p_u_252.cornerLines do
		if p_u_255 > 0 then
			local v265 = p_u_255 * 0.8
			local v266 = {
				["BackgroundTransparency"] = 1 - p_u_254
			}
			local v267 = Enum.EasingStyle.Quad
			v_u_3:Create(v264, TweenInfo.new(v265, v267 or Enum.EasingStyle.Quint, p_u_256 or Enum.EasingDirection.Out), v266):Play()
		else
			v264.BackgroundTransparency = 1 - p_u_254
		end
	end
	local v_u_268 = {
		["TextTransparency"] = 1 - p_u_254,
		["TextStrokeTransparency"] = 1 - p_u_254 * 0.15
	}
	if p_u_255 > 0 then
		local v269 = p_u_252.rec
		local v270 = {
			["Position"] = UDim2.new(1, -(v_u_218.inX * p253 + v_u_218.recX), 0, v_u_218.inY * p253 + v_u_218.recY)
		}
		local v271 = Enum.EasingStyle.Quint
		v_u_3:Create(v269, TweenInfo.new(p_u_255, v271 or Enum.EasingStyle.Quint, p_u_256 or Enum.EasingDirection.Out), v270):Play()
		local function v282() -- name: fadeRec
			-- upvalues: (copy) p_u_252, (copy) p_u_255, (copy) p_u_254, (copy) p_u_256, (ref) v_u_3, (copy) v_u_268
			local v272 = p_u_252.recDot
			local v273 = p_u_255 * 0.7
			local v274 = {
				["BackgroundTransparency"] = 1 - p_u_254
			}
			local v275 = Enum.EasingStyle.Quad
			local v276 = p_u_256
			v_u_3:Create(v272, TweenInfo.new(v273, v275 or Enum.EasingStyle.Quint, v276 or Enum.EasingDirection.Out), v274):Play()
			local v277 = p_u_252.recText
			local v278 = p_u_255 * 0.7
			local v279 = v_u_268
			local v280 = Enum.EasingStyle.Quad
			local v281 = p_u_256
			v_u_3:Create(v277, TweenInfo.new(v278, v280 or Enum.EasingStyle.Quint, v281 or Enum.EasingDirection.Out), v279):Play()
		end
		if p257 and p257 > 0 then
			task.delay(p257, v282)
		else
			v282()
		end
	else
		p_u_252.rec.Position = UDim2.new(1, -(v_u_218.inX * p253 + v_u_218.recX), 0, v_u_218.inY * p253 + v_u_218.recY)
		p_u_252.recDot.BackgroundTransparency = 1 - p_u_254
		p_u_252.recText.TextTransparency = v_u_268.TextTransparency
		p_u_252.recText.TextStrokeTransparency = v_u_268.TextStrokeTransparency
		return
	end
end
local v_u_284 = nil
local function v_u_302(p_u_285, p_u_286) -- name: setPortrait
	-- upvalues: (copy) v_u_302
	for _, v287 in p_u_285.portrait:GetChildren() do
		if not (v287:IsA("WorldModel") or v287:IsA("Camera")) then
			continue
		end
		v287:Destroy()
	end
	if p_u_286 then
		local v288 = p_u_286:FindFirstChild("Head")
		if v288 and v288:IsA("BasePart") then
			if not pcall(function()
				-- upvalues: (copy) p_u_286, (copy) p_u_285
				local v289 = Instance.new("WorldModel")
				local v290 = p_u_286:Clone()
				for _, v291 in v290:GetDescendants() do
					if not (v291:IsA("Tool") or v291:IsA("Highlight")) then
						continue
					end
					v291:Destroy()
				end
				local v292 = v290:FindFirstChild("HumanoidRootPart")
				if v292 and v292:IsA("BasePart") then
					v290.PrimaryPart = v292
				end
				v290:PivotTo(CFrame.new(0, 0, 0))
				v290.Parent = v289
				v289.Parent = p_u_285.portrait
				local v293 = v290:FindFirstChild("Head")
				local v294 = v293.Position
				local v295 = v293.CFrame.LookVector
				local v296 = v295.X
				local v297 = v295.Z
				local v298 = Vector3.new(v296, 0, v297)
				local v299 = v298.Magnitude <= 0.2 and Vector3.new(0, 0, -1) or v298.Unit
				local v300 = v299:Cross(Vector3.new(0, 1, 0))
				local v301 = Instance.new("Camera")
				v301.FieldOfView = 30
				v301.CFrame = CFrame.lookAt(v294 + v299 * 4 + v300 * 0.9 + Vector3.new(0, 0.3, 0), v294 + Vector3.new(0, -0.25, 0))
				v301.Parent = p_u_285.portrait
				p_u_285.portrait.CurrentCamera = v301
			end) then
				v_u_302(p_u_285, nil)
			end
		end
	else
		return
	end
end
local v_u_303 = nil
local v_u_304 = nil
local v_u_305 = 0
function v_u_6.ShowIntro(p306) -- name: ShowIntro
	-- upvalues: (ref) v_u_38, (copy) v_u_217, (copy) v_u_251, (copy) v_u_2, (copy) v_u_18, (copy) v_u_302, (copy) v_u_16, (copy) v_u_3
	if not v_u_38 then
		v_u_38 = v_u_217()
	end
	local v_u_307 = v_u_38
	v_u_251(v_u_307)
	v_u_307.gui.Enabled = true
	v_u_307.hud.Enabled = false
	v_u_307.cover.Visible = true
	v_u_307.cover.BackgroundTransparency = 0
	v_u_307.card.Visible = true
	v_u_307.frame.Enabled = false
	local v_u_308 = string.upper(p306.name)
	local v_u_309 = 104
	local function v310()
		-- upvalues: (ref) v_u_2, (copy) v_u_308, (copy) v_u_309
		return v_u_2:GetTextSize(v_u_308, v_u_309, Enum.Font.BuilderSansExtraBold, Vector2.new(4000, 400))
	end
	local v311, v312 = pcall(v310)
	local v313
	if v311 then
		v313 = v312.X * 1.06
	else
		v313 = #v_u_308 * v_u_309 * 0.62
	end
	if v313 > 940 then
		local v314 = v_u_309 * 940 / v313
		local v315 = math.floor(v314)
		v_u_309 = math.max(48, v315)
		local function v316()
			-- upvalues: (ref) v_u_2, (copy) v_u_308, (copy) v_u_309
			return v_u_2:GetTextSize(v_u_308, v_u_309, Enum.Font.BuilderSansExtraBold, Vector2.new(4000, 400))
		end
		local v317, v318 = pcall(v316)
		if v317 then
			v313 = v318.X * 1.06
		else
			v313 = #v_u_308 * v_u_309 * 0.62
		end
	end
	v_u_307.cardName.TextSize = v_u_309
	v_u_307.cardName.Text = v_u_308
	v_u_307.cardTitle.Text = p306.title
	local v319 = v_u_307.card
	local v320 = UDim2.fromOffset
	local v_u_321 = p306.title
	local v_u_322 = 30
	local function v323()
		-- upvalues: (ref) v_u_2, (copy) v_u_321, (copy) v_u_322
		return v_u_2:GetTextSize(v_u_321, v_u_322, Enum.Font.BuilderSansExtraBold, Vector2.new(4000, 400))
	end
	local v324, v325 = pcall(v323)
	local v326
	if v324 then
		v326 = v325.X * 1.06
	else
		v326 = #v_u_321 * 30 * 0.62
	end
	local v327 = v326 * 0.85
	v319.Size = v320(math.max(v313, v327, 440) + 222, 260)
	local v328 = v_u_307.cardStripe
	local v329
	if p306.ally then
		v329 = v_u_18.Ally
	else
		v329 = v_u_18.Enemy
	end
	v328.BackgroundColor3 = v329
	v_u_302(v_u_307, p306.portrait)
	v_u_307.cardLabel.TextTransparency = 1
	v_u_307.cardLabel.Position = UDim2.fromOffset(166, 8)
	v_u_307.cardBar.Size = UDim2.fromOffset(0, 5)
	v_u_307.cardName.TextTransparency = 1
	v_u_307.cardName.Position = UDim2.fromOffset(222, 84)
	v_u_307.cardTitle.TextTransparency = 1
	v_u_307.cardStripe.Size = UDim2.fromOffset(6, 0)
	v_u_307.portrait.ImageTransparency = 1
	v_u_307.portrait.BackgroundTransparency = 1
	v_u_307.portraitScale.Scale = 0.82
	local v330 = v_u_307.portrait:FindFirstChildOfClass("UIStroke")
	if v330 then
		v330.Transparency = 0.82
	end
	task.delay(0.05, function()
		-- upvalues: (ref) v_u_16, (copy) v_u_307, (ref) v_u_3
		v_u_16("UI/Whoosh")
		local v331 = v_u_307.cardLabel
		local v332 = {
			["TextTransparency"] = 0,
			["Position"] = nil,
			["Position"] = UDim2.fromOffset(196, 8)
		}
		v_u_3:Create(v331, TweenInfo.new(0.35, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), v332):Play()
		local v333 = v_u_307.cardBar
		local v334 = {
			["Size"] = UDim2.fromOffset(150, 5)
		}
		v_u_3:Create(v333, TweenInfo.new(0.45, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), v334):Play()
	end)
	task.delay(0.18, function()
		-- upvalues: (copy) v_u_307, (ref) v_u_3
		v_u_3:Create(v_u_307.portrait, TweenInfo.new(0.3, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			["ImageTransparency"] = 0,
			["BackgroundTransparency"] = 0
		}):Play()
		local v335 = v_u_307.portraitScale
		local v336 = Enum.EasingStyle.Back
		v_u_3:Create(v335, TweenInfo.new(0.4, v336 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			["Scale"] = 1
		}):Play()
		local v337 = v_u_307.cardStripe
		local v338 = {
			["Size"] = UDim2.fromOffset(6, 104)
		}
		v_u_3:Create(v337, TweenInfo.new(0.35, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), v338):Play()
	end)
	task.delay(0.26, function()
		-- upvalues: (copy) v_u_307, (ref) v_u_3
		local v339 = v_u_307.cardName
		local v340 = {
			["TextTransparency"] = 0,
			["Position"] = nil,
			["Position"] = UDim2.fromOffset(222, 60)
		}
		v_u_3:Create(v339, TweenInfo.new(0.42, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), v340):Play()
	end)
	task.delay(0.5, function()
		-- upvalues: (copy) v_u_307, (ref) v_u_3
		v_u_3:Create(v_u_307.cardTitle, TweenInfo.new(0.4, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			["TextTransparency"] = 0
		}):Play()
	end)
	v_u_307.tagName.Text = string.upper(p306.name)
	v_u_307.tagTitle.Text = p306.title
	local v341 = v_u_307.tagStripe
	local v342
	if p306.ally then
		v342 = v_u_18.Ally
	else
		v342 = v_u_18.Enemy
	end
	v341.BackgroundColor3 = v342
end
function v_u_6.Reveal() -- name: Reveal
	-- upvalues: (ref) v_u_38, (copy) v_u_217, (copy) v_u_251, (copy) v_u_41, (copy) v_u_218, (copy) v_u_283, (ref) v_u_284, (copy) v_u_40, (copy) v_u_5, (copy) v_u_39, (copy) v_u_3, (copy) v_u_16
	if not v_u_38 then
		v_u_38 = v_u_217()
	end
	local v_u_343 = v_u_38
	v_u_251(v_u_343)
	v_u_343.frame.Enabled = true
	local _ = Enum.EasingDirection.Out
	for v344, v345 in v_u_343.corners do
		local v346 = v_u_41[v344]
		v345.Position = UDim2.new(v346.X, (v346.X == 0 and 1 or -1) * v_u_218.inX * 0, v346.Y, (v346.Y == 0 and 1 or -1) * v_u_218.inY * 0)
	end
	for _, v347 in v_u_343.cornerLines do
		v347.BackgroundTransparency = 1
	end
	local v348 = {
		["TextTransparency"] = 1,
		["TextStrokeTransparency"] = 1
	}
	v_u_343.rec.Position = UDim2.new(1, -(v_u_218.inX * 0 + v_u_218.recX), 0, v_u_218.inY * 0 + v_u_218.recY)
	v_u_343.recDot.BackgroundTransparency = 1
	v_u_343.recText.TextTransparency = v348.TextTransparency
	v_u_343.recText.TextStrokeTransparency = v348.TextStrokeTransparency
	v_u_283(v_u_343, 1, 1, 0.4, Enum.EasingDirection.Out, 0.08)
	local v349 = v_u_284
	if not v349 then
		v349 = Instance.new("ColorCorrectionEffect")
		v349.Name = "TR_ReplayGrade"
		for v350, v351 in v_u_40 do
			v349[v350] = v351
		end
		v_u_284 = v349
	end
	local v352 = v_u_5.CurrentCamera
	if v352 and v349.Parent ~= v352 then
		v349.Parent = v352
	end
	local v353 = v_u_39
	local v354 = Enum.EasingStyle.Quad
	v_u_3:Create(v349, TweenInfo.new(0.4, v354 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out), v353):Play()
	local v355 = v_u_343.card
	local v356 = {
		["Position"] = UDim2.new(0.5, -60, 0.5, 0)
	}
	local v357 = Enum.EasingStyle.Quad
	local v358 = Enum.EasingDirection.In
	v_u_3:Create(v355, TweenInfo.new(0.3, v357 or Enum.EasingStyle.Quint, v358 or Enum.EasingDirection.Out), v356):Play()
	for _, v359 in { v_u_343.cardLabel, v_u_343.cardName, v_u_343.cardTitle } do
		v_u_3:Create(v359, TweenInfo.new(0.25, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			["TextTransparency"] = 1
		}):Play()
	end
	v_u_3:Create(v_u_343.portrait, TweenInfo.new(0.25, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
		["ImageTransparency"] = 1,
		["BackgroundTransparency"] = 1
	}):Play()
	local v360 = v_u_343.portrait:FindFirstChildOfClass("UIStroke")
	if v360 then
		v_u_3:Create(v360, TweenInfo.new(0.2, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			["Transparency"] = 1
		}):Play()
	end
	v_u_3:Create(v_u_343.cardBar, TweenInfo.new(0.25, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
		["BackgroundTransparency"] = 1
	}):Play()
	v_u_3:Create(v_u_343.cardStripe, TweenInfo.new(0.25, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
		["BackgroundTransparency"] = 1
	}):Play()
	local v361 = v_u_343.cover
	local v362 = Enum.EasingStyle.Quad
	v_u_3:Create(v361, TweenInfo.new(0.45, v362 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
		["BackgroundTransparency"] = 1
	}):Play()
	v_u_16("UI/Whoosh")
	task.delay(0.46, function()
		-- upvalues: (copy) v_u_343
		if v_u_343.cover.BackgroundTransparency >= 0.99 then
			v_u_343.card.Visible = false
			v_u_343.card.Position = UDim2.fromScale(0.5, 0.5)
			v_u_343.cardBar.BackgroundTransparency = 0
			v_u_343.cardStripe.BackgroundTransparency = 0
		end
	end)
	v_u_343.hud.Enabled = true
	v_u_343.tag.BackgroundTransparency = 1
	v_u_3:Create(v_u_343.tag, TweenInfo.new(0.4, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
		["BackgroundTransparency"] = 0.12
	}):Play()
end
function v_u_6.Kill(p363, p364, p365) -- name: Kill
	-- upvalues: (ref) v_u_38, (copy) v_u_217, (ref) v_u_305, (copy) v_u_18, (copy) v_u_3
	if not v_u_38 then
		v_u_38 = v_u_217()
	end
	local v_u_366 = v_u_38
	v_u_305 = v_u_305 + 1
	local v_u_367 = v_u_305
	local v368 = p364 >= 3 and "TRIPLE ELIMINATION" or (p364 == 2 and "DOUBLE ELIMINATION" or "ELIMINATED")
	v_u_366.popTop.Text = v368
	local v369 = v_u_366.popTop
	local v370
	if p364 >= 2 then
		v370 = v_u_18.Gold
	else
		v370 = v_u_18.TextDim
	end
	v369.TextColor3 = v370
	v_u_366.popName.Text = string.upper(p363) .. (p365 and "  \194\183  HEADSHOT" or "")
	v_u_366.pop.Visible = true
	v_u_366.pop.Position = UDim2.new(0.5, 0, 0.22, 14)
	v_u_366.popTop.TextTransparency = 1
	v_u_366.popName.TextTransparency = 1
	local v371 = v_u_366.pop
	local v372 = {
		["Position"] = UDim2.fromScale(0.5, 0.22)
	}
	v_u_3:Create(v371, TweenInfo.new(0.18, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), v372):Play()
	v_u_3:Create(v_u_366.popTop, TweenInfo.new(0.14, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
		["TextTransparency"] = 0
	}):Play()
	v_u_3:Create(v_u_366.popName, TweenInfo.new(0.14, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
		["TextTransparency"] = 0
	}):Play()
	task.delay(1.5, function()
		-- upvalues: (copy) v_u_367, (ref) v_u_305, (copy) v_u_366, (ref) v_u_3
		if v_u_367 == v_u_305 then
			v_u_3:Create(v_u_366.popTop, TweenInfo.new(0.3, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
				["TextTransparency"] = 1
			}):Play()
			v_u_3:Create(v_u_366.popName, TweenInfo.new(0.3, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
				["TextTransparency"] = 1
			}):Play()
			task.delay(0.32, function()
				-- upvalues: (ref) v_u_367, (ref) v_u_305, (ref) v_u_366
				if v_u_367 == v_u_305 then
					v_u_366.pop.Visible = false
				end
			end)
		end
	end)
end
function v_u_6.Outro(p_u_373, p_u_374) -- name: Outro
	-- upvalues: (ref) v_u_38, (copy) v_u_217, (copy) v_u_283, (ref) v_u_284, (copy) v_u_40, (copy) v_u_3
	if not v_u_38 then
		v_u_38 = v_u_217()
	end
	local v_u_375 = v_u_38
	local v376 = p_u_374 * 0.45
	local v_u_377 = math.max(0.15, v376)
	v_u_375.cover.Visible = true
	v_u_375.card.Visible = false
	v_u_283(v_u_375, 0, 0, v_u_377, Enum.EasingDirection.Out)
	if v_u_284 then
		local v378 = v_u_284
		local v379 = v_u_40
		local v380 = Enum.EasingStyle.Quad
		v_u_3:Create(v378, TweenInfo.new(v_u_377, v380 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out), v379):Play()
	end
	local v381 = v_u_375.cover
	local v382 = Enum.EasingStyle.Quad
	local v383 = Enum.EasingDirection.In
	v_u_3:Create(v381, TweenInfo.new(v_u_377, v382 or Enum.EasingStyle.Quint, v383 or Enum.EasingDirection.Out), {
		["BackgroundTransparency"] = 0
	}):Play()
	task.delay(v_u_377 + 0.02, function()
		-- upvalues: (copy) v_u_375, (ref) v_u_284, (copy) p_u_373, (copy) p_u_374, (copy) v_u_377, (ref) v_u_3
		v_u_375.hud.Enabled = false
		v_u_375.frame.Enabled = false
		if v_u_284 then
			v_u_284:Destroy()
			v_u_284 = nil
		end
		local v384 = p_u_373
		pcall(v384)
		local v385 = v_u_375.cover
		local v386 = p_u_374 - v_u_377
		local v387 = math.max(0.15, v386)
		local v388 = Enum.EasingStyle.Quad
		v_u_3:Create(v385, TweenInfo.new(v387, v388 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			["BackgroundTransparency"] = 1
		}):Play()
		local v389 = task.delay
		local v390 = p_u_374 - v_u_377
		v389(math.max(0.15, v390) + 0.02, function()
			-- upvalues: (ref) v_u_375
			if v_u_375.cover.BackgroundTransparency >= 0.99 then
				v_u_375.gui.Enabled = false
			end
		end)
	end)
end
function v_u_6.Hide() -- name: Hide
	-- upvalues: (ref) v_u_38, (ref) v_u_284, (copy) v_u_302
	local v391 = v_u_38
	if v391 then
		v391.gui.Enabled = false
		v391.hud.Enabled = false
		v391.frame.Enabled = false
		if v_u_284 then
			v_u_284:Destroy()
			v_u_284 = nil
		end
		v391.pop.Visible = false
		v_u_302(v391, nil)
	end
end
function v_u_6.BindSkip(p_u_392) -- name: BindSkip
	-- upvalues: (copy) v_u_6, (ref) v_u_38, (copy) v_u_217, (ref) v_u_303, (ref) v_u_304, (copy) v_u_4
	v_u_6.UnbindSkip()
	if not v_u_38 then
		v_u_38 = v_u_217()
	end
	local v393 = v_u_38
	local v_u_394 = os.clock() + 0.5
	v_u_303 = v393.skip.Activated:Connect(function()
		-- upvalues: (copy) v_u_394, (copy) p_u_392
		if v_u_394 <= os.clock() then
			p_u_392()
		end
	end)
	v_u_304 = v_u_4.InputBegan:Connect(function(p395, p396)
		-- upvalues: (copy) v_u_394, (ref) v_u_4, (copy) p_u_392
		if os.clock() >= v_u_394 and not v_u_4:GetFocusedTextBox() then
			if p395.KeyCode == Enum.KeyCode.ButtonB and not p396 then
				p_u_392()
			end
		end
	end)
end
function v_u_6.UnbindSkip() -- name: UnbindSkip
	-- upvalues: (ref) v_u_303, (ref) v_u_304
	if v_u_303 then
		v_u_303:Disconnect()
		v_u_303 = nil
	end
	if v_u_304 then
		v_u_304:Disconnect()
		v_u_304 = nil
	end
end
function v_u_6.DebugFrame(p397) -- name: DebugFrame
	-- upvalues: (ref) v_u_38, (copy) v_u_217, (copy) v_u_251, (copy) v_u_41, (copy) v_u_218, (ref) v_u_284, (copy) v_u_40, (copy) v_u_5, (copy) v_u_39
	if not v_u_38 then
		v_u_38 = v_u_217()
	end
	local v398 = v_u_38
	local v399 = math.clamp(p397 or 1, 0, 1)
	v_u_251(v398)
	v398.frame.Enabled = true
	local _ = Enum.EasingDirection.Out
	for v400, v401 in v398.corners do
		local v402 = v_u_41[v400]
		v401.Position = UDim2.new(v402.X, (v402.X == 0 and 1 or -1) * v_u_218.inX * v399, v402.Y, (v402.Y == 0 and 1 or -1) * v_u_218.inY * v399)
	end
	for _, v403 in v398.cornerLines do
		v403.BackgroundTransparency = 1 - v399
	end
	local v404 = {
		["TextTransparency"] = 1 - v399,
		["TextStrokeTransparency"] = 1 - v399 * 0.15
	}
	v398.rec.Position = UDim2.new(1, -(v_u_218.inX * v399 + v_u_218.recX), 0, v_u_218.inY * v399 + v_u_218.recY)
	v398.recDot.BackgroundTransparency = 1 - v399
	v398.recText.TextTransparency = v404.TextTransparency
	v398.recText.TextStrokeTransparency = v404.TextStrokeTransparency
	local v405 = v_u_284
	if not v405 then
		v405 = Instance.new("ColorCorrectionEffect")
		v405.Name = "TR_ReplayGrade"
		for v406, v407 in v_u_40 do
			v405[v406] = v407
		end
		v_u_284 = v405
	end
	local v408 = v_u_5.CurrentCamera
	if v408 and v405.Parent ~= v408 then
		v405.Parent = v408
	end
	v405.TintColor = v_u_40.TintColor:Lerp(v_u_39.TintColor, v399)
	v405.Saturation = v_u_39.Saturation * v399
	v405.Contrast = v_u_39.Contrast * v399
	return {
		["k"] = v399,
		["inX"] = v_u_218.inX,
		["inY"] = v_u_218.inY,
		["arm"] = v_u_218.arm,
		["stroke"] = v_u_218.stroke,
		["recX"] = v_u_218.recX,
		["recY"] = v_u_218.recY,
		["abs"] = v398.frame.AbsoluteSize
	}
end
function v_u_6.Gui() -- name: Gui
	-- upvalues: (ref) v_u_38
	if v_u_38 then
		return v_u_38.gui
	else
		return nil
	end
end
function v_u_6.HudGui() -- name: HudGui
	-- upvalues: (ref) v_u_38
	if v_u_38 then
		return v_u_38.hud
	else
		return nil
	end
end
return v_u_6