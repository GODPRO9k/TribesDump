local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("UserInputService")
local v5 = v2:WaitForChild("Shared")
local v_u_6 = require(v5:WaitForChild("Net"))
local v_u_7 = require(v5:WaitForChild("Keybinds"))
local v_u_8 = require(v5:WaitForChild("Combat"))
local v_u_9 = require(v5:WaitForChild("Sfx"))
local v_u_10 = require(script.Parent:WaitForChild("Util"))
local v11 = {}
local v_u_12 = v_u_1.LocalPlayer
local v_u_13 = Color3.fromRGB(40, 150, 255)
local v_u_14 = Color3.fromRGB(235, 70, 60)
local v_u_15 = Color3.fromRGB(18, 20, 26)
local v_u_16 = Color3.fromRGB(255, 255, 255)
local v_u_17 = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Heavy)
local v_u_18 = nil
local v_u_19 = {}
local v_u_20 = (-1 / 0)
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = nil
local function v_u_28() -- name: hasHumanTeammate
	-- upvalues: (copy) v_u_12, (copy) v_u_1
	local v24 = v_u_12:GetAttribute("MatchId")
	local v25 = type(v24) ~= "string" and "" or v24
	local v26 = v_u_12:GetAttribute("Team")
	if v25 == "" then
		return false
	end
	for _, v27 in v_u_1:GetPlayers() do
		if v27 == v_u_12 or (v27:GetAttribute("MatchId") ~= v25 or v27:GetAttribute("Team") ~= v26) then
			continue
		end
		return true
	end
	return false
end
local function v_u_39(p29, p30, p31) -- name: show
	-- upvalues: (copy) v_u_19, (copy) v_u_14, (copy) v_u_13, (copy) v_u_15, (copy) v_u_17, (copy) v_u_16, (ref) v_u_22, (copy) v_u_9
	local v32 = v_u_19[p29]
	if v32 then
		v_u_19[p29] = nil
		v32.frame:Destroy()
	end
	local v33
	if p31 == "enemy" then
		v33 = v_u_14
	else
		v33 = v_u_13
	end
	local v34 = Instance.new("Frame")
	v34.Name = "Mark"
	v34.AnchorPoint = Vector2.new(0.5, 0.5)
	v34.Size = UDim2.fromOffset(64, 56)
	v34.BackgroundTransparency = 1
	v34.Visible = false
	local v35 = Instance.new("Frame")
	v35.AnchorPoint = Vector2.new(0.5, 0.5)
	v35.Position = UDim2.new(0.5, 0, 0, 18)
	v35.Size = UDim2.fromOffset(18, 18)
	v35.Rotation = 45
	v35.BackgroundColor3 = v33
	v35.BorderSizePixel = 0
	v35.Parent = v34
	local v36 = Instance.new("UICorner")
	v36.CornerRadius = UDim.new(0, 3)
	v36.Parent = v35
	local v37 = Instance.new("UIStroke")
	v37.Thickness = 2
	v37.Color = v_u_15
	v37.Transparency = 0.2
	v37.Parent = v35
	local v38 = Instance.new("TextLabel")
	v38.BackgroundTransparency = 1
	v38.AnchorPoint = Vector2.new(0.5, 0)
	v38.Position = UDim2.new(0.5, 0, 0, 34)
	v38.Size = UDim2.new(1, 0, 0, 18)
	v38.FontFace = v_u_17
	v38.TextSize = 14
	v38.TextColor3 = v_u_16
	v38.TextStrokeColor3 = v_u_15
	v38.TextStrokeTransparency = 0.3
	v38.Text = ""
	v38.AutoLocalize = false
	v38.Parent = v34
	v34.Parent = v_u_22
	v_u_19[p29] = {
		["position"] = p30 + Vector3.new(0, 1.5, 0),
		["frame"] = v34,
		["diamond"] = v35,
		["stroke"] = v37,
		["label"] = v38,
		["born"] = os.clock()
	}
	v_u_9.PlayUI("Click")
end
local function v_u_53(p40, p41) -- name: place
	local v42 = p41.ViewportSize
	local v43 = p41:WorldToViewportPoint(p40.position)
	local v44 = v43.X
	local v45 = v43.Y
	if v43.Z <= 0 then
		v44 = v42.X - v44
		v45 = v42.Y
	end
	local v46 = v42.X - 44
	local v47 = math.max(44, v46)
	local v48 = v42.Y - 44
	local v49 = math.max(74, v48)
	p40.frame.Position = UDim2.fromOffset(math.clamp(v44, 44, v47), (math.clamp(v45, 74, v49)))
	p40.frame.Visible = true
	local v50 = p40.label
	local v51 = (p41.CFrame.Position - p40.position).Magnitude + 0.5
	local v52 = math.floor(v51)
	v50.Text = tostring(v52)
end
local function v_u_61() -- name: ping
	-- upvalues: (copy) v_u_12, (ref) v_u_20, (copy) v_u_10, (copy) v_u_8, (copy) v_u_39, (ref) v_u_18
	local v54 = os.clock()
	local v55 = v_u_12:GetAttribute("MatchId")
	if (type(v55) ~= "string" and "" or v55) == "" or (v54 - v_u_20 < 0.6 or v_u_10.IsMouseUnlocked()) then
		return
	else
		local v56 = v_u_12.Character
		if v56 then
			v56 = v56:FindFirstChildOfClass("Humanoid")
		end
		if v56 and v56.Health > 0 then
			local v57, v58 = v_u_10.AimPoint(600)
			local v59 = nil
			local v60
			if v58 then
				v60 = v_u_8.FindCharacter(v58.Instance)
				if v60 then
					if not v_u_10.IsEnemy(v60) then
						v60 = v59
					end
				else
					v60 = v59
				end
			else
				v60 = v59
			end
			v_u_20 = v54
			v_u_39(v_u_12.UserId, v57, v60 and "enemy" or "spot")
			if v_u_18 then
				v_u_18:FireServer(v57, v60)
			end
		end
	end
end
local function v_u_68() -- name: buildButton
	-- upvalues: (copy) v_u_15, (copy) v_u_16, (copy) v_u_17, (copy) v_u_61, (copy) v_u_12, (ref) v_u_21, (ref) v_u_23, (ref) v_u_22
	local v62 = Instance.new("ScreenGui")
	v62.Name = "TribesPing"
	v62.ResetOnSpawn = false
	v62.IgnoreGuiInset = true
	v62.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
	v62.DisplayOrder = 5
	local v63 = Instance.new("TextButton")
	v63.Name = "Ping"
	v63.AnchorPoint = Vector2.new(1, 0.5)
	v63.Position = UDim2.new(1, -22, 0.3, 0)
	v63.Size = UDim2.fromOffset(48, 48)
	v63.BackgroundColor3 = v_u_15
	v63.BackgroundTransparency = 0.3
	v63.AutoButtonColor = false
	v63.Text = "PING"
	v63.TextColor3 = v_u_16
	v63.TextSize = 12
	v63.FontFace = v_u_17
	v63.Visible = false
	local v64 = Instance.new("UICorner")
	v64.CornerRadius = UDim.new(1, 0)
	v64.Parent = v63
	local v65 = Instance.new("UIStroke")
	v65.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v65.Thickness = 2
	v65.Color = v_u_16
	v65.Transparency = 0.8
	v65.Parent = v63
	v63.InputBegan:Connect(function(p66)
		-- upvalues: (ref) v_u_61
		if p66.UserInputType == Enum.UserInputType.Touch or p66.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_61()
		end
	end)
	v63.Parent = v62
	v62.Parent = v_u_12:WaitForChild("PlayerGui")
	v_u_21 = v62
	v_u_23 = v63
	local v67 = Instance.new("ScreenGui")
	v67.Name = "TribesPingMarks"
	v67.ResetOnSpawn = false
	v67.IgnoreGuiInset = true
	v67.ScreenInsets = Enum.ScreenInsets.None
	v67.DisplayOrder = 4
	v67.Parent = v_u_12:WaitForChild("PlayerGui")
	v_u_22 = v67
end
function v11.Start() -- name: Start
	-- upvalues: (ref) v_u_18, (copy) v_u_6, (copy) v_u_68, (copy) v_u_12, (copy) v_u_39, (copy) v_u_7, (copy) v_u_61, (copy) v_u_3, (ref) v_u_23, (copy) v_u_4, (copy) v_u_28, (copy) v_u_10, (copy) v_u_19, (copy) v_u_53
	v_u_18 = v_u_6.Event("Ping")
	v_u_68()
	v_u_18.OnClientEvent:Connect(function(p69, p70, p71)
		-- upvalues: (ref) v_u_12, (ref) v_u_39
		if type(p69) == "number" and typeof(p70) == "Vector3" then
			local v72 = v_u_12:GetAttribute("MatchId")
			if (type(v72) ~= "string" and "" or v72) ~= "" then
				v_u_39(p69, p70, p71 == "enemy" and "enemy" or "spot")
			end
		end
	end)
	v_u_7.OnInput("Began", function(p73, p74)
		-- upvalues: (ref) v_u_7, (ref) v_u_61
		if not p74 then
			if v_u_7.ActionOf(p73) == "Ping" or v_u_7.IsPad(p73, "Ping") and not v_u_7.PadBlocked() then
				v_u_61()
			end
		end
	end)
	local v_u_75 = 0
	v_u_3.RenderStepped:Connect(function()
		-- upvalues: (ref) v_u_75, (ref) v_u_23, (ref) v_u_4, (ref) v_u_28, (ref) v_u_10, (ref) v_u_12, (ref) v_u_19, (ref) v_u_53
		local v76 = os.clock()
		if v_u_75 <= v76 then
			v_u_75 = v76 + 0.25
			local v77 = v_u_23
			if v77 then
				local v78 = v_u_4.PreferredInput == Enum.PreferredInput.Touch and (v_u_28() and not v_u_10.IsMouseUnlocked())
				if v78 then
					v78 = v_u_12:GetAttribute("Alive") ~= false
				end
				v77.Visible = v78
			end
			local v79 = v_u_12:GetAttribute("MatchId")
			if (type(v79) ~= "string" and "" or v79) == "" then
				for v80 in v_u_19 do
					local v81 = v_u_19[v80]
					if not v81 then
						continue
					end
					v_u_19[v80] = nil
					v81.frame:Destroy()
				end
			end
		end
		local v82 = workspace.CurrentCamera
		for v83, v84 in v_u_19 do
			local v85 = v76 - v84.born
			if v85 >= 6 then
				local v86 = v_u_19[v83]
				if not v86 then
					continue
				end
				v_u_19[v83] = nil
				v86.frame:Destroy()
			else
				local v87 = (v85 - 5) / 1
				local v88 = math.clamp(v87, 0, 1)
				v84.diamond.BackgroundTransparency = v88
				v84.stroke.Transparency = v88 * 0.8 + 0.2
				v84.label.TextTransparency = v88
				v84.label.TextStrokeTransparency = v88 * 0.7 + 0.3
				if not v82 then
					continue
				end
				v_u_53(v84, v82)
			end
		end
	end)
end
return v11