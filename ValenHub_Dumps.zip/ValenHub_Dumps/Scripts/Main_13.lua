local v1 = game:GetService("ReplicatedStorage")
require(v1:WaitForChild("Shared"):WaitForChild("Camera"))
local v_u_2 = {
	"Quality",
	"Movement",
	"TouchControls",
	"Procedural",
	"Footsteps",
	"RemoteAnimate",
	"ResetButton",
	"ViewModel"
}
local v_u_3 = {}
for _, v_u_4 in v_u_2 do
	task.spawn(function()
		-- upvalues: (copy) v_u_4, (copy) v_u_3
		local v5 = os.clock()
		local function v6()
			-- upvalues: (ref) v_u_4
			require((script.Parent:WaitForChild(v_u_4, 10))).Start()
		end
		local v7, v8 = pcall(v6)
		if v7 then
			v_u_3[v_u_4] = (os.clock() - v5) * 1000
		else
			warn((("[Character] %* failed to start: %*"):format(v_u_4, v8)))
			v_u_3[v_u_4] = -1
		end
	end)
end
task.delay(5, function()
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v9 = {}
	for _, v10 in v_u_2 do
		local v11 = v_u_3[v10]
		local v12
		if v11 == nil then
			v12 = ("%* STILL STARTING"):format(v10)
		elseif v11 < 0 then
			v12 = ("%* FAILED"):format(v10)
		else
			v12 = string.format("%s %.1f", v10, v11)
		end
		table.insert(v9, v12)
	end
	local v13 = "[Character] started (ms): " .. table.concat(v9, ", ")
	for _, v14 in v_u_2 do
		if v_u_3[v14] ~= nil and v_u_3[v14] >= 0 then
			continue
		end
		warn(v13)
		return
	end
	print(v13)
end)