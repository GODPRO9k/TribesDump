local v1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_6 = v2.LocalPlayer
local v_u_7 = Random.new()
local v_u_8 = {}
local function v42(p_u_9) -- name: setup
	-- upvalues: (copy) v_u_8, (copy) v_u_7
	if p_u_9:IsA("Model") and not v_u_8[p_u_9] then
		local v_u_10 = {
			["model"] = nil,
			["root"] = nil,
			["idle"] = nil,
			["wave"] = nil,
			["cheer"] = nil,
			["greetedAt"] = (-1 / 0),
			["nextEmote"] = nil,
			["alive"] = true,
			["plate"] = nil,
			["plateShown"] = false,
			["plateAlpha"] = nil,
			["model"] = p_u_9,
			["nextEmote"] = os.clock() + v_u_7:NextNumber(6, 16)
		}
		v_u_8[p_u_9] = v_u_10
		task.spawn(function()
			-- upvalues: (copy) p_u_9, (copy) v_u_10, (ref) v_u_7
			local v_u_11 = p_u_9:WaitForChild("Humanoid", 10)
			if v_u_11 then
				v_u_11 = v_u_11:WaitForChild("Animator", 10)
			end
			if v_u_10.alive and (v_u_11 and v_u_11:IsA("Animator")) then
				v_u_10.root = p_u_9.PrimaryPart or p_u_9:FindFirstChild("HumanoidRootPart")
				local v12 = p_u_9:GetAttribute("IdleAnim")
				local v_u_13 = (type(v12) ~= "string" or v12 == "") and "rbxassetid://507766388" or v12
				local v14 = Enum.AnimationPriority.Idle
				local v18, v_u_19 = pcall(function()
					-- upvalues: (copy) v_u_11, (copy) v_u_13
					local v15 = v_u_11
					local v16 = v_u_13
					local v17 = Instance.new("Animation")
					v17.AnimationId = v16
					return v15:LoadAnimation(v17)
				end)
				if v18 and v_u_19 then
					v_u_19.Priority = v14
					v_u_19.Looped = true
				else
					v_u_19 = nil
				end
				if not v_u_19 then
					local v20 = Enum.AnimationPriority.Idle
					local v_u_21 = "rbxassetid://507766388"
					local v22
					v22, v_u_19 = pcall(function()
						-- upvalues: (copy) v_u_11, (copy) v_u_21
						local v23 = v_u_11
						local v24 = v_u_21
						local v25 = Instance.new("Animation")
						v25.AnimationId = v24
						return v23:LoadAnimation(v25)
					end)
					if v22 and v_u_19 then
						v_u_19.Priority = v20
						v_u_19.Looped = true
					else
						v_u_19 = nil
					end
				end
				local v26 = v_u_10
				local v27 = Enum.AnimationPriority.Action
				local v_u_28 = "rbxassetid://507770239"
				local v32, v33 = pcall(function()
					-- upvalues: (copy) v_u_11, (copy) v_u_28
					local v29 = v_u_11
					local v30 = v_u_28
					local v31 = Instance.new("Animation")
					v31.AnimationId = v30
					return v29:LoadAnimation(v31)
				end)
				if v32 and v33 then
					v33.Priority = v27
					v33.Looped = false
				else
					v33 = nil
				end
				v26.wave = v33
				local v34 = v_u_10
				local v35 = Enum.AnimationPriority.Action
				local v_u_36 = "rbxassetid://507770677"
				local v40, v41 = pcall(function()
					-- upvalues: (copy) v_u_11, (copy) v_u_36
					local v37 = v_u_11
					local v38 = v_u_36
					local v39 = Instance.new("Animation")
					v39.AnimationId = v38
					return v37:LoadAnimation(v39)
				end)
				if v40 and v41 then
					v41.Priority = v35
					v41.Looped = false
				else
					v41 = nil
				end
				v34.cheer = v41
				if v_u_10.alive then
					v_u_10.idle = v_u_19
					if v_u_19 then
						v_u_19:Play(0.4, 1, v_u_7:NextNumber(0.85, 1))
						task.delay(0.2, function()
							-- upvalues: (ref) v_u_10, (copy) v_u_19, (ref) v_u_7
							if v_u_10.alive and v_u_19.Length > 0 then
								v_u_19.TimePosition = v_u_7:NextNumber(0, v_u_19.Length)
							end
						end)
					end
				end
			else
				return
			end
		end)
	end
end
local v_u_43 = { 18, 34 }
local function v_u_45(p44) -- name: emote
	if p44 and not p44.IsPlaying then
		p44:Play(0.3, 1, 1)
	end
end
local function v_u_49(p46) -- name: teardown
	-- upvalues: (copy) v_u_8
	local v47 = v_u_8[p46]
	if v47 then
		v47.alive = false
		v_u_8[p46] = nil
		if v47.plateAlpha then
			v47.plateAlpha:Destroy()
		end
		for _, v48 in { v47.idle, v47.wave, v47.cheer } do
			if not v48 then
				continue
			end
			v48:Stop(0)
			v48:Destroy()
		end
	end
end
for _, v50 in v1:GetTagged("HallOfFameChampion") do
	v42(v50)
end
v1:GetInstanceAddedSignal("HallOfFameChampion"):Connect(v42)
v1:GetInstanceRemovedSignal("HallOfFameChampion"):Connect(function(p51)
	-- upvalues: (copy) v_u_49
	if p51:IsA("Model") then
		v_u_49(p51)
	end
end)
local function v_u_63(p52, p_u_53, p54) -- name: bindPlate
	if p52.plateAlpha then
		p52.plateAlpha:Destroy()
	end
	local v_u_55 = {}
	for _, v56 in p_u_53:GetDescendants() do
		if not v56:IsA("GuiObject") then
			continue
		end
		local v57 = {
			["gui"] = v56,
			["bg"] = v56.BackgroundTransparency
		}
		local v58
		if v56:IsA("TextLabel") then
			v58 = v56.TextTransparency
		else
			v58 = nil
		end
		v57.text = v58
		table.insert(v_u_55, v57)
	end
	local v59 = Instance.new("NumberValue")
	local function v62(p60) -- name: apply
		-- upvalues: (copy) v_u_55, (copy) p_u_53
		for _, v61 in v_u_55 do
			v61.gui.BackgroundTransparency = v61.bg + (1 - v61.bg) * p60
			if not v61.text then
				continue
			end
			v61.gui.TextTransparency = v61.text + (1 - v61.text) * p60
		end
		p_u_53.Enabled = p60 < 0.99
	end
	v59.Changed:Connect(v62)
	v59.Value = p54 and 0 or 1
	v62(v59.Value)
	p52.plate = p_u_53
	p52.plateShown = p54
	p52.plateAlpha = v59
end
local function v_u_70(p64, p65, p66) -- name: updatePlate
	-- upvalues: (copy) v_u_63, (copy) v_u_3, (copy) v_u_5
	local v67 = p65:FindFirstChild("Nameplate")
	if v67 and v67:IsA("BillboardGui") then
		local v68 = (p65.Position - p66).Magnitude
		if v67 == p64.plate then
			local v69
			if p64.plateShown then
				v69 = v68 <= 31
			else
				v69 = v68 <= 27
			end
			if v69 ~= p64.plateShown and p64.plateAlpha then
				p64.plateShown = v69
				v_u_3:Create(p64.plateAlpha, v_u_5, {
					["Value"] = v69 and 0 or 1
				}):Play()
			end
		else
			v_u_63(p64, v67, v68 <= 27)
		end
	else
		p64.plate = nil
		return
	end
end
task.spawn(function()
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_8, (copy) v_u_49, (copy) v_u_70, (copy) v_u_7, (copy) v_u_43, (copy) v_u_45
	while true do
		task.wait(0.25)
		local v71 = v_u_4.CurrentCamera
		local v72 = v_u_6.Character
		if v72 then
			v72 = v72:FindFirstChild("HumanoidRootPart")
		end
		local v73 = os.clock()
		for v74, v75 in v_u_8 do
			if v74.Parent then
				local v76 = v75.root or v74.PrimaryPart
				if v76 and v71 then
					v_u_70(v75, v76, v71.CFrame.Position)
				end
				if not (v76 and (v75.idle and v72)) then
					continue
				end
				local v77 = (v76.Position - v72.Position).Magnitude
				if v77 <= 22 and v73 - v75.greetedAt > 40 then
					v75.greetedAt = v73
					v75.nextEmote = v73 + v_u_7:NextNumber(v_u_43[1], v_u_43[2])
					task.delay(v_u_7:NextNumber(0, 0.7), v_u_45, v75.wave)
				else
					if v77 > 90 or v75.nextEmote > v73 then
						continue
					end
					v75.nextEmote = v73 + v_u_7:NextNumber(v_u_43[1], v_u_43[2])
					local v78
					if v74:GetAttribute("Rank") == 1 and v_u_7:NextNumber() < 0.6 then
						v78 = v75.cheer
					else
						v78 = v75.wave
					end
					if not v78 then
						continue
					end
					if v78.IsPlaying then
						continue
					end
					v78:Play(0.3, 1, 1)
				end
			else
				v_u_49(v74)
			end
		end
	end
end)