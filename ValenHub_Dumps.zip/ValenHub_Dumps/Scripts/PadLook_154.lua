local v_u_1 = {
	["MAX_RATE"] = 4.363323129985824,
	["PITCH"] = 0.75,
	["DEADZONE"] = 0.15,
	["BOOST"] = 1.6,
	["BOOST_AT"] = 0.92,
	["BOOST_DELAY"] = 0.12,
	["BOOST_RAMP"] = 0.3,
	["BOOST_FALL"] = 0.1
}
local v_u_2 = 1
local v_u_3 = false
local v_u_4 = 0
local v_u_5 = 0
function v_u_1.SetSensitivity(p6) -- name: SetSensitivity
	-- upvalues: (ref) v_u_2
	if type(p6) == "number" and p6 == p6 then
		v_u_2 = math.clamp(p6, 0.1, 5)
	end
end
function v_u_1.GetSensitivity() -- name: GetSensitivity
	-- upvalues: (ref) v_u_2
	return v_u_2
end
function v_u_1.SetInvertY(p7) -- name: SetInvertY
	-- upvalues: (ref) v_u_3
	v_u_3 = p7 == true
end
local v_u_8 = false
local v_u_9 = (-1 / 0)
function v_u_1.IsInverted() -- name: IsInverted
	-- upvalues: (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
	local v10 = os.clock()
	if v10 - v_u_9 > 2 then
		v_u_9 = v10
		local v11, v12 = pcall(function()
			return UserSettings():GetService("UserGameSettings"):GetCameraYInvertValue()
		end)
		if v11 then
			v11 = v12 == -1
		end
		v_u_8 = v11
	end
	return v_u_3 or v_u_8
end
function v_u_1.Step(p13, p14, p15) -- name: Step
	-- upvalues: (copy) v_u_1, (ref) v_u_4, (ref) v_u_5, (ref) v_u_2, (ref) v_u_9, (ref) v_u_8, (ref) v_u_3
	local v16 = p13.Magnitude
	if v16 <= v_u_1.DEADZONE then
		v_u_4 = 0
		v_u_5 = 0
		return 0, 0
	end
	local v17 = (math.min(v16, 1) - v_u_1.DEADZONE) / (1 - v_u_1.DEADZONE)
	local v18 = v17 * v17 * 0.6 + v17 * 0.4
	if v_u_1.BOOST_AT <= v16 and not p15 then
		v_u_4 = v_u_4 + p14
		if v_u_4 >= v_u_1.BOOST_DELAY then
			local v19 = v_u_5 + p14 / v_u_1.BOOST_RAMP
			v_u_5 = math.min(1, v19)
		end
	else
		v_u_4 = 0
		local v20 = v_u_5 - p14 / v_u_1.BOOST_FALL
		v_u_5 = math.max(0, v20)
	end
	local v21 = v_u_1.MAX_RATE * v18 * (1 + (v_u_1.BOOST - 1) * v_u_5) * v_u_2 * p14
	local v22 = p13 / v16
	local v23 = -v22.X * v21
	local v24 = v22.Y * v21 * v_u_1.PITCH
	local v25 = os.clock()
	if v25 - v_u_9 > 2 then
		v_u_9 = v25
		local v26, v27 = pcall(function()
			return UserSettings():GetService("UserGameSettings"):GetCameraYInvertValue()
		end)
		if v26 then
			v26 = v27 == -1
		end
		v_u_8 = v26
	end
	return v23, v24 * ((v_u_3 or v_u_8) and -1 or 1)
end
function v_u_1.Boost() -- name: Boost
	-- upvalues: (ref) v_u_5
	return v_u_5
end
return v_u_1