local v_u_1 = game:GetService("ContextActionService")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("Players")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = require(v4.Shared.Ranks)
local v_u_7 = require(script.Parent.Parent.RankArt)
local v_u_8 = require(script.Parent.Parent.Fx)
return {
	["Init"] = function(p_u_9) -- name: Init
		-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_8, (copy) v_u_7, (copy) v_u_2, (copy) v_u_6, (copy) v_u_1
		local v_u_10 = p_u_9.UI
		local v_u_11 = p_u_9.Theme
		local v_u_12 = p_u_9.State
		local v_u_13 = v_u_11.Colors
		local v_u_14 = v_u_11.Fonts
		local v_u_15 = v_u_3.LocalPlayer
		local v_u_16 = v_u_10.Assets
		local v_u_17 = nil
		local v_u_18 = nil
		local v_u_19 = 0
		local function v_u_33() -- name: build
			-- upvalues: (ref) v_u_17, (copy) v_u_10, (copy) p_u_9, (copy) v_u_13, (copy) v_u_16, (ref) v_u_8, (ref) v_u_7, (copy) v_u_14, (copy) v_u_11
			if not v_u_17 then
				local v20, v21 = v_u_10.Screen("TR_RankUp", 31, p_u_9.PlayerGui, {
					["fullBleed"] = true
				})
				v_u_17 = {
					["sg"] = v20,
					["canvas"] = v21
				}
				local v22 = v_u_10.new("Frame", {
					["Name"] = "Root",
					["Size"] = nil,
					["Visible"] = false,
					["Parent"] = nil,
					["Size"] = UDim2.fromScale(1, 1),
					["Parent"] = v21
				})
				v_u_17.root = v22
				v_u_17.dim = v_u_10.new("Frame", {
					["Name"] = "Dim",
					["Size"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 1,
					["ZIndex"] = 1,
					["Parent"] = nil,
					["Size"] = UDim2.fromScale(1, 1),
					["BackgroundColor3"] = v_u_13.Void,
					["Parent"] = v22
				})
				local v23 = v_u_10.new("Frame", {
					["Name"] = "Stage",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 2,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Size"] = UDim2.fromOffset(1600, 900),
					["Parent"] = v22
				})
				local v_u_24 = v_u_10.new("UIScale", {
					["Scale"] = 1,
					["Parent"] = nil,
					["Parent"] = v23
				})
				local function v29() -- name: fit
					-- upvalues: (ref) v_u_10, (copy) v_u_24
					local v25 = v_u_10.CanvasSize()
					local v26 = v_u_24
					local v27 = v25.X / 1600
					local v28 = v25.Y / 900
					v26.Scale = math.min(1, v27, v28)
				end
				local v30 = v_u_10.CanvasSize()
				local v31 = v30.X / 1600
				local v32 = v30.Y / 900
				v_u_24.Scale = math.min(1, v31, v32)
				v_u_10.ScaleChanged:Connect(v29)
				v_u_10.LayoutChanged:Connect(v29)
				v_u_17.stage = v23
				v_u_17.glow = v_u_10.Image(v_u_16.Icons.Glow, {
					["Name"] = "Glow",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ImageTransparency"] = 1,
					["ZIndex"] = 2,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.385),
					["Size"] = UDim2.fromOffset(1100, 1100),
					["Parent"] = v_u_17.stage
				})
				v_u_17.rays = v_u_10.Image(v_u_16.Fx.Rays, {
					["Name"] = "Rays",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ImageTransparency"] = 1,
					["ZIndex"] = 3,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.385),
					["Size"] = UDim2.fromOffset(820, 820),
					["Parent"] = v_u_17.stage
				})
				v_u_17.raysThin = v_u_10.Image(v_u_16.Fx.RaysThin, {
					["Name"] = "RaysThin",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ImageTransparency"] = 1,
					["ZIndex"] = 3,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.385),
					["Size"] = UDim2.fromOffset(980, 980),
					["Parent"] = v_u_17.stage
				})
				v_u_17.ring = v_u_10.Image(v_u_16.Fx.Ring, {
					["Name"] = "Ring",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ImageTransparency"] = 1,
					["ZIndex"] = 4,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.385),
					["Size"] = UDim2.fromOffset(200, 200),
					["Parent"] = v_u_17.stage
				})
				v_u_17.flash = v_u_10.new("Frame", {
					["Name"] = "Flash",
					["Size"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 1,
					["ZIndex"] = 9,
					["Parent"] = nil,
					["Size"] = UDim2.fromScale(1, 1),
					["BackgroundColor3"] = v_u_13.White,
					["Parent"] = v22
				})
				v_u_17.fxLayer = v_u_10.new("Frame", {
					["Name"] = "FxLayer",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 8,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.385),
					["Size"] = UDim2.fromOffset(0, 0),
					["Parent"] = v_u_17.stage
				})
				v_u_17.pool = v_u_8.Pool(v_u_17.fxLayer, 90, 8)
				v_u_17.emblemHolder = v_u_10.new("Frame", {
					["Name"] = "EmblemHolder",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 6,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.385),
					["Size"] = UDim2.fromOffset(300, 300),
					["Parent"] = v_u_17.stage
				})
				v_u_17.emblemScale = v_u_10.new("UIScale", {
					["Scale"] = 1,
					["Parent"] = nil,
					["Parent"] = v_u_17.emblemHolder
				})
				v_u_17.emblem = v_u_7.Emblem(1, 300, {
					["ZIndex"] = 6,
					["Parent"] = nil,
					["Parent"] = v_u_17.emblemHolder
				})
				v_u_17.emblem.Size = UDim2.fromScale(1, 1)
				v_u_17.kicker = v_u_10.new("TextLabel", {
					["Name"] = "Kicker",
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.11),
					["Size"] = UDim2.fromOffset(800, 50),
					["Text"] = "RANK UP",
					["FontFace"] = v_u_14.Display,
					["TextSize"] = 46,
					["TextColor3"] = v_u_13.Text,
					["TextTransparency"] = 1,
					["ZIndex"] = 7,
					v_u_10.TextStroke(v_u_13.Void, 3, 0.3),
					["Parent"] = v_u_17.stage
				})
				v_u_17.name = v_u_10.new("TextLabel", {
					["Name"] = "RankName",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["FontFace"] = nil,
					["TextSize"] = 104,
					["TextColor3"] = nil,
					["TextTransparency"] = 1,
					["ZIndex"] = 7,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.615),
					["Size"] = UDim2.fromOffset(1000, 110),
					["FontFace"] = v_u_14.Display,
					["TextColor3"] = v_u_13.Text,
					["Parent"] = v_u_17.stage
				})
				v_u_17.nameGrad = v_u_10.new("UIGradient", {
					["Rotation"] = 90,
					["Parent"] = nil,
					["Parent"] = v_u_17.name
				})
				v_u_17.nameStroke = v_u_10.TextStroke(v_u_13.Void, 4, 0.2)
				v_u_17.nameStroke.Parent = v_u_17.name
				v_u_17.nameScale = v_u_10.new("UIScale", {
					["Scale"] = 1,
					["Parent"] = nil,
					["Parent"] = v_u_17.name
				})
				v_u_17.sub = v_u_10.new("TextLabel", {
					["Name"] = "Sub",
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.68),
					["Size"] = UDim2.fromOffset(900, 34),
					["Text"] = "",
					["FontFace"] = v_u_14.Heavy,
					["TextSize"] = 28,
					["TextColor3"] = v_u_13.TextDim,
					["TextTransparency"] = 1,
					["ZIndex"] = 7,
					v_u_10.TextStroke(v_u_13.Void, 2, 0.35),
					["Parent"] = v_u_17.stage
				})
				v_u_17.newTitle = v_u_10.new("TextLabel", {
					["Name"] = "NewTitle",
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.735),
					["Size"] = UDim2.fromOffset(900, 28),
					["Text"] = "",
					["FontFace"] = v_u_14.Heavy,
					["TextSize"] = 22,
					["TextColor3"] = v_u_13.TextDim,
					["TextTransparency"] = 1,
					["ZIndex"] = 7,
					v_u_10.TextStroke(v_u_13.Void, 2, 0.4),
					["Parent"] = v_u_17.stage
				})
				v_u_17.cards = v_u_10.new("Frame", {
					["Name"] = "Cards",
					["AnchorPoint"] = Vector2.new(0.5, 0),
					["Position"] = UDim2.fromScale(0.5, 0.76),
					["Size"] = UDim2.fromOffset(1000, 132),
					["ZIndex"] = 7,
					v_u_10.List(Enum.FillDirection.Horizontal, 16, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Top),
					["Parent"] = v_u_17.stage
				})
				v_u_17.cont = v_u_10.new("TextButton", {
					["Name"] = "Continue",
					["AnchorPoint"] = Vector2.new(0.5, 1),
					["Position"] = UDim2.new(0.5, 0, 1, -14),
					["Size"] = UDim2.fromOffset(260, 52),
					["Text"] = "",
					["AutoButtonColor"] = false,
					["BackgroundColor3"] = v_u_13.Panel,
					["BackgroundTransparency"] = 0.15,
					["Visible"] = false,
					["ZIndex"] = 10,
					v_u_10.Corner(v_u_11.Radius.Pill),
					v_u_10.Stroke(v_u_13.Stroke, 1.5, 0.6),
					["Parent"] = v_u_17.stage
				})
				v_u_10.new("TextLabel", {
					["Name"] = "Label",
					["Size"] = nil,
					["Text"] = "CONTINUE",
					["FontFace"] = nil,
					["TextSize"] = 24,
					["TextColor3"] = nil,
					["ZIndex"] = 11,
					["Parent"] = nil,
					["Size"] = UDim2.fromScale(1, 1),
					["FontFace"] = v_u_14.Display,
					["TextColor3"] = v_u_13.Text,
					["Parent"] = v_u_17.cont
				})
				v_u_17.contScale = v_u_10.new("UIScale", {
					["Scale"] = 1,
					["Parent"] = nil,
					["Parent"] = v_u_17.cont
				})
				v_u_17.catcher = v_u_10.new("TextButton", {
					["Name"] = "Catcher",
					["Size"] = nil,
					["Text"] = "",
					["BackgroundTransparency"] = 1,
					["AutoButtonColor"] = false,
					["ZIndex"] = 1,
					["Parent"] = nil,
					["Size"] = UDim2.fromScale(1, 1),
					["Parent"] = v22
				})
			end
		end
		local v_u_34 = nil
		local function v_u_36() -- name: clearCards
			-- upvalues: (ref) v_u_17
			for _, v35 in v_u_17.cards:GetChildren() do
				if not v35:IsA("GuiObject") then
					continue
				end
				v35:Destroy()
			end
		end
		local function v_u_47(p37, p38, p39, p40) -- name: weaponCard
			-- upvalues: (copy) v_u_10, (copy) v_u_13, (copy) v_u_11, (ref) v_u_17, (copy) p_u_9, (copy) v_u_14
			local v41 = v_u_10.new("Frame", {
				["Name"] = "Card_" .. p37,
				["Size"] = UDim2.fromOffset(150, 132),
				["BackgroundColor3"] = v_u_13.Panel,
				["BackgroundTransparency"] = 0.1,
				["LayoutOrder"] = p40,
				["ZIndex"] = 7,
				v_u_10.Corner(v_u_11.Radius.Large),
				v_u_10.Stroke(p39, 2, 0.25),
				["Parent"] = v_u_17.cards
			})
			v_u_10.new("UIScale", {
				["Scale"] = 1,
				["Parent"] = nil,
				["Parent"] = v41
			})
			local v42 = v_u_10.new("Frame", {
				["Name"] = "Icon",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 8,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 8),
				["Size"] = UDim2.fromOffset(84, 84),
				["Parent"] = v41
			})
			p_u_9.WeaponIcon.Set(v42, p37, {
				["spin"] = true
			})
			v_u_10.new("TextLabel", {
				["Name"] = "Name",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 17,
				["TextScaled"] = false,
				["TextColor3"] = nil,
				["TextTruncate"] = nil,
				["ZIndex"] = 8,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 1),
				["Position"] = UDim2.new(0.5, 0, 1, -8),
				["Size"] = UDim2.new(1, -12, 0, 22),
				["Text"] = string.upper(p_u_9.WeaponInfo.Name(p37)),
				["FontFace"] = v_u_14.Heavy,
				["TextColor3"] = v_u_13.Text,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v41
			})
			local v43 = v_u_10.new
			local v44 = "TextLabel"
			local v45 = {
				["Name"] = "Tag",
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.new(1, -6, 0, 6),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["Size"] = UDim2.fromOffset(0, 20),
				["Text"] = p38 and " OWNED " or " NEW ",
				["FontFace"] = v_u_14.Heavy,
				["TextSize"] = 14
			}
			local v46
			if p38 then
				v46 = v_u_13.TextDim
			else
				v46 = v_u_13.TextDark
			end
			v45.TextColor3 = v46
			if p38 then
				p39 = v_u_13.Raised
			end
			v45.BackgroundColor3 = p39
			v45.BackgroundTransparency = 0
			v45.ZIndex = 9
			__set_list(v45, 1, {(v_u_10.Corner(v_u_11.Radius.Pill))})
			v45.Parent = v41
			v43(v44, v45)
			return v41
		end
		local v_u_48 = nil
		local v_u_49 = nil
		local v_u_50 = nil
		local v_u_51 = nil
		local function v_u_60(p52) -- name: finish
			-- upvalues: (ref) v_u_18, (ref) v_u_19, (ref) v_u_48, (ref) v_u_49, (ref) v_u_50, (ref) v_u_51, (ref) v_u_34, (ref) v_u_5, (ref) v_u_17, (copy) v_u_36, (copy) p_u_9
			if v_u_18 then
				local v53 = v_u_18.onDone
				v_u_18 = nil
				v_u_19 = v_u_19 + 1
				if v_u_48 then
					v_u_48()
					v_u_48 = nil
				end
				if v_u_49 then
					v_u_49:Disconnect()
					v_u_49 = nil
				end
				if v_u_50 then
					v_u_50:Disconnect()
					v_u_50 = nil
				end
				if v_u_51 then
					v_u_51:Disconnect()
					v_u_51 = nil
				end
				if v_u_34 then
					local v_u_54 = v_u_34
					v_u_34 = nil
					local v55 = v_u_5:Create(v_u_54, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Size"] = 0
					})
					v55:Play()
					v55.Completed:Connect(function()
						-- upvalues: (copy) v_u_54
						v_u_54:Destroy()
					end)
				end
				v_u_17.pool:Clear()
				for _, v56 in {
					v_u_17.glow,
					v_u_17.rays,
					v_u_17.raysThin,
					v_u_17.ring
				} do
					v_u_5:Create(v56, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["ImageTransparency"] = 1
					}):Play()
				end
				for _, v57 in {
					v_u_17.kicker,
					v_u_17.name,
					v_u_17.sub,
					v_u_17.newTitle
				} do
					v_u_5:Create(v57, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["TextTransparency"] = 1
					}):Play()
				end
				v_u_5:Create(v_u_17.nameStroke, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Transparency"] = 1
				}):Play()
				v_u_5:Create(v_u_17.dim, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["BackgroundTransparency"] = 1
				}):Play()
				v_u_17.cont.Visible = false
				task.delay(0.25, function()
					-- upvalues: (ref) v_u_18, (ref) v_u_17, (ref) v_u_36
					if not v_u_18 then
						v_u_17.root.Visible = false
						v_u_36()
					end
				end)
				p_u_9.SetHudHidden("RankUp", false)
				p_u_9.MenuManager.HoldChat("RankUp", false)
				if p_u_9.TopbarSettings then
					local v58 = p_u_9.TopbarSettings.SetHidden
					if type(v58) == "function" then
						local v59 = p_u_9.TopbarSettings.SetHidden
						pcall(v59, "RankUp", false)
					end
				end
				if v53 then
					task.spawn(v53, p52)
				end
			end
		end
		local function v_u_64(p61) -- name: settle
			-- upvalues: (ref) v_u_18, (ref) v_u_17, (copy) v_u_10
			if v_u_18 and (v_u_18.token == p61 and not v_u_18.settled) then
				v_u_18.settled = true
				v_u_17.emblemScale.Scale = 1
				v_u_17.nameScale.Scale = 1
				v_u_17.kicker.TextTransparency = 0
				v_u_17.name.TextTransparency = 0
				v_u_17.nameStroke.Transparency = 0.2
				v_u_17.sub.TextTransparency = 0
				v_u_17.newTitle.TextTransparency = 0
				v_u_17.glow.ImageTransparency = 0.35
				v_u_17.rays.ImageTransparency = 0.55
				v_u_17.raysThin.ImageTransparency = 0.75
				v_u_17.dim.BackgroundTransparency = 0.22
				for _, v62 in v_u_18.cards do
					v62.Visible = true
					local v63 = v62:FindFirstChildOfClass("UIScale")
					if not v63 then
						continue
					end
					v63.Scale = 1
				end
				v_u_17.cont.Visible = true
				v_u_18.contAt = os.clock()
				v_u_10.Pop(v_u_17.cont, 0.6)
			end
		end
		local v_u_115 = {
			["IsPlaying"] = function() -- name: IsPlaying
				-- upvalues: (ref) v_u_18
				return v_u_18 ~= nil
			end,
			["Stop"] = function() -- name: Stop
				-- upvalues: (copy) v_u_60
				v_u_60("interrupted")
			end,
			["Play"] = function(p65, p66) -- name: Play
				-- upvalues: (copy) v_u_15, (copy) p_u_9, (copy) v_u_33, (ref) v_u_18, (copy) v_u_60, (ref) v_u_19, (ref) v_u_6, (ref) v_u_7, (copy) v_u_36, (ref) v_u_17, (copy) v_u_11, (copy) v_u_12, (copy) v_u_10, (copy) v_u_47, (ref) v_u_50, (copy) v_u_64, (ref) v_u_51, (ref) v_u_1, (ref) v_u_48, (ref) v_u_49, (ref) v_u_34, (ref) v_u_2, (ref) v_u_5
				local v67
				if type(p65) == "table" then
					local v68 = p65.rank
					v67 = tonumber(v68) or nil
				else
					v67 = nil
				end
				if not v67 then
					return false
				end
				if v_u_15:GetAttribute("ReplayPlaying") == true and true or (p_u_9.IsHudHiddenFor("Intro") or p_u_9.IsHudHiddenFor("Celebrate")) then
					return false
				end
				v_u_33()
				if v_u_18 then
					v_u_60("interrupted")
				end
				v_u_19 = v_u_19 + 1
				local v_u_69 = v_u_19
				local v70 = math.floor(v67)
				local v71 = v_u_6.Count
				local v72 = math.clamp(v70, 1, v71())
				local v73 = v_u_6.Get(v72)
				local v_u_74, v_u_75 = v_u_7.Color(v72)
				local v76 = v_u_6.NewItems(v72 - 1, v72)
				v_u_18 = {
					["token"] = nil,
					["onDone"] = nil,
					["settled"] = false,
					["cards"] = nil,
					["token"] = v_u_69,
					["onDone"] = p66,
					["cards"] = {}
				}
				p_u_9.SetHudHidden("RankUp", true)
				p_u_9.MenuManager.HoldChat("RankUp", true)
				if p_u_9.TopbarSettings then
					local v77 = p_u_9.TopbarSettings.SetHidden
					if type(v77) == "function" then
						local v78 = p_u_9.TopbarSettings.SetHidden
						pcall(v78, "RankUp", true)
					end
				end
				v_u_36()
				v_u_17.root.Visible = true
				v_u_17.dim.BackgroundTransparency = 1
				v_u_17.flash.BackgroundTransparency = 1
				for _, v79 in {
					v_u_17.glow,
					v_u_17.rays,
					v_u_17.raysThin,
					v_u_17.ring
				} do
					v79.ImageTransparency = 1
					v79.ImageColor3 = v_u_74
				end
				v_u_17.raysThin.ImageColor3 = v_u_11.Lighten(v_u_74, 0.4)
				v_u_17.ring.Size = UDim2.fromOffset(200, 200)
				v_u_7.SetEmblem(v_u_17.emblem, v72)
				v_u_17.emblem.Visible = false
				v_u_17.emblemScale.Scale = 2.6
				v_u_17.kicker.TextTransparency = 1
				v_u_17.name.Text = string.upper(v73.name)
				v_u_17.name.TextTransparency = 1
				v_u_17.nameStroke.Transparency = 1
				v_u_17.nameGrad.Color = ColorSequence.new(v_u_11.Lighten(v_u_74, 0.35), v_u_74)
				v_u_17.nameScale.Scale = 1.8
				local v80 = (v_u_12.Profile or {}).trophies
				local v81 = tonumber(v80) or 0
				local v82 = v73.trophies
				local v83 = math.max(v81, v82)
				v_u_17.sub.Text = string.format("%s TROPHIES", v_u_10.FormatNumber(v83))
				v_u_17.sub.TextTransparency = 1
				v_u_17.newTitle.TextTransparency = 1
				if #v76 > 0 then
					v_u_17.newTitle.Text = #v76 == 1 and "NEW WEAPON IN DROPS" or "NEW WEAPONS IN DROPS"
				elseif v_u_6.Count() <= v72 then
					v_u_17.newTitle.Text = "THE TOP RANK"
				else
					local v84 = v_u_6.Get(v72 + 1)
					v_u_17.newTitle.Text = string.format("NEXT: %s AT %s", string.upper(v84.name), v_u_10.FormatNumber(v84.trophies))
				end
				local v85 = p_u_9.Economy
				if v85 then
					v85 = p_u_9.Economy.Owns
				end
				for v86, v87 in v76 do
					local v88
					if type(v85) == "function" then
						v88 = v85(v87) == true
					else
						v88 = false
					end
					local v89 = v_u_47(v87, v88, v_u_74, v86)
					v89.Visible = false
					local v90 = v_u_18.cards
					table.insert(v90, v89)
				end
				v_u_17.cont.Visible = false
				v_u_50 = v_u_17.catcher.Activated:Connect(function()
					-- upvalues: (ref) v_u_18, (ref) v_u_64
					if v_u_18 then
						if not v_u_18.settled then
							v_u_64(v_u_18.token)
						end
					else
						return
					end
				end)
				v_u_51 = v_u_17.cont.Activated:Connect(function()
					-- upvalues: (ref) v_u_18, (ref) v_u_64, (ref) p_u_9, (ref) v_u_60
					if v_u_18 then
						if v_u_18.settled then
							if os.clock() - (v_u_18.contAt or 0) > 0.35 then
								p_u_9.Sounds.Play("Click")
								v_u_60("done")
							end
						else
							v_u_64(v_u_18.token)
						end
					else
						return
					end
				end)
				v_u_1:BindActionAtPriority("TR_RankUpKeys", function(_, p91)
					-- upvalues: (ref) v_u_18, (ref) v_u_64, (ref) p_u_9, (ref) v_u_60
					if p91 == Enum.UserInputState.Begin and v_u_18 then
						if v_u_18.settled then
							if os.clock() - (v_u_18.contAt or 0) > 0.35 then
								p_u_9.Sounds.Play("Click")
								v_u_60("done")
							end
						else
							v_u_64(v_u_18.token)
						end
					end
					return Enum.ContextActionResult.Sink
				end, false, Enum.ContextActionPriority.High.Value + 60, Enum.KeyCode.Space, Enum.KeyCode.Return, Enum.KeyCode.ButtonA)
				v_u_48 = function()
					-- upvalues: (ref) v_u_1
					v_u_1:UnbindAction("TR_RankUpKeys")
				end
				v_u_49 = game:GetService("RunService").RenderStepped:Connect(function(p92)
					-- upvalues: (ref) v_u_18, (copy) v_u_69, (ref) v_u_17
					if v_u_18 and v_u_18.token == v_u_69 then
						v_u_17.rays.Rotation = (v_u_17.rays.Rotation + p92 * 9) % 360
						v_u_17.raysThin.Rotation = (v_u_17.raysThin.Rotation - p92 * 5) % 360
					end
				end)
				task.spawn(function()
					-- upvalues: (ref) v_u_34, (ref) v_u_10, (ref) v_u_2, (ref) v_u_5, (ref) v_u_17, (ref) v_u_18, (copy) v_u_69, (ref) v_u_15, (ref) p_u_9, (ref) v_u_60, (copy) v_u_74, (ref) v_u_11, (copy) v_u_75, (ref) v_u_64
					if not (v_u_34 and v_u_34.Parent) then
						local v93 = {
							["Name"] = "TR_RankUpBlur",
							["Size"] = 0,
							["Parent"] = nil,
							["Parent"] = v_u_2
						}
						v_u_34 = v_u_10.new("BlurEffect", v93)
					end
					v_u_5:Create(v_u_34, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Size"] = 14
					}):Play()
					v_u_5:Create(v_u_17.dim, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["BackgroundTransparency"] = 0.22
					}):Play()
					v_u_5:Create(v_u_17.glow, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["ImageTransparency"] = 0.6
					}):Play()
					task.wait(0.25)
					local v94
					if v_u_18 and v_u_18.token == v_u_69 then
						if v_u_15:GetAttribute("ReplayPlaying") == true and true or (p_u_9.IsHudHiddenFor("Intro") or p_u_9.IsHudHiddenFor("Celebrate")) then
							v_u_60("interrupted")
							v94 = false
						else
							v94 = not v_u_18.settled
						end
					else
						v94 = false
					end
					if v94 then
						v_u_17.kicker.Position = UDim2.fromScale(0.5, 0.08)
						local v95 = v_u_17.kicker
						local v96 = {
							["TextTransparency"] = 0,
							["Position"] = nil,
							["Position"] = UDim2.fromScale(0.5, 0.11)
						}
						local v97 = Enum.EasingStyle.Back
						v_u_5:Create(v95, TweenInfo.new(0.35, v97 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v96):Play()
						p_u_9.Sounds.Play("Whoosh")
						task.wait(0.2)
						local v98
						if v_u_18 and v_u_18.token == v_u_69 then
							if v_u_15:GetAttribute("ReplayPlaying") == true and true or (p_u_9.IsHudHiddenFor("Intro") or p_u_9.IsHudHiddenFor("Celebrate")) then
								v_u_60("interrupted")
								v98 = false
							else
								v98 = not v_u_18.settled
							end
						else
							v98 = false
						end
						if v98 then
							v_u_17.emblem.Visible = true
							local v99 = v_u_17.emblemScale
							local v100 = Enum.EasingStyle.Back
							local v101 = Enum.EasingDirection.Out
							v_u_5:Create(v99, TweenInfo.new(0.28, v100 or Enum.EasingStyle.Quad, v101 or Enum.EasingDirection.Out), {
								["Scale"] = 1
							}):Play()
							task.wait(0.2)
							local v102
							if v_u_18 and v_u_18.token == v_u_69 then
								if v_u_15:GetAttribute("ReplayPlaying") == true and true or (p_u_9.IsHudHiddenFor("Intro") or p_u_9.IsHudHiddenFor("Celebrate")) then
									v_u_60("interrupted")
									v102 = false
								else
									v102 = not v_u_18.settled
								end
							else
								v102 = false
							end
							if v102 then
								p_u_9.Sounds.Play("LevelUp")
								p_u_9.Sounds.Play("Fanfare")
								v_u_17.flash.BackgroundTransparency = 0.55
								v_u_5:Create(v_u_17.flash, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
									["BackgroundTransparency"] = 1
								}):Play()
								v_u_17.ring.ImageTransparency = 0.1
								local v103 = v_u_17.ring
								local v104 = {
									["Size"] = nil,
									["ImageTransparency"] = 1,
									["Size"] = UDim2.fromOffset(900, 900)
								}
								v_u_5:Create(v103, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v104):Play()
								v_u_5:Create(v_u_17.glow, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
									["ImageTransparency"] = 0.35
								}):Play()
								v_u_17.pool:Burst(46, {
									["mode"] = "point",
									["speed"] = 900,
									["colors"] = nil,
									["white"] = nil,
									["life"] = 1.1,
									["grav"] = 260,
									["colors"] = { v_u_74, v_u_11.Lighten(v_u_74, 0.4), v_u_75 },
									["white"] = v_u_11.Lighten(v_u_74, 0.7)
								})
								v_u_17.pool:Burst(18, {
									["mode"] = "point",
									["kind"] = "sparkle",
									["speed"] = 420,
									["color"] = nil,
									["size"] = 26,
									["life"] = 1.4,
									["grav"] = -40,
									["color"] = v_u_11.Lighten(v_u_74, 0.5)
								})
								v_u_10.Shake(v_u_17.root, 10)
								v_u_5:Create(v_u_17.rays, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
									["ImageTransparency"] = 0.55
								}):Play()
								v_u_5:Create(v_u_17.raysThin, TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
									["ImageTransparency"] = 0.75
								}):Play()
								task.wait(0.15)
								local v105
								if v_u_18 and v_u_18.token == v_u_69 then
									if v_u_15:GetAttribute("ReplayPlaying") == true and true or (p_u_9.IsHudHiddenFor("Intro") or p_u_9.IsHudHiddenFor("Celebrate")) then
										v_u_60("interrupted")
										v105 = false
									else
										v105 = not v_u_18.settled
									end
								else
									v105 = false
								end
								if v105 then
									v_u_5:Create(v_u_17.name, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
										["TextTransparency"] = 0
									}):Play()
									v_u_5:Create(v_u_17.nameStroke, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
										["Transparency"] = 0.2
									}):Play()
									local v106 = v_u_17.nameScale
									local v107 = Enum.EasingStyle.Back
									v_u_5:Create(v106, TweenInfo.new(0.32, v107 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
										["Scale"] = 1
									}):Play()
									task.wait(0.3)
									local v108
									if v_u_18 and v_u_18.token == v_u_69 then
										if v_u_15:GetAttribute("ReplayPlaying") == true and true or (p_u_9.IsHudHiddenFor("Intro") or p_u_9.IsHudHiddenFor("Celebrate")) then
											v_u_60("interrupted")
											v108 = false
										else
											v108 = not v_u_18.settled
										end
									else
										v108 = false
									end
									if v108 then
										v_u_5:Create(v_u_17.sub, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
											["TextTransparency"] = 0
										}):Play()
										task.wait(0.45)
										local v109
										if v_u_18 and v_u_18.token == v_u_69 then
											if v_u_15:GetAttribute("ReplayPlaying") == true and true or (p_u_9.IsHudHiddenFor("Intro") or p_u_9.IsHudHiddenFor("Celebrate")) then
												v_u_60("interrupted")
												v109 = false
											else
												v109 = not v_u_18.settled
											end
										else
											v109 = false
										end
										if v109 then
											v_u_5:Create(v_u_17.newTitle, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
												["TextTransparency"] = 0
											}):Play()
											for _, v110 in v_u_18.cards do
												task.wait(0.2)
												local v111
												if v_u_18 and v_u_18.token == v_u_69 then
													if v_u_15:GetAttribute("ReplayPlaying") == true and true or (p_u_9.IsHudHiddenFor("Intro") or p_u_9.IsHudHiddenFor("Celebrate")) then
														v_u_60("interrupted")
														v111 = false
													else
														v111 = not v_u_18.settled
													end
												else
													v111 = false
												end
												if not v111 then
													return
												end
												v110.Visible = true
												local v112 = v110:FindFirstChildOfClass("UIScale")
												if v112 then
													v112.Scale = 0.3
													local v113 = Enum.EasingStyle.Back
													v_u_5:Create(v112, TweenInfo.new(0.3, v113 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
														["Scale"] = 1
													}):Play()
												end
												p_u_9.Sounds.Play("Coin", {
													["pitch"] = 1.1
												})
											end
											task.wait(0.5)
											local v114
											if v_u_18 and v_u_18.token == v_u_69 then
												if v_u_15:GetAttribute("ReplayPlaying") == true and true or (p_u_9.IsHudHiddenFor("Intro") or p_u_9.IsHudHiddenFor("Celebrate")) then
													v_u_60("interrupted")
													v114 = false
												else
													v114 = not v_u_18.settled
												end
											else
												v114 = false
											end
											if v114 then
												v_u_64(v_u_69)
											end
										end
									else
										return
									end
								else
									return
								end
							else
								return
							end
						else
							return
						end
					else
						return
					end
				end)
				return true
			end
		}
		p_u_9.RankUp = v_u_115
		function p_u_9.Debug.rankUp(p116)
			-- upvalues: (copy) v_u_115
			return v_u_115.Play({
				["rank"] = nil,
				["source"] = "rank",
				["rank"] = tonumber(p116) or 4
			}, function(p117)
				print("[RankUp] done:", p117)
			end)
		end
	end
}