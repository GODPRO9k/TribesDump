local v_u_1 = game:GetService("RunService")
local v2 = {}
local v_u_3 = {
	["spark"] = 1,
	["shard"] = 2,
	["sparkle"] = 3,
	["dust"] = 4
}
local v_u_4 = nil
local function v_u_7() -- name: images
	-- upvalues: (ref) v_u_4
	if not v_u_4 then
		local v5, v6 = pcall(function()
			return require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("UIAssets"))
		end)
		v_u_4 = (not v5 or type(v6) ~= "table") and {
			["Fx"] = {}
		} or v6
	end
	return v_u_4.Fx or {}
end
local v_u_8 = {}
v_u_8.__index = v_u_8
function v2.Pool(p9, p10, p11) -- name: Pool
	-- upvalues: (copy) v_u_8
	local v12 = {
		["Layer"] = nil,
		["Pace"] = 1,
		["_free"] = nil,
		["_live"] = nil,
		["_spare"] = nil,
		["_emitters"] = nil,
		["_conn"] = nil,
		["_rng"] = nil,
		["Layer"] = p9,
		["_free"] = {},
		["_live"] = {},
		["_spare"] = {},
		["_emitters"] = {},
		["_rng"] = Random.new()
	}
	local v13 = v_u_8
	local v14 = setmetatable(v12, v13)
	for v15 = 1, p10 do
		local v16 = Instance.new("ImageLabel")
		v16.Name = "P" .. v15
		v16.AnchorPoint = Vector2.new(0.5, 0.5)
		v16.Size = UDim2.fromOffset(20, 20)
		v16.BackgroundTransparency = 1
		v16.BorderSizePixel = 0
		v16.ImageTransparency = 1
		v16.Visible = false
		v16.ZIndex = p11 or p9.ZIndex
		v16.Parent = p9
		v14._free[v15] = v16
	end
	return v14
end
local function v_u_46(p17, p18) -- name: stepPool
	local v19 = p17.Pace
	local v20 = p18 / math.max(v19, 0.01)
	for v21 = #p17._emitters, 1, -1 do
		local v22 = p17._emitters[v21]
		if v22.alive then
			v22.acc = v22.acc + v22.rate * v20
			if v22.acc < 1 then
				continue
			end
			local v23 = v22.acc
			local v24 = math.floor(v23)
			v22.acc = v22.acc - v24
			p17:Burst(v24, v22.opts)
		else
			p17._emitters[v21] = p17._emitters[#p17._emitters]
			p17._emitters[#p17._emitters] = nil
		end
	end
	local v25 = p17._live
	local v26 = 1
	while v26 <= #v25 do
		local v27 = v25[v26]
		v27.age = v27.age + v20
		local v28 = v27.age / v27.life
		if v28 >= 1 then
			v27.img.Visible = false
			local v29 = p17._free
			local v30 = v27.img
			table.insert(v29, v30)
			local v31 = p17._spare
			table.insert(v31, v27)
			v25[v26] = v25[#v25]
			v25[#v25] = nil
		else
			local v32 = 1 - v27.drag * v20
			local v33 = math.max(0, v32)
			v27.vx = v27.vx * v33
			v27.vy = v27.vy * v33 + v27.grav * v20
			v27.px = v27.px + v27.vx * v20
			v27.py = v27.py + v27.vy * v20
			local v34 = v27.img
			v34.Position = UDim2.fromOffset(v27.px, v27.py)
			local v35 = v27.kind
			if v35 == 1 then
				local v36 = v27.vy
				local v37 = v27.vx
				local v38 = math.atan2(v36, v37)
				v34.Rotation = math.deg(v38)
				local v39 = v27.vx * v27.vx + v27.vy * v27.vy
				local v40 = math.sqrt(v39) / 900
				local v41 = math.clamp(v40, 0.35, 1.4)
				v34.Size = UDim2.fromOffset(v27.w * v41, v27.h)
				v34.ImageTransparency = v27.base + (1 - v27.base) * (v28 * v28)
			elseif v35 == 3 then
				local v42 = 1 - v28 * v28
				local v43 = v27.phase + v27.age * 26
				local v44 = v42 * (math.sin(v43) * 0.25 + 0.75)
				v34.Size = UDim2.fromOffset(v27.w * v44, v27.w * v44)
				v27.rot = v27.rot + v27.spin * v20
				v34.Rotation = v27.rot
				v34.ImageTransparency = v27.base + (1 - v27.base) * v28 ^ 3
			elseif v35 == 4 then
				local v45 = 1 + (v27.grow - 1) * (1 - (1 - v28) * (1 - v28))
				v34.Size = UDim2.fromOffset(v27.w * v45, v27.h * v45)
				v34.ImageTransparency = v27.base + (1 - v27.base) * v28
			else
				v27.rot = v27.rot + v27.spin * v20
				v34.Rotation = v27.rot
				v34.ImageTransparency = v27.base + (1 - v27.base) * (v28 * v28)
			end
			v26 = v26 + 1
		end
	end
	if #v25 == 0 and (#p17._emitters == 0 and p17._conn) then
		p17._conn:Disconnect()
		p17._conn = nil
	end
end
function v_u_8.Burst(p_u_47, p48, p49) -- name: Burst
	-- upvalues: (copy) v_u_7, (copy) v_u_3, (copy) v_u_1, (copy) v_u_46
	local v50 = p49 or {}
	local v51 = v_u_7()
	local v52 = p_u_47._rng
	local v53 = v50.mode or (v50.dir and "point" or "box")
	local v54 = v50.box or Vector2.zero
	local v55 = v50.at or Vector2.zero
	local v56 = v50.speed or 600
	local v57 = v50.whiteChance == nil and 0.35 or v50.whiteChance
	local v58 = v50.white or Color3.fromRGB(255, 244, 220)
	for _ = 1, p48 do
		local v59 = table.remove(p_u_47._free)
		if not v59 then
			break
		end
		local v60
		if v50.kind then
			v60 = v_u_3[v50.kind] or 2
		else
			v60 = v52:NextNumber() < (v50.sparkChance or 0.55) and 1 or 2
		end
		local v61, v62, v63, v64
		if v53 == "box" then
			local v65 = v52:NextNumber(-v54.X / 2, v54.X / 2)
			local v66 = v52:NextNumber(-v54.Y / 2, v54.Y / 2)
			local v67 = v54.X / 2
			v61 = v65 / math.max(v67, 1) * 1.3 + v52:NextNumber(-0.4, 0.4)
			local v68 = v54.Y / 2
			v62 = v66 / math.max(v68, 1) + v52:NextNumber(-0.9, 0.9)
			v63 = v55.X + v65
			v64 = v55.Y + v66
		else
			local v69 = v50.jitter or 0
			local v70 = v52:NextNumber(0, 6.283185307179586)
			local v71 = v52:NextNumber()
			local v72 = v69 * math.sqrt(v71)
			v63 = v55.X + math.cos(v70) * v72
			v64 = v55.Y + math.sin(v70) * v72
			local v73 = v50.dir or 0
			local v74 = math.rad(v73)
			local v75
			if v50.spread == nil then
				v75 = v50.dir and 30 or 180
			else
				v75 = v50.spread
			end
			local v76 = math.rad(v75)
			local v77 = v74 + v52:NextNumber(-v76, v76)
			v61 = math.cos(v77)
			v62 = math.sin(v77)
		end
		local v78 = v61 * v61 + v62 * v62
		local v79 = math.sqrt(v78)
		if v79 < 0.01 then
			v61 = 1
			v79 = 1
			v62 = 0
		end
		local v80 = v61 / v79
		local v81 = v62 / v79
		local v82
		if v50.speedMin and v50.speedMax then
			v82 = v52:NextNumber(v50.speedMin, v50.speedMax)
		else
			v82 = v56 * v52:NextNumber(0.5, 1.15)
		end
		local v83 = v50.size
		local v84, v85
		if v60 == 1 then
			local v86 = v50.sparkLen
			if not v86 then
				if v50.kind ~= "spark" then
					v83 = nil
				end
				v86 = v83 or 160
			end
			v84 = v52:NextNumber(v86 * 0.7, v86 * 1.3)
			v85 = v52:NextNumber(10, 16) * (v86 / 160) ^ 0.5
			v59.Image = v51.Spark or ""
		elseif v60 == 2 then
			v85 = v52:NextNumber(0.6, 1.4) * (v83 or 24)
			v59.Image = v51.Shard or ""
			v84 = v85
		elseif v60 == 3 then
			v85 = v52:NextNumber(0.6, 1.3) * (v83 or 30)
			v59.Image = v51.Sparkle or ""
			v84 = v85
		else
			v84 = v52:NextNumber(0.7, 1.3) * (v83 or 60)
			v85 = v84 * v52:NextNumber(0.7, 0.9)
			v59.Image = v51.Dust or ""
		end
		local v87
		if v50.colors and #v50.colors > 0 then
			v87 = v50.colors[v52:NextInteger(1, #v50.colors)]
		else
			v87 = v50.color or Color3.fromRGB(255, 200, 80)
		end
		if v60 ~= 4 and v52:NextNumber() < v57 then
			v87 = v58
		end
		v59.ImageColor3 = v87
		v59.Size = UDim2.fromOffset(v84, v85)
		v59.Position = UDim2.fromOffset(v63, v64)
		v59.Rotation = 0
		v59.ImageTransparency = v50.base or 0
		v59.Visible = true
		local v88
		if v50.lifeMin and v50.lifeMax then
			v88 = v52:NextNumber(v50.lifeMin, v50.lifeMax)
		else
			v88 = (v50.life or 1) * v52:NextNumber(0.55, 1)
		end
		local v89 = table.remove(p_u_47._spare) or {}
		v89.img = v59
		v89.px = v63
		v89.py = v64
		local v90 = v80 * v82
		local v91 = v81 * v82
		v89.vx = v90
		v89.vy = v91
		v89.rot = v52:NextNumber(0, 360)
		v89.spin = v52:NextNumber(-1, 1) * (v50.spin or 540)
		v89.age = 0
		v89.life = v88 * (v50.lifeMult or 1)
		v89.w = v84
		v89.h = v85
		v89.kind = v60
		v89.drag = v50.drag or 2.6
		v89.grav = v50.grav == nil and 420 or v50.grav
		v89.base = v50.base or 0
		v89.grow = v50.grow or (v60 == 4 and 2.2 or 1)
		v89.phase = v52:NextNumber(0, 6.28)
		local v92 = p_u_47._live
		table.insert(v92, v89)
	end
	if not p_u_47._conn and (#p_u_47._live > 0 or #p_u_47._emitters > 0) then
		p_u_47._conn = v_u_1.RenderStepped:Connect(function(p93)
			-- upvalues: (ref) v_u_46, (copy) p_u_47
			v_u_46(p_u_47, p93)
		end)
	end
end
function v_u_8.Emit(p_u_94, p95, p96) -- name: Emit
	-- upvalues: (copy) v_u_1, (copy) v_u_46
	local v_u_97 = {
		["rate"] = nil,
		["acc"] = 0,
		["opts"] = nil,
		["alive"] = true,
		["rate"] = p95,
		["opts"] = p96 or {}
	}
	local v98 = p_u_94._emitters
	table.insert(v98, v_u_97)
	if not p_u_94._conn then
		p_u_94._conn = v_u_1.RenderStepped:Connect(function(p99)
			-- upvalues: (ref) v_u_46, (copy) p_u_94
			v_u_46(p_u_94, p99)
		end)
	end
	return function()
		-- upvalues: (copy) v_u_97
		v_u_97.alive = false
	end
end
function v_u_8.Clear(p100) -- name: Clear
	for _, v101 in p100._emitters do
		v101.alive = false
	end
	table.clear(p100._emitters)
	for _, v102 in p100._live do
		v102.img.Visible = false
		local v103 = p100._free
		local v104 = v102.img
		table.insert(v103, v104)
		local v105 = p100._spare
		table.insert(v105, v102)
	end
	table.clear(p100._live)
	if p100._conn then
		p100._conn:Disconnect()
		p100._conn = nil
	end
end
function v_u_8.Count(p106) -- name: Count
	return #p106._live
end
return v2