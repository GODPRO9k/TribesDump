local v1 = game:GetService("RunService")
local v2 = require(script.Parent.Config)
local v_u_3 = {}
local v4 = v1:IsStudio() or game.PlaceId == v2.STAGING_PLACE_ID
v_u_3.BUDGET = 12
v_u_3.MAX_ITEMS = 6
v_u_3.MAX_AMMO_BUNDLES = 3
v_u_3.DEFAULT_AMMO_BUNDLES = 2
v_u_3.AMMO_TYPES = { "arrows", "shot" }
local v5 = {
	["arrows"] = table.freeze({
		["id"] = "arrows",
		["name"] = "Arrows",
		["perBundle"] = 12,
		["points"] = 1,
		["description"] = "12 arrows for bows and crossbows."
	}),
	["shot"] = table.freeze({
		["id"] = "shot",
		["name"] = "Bullets",
		["perBundle"] = 6,
		["points"] = 1,
		["description"] = "6 bullets for the musket, flintlock and blunderbuss."
	}),
	["fire_arrows"] = table.freeze({
		["id"] = "fire_arrows",
		["name"] = "Fire Arrows",
		["perBundle"] = 6,
		["points"] = 2,
		["description"] = "6 burning arrows for bows and crossbows, fired before your plain arrows. A hit sets the target on fire.",
		["as"] = "arrows",
		["burn"] = nil,
		["patch"] = nil,
		["unlock"] = true,
		["role"] = "Burning",
		["burn"] = table.freeze({
			["damage"] = 5,
			["ticks"] = 3,
			["interval"] = 0.5
		}),
		["patch"] = table.freeze({
			["radius"] = 3.5,
			["duration"] = 1.5
		})
	})
}
local v6 = v_u_3.AMMO_TYPES
table.insert(v6, "fire_arrows")
v_u_3.AMMO = table.freeze(v5)
local v_u_7 = {}
for _, v8 in v_u_3.AMMO_TYPES do
	local v9 = v_u_3.AMMO[v8]
	if not v9.as then
		continue
	end
	v_u_7[v9.as] = v_u_7[v9.as] or {}
	local v10 = v_u_7[v9.as]
	table.insert(v10, v8)
end
local v_u_11 = table.freeze({})
function v_u_3.AltAmmo(p12) -- name: AltAmmo
	-- upvalues: (copy) v_u_7, (copy) v_u_11
	return type(p12) == "string" and v_u_7[p12] or v_u_11
end
local v_u_13 = {}
for _, v14 in v_u_3.AMMO_TYPES do
	if not v_u_3.AMMO[v14].unlock then
		continue
	end
	table.insert(v_u_13, v14)
end
table.freeze(v_u_13)
function v_u_3.UnlockAmmo() -- name: UnlockAmmo
	-- upvalues: (copy) v_u_13
	return v_u_13
end
v_u_3.CATEGORIES = {
	"bow",
	"gun",
	"melee",
	"throwable",
	"utility",
	"healing",
	"armor"
}
v_u_3.CATEGORY_NAMES = {
	["bow"] = "Bows",
	["gun"] = "Powder guns",
	["melee"] = "Melee",
	["throwable"] = "Throwables",
	["utility"] = "Utility",
	["healing"] = "Healing",
	["armor"] = "Armor"
}
v_u_3.DEFAULT_LOADOUT = table.freeze({
	["items"] = nil,
	["armor"] = "hide_armor",
	["ammo"] = nil,
	["items"] = table.freeze({ "bronze_sword", "short_bow", "bandage" }),
	["ammo"] = table.freeze({
		["arrows"] = 3
	})
})
v_u_3.SLOTS = {
	"primary",
	"secondary",
	"melee",
	"utility"
}
v_u_3.SLOT_INDEX = {
	["primary"] = 1,
	["secondary"] = 2,
	["melee"] = 3,
	["utility"] = 4
}
v_u_3.SLOT_NAMES = {
	["primary"] = "Primary",
	["secondary"] = "Secondary",
	["melee"] = "Melee",
	["utility"] = "Utility"
}
v_u_3.STARTER_LOADOUT = table.freeze({
	["primary"] = "short_bow",
	["secondary"] = "throwing_knives",
	["melee"] = "bronze_sword",
	["utility"] = "fire_bomb"
})
v_u_3.STAT_BARS = {
	{
		["key"] = "damage",
		["label"] = "Damage"
	},
	{
		["key"] = "rate",
		["label"] = "Speed"
	},
	{
		["key"] = "range",
		["label"] = "Range"
	},
	{
		["key"] = "mobility",
		["label"] = "Mobility"
	}
}
v_u_3.KINDS = {
	"Bow",
	"Crossbow",
	"Musket",
	"Pistol",
	"Blunderbuss",
	"Knives",
	"Javelin",
	"Sling",
	"Sword",
	"Axe",
	"Spear",
	"Dagger",
	"Club",
	"Bomb",
	"Herbs",
	"Trap",
	"Armor",
	"Horn",
	"Shield",
	"Gauntlets",
	"Scythe",
	"Katana",
	"Hatchets"
}
local v_u_15 = {
	{
		["id"] = "short_bow",
		["name"] = "Wood Bow",
		["category"] = "bow",
		["points"] = 3,
		["hotbar"] = true,
		["slot"] = "primary",
		["kind"] = "Bow",
		["role"] = "Skirmisher",
		["description"] = "A quick-drawing bow. Hold to draw, release to shoot; arrows drop over distance. Uses arrows.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 4.5,
			["rate"] = 8,
			["range"] = 6.5,
			["mobility"] = 8
		},
		["details"] = {
			{ "Damage", "40 (70 head)" },
			{ "Draw", "0.5 s" },
			{ "Ammo", "arrows" }
		},
		["tuning"] = {
			["ammo"] = "arrows",
			["damage"] = 40,
			["damageMin"] = 8,
			["drawTime"] = 0.5,
			["speedMin"] = 120,
			["speedMax"] = 250,
			["gravity"] = 55,
			["radius"] = 0.3,
			["cooldown"] = 0.15,
			["tapCooldown"] = 0.35,
			["headshotMult"] = 1.75,
			["aimFov"] = 55,
			["drawSpeedMult"] = 0.8,
			["speedMult"] = 1,
			["projectile"] = "Arrow",
			["range"] = 400
		}
	},
	{
		["id"] = "longbow",
		["name"] = "Headhunter",
		["category"] = "bow",
		["points"] = 5,
		["hotbar"] = true,
		["slot"] = "primary",
		["kind"] = "Bow",
		["role"] = "Sniper",
		["description"] = "A long-range bow with a heavy draw. A fully drawn headshot kills. Aim to zoom. Uses arrows.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 8.5,
			["rate"] = 3,
			["range"] = 10,
			["mobility"] = 4.5
		},
		["details"] = {
			{ "Damage", "72 (144 head)" },
			{ "Draw", "1.1 s" },
			{ "Ammo", "arrows" }
		},
		["tuning"] = {
			["ammo"] = "arrows",
			["damage"] = 72,
			["damageMin"] = 10,
			["drawTime"] = 1.1,
			["speedMin"] = 160,
			["speedMax"] = 380,
			["gravity"] = 32,
			["radius"] = 0.28,
			["cooldown"] = 0.3,
			["tapCooldown"] = 0.6,
			["headshotMult"] = 2,
			["aimFov"] = 32,
			["drawSpeedMult"] = 0.55,
			["speedMult"] = 0.95,
			["projectile"] = "Arrow",
			["range"] = 600
		}
	},
	{
		["id"] = "crossbow",
		["name"] = "Crossbow",
		["category"] = "bow",
		["points"] = 4,
		["hotbar"] = true,
		["slot"] = "primary",
		["kind"] = "Crossbow",
		["role"] = "Marksman",
		["description"] = "Fires a heavy bolt instantly, even while moving. Reloads after every shot. Uses arrows.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 6.5,
			["rate"] = 3.5,
			["range"] = 8,
			["mobility"] = 7
		},
		["details"] = {
			{ "Damage", "50 (90 head)" },
			{ "Reload", "1.5 s" },
			{ "Ammo", "arrows" }
		},
		["tuning"] = {
			["ammo"] = "arrows",
			["damage"] = 50,
			["magazine"] = 1,
			["reloadTime"] = 1.5,
			["fireInterval"] = 0.2,
			["speed"] = 320,
			["gravity"] = 28,
			["radius"] = 0.28,
			["headshotMult"] = 1.8,
			["aimFov"] = 48,
			["speedMult"] = 0.95,
			["aimSpeedMult"] = 0.85,
			["projectile"] = "Bolt",
			["range"] = 500
		}
	},
	{
		["id"] = "musket",
		["name"] = "Musket",
		["category"] = "gun",
		["points"] = 5,
		["hotbar"] = true,
		["slot"] = "primary",
		["kind"] = "Musket",
		["role"] = "Heavy",
		["description"] = "One fast, heavy shot that crosses the map. Aim to steady it. Slow reload. Uses shot.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 9.5,
			["rate"] = 1.5,
			["range"] = 9.5,
			["mobility"] = 5
		},
		["details"] = {
			{ "Damage", "85 (136 head)" },
			{ "Reload", "2.4 s" },
			{ "Ammo", "shot" }
		},
		["tuning"] = {
			["ammo"] = "shot",
			["damage"] = 85,
			["magazine"] = 1,
			["reloadTime"] = 2.4,
			["fireInterval"] = 0.3,
			["speed"] = 900,
			["gravity"] = 12,
			["radius"] = 0.22,
			["headshotMult"] = 1.6,
			["spreadHip"] = 3.2,
			["spreadAim"] = 0.25,
			["falloff"] = nil,
			["aimFov"] = 40,
			["speedMult"] = 0.92,
			["aimSpeedMult"] = 0.6,
			["reloadSpeedMult"] = 0.75,
			["kick"] = 11,
			["climb"] = 3.25,
			["shake"] = 0.5,
			["projectile"] = "Ball",
			["range"] = 600,
			["falloff"] = {
				["start"] = 140,
				["finish"] = 320,
				["minMult"] = 0.7
			}
		}
	},
	{
		["id"] = "blunderbuss",
		["name"] = "Blunderbuss",
		["category"] = "gun",
		["points"] = 4,
		["hotbar"] = true,
		["slot"] = "primary",
		["kind"] = "Blunderbuss",
		["role"] = "Brawler",
		["description"] = "A wide cone of pellets: lethal point-blank, weak at range. Uses shot.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 9,
			["rate"] = 3,
			["range"] = 2.5,
			["mobility"] = 7
		},
		["details"] = {
			{ "Damage", "8 \195\151 13" },
			{ "Reload", "1.5 s" },
			{ "Ammo", "shot" }
		},
		["tuning"] = {
			["ammo"] = "shot",
			["damage"] = 13,
			["pellets"] = 8,
			["spread"] = 6.5,
			["spreadAim"] = 4.5,
			["magazine"] = 1,
			["reloadTime"] = 1.5,
			["fireInterval"] = 0.3,
			["speed"] = 420,
			["gravity"] = 20,
			["radius"] = 0.3,
			["headshotMult"] = 1.5,
			["falloff"] = nil,
			["aimFov"] = 60,
			["speedMult"] = 1,
			["aimSpeedMult"] = 0.8,
			["kick"] = 13,
			["climb"] = 3.9,
			["shake"] = 0.6,
			["knockback"] = 18,
			["projectile"] = "Pellet",
			["range"] = 90,
			["falloff"] = {
				["start"] = 14,
				["finish"] = 45,
				["minMult"] = 0.25
			}
		}
	},
	{
		["id"] = "throwing_knives",
		["name"] = "Throwing Knives",
		["category"] = "throwable",
		["points"] = 2,
		["hotbar"] = true,
		["slot"] = "secondary",
		["kind"] = "Knives",
		["role"] = "Finisher",
		["description"] = "Fast, flat throws. Five knives per round.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 4,
			["rate"] = 9,
			["range"] = 5.5,
			["mobility"] = 9
		},
		["details"] = {
			{ "Damage", "30 (45 head)" },
			{ "Knives", "5 per round" },
			{ "Rate", "0.28 s" }
		},
		["tuning"] = {
			["damage"] = 30,
			["charges"] = 5,
			["fireInterval"] = 0.28,
			["speed"] = 240,
			["gravity"] = 30,
			["radius"] = 0.3,
			["headshotMult"] = 1.5,
			["speedMult"] = 1.05,
			["projectile"] = "Knife",
			["range"] = 300
		}
	},
	{
		["id"] = "flintlock",
		["name"] = "Flintlock",
		["category"] = "gun",
		["points"] = 3,
		["hotbar"] = true,
		["slot"] = "secondary",
		["kind"] = "Pistol",
		["role"] = "Duelist",
		["description"] = "A single-shot pistol. Hits hard and fast; reloads after every shot. Uses shot.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 6,
			["rate"] = 4.5,
			["range"] = 6.5,
			["mobility"] = 9
		},
		["details"] = {
			{ "Damage", "42 (76 head)" },
			{ "Reload", "1.4 s" },
			{ "Ammo", "shot" }
		},
		["tuning"] = {
			["ammo"] = "shot",
			["damage"] = 42,
			["magazine"] = 1,
			["reloadTime"] = 1.4,
			["fireInterval"] = 0.2,
			["speed"] = 700,
			["gravity"] = 20,
			["radius"] = 0.25,
			["headshotMult"] = 1.8,
			["spreadHip"] = 1.4,
			["spreadAim"] = 0.3,
			["falloff"] = nil,
			["aimFov"] = 55,
			["speedMult"] = 1.05,
			["aimSpeedMult"] = 0.85,
			["kick"] = 7,
			["climb"] = 1.95,
			["shake"] = 0.35,
			["projectile"] = "Ball",
			["range"] = 400,
			["falloff"] = {
				["start"] = 60,
				["finish"] = 160,
				["minMult"] = 0.6
			}
		}
	},
	{
		["id"] = "javelins",
		["name"] = "Javelins",
		["category"] = "throwable",
		["points"] = 2,
		["hotbar"] = true,
		["slot"] = "secondary",
		["kind"] = "Javelin",
		["role"] = "Impact",
		["description"] = "Heavy throwing spears. Wind up for more power; hits knock enemies back. Three per round.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 8,
			["rate"] = 2.5,
			["range"] = 7,
			["mobility"] = 7
		},
		["details"] = {
			{ "Damage", "35\226\128\14755 (88 head)" },
			{ "Javelins", "3 per round" },
			{ "Kill", "2 body" }
		},
		["tuning"] = {
			["damage"] = 55,
			["damageMin"] = 35,
			["drawTime"] = 0.45,
			["charges"] = 3,
			["speedMin"] = 95,
			["speedMax"] = 175,
			["gravity"] = 62,
			["radius"] = 0.45,
			["cooldown"] = 0.45,
			["headshotMult"] = 1.6,
			["knockback"] = 32,
			["drawSpeedMult"] = 0.75,
			["speedMult"] = 1,
			["projectile"] = "Javelin",
			["range"] = 400
		}
	},
	{
		["id"] = "sling",
		["name"] = "Sling",
		["category"] = "throwable",
		["points"] = 1,
		["hotbar"] = true,
		["slot"] = "secondary",
		["kind"] = "Sling",
		["role"] = "Harasser",
		["description"] = "Lobbed stones that arc over cover. Twelve per round.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 4,
			["rate"] = 7,
			["range"] = 7,
			["mobility"] = 9
		},
		["details"] = {
			{ "Damage", "26 (46 head)" },
			{ "Stones", "12 per round" },
			{ "Rate", "0.45 s" }
		},
		["tuning"] = {
			["damage"] = 26,
			["charges"] = 12,
			["cooldown"] = 0.45,
			["speed"] = 150,
			["gravity"] = 85,
			["radius"] = 0.35,
			["headshotMult"] = 1.75,
			["speedMult"] = 1.05,
			["projectile"] = "Stone",
			["range"] = 350
		}
	},
	{
		["id"] = "bolas",
		["name"] = "Bolas",
		["category"] = "throwable",
		["points"] = 2,
		["hotbar"] = true,
		["slot"] = "secondary",
		["kind"] = "Knives",
		["role"] = "Snare",
		["description"] = "A spinning throw that tangles the legs: the enemy it hits is slowed and can\'t slide. Two per round.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 1.5,
			["rate"] = 4,
			["range"] = 4.5,
			["mobility"] = 9
		},
		["details"] = {
			{ "Slow", "to 40% for 1.5 s" },
			{ "Damage", "12" },
			{ "Bolas", "2 per round" }
		},
		["tuning"] = {
			["damage"] = 12,
			["charges"] = 2,
			["fireInterval"] = 0.7,
			["speed"] = 150,
			["gravity"] = 45,
			["radius"] = 0.7,
			["headshotMult"] = 1,
			["slow"] = nil,
			["speedMult"] = 1.05,
			["projectile"] = "Bolas",
			["range"] = 160,
			["slow"] = {
				["mult"] = 0.4,
				["duration"] = 1.5
			}
		}
	},
	{
		["id"] = "harpoon",
		["name"] = "Harpoon",
		["category"] = "throwable",
		["points"] = 4,
		["hotbar"] = true,
		["slot"] = "secondary",
		["kind"] = "Javelin",
		["role"] = "Hook",
		["description"] = "Wind it up and hurl it: the enemy it hits is dragged toward you. Slow to ready again. Three per round.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 5.5,
			["rate"] = 2,
			["range"] = 5.5,
			["mobility"] = 7
		},
		["details"] = {
			{ "Damage", "38\226\128\14745 (68 head)" },
			{ "Pull", "11 studs" },
			{ "Wind-up", "0.6 s" },
			{ "Harpoons", "3 per round" }
		},
		["tuning"] = {
			["damage"] = 45,
			["damageMin"] = 30,
			["drawTime"] = 0.6,
			["minCharge"] = 0.5,
			["charges"] = 3,
			["cooldown"] = 1,
			["speedMin"] = 110,
			["speedMax"] = 160,
			["gravity"] = 55,
			["radius"] = 0.5,
			["headshotMult"] = 1.5,
			["drawSpeedMult"] = 0.7,
			["pull"] = nil,
			["speedMult"] = 0.95,
			["projectile"] = "Harpoon",
			["range"] = 220,
			["pull"] = {
				["distance"] = 11,
				["stop"] = 3.5
			}
		}
	},
	{
		["id"] = "chakram",
		["name"] = "Chakram",
		["category"] = "throwable",
		["points"] = 2,
		["hotbar"] = true,
		["slot"] = "secondary",
		["kind"] = "Knives",
		["role"] = "Trickshot",
		["description"] = "A bladed ring that flies out and comes back, cutting on both passes. Catch it to throw again at once; miss the catch and it takes a moment to pick up.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 3.5,
			["rate"] = 5,
			["range"] = 4.5,
			["mobility"] = 9
		},
		["details"] = {
			{ "Damage", "24 out, 24 back" },
			{ "Reach", "45 studs" },
			{ "Missed catch", "2 s" }
		},
		["tuning"] = {
			["damage"] = 24,
			["charges"] = 1,
			["fireInterval"] = 0.35,
			["speed"] = 110,
			["gravity"] = 0,
			["radius"] = 0.9,
			["headshotMult"] = 1,
			["returns"] = nil,
			["speedMult"] = 1.05,
			["projectile"] = "Chakram",
			["range"] = 45,
			["returns"] = {
				["range"] = 45,
				["catch"] = 4.5,
				["pickup"] = 2
			}
		}
	},
	{
		["id"] = "bronze_sword",
		["name"] = "Iron Sword",
		["category"] = "melee",
		["points"] = 3,
		["hotbar"] = true,
		["slot"] = "melee",
		["kind"] = "Sword",
		["role"] = "Balanced",
		["description"] = "A fast three-hit combo; the third hit lands hardest. Hold aim to block.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 6,
			["rate"] = 7,
			["range"] = 3,
			["mobility"] = 8
		},
		["details"] = {
			{ "Damage", "30 / 30 / 41" },
			{ "Block", "60% melee, 40% ranged" },
			{ "Kill", "3-hit combo" }
		},
		["tuning"] = {
			["damage"] = 30,
			["combo"] = nil,
			["cooldown"] = 0.42,
			["comboWindow"] = 0.95,
			["range"] = 9.5,
			["arc"] = 70,
			["maxTargets"] = 2,
			["knockback"] = 14,
			["block"] = nil,
			["speedMult"] = 1.05,
			["combo"] = { 1, 1, 1.35 },
			["block"] = {
				["melee"] = 0.6,
				["ranged"] = 0.4,
				["speedMult"] = 0.6
			}
		}
	},
	{
		["id"] = "battle_axe",
		["name"] = "Battle Axe",
		["category"] = "melee",
		["points"] = 4,
		["hotbar"] = true,
		["slot"] = "melee",
		["kind"] = "Axe",
		["role"] = "Bruiser",
		["description"] = "Heavy chops. Hold aim to wind up an overhead strike that nearly halves a foe.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 9,
			["rate"] = 3.5,
			["range"] = 3.2,
			["mobility"] = 6
		},
		["details"] = {
			{ "Damage", "44 / 56 (heavy 80)" },
			{ "Wind-up", "0.7 s" },
			{ "Kill", "2 chops" }
		},
		["tuning"] = {
			["damage"] = 44,
			["combo"] = nil,
			["cooldown"] = 0.78,
			["comboWindow"] = 1.3,
			["range"] = 10,
			["arc"] = 60,
			["maxTargets"] = 2,
			["knockback"] = 22,
			["heavy"] = nil,
			["speedMult"] = 0.95,
			["combo"] = { 1, 1.28 },
			["heavy"] = {
				["damage"] = 80,
				["charge"] = 0.7,
				["cooldown"] = 1.2,
				["knockback"] = 50,
				["range"] = 11,
				["speedMult"] = 0.5
			}
		}
	},
	{
		["id"] = "spear",
		["name"] = "Spear",
		["category"] = "melee",
		["points"] = 4,
		["hotbar"] = true,
		["slot"] = "melee",
		["kind"] = "Spear",
		["role"] = "Reach",
		["description"] = "The longest reach of any melee weapon. Hold aim to charge a lunge, release to dash forward.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 6.5,
			["rate"] = 5,
			["range"] = 5,
			["mobility"] = 7.5
		},
		["details"] = {
			{ "Damage", "34 (lunge 55)" },
			{ "Reach", "13" },
			{ "Kill", "3 pokes / lunge + 2" }
		},
		["tuning"] = {
			["damage"] = 34,
			["combo"] = nil,
			["cooldown"] = 0.5,
			["comboWindow"] = 1.1,
			["range"] = 13,
			["arc"] = 30,
			["maxTargets"] = 2,
			["knockback"] = 12,
			["lunge"] = nil,
			["speedMult"] = 1,
			["combo"] = { 1, 1 },
			["lunge"] = {
				["damage"] = 55,
				["charge"] = 0.6,
				["cooldown"] = 1.5,
				["speed"] = 72,
				["distance"] = 16,
				["range"] = 14,
				["knockback"] = 38,
				["speedMult"] = 0.55
			}
		}
	},
	{
		["id"] = "obsidian_dagger",
		["name"] = "Diamond Dagger",
		["category"] = "melee",
		["points"] = 2,
		["hotbar"] = true,
		["slot"] = "melee",
		["kind"] = "Dagger",
		["role"] = "Assassin",
		["description"] = "Very fast stabs and a lighter step. Hits from behind deal 2.5\195\151 damage.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 4.5,
			["rate"] = 10,
			["range"] = 2,
			["mobility"] = 10
		},
		["details"] = {
			{ "Damage", "25 (backstab 62)" },
			{ "Rate", "0.28 s" },
			{ "Kill", "4 stabs / 2 backstabs" }
		},
		["tuning"] = {
			["damage"] = 25,
			["combo"] = nil,
			["cooldown"] = 0.28,
			["comboWindow"] = 0.7,
			["range"] = 7.5,
			["arc"] = 55,
			["maxTargets"] = 1,
			["knockback"] = 5,
			["backstabMult"] = 2.5,
			["backstabAngle"] = 70,
			["speedMult"] = 1.12,
			["combo"] = { 1, 1 }
		}
	},
	{
		["id"] = "war_club",
		["name"] = "Hammer",
		["category"] = "melee",
		["points"] = 3,
		["hotbar"] = true,
		["slot"] = "melee",
		["kind"] = "Club",
		["role"] = "Enforcer",
		["description"] = "Every hit knocks enemies back and staggers them (never twice in a row).",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 7.5,
			["rate"] = 5,
			["range"] = 3,
			["mobility"] = 7
		},
		["details"] = {
			{ "Damage", "36 / 44" },
			{ "Stagger", "0.45 s" },
			{ "Kill", "3 hits (1.1 s)" }
		},
		["tuning"] = {
			["damage"] = 36,
			["combo"] = nil,
			["cooldown"] = 0.55,
			["comboWindow"] = 1.2,
			["range"] = 9.5,
			["arc"] = 65,
			["maxTargets"] = 2,
			["knockback"] = 42,
			["stagger"] = nil,
			["speedMult"] = 1,
			["combo"] = { 1, 1.22 },
			["stagger"] = {
				["duration"] = 0.45,
				["speedMult"] = 0.45
			}
		}
	},
	{
		["id"] = "gauntlets",
		["name"] = "Gauntlets",
		["category"] = "melee",
		["points"] = 3,
		["hotbar"] = true,
		["slot"] = "melee",
		["kind"] = "Gauntlets",
		["role"] = "Brawler",
		["description"] = "The fastest melee weapon: a four-punch combo whose last punch staggers. Aim to dash forward with a punch.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 5.5,
			["rate"] = 10,
			["range"] = 2,
			["mobility"] = 9.5
		},
		["details"] = {
			{ "Damage", "20 / 20 / 20 / 32" },
			{ "4th punch", "staggers 0.3 s" },
			{ "Dash punch", "26, every 2.5 s" }
		},
		["tuning"] = {
			["damage"] = 20,
			["combo"] = nil,
			["cooldown"] = 0.22,
			["comboWindow"] = 0.6,
			["range"] = 7.5,
			["arc"] = 55,
			["maxTargets"] = 1,
			["knockback"] = 6,
			["finisher"] = nil,
			["lunge"] = nil,
			["speedMult"] = 1.08,
			["combo"] = {
				1,
				1,
				1,
				1.6
			},
			["finisher"] = {
				["stagger"] = nil,
				["knockback"] = 24,
				["stagger"] = {
					["duration"] = 0.3,
					["speedMult"] = 0.5
				}
			},
			["lunge"] = {
				["damage"] = 26,
				["charge"] = 0,
				["cooldown"] = 2.5,
				["speed"] = 60,
				["distance"] = 9,
				["range"] = 7,
				["knockback"] = 20,
				["speedMult"] = 1
			}
		}
	},
	{
		["id"] = "scythe",
		["name"] = "Scythe",
		["category"] = "melee",
		["points"] = 4,
		["hotbar"] = true,
		["slot"] = "melee",
		["kind"] = "Scythe",
		["role"] = "Reaper",
		["description"] = "Wide sweeps that cut everyone in front of you. Aim to dash through them with a reaping slash: a kill brings the dash back at once.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 8,
			["rate"] = 3,
			["range"] = 4.2,
			["mobility"] = 9
		},
		["details"] = {
			{ "Damage", "40 / 46, up to 3 at once" },
			{ "Reaping dash", "15 studs, 45 to each" },
			{ "Kill", "the dash is back" }
		},
		["tuning"] = {
			["damage"] = 40,
			["combo"] = nil,
			["cooldown"] = 0.85,
			["comboWindow"] = 1.4,
			["range"] = 11.5,
			["arc"] = 80,
			["maxTargets"] = 3,
			["knockback"] = 10,
			["lunge"] = nil,
			["speedMult"] = 0.96,
			["combo"] = { 1, 1.15 },
			["lunge"] = {
				["damage"] = 35,
				["charge"] = 0,
				["cooldown"] = 5,
				["speed"] = 75,
				["distance"] = 15,
				["range"] = 8,
				["arc"] = 70,
				["knockback"] = 16,
				["speedMult"] = 1,
				["through"] = true,
				["brake"] = true,
				["refreshOnKill"] = true
			}
		}
	},
	{
		["id"] = "katana",
		["name"] = "Katana",
		["category"] = "melee",
		["points"] = 4,
		["hotbar"] = true,
		["slot"] = "melee",
		["kind"] = "Katana",
		["role"] = "Duelist",
		["description"] = "Fast, clean cuts. Hold aim to parry: the next arrow flies back at its shooter, the next sword that hits you is staggered.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 5.5,
			["rate"] = 8,
			["range"] = 3.2,
			["mobility"] = 8.5
		},
		["details"] = {
			{ "Damage", "24 / 24 / 24 / 36" },
			{ "Parry", "up to 1.5 s, then 5 s" },
			{ "Kill", "4 cuts" }
		},
		["tuning"] = {
			["damage"] = 24,
			["combo"] = nil,
			["cooldown"] = 0.29,
			["comboWindow"] = 0.8,
			["range"] = 9,
			["arc"] = 55,
			["maxTargets"] = 1,
			["knockback"] = 8,
			["parry"] = nil,
			["speedMult"] = 1.06,
			["combo"] = {
				1,
				1,
				1,
				1.5
			},
			["parry"] = {
				["cooldown"] = 5,
				["maxHold"] = 1.5,
				["arc"] = 150,
				["grace"] = 0.1,
				["speedMult"] = 0.7,
				["stagger"] = nil,
				["stagger"] = {
					["duration"] = 0.5,
					["speedMult"] = 0.4
				}
			}
		}
	},
	{
		["id"] = "twin_hatchets",
		["name"] = "Twin Hatchets",
		["category"] = "melee",
		["points"] = 3,
		["hotbar"] = true,
		["slot"] = "melee",
		["kind"] = "Hatchets",
		["role"] = "Skirmisher",
		["description"] = "A hatchet in each hand: quick alternating chops. Aim to throw one; walk over it to pick it back up (or it comes back after a few seconds).",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 5,
			["rate"] = 9,
			["range"] = 6,
			["mobility"] = 8.5
		},
		["details"] = {
			{ "Damage", "21 / 21 / 21 / 29" },
			{ "Throw", "40 (head 60)" },
			{ "Back", "pick up or 6 s" }
		},
		["tuning"] = {
			["damage"] = 21,
			["combo"] = nil,
			["cooldown"] = 0.27,
			["comboWindow"] = 0.7,
			["range"] = 7.5,
			["arc"] = 60,
			["maxTargets"] = 1,
			["knockback"] = 6,
			["oneHanded"] = nil,
			["throw"] = nil,
			["speedMult"] = 1.06,
			["combo"] = {
				1,
				1,
				1,
				1.4
			},
			["oneHanded"] = {
				["cooldown"] = 0.42,
				["combo"] = nil,
				["combo"] = { 1, 1 }
			},
			["throw"] = {
				["damage"] = 40,
				["speed"] = 120,
				["gravity"] = 45,
				["radius"] = 0.6,
				["headshotMult"] = 1.5,
				["knockback"] = 8,
				["range"] = 170,
				["cooldown"] = 0.45,
				["returnTime"] = 6,
				["pickup"] = 5
			}
		}
	},
	{
		["id"] = "shield",
		["name"] = "Shield",
		["category"] = "melee",
		["points"] = 3,
		["hotbar"] = true,
		["slot"] = "melee",
		["kind"] = "Shield",
		["role"] = "Bulwark",
		["description"] = "Hold aim to raise it: nothing shot or thrown gets through from the front, and most of a melee hit is stopped. Click to bash. Slow while raised; blasts go around it.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 2,
			["rate"] = 3,
			["range"] = 2.5,
			["mobility"] = 6
		},
		["details"] = {
			{ "Block", "all shots, 60% melee" },
			{ "Covers", "100\194\176 in front" },
			{ "Bash", "18 + knockback" }
		},
		["tuning"] = {
			["damage"] = 18,
			["combo"] = nil,
			["cooldown"] = 1.2,
			["comboWindow"] = 0.5,
			["range"] = 8,
			["arc"] = 80,
			["maxTargets"] = 1,
			["knockback"] = 26,
			["block"] = nil,
			["speedMult"] = 0.98,
			["combo"] = { 1 },
			["block"] = {
				["melee"] = 0.6,
				["ranged"] = 1,
				["arc"] = 100,
				["explosion"] = 0,
				["speedMult"] = 0.7
			}
		}
	},
	{
		["id"] = "fire_bomb",
		["name"] = "Fireball",
		["category"] = "utility",
		["points"] = 2,
		["hotbar"] = true,
		["slot"] = "utility",
		["kind"] = "Bomb",
		["role"] = "Area",
		["description"] = "Bursts into flames on impact: splash damage, burning, and burning ground for 3 s.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 5,
			["rate"] = 2,
			["range"] = 5,
			["mobility"] = 8
		},
		["details"] = {
			{ "Damage", "38 + burn 15" },
			{ "Fire", "3 s" },
			{ "Charges", "2 per round" }
		},
		["tuning"] = {
			["charges"] = 2,
			["drawTime"] = 0.35,
			["speedMin"] = 60,
			["speedMax"] = 110,
			["gravity"] = 100,
			["radius"] = 0.5,
			["cooldown"] = 0.6,
			["splash"] = nil,
			["burn"] = nil,
			["fireZone"] = nil,
			["selfDamage"] = false,
			["projectile"] = "FireBomb",
			["speedMult"] = 1,
			["splash"] = {
				["damage"] = 38,
				["radius"] = 11,
				["minMult"] = 0.4,
				["knockback"] = 30
			},
			["burn"] = {
				["damage"] = 5,
				["ticks"] = 3,
				["interval"] = 0.5
			},
			["fireZone"] = {
				["radius"] = 9,
				["duration"] = 3
			}
		}
	},
	{
		["id"] = "smoke_bomb",
		["name"] = "Smoke Bomb",
		["category"] = "utility",
		["points"] = 1,
		["hotbar"] = true,
		["slot"] = "utility",
		["kind"] = "Bomb",
		["role"] = "Cover",
		["description"] = "Bursts into a thick cloud that blocks sight for everyone.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 0,
			["rate"] = 2,
			["range"] = 5,
			["mobility"] = 8
		},
		["details"] = {
			{ "Cloud", "13 studs, 7 s" },
			{ "Charges", "2 per round" }
		},
		["tuning"] = {
			["charges"] = 2,
			["drawTime"] = 0.3,
			["speedMin"] = 55,
			["speedMax"] = 105,
			["gravity"] = 100,
			["radius"] = 0.5,
			["cooldown"] = 0.6,
			["smoke"] = nil,
			["projectile"] = "SmokeBomb",
			["speedMult"] = 1,
			["smoke"] = {
				["radius"] = 13,
				["duration"] = 7
			}
		}
	},
	{
		["id"] = "bandage",
		["name"] = "Bandage",
		["category"] = "healing",
		["points"] = 1,
		["hotbar"] = true,
		["slot"] = "utility",
		["kind"] = "Herbs",
		["role"] = "First aid",
		["description"] = "Quick first aid: +15 health at once. Three per round; taking a hit interrupts it.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 0,
			["rate"] = 5,
			["range"] = 0,
			["mobility"] = 6
		},
		["details"] = {
			{ "Heal", "+15 at once" },
			{ "Use", "0.7 s" },
			{ "Charges", "3 per round" }
		},
		["tuning"] = {
			["charges"] = 3,
			["useTime"] = 0.7,
			["heal"] = 15,
			["healTime"] = 0,
			["useSpeedMult"] = 0.55,
			["interruptible"] = true,
			["speedMult"] = 1
		}
	},
	{
		["id"] = "healing_herbs",
		["name"] = "Apple",
		["category"] = "healing",
		["points"] = 2,
		["hotbar"] = true,
		["slot"] = "utility",
		["kind"] = "Herbs",
		["role"] = "Sustain",
		["description"] = "Eat to heal 40 over 3 seconds while you keep fighting. Two per round.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 0,
			["rate"] = 3,
			["range"] = 0,
			["mobility"] = 6
		},
		["details"] = {
			{ "Heal", "40 over 3 s" },
			{ "Use", "0.6 s" },
			{ "Charges", "2 per round" }
		},
		["tuning"] = {
			["charges"] = 2,
			["useTime"] = 0.6,
			["heal"] = 40,
			["healTime"] = 3,
			["useSpeedMult"] = 0.6,
			["interruptible"] = true,
			["speedMult"] = 1
		}
	},
	{
		["id"] = "healing_tonic",
		["name"] = "Golden Apple",
		["category"] = "healing",
		["points"] = 3,
		["hotbar"] = true,
		["slot"] = "utility",
		["kind"] = "Herbs",
		["role"] = "Recovery",
		["description"] = "Heals you to full over 3 seconds. One per round.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 0,
			["rate"] = 1.5,
			["range"] = 0,
			["mobility"] = 5
		},
		["details"] = {
			{ "Heal", "100 over 3 s" },
			{ "Use", "0.9 s" },
			{ "Charges", "1 per round" }
		},
		["tuning"] = {
			["charges"] = 1,
			["useTime"] = 0.9,
			["heal"] = 100,
			["healTime"] = 3,
			["useSpeedMult"] = 0.5,
			["interruptible"] = true,
			["speedMult"] = 1
		}
	},
	{
		["id"] = "healing_flask",
		["name"] = "Healing Flask",
		["category"] = "healing",
		["points"] = 3,
		["hotbar"] = true,
		["slot"] = "utility",
		["kind"] = "Bomb",
		["role"] = "Medic",
		["description"] = "Throw it to splash a healing pool: you and your allies inside regain 30 health over 3 seconds. One per round.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 0,
			["rate"] = 1.5,
			["range"] = 4,
			["mobility"] = 7
		},
		["details"] = {
			{ "Heal", "30 over 3 s, allies too" },
			{ "Pool", "10 studs" },
			{ "Charges", "1 per round" }
		},
		["tuning"] = {
			["charges"] = 1,
			["drawTime"] = 0.3,
			["speedMin"] = 55,
			["speedMax"] = 105,
			["gravity"] = 100,
			["radius"] = 0.5,
			["cooldown"] = 0.6,
			["healSplash"] = nil,
			["projectile"] = "Flask",
			["speedMult"] = 1,
			["healSplash"] = {
				["amount"] = 30,
				["time"] = 3,
				["radius"] = 10
			}
		}
	},
	{
		["id"] = "bear_trap",
		["name"] = "Snap Trap",
		["category"] = "utility",
		["points"] = 1,
		["hotbar"] = true,
		["slot"] = "utility",
		["kind"] = "Trap",
		["role"] = "Ambush",
		["description"] = "Set a hidden trap. The first enemy to step in is hurt and rooted in place.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 4,
			["rate"] = 2,
			["range"] = 1.5,
			["mobility"] = 7
		},
		["details"] = {
			{ "Damage", "40 + root 2 s" },
			{ "Hidden", "past 15 studs" },
			{ "Charges", "2 per round" }
		},
		["tuning"] = {
			["charges"] = 2,
			["useTime"] = 0.45,
			["damage"] = 40,
			["rootTime"] = 2,
			["armTime"] = 0.8,
			["triggerRadius"] = 3.2,
			["maxActive"] = 2,
			["placeRange"] = 7,
			["hiddenBeyond"] = 15,
			["speedMult"] = 1
		}
	},
	{
		["id"] = "caltrops",
		["name"] = "Caltrops",
		["hidden"] = true,
		["category"] = "utility",
		["points"] = 1,
		["hotbar"] = true,
		["slot"] = "utility",
		["kind"] = "Bomb",
		["role"] = "Denial",
		["description"] = "Toss a bag of iron spikes: they scatter into a patch that hurts and slows any enemy who walks in for 15 seconds. Everyone can see them; jump over them. Two per round.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 2,
			["rate"] = 2,
			["range"] = 4.5,
			["mobility"] = 8
		},
		["details"] = {
			{ "Patch", "7 studs, 15 s" },
			{ "Inside", "5 per 0.5 s, 50% slow" },
			{ "Charges", "2 per round" }
		},
		["tuning"] = {
			["charges"] = 2,
			["drawTime"] = 0.3,
			["speedMin"] = 50,
			["speedMax"] = 95,
			["gravity"] = 100,
			["radius"] = 0.5,
			["cooldown"] = 0.6,
			["caltrops"] = nil,
			["projectile"] = "Caltrops",
			["speedMult"] = 1,
			["caltrops"] = {
				["radius"] = 3.5,
				["duration"] = 15,
				["damage"] = 5,
				["interval"] = 0.5,
				["slow"] = 0.5,
				["linger"] = 0.35,
				["maxActive"] = 2
			}
		}
	},
	{
		["id"] = "beehive",
		["name"] = "Beehive",
		["category"] = "utility",
		["points"] = 2,
		["hotbar"] = true,
		["slot"] = "utility",
		["kind"] = "Bomb",
		["role"] = "Harass",
		["description"] = "Throw a beehive: the swarm chases the nearest enemy it can see for a few seconds and stings. Run, or break its line of sight. Two per round.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 3,
			["rate"] = 2,
			["range"] = 6,
			["mobility"] = 8
		},
		["details"] = {
			{ "Swarm", "4.5 s, chases" },
			{ "Stings", "4 per 0.4 s" },
			{ "Charges", "2 per round" }
		},
		["tuning"] = {
			["charges"] = 2,
			["drawTime"] = 0.3,
			["speedMin"] = 50,
			["speedMax"] = 95,
			["gravity"] = 100,
			["radius"] = 0.5,
			["cooldown"] = 0.6,
			["bees"] = nil,
			["projectile"] = "Beehive",
			["speedMult"] = 1,
			["bees"] = {
				["duration"] = 4.5,
				["seek"] = 32,
				["speed"] = 18,
				["reach"] = 4,
				["damage"] = 4,
				["interval"] = 0.4,
				["lose"] = 0.6,
				["maxActive"] = 2
			}
		}
	},
	{
		["id"] = "palisade",
		["name"] = "Palisade",
		["category"] = "utility",
		["points"] = 2,
		["hotbar"] = true,
		["slot"] = "utility",
		["kind"] = "Trap",
		["role"] = "Cover",
		["description"] = "Plant a wall of stakes where you look: it stops arrows, shot and anyone in the way until it is chopped down or falls. One per round.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 0,
			["rate"] = 1,
			["range"] = 2,
			["mobility"] = 7
		},
		["details"] = {
			{ "Wall", "6 wide, 6.5 tall" },
			{ "Health", "150, 20 s" },
			{ "Charges", "1 per round" }
		},
		["tuning"] = {
			["charges"] = 1,
			["useTime"] = 0.45,
			["placeRange"] = 8,
			["wall"] = nil,
			["speedMult"] = 1,
			["wall"] = {
				["width"] = 6,
				["height"] = 6.5,
				["health"] = 150,
				["duration"] = 20
			}
		}
	},
	{
		["id"] = "war_horn",
		["name"] = "War Horn",
		["category"] = "utility",
		["points"] = 2,
		["hotbar"] = true,
		["slot"] = "utility",
		["kind"] = "Horn",
		["role"] = "Rally",
		["description"] = "Blow it to mark every nearby enemy through walls for your tribe and speed your tribe up. It\'s loud: the enemy hears where you are. One per round.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 0,
			["rate"] = 1,
			["range"] = 6,
			["mobility"] = 8
		},
		["details"] = {
			{ "Marks enemies", "60 studs, 3 s" },
			{ "Tribe speed", "+10% for 4 s" },
			{ "Charges", "1 per round" }
		},
		["tuning"] = {
			["charges"] = 1,
			["useTime"] = 0.6,
			["useSpeedMult"] = 0.8,
			["interruptible"] = false,
			["horn"] = nil,
			["speedMult"] = 1,
			["horn"] = {
				["range"] = 60,
				["reveal"] = 3,
				["speedMult"] = 1.1,
				["speedTime"] = 4
			}
		}
	},
	{
		["id"] = "hide_armor",
		["name"] = "Leather Armor",
		["category"] = "armor",
		["points"] = 2,
		["hotbar"] = false,
		["slot"] = "armor",
		["kind"] = "Armor",
		["role"] = "Light",
		["description"] = "Light armor: absorbs damage before your health and takes 10% off ranged hits while it holds. Barely slows you.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 0,
			["rate"] = 0,
			["range"] = 0,
			["mobility"] = 9
		},
		["details"] = {
			{ "Armor", "25" },
			{ "Vs ranged", "\226\136\14610%" },
			{ "Speed", "\226\136\1463%" },
			{ "Knockback", "full" }
		},
		["tuning"] = {
			["armor"] = 25,
			["speedMult"] = 0.97,
			["knockbackMult"] = 1,
			["rangedReduction"] = 0.1
		}
	},
	{
		["id"] = "bone_armor",
		["name"] = "Iron Armor",
		["category"] = "armor",
		["points"] = 4,
		["hotbar"] = false,
		["slot"] = "armor",
		["kind"] = "Armor",
		["role"] = "Medium",
		["description"] = "Medium armor: takes 30% off ranged hits while it holds. A little slower, a little harder to knock back.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 0,
			["rate"] = 0,
			["range"] = 0,
			["mobility"] = 7.5
		},
		["details"] = {
			{ "Armor", "50" },
			{ "Vs ranged", "\226\136\14630%" },
			{ "Speed", "\226\136\1467%" },
			{ "Knockback", "\226\136\14615%" }
		},
		["tuning"] = {
			["armor"] = 50,
			["speedMult"] = 0.93,
			["knockbackMult"] = 0.85,
			["rangedReduction"] = 0.3
		}
	},
	{
		["id"] = "bronze_armor",
		["name"] = "Diamond Armor",
		["category"] = "armor",
		["points"] = 6,
		["hotbar"] = false,
		["slot"] = "armor",
		["kind"] = "Armor",
		["role"] = "Heavy",
		["description"] = "Heavy armor: takes 40% off ranged hits while it holds. Slow, but hard to knock back and it survives a sniper headshot.",
		["unlock"] = false,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["stats"] = {
			["damage"] = 0,
			["rate"] = 0,
			["range"] = 0,
			["mobility"] = 5.5
		},
		["details"] = {
			{ "Armor", "80" },
			{ "Vs ranged", "\226\136\14640%" },
			{ "Speed", "\226\136\14612%" },
			{ "Knockback", "\226\136\14630%" }
		},
		["tuning"] = {
			["armor"] = 80,
			["speedMult"] = 0.88,
			["knockbackMult"] = 0.7,
			["rangedReduction"] = 0.4
		}
	}
}
local v_u_16 = {}
for v17 = #v_u_15, 1, -1 do
	if v_u_15[v17].hidden then
		table.remove(v_u_15, v17)
	else
		if not v_u_15[v17].staging then
			continue
		end
		v_u_16[v_u_15[v17].id] = true
		if v4 then
			continue
		end
		table.remove(v_u_15, v17)
	end
end
local v_u_18 = {}
local v_u_19 = {}
local v_u_20 = {}
for v21, v22 in v_u_3.CATEGORIES do
	v_u_18[v22] = {}
	v_u_19[v22] = v21
end
local v_u_23 = {}
local v_u_24 = {
	["primary"] = {},
	["secondary"] = {},
	["melee"] = {},
	["utility"] = {}
}
for v25, v26 in v_u_15 do
	v_u_23[v26] = v25
end
table.sort(v_u_15, function(p27, p28)
	-- upvalues: (copy) v_u_19, (copy) v_u_23
	local v29 = v_u_19[p27.category] or 99
	local v30 = v_u_19[p28.category] or 99
	if v29 == v30 then
		return v_u_23[p27] < v_u_23[p28]
	else
		return v29 < v30
	end
end)
for _, v31 in v_u_15 do
	local v32 = v_u_18[v31.category]
	local v33 = v31.category
	local v34 = "unknown category " .. tostring(v33) .. " for " .. v31.id
	assert(v32, v34)
	local v35 = v31.points
	local v36
	if type(v35) == "number" then
		v36 = v31.points >= 0
	else
		v36 = false
	end
	local v37 = "points for " .. v31.id
	assert(v36, v37)
	v31.slotIndex = v_u_3.SLOT_INDEX[v31.slot]
	v_u_20[v31.id] = v31
	local v38 = v_u_18[v31.category]
	table.insert(v38, v31)
	if v_u_24[v31.slot] then
		local v39 = v_u_24[v31.slot]
		table.insert(v39, v31)
	end
	table.freeze(v31.stats)
	table.freeze(v31.tuning)
	table.freeze(v31)
end
table.freeze(v_u_15)
for _, v40 in v_u_18 do
	table.freeze(v40)
end
for _, v41 in v_u_24 do
	table.freeze(v41)
end
function v_u_3.Get(p42) -- name: Get
	-- upvalues: (copy) v_u_20
	if type(p42) == "string" then
		return v_u_20[p42]
	else
		return nil
	end
end
function v_u_3.All() -- name: All
	-- upvalues: (copy) v_u_15
	return v_u_15
end
function v_u_3.IsStagingOnly(p43) -- name: IsStagingOnly
	-- upvalues: (copy) v_u_16
	local v44
	if type(p43) == "string" then
		v44 = v_u_16[p43] == true
	else
		v44 = false
	end
	return v44
end
function v_u_3.ByCategory(p45) -- name: ByCategory
	-- upvalues: (copy) v_u_18
	return v_u_18[p45] or {}
end
function v_u_3.IsValid(p46) -- name: IsValid
	-- upvalues: (copy) v_u_20
	local v47
	if type(p46) == "string" then
		v47 = v_u_20[p46] ~= nil
	else
		v47 = false
	end
	return v47
end
function v_u_3.IsHotbar(p48) -- name: IsHotbar
	-- upvalues: (copy) v_u_20
	local v49 = type(p48) == "string" and v_u_20[p48] or nil
	local v50
	if v49 == nil then
		v50 = false
	else
		v50 = v49.hotbar
	end
	return v50
end
function v_u_3.IsArmor(p51) -- name: IsArmor
	-- upvalues: (copy) v_u_20
	local v52 = type(p51) == "string" and v_u_20[p51] or nil
	local v53
	if v52 == nil then
		v53 = false
	else
		v53 = v52.category == "armor"
	end
	return v53
end
function v_u_3.Cost(p54) -- name: Cost
	-- upvalues: (copy) v_u_20, (copy) v_u_3
	if type(p54) ~= "table" then
		return 0
	end
	local v55 = 0
	local v56 = p54.items
	if type(v56) == "table" then
		for _, v57 in p54.items do
			local v58
			if type(v57) == "string" then
				v58 = v_u_20[v57] or nil
			else
				v58 = nil
			end
			if not v58 then
				continue
			end
			v55 = v55 + v58.points
		end
	end
	local v59 = p54.armor
	local v60
	if type(v59) == "string" then
		v60 = v_u_20[p54.armor] or nil
	else
		v60 = nil
	end
	if v60 and v60.category == "armor" then
		v55 = v55 + v60.points
	end
	local v61 = p54.ammo
	if type(v61) == "table" then
		for v62, v63 in p54.ammo do
			local v64
			if type(v62) == "string" then
				v64 = v_u_3.AMMO[v62] or nil
			else
				v64 = nil
			end
			if not v64 or (type(v63) ~= "number" or v63 <= 0) then
				continue
			end
			v55 = v55 + v64.points * math.floor(v63)
		end
	end
	return v55
end
function v_u_3.AmmoOf(p65) -- name: AmmoOf
	-- upvalues: (copy) v_u_20, (copy) v_u_3
	local v66 = type(p65) == "string" and v_u_20[p65] or nil
	if v66 then
		v66 = v66.tuning.ammo
	end
	if type(v66) == "string" and v_u_3.AMMO[v66] then
		return v66
	else
		return nil
	end
end
function v_u_3.AmmoNeeded(p67) -- name: AmmoNeeded
	-- upvalues: (copy) v_u_3
	local v68 = {}
	if type(p67) == "table" then
		local v69 = p67.items
		if type(v69) == "table" then
			for _, v70 in p67.items do
				local v71 = v_u_3.AmmoOf(v70)
				if not v71 then
					continue
				end
				v68[v71] = true
				for _, v72 in v_u_3.AltAmmo(v71) do
					v68[v72] = true
				end
			end
		end
	end
	return v68
end
function v_u_3.MissingAmmo(p73) -- name: MissingAmmo
	-- upvalues: (copy) v_u_3
	local v74 = {}
	local v75
	if type(p73) == "table" then
		local v76 = p73.ammo
		v75 = type(v76) == "table" and (p73.ammo or {}) or {}
	else
		v75 = {}
	end
	for _, v77 in v_u_3.AMMO_TYPES do
		if v_u_3.AMMO[v77].as ~= nil or not v_u_3.AmmoNeeded(p73)[v77] then
			continue
		end
		local v78 = v75[v77]
		local v79
		if type(v78) == "number" then
			v79 = v75[v77] >= 1
		else
			v79 = false
		end
		if v79 then
			continue
		end
		local v80 = false
		for _, v81 in v_u_3.AltAmmo(v77) do
			if v80 then
				continue
			end
			local v82 = v75[v81]
			if type(v82) == "number" then
				v80 = v75[v81] >= 1
			else
				v80 = false
			end
		end
		if v80 then
			break
		end
		table.insert(v74, v77)
	end
	return v74
end
function v_u_3.AmmoRounds(p83, p84) -- name: AmmoRounds
	-- upvalues: (copy) v_u_3
	local v85 = v_u_3.AMMO[p84]
	local v86
	if type(p83) == "table" then
		local v87 = p83.ammo
		v86 = type(v87) == "table" and (p83.ammo[p84] or 0) or 0
	else
		v86 = 0
	end
	if not v85 or type(v86) ~= "number" then
		return 0
	end
	local v88 = math.floor(v86)
	return math.max(0, v88) * v85.perBundle
end
function v_u_3.FromSlots(p89) -- name: FromSlots
	-- upvalues: (copy) v_u_3, (copy) v_u_20
	local v90 = {}
	if type(p89) == "table" then
		for _, v91 in v_u_3.SLOTS do
			local v92 = p89[v91]
			if type(v92) ~= "string" or (not v_u_20[v92] or (not v_u_20[v92].hotbar or table.find(v90, v92))) then
				continue
			end
			table.insert(v90, v92)
		end
	end
	return {
		["items"] = nil,
		["armor"] = false,
		["ammo"] = nil,
		["items"] = v90
	}
end
local function v_u_93() -- name: defaultCopy
	-- upvalues: (copy) v_u_3
	return {
		["items"] = table.clone(v_u_3.DEFAULT_LOADOUT.items),
		["armor"] = v_u_3.DEFAULT_LOADOUT.armor,
		["ammo"] = table.clone(v_u_3.DEFAULT_LOADOUT.ammo)
	}
end
function v_u_3.Validate(p94) -- name: Validate
	-- upvalues: (copy) v_u_93, (copy) v_u_3, (copy) v_u_20
	if type(p94) ~= "table" then
		return false, "BadShape", v_u_93()
	end
	local v95 = nil
	local v96 = p94.items
	if type(v96) ~= "table" then
		v95 = v95 or "BadShape"
		if p94.primary == nil and (p94.secondary == nil and (p94.melee == nil and p94.utility == nil)) then
			p94 = {
				["items"] = {},
				["armor"] = p94.armor,
				["ammo"] = p94.ammo
			}
		else
			p94 = v_u_3.FromSlots(p94)
		end
	end
	local v97 = {}
	local v98 = false
	local v99 = p94.armor
	if v99 ~= nil and v99 ~= false then
		if v_u_3.IsArmor(v99) then
			v98 = v99
		elseif not v95 then
			v95 = "BadArmor"
		end
	end
	for _, v100 in p94.items do
		local v101
		if type(v100) == "string" then
			v101 = v_u_20[v100] or nil
		else
			v101 = nil
		end
		if v101 then
			if v101.hotbar then
				if table.find(v97, v101.id) then
					if v95 then
						continue
					end
					v95 = "Duplicate"
				elseif #v97 >= v_u_3.MAX_ITEMS then
					if v95 then
						continue
					end
					v95 = "TooManyItems"
				else
					local v102 = v101.id
					table.insert(v97, v102)
				end
			else
				v95 = v95 or "NotHotbar"
				if v101.category ~= "armor" or v98 ~= false then
					continue
				end
				v98 = v101.id
			end
		else
			if v95 then
				continue
			end
			v95 = "UnknownItem"
		end
	end
	if #v97 == 0 then
		v95 = v95 or "Empty"
		return false, v95, v_u_93()
	end
	local v103 = {}
	local v104 = p94.ammo
	if type(v104) == "table" then
		for v105, v106 in p94.ammo do
			if type(v105) == "string" and v_u_3.AMMO[v105] then
				if type(v106) == "number" and v106 == v106 then
					local v107 = math.floor(v106)
					local v108 = v_u_3.MAX_AMMO_BUNDLES
					local v109 = math.clamp(v107, 0, v108)
					v95 = v109 ~= v106 and not v95 and "BadAmmo" or v95
					if v109 <= 0 then
						continue
					end
					v103[v105] = v109
				else
					if v95 then
						continue
					end
					v95 = "BadAmmo"
				end
			else
				if v95 then
					continue
				end
				v95 = "UnknownAmmo"
			end
		end
	elseif p94.ammo == nil then
		local v110 = v_u_3.AmmoNeeded({
			["items"] = v97
		})
		if next(v110) then
			v95 = v95 or "MissingAmmo"
			for _, v111 in v_u_3.AMMO_TYPES do
				if not v110[v111] or v_u_3.AMMO[v111].as ~= nil then
					continue
				end
				v103[v111] = v_u_3.DEFAULT_AMMO_BUNDLES
			end
		end
	elseif not v95 then
		v95 = "BadAmmo"
	end
	local v112 = {
		["items"] = v97,
		["armor"] = v98,
		["ammo"] = v103
	}
	if v_u_3.Cost(v112) > v_u_3.BUDGET then
		local v113 = v_u_3.AmmoNeeded(v112)
		v95 = v95 or "OverBudget"
		for v114 in v103 do
			if v113[v114] then
				continue
			end
			v103[v114] = nil
		end
		while v_u_3.Cost(v112) > v_u_3.BUDGET do
			local v115 = 1
			local v116 = nil
			for v117, v118 in v103 do
				if v115 >= v118 then
					continue
				end
				v116 = v117
				v115 = v118
			end
			if not v116 then
				break
			end
			v103[v116] = v115 - 1
		end
		while v_u_3.Cost(v112) > v_u_3.BUDGET and #v97 > 1 do
			table.remove(v97)
			local v119 = v_u_3.AmmoNeeded(v112)
			for v120 in v103 do
				if v119[v120] then
					continue
				end
				v103[v120] = nil
			end
		end
		if v_u_3.Cost(v112) > v_u_3.BUDGET then
			v112.armor = false
		end
		if v_u_3.Cost(v112) > v_u_3.BUDGET then
			table.clear(v103)
		end
		while v_u_3.Cost(v112) > v_u_3.BUDGET and #v97 > 1 do
			table.remove(v97)
		end
	end
	return v95 == nil, v95, v112
end
function v_u_3.BySlot(p121) -- name: BySlot
	-- upvalues: (copy) v_u_24
	return v_u_24[p121] or {}
end
function v_u_3.SlotOf(p122) -- name: SlotOf
	-- upvalues: (copy) v_u_20
	local v123 = v_u_20[p122]
	return v123 and v123.slot or nil
end
function v_u_3.IsStarter(p124) -- name: IsStarter
	-- upvalues: (copy) v_u_20
	return v_u_20[p124] ~= nil
end
function v_u_3.SanitizeLoadout(p125) -- name: SanitizeLoadout
	-- upvalues: (copy) v_u_3, (copy) v_u_20
	local v126 = table.clone(v_u_3.STARTER_LOADOUT)
	if type(p125) == "table" then
		for _, v127 in v_u_3.SLOTS do
			local v128 = p125[v127]
			local v129
			if type(v128) == "string" then
				v129 = v_u_20[v128] or nil
			else
				v129 = nil
			end
			if not v129 or v129.slot ~= v127 then
				continue
			end
			v126[v127] = v128
		end
	end
	return v126
end
return v_u_3