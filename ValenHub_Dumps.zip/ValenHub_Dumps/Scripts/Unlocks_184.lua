local v_u_1 = {}
local v2, v_u_3 = pcall(function()
	return require(script.Parent:WaitForChild("Weapons"))
end)
if not v2 then
	v_u_3 = nil
end
local v_u_4, v5 = pcall(function()
	return require(script.Parent:WaitForChild("Config"))
end)
if v_u_4 then
	if type(v5) == "table" then
		v_u_4 = game.PlaceId == v5.STAGING_PLACE_ID
	else
		v_u_4 = false
	end
end
v_u_1.EVERYTHING_OWNED = v_u_4
v_u_1.STARTERS = table.freeze({
	["short_bow"] = true,
	["bronze_sword"] = true,
	["throwing_knives"] = true,
	["bandage"] = true,
	["smoke_bomb"] = true,
	["sling"] = true,
	["war_club"] = true,
	["hide_armor"] = true
})
v_u_1.DEFAULT = table.freeze({
	["size"] = "medium"
})
v_u_1.ITEMS = table.freeze({
	["obsidian_dagger"] = {
		["size"] = "small"
	},
	["bear_trap"] = {
		["size"] = "small"
	},
	["healing_herbs"] = {
		["size"] = "small"
	},
	["javelins"] = {
		["size"] = "small"
	},
	["crossbow"] = {
		["size"] = "medium"
	},
	["spear"] = {
		["size"] = "medium"
	},
	["battle_axe"] = {
		["size"] = "medium"
	},
	["flintlock"] = {
		["size"] = "medium"
	},
	["blunderbuss"] = {
		["size"] = "medium"
	},
	["fire_bomb"] = {
		["size"] = "medium"
	},
	["bone_armor"] = {
		["size"] = "medium"
	},
	["longbow"] = {
		["size"] = "large"
	},
	["musket"] = {
		["size"] = "large"
	},
	["healing_tonic"] = {
		["size"] = "large"
	},
	["bronze_armor"] = {
		["size"] = "large"
	},
	["bolas"] = {
		["size"] = "small"
	},
	["harpoon"] = {
		["size"] = "large"
	},
	["healing_flask"] = {
		["size"] = "medium"
	},
	["war_horn"] = {
		["size"] = "small"
	},
	["shield"] = {
		["size"] = "large"
	},
	["palisade"] = {
		["size"] = "medium"
	},
	["chakram"] = {
		["size"] = "medium"
	},
	["fire_arrows"] = {
		["size"] = "small"
	},
	["caltrops"] = {
		["size"] = "small"
	},
	["gauntlets"] = {
		["size"] = "medium"
	},
	["scythe"] = {
		["size"] = "large"
	},
	["beehive"] = {
		["size"] = "small"
	},
	["twin_hatchets"] = {
		["size"] = "medium"
	},
	["katana"] = {
		["size"] = "large"
	}
})
v_u_1.DROPS = table.freeze({ table.freeze({
		["key"] = "drop_golden",
		["kind"] = "golden",
		["count"] = 1
	}), table.freeze({
		["key"] = "drop_golden5",
		["kind"] = "golden",
		["count"] = 5
	}) })
v_u_1.FIRST_DROP = table.freeze({
	["key"] = "drop_golden_first",
	["kind"] = "golden",
	["count"] = 1,
	["duration"] = 172800,
	["minMatches"] = 1
})
v_u_1.RESTORE_MIN_STREAK = 2
v_u_1.RESTORE_WINDOW = 86400
v_u_1.RESTORE = table.freeze({ table.freeze({
		["key"] = "streak_s",
		["max"] = 4
	}), table.freeze({
		["key"] = "streak_m",
		["max"] = 9
	}), table.freeze({
		["key"] = "streak_l",
		["max"] = 1000000000
	}) })
function v_u_1.IsAmmo(p6) -- name: IsAmmo
	-- upvalues: (ref) v_u_3
	local v7 = type(p6) == "string" and v_u_3
	if v7 then
		local v8 = v_u_3.AMMO
		if type(v8) == "table" then
			v7 = v_u_3.AMMO[p6]
		else
			v7 = false
		end
	end
	local v9
	if type(v7) == "table" then
		v9 = v7.unlock == true
	else
		v9 = false
	end
	return v9
end
local function v_u_12(p10) -- name: known
	-- upvalues: (ref) v_u_3, (copy) v_u_1
	if type(p10) ~= "string" then
		return false
	end
	if v_u_3 then
		local v11 = v_u_3.Get
		if type(v11) == "function" then
			return v_u_3.Get(p10) ~= nil and true or v_u_1.IsAmmo(p10)
		end
	end
	return v_u_1.STARTERS[p10] == true and true or v_u_1.ITEMS[p10] ~= nil
end
v_u_1.IsKnown = v_u_12
function v_u_1.IsStarter(p13) -- name: IsStarter
	-- upvalues: (copy) v_u_1
	local v14
	if type(p13) == "string" then
		v14 = v_u_1.STARTERS[p13] == true
	else
		v14 = false
	end
	return v14
end
function v_u_1.SizeOf(p15) -- name: SizeOf
	-- upvalues: (copy) v_u_1
	local v16
	if v_u_1.IsStarter(p15) then
		v16 = nil
	else
		v16 = type(p15) == "string" and v_u_1.ITEMS[p15] or v_u_1.DEFAULT
	end
	return not v16 and "starter" or v16.size
end
function v_u_1.Owns(p17, p18) -- name: Owns
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_12, (ref) v_u_3
	if type(p18) ~= "string" then
		return false
	end
	if v_u_1.STARTERS[p18] then
		return true
	end
	if v_u_4 and v_u_12(p18) then
		return true
	end
	if v_u_3 then
		local v19 = v_u_3.IsStagingOnly
		if type(v19) == "function" and v_u_3.IsStagingOnly(p18) then
			return true
		end
	end
	local v20
	if type(p17) == "table" then
		v20 = p17[p18]
	else
		v20 = false
	end
	local v21
	if type(v20) == "table" then
		local v22 = v20.level
		if type(v22) == "number" then
			v21 = v20.level >= 1
		else
			v21 = false
		end
	else
		v21 = false
	end
	return v21
end
function v_u_1.AllIds() -- name: AllIds
	-- upvalues: (ref) v_u_3, (copy) v_u_1
	local v23 = {}
	if v_u_3 then
		local v24 = v_u_3.All
		if type(v24) == "function" then
			for _, v25 in v_u_3.All() do
				local v26 = v25.id
				table.insert(v23, v26)
			end
			local v27 = v_u_3.UnlockAmmo
			if type(v27) == "function" then
				for _, v28 in v_u_3.UnlockAmmo() do
					table.insert(v23, v28)
				end
				return v23
			end
			return v23
		else
			for v31 in v_u_1.STARTERS do
				table.insert(v23, v31)
			end
			for v32 in v_u_1.ITEMS do
				table.insert(v23, v32)
			end
			table.sort(v23)
			return v23
		end
	else
		for v31 in v_u_1.STARTERS do
			table.insert(v23, v31)
		end
		for v32 in v_u_1.ITEMS do
			table.insert(v23, v32)
		end
		table.sort(v23)
		return v23
	end
end
function v_u_1.FirstLocked(p33, p34) -- name: FirstLocked
	-- upvalues: (copy) v_u_1
	if type(p34) ~= "table" then
		return nil
	end
	local v35 = p34.items
	if type(v35) == "table" then
		for v36 = 1, 16 do
			local v37 = p34.items[v36]
			if v37 ~= nil then
				if type(v37) ~= "string" or v_u_1.Owns(p33, v37) then
					continue
				end
				return v37
			end
		end
	end
	local v38 = p34.armor
	if type(v38) == "string" and not v_u_1.Owns(p33, p34.armor) then
		return p34.armor
	end
	local v39 = p34.ammo
	if type(v39) == "table" then
		for v40, v41 in p34.ammo do
			if type(v41) ~= "number" or (v41 < 1 or (not v_u_1.IsAmmo(v40) or v_u_1.Owns(p33, v40))) then
				continue
			end
			return v40
		end
	end
	return nil
end
function v_u_1.FilterLoadout(p42, p43) -- name: FilterLoadout
	-- upvalues: (copy) v_u_1, (ref) v_u_3
	local v44 = {}
	if type(p43) == "table" then
		local v45 = p43.items
		if type(v45) == "table" then
			for v46 = 1, 16 do
				local v47 = p43.items[v46]
				if v47 == nil then
					break
				end
				if type(v47) ~= "string" or not v_u_1.Owns(p42, v47) then
					continue
				end
				table.insert(v44, v47)
			end
		end
	end
	local v48
	if type(p43) == "table" then
		local v49 = p43.armor
		if type(v49) == "string" and v_u_1.Owns(p42, p43.armor) then
			v48 = p43.armor
		else
			v48 = false
		end
	else
		v48 = false
	end
	local v50 = nil
	if type(p43) == "table" then
		local v51 = p43.ammo
		if type(v51) == "table" then
			v50 = {}
			local v52 = nil
			if v_u_3 then
				local v53 = v_u_3.AmmoNeeded
				if type(v53) == "function" then
					v52 = v_u_3.AmmoNeeded({
						["items"] = v44
					})
				end
			end
			for v54, v55 in p43.ammo do
				if type(v54) ~= "string" or v52 ~= nil and not v52[v54] or v_u_1.IsAmmo(v54) and not v_u_1.Owns(p42, v54) then
					continue
				end
				v50[v54] = v55
			end
		end
	end
	return {
		["items"] = v44,
		["armor"] = v48,
		["ammo"] = v50
	}
end
function v_u_1.RestoreTier(p56) -- name: RestoreTier
	-- upvalues: (copy) v_u_1
	for _, v57 in v_u_1.RESTORE do
		if p56 > v57.max then
			continue
		end
		return v57
	end
	return v_u_1.RESTORE[#v_u_1.RESTORE]
end
function v_u_1.DropProduct(p58) -- name: DropProduct
	-- upvalues: (copy) v_u_1
	if p58 == v_u_1.FIRST_DROP.key then
		return v_u_1.FIRST_DROP
	end
	for _, v59 in v_u_1.DROPS do
		if v59.key ~= p58 then
			continue
		end
		return v59
	end
	return nil
end
function v_u_1.ProductKey(p60, p61) -- name: ProductKey
	if p60 == "unlock" then
		return "unlock_" .. p61
	else
		return p61
	end
end
function v_u_1.Cost(p62) -- name: Cost
	local v63, v64 = pcall(function()
		return require(script.Parent:WaitForChild("Shards"))
	end)
	return not v63 and 0 or v64.UnlockCost(p62)
end
return v_u_1