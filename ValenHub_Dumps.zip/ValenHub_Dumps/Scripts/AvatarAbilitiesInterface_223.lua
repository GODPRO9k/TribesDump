local v1 = game:GetService("Players")
local v2 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
local v3 = v2.getUserFlag("UserPlayerScriptsCCLIntegrationD")
local v_u_4 = v2.getUserFlag("UserPlayerScriptsPlayerControlState2")
local v_u_5 = v2.getUserFlag("UserPlayerScriptsTaskDeferSimulation")
local v_u_6 = v2.getUserFlag("UserPlayerScriptsImportWaitForAbilitiesFolder")
local v_u_7
if v_u_6 then
	v_u_7 = nil
else
	local function v_u_19(p8, p_u_9, p10) -- name: waitForChildren
		if #p_u_9 == 0 then
			return nil
		end
		for _, v11 in p_u_9 do
			local v12 = p8:FindFirstChild(v11)
			if not v12 then
				continue
			end
			return v12
		end
		local v_u_13 = coroutine.running()
		local v_u_14 = nil
		local v_u_15 = false
		local v17 = p8.ChildAdded:Connect(function(p16)
			-- upvalues: (copy) p_u_9, (ref) v_u_15, (ref) v_u_14, (copy) v_u_13
			if table.find(p_u_9, p16.Name) then
				if v_u_15 then
					return
				end
				v_u_15 = true
				v_u_14 = p16
				task.spawn(v_u_13)
			end
		end)
		local v18
		if p10 then
			v18 = task.delay(p10, function()
				-- upvalues: (ref) v_u_15, (ref) v_u_14, (copy) v_u_13
				if not v_u_15 then
					v_u_15 = true
					v_u_14 = nil
					task.spawn(v_u_13)
				end
			end)
		else
			v18 = nil
		end
		coroutine.yield()
		v17:Disconnect()
		if v18 and coroutine.status(v18) == "suspended" then
			task.cancel(v18)
		end
		return v_u_14
	end
	v_u_7 = function(p20, p21)
		-- upvalues: (copy) v_u_19
		if p20 then
			local v22
			if p21 then
				v22 = time() + p21
			else
				v22 = nil
			end
			local v23 = v_u_19
			local v24 = { "AbilityManagerActor", "Abilities" }
			local v25
			if v22 then
				local v26 = v22 - time()
				v25 = math.max(v26, 0)
			else
				v25 = nil
			end
			local v27 = v23(p20, v24, v25)
			if v27 then
				if v27.Name == "Abilities" then
					if v27:IsA("Folder") then
						return v27
					else
						return nil
					end
				else
					local v28
					if v22 then
						local v29 = v22 - time()
						v28 = math.max(v29, 0)
					else
						v28 = nil
					end
					local v30
					if v28 then
						v30 = v27:WaitForChild("Abilities", v28)
					else
						v30 = v27:WaitForChild("Abilities")
					end
					if v30 and v30:IsA("Folder") then
						return v30
					else
						return nil
					end
				end
			else
				return nil
			end
		else
			return nil
		end
	end
end
if not v3 then
	local v_u_31 = game:GetService("Players")
	local v32 = {}
	local v_u_33 = nil
	local v_u_34 = nil
	local v_u_35 = Instance.new("BindableEvent")
	local v_u_36 = nil
	local v_u_37 = false
	local function v_u_39(p38) -- name: characterAdded
		-- upvalues: (ref) v_u_33, (ref) v_u_34, (ref) v_u_36, (copy) v_u_35
		v_u_33 = nil
		v_u_34 = nil
		if v_u_36 then
			v_u_36:Disconnect()
			v_u_36 = nil
		end
		if p38 then
			v_u_33 = p38:FindFirstChild("AbilityManagerActor")
			v_u_34 = p38:FindFirstChildOfClass("Humanoid")
			while not v_u_34 do
				p38.ChildAdded:wait()
				v_u_34 = p38:FindFirstChildOfClass("Humanoid")
			end
			v_u_35:Fire()
			v_u_36 = v_u_34:GetPropertyChangedSignal("EvaluateStateMachine"):Connect(function()
				-- upvalues: (ref) v_u_35
				v_u_35:Fire()
			end)
		end
	end
	function v32.isEnabled() -- name: isEnabled
		-- upvalues: (ref) v_u_37, (copy) v_u_31, (copy) v_u_39, (ref) v_u_33, (ref) v_u_34
		if not v_u_37 then
			v_u_37 = true
			local v40 = v_u_31.LocalPlayer
			if v40 then
				v40.characterAdded:Connect(v_u_39)
				if v40.Character then
					v_u_39(v40.Character)
				end
			end
		end
		local v41 = v_u_33 ~= nil and v_u_34
		if v41 then
			v41 = not v_u_34.EvaluateStateMachine
		end
		return v41
	end
	function v32.GetEnabledChangedSignal() -- name: GetEnabledChangedSignal
		-- upvalues: (ref) v_u_37, (copy) v_u_31, (copy) v_u_39, (copy) v_u_35
		if not v_u_37 then
			v_u_37 = true
			local v42 = v_u_31.LocalPlayer
			if v42 then
				v42.characterAdded:Connect(v_u_39)
				if v42.Character then
					v_u_39(v42.Character)
				end
			end
		end
		return v_u_35.Event
	end
	return v32
end
local v_u_43 = {}
v_u_43.__index = v_u_43
local v_u_44 = {}
v1.PlayerRemoving:Connect(function(p45)
	-- upvalues: (copy) v_u_44
	wait(1)
	local v46 = v_u_44[p45.UserId]
	if v46 then
		v46:destroy()
		v_u_44[p45.UserId] = nil
	end
end)
local function v_u_51(p47) -- name: createAbilitiesByInputNameTable
	local v48 = {}
	for _, v49 in p47:GetChildren() do
		if not v49:IsA("Configuration") then
			continue
		end
		local v50 = v49:GetAttribute("InputName")
		if not v50 then
			continue
		end
		v48[v50] = v49
	end
	return v48
end
local function v_u_58(p52, p_u_53) -- name: notifyAbilitiesChanged
	local v_u_55 = p52.ChildAdded:Connect(function(p54)
		-- upvalues: (copy) p_u_53
		if p54:IsA("Configuration") then
			p_u_53(p54, "added")
		end
	end)
	local v_u_57 = p52.ChildRemoved:Connect(function(p56)
		-- upvalues: (copy) p_u_53
		if p56:IsA("Configuration") then
			p_u_53(p56, "removed")
		end
	end)
	return function()
		-- upvalues: (copy) v_u_55, (copy) v_u_57
		v_u_55:Disconnect()
		v_u_57:Disconnect()
	end
end
function v_u_43._new(p_u_59) -- name: _new
	-- upvalues: (copy) v_u_43, (copy) v_u_4, (copy) v_u_5
	local v60 = v_u_43
	local v_u_61 = setmetatable({}, v60)
	v_u_61._player = p_u_59
	v_u_61._data = {}
	v_u_61._character = nil
	v_u_61._humanoid = nil
	v_u_61._enabledChangedEvent = Instance.new("BindableEvent")
	v_u_61._abilitiesChangedEvent = Instance.new("BindableEvent")
	v_u_61._evaluateStateMachineChangedConnection = nil
	v_u_61._abilityChangedEvents = {}
	v_u_61._abilityChangedConnections = {}
	v_u_61._abilitiesByInputName = {}
	v_u_61._disconnectAbilitiesChanged = nil
	if v_u_4 and not v_u_5 then
		task.spawn(function()
			-- upvalues: (copy) v_u_61, (copy) p_u_59
			v_u_61._characterAddedConnection = p_u_59.CharacterAdded:Connect(function(p62)
				-- upvalues: (ref) v_u_61
				v_u_61:_onCharacterAdded(p62)
			end)
		end)
	else
		v_u_61._characterAddedConnection = p_u_59.CharacterAdded:Connect(function(p63)
			-- upvalues: (copy) v_u_61
			v_u_61:_onCharacterAdded(p63)
		end)
	end
	if p_u_59.Character then
		v_u_61:_onCharacterAdded(p_u_59.Character)
	end
	return v_u_61
end
local v_u_64 = nil
function v_u_43._avatarAbilities() -- name: _avatarAbilities
	-- upvalues: (ref) v_u_64
	if not v_u_64 then
		local v65 = game:GetService("ReplicatedStorage"):FindFirstChild("Packages")
		local v66
		if v65 then
			v66 = v65:FindFirstChild("AvatarAbilities")
		else
			v66 = nil
		end
		local v67
		if v66 then
			v67 = require(v66)
		else
			v67 = nil
		end
		v_u_64 = v67
		if not v_u_64 then
			v_u_64 = require("@rbx/AvatarAbilities")
		end
	end
	return v_u_64
end
function v_u_43.get(p68) -- name: get
	-- upvalues: (copy) v_u_44, (copy) v_u_43
	if not p68 or p68.UserId == 0 then
		return nil
	end
	local v69 = v_u_44[p68.UserId]
	if not v69 then
		v69 = v_u_43._new(p68)
		v_u_44[p68.UserId] = v69
	end
	return v69
end
function v_u_43._hookUpAbilityChangedEvent(p_u_70, p_u_71, p_u_72) -- name: _hookUpAbilityChangedEvent
	local v73 = p_u_70._abilitiesByInputName[p_u_71]
	if v73 then
		local v74 = v73:FindFirstChild("SyncedState")
		if v74 then
			if not p_u_70._abilityChangedConnections[p_u_72] then
				p_u_70._abilityChangedConnections[p_u_72] = {}
			end
			if p_u_70._abilityChangedConnections[p_u_72][p_u_71] then
				p_u_70._abilityChangedConnections[p_u_72][p_u_71]:Disconnect()
				p_u_70._abilityChangedConnections[p_u_72][p_u_71] = nil
			end
			p_u_70._abilityChangedConnections[p_u_72][p_u_71] = v74:GetAttributeChangedSignal(p_u_72):Connect(function()
				-- upvalues: (copy) p_u_70, (copy) p_u_72, (copy) p_u_71
				p_u_70._abilityChangedEvents[p_u_72][p_u_71]:Fire()
			end)
		end
	else
		return
	end
end
function v_u_43._onCharacterAdded(p_u_75, p_u_76) -- name: _onCharacterAdded
	-- upvalues: (copy) v_u_6, (ref) v_u_7, (copy) v_u_58, (copy) v_u_51
	p_u_75._humanoid = nil
	p_u_75._character = p_u_76
	p_u_75._abilitiesByInputName = {}
	p_u_75._data = {}
	if p_u_75._disconnectAbilitiesChanged then
		p_u_75._disconnectAbilitiesChanged()
		p_u_75._disconnectAbilitiesChanged = nil
	end
	for _, v77 in p_u_75._abilityChangedConnections do
		for _, v78 in v77 do
			v78:Disconnect()
		end
	end
	p_u_75._abilityChangedConnections = {}
	if p_u_75._evaluateStateMachineChangedConnection then
		p_u_75._evaluateStateMachineChangedConnection:Disconnect()
		p_u_75._evaluateStateMachineChangedConnection = nil
	end
	if p_u_75._character then
		task.spawn(function()
			-- upvalues: (ref) v_u_6, (copy) p_u_75, (copy) p_u_76, (ref) v_u_7, (ref) v_u_58, (ref) v_u_51
			local v_u_79
			if v_u_6 then
				v_u_79 = p_u_75._avatarAbilities().waitForAbilitiesFolder(p_u_76)
			else
				v_u_79 = v_u_7(p_u_76)
			end
			if v_u_79 and p_u_75._character == p_u_76 then
				p_u_75._humanoid = p_u_76:FindFirstChildOfClass("Humanoid")
				while not p_u_75._humanoid do
					p_u_76.ChildAdded:Wait()
					if p_u_75._character ~= p_u_76 then
						return
					end
					p_u_75._humanoid = p_u_76:FindFirstChildOfClass("Humanoid")
				end
				if p_u_75._evaluateStateMachineChangedConnection then
					p_u_75._evaluateStateMachineChangedConnection:Disconnect()
					p_u_75._evaluateStateMachineChangedConnection = nil
				end
				local function v_u_91() -- name: enabledChanged
					-- upvalues: (ref) p_u_75, (ref) v_u_58, (ref) v_u_79, (ref) v_u_51
					if p_u_75._disconnectAbilitiesChanged then
						p_u_75._disconnectAbilitiesChanged()
						p_u_75._disconnectAbilitiesChanged = nil
					end
					if p_u_75:isEnabled() then
						p_u_75._disconnectAbilitiesChanged = v_u_58(v_u_79, function(p80, p81)
							-- upvalues: (ref) p_u_75
							local v82 = p80:GetAttribute("InputName")
							if v82 then
								if p81 == "added" then
									p_u_75._abilitiesByInputName[v82] = p80
									for v83, v84 in p_u_75._abilityChangedEvents do
										if not v84[v82] then
											continue
										end
										p_u_75:_hookUpAbilityChangedEvent(v82, v83)
									end
								elseif p_u_75._abilitiesByInputName[v82] == p80 then
									p_u_75._abilitiesByInputName[v82] = nil
									for _, v85 in p_u_75._abilityChangedConnections do
										local v86 = v85[v82]
										if not v86 then
											continue
										end
										v86:Disconnect()
										v85[v82] = nil
									end
								end
								p_u_75._abilitiesChangedEvent:Fire()
							end
						end)
						p_u_75._abilitiesByInputName = v_u_51(v_u_79)
						p_u_75._abilitiesChangedEvent:Fire()
						for v87, v88 in p_u_75._abilityChangedEvents do
							for v89, v90 in v88 do
								v90:Fire()
								p_u_75:_hookUpAbilityChangedEvent(v89, v87)
							end
						end
					end
					p_u_75._enabledChangedEvent:Fire()
				end
				p_u_75._evaluateStateMachineChangedConnection = p_u_75._humanoid:GetPropertyChangedSignal("EvaluateStateMachine"):Connect(function()
					-- upvalues: (copy) v_u_91
					v_u_91()
				end)
				v_u_91()
			end
		end)
	end
end
function v_u_43.isEnabled(p92) -- name: isEnabled
	local v93
	if p92._humanoid == nil then
		v93 = false
	else
		v93 = not p92._humanoid.EvaluateStateMachine
	end
	return v93
end
function v_u_43.GetEnabledChangedSignal(p94) -- name: GetEnabledChangedSignal
	return p94._enabledChangedEvent.Event
end
function v_u_43.SendInput(p95, p96, p97) -- name: SendInput
	if p95:isEnabled() then
		if p97 ~= p95._data[p96] then
			p95._data[p96] = p97
			p95._avatarAbilities().setAbilityManagerCommand(p95._character, p96, p97)
		end
	end
end
function v_u_43.GetAbilityAttribute(p98, p99, p100, p101) -- name: GetAbilityAttribute
	local v102 = p98._abilitiesByInputName[p99]
	if v102 then
		local v103 = v102:FindFirstChild("SyncedState")
		if v103 then
			local v104 = v103:GetAttribute(p100)
			if v104 == nil then
				return p101
			else
				return v104
			end
		else
			return p101
		end
	else
		return p101
	end
end
function v_u_43.GetAbilityAttributeChangedSignal(p105, p106, p107) -- name: GetAbilityAttributeChangedSignal
	if not p105._abilityChangedEvents[p107] then
		p105._abilityChangedEvents[p107] = {}
	end
	if p105._abilityChangedEvents[p107][p106] then
		return p105._abilityChangedEvents[p107][p106].Event
	end
	local v108 = Instance.new("BindableEvent")
	p105._abilityChangedEvents[p107][p106] = v108
	p105:_hookUpAbilityChangedEvent(p106, p107)
	return v108.Event
end
function v_u_43.GetAbilityEnabled(p109, p110) -- name: GetAbilityEnabled
	return p109:GetAbilityAttribute(p110, "Enabled", false)
end
function v_u_43.GetAbilityEnabledChangedSignal(p111, p112) -- name: GetAbilityEnabledChangedSignal
	return p111:GetAbilityAttributeChangedSignal(p112, "Enabled")
end
function v_u_43.GetAbilitySuspended(p113, p114) -- name: GetAbilitySuspended
	return p113:GetAbilityAttribute(p114, "Suspended", false)
end
function v_u_43.GetAbilitySuspendedChangedSignal(p115, p116) -- name: GetAbilitySuspendedChangedSignal
	return p115:GetAbilityAttributeChangedSignal(p116, "Suspended")
end
function v_u_43.GetAbilityActive(p117, p118) -- name: GetAbilityActive
	return p117:GetAbilityAttribute(p118, "Active", false)
end
function v_u_43.GetAbilityActiveChangedSignal(p119, p120) -- name: GetAbilityActiveChangedSignal
	return p119:GetAbilityAttributeChangedSignal(p120, "Active")
end
function v_u_43.GetAbilityValid(p121, p122) -- name: GetAbilityValid
	return p121:GetAbilityAttribute(p122, "IsValid", true)
end
function v_u_43.GetAbilityValidChangedSignal(p123, p124) -- name: GetAbilityValidChangedSignal
	return p123:GetAbilityAttributeChangedSignal(p124, "IsValid")
end
function v_u_43.GetAbilities(p125) -- name: GetAbilities
	local v126 = {}
	for v127 in p125._abilitiesByInputName do
		table.insert(v126, v127)
	end
	return v126
end
function v_u_43.GetAbilitiesChangedSignal(p128) -- name: GetAbilitiesChangedSignal
	return p128._abilitiesChangedEvent.Event
end
function v_u_43.GetAbilityConfig(p129, p130) -- name: GetAbilityConfig
	local v131 = {
		["Slot"] = -1
	}
	local v132 = p129._abilitiesByInputName[p130]
	if not v132 then
		return v131
	end
	local v133 = v132:GetAttribute("ActionSlot")
	return v133 and {
		["Slot"] = tonumber(v133),
		["ButtonAssetId"] = v132:GetAttribute("CustomIcon"),
		["ButtonPressedAssetId"] = v132:GetAttribute("CustomIconActive"),
		["ButtonInvalidAssetId"] = v132:GetAttribute("CustomIconInvalid")
	} or v131
end
function v_u_43.destroy(p134) -- name: destroy
	if p134._characterAddedConnection then
		p134._characterAddedConnection:Disconnect()
		p134._characterAddedConnection = nil
	end
	if p134._evaluateStateMachineChangedConnection then
		p134._evaluateStateMachineChangedConnection:Disconnect()
		p134._evaluateStateMachineChangedConnection = nil
	end
	if p134._disconnectAbilitiesChanged then
		p134._disconnectAbilitiesChanged()
		p134._disconnectAbilitiesChanged = nil
	end
	for _, v135 in p134._abilityChangedConnections do
		for _, v136 in v135 do
			v136:Disconnect()
		end
	end
	p134._abilityChangedConnections = {}
end
return v_u_43