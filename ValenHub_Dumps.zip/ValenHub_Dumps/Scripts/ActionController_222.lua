local v_u_1 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil").getUserFlag("UserControlModuleEnabledAPI")
local v_u_2 = {}
v_u_2.__index = v_u_2
function v_u_2.new() -- name: new
	-- upvalues: (copy) v_u_2
	local v3 = v_u_2
	local v4 = setmetatable({}, v3)
	v4.enabled = true
	return v4
end
function v_u_2.initializeActions(p_u_5, p_u_6) -- name: initializeActions
	p_u_5.connectionUtil:trackConnection("SERVER_AUTHORITY_CHANGED", p_u_5.eventBus:subscribe("SERVER_AUTHORITY_CHANGED"):Connect(function()
		-- upvalues: (copy) p_u_6
		p_u_6.actions = {}
	end))
	if p_u_6.actions.MoveAction and p_u_6.actions.JumpAction then
		return
	elseif p_u_6.player then
		pcall(function()
			-- upvalues: (copy) p_u_5, (copy) p_u_6
			local v7 = script.Parent.Parent.InputContexts
			if p_u_5.isServerAuthority then
				v7 = p_u_6.player.InputContexts
			end
			local v8 = v7.CharacterContext
			p_u_6.actions = {
				["MoveAction"] = v8.MoveAction,
				["JumpAction"] = v8.JumpAction
			}
			p_u_5.eventBus:publish("ACTIONS_RELOADED")
		end)
	end
end
function v_u_2.update(p9) -- name: update
	-- upvalues: (copy) v_u_1
	if v_u_1 then
		if not (p9.actions.MoveAction and p9.actions.JumpAction) then
			return
		end
		local v10 = p9.playerModule.ControlModule
		p9.actions.MoveAction.Enabled = v10.Enabled
		p9.actions.JumpAction.Enabled = v10.Enabled
	end
	p9.moveVector = p9.actions.MoveAction:GetState()
	p9.isJumping = p9.actions.JumpAction:GetState()
end
function v_u_2.Enable(_, _) -- name: Enable end
return v_u_2