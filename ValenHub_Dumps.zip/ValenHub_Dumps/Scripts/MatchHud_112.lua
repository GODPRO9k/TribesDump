local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
return {
	["Init"] = function(p_u_5) -- name: Init
		-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_1, (copy) v_u_3
		local v_u_6 = p_u_5.UI
		local v_u_7 = p_u_5.Theme
		local v_u_8 = p_u_5.State
		local v_u_9 = p_u_5.Portraits
		local v_u_10 = v_u_7.Colors
		local v_u_11 = v_u_7.Fonts
		local v_u_12 = v_u_2.LocalPlayer
		local v_u_13 = v_u_6.new("Frame", {
			["Name"] = "MatchHud",
			["Size"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = p_u_5.Canvas.HUD
		})
		local v_u_14 = Color3.fromRGB(255, 146, 52)
		local v_u_15 = v_u_6.new("Frame", {
			["Name"] = "Scoreboard",
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Size"] = UDim2.fromOffset(700, 96),
			["Parent"] = v_u_13
		})
		p_u_5.Scoreboard = v_u_15
		local v16 = v_u_6.Panel({
			["Name"] = "Center",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundTransparency"] = 0.2,
			["Radius"] = nil,
			["Trim"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.fromScale(0.5, 0),
			["Size"] = UDim2.fromOffset(150, 74),
			["Radius"] = UDim.new(0, 12),
			["Trim"] = v_u_10.Accent,
			["Parent"] = v_u_15
		})
		local v_u_17 = v_u_6.DisplayText({
			["Name"] = "Timer",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "1:15",
			["TextSize"] = 42,
			["TextColor3"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(0, 4),
			["Size"] = UDim2.new(1, 0, 0, 44),
			["TextColor3"] = v_u_10.Text,
			["Parent"] = v16
		})
		local v_u_18 = v_u_6.new("TextLabel", {
			["Name"] = "Round",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "ROUND 1",
			["FontFace"] = nil,
			["TextSize"] = 15,
			["TextColor3"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(0, 48),
			["Size"] = UDim2.new(1, 0, 0, 20),
			["FontFace"] = v_u_11.Heavy,
			["TextColor3"] = v_u_10.TextDim,
			["Parent"] = v16
		})
		local v_u_19 = {}
		local function v52(p20) -- name: makeSide
			-- upvalues: (copy) v_u_10, (copy) v_u_6, (copy) v_u_15, (copy) v_u_14, (copy) v_u_7, (copy) v_u_11
			local v21
			if p20 then
				v21 = v_u_10.Ally
			else
				v21 = v_u_10.Enemy
			end
			local v22 = v_u_6.new("Frame", {
				["Name"] = p20 and "Left" or "Right",
				["AnchorPoint"] = Vector2.new(p20 and 1 or 0, 0),
				["Position"] = UDim2.new(0.5, p20 and -80 or 80, 0, 0),
				["Size"] = UDim2.fromOffset(270, 96),
				["Parent"] = v_u_15
			})
			local v23 = v_u_6.new("ImageLabel", {
				["Name"] = "FinalGlow",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Image"] = nil,
				["ImageColor3"] = nil,
				["ImageTransparency"] = 1,
				["ZIndex"] = 0,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.new(p20 and 1 or 0, p20 and -33 or 33, 0, 30),
				["Size"] = UDim2.fromOffset(150, 136),
				["Image"] = v_u_6.Assets.Icons.Glow,
				["ImageColor3"] = v_u_14,
				["Parent"] = v22
			})
			local v24 = v_u_6.Stroke(v_u_7.Lighten(v21, 0.4), 2, 0.3)
			local v25 = v_u_6.new("Frame", {
				["Name"] = "ScoreBox",
				["AnchorPoint"] = Vector2.new(p20 and 1 or 0, 0),
				["Position"] = UDim2.fromScale(p20 and 1 or 0, 0),
				["Size"] = UDim2.fromOffset(66, 60),
				["BackgroundColor3"] = Color3.new(1, 1, 1),
				["BackgroundTransparency"] = 0.05,
				v_u_6.Corner(12),
				v_u_6.Gradient(v_u_7.Lighten(v21, 0.1), v_u_7.Darken(v21, 0.35), 90),
				v24,
				["Parent"] = v22
			})
			local v26 = v_u_6.DisplayText({
				["Name"] = "Score",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "0",
				["TextSize"] = 44,
				["TextColor3"] = nil,
				["StrokeThickness"] = 2.5,
				["StrokeColor"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromScale(1, 1),
				["TextColor3"] = v_u_10.Text,
				["StrokeColor"] = v_u_7.Darken(v21, 0.7),
				["Parent"] = v25
			})
			local v27 = v_u_6.new("Frame", {
				["Name"] = "Pips",
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(p20 and 1 or 0, p20 and -33 or 33, 0, 64),
				["Size"] = UDim2.fromOffset(66, 10),
				v_u_6.List(Enum.FillDirection.Horizontal, 3, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
				["Parent"] = v22
			})
			local v28 = v_u_6.new
			local v29 = "Frame"
			local v30 = {
				["Name"] = "Portraits",
				["AnchorPoint"] = Vector2.new(p20 and 1 or 0, 0),
				["Position"] = UDim2.new(p20 and 1 or 0, p20 and -74 or 74, 0, 2),
				["Size"] = UDim2.fromOffset(174, 54)
			}
			local v31 = v_u_6.List
			local v32 = Enum.FillDirection.Horizontal
			local v33 = 6
			local v34
			if p20 then
				v34 = Enum.HorizontalAlignment.Right
			else
				v34 = Enum.HorizontalAlignment.Left
			end
			__set_list(v30, 1, {(v31(v32, v33, v34, Enum.VerticalAlignment.Top))})
			v30.Parent = v22
			local v35 = v28(v29, v30)
			local v36 = v_u_6.new
			local v37 = "TextLabel"
			local v38 = {
				["Name"] = "Tribe",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "WOLF",
				["FontFace"] = nil,
				["TextSize"] = 16,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["Visible"] = false,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(p20 and 1 or 0, 0),
				["Position"] = UDim2.new(p20 and 1 or 0, p20 and -74 or 74, 0, 60),
				["Size"] = UDim2.fromOffset(174, 18),
				["FontFace"] = v_u_11.Heavy,
				["TextColor3"] = v_u_7.Lighten(v21, 0.45)
			}
			local v39
			if p20 then
				v39 = Enum.TextXAlignment.Right
			else
				v39 = Enum.TextXAlignment.Left
			end
			v38.TextXAlignment = v39
			v38.Parent = v22
			local v40 = v36(v37, v38)
			local v41 = {}
			for v42 = 1, 3 do
				local v43 = v_u_6.new
				local v44 = "Frame"
				local v45 = {
					["Name"] = "P" .. v42,
					["Size"] = UDim2.fromOffset(54, 54),
					["BackgroundColor3"] = v_u_7.Darken(v21, 0.55),
					["BackgroundTransparency"] = 0.1
				}
				local v46
				if p20 then
					v46 = 4 - v42
				else
					v46 = v42
				end
				v45.LayoutOrder = v46
				v45.ClipsDescendants = false
				__set_list(v45, 1, {(v_u_6.Corner(v_u_7.Radius.Pill))})
				v45.Parent = v35
				local v47 = v43(v44, v45)
				local v48 = v_u_6.Stroke(v21, 2.5, 0)
				v48.Parent = v47
				local v49 = v_u_6.new("ImageLabel", {
					["Name"] = "Img",
					["Size"] = UDim2.fromScale(1, 1),
					["ScaleType"] = Enum.ScaleType.Crop,
					v_u_6.Corner(v_u_7.Radius.Pill),
					["Parent"] = v47
				})
				local v50 = v_u_6.new("Frame", {
					["Name"] = "Dim",
					["Size"] = UDim2.fromScale(1, 1),
					["BackgroundColor3"] = v_u_10.Void,
					["BackgroundTransparency"] = 0.35,
					["Visible"] = false,
					["ZIndex"] = 2,
					v_u_6.Corner(v_u_7.Radius.Pill),
					["Parent"] = v47
				})
				local v51 = v_u_6.Icon("cross", 40, v_u_10.Danger, {
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Thickness"] = 5,
					["ZIndex"] = 3,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Parent"] = v47
				})
				v51.Visible = false
				v41[v42] = {
					["holder"] = v47,
					["img"] = v49,
					["stroke"] = v48,
					["x"] = v51,
					["dim"] = v50
				}
			end
			return {
				["frame"] = v22,
				["score"] = v26,
				["boxStroke"] = v24,
				["glow"] = v23,
				["name"] = v40,
				["pips"] = v27,
				["portraits"] = v41
			}
		end
		v_u_19[1] = v52(true)
		v_u_19[2] = v52(false)
		local function v_u_68(p53, p54, p55, p56) -- name: setPips
			-- upvalues: (copy) v_u_6
			local v57 = {}
			for _, v58 in p53.pips:GetChildren() do
				if not v58:IsA("Frame") then
					continue
				end
				table.insert(v57, v58)
			end
			for v59 = #v57 + 1, p55 do
				local v60 = v_u_6.new
				local v61 = {
					["Size"] = UDim2.fromOffset(12, 8),
					["BackgroundColor3"] = p56,
					["LayoutOrder"] = v59,
					v_u_6.Corner(3),
					["Parent"] = p53.pips
				}
				table.insert(v57, v60("Frame", v61))
			end
			local v62 = 66 / math.max(p55, 1)
			local v63 = math.floor(v62) - 3
			local v64 = math.clamp(v63, 4, 14)
			for v65, v66 in v57 do
				v66.Visible = v65 <= p55
				v66.Size = UDim2.fromOffset(v64, 8)
				local v67
				if v65 <= p54 then
					v67 = p56
				else
					v67 = Color3.fromRGB(52, 56, 68)
				end
				v66.BackgroundColor3 = v67
				v66.BackgroundTransparency = v65 <= p54 and 0 or 0.25
			end
		end
		local v_u_69 = -1
		local v_u_70 = false
		local v_u_71 = false
		local v_u_72 = v16:FindFirstChildOfClass("UIStroke")
		local v_u_73 = v_u_72 and { v_u_72.Color, v_u_72.Transparency, v_u_72.Thickness } or v_u_72
		local function v_u_93(p74) -- name: paintFinal
			-- upvalues: (ref) v_u_71, (copy) v_u_6, (copy) v_u_18, (copy) v_u_19, (copy) v_u_7, (copy) v_u_10, (copy) v_u_72, (copy) v_u_73, (copy) v_u_14
			if p74 ~= v_u_71 then
				v_u_71 = p74
				if p74 then
					v_u_6.Bump(v_u_18, 0.25)
				else
					for v75, v76 in v_u_19 do
						v76.glow.ImageTransparency = 1
						local v77 = v76.boxStroke
						local v78 = v_u_7.Lighten
						local v79
						if v75 == 1 then
							v79 = v_u_10.Ally
						else
							v79 = v_u_10.Enemy
						end
						v77.Color = v78(v79, 0.4)
						v76.boxStroke.Transparency = 0.3
					end
					if v_u_72 and v_u_73 then
						local v80 = v_u_72
						local v81 = v_u_72
						local v82 = v_u_72
						local v83 = v_u_73[1]
						local v84 = v_u_73[2]
						local v85 = v_u_73[3]
						v80.Color = v83
						v81.Transparency = v84
						v82.Thickness = v85
					end
				end
			end
			if p74 then
				local v86 = os.clock() * 2.4
				local v87 = math.sin(v86) * 0.5 + 0.5
				for v88, v89 in v_u_19 do
					v89.glow.ImageTransparency = 0.7 - v87 * 0.24
					local v90 = v89.boxStroke
					local v91 = v_u_7.Lighten
					local v92
					if v88 == 1 then
						v92 = v_u_10.Ally
					else
						v92 = v_u_10.Enemy
					end
					v90.Color = v91(v92, 0.4):Lerp(v_u_14, v87 * 0.35 + 0.35)
					v89.boxStroke.Transparency = 0.25 - v87 * 0.15
				end
				if v_u_72 then
					v_u_72.Color = v_u_14
					v_u_72.Thickness = 1.5
					v_u_72.Transparency = 0.6 - v87 * 0.3
				end
			end
		end
		local function v_u_97(p94) -- name: phaseText
			-- upvalues: (copy) v_u_8, (copy) v_u_6, (copy) v_u_10
			if p94 then
				p94 = p94.phase
			end
			local v95 = v_u_8.PhaseTimeLeft()
			if p94 == "Overtime" then
				return v95 <= 0 and "OVERTIME" or v_u_6.FormatTime(v95), v_u_10.Danger
			elseif p94 == "Live" then
				local v96 = v_u_6.FormatTime(v95)
				if v95 <= 10 then
					return v96, v_u_10.Danger
				else
					return v96, v_u_10.Text
				end
			elseif p94 == "PreRound" or p94 == "Intro" then
				return v_u_6.FormatTime(v_u_8.RoundTime()), v_u_10.TextDim
			elseif p94 == "RoundEnd" or p94 == "MatchEnd" then
				return "0:00", v_u_10.TextDim
			else
				return v_u_6.FormatTime(v95), v_u_10.Text
			end
		end
		local v_u_98 = v_u_6.new("TextLabel", {
			["Name"] = "Overtime",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "OVERTIME",
			["FontFace"] = nil,
			["TextSize"] = 17,
			["TextColor3"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 78),
			["Size"] = UDim2.fromOffset(200, 20),
			["FontFace"] = v_u_11.Title,
			["TextColor3"] = v_u_10.Danger,
			["Parent"] = v_u_15
		})
		v_u_6.TextStroke(v_u_10.Void, 2, 0.1).Parent = v_u_98
		local v_u_99 = v_u_6.new("Frame", {
			["Name"] = "Health",
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Size"] = UDim2.fromOffset(372, 40),
			["Parent"] = v_u_13
		})
		local v_u_100 = v_u_6.DisplayText({
			["Name"] = "Number",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "100",
			["TextSize"] = 40,
			["TextXAlignment"] = nil,
			["TextColor3"] = nil,
			["StrokeThickness"] = 2.5,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 0, 1, 2),
			["Size"] = UDim2.fromOffset(72, 40),
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextColor3"] = v_u_10.Text,
			["Parent"] = v_u_99
		})
		local v101 = v_u_6.new("Frame", {
			["Name"] = "Bar",
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(1, 0, 1, -4),
			["Size"] = UDim2.new(1, -80, 0, 20),
			["BackgroundColor3"] = v_u_10.Void,
			["BackgroundTransparency"] = 0.3,
			["ClipsDescendants"] = true,
			v_u_6.Corner(6),
			v_u_6.Stroke(v_u_10.Stroke, 2, 0.6),
			["Parent"] = v_u_99
		})
		local v_u_102 = v_u_6.new("Frame", {
			["Name"] = "Trail",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = v_u_10.HealthTrail,
			["BackgroundTransparency"] = 0.15,
			v_u_6.Corner(6),
			["Parent"] = v101
		})
		local v_u_103 = v_u_6.new("Frame", {
			["Name"] = "Fill",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			v_u_6.Corner(6),
			["Parent"] = v101
		})
		local v_u_104 = v_u_6.Gradient(v_u_7.Lighten(v_u_10.Health, 0.2), v_u_7.Darken(v_u_10.Health, 0.15), 90)
		v_u_104.Parent = v_u_103
		local function v_u_119() -- name: tickTimer
			-- upvalues: (copy) v_u_8, (copy) v_u_97, (copy) v_u_17, (copy) p_u_5, (copy) v_u_18, (copy) v_u_14, (copy) v_u_10, (copy) v_u_93, (ref) v_u_70, (copy) v_u_98, (copy) v_u_6, (ref) v_u_69
			local v105 = v_u_8.Match
			local v106, v107 = v_u_97(v105)
			v_u_17.Text = v106
			v_u_17.TextColor3 = v107
			local v108
			if p_u_5.Decider == nil then
				v108 = false
			else
				v108 = p_u_5.Decider.Active()
			end
			local v109 = v_u_18
			local v110
			if v108 then
				v110 = "FINAL ROUND"
			else
				local v111 = v105 and (v105.round or 1) or 1
				v110 = "ROUND " .. tostring(v111)
			end
			v109.Text = v110
			local v112 = v_u_18
			local v113
			if v108 then
				v113 = v_u_14
			else
				v113 = v_u_10.TextDim
			end
			v112.TextColor3 = v113
			v_u_93(v108)
			if v105 then
				v105 = v105.phase
			end
			local v114 = v105 == "Overtime"
			if v114 ~= v_u_70 then
				v_u_70 = v114
				v_u_98.Visible = v114
				if v114 then
					v_u_6.Pop(v_u_98, 1.5)
				end
			end
			if v114 then
				local v115 = v_u_98
				local v116 = os.clock() * 6
				v115.TextTransparency = math.sin(v116) * 0.25 + 0.25
			end
			if v105 == "Live" or v105 == "Overtime" then
				local v117 = v_u_8.PhaseTimeLeft()
				local v118 = math.ceil(v117)
				if v118 ~= v_u_69 then
					v_u_69 = v118
					if v118 <= 10 and v118 > 0 then
						v_u_6.Bump(v_u_17, 0.12)
					end
				end
			end
		end
		local function v_u_139(p120) -- name: paintBoard
			-- upvalues: (copy) v_u_8, (copy) v_u_19, (copy) v_u_10, (copy) v_u_6, (copy) v_u_68, (copy) v_u_9
			if p120 then
				local v121 = v_u_8.MyTeam()
				for v122, v123 in { v121, 3 - v121 } do
					local v124 = v_u_19[v122]
					local v125 = p120.teams[v123]
					local v126
					if v122 == 1 then
						v126 = v_u_10.Ally
					else
						v126 = v_u_10.Enemy
					end
					v124.name.Text = ""
					local v127 = v125.score or 0
					v124.score.Text = tostring(v127)
					if v124.lastScore and v124.lastScore < v127 then
						v_u_6.Pop(v124.score, 1.6)
					end
					v124.lastScore = v127
					v_u_68(v124, v127, p120.roundsToWin or v_u_8.RoundsToWin(), v126)
					for v128, v129 in v124.portraits do
						local v130 = v125.members[v128]
						v129.holder.Visible = v130 ~= nil
						if not v130 then
							continue
						end
						v_u_9.Apply(v129.img, v130, 60)
						local v131 = v130.alive == false
						local v132 = v130.connected == false
						v129.x.Visible = v131
						v129.dim.Visible = v131 or v132
						local v133 = v_u_9.SetTint
						local v134 = v129.img
						local v135
						if v131 then
							v135 = Color3.fromRGB(150, 150, 150)
						else
							v135 = Color3.new(1, 1, 1)
						end
						v133(v134, v135, v131 and 0.35 or 0)
						local v136 = v129.stroke
						local v137
						if v131 then
							v137 = Color3.fromRGB(90, 84, 78)
						else
							v137 = v126
						end
						v136.Color = v137
						local v138 = v130.id == v_u_8.MyId()
						v129.stroke.Thickness = v138 and 3.5 or 2.5
					end
				end
			end
		end
		for v140 = 1, 3 do
			v_u_6.new("Frame", {
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.55,
				["ZIndex"] = 2,
				["Parent"] = nil,
				["Position"] = UDim2.new(v140 * 0.25, -1, 0, 3),
				["Size"] = UDim2.new(0, 2, 1, -6),
				["BackgroundColor3"] = v_u_10.Void,
				["Parent"] = v101
			})
		end
		local v_u_141 = v_u_6.new("Frame", {
			["Name"] = "Flash",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["BackgroundTransparency"] = 1,
			["ZIndex"] = 3,
			v_u_6.Corner(6),
			["Parent"] = v101
		})
		local v142 = v_u_10.Armor
		local v_u_143 = v_u_6.new("Frame", {
			["Name"] = "Armor",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(1, 0, 0, -2),
			["Size"] = UDim2.new(1, -80, 0, 12),
			["Parent"] = v_u_99
		})
		local v_u_144 = v_u_6.Image(v_u_6.Assets.Icons.Shield, {
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(0, -6, 0.5, 0),
			["Size"] = UDim2.fromOffset(16, 16),
			["ImageColor3"] = v142,
			["Parent"] = v_u_143
		})
		local v_u_145 = v_u_6.DisplayText({
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "0",
			["TextSize"] = 16,
			["TextXAlignment"] = nil,
			["TextColor3"] = nil,
			["StrokeThickness"] = 1.5,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(0, -26, 0.5, 1),
			["Size"] = UDim2.fromOffset(40, 16),
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["TextColor3"] = v142,
			["Parent"] = v_u_143
		})
		local v146 = v_u_6.new("Frame", {
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = v_u_10.Void,
			["BackgroundTransparency"] = 0.3,
			["ClipsDescendants"] = true,
			v_u_6.Corner(4),
			v_u_6.Stroke(v_u_10.Stroke, 1.5, 0.7),
			["Parent"] = v_u_143
		})
		local v_u_147 = v_u_6.new("Frame", {
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			v_u_6.Corner(4),
			v_u_6.Gradient(v_u_7.Lighten(v142, 0.2), v_u_7.Darken(v142, 0.15), 90),
			["Parent"] = v146
		})
		local v_u_148 = 0
		local v_u_149 = nil
		local function v_u_161(p150) -- name: paintArmor
			-- upvalues: (ref) v_u_149, (copy) v_u_143, (copy) v_u_145, (copy) v_u_147, (copy) v_u_6, (ref) v_u_148, (copy) v_u_7, (copy) v_u_144
			local v151 = v_u_149
			local v152
			if v151 then
				v152 = v151:GetAttribute("MaxArmor")
			else
				v152 = v151
			end
			if v151 then
				v151 = v151:GetAttribute("Armor")
			end
			local v153 = type(v152) ~= "number" and 0 or v152
			local v154 = type(v151) ~= "number" and 0 or math.clamp(v151, 0, v153)
			v_u_143.Visible = v153 > 0
			if v153 > 0 then
				local v155 = v_u_145
				local v156 = math.ceil(v154)
				v155.Text = tostring(v156)
				local v157 = v154 / v153
				if p150 then
					v_u_147.Size = UDim2.fromScale(v157, 1)
				else
					local v158 = v_u_6.Tween
					local v159 = v_u_147
					local v160
					if v154 < v_u_148 then
						v160 = v_u_7.Tween.Fast
					else
						v160 = v_u_7.Tween.Smooth
					end
					v158(v159, v160, {
						["Size"] = UDim2.fromScale(v157, 1)
					})
					if v154 < v_u_148 then
						v_u_6.Bump(v_u_144, 0.25)
						if v154 <= 0 then
							v_u_6.Shake(v_u_143, 6)
						end
					end
				end
				v_u_147.BackgroundTransparency = v154 <= 0 and 1 or 0
				v_u_148 = v154
			end
		end
		local v_u_162 = nil
		local v_u_163 = 100
		local v_u_164 = 0
		local v_u_165 = false
		local function v_u_182(p166) -- name: paintHealth
			-- upvalues: (ref) v_u_162, (copy) v_u_100, (copy) v_u_10, (copy) v_u_104, (copy) v_u_7, (ref) v_u_165, (copy) v_u_103, (copy) v_u_102, (ref) v_u_163, (copy) v_u_141, (copy) v_u_6, (copy) v_u_99, (ref) v_u_164
			local v167 = v_u_162
			if v167 then
				local v168 = v167.MaxHealth <= 0 and 100 or v167.MaxHealth
				local v169 = v167.Health
				local v170 = math.clamp(v169, 0, v168)
				local v_u_171 = v170 / v168
				local v172 = math.ceil(v170)
				v_u_100.Text = tostring(v172)
				local v173
				if v_u_171 <= 0.3 then
					v173 = v_u_10.HealthLow
				elseif v_u_171 <= 0.6 then
					v173 = Color3.fromRGB(240, 196, 70)
				else
					v173 = v_u_10.Health
				end
				v_u_104.Color = ColorSequence.new(v_u_7.Lighten(v173, 0.2), v_u_7.Darken(v173, 0.15))
				local v174
				if v_u_171 <= 0.3 then
					v174 = v170 > 0
				else
					v174 = false
				end
				v_u_165 = v174
				if p166 then
					v_u_103.Size = UDim2.fromScale(v_u_171, 1)
					v_u_102.Size = UDim2.fromScale(v_u_171, 1)
				elseif v170 < v_u_163 then
					v_u_103.Size = UDim2.fromScale(v_u_171, 1)
					v_u_141.BackgroundTransparency = 0.35
					v_u_6.Tween(v_u_141, TweenInfo.new(0.25), {
						["BackgroundTransparency"] = 1
					})
					local v175 = v_u_6.Bump
					local v176 = v_u_100
					local v177 = (v_u_163 - v170) / 60
					v175(v176, (math.clamp(v177, 0.08, 0.3)))
					if v_u_163 - v170 >= 8 then
						local v178 = v_u_6.Shake
						local v179 = v_u_99
						local v180 = (v_u_163 - v170) / 5
						v178(v179, (math.clamp(v180, 3, 9)))
					end
					v_u_164 = v_u_164 + 1
					local v_u_181 = v_u_164
					task.delay(0.35, function()
						-- upvalues: (copy) v_u_181, (ref) v_u_164, (ref) v_u_6, (ref) v_u_102, (copy) v_u_171
						if v_u_181 == v_u_164 then
							v_u_6.Tween(v_u_102, TweenInfo.new(0.4, Enum.EasingStyle.Quad), {
								["Size"] = UDim2.fromScale(v_u_171, 1)
							})
						end
					end)
				else
					v_u_6.Tween(v_u_103, v_u_7.Tween.Smooth, {
						["Size"] = UDim2.fromScale(v_u_171, 1)
					})
					v_u_6.Tween(v_u_102, v_u_7.Tween.Smooth, {
						["Size"] = UDim2.fromScale(v_u_171, 1)
					})
					if v_u_163 + 1 < v170 then
						v_u_100.TextColor3 = v_u_10.Health
						task.delay(0.4, function()
							-- upvalues: (ref) v_u_100, (ref) v_u_10
							v_u_100.TextColor3 = v_u_10.Text
						end)
					end
				end
				v_u_163 = v170
			end
		end
		local v_u_183 = {}
		local v_u_184 = nil
		local function v_u_214(p185) -- name: hookCharacter
			-- upvalues: (copy) v_u_183, (ref) v_u_162, (ref) v_u_149, (ref) v_u_148, (copy) v_u_143, (copy) v_u_145, (copy) v_u_147, (copy) v_u_161, (copy) v_u_12, (ref) v_u_184, (ref) v_u_163, (copy) v_u_182
			for _, v186 in v_u_183 do
				v186:Disconnect()
			end
			table.clear(v_u_183)
			v_u_162 = nil
			v_u_149 = p185
			v_u_148 = 0
			local v187 = v_u_149
			local v188
			if v187 then
				v188 = v187:GetAttribute("MaxArmor")
			else
				v188 = v187
			end
			if v187 then
				v187 = v187:GetAttribute("Armor")
			end
			local v189 = type(v188) ~= "number" and 0 or v188
			local v190 = type(v187) ~= "number" and 0 or math.clamp(v187, 0, v189)
			v_u_143.Visible = v189 > 0
			if v189 > 0 then
				local v191 = v_u_145
				local v192 = math.ceil(v190)
				v191.Text = tostring(v192)
				local v193 = v190 / v189
				v_u_147.Size = UDim2.fromScale(v193, 1)
				v_u_147.BackgroundTransparency = v190 <= 0 and 1 or 0
				v_u_148 = v190
			end
			if p185 then
				local v194 = v_u_183
				local v195 = p185:GetAttributeChangedSignal("Armor")
				local function v196()
					-- upvalues: (ref) v_u_161
					v_u_161(false)
				end
				table.insert(v194, v195:Connect(v196))
				local v197 = v_u_183
				local v198 = p185:GetAttributeChangedSignal("MaxArmor")
				local function v206()
					-- upvalues: (ref) v_u_149, (ref) v_u_143, (ref) v_u_145, (ref) v_u_147, (ref) v_u_148
					local v199 = v_u_149
					local v200
					if v199 then
						v200 = v199:GetAttribute("MaxArmor")
					else
						v200 = v199
					end
					if v199 then
						v199 = v199:GetAttribute("Armor")
					end
					local v201 = type(v200) ~= "number" and 0 or v200
					local v202 = type(v199) ~= "number" and 0 or math.clamp(v199, 0, v201)
					v_u_143.Visible = v201 > 0
					if v201 > 0 then
						local v203 = v_u_145
						local v204 = math.ceil(v202)
						v203.Text = tostring(v204)
						local v205 = v202 / v201
						v_u_147.Size = UDim2.fromScale(v205, 1)
						v_u_147.BackgroundTransparency = v202 <= 0 and 1 or 0
						v_u_148 = v202
					end
				end
				table.insert(v197, v198:Connect(v206))
				local v207 = p185:FindFirstChildOfClass("Humanoid") or p185:WaitForChild("Humanoid", 10)
				if v207 and (v207:IsA("Humanoid") and (v_u_12.Character == p185 or v_u_184 == p185)) then
					v_u_162 = v207
					v_u_163 = v207.Health
					v_u_182(true)
					local v208 = v_u_183
					local v209 = v207.HealthChanged
					local function v210()
						-- upvalues: (ref) v_u_182
						v_u_182(false)
					end
					table.insert(v208, v209:Connect(v210))
					local v211 = v_u_183
					local v212 = v207:GetPropertyChangedSignal("MaxHealth")
					local function v213()
						-- upvalues: (ref) v_u_182
						v_u_182(true)
					end
					table.insert(v211, v212:Connect(v213))
				end
			else
				return
			end
		end
		v_u_12.CharacterAdded:Connect(function(p215)
			-- upvalues: (ref) v_u_184, (copy) v_u_214
			if not v_u_184 then
				v_u_214(p215)
			end
		end)
		task.spawn(v_u_214, v_u_12.Character)
		local v_u_216 = UDim2.new(0.5, 0, 0, 0)
		local v_u_217 = 0
		local v_u_218 = nil
		local v_u_219 = TweenInfo.new(0.28, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
		local function v_u_226() -- name: boardHomeRect
			-- upvalues: (copy) v_u_6, (copy) v_u_13, (copy) v_u_15, (ref) v_u_216
			local v220 = v_u_6.Scale
			local v221 = math.max(v220, 0.01)
			local v222 = v_u_13.AbsoluteSize / v221
			local v223 = v_u_15.AbsoluteSize / v221
			local v224 = v_u_216.X.Scale * v222.X + v_u_216.X.Offset - v_u_15.AnchorPoint.X * v223.X
			local v225 = v_u_216.Y.Scale * v222.Y + v_u_216.Y.Offset
			return Rect.new(v224, v225, v224 + v223.X, v225 + v223.Y), v222
		end
		local function v_u_233() -- name: computeBoardShift
			-- upvalues: (copy) v_u_6, (copy) v_u_13, (copy) v_u_15, (copy) v_u_226
			local v227 = v_u_6.ChatRectIn(v_u_13)
			if not v227 or (not v_u_13.Visible or (not v_u_15.Visible or v_u_6.Compact)) then
				return 0
			end
			local v228, v229 = v_u_226()
			if v227.Max.X + 12 <= v228.Min.X or (v227.Min.X >= v228.Max.X or (v227.Max.Y <= v228.Min.Y or v227.Min.Y >= v228.Max.Y)) then
				return 0
			end
			local v230 = v227.Max.X + 12 - v228.Min.X
			local v231 = v229.X - 12 - v228.Max.X
			local v232 = math.min(v230, v231)
			return math.max(0, v232)
		end
		local function v_u_236(p234) -- name: applyBoard
			-- upvalues: (ref) v_u_216, (ref) v_u_217, (ref) v_u_218, (copy) v_u_13, (copy) v_u_15, (ref) v_u_4, (copy) v_u_219, (copy) p_u_5
			local v235 = v_u_216 + UDim2.fromOffset(v_u_217, 0)
			if v_u_218 then
				v_u_218:Cancel()
				v_u_218 = nil
			end
			if p234 and (v_u_13.Visible and v_u_15.Visible) then
				v_u_218 = v_u_4:Create(v_u_15, v_u_219, {
					["Position"] = v235
				})
				v_u_218:Play()
			else
				v_u_15.Position = v235
			end
			if p_u_5.KillFeedRelayout then
				p_u_5.KillFeedRelayout()
			end
		end
		local function v_u_240(p237) -- name: redodgeBoard
			-- upvalues: (copy) v_u_233, (ref) v_u_217, (copy) v_u_236
			local v238 = v_u_233()
			local v239 = v238 - v_u_217
			if math.abs(v239) > 1 then
				v_u_217 = v238
				v_u_236(p237)
			end
		end
		v_u_6.ChatChanged:Connect(function()
			-- upvalues: (copy) v_u_240
			task.defer(v_u_240, true)
		end)
		v_u_13:GetPropertyChangedSignal("Visible"):Connect(function()
			-- upvalues: (copy) v_u_240
			task.defer(v_u_240, false)
		end)
		v_u_15:GetPropertyChangedSignal("Visible"):Connect(function()
			-- upvalues: (copy) v_u_240
			task.defer(v_u_240, false)
		end)
		local v_u_241 = v_u_6.new("UIScale", {
			["Name"] = "FitScale",
			["Parent"] = nil,
			["Parent"] = v_u_15
		})
		local function v_u_265() -- name: phoneBoardHome
			-- upvalues: (copy) v_u_6, (copy) v_u_13, (copy) p_u_5, (ref) v_u_1
			local v242 = v_u_6.Scale
			local v243 = math.max(v242, 0.01)
			local v244 = v_u_13.AbsolutePosition
			local v245 = v_u_13.AbsoluteSize / v243
			local v246 = p_u_5.TopbarSettings
			if v246 then
				v246 = p_u_5.TopbarSettings.Button
			end
			local v247
			if v246 then
				v247 = v246:FindFirstAncestorOfClass("ScreenGui")
			else
				v247 = v246
			end
			local v248, v249, v250
			if v_u_6.DebugDevice or (not v246 or (not v247 or v246.AbsoluteSize.X < 1)) then
				v248 = (v_u_6.TopInset() - 4) * 6
				v249 = v245.X - 16
				v250 = 6
			else
				v248 = (v246.AbsolutePosition.X + v246.AbsoluteSize.X - v244.X) / v243 + 12
				v250 = (v246.AbsolutePosition.Y - v244.Y) / v243
				local v251 = v_u_1.TopbarInset
				if v251.Width > 0 then
					v249 = (v247.AbsolutePosition.X + v251.Max.X - v244.X) / v243 - 8
				else
					v249 = v245.X - 16
				end
			end
			local v252 = v245.X - 16
			local v253 = math.min(v249, v252)
			local v254 = (v253 - v248) / 700
			if v254 < 0.55 then
				local v255 = (v245.X - 32) / 700
				local v256 = math.min(1, v255)
				return UDim2.new(0.5, 0, 0, v_u_6.TopInset()), v256
			end
			local v257 = math.min(v254, 1)
			local v258 = 700 * v257
			local v259 = v245.X / 2
			if v259 - v258 / 2 < v248 then
				v259 = v248 + v258 / 2
			end
			if v253 < v259 + v258 / 2 then
				local v260 = v248 + v258 / 2
				local v261 = v253 - v258 / 2
				v259 = math.max(v260, v261)
			end
			local v262 = UDim2.fromOffset
			local v263 = math.floor(v259)
			local v264 = math.max(2, v250)
			return v262(v263, (math.floor(v264))), v257
		end
		local function v_u_272() -- name: layout
			-- upvalues: (copy) v_u_6, (copy) v_u_265, (ref) v_u_216, (copy) v_u_241, (ref) v_u_217, (ref) v_u_218, (copy) v_u_15, (copy) p_u_5, (copy) v_u_240, (copy) v_u_99
			local v266 = v_u_6.TopInset()
			if v_u_6.Compact then
				local v267, v268 = v_u_265()
				v_u_216 = v267
				v_u_241.Scale = v268
			else
				v_u_216 = UDim2.new(0.5, 0, 0, v266)
				v_u_241.Scale = 1
			end
			local v269 = v_u_216 + UDim2.fromOffset(v_u_217, 0)
			if v_u_218 then
				v_u_218:Cancel()
				v_u_218 = nil
			end
			v_u_15.Position = v269
			if p_u_5.KillFeedRelayout then
				p_u_5.KillFeedRelayout()
			end
			task.defer(v_u_240, false)
			local v270 = not p_u_5.HotbarWidth and 372 or p_u_5.HotbarWidth()
			v_u_99.Size = UDim2.fromOffset(v270, 40)
			local v271 = not p_u_5.HotbarTop and 110 or p_u_5.HotbarTop()
			v_u_99.Position = UDim2.new(0.5, 0, 1, -(v271 + 8))
		end
		v_u_272()
		v_u_6.LayoutChanged:Connect(v_u_272)
		v_u_6.TopInsetChanged:Connect(v_u_272)
		local v_u_273 = false
		local function v274() -- name: queueLayout
			-- upvalues: (ref) v_u_273, (copy) v_u_272
			if not v_u_273 then
				v_u_273 = true
				task.defer(function()
					-- upvalues: (ref) v_u_273, (ref) v_u_272
					v_u_273 = false
					v_u_272()
				end)
			end
		end
		v_u_6.ScaleChanged:Connect(v274)
		v_u_13:GetPropertyChangedSignal("AbsoluteSize"):Connect(v274)
		if p_u_5.TopbarSettings and p_u_5.TopbarSettings.Button then
			p_u_5.TopbarSettings.Button:GetPropertyChangedSignal("AbsolutePosition"):Connect(v274)
		end
		if p_u_5.HotbarChanged then
			p_u_5.HotbarChanged.Event:Connect(v_u_272)
		end
		if p_u_5.ToastAvoid then
			p_u_5.ToastAvoid("Scoreboard", v_u_15)
		end
		local v_u_275 = nil
		local function v_u_280() -- name: refreshVisible
			-- upvalues: (copy) v_u_8, (copy) p_u_5, (ref) v_u_184, (copy) v_u_13, (copy) v_u_99, (copy) v_u_15, (ref) v_u_275, (ref) v_u_3, (copy) v_u_119, (ref) v_u_165, (copy) v_u_103
			local v276 = v_u_8.SeesMatch() and not p_u_5.HudHidden or v_u_184 ~= nil
			if v_u_8.Match == nil or v_u_8.Match.phase == "Loading" then
				v276 = false
			end
			v_u_13.Visible = v276
			local v277 = v_u_8.IsAlive()
			if v277 then
				v277 = not v_u_8.Watching()
			end
			v_u_99.Visible = v277 or v_u_184 ~= nil
			v_u_15.Visible = v_u_184 == nil
			if p_u_5.TopbarSettings then
				p_u_5.TopbarSettings.SetHidden("Replay", v_u_184 ~= nil)
			end
			if v276 and not v_u_275 then
				v_u_275 = v_u_3.Heartbeat:Connect(function()
					-- upvalues: (ref) v_u_119, (ref) v_u_165, (ref) v_u_103
					v_u_119()
					if v_u_165 then
						local v278 = v_u_103
						local v279 = os.clock() * 8
						v278.BackgroundTransparency = math.sin(v279) * 0.25 + 0.25
					elseif v_u_103.BackgroundTransparency ~= 0 then
						v_u_103.BackgroundTransparency = 0
					end
				end)
			elseif not v276 and v_u_275 then
				v_u_275:Disconnect()
				v_u_275 = nil
			end
		end
		v_u_8.MatchChanged:Connect(function(p281)
			-- upvalues: (copy) v_u_139, (copy) v_u_280
			v_u_139(p281)
			v_u_280()
		end)
		v_u_8.PlayerStateChanged:Connect(v_u_280)
		v_u_8.WatchChanged:Connect(function()
			-- upvalues: (copy) v_u_139, (copy) v_u_8, (copy) v_u_280
			v_u_139(v_u_8.Match)
			v_u_280()
		end)
		v_u_8.AttrChanged:Connect(function(p282)
			-- upvalues: (copy) v_u_280, (copy) v_u_139, (copy) v_u_8
			if p282 == "Alive" or p282 == "Team" then
				v_u_280()
				v_u_139(v_u_8.Match)
			end
		end)
		p_u_5.HudHiddenChanged:Connect(v_u_280)
		v_u_139(v_u_8.Match)
		v_u_280()
		p_u_5.MatchHud = {
			["Root"] = v_u_13,
			["Board"] = v_u_15,
			["Health"] = v_u_99
		}
		local function v288() -- name: KillFeedTop
			-- upvalues: (copy) v_u_6, (copy) v_u_15, (copy) v_u_13, (ref) v_u_217, (copy) v_u_226
			if v_u_6.Compact and v_u_15.Visible then
				local v283 = v_u_6.Scale
				local v284 = math.max(v283, 0.01)
				local v285 = v_u_13.AbsolutePosition
				local v286 = (v_u_15.AbsolutePosition.X + v_u_15.AbsoluteSize.X - v285.X) / v284
				local v287 = (v_u_15.AbsolutePosition.Y + v_u_15.AbsoluteSize.Y - v285.Y) / v284
				if (v_u_13.AbsoluteSize / v284).X - 340 < v286 and v287 + 8 > v_u_6.TopInset() then
					return v287 + 8
				else
					return nil
				end
			elseif v_u_217 <= 0 then
				return nil
			else
				return v_u_226().Max.Y + 8
			end
		end
		p_u_5.MatchHud.KillFeedTop = v288
		local function v290(p289) -- name: SetReplaySource
			-- upvalues: (ref) v_u_184, (copy) v_u_214, (copy) v_u_12, (copy) v_u_280
			v_u_184 = p289
			v_u_214(p289 or v_u_12.Character)
			v_u_280()
		end
		p_u_5.MatchHud.SetReplaySource = v290
	end
}