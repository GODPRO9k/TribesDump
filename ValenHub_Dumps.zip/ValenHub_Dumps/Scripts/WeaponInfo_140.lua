local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = {
	["CATEGORIES"] = {
		"bow",
		"gun",
		"melee",
		"throwable",
		"utility",
		"healing",
		"armor",
		"ammo"
	},
	["CATEGORY_NAMES"] = {
		["bow"] = "BOWS",
		["gun"] = "GUNS",
		["melee"] = "MELEE",
		["throwable"] = "THROWABLES",
		["utility"] = "UTILITY",
		["healing"] = "HEALING",
		["armor"] = "ARMOR",
		["ammo"] = "AMMO"
	},
	["CATEGORY_SINGULAR"] = {
		["bow"] = "BOW",
		["gun"] = "GUN",
		["melee"] = "MELEE",
		["throwable"] = "THROWABLE",
		["utility"] = "UTILITY",
		["healing"] = "HEALING",
		["armor"] = "ARMOR",
		["ammo"] = "AMMO"
	},
	["CATEGORY_COLORS"] = {
		["bow"] = Color3.fromRGB(232, 170, 44),
		["gun"] = Color3.fromRGB(128, 150, 176),
		["melee"] = Color3.fromRGB(214, 72, 52),
		["throwable"] = Color3.fromRGB(44, 176, 172),
		["utility"] = Color3.fromRGB(156, 112, 206),
		["healing"] = Color3.fromRGB(110, 196, 86),
		["armor"] = Color3.fromRGB(196, 148, 92),
		["ammo"] = Color3.fromRGB(240, 96, 48)
	}
}
local v_u_3 = {
	["short_bow"] = {
		["name"] = "Wood Bow",
		["category"] = "bow",
		["kind"] = "Bow",
		["points"] = 3,
		["description"] = "Fast draw, arrows drop over distance. Reliable at any range.",
		["bars"] = nil,
		["bars"] = {
			0.45,
			0.8,
			0.7,
			0.8
		}
	},
	["longbow"] = {
		["name"] = "Headhunter",
		["category"] = "bow",
		["kind"] = "Bow",
		["points"] = 5,
		["description"] = "Slow, heavy draw with a zoom. A full-draw headshot kills.",
		["bars"] = nil,
		["bars"] = {
			0.85,
			0.3,
			1,
			0.45
		}
	},
	["crossbow"] = {
		["name"] = "Crossbow",
		["category"] = "bow",
		["kind"] = "Crossbow",
		["points"] = 4,
		["description"] = "Instant bolt, no draw. Reload after every shot.",
		["bars"] = nil,
		["bars"] = {
			0.7,
			0.4,
			0.85,
			0.75
		}
	},
	["musket"] = {
		["name"] = "Musket",
		["category"] = "gun",
		["kind"] = "Musket",
		["points"] = 5,
		["description"] = "Thunderous single shot with a smoke puff. Long reload.",
		["bars"] = nil,
		["bars"] = {
			1,
			0.15,
			0.95,
			0.5
		}
	},
	["blunderbuss"] = {
		["name"] = "Blunderbuss",
		["category"] = "gun",
		["kind"] = "Blunderbuss",
		["points"] = 4,
		["description"] = "A spray of pellets. Devastating up close, useless far away.",
		["bars"] = nil,
		["bars"] = {
			0.9,
			0.3,
			0.25,
			0.7
		}
	},
	["flintlock"] = {
		["name"] = "Flintlock",
		["category"] = "gun",
		["kind"] = "Pistol",
		["points"] = 3,
		["description"] = "One-shot pistol. Finish a wounded foe, then reload.",
		["bars"] = nil,
		["bars"] = {
			0.7,
			0.45,
			0.65,
			0.9
		}
	},
	["bronze_sword"] = {
		["name"] = "Iron Sword",
		["category"] = "melee",
		["kind"] = "Sword",
		["points"] = 3,
		["description"] = "Balanced three-hit combo. Hold to block.",
		["bars"] = nil,
		["bars"] = {
			0.6,
			0.7,
			0.3,
			0.8
		}
	},
	["battle_axe"] = {
		["name"] = "Battle Axe",
		["category"] = "melee",
		["kind"] = "Axe",
		["points"] = 4,
		["description"] = "Heavy swings and a charged overhead that splits guards.",
		["bars"] = nil,
		["bars"] = {
			0.9,
			0.35,
			0.3,
			0.7
		}
	},
	["spear"] = {
		["name"] = "Spear",
		["category"] = "melee",
		["kind"] = "Spear",
		["points"] = 4,
		["description"] = "Longest reach. Charge a lunge to close the gap.",
		["bars"] = nil,
		["bars"] = {
			0.65,
			0.5,
			0.5,
			0.75
		}
	},
	["war_club"] = {
		["name"] = "Hammer",
		["category"] = "melee",
		["kind"] = "Club",
		["points"] = 3,
		["description"] = "Knocks foes back and staggers them.",
		["bars"] = nil,
		["bars"] = {
			0.75,
			0.45,
			0.3,
			0.7
		}
	},
	["obsidian_dagger"] = {
		["name"] = "Diamond Dagger",
		["category"] = "melee",
		["kind"] = "Dagger",
		["points"] = 2,
		["description"] = "Lightning-fast stabs with a backstab bonus.",
		["bars"] = nil,
		["bars"] = {
			0.35,
			1,
			0.2,
			1
		}
	},
	["throwing_knives"] = {
		["name"] = "Throwing Knives",
		["category"] = "throwable",
		["kind"] = "Knives",
		["points"] = 2,
		["description"] = "Fast, flat throws. Five knives per round.",
		["bars"] = nil,
		["bars"] = {
			0.35,
			0.95,
			0.55,
			0.9
		}
	},
	["javelins"] = {
		["name"] = "Javelins",
		["category"] = "throwable",
		["kind"] = "Javelin",
		["points"] = 2,
		["description"] = "Heavy throws that hit hard. Three per round.",
		["bars"] = nil,
		["bars"] = {
			0.8,
			0.4,
			0.65,
			0.7
		}
	},
	["sling"] = {
		["name"] = "Sling",
		["category"] = "throwable",
		["kind"] = "Sling",
		["points"] = 1,
		["description"] = "Lobbed stones that arc over cover. Twelve per round.",
		["bars"] = nil,
		["bars"] = {
			0.35,
			0.8,
			0.7,
			0.9
		}
	},
	["fire_bomb"] = {
		["name"] = "Fireball",
		["category"] = "utility",
		["kind"] = "Bomb",
		["points"] = 2,
		["description"] = "Shatters into a pool of flame that burns anyone inside.",
		["bars"] = nil,
		["bars"] = {
			0.6,
			0.4,
			0.55,
			0.8
		}
	},
	["smoke_bomb"] = {
		["name"] = "Smoke Bomb",
		["category"] = "utility",
		["kind"] = "Bomb",
		["points"] = 1,
		["description"] = "A thick cloud that blocks sight. Reposition, escape, revive a push.",
		["bars"] = nil,
		["bars"] = {
			0,
			0.5,
			0.55,
			1
		}
	},
	["bear_trap"] = {
		["name"] = "Snap Trap",
		["category"] = "utility",
		["kind"] = "Trap",
		["points"] = 1,
		["description"] = "Set it in a chokepoint. Roots the first enemy who steps in.",
		["bars"] = nil,
		["bars"] = {
			0.45,
			0.3,
			0.15,
			0.8
		}
	},
	["bandage"] = {
		["name"] = "Bandage",
		["category"] = "healing",
		["kind"] = "Bandage",
		["points"] = 1,
		["description"] = "A quick, small heal. A few uses per round.",
		["bars"] = nil,
		["bars"] = {
			0,
			0.8,
			0,
			0.8
		}
	},
	["healing_herbs"] = {
		["name"] = "Apple",
		["category"] = "healing",
		["kind"] = "Herbs",
		["points"] = 2,
		["description"] = "Chew to heal over a few seconds. Stay out of sight.",
		["bars"] = nil,
		["bars"] = {
			0,
			0.5,
			0,
			0.7
		}
	},
	["healing_tonic"] = {
		["name"] = "Golden Apple",
		["category"] = "healing",
		["kind"] = "Tonic",
		["points"] = 3,
		["description"] = "One big heal over time. Drink it behind cover.",
		["bars"] = nil,
		["bars"] = {
			0,
			0.3,
			0,
			0.6
		}
	},
	["hide_armor"] = {
		["name"] = "Leather Armor",
		["category"] = "armor",
		["hotbar"] = false,
		["points"] = 2,
		["armor"] = 25,
		["speed"] = 0.97,
		["description"] = "Light armor: soaks a hit or two, barely slows you."
	},
	["bone_armor"] = {
		["name"] = "Iron Armor",
		["category"] = "armor",
		["hotbar"] = false,
		["points"] = 4,
		["armor"] = 50,
		["speed"] = 0.93,
		["description"] = "Medium armor: a real second health bar, a little slower."
	},
	["bronze_armor"] = {
		["name"] = "Diamond Armor",
		["category"] = "armor",
		["hotbar"] = false,
		["points"] = 6,
		["armor"] = 80,
		["speed"] = 0.88,
		["description"] = "Heavy armor: shrug off a volley, but you\'ll feel the weight."
	}
}
local v_u_4 = {
	"DAMAGE",
	"SPEED",
	"RANGE",
	"MOBILITY"
}
local v_u_5 = {
	["items"] = nil,
	["armor"] = "hide_armor",
	["ammo"] = nil,
	["items"] = { "bronze_sword", "short_bow", "bandage" },
	["ammo"] = {
		["arrows"] = 3
	}
}
local v_u_6 = {
	["arrows"] = {
		["id"] = "arrows",
		["name"] = "Arrows",
		["perBundle"] = 12,
		["points"] = 1,
		["order"] = 1
	},
	["shot"] = {
		["id"] = "shot",
		["name"] = "Bullets",
		["perBundle"] = 6,
		["points"] = 1,
		["order"] = 2
	}
}
local v_u_7 = {
	["short_bow"] = "arrows",
	["longbow"] = "arrows",
	["crossbow"] = "arrows",
	["musket"] = "shot",
	["flintlock"] = "shot",
	["blunderbuss"] = "shot"
}
local v_u_8 = nil
local v_u_9 = (-1 / 0)
local function v_u_14() -- name: getRegistry
	-- upvalues: (ref) v_u_8, (ref) v_u_9, (copy) v_u_1
	if v_u_8 then
		return v_u_8
	end
	if os.clock() - v_u_9 < 5 then
		return nil
	end
	v_u_9 = os.clock()
	local v10 = v_u_1.Shared:FindFirstChild("Weapons")
	if v10 and v10:IsA("ModuleScript") then
		local v11 = require
		local v12, v13 = pcall(v11, v10)
		if v12 and type(v13) == "table" then
			v_u_8 = v13
		end
	end
	return v_u_8
end
local function v_u_36(p15) -- name: fromRegistry
	-- upvalues: (copy) v_u_14
	local v16 = v_u_14()
	if not v16 then
		return nil
	end
	local v17 = v16.Get
	if type(v17) == "function" then
		local v18 = v16.Get
		local v19, v20 = pcall(v18, p15)
		if v19 and type(v20) == "table" then
			return v20
		end
	end
	local v21 = v16.AMMO
	local v22
	if type(v21) == "table" then
		v22 = v16.AMMO[p15]
	else
		v22 = false
	end
	if type(v22) ~= "table" or v22.unlock ~= true then
		return nil
	end
	local v23 = {
		["id"] = nil,
		["name"] = nil,
		["category"] = "ammo",
		["kind"] = "Ammo",
		["role"] = nil,
		["points"] = nil,
		["hotbar"] = false,
		["isAmmo"] = true,
		["description"] = nil,
		["stats"] = nil,
		["details"] = nil,
		["tuning"] = nil,
		["id"] = p15,
		["name"] = v22.name,
		["role"] = v22.role or "Ammo",
		["points"] = v22.points,
		["description"] = v22.description,
		["stats"] = {
			["damage"] = 0,
			["rate"] = 0,
			["range"] = 0,
			["mobility"] = 0
		}
	}
	local v24 = {}
	local v25 = {}
	local v26 = v22.perBundle
	__set_list(v25, 1, {"Bundle", tostring(v26) .. " arrows"})
	local v27 = {}
	local v28 = v22.points
	__set_list(v27, 1, {"Cost", tostring(v28) .. " points"})
	local v29 = {}
	local v30 = "Burn"
	local v31 = v22.burn
	local v32
	if type(v31) == "table" then
		local v33 = v22.burn.damage
		local v34 = tostring(v33)
		local v35 = v22.burn.ticks
		v32 = v34 .. " \195\151 " .. tostring(v35)
	else
		v32 = "-"
	end
	__set_list(v29, 1, {v30, v32})
	__set_list(v24, 1, {v25, v27, v29})
	v23.details = v24
	v23.tuning = {}
	return v23
end
v_u_2.OwnsAmmo = nil
local function v_u_49() -- name: allIds
	-- upvalues: (copy) v_u_14, (copy) v_u_3
	local v37 = {}
	local v38 = {}
	local v39 = v_u_14()
	if v39 then
		local v40 = v39.All
		if type(v40) == "function" then
			local v41 = v39.All
			local v42, v43 = pcall(v41)
			if v42 and type(v43) == "table" then
				for _, v44 in v43 do
					if type(v44) ~= "table" then
						continue
					end
					local v45 = v44.id
					if type(v45) ~= "string" or v37[v45] then
						continue
					end
					v37[v45] = true
					table.insert(v38, v45)
				end
			end
		end
	end
	if v39 then
		local v46 = v39.UnlockAmmo
		if type(v46) == "function" then
			for _, v47 in v39.UnlockAmmo() do
				if type(v47) ~= "string" or v37[v47] then
					continue
				end
				v37[v47] = true
				table.insert(v38, v47)
			end
		end
	end
	for v48 in v_u_3 do
		if type(v48) ~= "string" or v37[v48] then
			continue
		end
		v37[v48] = true
		table.insert(v38, v48)
	end
	return v38
end
local v_u_50 = {}
local v_u_51 = 0
function v_u_2.Get(p52) -- name: Get
	-- upvalues: (ref) v_u_51, (copy) v_u_50, (copy) v_u_3, (copy) v_u_36, (copy) v_u_2
	if type(p52) ~= "string" then
		return nil
	end
	if os.clock() - v_u_51 > 10 then
		table.clear(v_u_50)
		v_u_51 = os.clock()
	end
	local v53 = v_u_50[p52]
	if v53 then
		return v53
	end
	local v54 = v_u_3[p52]
	local v55 = v_u_36(p52)
	if not (v55 or v54) then
		return nil
	end
	local v56 = {}
	if v54 then
		for v57, v58 in v54 do
			v56[v57] = v58
		end
	end
	if v55 then
		for v59, v60 in v55 do
			v56[v59] = v60
		end
	end
	v56.id = p52
	local v61 = v56.name
	local v62
	if type(v61) == "string" then
		v62 = v56.name
	else
		v62 = p52:gsub("_", " ")
	end
	v56.name = v62
	local v63 = v56.description
	v56.description = type(v63) ~= "string" and "" or v56.description
	if not v_u_2.CATEGORY_NAMES[v56.category] then
		v56.category = v54 and (v54.category or "utility") or "utility"
	end
	local v64 = v56.points
	if type(v64) ~= "number" then
		v56.points = v54 and v54.points or 1
	end
	if v56.hotbar == nil then
		v56.hotbar = v56.category ~= "armor"
	end
	v_u_50[p52] = v56
	return v56
end
function v_u_2.Name(p65) -- name: Name
	-- upvalues: (copy) v_u_2
	local v66 = v_u_2.Get(p65)
	if v66 then
		return v66.name
	else
		return type(p65) ~= "string" and "" or p65
	end
end
function v_u_2.Points(p67) -- name: Points
	-- upvalues: (copy) v_u_2
	local v68 = v_u_2.Get(p67)
	return not v68 and 0 or v68.points
end
function v_u_2.IsArmor(p69) -- name: IsArmor
	-- upvalues: (copy) v_u_2
	local v70 = v_u_2.Get(p69)
	local v71
	if v70 == nil or v70.category == "ammo" then
		v71 = false
	else
		v71 = v70.category == "armor" and true or v70.hotbar == false
	end
	return v71
end
function v_u_2.AmmoTypes() -- name: AmmoTypes
	-- upvalues: (copy) v_u_14, (copy) v_u_6
	local v72 = v_u_14()
	local v73 = {}
	if v72 then
		local v74 = v72.AMMO
		if type(v74) == "table" then
			for v80, v76 in v72.AMMO do
				if type(v76) ~= "table" then
					continue
				end
				local v77 = v_u_6[v80]
				local v78 = {
					["id"] = v80
				}
				local v79 = v76.name
				local v80
				if v79 then
					v80 = v79
				elseif v77 then
					v80 = v77.name or v80
				end
				v78.name = v80
				v78.perBundle = v76.perBundle or (v76.count or v76.amount or (v77 and (v77.perBundle or 10) or 10))
				v78.points = v76.points or v76.cost or (v77 and (v77.points or 1) or 1)
				v78.order = v76.order or (v77 and v77.order or 9)
				v78.as = v76.as
				v78.optional = v76.as ~= nil
				v78.description = v76.description
				table.insert(v73, v78)
			end
		else
			for v83, v84 in v_u_6 do
				table.insert(v73, v84)
			end
		end
	else
		for v83, v84 in v_u_6 do
			table.insert(v73, v84)
		end
	end
	table.sort(v73, function(p85, p86)
		return p85.order < p86.order
	end)
	return v73
end
function v_u_2.AmmoDef(p87) -- name: AmmoDef
	-- upvalues: (copy) v_u_2
	for _, v88 in v_u_2.AmmoTypes() do
		if v88.id ~= p87 then
			continue
		end
		return v88
	end
	return nil
end
function v_u_2.MaxAmmoBundles() -- name: MaxAmmoBundles
	-- upvalues: (copy) v_u_14
	local v89 = v_u_14()
	if v89 then
		local v90 = v89.MAX_AMMO_BUNDLES
		if type(v90) == "number" then
			return v89.MAX_AMMO_BUNDLES
		end
	end
	return 3
end
function v_u_2.AmmoOf(p91) -- name: AmmoOf
	-- upvalues: (copy) v_u_2, (copy) v_u_7
	local v92 = v_u_2.Get(p91)
	if v92 then
		local v93 = v92.ammoType or v92.ammo
		if not v93 then
			local v94 = v92.tuning
			if type(v94) == "table" then
				v93 = v92.tuning.ammoType or v92.tuning.ammo
			else
				v93 = false
			end
		end
		if type(v93) == "string" and v93 ~= "" then
			return v93
		else
			return v_u_7[v92.id]
		end
	else
		return nil
	end
end
function v_u_2.AmmoNeeded(p95) -- name: AmmoNeeded
	-- upvalues: (copy) v_u_14, (copy) v_u_2
	local v96 = {}
	local v97
	if type(p95) == "table" then
		local v98 = p95.items
		v97 = type(v98) ~= "table" and {} or p95.items
	else
		v97 = {}
	end
	local v99 = v_u_14()
	for _, v100 in v97 do
		local v101 = v_u_2.AmmoOf(v100)
		if not v101 then
			continue
		end
		v96[v101] = true
		if not v99 then
			continue
		end
		local v102 = v99.AltAmmo
		if type(v102) ~= "function" then
			continue
		end
		for _, v103 in v99.AltAmmo(v101) do
			local v104 = v99.AMMO
			local v105
			if type(v104) == "table" then
				v105 = v99.AMMO[v103]
			else
				v105 = false
			end
			local v106 = v_u_2.OwnsAmmo
			if type(v105) == "table" and (v105.unlock == true and (v106 and not v106(v103))) then
				continue
			end
			v96[v103] = true
		end
	end
	return v96
end
function v_u_2.Budget() -- name: Budget
	-- upvalues: (copy) v_u_14
	local v107 = v_u_14()
	if v107 then
		local v108 = v107.BUDGET
		if type(v108) == "number" then
			return v107.BUDGET
		end
	end
	return 12
end
function v_u_2.MaxItems() -- name: MaxItems
	-- upvalues: (copy) v_u_14
	local v109 = v_u_14()
	if v109 then
		local v110 = v109.MAX_ITEMS
		if type(v110) == "number" then
			return v109.MAX_ITEMS
		end
	end
	return 6
end
function v_u_2.ByCategory(p111) -- name: ByCategory
	-- upvalues: (copy) v_u_49, (copy) v_u_2
	local v112 = {}
	for _, v113 in v_u_49() do
		local v114 = v_u_2.Get(v113)
		if not v114 or v114.category ~= p111 then
			continue
		end
		table.insert(v112, v114)
	end
	table.sort(v112, function(p115, p116)
		if p115.points == p116.points then
			return p115.name < p116.name
		else
			return p115.points < p116.points
		end
	end)
	return v112
end
function v_u_2.Normalize(p117) -- name: Normalize
	local v118 = {
		["items"] = nil,
		["armor"] = false,
		["ammo"] = nil,
		["items"] = {},
		["ammo"] = {}
	}
	if type(p117) ~= "table" then
		return v118
	end
	local v119 = p117.ammo
	if type(v119) == "table" then
		for v120, v121 in p117.ammo do
			if type(v120) ~= "string" or (type(v121) ~= "number" or v121 <= 0) then
				continue
			end
			v118.ammo[v120] = math.floor(v121)
		end
	end
	local v122 = p117.items
	if type(v122) == "table" then
		for _, v123 in p117.items do
			if type(v123) ~= "string" then
				continue
			end
			local v124 = v118.items
			table.insert(v124, v123)
		end
		local v125 = p117.armor
		if type(v125) == "string" and p117.armor ~= "" then
			v118.armor = p117.armor
			return v118
		end
	else
		for _, v126 in {
			"primary",
			"secondary",
			"melee",
			"utility"
		} do
			local v127 = p117[v126]
			if type(v127) ~= "string" then
				continue
			end
			local v128 = v118.items
			local v129 = p117[v126]
			table.insert(v128, v129)
		end
	end
	return v118
end
function v_u_2.Cost(p130) -- name: Cost
	-- upvalues: (copy) v_u_2
	local v131 = v_u_2.Normalize(p130)
	local v132 = 0
	for _, v133 in v131.items do
		v132 = v132 + v_u_2.Points(v133)
	end
	if v131.armor then
		v132 = v132 + v_u_2.Points(v131.armor)
	end
	for v134, v135 in v131.ammo do
		local v136 = v_u_2.AmmoDef(v134)
		if not v136 then
			continue
		end
		v132 = v132 + v136.points * v135
	end
	return v132
end
function v_u_2.Validate(p137) -- name: Validate
	-- upvalues: (copy) v_u_14, (copy) v_u_2
	local v138 = v_u_14()
	if v138 then
		local v139 = v138.Validate
		if type(v139) == "function" then
			local v140 = v138.AMMO
			if type(v140) == "table" then
				local v141 = v138.Validate
				local v142 = v_u_2.Normalize
				local v143, v144, v145, v146 = pcall(v141, v142(p137))
				if v143 and type(v146) == "table" then
					return v144 == true, v145, v_u_2.Normalize(v146)
				end
			end
		end
	end
	local v147 = v_u_2.Normalize(p137)
	local v148 = {}
	local v149 = {
		["items"] = nil,
		["armor"] = false,
		["ammo"] = nil,
		["items"] = {},
		["ammo"] = {}
	}
	for _, v150 in v147.items do
		if not v_u_2.Get(v150) or v148[v150] then
			continue
		end
		v148[v150] = true
		if v_u_2.IsArmor(v150) then
			if v149.armor then
				continue
			end
			v149.armor = v150
		else
			if #v149.items >= v_u_2.MaxItems() then
				continue
			end
			local v151 = v149.items
			table.insert(v151, v150)
		end
	end
	if v147.armor and v_u_2.IsArmor(v147.armor) then
		v149.armor = v147.armor
	end
	for v152, v153 in v147.ammo do
		if not v_u_2.AmmoDef(v152) then
			continue
		end
		local v154 = v149.ammo
		local v155 = v_u_2.MaxAmmoBundles()
		v154[v152] = math.clamp(v153, 0, v155)
	end
	local v156 = nil
	if v_u_2.Cost(v149) > v_u_2.Budget() then
		local v157 = v_u_2.AmmoNeeded(v149)
		for v158 in v149.ammo do
			if v157[v158] then
				continue
			end
			v149.ammo[v158] = nil
		end
	end
	while v_u_2.Cost(v149) > v_u_2.Budget() and #v149.items > 0 do
		table.remove(v149.items)
		local v159 = v_u_2.AmmoNeeded(v149)
		for v160 in v149.ammo do
			if v159[v160] then
				continue
			end
			v149.ammo[v160] = nil
		end
		v156 = "Over budget"
	end
	if v_u_2.Cost(v149) > v_u_2.Budget() then
		v149.armor = false
		v156 = "Over budget"
	end
	return v156 == nil, v156, v149
end
function v_u_2.DefaultLoadout() -- name: DefaultLoadout
	-- upvalues: (copy) v_u_14, (copy) v_u_2, (copy) v_u_5
	local v161 = v_u_14()
	if v161 then
		local v162 = v161.DEFAULT_LOADOUT
		if type(v162) == "table" then
			return v_u_2.Normalize(v161.DEFAULT_LOADOUT)
		end
	end
	return v_u_2.Normalize(v_u_5)
end
v_u_2.FILTERS = {
	{
		["id"] = "all",
		["name"] = "ALL",
		["cats"] = nil
	},
	{
		["id"] = "weapons",
		["name"] = "WEAPONS",
		["cats"] = nil,
		["cats"] = {
			["bow"] = true,
			["gun"] = true,
			["melee"] = true
		}
	},
	{
		["id"] = "utility",
		["name"] = "UTILITY",
		["cats"] = nil,
		["cats"] = {
			["throwable"] = true,
			["utility"] = true
		}
	},
	{
		["id"] = "healing",
		["name"] = "HEALING",
		["cats"] = nil,
		["cats"] = {
			["healing"] = true
		}
	},
	{
		["id"] = "armor",
		["name"] = "ARMOR",
		["cats"] = nil,
		["cats"] = {
			["armor"] = true
		}
	}
}
function v_u_2.AllItems() -- name: AllItems
	-- upvalues: (copy) v_u_2
	local v163 = {}
	for _, v164 in v_u_2.CATEGORIES do
		for _, v165 in v_u_2.ByCategory(v164) do
			table.insert(v163, v165)
		end
	end
	return v163
end
function v_u_2.ArmorStats(p166) -- name: ArmorStats
	local v167 = p166 and (p166.tuning or p166.stats or {}) or {}
	local v168 = v167.armor or v167.maxArmor or (p166.armor or 0)
	local v169 = v167.speedMult or (v167.moveSpeedMult or v167.speed or (p166.speed or 1))
	return type(v168) ~= "number" and 0 or v168, type(v169) ~= "number" and 1 or v169
end
function v_u_2.Bars(p170) -- name: Bars
	-- upvalues: (copy) v_u_2, (copy) v_u_14, (copy) v_u_3, (copy) v_u_4
	local v171 = {}
	if not p170 then
		return v171
	end
	if p170.category ~= "armor" then
		local v172 = v_u_14()
		local v173 = p170.stats
		if type(v173) == "table" and v172 then
			local v174 = v172.STAT_BARS
			if type(v174) == "table" then
				for _, v175 in v172.STAT_BARS do
					local v176
					if type(v175) == "table" then
						v176 = p170.stats[v175.key]
					else
						v176 = false
					end
					if type(v176) ~= "number" then
						continue
					end
					local v177 = {}
					local v178 = string.upper
					local v179 = v175.label or v175.key
					v177.label = v178((tostring(v179)))
					local v180 = v176 / 10
					v177.frac = math.clamp(v180, 0, 1)
					table.insert(v171, v177)
				end
				if #v171 >= 2 then
					return v171
				end
				v171 = {}
			end
		end
		local v181 = v_u_3[p170.id]
		local v182 = p170.bars
		if v182 then
			v181 = v182
		elseif v181 then
			v181 = v181.bars
		end
		if type(v181) == "table" then
			for v183, v184 in v181 do
				if type(v184) ~= "number" or not v_u_4[v183] then
					continue
				end
				local v185 = {
					["label"] = v_u_4[v183],
					["frac"] = math.clamp(v184, 0, 1)
				}
				table.insert(v171, v185)
			end
		end
		return v171
	end
	local v186, v187 = v_u_2.ArmorStats(p170)
	local v188 = {
		["label"] = "ARMOR",
		["frac"] = nil
	}
	local v189 = v186 / 100
	v188.frac = math.clamp(v189, 0.05, 1)
	table.insert(v171, v188)
	local v190 = {
		["label"] = "SPEED",
		["frac"] = nil
	}
	local v191 = (v187 - 0.75) / 0.25
	v190.frac = math.clamp(v191, 0.05, 1)
	table.insert(v171, v190)
	local v192 = p170.tuning
	local v193
	if type(v192) == "table" then
		v193 = p170.tuning.rangedReduction
	else
		v193 = false
	end
	if type(v193) == "number" and v193 > 0 then
		local v194 = {
			["label"] = "VS RANGED",
			["frac"] = nil
		}
		local v195 = v193 / 0.4
		v194.frac = math.clamp(v195, 0.05, 1)
		table.insert(v171, v194)
	end
	return v171
end
return v_u_2