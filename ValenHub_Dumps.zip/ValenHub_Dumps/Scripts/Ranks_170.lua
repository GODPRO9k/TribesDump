local v_u_1 = {
	["WIN"] = 30,
	["LOSS"] = -30,
	["CLIMB_FROM"] = 400,
	["WIN_FALL"] = 200,
	["LOSS_RISE"] = 90,
	["WIN_MIN"] = 12,
	["LOSS_MAX"] = -60,
	["GATE_TOP"] = 4,
	["START"] = 1792195200,
	["PER_DAY_MAX"] = 150,
	["LADDER"] = table.freeze({
		table.freeze({
			["id"] = "bronze",
			["name"] = "Bronze",
			["trophies"] = 0,
			["items"] = nil,
			["items"] = table.freeze({})
		}),
		table.freeze({
			["id"] = "silver",
			["name"] = "Silver",
			["trophies"] = 60,
			["items"] = nil,
			["items"] = table.freeze({ "harpoon", "beehive", "longbow" })
		}),
		table.freeze({
			["id"] = "gold",
			["name"] = "Gold",
			["trophies"] = 200,
			["items"] = nil,
			["items"] = table.freeze({ "twin_hatchets", "bronze_armor", "musket" })
		}),
		table.freeze({
			["id"] = "platinum",
			["name"] = "Platinum",
			["trophies"] = 400,
			["items"] = nil,
			["items"] = table.freeze({ "gauntlets", "katana" })
		}),
		table.freeze({
			["id"] = "diamond",
			["name"] = "Diamond",
			["trophies"] = 700,
			["items"] = nil,
			["items"] = table.freeze({ "scythe" })
		}),
		table.freeze({
			["id"] = "master",
			["name"] = "Master",
			["trophies"] = 1100,
			["items"] = nil,
			["items"] = table.freeze({})
		}),
		table.freeze({
			["id"] = "grandmaster",
			["name"] = "Grandmaster",
			["trophies"] = 1600,
			["items"] = nil,
			["items"] = table.freeze({})
		}),
		table.freeze({
			["id"] = "immortal",
			["name"] = "Immortal",
			["trophies"] = 2200,
			["items"] = nil,
			["items"] = table.freeze({})
		})
	})
}
local v_u_2 = {}
for v3, v4 in v_u_1.LADDER do
	for _, v5 in v4.items do
		v_u_2[v5] = v3
	end
end
function v_u_1.Count() -- name: Count
	-- upvalues: (copy) v_u_1
	return #v_u_1.LADDER
end
function v_u_1.Get(p6) -- name: Get
	-- upvalues: (copy) v_u_1
	local v7 = (type(p6) ~= "number" or (p6 ~= p6 or (p6 == (1 / 0) or p6 == (-1 / 0)))) and 1 or p6
	local v8 = math.floor(v7)
	local v9 = #v_u_1.LADDER
	local v10 = math.clamp(v8, 1, v9)
	return v_u_1.LADDER[v10]
end
function v_u_1.RankOf(p11) -- name: RankOf
	-- upvalues: (copy) v_u_1
	local v12 = (type(p11) ~= "number" or (p11 ~= p11 or (p11 == (1 / 0) or p11 == (-1 / 0)))) and 0 or p11
	local v13 = 1
	for v14, v15 in v_u_1.LADDER do
		if v15.trophies > v12 then
			continue
		end
		v13 = v14
	end
	return v13
end
function v_u_1.Floor(p16) -- name: Floor
	-- upvalues: (copy) v_u_1
	local v17 = v_u_1.Get
	local v18 = (type(p16) ~= "number" or (p16 ~= p16 or (p16 == (1 / 0) or p16 == (-1 / 0)))) and 1 or p16
	local v19 = math.floor(v18)
	local v20 = v_u_1.GATE_TOP
	return v17((math.min(v19, v20))).trophies
end
function v_u_1.Steps(p21) -- name: Steps
	-- upvalues: (copy) v_u_1
	local v22 = ((type(p21) ~= "number" or (p21 ~= p21 or (p21 == (1 / 0) or p21 == (-1 / 0)))) and 0 or p21) - v_u_1.CLIMB_FROM
	local v23 = math.max(0, v22)
	local v24 = v_u_1.WIN_MIN
	local v25 = v_u_1.WIN - v23 / v_u_1.WIN_FALL + 0.5
	local v26 = math.floor(v25)
	local v27 = math.max(v24, v26)
	local v28 = v_u_1.LOSS_MAX
	local v29 = -v_u_1.LOSS + v23 / v_u_1.LOSS_RISE + 0.5
	local v30 = -math.floor(v29)
	return v27, math.max(v28, v30)
end
function v_u_1.Apply(p31, p32, p33) -- name: Apply
	-- upvalues: (copy) v_u_1
	local v34 = (type(p31) ~= "number" or (p31 ~= p31 or (p31 == (1 / 0) or p31 == (-1 / 0)))) and 0 or p31
	local v35 = math.floor(v34)
	local v36 = math.max(0, v35)
	local v37 = (type(p32) ~= "number" or (p32 ~= p32 or (p32 == (1 / 0) or p32 == (-1 / 0)))) and 1 or p32
	local v38 = math.floor(v37)
	local v39 = #v_u_1.LADDER
	local v40 = math.clamp(v38, 1, v39)
	local v41 = v_u_1.RankOf
	local v42 = math.max(v40, v41(v36))
	if p33 == nil then
		return v36, 0, v42, false
	end
	local v44, v44 = v_u_1.Steps(v36)
	local v45 = v36 + v44
	local v46 = v_u_1.Floor(v42)
	local v47 = math.max(v45, v46, 0)
	local v48 = v_u_1.RankOf
	local v49 = math.max(v42, v48(v47))
	local v50 = v47 - v36
	local v51 = not p33
	if v51 then
		v51 = v45 < v47
	end
	return v47, v50, v49, v51
end
function v_u_1.ItemRank(p52) -- name: ItemRank
	-- upvalues: (copy) v_u_2
	return type(p52) == "string" and (v_u_2[p52] or 1) or 1
end
function v_u_1.Allows(p53, p54) -- name: Allows
	-- upvalues: (copy) v_u_1
	local v55 = v_u_1.ItemRank(p54)
	local v56 = (type(p53) ~= "number" or (p53 ~= p53 or (p53 == (1 / 0) or p53 == (-1 / 0)))) and 1 or p53
	return v55 <= math.floor(v56)
end
function v_u_1.NewItems(p57, p58) -- name: NewItems
	-- upvalues: (copy) v_u_1
	local v59 = (type(p57) ~= "number" or (p57 ~= p57 or (p57 == (1 / 0) or p57 == (-1 / 0)))) and 1 or p57
	local v60 = math.floor(v59)
	local v61 = (type(p58) ~= "number" or (p58 ~= p58 or (p58 == (1 / 0) or p58 == (-1 / 0)))) and 1 or p58
	local v62 = math.floor(v61)
	local v63 = v60 + 1
	local v64 = math.max(1, v63)
	local v65 = #v_u_1.LADDER
	local v66 = {}
	for v67 = v64, math.min(v65, v62) do
		for _, v68 in v_u_1.LADDER[v67].items do
			table.insert(v66, v68)
		end
	end
	return v66
end
function v_u_1.Progress(p69) -- name: Progress
	-- upvalues: (copy) v_u_1
	local v70 = (type(p69) ~= "number" or (p69 ~= p69 or (p69 == (1 / 0) or p69 == (-1 / 0)))) and 0 or p69
	local v71 = math.max(0, v70)
	local v72 = v_u_1.RankOf(v71)
	local v73 = v_u_1.LADDER[v72]
	local v74 = v_u_1.LADDER[v72 + 1]
	local v75 = v71 - v73.trophies
	if v74 then
		return v72, v75, v74.trophies - v73.trophies
	else
		return v72, v75, nil
	end
end
function v_u_1.PlausibleMax(p76) -- name: PlausibleMax
	-- upvalues: (copy) v_u_1
	local v77 = 0
	local v78 = v_u_1.START
	if type(p76) == "number" and (p76 == p76 and (p76 ~= (1 / 0) and p76 ~= (-1 / 0))) then
		v78 = p76
	end
	local v79 = (v78 - v_u_1.START) / 86400
	local v80 = (math.max(v77, v79) + 1) * v_u_1.PER_DAY_MAX
	return math.floor(v80)
end
v_u_1.REWARD_GOLDEN_FROM = 5
v_u_1.LEAD = 0.2
function v_u_1.Lead(p81, p82) -- name: Lead
	-- upvalues: (copy) v_u_1
	local v83 = math.floor(p81)
	local v84 = math.max(0, v83)
	local v85 = v84 * v_u_1.LEAD
	local v86 = math.ceil(v85)
	local v87 = math.floor(p82 or 0)
	local v88 = v84 - math.max(0, v87) - 1
	local v89 = math.min(v86, v88)
	return math.max(0, v89)
end
function v_u_1.RewardKind(p90) -- name: RewardKind
	-- upvalues: (copy) v_u_1
	return v_u_1.REWARD_GOLDEN_FROM <= p90 and "golden" or "victory"
end
return table.freeze(v_u_1)