local v1 = game:GetService("CorePackages")
local v2 = require(v1.Packages.Dev.JestGlobals)
local v3 = v2.describe
local v_u_4 = v2.expect
local v_u_5 = v2.it
local v6 = require(script.Parent.VRCameraTeleportDetector)
local v_u_7 = v6.shouldRecenter
local v_u_8 = v6.JUMP_STUDS
local v_u_9 = v6.SETTLED_STUDS
local v_u_10 = v6.DEBOUNCE_SECONDS
v3("VRCameraTeleportDetector.shouldRecenter", function()
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_7, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10
	v_u_5("fires on a discrete jump from rest (no prior step, never recentered)", function()
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_8
		v_u_4(v_u_7(nil, v_u_8 + 10, nil, 100)).toBe(true)
	end)
	v_u_5("fires on a discrete jump preceded by a near-still frame", function()
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_9, (ref) v_u_8
		v_u_4(v_u_7(v_u_9 - 0.5, v_u_8 + 10, nil, 100)).toBe(true)
	end)
	v_u_5("does not fire for sub-threshold motion", function()
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_8
		v_u_4(v_u_7(0, v_u_8 - 0.1, nil, 100)).toBe(false)
		v_u_4(v_u_7(0, 0, nil, 100)).toBe(false)
	end)
	v_u_5("does not fire when the previous frame was already moving (continuous motion)", function()
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_9, (ref) v_u_8
		v_u_4(v_u_7(v_u_9 + 0.1, v_u_8 + 10, nil, 100)).toBe(false)
	end)
	v_u_5("does not fire within the debounce interval", function()
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_8, (ref) v_u_10
		v_u_4(v_u_7(nil, v_u_8 + 10, 100, 100 + v_u_10 - 0.01)).toBe(false)
	end)
	v_u_5("fires again once the debounce interval has elapsed", function()
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_8, (ref) v_u_10
		v_u_4(v_u_7(nil, v_u_8 + 10, 100, 100 + v_u_10 + 0.01)).toBe(true)
	end)
	v_u_5("does not retrigger every frame under continuous per-frame CFrame writes (oscillation guard)", function()
		-- upvalues: (ref) v_u_8, (ref) v_u_7, (ref) v_u_4
		local v11 = v_u_8 + 10
		local v12 = nil
		local v13 = nil
		local v14 = 0
		local v15 = 0
		for _ = 1, 120 do
			if v_u_7(v12, v11, v13, v14) then
				v15 = v15 + 1
				v13 = v14
			end
			v14 = v14 + 0.016666666666666666
			v12 = v11
		end
		v_u_4(v15).toBe(1)
	end)
end)