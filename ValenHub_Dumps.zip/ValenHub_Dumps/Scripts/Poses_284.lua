local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = {}
local v_u_5 = v_u_2.LocalPlayer
v_u_4.POSES = {}
local v_u_6 = {}
local v_u_7 = {}
local function v19() -- name: rebuild
	-- upvalues: (copy) v_u_4, (copy) v_u_7
	for v8, v9 in v_u_4.POSES do
		local v10 = {}
		for v11, v12 in v9 do
			local v13 = CFrame.Angles
			local v14 = v12.X
			local v15 = math.rad(v14)
			local v16 = v12.Y
			local v17 = math.rad(v16)
			local v18 = v12.Z
			v10[v11] = v13(v15, v17, (math.rad(v18)))
		end
		v_u_7[v8] = v10
	end
end
v19()
v_u_4.Rebuild = v19
local v_u_20 = {
	"RightShoulder",
	"RightElbow",
	"RightWrist",
	"LeftShoulder",
	"LeftElbow"
}
local function v_u_25(p21) -- name: findMotors
	-- upvalues: (copy) v_u_20
	local v22 = {}
	for _, v23 in v_u_20 do
		local v24 = p21:FindFirstChild(v23, true)
		if not (v24 and (v24:IsA("Motor6D") or v24:IsA("AnimationConstraint"))) then
			continue
		end
		v22[v23] = v24
	end
	return v22
end
local function v_u_29(p26) -- name: refresh
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_25
	local v27 = p26:FindFirstChildOfClass("Tool")
	if v27 then
		v27 = v27:GetAttribute("Kind")
	end
	if type(v27) ~= "string" or not v_u_7[v27] then
		v27 = nil
	end
	if v27 then
		local v28 = v_u_6[p26]
		if not v28 then
			v28 = {
				["model"] = nil,
				["pose"] = nil,
				["alpha"] = 0,
				["motors"] = nil,
				["kick"] = 0,
				["model"] = p26,
				["motors"] = v_u_25(p26)
			}
			v_u_6[p26] = v28
		end
		v28.pose = v27
		v28.motors = v_u_25(p26)
	elseif v_u_6[p26] then
		v_u_6[p26].pose = nil
	end
end
function v_u_4.Kick(p30, p31) -- name: Kick
	-- upvalues: (copy) v_u_6, (copy) v_u_25
	if p30 then
		local v32 = v_u_6[p30]
		if not v32 then
			v32 = {
				["model"] = nil,
				["pose"] = nil,
				["alpha"] = 0,
				["motors"] = nil,
				["kick"] = 0,
				["model"] = p30,
				["motors"] = v_u_25(p30)
			}
			v_u_6[p30] = v32
		end
		if not next(v32.motors) then
			v32.motors = v_u_25(p30)
		end
		local v33 = v32.kick
		local v34 = math.min(p31, 45)
		v32.kick = math.max(v33, v34)
	end
end
local v_u_35 = {}
local function v_u_39(p_u_36) -- name: watch
	-- upvalues: (copy) v_u_35, (copy) v_u_29, (copy) v_u_6
	if not v_u_35[p_u_36] then
		v_u_35[p_u_36] = true
		p_u_36.ChildAdded:Connect(function(p37)
			-- upvalues: (ref) v_u_29, (copy) p_u_36
			if p37:IsA("Tool") then
				task.defer(v_u_29, p_u_36)
			end
		end)
		p_u_36.ChildRemoved:Connect(function(p38)
			-- upvalues: (ref) v_u_29, (copy) p_u_36
			if p38:IsA("Tool") then
				task.defer(v_u_29, p_u_36)
			end
		end)
		p_u_36.Destroying:Once(function()
			-- upvalues: (ref) v_u_35, (copy) p_u_36, (ref) v_u_6
			v_u_35[p_u_36] = nil
			v_u_6[p_u_36] = nil
		end)
		v_u_29(p_u_36)
	end
end
v_u_4.Watch = v_u_39
local function v_u_58(p40) -- name: step
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_7
	local v41 = v_u_5.Character
	for v42, v43 in v_u_6 do
		if v42:IsDescendantOf(workspace) then
			if (v43.pose and 1 or 0) > v43.alpha then
				local v44 = v43.alpha + p40 / 0.1
				v43.alpha = math.min(1, v44)
			else
				local v45 = v43.alpha - p40 / 0.14
				v43.alpha = math.max(0, v45)
			end
			local v46 = v43.kick - p40 * v43.kick * 14 - p40 * 20
			v43.kick = math.max(0, v46)
			if v43.alpha <= 0 and v43.kick <= 0 then
				if v43.pose then
					continue
				end
				v_u_6[v42] = nil
			else
				local v47 = v43.alpha * v43.alpha * (3 - v43.alpha * 2)
				local v48 = v43.pose
				if v48 then
					v48 = v_u_7[v43.pose]
				end
				local v49
				if v42 == v41 and v43.pose then
					local v50 = workspace.CurrentCamera.CFrame.LookVector.Y
					local v51 = math.clamp(v50, -1, 1)
					v49 = math.asin(v51)
				else
					v49 = 0
				end
				for v52, v53 in v43.motors do
					if not v53.Parent then
						continue
					end
					local v54 = v53.Transform
					if v48 and v48[v52] then
						local v55 = v48[v52]
						if v52 == "RightShoulder" and v49 ~= 0 then
							v55 = CFrame.Angles(v49, 0, 0) * v55
						end
						v54 = v54:Lerp(v55, v47)
					end
					if v43.kick > 0 and (v52 == "RightShoulder" or v52 == "RightElbow") then
						local v56 = CFrame.Angles
						local v57 = v43.kick * (v52 == "RightElbow" and 0.6 or 1)
						v54 = v56(math.rad(v57), 0, 0) * v54
					end
					v53.Transform = v54
				end
			end
		else
			v_u_6[v42] = nil
		end
	end
end
local v_u_59 = false
function v_u_4.Init() -- name: Init
	-- upvalues: (ref) v_u_59, (copy) v_u_3, (copy) v_u_58, (copy) v_u_39, (copy) v_u_2, (copy) v_u_1
	if not v_u_59 then
		v_u_59 = true
		v_u_3.PreSimulation:Connect(v_u_58)
		local function v61(p60) -- name: onPlayer
			-- upvalues: (ref) v_u_39
			p60.CharacterAdded:Connect(v_u_39)
			if p60.Character then
				v_u_39(p60.Character)
			end
		end
		for _, v62 in v_u_2:GetPlayers() do
			v62.CharacterAdded:Connect(v_u_39)
			if not v62.Character then
				continue
			end
			v_u_39(v62.Character)
		end
		v_u_2.PlayerAdded:Connect(v61)
		for _, v63 in { "Combatant", "Bot" } do
			v_u_1:GetInstanceAddedSignal(v63):Connect(function(p64)
				-- upvalues: (ref) v_u_39
				if p64:IsA("Model") then
					v_u_39(p64)
				end
			end)
			for _, v65 in v_u_1:GetTagged(v63) do
				if not v65:IsA("Model") then
					continue
				end
				v_u_39(v65)
			end
		end
	end
end
return v_u_4