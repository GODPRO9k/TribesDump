local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = require(v3:WaitForChild("Shared"):WaitForChild("MatchPrefs"))
local v5 = {}
local v_u_6 = Color3.fromRGB(142, 149, 166)
function v5.Init(p_u_7) -- name: Init
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_6, (copy) v_u_1
	local v_u_8 = p_u_7.UI
	local v9 = p_u_7.Theme
	local v_u_10 = p_u_7.State
	local v_u_11 = v9.Colors
	local v_u_12 = v9.Fonts
	local v_u_13 = UDim2.fromOffset
	local v_u_14 = require(script.Parent.Parent:WaitForChild("SettingsStore"))
	local v_u_15 = v_u_2.LocalPlayer
	local v_u_16 = false
	function p_u_7.PremiumTestOn() -- name: PremiumTestOn
		-- upvalues: (ref) v_u_16
		return v_u_16
	end
	function p_u_7.PremiumTestToggle() -- name: PremiumTestToggle
		-- upvalues: (ref) v_u_16, (copy) p_u_7
		local v17 = not v_u_16
		if p_u_7.QueueAction(v17 and "PremiumTestOn" or "PremiumTestOff") then
			v_u_16 = v17
		end
	end
	local v_u_18 = p_u_7.LobbyHud
	if v_u_18 and v_u_18.PlayButton then
		local v_u_19 = v_u_18.PlayButton.Instance
		local v20 = v_u_8.Compact == true
		local v21 = v_u_8.Touch == true
		local v_u_22 = v20 and 56 or 60
		local v_u_23 = v_u_8.IconButton({
			["Name"] = "MatchSettingsCog",
			["IconName"] = "gear",
			["Size"] = nil,
			["Parent"] = nil,
			["Size"] = v_u_13(v_u_22, v_u_22),
			["Parent"] = v_u_18.Root
		})
		v_u_8.Corner(14).Parent = v_u_23
		local function v35() -- name: placeCog
			-- upvalues: (copy) v_u_18, (copy) v_u_19, (copy) v_u_23, (copy) v_u_13, (copy) v_u_22, (copy) v_u_10
			local v24 = v_u_18.Root
			local v25 = 1
			while v24 and not v24:IsA("ScreenGui") do
				local v26 = v24:FindFirstChildOfClass("UIScale")
				if v26 then
					v25 = v25 * v26.Scale
				end
				v24 = v24.Parent
			end
			local v27 = v25 <= 0.01 and 1 or v25
			local v28 = v_u_18.Root.AbsolutePosition
			local v29 = v_u_19.AbsolutePosition
			local v30 = v_u_19.AbsoluteSize
			v_u_23.Position = v_u_13((v29.X - v28.X) / v27 - 10 - v_u_22, (v29.Y - v28.Y) / v27 + (v30.Y / v27 - v_u_22) / 2)
			local v31 = v_u_23
			local v32 = v_u_19.Visible
			if v32 then
				local v33 = v_u_10.Profile
				if v33 then
					v33 = v_u_10.Profile.stats
				end
				if type(v33) == "table" then
					local v34 = v33.matches
					if type(v34) == "number" then
						v32 = v33.matches >= 1
					else
						v32 = false
					end
				else
					v32 = false
				end
			end
			v31.Visible = v32
		end
		for _, v36 in { "AbsolutePosition", "AbsoluteSize", "Visible" } do
			v_u_19:GetPropertyChangedSignal(v36):Connect(v35)
		end
		v_u_18.Root:GetPropertyChangedSignal("AbsoluteSize"):Connect(v35)
		v_u_10.ProfileChanged:Connect(v35)
		v35()
		local v_u_37 = v20 and 640 or 600
		local v_u_38 = v21 and 76 or 68
		local v39 = v21 and 56 or 46
		local v40 = #v_u_4.REGIONS / 2
		local v_u_41 = math.ceil(v40) * (v39 + 8) + 30 - 8
		local v_u_42 = 106
		local v_u_43 = v_u_42 + 18 + 10 + v_u_38 + 10 + v_u_38 + 18 + 16
		local v_u_44 = v_u_43 + 6 + v_u_41
		local v_u_45 = v_u_8.Window({
			["Name"] = "MatchSettings",
			["Title"] = "MATCHMAKING",
			["Subtitle"] = "How we find your matches",
			["Size"] = nil,
			["HeaderHeight"] = 80,
			["Parent"] = nil,
			["OnCloseRequested"] = nil,
			["Size"] = v_u_13(v_u_37, v_u_44 + 80),
			["Parent"] = p_u_7.Canvas.Menus,
			["OnCloseRequested"] = function() -- name: OnCloseRequested
				-- upvalues: (copy) p_u_7
				p_u_7.MenuManager.Close("MatchSettings")
			end
		})
		local v_u_46 = v_u_45.Content
		v_u_8.SelectionRing(v_u_45.Root)
		local function v63(p47, p48, p49, p50, p_u_51, p_u_52, p53) -- name: switchRow
			-- upvalues: (copy) v_u_38, (copy) v_u_8, (copy) v_u_13, (copy) v_u_11, (copy) v_u_46, (copy) v_u_12, (ref) v_u_6, (copy) p_u_7
			local v54 = p53 or v_u_38
			local v55 = v_u_38 < v54
			local v56 = v_u_8.new("TextButton", {
				["Name"] = p47,
				["Position"] = v_u_13(18, p48),
				["Size"] = UDim2.new(1, -36, 0, v54),
				["BackgroundColor3"] = v_u_11.PanelHi,
				["BackgroundTransparency"] = 0.3,
				["Text"] = "",
				["AutoButtonColor"] = false,
				v_u_8.Corner(12),
				v_u_8.Stroke(v_u_11.Stroke, 1, 0.92),
				["Parent"] = v_u_46
			})
			v_u_8.new("TextLabel", {
				["Name"] = "Title",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 18,
				["TextXAlignment"] = nil,
				["Parent"] = nil,
				["Position"] = v_u_13(16, v55 and 14 or v_u_38 / 2 - 24),
				["Size"] = UDim2.new(1, -110, 0, 24),
				["Text"] = p49,
				["FontFace"] = v_u_12.Heavy,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Parent"] = v56
			})
			local v57 = v_u_8.new
			local v58 = "TextLabel"
			local v59 = {
				["Name"] = "Desc",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 14,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextYAlignment"] = nil,
				["TextWrapped"] = nil,
				["TextTruncate"] = nil,
				["Parent"] = nil,
				["Position"] = v_u_13(16, v55 and 42 or v_u_38 / 2 + 2),
				["Size"] = UDim2.new(1, -110, 0, not v55 and 20 or v54 - 42 - 12),
				["Text"] = p50,
				["FontFace"] = v_u_12.Bold,
				["TextColor3"] = v_u_6,
				["TextXAlignment"] = Enum.TextXAlignment.Left
			}
			local v60
			if v55 then
				v60 = Enum.TextYAlignment.Top
			else
				v60 = Enum.TextYAlignment.Center
			end
			v59.TextYAlignment = v60
			v59.TextWrapped = v55
			local v61
			if v55 then
				v61 = Enum.TextTruncate.None
			else
				v61 = Enum.TextTruncate.AtEnd
			end
			v59.TextTruncate = v61
			v59.Parent = v56
			v57(v58, v59)
			local v_u_62 = v_u_8.Switch({
				["Width"] = 60,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(1, 0.5),
				["Position"] = UDim2.new(1, -16, 0.5, 0),
				["Parent"] = v56
			})
			v56.Activated:Connect(function()
				-- upvalues: (ref) p_u_7, (copy) p_u_52, (copy) p_u_51, (copy) v_u_62
				p_u_7.Sounds.Play("Click")
				p_u_52(not p_u_51())
				v_u_62:Set(p_u_51(), nil)
			end)
			v_u_62:Set(p_u_51(), true)
			return function()
				-- upvalues: (copy) v_u_62, (copy) p_u_51
				v_u_62:Set(p_u_51(), true)
			end, v56
		end
		local v_u_64 = nil
		local v_u_65 = nil
		local v_u_67, v_u_68 = v63("NoBots", v_u_42 + 18 + 10, "PREVENT FULL BOT MATCHES", "Keep searching until another player joins. Can take longer.", function()
			-- upvalues: (copy) v_u_14
			return v_u_14.Get("mmNoBots") > 0.5
		end, function(p66)
			-- upvalues: (copy) v_u_14
			v_u_14.Set("mmNoBots", p66 and 1 or 0, true)
		end)
		local v_u_71, v_u_72 = v63("Premium", 18, "PREMIUM ONLY QUEUE", "Only match with players who bought something in Tribes. This helps prevent cheaters from showing in your games at the cost of slower queue times.", function()
			-- upvalues: (copy) v_u_15, (ref) v_u_4, (copy) v_u_14
			local v69 = v_u_15:GetAttribute(v_u_4.PREMIUM_ATTR) == true
			if v69 then
				v69 = v_u_14.Get("mmPremium") > 0.5
			end
			return v69
		end, function(p70)
			-- upvalues: (copy) v_u_15, (ref) v_u_4, (copy) p_u_7, (copy) v_u_14
			if v_u_15:GetAttribute(v_u_4.PREMIUM_ATTR) == true then
				v_u_14.Set("mmPremium", p70 and 1 or 0, true)
			else
				p_u_7.Toast("Unlocks with any Robux purchase in Tribes (accounts 7+ days old).", "info")
			end
		end, v_u_42)
		local v_u_73 = v_u_8.new("ImageLabel", {
			["Name"] = "Robux",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundTransparency"] = 1,
			["Image"] = "rbxasset://textures/ui/common/robux@3x.png",
			["ImageColor3"] = nil,
			["ScaleType"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = v_u_13(16, 26),
			["Size"] = v_u_13(24, 24),
			["ImageColor3"] = v_u_11.Gold,
			["ScaleType"] = Enum.ScaleType.Fit,
			["Parent"] = v_u_72
		})
		local v74 = v_u_72:FindFirstChild("Title")
		if v74 then
			v74.Position = v_u_13(48, v74.Position.Y.Offset)
			v74.Size = UDim2.new(1, -142, 0, v74.Size.Y.Offset)
		end
		local v_u_75 = nil
		local function v_u_81() -- name: paintPremiumLock
			-- upvalues: (copy) v_u_15, (ref) v_u_4, (copy) v_u_73, (copy) v_u_11, (copy) v_u_72, (copy) v_u_71, (ref) v_u_75
			local v76 = v_u_15:GetAttribute(v_u_4.PREMIUM_ATTR) == true
			local v77 = v_u_73
			local v78
			if v76 then
				v78 = v_u_11.Gold
			else
				v78 = Color3.fromRGB(140, 140, 140)
			end
			v77.ImageColor3 = v78
			v_u_73.ImageTransparency = v76 and 0 or 0.35
			local v79 = v_u_72:FindFirstChild("Desc")
			local v80 = v_u_72:FindFirstChild("Title")
			if v79 then
				v79.Text = v76 and "Only match with players who bought something in Tribes. This helps prevent cheaters from showing in your games at the cost of slower queue times." or "Unlocks with any Robux purchase in Tribes (accounts 7+ days old). This helps prevent cheaters from showing in your games at the cost of slower queue times."
			end
			if v80 then
				v80.TextTransparency = v76 and 0 or 0.45
			end
			v_u_72.BackgroundTransparency = v76 and 0.3 or 0.55
			v_u_71()
			if v_u_75 then
				task.defer(v_u_75)
			end
		end
		v_u_15:GetAttributeChangedSignal(v_u_4.PREMIUM_ATTR):Connect(v_u_81)
		v_u_81()
		local v_u_88, v_u_89 = v63("ManualRegion", v_u_42 + 18 + 10 + v_u_38 + 10, "MANUAL REGION SELECTION", "Pick more regions to search in. Off: only your own, for the best ping.", function()
			-- upvalues: (copy) v_u_14
			return v_u_14.Get("mmAutoRegion") < 0.5
		end, function(p82)
			-- upvalues: (copy) v_u_14, (ref) v_u_65, (ref) v_u_64, (copy) v_u_45, (copy) v_u_13, (copy) v_u_37, (ref) v_u_44, (ref) v_u_43
			v_u_14.Set("mmAutoRegion", p82 and 0 or 1, true)
			v_u_65()
			local v83 = v_u_14.Get("mmAutoRegion") < 0.5
			v_u_64.Visible = v83
			local v84 = v_u_45.Holder
			local v85 = v_u_13
			local v86 = v_u_37
			local v87
			if v83 then
				v87 = v_u_44
			else
				v87 = v_u_43
			end
			v84.Size = v85(v86, v87 + 80)
			if v_u_45.Refit then
				v_u_45.Refit()
			end
		end)
		v_u_64 = v_u_8.new("Frame", {
			["Name"] = "Regions",
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Position"] = v_u_13(18, v_u_43 - 18 - 16 + 6),
			["Size"] = UDim2.new(1, -36, 0, v_u_41),
			["Parent"] = v_u_46
		})
		v_u_8.new("TextLabel", {
			["Name"] = "Hint",
			["Size"] = nil,
			["Text"] = "Also search in these regions. Yours is always included. Other regions mean higher ping.",
			["FontFace"] = nil,
			["TextSize"] = 14,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 22),
			["FontFace"] = v_u_12.Bold,
			["TextColor3"] = v_u_6,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v_u_64
		})
		local v_u_90 = v_u_44
		local v_u_91 = v_u_43
		local v_u_92 = v_u_64
		local v_u_93 = {}
		for v_u_94, v95 in v_u_4.REGIONS do
			local v96 = (v_u_94 - 1) % 2
			local v97 = (v_u_94 - 1) / 2
			local v98 = math.floor(v97)
			local v99 = v_u_8.new("TextButton", {
				["Name"] = v95.id,
				["Position"] = UDim2.new(v96 * 0.5, v96 == 1 and 5 or 0, 0, v98 * (v39 + 8) + 30),
				["Size"] = UDim2.new(0.5, -5, 0, v39),
				["BackgroundColor3"] = v_u_11.PanelHi,
				["BackgroundTransparency"] = 0.3,
				["Text"] = "",
				["AutoButtonColor"] = false,
				v_u_8.Corner(10),
				v_u_8.Stroke(v_u_11.Stroke, 1, 0.92),
				["Parent"] = v_u_92
			})
			local v100 = v_u_8.new("Frame", {
				["Name"] = "Box",
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 12, 0.5, 0),
				["Size"] = v_u_13(24, 24),
				["BackgroundColor3"] = v_u_11.Void,
				["BackgroundTransparency"] = 0.2,
				v_u_8.Corner(6),
				v_u_8.Stroke(v_u_11.Stroke, 1.5, 0.6),
				["Parent"] = v99
			})
			local v101 = v_u_8.Icon("check", 16, v_u_11.Text, {
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Parent"] = v100
			})
			v_u_8.new("TextLabel", {
				["Name"] = "Name",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 16,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Parent"] = nil,
				["Position"] = v_u_13(48, 0),
				["Size"] = UDim2.new(1, -56, 1, 0),
				["Text"] = v95.name,
				["FontFace"] = v_u_12.Heavy,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v99
			})
			v_u_93[v_u_94] = {
				["box"] = v100,
				["check"] = v101
			}
			v99.Activated:Connect(function()
				-- upvalues: (copy) p_u_7, (copy) v_u_14, (ref) v_u_4, (copy) v_u_94, (ref) v_u_65
				p_u_7.Sounds.Play("Click")
				local v102 = v_u_14.Get("mmRegions")
				local v103 = math.floor(v102)
				v_u_14.Set("mmRegions", v_u_4.With(v103, v_u_94, not v_u_4.Has(v103, v_u_94)), true)
				v_u_65()
			end)
		end
		local function v_u_111()
			-- upvalues: (copy) v_u_14, (copy) v_u_93, (ref) v_u_4, (copy) v_u_11
			local v104 = v_u_14.Get("mmRegions")
			local v105 = math.floor(v104)
			for v106, v107 in v_u_93 do
				local v108 = v_u_4.Has(v105, v106)
				v107.check.Visible = v108
				local v109 = v107.box
				local v110
				if v108 then
					v110 = v_u_11.Accent
				else
					v110 = v_u_11.Void
				end
				v109.BackgroundColor3 = v110
				v107.box.BackgroundTransparency = v108 and 0 or 0.2
			end
		end
		local v_u_112 = false
		v_u_75 = function()
			-- upvalues: (copy) v_u_72, (ref) v_u_112, (copy) v_u_38, (ref) v_u_42, (copy) v_u_68, (copy) v_u_13, (copy) v_u_89, (ref) v_u_91, (ref) v_u_90, (copy) v_u_41, (ref) v_u_92, (copy) v_u_14, (copy) v_u_45, (copy) v_u_37
			local v_u_113 = v_u_72:FindFirstChild("Desc")
			if v_u_112 or (not v_u_113 or (v_u_113.AbsoluteSize.X <= 0 or v_u_113.Size.Y.Offset <= 0)) then
				return
			else
				local v114 = v_u_113.AbsoluteSize.Y / v_u_113.Size.Y.Offset
				local v_u_115 = v_u_113.AbsoluteSize.X / math.max(v114, 0.01)
				v_u_112 = true
				local v116 = 0
				for _, v_u_117 in { "Only match with players who bought something in Tribes. This helps prevent cheaters from showing in your games at the cost of slower queue times.", "Unlocks with any Robux purchase in Tribes (accounts 7+ days old). This helps prevent cheaters from showing in your games at the cost of slower queue times." } do
					local v119, v120 = pcall(function()
						-- upvalues: (copy) v_u_117, (copy) v_u_113, (copy) v_u_115
						local v118 = Instance.new("GetTextBoundsParams")
						v118.Text = v_u_117
						v118.Font = v_u_113.FontFace
						v118.Size = v_u_113.TextSize
						v118.Width = v_u_115
						return game:GetService("TextService"):GetTextBoundsAsync(v118)
					end)
					if not v119 or typeof(v120) ~= "Vector2" then
						continue
					end
					local v121 = v120.Y
					v116 = math.max(v116, v121)
				end
				v_u_112 = false
				if v116 <= 0 then
					return
				else
					local v122 = v_u_38
					local v123 = v116 + 42 + 14
					local v124 = math.ceil(v123)
					local v125 = math.max(v122, v124)
					local v126 = v125 - v_u_42
					if math.abs(v126) >= 1 then
						v_u_42 = v125
						v_u_72.Size = UDim2.new(1, -36, 0, v125)
						v_u_113.Size = UDim2.new(1, -110, 0, v125 - 42 - 12)
						v_u_68.Position = v_u_13(18, v125 + 18 + 10)
						v_u_89.Position = v_u_13(18, v125 + 18 + 10 + v_u_38 + 10)
						v_u_91 = v125 + 18 + 10 + v_u_38 + 10 + v_u_38 + 18 + 16
						v_u_90 = v_u_91 + 6 + v_u_41
						v_u_92.Position = v_u_13(18, v_u_91 - 18 - 16 + 6)
						local v127 = v_u_14.Get("mmAutoRegion") < 0.5
						v_u_92.Visible = v127
						local v128 = v_u_45.Holder
						local v129 = v_u_13
						local v130 = v_u_37
						local v131
						if v127 then
							v131 = v_u_90
						else
							v131 = v_u_91
						end
						v128.Size = v129(v130, v131 + 80)
						if v_u_45.Refit then
							v_u_45.Refit()
						end
					end
				end
			end
		end
		v_u_14.Changed:Connect(function(p132)
			-- upvalues: (copy) p_u_7, (copy) v_u_67, (copy) v_u_81, (copy) v_u_88, (ref) v_u_111, (copy) v_u_14, (ref) v_u_92, (copy) v_u_45, (copy) v_u_13, (copy) v_u_37, (ref) v_u_90, (ref) v_u_91, (ref) v_u_75
			if string.sub(p132, 1, 2) == "mm" and p_u_7.MenuManager.IsOpen("MatchSettings") then
				v_u_67()
				v_u_81()
				v_u_88()
				v_u_111()
				local v133 = v_u_14.Get("mmAutoRegion") < 0.5
				v_u_92.Visible = v133
				local v134 = v_u_45.Holder
				local v135 = v_u_13
				local v136 = v_u_37
				local v137
				if v133 then
					v137 = v_u_90
				else
					v137 = v_u_91
				end
				v134.Size = v135(v136, v137 + 80)
				if v_u_45.Refit then
					v_u_45.Refit()
				end
				task.defer(v_u_75)
			end
		end)
		local v145 = {
			["open"] = function() -- name: open
				-- upvalues: (copy) v_u_67, (copy) v_u_81, (copy) v_u_88, (ref) v_u_111, (copy) v_u_14, (ref) v_u_92, (copy) v_u_45, (copy) v_u_13, (copy) v_u_37, (ref) v_u_90, (ref) v_u_91, (ref) v_u_75, (copy) v_u_8, (ref) v_u_1, (copy) v_u_46
				v_u_67()
				v_u_81()
				v_u_88()
				v_u_111()
				local v138 = v_u_14.Get("mmAutoRegion") < 0.5
				v_u_92.Visible = v138
				local v139 = v_u_45.Holder
				local v140 = v_u_13
				local v141 = v_u_37
				local v142
				if v138 then
					v142 = v_u_90
				else
					v142 = v_u_91
				end
				v139.Size = v140(v141, v142 + 80)
				if v_u_45.Refit then
					v_u_45.Refit()
				end
				task.defer(v_u_75)
				v_u_45:Open()
				if v_u_8.Gamepad then
					v_u_1.SelectedObject = v_u_46:FindFirstChild("Premium")
				end
			end,
			["close"] = function(p143) -- name: close
				-- upvalues: (ref) v_u_1, (copy) v_u_45
				local v144 = v_u_1.SelectedObject
				if v144 and v144:IsDescendantOf(v_u_45.Root) then
					v_u_1.SelectedObject = nil
				end
				v_u_45:Close(p143)
			end
		}
		p_u_7.MenuManager.Register("MatchSettings", v145)
		v_u_23.Activated:Connect(function()
			-- upvalues: (copy) p_u_7
			p_u_7.Sounds.Play("Click")
			p_u_7.MenuManager.Open("MatchSettings")
		end)
		v_u_10.PlayerStateChanged:Connect(function()
			-- upvalues: (copy) v_u_10, (copy) p_u_7
			if v_u_10.InMatch() and p_u_7.MenuManager.IsOpen("MatchSettings") then
				p_u_7.MenuManager.Close("MatchSettings", true)
			end
		end)
	end
end
return v5