game:GetService("GuiService")
local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = {}
local v_u_5 = v1.LocalPlayer
local v_u_6 = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.ExtraBold)
local v_u_7 = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Heavy)
local v_u_8 = Color3.fromRGB(250, 248, 242)
local v_u_9 = Color3.fromRGB(255, 208, 60)
local v_u_10 = Color3.fromRGB(255, 62, 62)
local v_u_11 = Color3.fromRGB(96, 186, 255)
local v_u_12 = Color3.fromRGB(16, 12, 10)
local v_u_13 = Color3.fromRGB(120, 110, 100)
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = {}
local v_u_17 = "Dot"
local v_u_18 = 1
local v_u_19 = 0
local v_u_20 = 0
local v_u_21 = 0
local v_u_22 = false
local v_u_23 = false
local v_u_24 = 0
local v_u_25 = 0
local v_u_26 = v_u_8
local function v_u_33(p27, p28, p29, p30, p31) -- name: frame
	-- upvalues: (copy) v_u_8
	local v32 = Instance.new("Frame")
	v32.Name = p28
	v32.Size = p29
	v32.Position = p30 or UDim2.fromScale(0.5, 0.5)
	v32.AnchorPoint = Vector2.new(0.5, 0.5)
	v32.BackgroundColor3 = p31 or v_u_8
	v32.BorderSizePixel = 0
	v32.Parent = p27
	return v32
end
local function v_u_45(p34, p35, p36, p37, p38) -- name: ring
	-- upvalues: (copy) v_u_33, (copy) v_u_8, (copy) v_u_12
	local v39 = v_u_33(p34, p35, UDim2.fromOffset(p36, p36))
	v39.BackgroundTransparency = 1
	local v40 = Instance.new("UICorner")
	v40.CornerRadius = UDim.new(1, 0)
	v40.Parent = v39
	local v41 = Instance.new("UIStroke")
	v41.Name = "Stroke"
	v41.Thickness = p37
	v41.Color = v_u_8
	v41.Transparency = p38 or 0
	v41.Parent = v39
	local v42 = v_u_33(v39, "Rim", UDim2.new(1, p37 + 2, 1, p37 + 2))
	v42.BackgroundTransparency = 1
	local v43 = Instance.new("UICorner")
	v43.CornerRadius = UDim.new(1, 0)
	v43.Parent = v42
	local v44 = Instance.new("UIStroke")
	v44.Name = "Stroke"
	v44.Thickness = 1
	v44.Color = v_u_12
	v44.Transparency = 0.6
	v44.Parent = v42
	return v39
end
local function v_u_54(p46, p47, p48, p49, p50, p51) -- name: label
	-- upvalues: (copy) v_u_6, (copy) v_u_8, (copy) v_u_12
	local v52 = Instance.new("TextLabel")
	v52.Name = p47
	v52.BackgroundTransparency = 1
	v52.AnchorPoint = Vector2.new(0.5, 0.5)
	v52.Position = p50
	v52.Size = UDim2.fromOffset(460, p49 + 8)
	v52.FontFace = v_u_6
	v52.TextSize = p49
	v52.TextColor3 = p51 or v_u_8
	v52.Text = p48
	v52.Parent = p46
	local v53 = Instance.new("UIStroke")
	v53.Thickness = 2
	v53.Color = v_u_12
	v53.Transparency = 0.2
	v53.Parent = v52
	return v52
end
local v_u_55 = {}
local v_u_56 = nil
local v_u_57 = {}
local function v_u_125() -- name: buildStyles
	-- upvalues: (copy) v_u_33, (ref) v_u_15, (copy) v_u_12, (copy) v_u_45, (copy) v_u_11, (copy) v_u_16, (copy) v_u_8, (copy) v_u_55, (ref) v_u_56
	local v58 = v_u_33(v_u_15, "Melee", UDim2.fromOffset(0, 0))
	v58.BackgroundTransparency = 1
	local v59 = v_u_33(v58, "Dot", UDim2.fromOffset(5, 5))
	local v60 = Instance.new("UICorner")
	v60.CornerRadius = UDim.new(1, 0)
	v60.Parent = v59
	local v61 = v_u_12
	local v62 = Instance.new("UIStroke")
	v62.Name = "Stroke"
	v62.Thickness = 1.2
	v62.Color = v61 or v_u_12
	v62.Transparency = 0.25
	v62.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v62.Parent = v59
	v_u_45(v58, "Ring", 24, 1.6, 0.45)
	local v63 = v_u_33(v58, "Shield", UDim2.fromOffset(30, 36))
	v63.BackgroundTransparency = 1
	v63.Visible = false
	for _, v64 in {
		{ "Top", UDim2.fromOffset(28, 20), UDim2.fromScale(0.5, 0.3) },
		{ "Point", UDim2.fromOffset(20, 20), UDim2.fromScale(0.5, 0.58) }
	} do
		local v65 = v_u_33(v63, v64[1], v64[2], v64[3], v_u_11)
		v65.BackgroundTransparency = 0.3
		if v64[1] == "Point" then
			v65.Rotation = 45
		end
		local v66 = Instance.new("UICorner")
		v66.CornerRadius = UDim.new(0, v64[1] == "Top" and 5 or 3)
		v66.Parent = v65
	end
	local v67 = Instance.new("UIScale")
	v67.Name = "Pulse"
	v67.Parent = v63
	v_u_16.Melee = v58
	local v68 = v_u_33(v_u_15, "Bow", UDim2.fromOffset(0, 0))
	v68.BackgroundTransparency = 1
	local v69 = v_u_33(v68, "Dot", UDim2.fromOffset(4, 4))
	local v70 = Instance.new("UICorner")
	v70.CornerRadius = UDim.new(1, 0)
	v70.Parent = v69
	local v71 = v_u_12
	local v72 = Instance.new("UIStroke")
	v72.Name = "Stroke"
	v72.Thickness = 1.2
	v72.Color = v71 or v_u_12
	v72.Transparency = 0.25
	v72.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v72.Parent = v69
	v_u_45(v68, "Ring", 66, 2.2, 0.1)
	for v73, v74 in { -1, 1 } do
		local v75 = v_u_33(v68, "Side" .. v73, UDim2.fromOffset(9, 2.5))
		local v76 = v_u_12
		local v77 = Instance.new("UIStroke")
		v77.Name = "Stroke"
		v77.Thickness = 1
		v77.Color = v76 or v_u_12
		v77.Transparency = 0.3
		v77.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v77.Parent = v75
		v75.Position = UDim2.new(0.5, v74 * 44, 0.5, 0)
	end
	v_u_16.Bow = v68
	local v78 = v_u_33(v_u_15, "Gun", UDim2.fromOffset(0, 0))
	v78.BackgroundTransparency = 1
	local v79 = v_u_33(v78, "Dot", UDim2.fromOffset(3.5, 3.5))
	local v80 = Instance.new("UICorner")
	v80.CornerRadius = UDim.new(1, 0)
	v80.Parent = v79
	local v81 = v_u_12
	local v82 = Instance.new("UIStroke")
	v82.Name = "Stroke"
	v82.Thickness = 1.2
	v82.Color = v81 or v_u_12
	v82.Transparency = 0.25
	v82.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v82.Parent = v79
	for _, v83 in {
		"Up",
		"Down",
		"Left",
		"Right"
	} do
		local v84 = v83 == "Up" and true or v83 == "Down"
		local v85 = v_u_33(v78, v83, UDim2.fromOffset(v84 and 2.5 or 10, v84 and 10 or 2.5))
		local v86 = v_u_12
		local v87 = Instance.new("UIStroke")
		v87.Name = "Stroke"
		v87.Thickness = 1
		v87.Color = v86 or v_u_12
		v87.Transparency = 0.3
		v87.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v87.Parent = v85
	end
	v_u_16.Gun = v78
	local v88 = v_u_33(v_u_15, "Spread", UDim2.fromOffset(0, 0))
	v88.BackgroundTransparency = 1
	local v89 = v_u_33(v88, "Dot", UDim2.fromOffset(4, 4))
	local v90 = Instance.new("UICorner")
	v90.CornerRadius = UDim.new(1, 0)
	v90.Parent = v89
	local v91 = v_u_12
	local v92 = Instance.new("UIStroke")
	v92.Name = "Stroke"
	v92.Thickness = 1.2
	v92.Color = v91 or v_u_12
	v92.Transparency = 0.25
	v92.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v92.Parent = v89
	v_u_45(v88, "Ring", 80, 2, 0.15)
	for v93 = 0, 3 do
		local v94 = v93 * 90
		local v95 = math.rad(v94)
		local v96 = "Notch" .. v93
		local v97 = v93 % 2 == 0 and 2.5 or 8
		local v98 = v93 % 2 == 0 and 8 or 2.5
		local v99 = v_u_33(v88, v96, UDim2.fromOffset(v97, v98))
		local v100 = v_u_12
		local v101 = Instance.new("UIStroke")
		v101.Name = "Stroke"
		v101.Thickness = 1
		v101.Color = v100 or v_u_12
		v101.Transparency = 0.3
		v101.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v101.Parent = v99
		v99.Position = UDim2.new(0.5, math.sin(v95) * 40, 0.5, -math.cos(v95) * 40)
	end
	v_u_16.Spread = v88
	local v102 = v_u_33(v_u_15, "Throw", UDim2.fromOffset(0, 0))
	v102.BackgroundTransparency = 1
	local v103 = v_u_33(v102, "Dot", UDim2.fromOffset(5, 5))
	local v104 = Instance.new("UICorner")
	v104.CornerRadius = UDim.new(1, 0)
	v104.Parent = v103
	local v105 = v_u_12
	local v106 = Instance.new("UIStroke")
	v106.Name = "Stroke"
	v106.Thickness = 1.2
	v106.Color = v105 or v_u_12
	v106.Transparency = 0.25
	v106.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v106.Parent = v103
	v_u_45(v102, "Ring", 44, 2, 0.25)
	v_u_16.Throw = v102
	local v107 = v_u_33(v_u_15, "Use", UDim2.fromOffset(0, 0))
	v107.BackgroundTransparency = 1
	local v108 = v_u_33(v107, "Dot", UDim2.fromOffset(5, 5))
	local v109 = Instance.new("UICorner")
	v109.CornerRadius = UDim.new(1, 0)
	v109.Parent = v108
	local v110 = v_u_12
	local v111 = Instance.new("UIStroke")
	v111.Name = "Stroke"
	v111.Thickness = 1.2
	v111.Color = v110 or v_u_12
	v111.Transparency = 0.25
	v111.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v111.Parent = v108
	v_u_45(v107, "Ring", 18, 1.4, 0.55)
	v_u_16.Use = v107
	local v112 = v_u_33(v_u_15, "Dot", UDim2.fromOffset(0, 0))
	v112.BackgroundTransparency = 1
	local v113 = v_u_33(v112, "Dot", UDim2.fromOffset(4, 4))
	local v114 = Instance.new("UICorner")
	v114.CornerRadius = UDim.new(1, 0)
	v114.Parent = v113
	local v115 = v_u_12
	local v116 = Instance.new("UIStroke")
	v116.Name = "Stroke"
	v116.Thickness = 1.2
	v116.Color = v115 or v_u_12
	v116.Transparency = 0.25
	v116.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v116.Parent = v113
	v_u_16.Dot = v112
	for _, v117 in v_u_16 do
		v117.Visible = false
		local v118 = Instance.new("UIScale")
		v118.Name = "Punch"
		v118.Parent = v117
	end
	v_u_16.Dot.Visible = true
	local v119 = v_u_33(v_u_15, "Arc", UDim2.fromOffset(0, 0))
	v119.BackgroundTransparency = 1
	for v120 = 1, 24 do
		local v121 = (v120 - 1) / 24 * 3.141592653589793 * 2
		local v122 = v_u_33(v119, "D" .. v120, UDim2.fromOffset(4, 4), UDim2.new(0.5, math.sin(v121) * 30, 0.5, -math.cos(v121) * 30), v_u_8)
		local v123 = Instance.new("UICorner")
		v123.CornerRadius = UDim.new(1, 0)
		v123.Parent = v122
		v122.Visible = false
		v_u_55[v120] = v122
	end
	v_u_56 = v_u_33(v_u_15, "Pips", UDim2.fromOffset(120, 10), UDim2.new(0.5, 0, 0.5, 44))
	v_u_56.BackgroundTransparency = 1
	local v124 = Instance.new("UIListLayout")
	v124.FillDirection = Enum.FillDirection.Horizontal
	v124.HorizontalAlignment = Enum.HorizontalAlignment.Center
	v124.VerticalAlignment = Enum.VerticalAlignment.Center
	v124.Padding = UDim.new(0, 6)
	v124.SortOrder = Enum.SortOrder.LayoutOrder
	v124.Parent = v_u_56
	v_u_56.Visible = false
end
local v_u_126 = {}
local v_u_127 = 0
local v_u_128 = {
	Vector2.new(-1, -1),
	Vector2.new(1, -1),
	Vector2.new(1, 1),
	Vector2.new(-1, 1)
}
local function v_u_134() -- name: buildHitmarker
	-- upvalues: (copy) v_u_33, (ref) v_u_15, (copy) v_u_12, (copy) v_u_126
	local v129 = v_u_33(v_u_15, "Hitmarker", UDim2.fromOffset(0, 0))
	v129.BackgroundTransparency = 1
	v129.ZIndex = 5
	for v130 = 1, 4 do
		local v131 = v_u_33(v129, "L" .. v130, UDim2.fromOffset(10, 3))
		v131.BackgroundTransparency = 1
		v131.Rotation = v130 % 2 == 1 and 45 or -45
		v131.ZIndex = 5
		local v132 = v_u_12
		local v133 = Instance.new("UIStroke")
		v133.Name = "Stroke"
		v133.Thickness = 1.2
		v133.Color = v132 or v_u_12
		v133.Transparency = 1
		v133.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v133.Parent = v131
		v133.Name = "Stroke"
		v_u_126[v130] = v131
	end
end
local function v_u_137(p135) -- name: punch
	-- upvalues: (copy) v_u_16, (ref) v_u_17, (copy) v_u_3
	local v136 = v_u_16[v_u_17]
	if v136 then
		v136 = v136:FindFirstChild("Punch")
	end
	if v136 then
		v136.Scale = p135
		v_u_3:Create(v136, TweenInfo.new(0.18, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			["Scale"] = 1
		}):Play()
	end
end
function v_u_4.Hitmarker(p138) -- name: Hitmarker
	-- upvalues: (ref) v_u_127, (copy) v_u_10, (copy) v_u_9, (copy) v_u_8, (copy) v_u_126, (copy) v_u_128, (copy) v_u_3, (copy) v_u_137
	v_u_127 = os.clock()
	local v139
	if p138 == "kill" then
		v139 = v_u_10
	elseif p138 == "crit" then
		v139 = v_u_9
	else
		v139 = v_u_8
	end
	local v140 = p138 == "kill" and true or p138 == "crit"
	local v141 = p138 == "kill" and 18 or (p138 == "crit" and 14 or 11)
	local v142 = p138 == "kill" and 4 or (p138 == "crit" and 3.4 or 2.8)
	local v143 = p138 == "kill" and 8 or 6
	local v144 = p138 == "kill" and 20 or (v140 and 15 or 12)
	local v145 = p138 == "predict" and 0.25 or 0
	for v146, v147 in v_u_126 do
		local v148 = v_u_128[v146]
		v147.Size = UDim2.fromOffset(v141 * 1.4, v142)
		v147.BackgroundColor3 = v139
		v147.BackgroundTransparency = v145
		v147.Position = UDim2.new(0.5, v148.X * v143, 0.5, v148.Y * v143)
		local v149 = v147:FindFirstChild("Stroke")
		v149.Transparency = v145 + 0.25
		local v150 = TweenInfo.new(p138 == "kill" and 0.55 or 0.34, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		v_u_3:Create(v147, v150, {
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundTransparency"] = 1,
			["Position"] = UDim2.new(0.5, v148.X * v144, 0.5, v148.Y * v144),
			["Size"] = UDim2.fromOffset(v141, v142)
		}):Play()
		v_u_3:Create(v149, v150, {
			["Transparency"] = 1
		}):Play()
	end
	v_u_137(p138 == "kill" and 1.6 or (v140 and 1.35 or 1.2))
end
function v_u_4.UpgradeHitmarker(p151) -- name: UpgradeHitmarker
	-- upvalues: (ref) v_u_127, (copy) v_u_4, (copy) v_u_10, (copy) v_u_9, (copy) v_u_8, (copy) v_u_126, (copy) v_u_3
	if p151 == "kill" or (p151 == "crit" or os.clock() - v_u_127 > 0.3) then
		v_u_4.Hitmarker(p151)
	else
		local v152
		if p151 == "kill" then
			v152 = v_u_10
		elseif p151 == "crit" then
			v152 = v_u_9
		else
			v152 = v_u_8
		end
		local v153 = 0.34 - (os.clock() - v_u_127)
		local v154 = math.max(0.12, v153)
		local v155 = TweenInfo.new(v154, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		for _, v156 in v_u_126 do
			v156.BackgroundColor3 = v152
			v156.BackgroundTransparency = 0
			local v157 = v156:FindFirstChild("Stroke")
			v157.Transparency = 0.25
			v_u_3:Create(v156, v155, {
				["BackgroundTransparency"] = 1
			}):Play()
			v_u_3:Create(v157, v155, {
				["Transparency"] = 1
			}):Play()
		end
	end
end
local v_u_158 = {}
local v_u_159 = {}
local v_u_160 = nil
local v_u_161 = {
	["crit"] = v_u_9,
	["kill"] = v_u_10,
	["dot"] = Color3.fromRGB(255, 150, 60),
	["health"] = v_u_8,
	["blocked"] = Color3.fromRGB(150, 200, 255),
	["armor"] = Color3.fromRGB(170, 190, 215)
}
local v_u_162 = {
	["crit"] = 56,
	["kill"] = 62,
	["dot"] = 26,
	["health"] = 42,
	["blocked"] = 34,
	["armor"] = 38
}
local function v_u_166(p_u_163) -- name: popNumber
	-- upvalues: (ref) v_u_18, (copy) v_u_3
	local v164 = (p_u_163.big and 1.7 or 1.5) * v_u_18
	p_u_163.scale.Scale = v_u_18 * 0.3
	v_u_3:Create(p_u_163.scale, TweenInfo.new(0.12, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
		["Scale"] = v164
	}):Play()
	task.delay(0.12, function()
		-- upvalues: (copy) p_u_163, (ref) v_u_3, (ref) v_u_18
		if p_u_163.label.Parent then
			local v165 = {
				["Scale"] = v_u_18
			}
			v_u_3:Create(p_u_163.scale, TweenInfo.new(0.14, Enum.EasingStyle.Quad), v165):Play()
		end
	end)
end
local function v_u_172(p167, p168, p169) -- name: tagLabel
	-- upvalues: (copy) v_u_6, (copy) v_u_12
	local v170 = Instance.new("TextLabel")
	v170.Name = "Tag"
	v170.BackgroundTransparency = 1
	v170.AnchorPoint = Vector2.new(0.5, 0)
	v170.Position = UDim2.new(0.5, 0, 1, -10)
	v170.Size = UDim2.fromOffset(160, 18)
	v170.FontFace = v_u_6
	v170.TextSize = 16
	v170.TextColor3 = p169
	v170.Text = p168
	v170.ZIndex = 3
	v170.Parent = p167
	local v171 = Instance.new("UIStroke")
	v171.Thickness = 2
	v171.Color = v_u_12
	v171.Parent = v170
	return v170
end
local function v_u_177(p173, p174) -- name: setKind
	-- upvalues: (copy) v_u_161, (copy) v_u_8, (copy) v_u_162, (copy) v_u_12
	if p173.kind ~= p174 and p173.kind ~= "kill" then
		p173.kind = p174
		p173.big = p174 == "crit" and true or p174 == "kill"
		p173.label.TextColor3 = v_u_161[p174] or v_u_8
		p173.label.TextSize = v_u_162[p174] or 42
		local v175 = p173.stroke
		local v176
		if p174 == "kill" then
			v176 = Color3.fromRGB(60, 6, 6)
		else
			v176 = v_u_12
		end
		v175.Color = v176
		if p173.tag then
			p173.tag.TextColor3 = p173.label.TextColor3
		end
	end
end
local function v_u_189(p178, p179, p180, p181) -- name: newNumber
	-- upvalues: (copy) v_u_159, (copy) v_u_7, (copy) v_u_162, (copy) v_u_161, (copy) v_u_8, (ref) v_u_160, (copy) v_u_12, (copy) v_u_158
	local v182 = os.clock()
	local v183 = table.remove(v_u_159)
	if not v183 then
		v183 = Instance.new("TextLabel")
		v183.Name = "DamageNumber"
		v183.BackgroundTransparency = 1
		v183.AnchorPoint = Vector2.new(0.5, 0.5)
		v183.Size = UDim2.fromOffset(200, 64)
		v183.FontFace = v_u_7
		v183.ZIndex = 3
		local v184 = Instance.new("UIStroke")
		v184.Thickness = 3.5
		v184.Parent = v183
		Instance.new("UIScale").Parent = v183
	end
	v183.TextSize = v_u_162[p179] or 42
	v183.TextColor3 = v_u_161[p179] or v_u_8
	v183.TextTransparency = 0
	v183.Visible = false
	v183.Parent = v_u_160
	local v185 = v183:FindFirstChildOfClass("UIStroke")
	local v186
	if p179 == "kill" then
		v186 = Color3.fromRGB(60, 6, 6)
	else
		v186 = v_u_12
	end
	v185.Color = v186
	v185.Transparency = 0
	local v187 = {
		["label"] = nil,
		["stroke"] = nil,
		["tag"] = nil,
		["world"] = nil,
		["t0"] = nil,
		["lastHit"] = nil,
		["offset"] = nil,
		["key"] = nil,
		["kind"] = nil,
		["amount"] = 0,
		["scale"] = nil,
		["big"] = nil,
		["predAmount"] = 0,
		["predN"] = 0,
		["confAmount"] = 0,
		["confN"] = 0,
		["predUntil"] = 0,
		["label"] = v183,
		["stroke"] = v185,
		["world"] = p178,
		["t0"] = v182,
		["lastHit"] = v182,
		["offset"] = Vector2.new((math.random() - 0.5) * 18, p181 * -32),
		["key"] = p180,
		["kind"] = p179,
		["scale"] = v183:FindFirstChildOfClass("UIScale"),
		["big"] = p179 == "crit" and true or p179 == "kill"
	}
	local v188 = v_u_158
	table.insert(v188, v187)
	return v187
end
local function v_u_194(p190, p191) -- name: stacked
	-- upvalues: (copy) v_u_158
	local v192 = 0
	if p190 ~= nil then
		for _, v193 in v_u_158 do
			if v193.key ~= p190 or p191 - v193.t0 >= 0.5 then
				continue
			end
			v192 = v192 + 1
		end
	end
	return v192
end
function v_u_4.PredictNumber(p195, p196, p197, p198) -- name: PredictNumber
	-- upvalues: (ref) v_u_160, (copy) v_u_158, (copy) v_u_177, (copy) v_u_166, (copy) v_u_189, (copy) v_u_194
	if p196 >= 0.5 and (v_u_160 and p198 ~= nil) then
		local v199 = os.clock()
		for _, v200 in v_u_158 do
			if v200.key ~= p198 or (v199 - v200.lastHit >= 0.45 or v200.kind == "dot") then
				continue
			end
			v200.predAmount = v200.predAmount + p196
			v200.predN = v200.predN + 1
			v200.lastHit = v199
			v200.predUntil = v199 + 0.7
			local v201 = v200.t0
			local v202 = v199 - 0.25
			v200.t0 = math.max(v201, v202)
			if p197 then
				v_u_177(v200, "crit")
			end
			local v203
			if v200.predN > v200.confN then
				local v204 = v200.confAmount
				local v205 = v200.predAmount
				v203 = math.max(v204, v205)
			else
				v203 = v200.confAmount
			end
			local v206 = v203 + 0.5
			local v207 = math.floor(v206)
			local v208 = v200.amount + 0.5
			local _ = v207 == math.floor(v208)
			v200.amount = v203
			local v209 = v200.label
			local v210 = v203 + 0.5
			local v211 = math.floor(v210)
			v209.Text = tostring(v211)
			v_u_166(v200)
			return
		end
		local v212 = v_u_189(p195, p197 and "crit" or "health", p198, (v_u_194(p198, v199)))
		v212.predAmount = p196
		v212.predN = 1
		v212.predUntil = v199 + 0.7
		local v213
		if v212.predN > v212.confN then
			local v214 = v212.confAmount
			local v215 = v212.predAmount
			v213 = math.max(v214, v215)
		else
			v213 = v212.confAmount
		end
		local v216 = v213 + 0.5
		local v217 = math.floor(v216)
		local v218 = v212.amount + 0.5
		local _ = v217 == math.floor(v218)
		v212.amount = v213
		local v219 = v212.label
		local v220 = v213 + 0.5
		local v221 = math.floor(v220)
		v219.Text = tostring(v221)
		v_u_166(v212)
	end
end
function v_u_4.DamageNumber(p222, p223, p224, p225, p226) -- name: DamageNumber
	-- upvalues: (ref) v_u_160, (copy) v_u_158, (copy) v_u_177, (copy) v_u_172, (copy) v_u_166, (copy) v_u_189, (copy) v_u_194
	if p223 >= 0.5 and v_u_160 then
		local v227 = os.clock()
		if p225 ~= nil then
			for _, v228 in v_u_158 do
				if v228.key ~= p225 or (v228.predN <= v228.confN or (v227 >= v228.predUntil + 0.2 or p224 == "dot")) then
					continue
				end
				v228.confN = v228.confN + 1
				v228.confAmount = v228.confAmount + p223
				v228.lastHit = v227
				local v229 = v228.predUntil
				local v230 = v227 + 0.15
				v228.predUntil = math.max(v229, v230)
				local v231 = v228.kind
				if p224 ~= "health" then
					v_u_177(v228, p224)
				end
				if p226 and not v228.tag then
					v228.tag = v_u_172(v228.label, p226, v228.label.TextColor3)
				end
				local v232 = v228.kind ~= v231
				local v233
				if v228.predN > v228.confN then
					local v234 = v228.confAmount
					local v235 = v228.predAmount
					v233 = math.max(v234, v235)
				else
					v233 = v228.confAmount
				end
				local v236 = v233 + 0.5
				local v237 = math.floor(v236)
				local v238 = v228.amount + 0.5
				local v239 = v237 ~= math.floor(v238)
				v228.amount = v233
				local v240 = v228.label
				local v241 = v233 + 0.5
				local v242 = math.floor(v241)
				v240.Text = tostring(v242)
				if v232 or v239 then
					v_u_166(v228)
				end
				return
			end
			for _, v243 in v_u_158 do
				if v243.key ~= p225 or v243.predN > v243.confN then
					continue
				end
				local v244
				if v243.kind == p224 then
					v244 = true
				elseif p224 == "kill" then
					v244 = v243.kind == "health" and true or v243.kind == "crit"
				else
					v244 = false
				end
				if not v244 or v227 - v243.lastHit >= 0.45 then
					continue
				end
				v243.confN = v243.confN + 1
				v243.confAmount = v243.confAmount + p223
				v243.lastHit = v227
				local v245 = v243.t0
				local v246 = v227 - 0.25
				v243.t0 = math.max(v245, v246)
				if p224 == "kill" then
					v_u_177(v243, "kill")
				end
				if p226 and not v243.tag then
					v243.tag = v_u_172(v243.label, p226, v243.label.TextColor3)
				end
				local v247
				if v243.predN > v243.confN then
					local v248 = v243.confAmount
					local v249 = v243.predAmount
					v247 = math.max(v248, v249)
				else
					v247 = v243.confAmount
				end
				local v250 = v247 + 0.5
				local v251 = math.floor(v250)
				local v252 = v243.amount + 0.5
				local _ = v251 == math.floor(v252)
				v243.amount = v247
				local v253 = v243.label
				local v254 = v247 + 0.5
				local v255 = math.floor(v254)
				v253.Text = tostring(v255)
				v_u_166(v243)
				return
			end
		end
		local v256 = v_u_189(p222, p224, p225, (v_u_194(p225, v227)))
		v256.confAmount = p223
		v256.confN = 1
		if p226 then
			v256.tag = v_u_172(v256.label, p226, v256.label.TextColor3)
		end
		local v257
		if v256.predN > v256.confN then
			local v258 = v256.confAmount
			local v259 = v256.predAmount
			v257 = math.max(v258, v259)
		else
			v257 = v256.confAmount
		end
		local v260 = v257 + 0.5
		local v261 = math.floor(v260)
		local v262 = v256.amount + 0.5
		local _ = v261 == math.floor(v262)
		v256.amount = v257
		local v263 = v256.label
		local v264 = v257 + 0.5
		local v265 = math.floor(v264)
		v263.Text = tostring(v265)
		v_u_166(v256)
	end
end
local function v_u_292() -- name: updateNumbers
	-- upvalues: (copy) v_u_158, (copy) v_u_166, (copy) v_u_159, (ref) v_u_18
	if #v_u_158 ~= 0 then
		local v266 = workspace.CurrentCamera
		local v267 = os.clock()
		local v268 = 1
		while v268 <= #v_u_158 do
			local v269 = v_u_158[v268]
			if v269.predN > v269.confN and v269.predUntil < v267 then
				v269.predN = v269.confN
				v269.predAmount = v269.confAmount
				if v269.confN == 0 then
					local v270 = v269.t0
					local v271 = v267 - 0.9999999999999999
					v269.t0 = math.min(v270, v271)
				else
					local v272
					if v269.predN > v269.confN then
						local v273 = v269.confAmount
						local v274 = v269.predAmount
						v272 = math.max(v273, v274)
					else
						v272 = v269.confAmount
					end
					local v275 = v272 + 0.5
					local v276 = math.floor(v275)
					local v277 = v269.amount + 0.5
					local v278 = v276 ~= math.floor(v277)
					v269.amount = v272
					local v279 = v269.label
					local v280 = v272 + 0.5
					local v281 = math.floor(v280)
					v279.Text = tostring(v281)
					if v278 then
						v_u_166(v269)
					end
				end
			end
			local v282 = v267 - v269.t0
			if v282 >= 1.15 then
				if v269.tag then
					v269.tag:Destroy()
				end
				if #v_u_159 < 24 then
					v269.label.Visible = false
					v269.label.Parent = nil
					local v283 = v_u_159
					local v284 = v269.label
					table.insert(v283, v284)
				else
					v269.label:Destroy()
				end
				table.remove(v_u_158, v268)
			else
				local v285 = v282 / 1.15
				local v286 = 3.5 * (1 - (1 - v285) * (1 - v285))
				local v287, v288 = v266:WorldToViewportPoint(v269.world + Vector3.new(0, v286, 0))
				local v289 = v269.label
				if v288 then
					v288 = v287.Z > 0
				end
				v289.Visible = v288
				v269.label.Position = UDim2.fromOffset(v287.X + v269.offset.X * v_u_18, v287.Y + v269.offset.Y * v_u_18)
				local v290 = (v282 - 0.7499999999999999) / 0.4
				local v291 = math.clamp(v290, 0, 1)
				v269.label.TextTransparency = v291
				v269.stroke.Transparency = v291
				if v269.tag then
					v269.tag.TextTransparency = v291
				end
				v268 = v268 + 1
			end
		end
	end
end
local v_u_293 = {}
local v_u_294 = nil
local v_u_295 = {}
local function v_u_300() -- name: buildVignette
	-- upvalues: (copy) v_u_10, (ref) v_u_14, (copy) v_u_295
	for _, v296 in {
		{
			"Top",
			UDim2.new(1, 0, 0.24, 0),
			UDim2.fromScale(0.5, 0),
			Vector2.new(0.5, 0),
			90
		},
		{
			"Bottom",
			UDim2.new(1, 0, 0.24, 0),
			UDim2.fromScale(0.5, 1),
			Vector2.new(0.5, 1),
			-90
		},
		{
			"Left",
			UDim2.new(0.2, 0, 1, 0),
			UDim2.fromScale(0, 0.5),
			Vector2.new(0, 0.5),
			0
		},
		{
			"Right",
			UDim2.new(0.2, 0, 1, 0),
			UDim2.fromScale(1, 0.5),
			Vector2.new(1, 0.5),
			180
		}
	} do
		local v297 = Instance.new("Frame")
		v297.Name = "Vignette" .. v296[1]
		v297.Size = v296[2]
		v297.Position = v296[3]
		v297.AnchorPoint = v296[4]
		v297.BorderSizePixel = 0
		v297.BackgroundColor3 = v_u_10
		v297.BackgroundTransparency = 1
		v297.Parent = v_u_14
		local v298 = Instance.new("UIGradient")
		v298.Rotation = v296[5]
		v298.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
		v298.Parent = v297
		local v299 = v_u_295
		table.insert(v299, v297)
	end
end
function v_u_4.Hurt(p301, p302) -- name: Hurt
	-- upvalues: (copy) v_u_295, (copy) v_u_3
	local v303 = math.clamp(p301, 0.15, 1)
	for _, v304 in v_u_295 do
		v304.BackgroundColor3 = p302 or Color3.fromRGB(200, 20, 20)
		v304.BackgroundTransparency = 1 - v303 * 0.6
		v_u_3:Create(v304, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["BackgroundTransparency"] = 1
		}):Play()
	end
end
function v_u_4.Flash(p305, p306, p307) -- name: Flash
	-- upvalues: (copy) v_u_295, (copy) v_u_3
	for _, v308 in v_u_295 do
		v308.BackgroundColor3 = p305
		v308.BackgroundTransparency = 1 - math.clamp(p306, 0, 1) * 0.6
		v_u_3:Create(v308, TweenInfo.new(p307 or 0.14, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["BackgroundTransparency"] = 1
		}):Play()
	end
end
function v_u_4.DamageFrom(p309, p310, p311, p312) -- name: DamageFrom
	-- upvalues: (copy) v_u_33, (ref) v_u_15, (copy) v_u_10, (copy) v_u_12, (copy) v_u_293
	local v313 = v_u_33(v_u_15, "DamageDir", UDim2.fromOffset(0, 0))
	v313.BackgroundTransparency = 1
	local v314 = p310 and 22 or 18
	local v315 = p310 and 7 or 5
	local v316 = {}
	for v317 = -1, 1 do
		local v318 = v_u_33(v313, "S" .. v317, UDim2.fromOffset(v314, v315), nil, p311 or v_u_10)
		local v319 = Instance.new("UICorner")
		v319.CornerRadius = UDim.new(1, 0)
		v319.Parent = v318
		local v320
		if p311 then
			v320 = Color3.fromRGB(60, 40, 10)
		else
			v320 = Color3.fromRGB(80, 0, 8)
		end
		local v321 = Instance.new("UIStroke")
		v321.Name = "Stroke"
		v321.Thickness = 1.2
		v321.Color = v320 or v_u_12
		v321.Transparency = 0.35
		v321.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v321.Parent = v318
		v318:SetAttribute("Offset", v317)
		table.insert(v316, v318)
	end
	local v322 = v_u_293
	local v323 = {
		["frame"] = v313,
		["source"] = p309,
		["t0"] = os.clock(),
		["life"] = p312
	}
	table.insert(v322, v323)
	if #v_u_293 > 6 then
		table.remove(v_u_293, 1).frame:Destroy()
	end
end
local function v_u_349() -- name: updateIndicators
	-- upvalues: (copy) v_u_293
	if #v_u_293 ~= 0 then
		local v324 = workspace.CurrentCamera
		local v325 = os.clock()
		local v326 = v324.CFrame
		local v327 = v326.LookVector.X
		local v328 = v326.LookVector.Z
		local v329 = Vector3.new(v327, 0, v328)
		local v330 = v326.RightVector.X
		local v331 = v326.RightVector.Z
		local v332 = Vector3.new(v330, 0, v331)
		local v333 = 1
		while v333 <= #v_u_293 do
			local v334 = v_u_293[v333]
			local v335 = v325 - v334.t0
			local v336 = v334.life or 0.6
			if v336 < v335 then
				v334.frame:Destroy()
				table.remove(v_u_293, v333)
			else
				local v337 = v334.source - v326.Position
				local v338 = v337.X
				local v339 = v337.Z
				local v340 = Vector3.new(v338, 0, v339)
				local v341
				if v340.Magnitude > 0.1 and v329.Magnitude > 0.01 then
					local v342 = v340.Unit:Dot(v332.Unit)
					local v343 = v340.Unit:Dot(v329.Unit)
					v341 = math.atan2(v342, v343)
				else
					v341 = 0
				end
				local v344 = (v335 - (v336 - 0.45)) / 0.45
				local v345 = math.clamp(v344, 0, 1)
				for _, v346 in v334.frame:GetChildren() do
					if not v346:IsA("Frame") then
						continue
					end
					local v347 = v341 + 0.1308996938995747 * (v346:GetAttribute("Offset") or 0)
					v346.Position = UDim2.new(0.5, math.sin(v347) * 140, 0.5, -math.cos(v347) * 140)
					v346.Rotation = math.deg(v347)
					v346.BackgroundTransparency = v345
					local v348 = v346:FindFirstChild("Stroke")
					if not v348 then
						continue
					end
					v348.Transparency = v345 * 0.65 + 0.35
				end
				v333 = v333 + 1
			end
		end
	end
end
local v_u_350 = nil
local v_u_351 = nil
local v_u_352 = nil
local v_u_353 = 0
local v_u_354 = 0
local v_u_355 = nil
local v_u_356 = nil
local v_u_357 = nil
local v_u_358 = nil
local function v_u_369() -- name: buildBars
	-- upvalues: (ref) v_u_350, (copy) v_u_33, (ref) v_u_15, (copy) v_u_12, (ref) v_u_351, (ref) v_u_352, (copy) v_u_54, (ref) v_u_355, (copy) v_u_9, (ref) v_u_356, (ref) v_u_357, (copy) v_u_10, (copy) v_u_7, (ref) v_u_358
	v_u_350 = v_u_33(v_u_15, "Channel", UDim2.fromOffset(170, 10), UDim2.new(0.5, 0, 0.5, 76), v_u_12)
	v_u_350.BackgroundTransparency = 0.25
	local v359 = v_u_350
	local v360 = Instance.new("UICorner")
	v360.CornerRadius = UDim.new(0.5, 0)
	v360.Parent = v359
	local v361 = v_u_350
	local v362 = v_u_12
	local v363 = Instance.new("UIStroke")
	v363.Name = "Stroke"
	v363.Thickness = 2
	v363.Color = v362 or v_u_12
	v363.Transparency = 0.2
	v363.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v363.Parent = v361
	v_u_351 = v_u_33(v_u_350, "Fill", UDim2.fromScale(0, 1), UDim2.fromScale(0, 0.5), Color3.fromRGB(120, 220, 110))
	v_u_351.AnchorPoint = Vector2.new(0, 0.5)
	local v364 = v_u_351
	local v365 = Instance.new("UICorner")
	v365.CornerRadius = UDim.new(0.5, 0)
	v365.Parent = v364
	v_u_352 = v_u_54(v_u_350, "Text", "", 18, UDim2.new(0.5, 0, 0, -16))
	v_u_350.Visible = false
	v_u_355 = v_u_54(v_u_15, "Toast", "", 22, UDim2.new(0.5, 0, 0.5, -124), v_u_9)
	v_u_356 = v_u_54(v_u_15, "Ammo", "", 18, UDim2.new(0.5, 0, 0.5, 60))
	v_u_356.Visible = false
	v_u_355.TextTransparency = 1
	local v366 = v_u_355:FindFirstChildOfClass("UIStroke")
	if v366 then
		v366.Transparency = 1
	end
	v_u_357 = v_u_54(v_u_15, "Kill", "", 28, UDim2.new(0.5, 0, 0.5, 100), v_u_10)
	v_u_357.FontFace = v_u_7
	v_u_357.TextTransparency = 1
	v_u_358 = v_u_54(v_u_15, "KillSub", "", 17, UDim2.new(0.5, 0, 0.5, 122), v_u_9)
	v_u_358.TextTransparency = 1
	for _, v367 in { v_u_357, v_u_358 } do
		local v368 = v367:FindFirstChildOfClass("UIStroke")
		if not v368 then
			continue
		end
		v368.Transparency = 1
	end
end
function v_u_4.StartChannel(p370, p371, p372) -- name: StartChannel
	-- upvalues: (ref) v_u_353, (ref) v_u_354, (ref) v_u_352, (ref) v_u_351, (ref) v_u_350
	v_u_353 = os.clock()
	v_u_354 = v_u_353 + p371
	v_u_352.Text = p370
	v_u_351.BackgroundColor3 = p372 or Color3.fromRGB(120, 220, 110)
	v_u_351.Size = UDim2.fromScale(0, 1)
	v_u_350.Visible = true
end
function v_u_4.StopChannel() -- name: StopChannel
	-- upvalues: (ref) v_u_350, (ref) v_u_354
	v_u_350.Visible = false
	v_u_354 = 0
end
function v_u_4.Toast(p373, p374, p375) -- name: Toast
	-- upvalues: (ref) v_u_355, (copy) v_u_9, (copy) v_u_3
	v_u_355.Text = p373
	v_u_355.TextColor3 = p374 or v_u_9
	v_u_355.TextTransparency = 0
	local v_u_376 = v_u_355:FindFirstChildOfClass("UIStroke")
	if v_u_376 then
		v_u_376.Transparency = 0.2
	end
	local v377 = v_u_355:FindFirstChildOfClass("UIScale") or Instance.new("UIScale")
	v377.Parent = v_u_355
	v377.Scale = 1.25
	v_u_3:Create(v377, TweenInfo.new(0.15, Enum.EasingStyle.Back), {
		["Scale"] = 1
	}):Play()
	local v_u_378 = os.clock()
	v_u_355:SetAttribute("T", v_u_378)
	task.delay(p375 or 1.1, function()
		-- upvalues: (ref) v_u_355, (copy) v_u_378, (ref) v_u_3, (copy) v_u_376
		if v_u_355:GetAttribute("T") == v_u_378 then
			v_u_3:Create(v_u_355, TweenInfo.new(0.3), {
				["TextTransparency"] = 1
			}):Play()
			if v_u_376 then
				v_u_3:Create(v_u_376, TweenInfo.new(0.3), {
					["Transparency"] = 1
				}):Play()
			end
		end
	end)
end
function v_u_4.KillBanner(p379, p380) -- name: KillBanner
	-- upvalues: (ref) v_u_357, (ref) v_u_358, (copy) v_u_3
	v_u_357.Text = p379
	v_u_358.Text = p380 or ""
	local v_u_381 = os.clock()
	for _, v382 in { v_u_357, v_u_358 } do
		v382.TextTransparency = v382 == v_u_358 and not p380 and 1 or 0
		local v383 = v382:FindFirstChildOfClass("UIStroke")
		if v383 then
			v383.Transparency = v382 == v_u_358 and not p380 and 1 or 0.1
		end
		local v384 = v382:FindFirstChildOfClass("UIScale") or Instance.new("UIScale")
		v384.Parent = v382
		v384.Scale = 1.7
		v_u_3:Create(v384, TweenInfo.new(0.26, Enum.EasingStyle.Back), {
			["Scale"] = 1
		}):Play()
		v382:SetAttribute("T", v_u_381)
	end
	task.delay(1.7, function()
		-- upvalues: (ref) v_u_357, (ref) v_u_358, (copy) v_u_381, (ref) v_u_3
		for _, v385 in { v_u_357, v_u_358 } do
			if v385:GetAttribute("T") ~= v_u_381 then
				continue
			end
			v_u_3:Create(v385, TweenInfo.new(0.4), {
				["TextTransparency"] = 1
			}):Play()
			local v386 = v385:FindFirstChildOfClass("UIStroke")
			if not v386 then
				continue
			end
			v_u_3:Create(v386, TweenInfo.new(0.4), {
				["Transparency"] = 1
			}):Play()
		end
	end)
end
function v_u_4.SetStyle(p387) -- name: SetStyle
	-- upvalues: (copy) v_u_16, (ref) v_u_17, (ref) v_u_19, (ref) v_u_20, (ref) v_u_22, (ref) v_u_21
	local v388 = not v_u_16[p387] and "Dot" or p387
	v_u_17 = v388
	for v389, v390 in v_u_16 do
		v390.Visible = v389 == v388
	end
	v_u_19 = 0
	v_u_20 = 0
	v_u_22 = false
	v_u_21 = 0
end
function v_u_4.GetStyle() -- name: GetStyle
	-- upvalues: (ref) v_u_17
	return v_u_17
end
function v_u_4.SetCharge(p391) -- name: SetCharge
	-- upvalues: (ref) v_u_19
	v_u_19 = math.clamp(p391, 0, 1)
end
function v_u_4.Kick(p392) -- name: Kick
	-- upvalues: (ref) v_u_20
	local v393 = v_u_20 + p392
	v_u_20 = math.min(v393, 30)
end
function v_u_4.SetSpread(p394) -- name: SetSpread
	-- upvalues: (ref) v_u_21
	v_u_21 = math.max(0, p394)
end
function v_u_4.SetPips(p395, p396, p397) -- name: SetPips
	-- upvalues: (ref) v_u_56, (copy) v_u_57, (copy) v_u_12, (copy) v_u_8
	local v398 = p396 or 0
	v_u_56.Visible = v398 > 0
	for v399 = #v_u_57 + 1, v398 do
		local v400 = Instance.new("Frame")
		v400.Name = "P" .. v399
		v400.LayoutOrder = v399
		v400.Size = UDim2.fromOffset(8, 8)
		v400.BorderSizePixel = 0
		v400.Rotation = 45
		v400.Parent = v_u_56
		local v401 = v_u_12
		local v402 = Instance.new("UIStroke")
		v402.Name = "Stroke"
		v402.Thickness = 1.2
		v402.Color = v401 or v_u_12
		v402.Transparency = 0.2
		v402.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v402.Parent = v400
		v_u_57[v399] = v400
	end
	for v403, v404 in v_u_57 do
		v404.Visible = v403 <= v398
		local v405 = v403 <= p395
		local v406
		if v405 then
			v406 = p397 or v_u_8
		else
			v406 = v_u_12
		end
		v404.BackgroundColor3 = v406
		v404.BackgroundTransparency = v405 and 0 or 0.55
	end
end
local v_u_407 = {
	["ARROWS"] = "ARROW",
	["BULLETS"] = "BULLET"
}
function v_u_4.SetAmmoCount(p408, p409) -- name: SetAmmoCount
	-- upvalues: (ref) v_u_356, (copy) v_u_407, (copy) v_u_10, (copy) v_u_9, (copy) v_u_8
	if v_u_356 then
		if p408 == nil then
			v_u_356.Visible = false
		else
			v_u_356.Visible = true
			local v410 = math.floor(p408)
			local v411 = math.max(0, v410)
			local v412 = p409 or ""
			if v411 == 1 then
				v412 = v_u_407[v412] or v412
			end
			v_u_356.Text = ("%* %*"):format(v411, v412)
			local v413 = v_u_356
			local v414
			if p408 <= 0 then
				v414 = v_u_10
			elseif p408 <= 3 then
				v414 = v_u_9
			else
				v414 = v_u_8
			end
			v413.TextColor3 = v414
		end
	else
		return
	end
end
function v_u_4.SetArc(p415, p416, p417) -- name: SetArc
	-- upvalues: (ref) v_u_24, (ref) v_u_25, (ref) v_u_26, (copy) v_u_8, (copy) v_u_55
	if p415 and p415 > 0 then
		v_u_24 = os.clock() - (p417 or 0)
		v_u_25 = v_u_24 + p415
		v_u_26 = p416 or v_u_8
	else
		v_u_25 = 0
		for _, v418 in v_u_55 do
			v418.Visible = false
		end
	end
end
function v_u_4.SetBlocking(p419) -- name: SetBlocking
	-- upvalues: (ref) v_u_22, (copy) v_u_16, (copy) v_u_3
	v_u_22 = p419
	local v420 = v_u_16.Melee
	if v420 then
		v420 = v_u_16.Melee:FindFirstChild("Shield")
	end
	if v420 then
		v420 = v420:FindFirstChild("Pulse")
	end
	if v420 and p419 then
		v420.Scale = 0.6
		v_u_3:Create(v420, TweenInfo.new(0.14, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			["Scale"] = 1
		}):Play()
	end
end
function v_u_4.BlockPulse() -- name: BlockPulse
	-- upvalues: (copy) v_u_16, (copy) v_u_3, (copy) v_u_8, (copy) v_u_11
	local v421 = v_u_16.Melee
	if v421 then
		v421 = v_u_16.Melee:FindFirstChild("Shield")
	end
	if v421 then
		local v422 = v421:FindFirstChild("Pulse")
		if v422 then
			v422.Scale = 1.45
			v_u_3:Create(v422, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Scale"] = 1
			}):Play()
		end
		for _, v423 in v421:GetChildren() do
			if not v423:IsA("Frame") then
				continue
			end
			v423.BackgroundColor3 = v_u_8
			v423.BackgroundTransparency = 0
			local v424 = {
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.3,
				["BackgroundColor3"] = v_u_11
			}
			v_u_3:Create(v423, TweenInfo.new(0.25), v424):Play()
		end
	end
end
function v_u_4.SetFrozen(p425) -- name: SetFrozen
	-- upvalues: (ref) v_u_23, (ref) v_u_15, (copy) v_u_13, (copy) v_u_8
	if v_u_23 ~= p425 then
		v_u_23 = p425
		for _, v426 in v_u_15:GetDescendants() do
			if not v426:IsA("Frame") or v426.Name ~= "Dot" then
				continue
			end
			local v427
			if v_u_23 then
				v427 = v_u_13
			else
				v427 = v_u_8
			end
			v426.BackgroundColor3 = v427
		end
	end
end
local function v_u_490(p428) -- name: update
	-- upvalues: (ref) v_u_20, (copy) v_u_16, (ref) v_u_17, (ref) v_u_19, (copy) v_u_9, (copy) v_u_8, (ref) v_u_21, (ref) v_u_18, (ref) v_u_22, (ref) v_u_25, (ref) v_u_24, (copy) v_u_55, (ref) v_u_26, (copy) v_u_12, (copy) v_u_4, (ref) v_u_354, (ref) v_u_353, (ref) v_u_351, (copy) v_u_349, (copy) v_u_292
	local v429 = os.clock()
	local v430 = v_u_20 - p428 * 80
	v_u_20 = math.max(0, v430)
	local v431 = v_u_16[v_u_17]
	if v_u_17 == "Bow" or v_u_17 == "Throw" then
		local v432 = v431:FindFirstChild("Ring")
		local v433 = v_u_17 == "Bow" and 66 or 44
		local v434 = v433 - (v433 - 12) * v_u_19 ^ 0.8
		v432.Size = UDim2.fromOffset(v434, v434)
		local v435 = v432:FindFirstChild("Stroke")
		local v436
		if v_u_19 >= 0.999 then
			v436 = v_u_9
		else
			v436 = v_u_8
		end
		v435.Color = v436
		local v437
		if v_u_19 >= 0.999 then
			local v438 = v429 * 20
			v437 = math.sin(v438) * 0.6 + 2.8
		else
			v437 = 2.2
		end
		v435.Thickness = v437
		v435.Transparency = v_u_19 > 0 and 0 or 0.35
		if v_u_17 == "Bow" then
			for v439, v440 in { -1, 1 } do
				local v441 = v431:FindFirstChild("Side" .. v439)
				v441.Position = UDim2.new(0.5, v440 * (v434 / 2 + 8), 0.5, 0)
				v441.BackgroundColor3 = v435.Color
			end
		end
	elseif v_u_17 == "Gun" then
		local v442 = v_u_21
		local v443 = workspace.CurrentCamera
		local v444 = v443.FieldOfView
		local v445 = v443.ViewportSize.Y / 2
		local v446 = math.rad(v442)
		local v447 = math.tan(v446)
		local v448 = v444 / 2
		local v449 = math.rad(v448)
		local v450 = v447 / math.tan(v449) * v445 / v_u_18 + 5 + v_u_20
		local v451 = v431:FindFirstChild("Up")
		local v452 = v431:FindFirstChild("Down")
		local v453 = v431:FindFirstChild("Left")
		local v454 = v431:FindFirstChild("Right")
		v451.Position = UDim2.new(0.5, 0, 0.5, -v450 - 5)
		v452.Position = UDim2.new(0.5, 0, 0.5, v450 + 5)
		v453.Position = UDim2.new(0.5, -v450 - 5, 0.5, 0)
		v454.Position = UDim2.new(0.5, v450 + 5, 0.5, 0)
	elseif v_u_17 == "Spread" then
		local v455 = v431:FindFirstChild("Ring")
		local v456 = v_u_21
		local v457 = workspace.CurrentCamera
		local v458 = v457.FieldOfView
		local v459 = v457.ViewportSize.Y / 2
		local v460 = math.rad(v456)
		local v461 = math.tan(v460)
		local v462 = v458 / 2
		local v463 = math.rad(v462)
		local v464 = v461 / math.tan(v463) * v459 / v_u_18
		local v465 = math.max(10, v464) + v_u_20 * 0.6
		v455.Size = UDim2.fromOffset(v465 * 2, v465 * 2)
		for v466 = 0, 3 do
			local v467 = v466 * 90
			local v468 = math.rad(v467)
			v431:FindFirstChild("Notch" .. v466).Position = UDim2.new(0.5, math.sin(v468) * v465, 0.5, -math.cos(v468) * v465)
		end
	elseif v_u_17 == "Melee" then
		local v469 = v431:FindFirstChild("Ring")
		local v470 = v469:FindFirstChild("Stroke")
		if v_u_19 > 0 then
			local v471 = 46 - v_u_19 * 26
			v469.Size = UDim2.fromOffset(v471, v471)
			local v472
			if v_u_19 >= 0.999 then
				v472 = v_u_9
			else
				v472 = v_u_8
			end
			v470.Color = v472
			v470.Transparency = 0
			local v473
			if v_u_19 >= 0.999 then
				local v474 = v429 * 20
				v473 = math.sin(v474) * 0.6 + 2.8
			else
				v473 = 2.2
			end
			v470.Thickness = v473
		else
			v470.Color = v_u_8
			v470.Transparency = 0.45
			v470.Thickness = 1.6
			v469.Size = UDim2.fromOffset(24, 24)
		end
		local v475 = v431:FindFirstChild("Shield")
		local v476 = v_u_22
		if v476 then
			v476 = v_u_19 <= 0
		end
		v475.Visible = v476
		v469.Visible = not v475.Visible
	end
	if v_u_25 > 0 then
		local v477 = v429 - v_u_24
		local v478 = v_u_25 - v_u_24
		local v479 = v477 / math.max(0.01, v478)
		local v480 = math.clamp(v479, 0, 1)
		local v481 = v480 * 24 + 0.5
		local v482 = math.floor(v481)
		for v483, v484 in v_u_55 do
			v484.Visible = true
			local v485
			if v483 <= v482 then
				v485 = v_u_26
			else
				v485 = v_u_12
			end
			v484.BackgroundColor3 = v485
			v484.BackgroundTransparency = v483 <= v482 and 0.05 or 0.6
		end
		if v480 >= 1 then
			v_u_4.SetArc(nil)
		end
	end
	if v_u_354 > 0 then
		local v486 = v429 - v_u_353
		local v487 = v_u_354 - v_u_353
		local v488 = v486 / math.max(0.01, v487)
		local v489 = math.clamp(v488, 0, 1)
		v_u_351.Size = UDim2.fromScale(v489, 1)
	end
	v_u_349()
	v_u_292()
end
function v_u_4.Init() -- name: Init
	-- upvalues: (copy) v_u_5, (ref) v_u_14, (ref) v_u_15, (copy) v_u_33, (ref) v_u_18, (ref) v_u_294, (ref) v_u_160, (copy) v_u_300, (copy) v_u_125, (copy) v_u_134, (copy) v_u_369, (copy) v_u_2, (copy) v_u_490
	local v491 = v_u_5:WaitForChild("PlayerGui")
	local v492 = v491:FindFirstChild("CombatHUD")
	if v492 then
		v492:Destroy()
	end
	v_u_14 = Instance.new("ScreenGui")
	v_u_14.Name = "CombatHUD"
	v_u_14.IgnoreGuiInset = true
	v_u_14.ScreenInsets = Enum.ScreenInsets.None
	v_u_14.ResetOnSpawn = false
	v_u_14.DisplayOrder = 4
	v_u_14.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	v_u_14.Parent = v491
	v_u_15 = v_u_33(v_u_14, "Center", UDim2.fromOffset(0, 0), UDim2.fromScale(0.5, 0.5))
	v_u_15.BackgroundTransparency = 1
	local v_u_493 = Instance.new("UIScale")
	v_u_493.Name = "ScreenScale"
	v_u_493.Parent = v_u_15
	local function v498() -- name: rescale
		-- upvalues: (ref) v_u_18, (copy) v_u_493
		local v494 = workspace.CurrentCamera.ViewportSize
		local v495 = v494.X / 1600
		local v496 = v494.Y / 900
		local v497 = math.min(v495, v496)
		v_u_18 = math.clamp(v497, 0.75, 1.6)
		v_u_493.Scale = v_u_18
	end
	local v499 = workspace.CurrentCamera.ViewportSize
	local v500 = v499.X / 1600
	local v501 = v499.Y / 900
	local v502 = math.min(v500, v501)
	v_u_18 = math.clamp(v502, 0.75, 1.6)
	v_u_493.Scale = v_u_18
	workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(v498)
	v_u_294 = v_u_33(v_u_14, "Directions", UDim2.fromScale(1, 1), UDim2.fromScale(0.5, 0.5))
	v_u_294.BackgroundTransparency = 1
	v_u_160 = v_u_33(v_u_14, "Numbers", UDim2.fromScale(1, 1), UDim2.fromScale(0.5, 0.5))
	v_u_160.BackgroundTransparency = 1
	v_u_160.ZIndex = 2
	v_u_300()
	v_u_125()
	v_u_134()
	v_u_369()
	v_u_2.RenderStepped:Connect(v_u_490)
end
function v_u_4.ScreenScale() -- name: ScreenScale
	-- upvalues: (ref) v_u_18
	return v_u_18
end
function v_u_4.SetVisible(p503) -- name: SetVisible
	-- upvalues: (ref) v_u_14
	if v_u_14 then
		v_u_14.Enabled = p503
	end
end
return v_u_4