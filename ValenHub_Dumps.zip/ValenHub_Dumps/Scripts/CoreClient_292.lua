local v_u_1 = script.Parent
local function v6(p2) -- name: start
	-- upvalues: (copy) v_u_1
	local v_u_3 = v_u_1:WaitForChild(p2, 10)
	if v_u_3 then
		local v4, v5 = pcall(function()
			-- upvalues: (copy) v_u_3
			require(v_u_3).Start()
		end)
		if not v4 then
			warn((("[CoreClient] %*.Start failed: %*"):format(p2, v5)))
		end
	else
		warn((("[CoreClient] missing module %*"):format(p2)))
	end
end
v6("LightingController")
v6("RingOfFire")
task.spawn(v6, "AnalyticsClient")