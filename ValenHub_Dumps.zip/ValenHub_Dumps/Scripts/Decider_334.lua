local v_u_1 = game:GetService("Lighting")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("TweenService")
local v6 = {}
local v_u_7 = Font.new("rbxasset://fonts/families/Oswald.json", Enum.FontWeight.Bold)
local v_u_8 = Color3.fromRGB
local v_u_9 = v_u_8(255, 198, 96)
local v_u_10 = v_u_8(255, 146, 52)
local v_u_11 = v_u_8(255, 98, 50)
local v_u_12 = v_u_8(255, 236, 200)
local v_u_13 = v_u_8(38, 12, 5)
v6.Color = v_u_10
local v_u_14 = {
	["PreRound"] = true,
	["Live"] = true,
	["Overtime"] = true
}
local v_u_15 = {
	["count"] = {
		["Brightness"] = -0.04,
		["Contrast"] = 0.14,
		["Saturation"] = 0.1,
		["TintColor"] = nil,
		["TintColor"] = v_u_8(255, 234, 212)
	},
	["live"] = {
		["Brightness"] = -0.02,
		["Contrast"] = 0.08,
		["Saturation"] = 0.07,
		["TintColor"] = nil,
		["TintColor"] = v_u_8(255, 243, 230)
	},
	["off"] = {
		["Brightness"] = 0,
		["Contrast"] = 0,
		["Saturation"] = 0,
		["TintColor"] = nil,
		["TintColor"] = v_u_8(255, 255, 255)
	}
}
local v_u_16 = {
	["count"] = 0.34,
	["live"] = 0.54,
	["off"] = 1
}
function v6.Init(p_u_17) -- name: Init
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (copy) v_u_13, (copy) v_u_14, (copy) v_u_4, (copy) v_u_1, (copy) v_u_16, (copy) v_u_15, (copy) v_u_7, (copy) v_u_10, (copy) v_u_8, (copy) v_u_9, (copy) v_u_12, (copy) v_u_11
	local v_u_18 = p_u_17.UI
	local v_u_19 = p_u_17.Theme
	local v_u_20 = p_u_17.State
	local v_u_21 = v_u_19.Colors
	local v_u_22 = v_u_18.Assets.Fx or {}
	local v_u_23 = v_u_18.Assets.Icons or {}
	local v_u_24 = v_u_2.LocalPlayer
	local v_u_25 = v_u_3:WaitForChild("Shared"):FindFirstChild("Sfx")
	local v26, v_u_27 = pcall(function()
		-- upvalues: (copy) v_u_25
		if v_u_25 then
			return require(v_u_25)
		else
			return nil
		end
	end)
	if not v26 or type(v_u_27) ~= "table" then
		v_u_27 = nil
	end
	if v_u_27 and v_u_27.Preload then
		local v28 = v_u_27.Preload
		pcall(v28, { "Match/Final_Round", "Match/Final_Heartbeat", "Music/Final_Round" })
	end
	local v_u_29 = 1
	local function v_u_37(p30, p31, p32, p33, p34, p35) -- name: tw
		-- upvalues: (ref) v_u_5, (ref) v_u_29
		local v36 = v_u_5:Create(p30, TweenInfo.new(p31 * v_u_29, p33 or Enum.EasingStyle.Quint, p34 or Enum.EasingDirection.Out, 0, false, (p35 or 0) * v_u_29), p32)
		v36:Play()
		return v36
	end
	local v_u_38 = {}
	local function v_u_50(p39, p40, p41, p42, p43, p44) -- name: textTo
		-- upvalues: (copy) v_u_37, (copy) v_u_38
		v_u_37(p39, p40, {
			["TextTransparency"] = p41
		}, p42, p43, p44)
		local v45 = v_u_38[p39]
		if v45 then
			local v46 = v_u_37
			local v47 = v45.stroke
			local v48 = {}
			local v49 = v_u_38[p39]
			v48.Transparency = (not v49 or p41 >= 1) and 1 or v49.base + (1 - v49.base) * p41
			v46(v47, p40, v48, p42, p43, p44)
		end
	end
	local function v_u_58(p51) -- name: isDecider
		-- upvalues: (copy) v_u_20
		if p51 == nil then
			p51 = v_u_20.Match
		end
		if type(p51) == "table" then
			local v52 = p51.teams
			if type(v52) == "table" then
				local v53 = p51.roundsToWin
				local v54
				if type(v53) == "number" then
					v54 = p51.roundsToWin
				else
					v54 = v_u_20.RoundsToWin()
				end
				if v54 < 2 then
					return false
				end
				local v55 = p51.teams[1]
				local v56 = p51.teams[2]
				local v57
				if type(v55) == "table" and (type(v56) == "table" and v55.score == v54 - 1) then
					v57 = v56.score == v54 - 1
				else
					v57 = false
				end
				return v57
			end
		end
		return false
	end
	local function v61() -- name: active
		-- upvalues: (copy) v_u_20, (ref) v_u_14, (copy) v_u_58
		local v59 = v_u_20.Match
		local v60 = v_u_20.SeesMatch()
		if v60 then
			if type(v59) == "table" and v_u_14[v59.phase] == true then
				v60 = v_u_58(v59)
			else
				v60 = false
			end
		end
		return v60
	end
	local _, v62 = v_u_18.Screen("TR_FinalRound", -1, p_u_17.PlayerGui, {
		["fullBleed"] = true
	})
	local v_u_63 = v_u_18.new("ImageLabel", {
		["Name"] = "Vignette",
		["Size"] = nil,
		["Image"] = nil,
		["ImageColor3"] = nil,
		["ImageTransparency"] = 1,
		["ScaleType"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Image"] = v_u_22.Vignette or "",
		["ImageColor3"] = v_u_13,
		["ScaleType"] = Enum.ScaleType.Stretch,
		["Parent"] = v62
	})
	local v_u_64 = false
	local v_u_65 = "off"
	local v_u_66 = nil
	local v_u_67 = nil
	local v_u_68 = 1
	local v_u_69 = 1
	local v_u_70 = (-1 / 0)
	local v_u_71 = 0.2
	local v_u_72 = nil
	local v_u_73 = 0
	local function v_u_104(p74, p75) -- name: setAtmos
		-- upvalues: (ref) v_u_65, (ref) v_u_73, (copy) v_u_24, (ref) v_u_66, (copy) v_u_18, (ref) v_u_1, (ref) v_u_67, (ref) v_u_69, (ref) v_u_16, (ref) v_u_68, (ref) v_u_70, (copy) v_u_63, (ref) v_u_72, (ref) v_u_4, (ref) v_u_71, (ref) v_u_15, (ref) v_u_5
		if p74 == v_u_65 and not p75 then
			return
		else
			v_u_65 = p74
			v_u_73 = v_u_73 + 1
			local v_u_76 = v_u_73
			local v77 = p74 ~= "off"
			if v_u_24:GetAttribute("FinalRound") ~= (v77 and true or nil) then
				v_u_24:SetAttribute("FinalRound", v77 and true or nil)
			end
			if v77 and not v_u_66 then
				local v78 = {
					["Name"] = "TR_FinalRoundCC",
					["Parent"] = nil,
					["Parent"] = v_u_1
				}
				v_u_66 = v_u_18.new("ColorCorrectionEffect", v78)
			end
			if v_u_67 then
				v_u_67:Cancel()
				v_u_67 = nil
			end
			v_u_69 = v_u_16[p74]
			if p75 then
				v_u_68 = v_u_69
				v_u_70 = (-1 / 0)
			end
			if v77 then
				v_u_63.Visible = true
				if not v_u_72 then
					v_u_72 = v_u_4.RenderStepped:Connect(function(p79)
						-- upvalues: (ref) v_u_68, (ref) v_u_69, (ref) v_u_70, (ref) v_u_71, (ref) v_u_65, (ref) v_u_63, (ref) v_u_72
						local v80 = v_u_68
						local v81 = v_u_69 - v_u_68
						local v82 = -p79 * 3
						v_u_68 = v80 + v81 * (1 - math.exp(v82))
						local v83 = os.clock()
						local v84 = v83 - v_u_70
						local v85
						if v84 < 1 then
							local v86 = v_u_71
							local v87
							if v84 < 0 then
								v87 = 0
							elseif v84 < 0.06 then
								v87 = v84 / 0.06
							else
								local v88 = -(v84 - 0.06) / 0.14
								v87 = math.exp(v88)
							end
							local v89 = v86 * v87
							local v90 = v_u_71 * 0.6
							local v91 = v84 - 0.27
							local v92
							if v91 < 0 then
								v92 = 0
							elseif v91 < 0.06 then
								v92 = v91 / 0.06
							else
								local v93 = -(v91 - 0.06) / 0.14
								v92 = math.exp(v93)
							end
							v85 = v89 + v90 * v92
						else
							v85 = 0
						end
						local v94
						if v_u_65 == "live" then
							local v95 = v83 * 2.4
							v94 = math.sin(v95) * 0.03
						else
							v94 = 0
						end
						local v96 = v_u_63
						local v97 = v_u_68 - v85 + v94
						local v98 = v_u_68
						local v99 = math.min(v98, 0.14)
						v96.ImageTransparency = math.clamp(v97, v99, 1)
						if v_u_65 == "off" and (v_u_68 > 0.995 and v84 > 1) then
							v_u_63.ImageTransparency = 1
							v_u_63.Visible = false
							if v_u_72 then
								v_u_72:Disconnect()
								v_u_72 = nil
							end
						end
					end)
				end
			elseif p75 then
				v_u_63.ImageTransparency = 1
				v_u_63.Visible = false
				if v_u_72 then
					v_u_72:Disconnect()
					v_u_72 = nil
				end
			end
			local v100 = v_u_66
			if v100 then
				v100.Enabled = true
				if p75 then
					if v77 then
						for v101, v102 in v_u_15[p74] do
							v100[v101] = v102
						end
					else
						v100:Destroy()
						v_u_66 = nil
					end
				else
					local v103 = p74 == "off" and 0.7 or (p74 == "count" and 0.5 or 1.2)
					v_u_67 = v_u_5:Create(v100, TweenInfo.new(v103, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), v_u_15[p74])
					v_u_67:Play()
					if not v77 then
						task.delay(v103 + 0.05, function()
							-- upvalues: (copy) v_u_76, (ref) v_u_73, (ref) v_u_65, (ref) v_u_66
							if v_u_76 == v_u_73 and (v_u_65 == "off" and v_u_66) then
								v_u_66:Destroy()
								v_u_66 = nil
							end
						end)
					end
					return
				end
			else
				return
			end
		end
	end
	local function v_u_106() -- name: wanted
		-- upvalues: (copy) v_u_20, (copy) v_u_24, (ref) v_u_64, (ref) v_u_14, (copy) v_u_58
		local v105 = v_u_20.Match
		return v_u_20.SeesMatch() and (type(v105) == "table" and v_u_24:GetAttribute("ReplayPlaying") ~= true) and (v_u_64 and "count" or (v_u_14[v105.phase] and v_u_58(v105) and (v105.phase == "PreRound" and "count" or "live") or "off")) or "off"
	end
	local v_u_107 = nil
	local function v_u_112(p108, p109, p110) -- name: headlineLabel
		-- upvalues: (copy) v_u_18, (ref) v_u_7, (copy) v_u_21
		local v111 = v_u_18.new("TextLabel", {
			["Name"] = nil,
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Text"] = "FINAL ROUND",
			["FontFace"] = nil,
			["TextSize"] = 100,
			["TextColor3"] = nil,
			["TextTransparency"] = 1,
			["ZIndex"] = nil,
			["Parent"] = nil,
			["Name"] = p109,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Size"] = UDim2.fromOffset(1400, 120),
			["FontFace"] = v_u_7,
			["TextColor3"] = v_u_21.Text,
			["ZIndex"] = p110,
			["Parent"] = p108
		})
		return v111, v_u_18.new("UIScale", {
			["Name"] = "HeadScale",
			["Parent"] = nil,
			["Parent"] = v111
		})
	end
	local function v_u_114(p113) -- name: fadeEnds
		return NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(p113, 0),
			NumberSequenceKeypoint.new(1 - p113, 0),
			NumberSequenceKeypoint.new(1, 1)
		})
	end
	local function v_u_165() -- name: buildCard
		-- upvalues: (copy) v_u_18, (copy) p_u_17, (copy) v_u_21, (copy) v_u_23, (ref) v_u_10, (copy) v_u_22, (ref) v_u_13, (copy) v_u_114, (ref) v_u_8, (ref) v_u_9, (copy) v_u_112, (ref) v_u_12, (copy) v_u_38, (copy) v_u_19, (ref) v_u_7
		local v115 = v_u_18.new("Frame", {
			["Name"] = "FinalRound",
			["Size"] = nil,
			["ZIndex"] = 4,
			["Visible"] = false,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = p_u_17.Canvas.Overlay
		})
		local v116 = v_u_18.new("Frame", {
			["Name"] = "Dim",
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 1,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = v_u_21.Void,
			["Parent"] = v115
		})
		local v117 = v_u_18.new("Frame", {
			["Name"] = "Stage",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.265),
			["Size"] = UDim2.fromOffset(0, 0),
			["Parent"] = v115
		})
		local v118 = v_u_18.new("UIScale", {
			["Name"] = "StageScale",
			["Parent"] = nil,
			["Parent"] = v117
		})
		local v_u_119 = v_u_18.new("Frame", {
			["Name"] = "Shaker",
			["Size"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(0, 0),
			["Parent"] = v117
		})
		local v120 = v_u_18.new("ImageLabel", {
			["Name"] = "Glow",
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Image"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 1,
			["ZIndex"] = 1,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Size"] = UDim2.fromOffset(1100, 360),
			["Image"] = v_u_23.Glow or "",
			["ImageColor3"] = v_u_10,
			["Parent"] = v_u_119
		})
		local v121 = v_u_18.new("ImageLabel", {
			["Name"] = "GhostBand",
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Image"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 1,
			["ScaleType"] = nil,
			["ZIndex"] = 1,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Size"] = UDim2.fromOffset(1500, 198.4),
			["Image"] = v_u_22.Band or "",
			["ImageColor3"] = v_u_13,
			["ScaleType"] = Enum.ScaleType.Stretch,
			["Parent"] = v_u_119
		})
		v_u_18.new("UIGradient", {
			["Transparency"] = v_u_114(0.25),
			["Parent"] = v121
		})
		local v122 = v_u_18.new("ImageLabel", {
			["Name"] = "Band",
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Image"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 0.06,
			["ScaleType"] = nil,
			["ZIndex"] = 2,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Size"] = UDim2.fromOffset(0, 124),
			["Image"] = v_u_22.Band or "",
			["ImageColor3"] = Color3.new(1, 1, 1),
			["ScaleType"] = Enum.ScaleType.Stretch,
			["Parent"] = v_u_119
		})
		local v123 = v_u_18.new("UIGradient", {
			["Color"] = ColorSequence.new({
				ColorSequenceKeypoint.new(0, v_u_13),
				ColorSequenceKeypoint.new(0.3, v_u_8(92, 30, 10)),
				ColorSequenceKeypoint.new(0.5, v_u_8(120, 42, 12)),
				ColorSequenceKeypoint.new(0.7, v_u_8(92, 30, 10)),
				ColorSequenceKeypoint.new(1, v_u_13)
			}),
			["Transparency"] = v_u_114(0.14),
			["Parent"] = v122
		})
		local function v126(p124) -- name: edge
			-- upvalues: (ref) v_u_18, (ref) v_u_9, (copy) v_u_119, (ref) v_u_114
			local v125 = v_u_18.new("Frame", {
				["Name"] = nil,
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["ZIndex"] = 3,
				["Parent"] = nil,
				["Name"] = p124,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Size"] = UDim2.fromOffset(0, 3),
				["BackgroundColor3"] = v_u_9,
				["Parent"] = v_u_119
			})
			v_u_18.new("UIGradient", {
				["Transparency"] = v_u_114(0.2),
				["Parent"] = v125
			})
			return v125
		end
		local v127 = v126("EdgeTop")
		local v128 = v126("EdgeBottom")
		local v129 = v_u_18.new("ImageLabel", {
			["Name"] = "Flare",
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Image"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 1,
			["ScaleType"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Size"] = UDim2.fromOffset(900, 96),
			["Image"] = v_u_22.Flare or "",
			["ImageColor3"] = v_u_9,
			["ScaleType"] = Enum.ScaleType.Stretch,
			["Parent"] = v_u_119
		})
		local v130 = v_u_18.new("ImageLabel", {
			["Name"] = "Ring",
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Image"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 1,
			["ZIndex"] = 1,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Size"] = UDim2.fromOffset(100, 100),
			["Image"] = v_u_22.Ring or "",
			["ImageColor3"] = v_u_9,
			["Parent"] = v_u_119
		})
		local v131, v132 = v_u_112(v_u_119, "Aura", 4)
		v131.TextColor3 = v_u_10
		local v133, v134 = v_u_112(v_u_119, "Shadow", 4)
		v133.TextColor3 = v_u_21.Void
		local v135, v136 = v_u_112(v_u_119, "Headline", 5)
		v_u_18.new("UIGradient", {
			["Rotation"] = 90,
			["Color"] = nil,
			["Parent"] = nil,
			["Color"] = ColorSequence.new(v_u_12, v_u_9),
			["Parent"] = v135
		})
		local v137 = v_u_18.TextStroke(v_u_13, 2, 0.35)
		v137.Parent = v135
		v_u_38[v135] = {
			["stroke"] = nil,
			["base"] = 0.35,
			["stroke"] = v137
		}
		local v138, v139 = v_u_112(v_u_119, "Sweep", 6)
		v138.TextColor3 = v_u_12
		local v140 = v_u_18.new("UIGradient", {
			["Rotation"] = 18,
			["Transparency"] = nil,
			["Offset"] = nil,
			["Parent"] = nil,
			["Transparency"] = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.44, 1),
				NumberSequenceKeypoint.new(0.5, 0.1),
				NumberSequenceKeypoint.new(0.56, 1),
				NumberSequenceKeypoint.new(1, 1)
			}),
			["Offset"] = Vector2.new(-1, 0),
			["Parent"] = v138
		})
		local v_u_141 = v_u_18.new("Frame", {
			["Name"] = "Row",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(0, 132),
			["Size"] = UDim2.fromOffset(0, 0),
			["Parent"] = v_u_119
		})
		local v142 = {}
		for v143 = 1, 2 do
			local v144
			if v143 == 1 then
				v144 = v_u_21.Ally
			else
				v144 = v_u_21.Enemy
			end
			local v145 = v_u_18.new("Frame", {
				["Name"] = v143 == 1 and "Mine" or "Theirs",
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(v143 == 1 and -156 or 156, 0),
				["Size"] = UDim2.fromOffset(92, 84),
				["BackgroundColor3"] = Color3.new(1, 1, 1),
				["BackgroundTransparency"] = 0.05,
				["ZIndex"] = 6,
				v_u_18.Corner(14),
				v_u_18.Gradient(v_u_19.Lighten(v144, 0.1), v_u_19.Darken(v144, 0.35), 90),
				v_u_18.Stroke(v_u_19.Lighten(v144, 0.4), 2.5, 0.25),
				["Parent"] = v_u_141
			})
			local v146 = v_u_18.new("UIScale", {
				["Parent"] = v145
			})
			v142[v143] = {
				["box"] = v145,
				["digit"] = v_u_18.DisplayText({
					["Name"] = "Score",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "2",
					["TextSize"] = 62,
					["TextColor3"] = nil,
					["StrokeThickness"] = 2.5,
					["StrokeColor"] = nil,
					["ZIndex"] = 7,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Size"] = UDim2.fromScale(1, 1),
					["TextColor3"] = v_u_21.Text,
					["StrokeColor"] = v_u_19.Darken(v144, 0.7),
					["Parent"] = v145
				}),
				["scale"] = v146
			}
		end
		local v147 = v_u_18.new("Frame", {
			["Name"] = "Dash",
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Size"] = UDim2.fromOffset(36, 6),
			["BackgroundColor3"] = v_u_9,
			["ZIndex"] = 6,
			v_u_18.Corner(3),
			["Parent"] = v_u_141
		})
		local v148 = v_u_18.new("ImageLabel", {
			["Name"] = "DigitRing",
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Image"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 1,
			["ZIndex"] = 5,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Size"] = UDim2.fromOffset(90, 90),
			["Image"] = v_u_22.Ring or "",
			["ImageColor3"] = v_u_9,
			["Parent"] = v_u_141
		})
		local function v152(p149, p150) -- name: digitLabel
			-- upvalues: (ref) v_u_18, (ref) v_u_7, (ref) v_u_21, (copy) v_u_141
			local v151 = v_u_18.new("TextLabel", {
				["Name"] = nil,
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 100,
				["TextColor3"] = nil,
				["TextTransparency"] = 1,
				["ZIndex"] = nil,
				["Parent"] = nil,
				["Name"] = p149,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Size"] = UDim2.fromOffset(180, 150),
				["FontFace"] = v_u_7,
				["TextColor3"] = v_u_21.Text,
				["ZIndex"] = p150,
				["Parent"] = v_u_141
			})
			return v151, v_u_18.new("UIScale", {
				["Parent"] = v151
			})
		end
		local v153, v154 = v152("DigitGhost", 6)
		local v155, v156 = v152("Digit", 7)
		local v157 = v_u_18.new("UIGradient", {
			["Rotation"] = 90,
			["Color"] = nil,
			["Parent"] = nil,
			["Color"] = ColorSequence.new(v_u_12, v_u_9),
			["Parent"] = v155
		})
		local v158 = v_u_18.TextStroke(v_u_13, 2.5, 0.2)
		v158.Parent = v155
		v_u_38[v155] = {
			["stroke"] = nil,
			["base"] = 0.2,
			["stroke"] = v158
		}
		v_u_18.new("UIGradient", {
			["Rotation"] = 90,
			["Color"] = nil,
			["Parent"] = nil,
			["Color"] = ColorSequence.new(v_u_12, v_u_10),
			["Parent"] = v153
		})
		local v159, v160 = v_u_112(v_u_119, "FightShadow", 4)
		v159.TextColor3 = v_u_21.Void
		v159.Text = "FIGHT!"
		local v161, v162 = v_u_112(v_u_119, "Fight", 5)
		v161.Text = "FIGHT!"
		v_u_18.new("UIGradient", {
			["Rotation"] = 90,
			["Color"] = nil,
			["Parent"] = nil,
			["Color"] = ColorSequence.new(v_u_12, v_u_10),
			["Parent"] = v161
		})
		local v163 = v_u_18.TextStroke(v_u_13, 2, 0.3)
		v163.Parent = v161
		v_u_38[v161] = {
			["stroke"] = nil,
			["base"] = 0.3,
			["stroke"] = v163
		}
		local v164 = v_u_18.new("Frame", {
			["Name"] = "Particles",
			["Size"] = nil,
			["ZIndex"] = 7,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(0, 0),
			["Parent"] = v_u_119
		})
		return {
			["root"] = v115,
			["dim"] = v116,
			["stage"] = v117,
			["stageScale"] = v118,
			["shaker"] = v_u_119,
			["glow"] = v120,
			["ring"] = v130,
			["band"] = v122,
			["bandGrad"] = v123,
			["ghost"] = v121,
			["edgeTop"] = v127,
			["edgeBottom"] = v128,
			["flare"] = v129,
			["head"] = v135,
			["headScale"] = v136,
			["shadow"] = v133,
			["shadowScale"] = v134,
			["aura"] = v131,
			["auraScale"] = v132,
			["sweep"] = v138,
			["sweepScale"] = v139,
			["sweepGrad"] = v140,
			["row"] = v_u_141,
			["boxes"] = v142,
			["digit"] = v155,
			["digitScale"] = v156,
			["digitGrad"] = v157,
			["digitGhost"] = v153,
			["ghostScale"] = v154,
			["digitRing"] = v148,
			["dash"] = v147,
			["fight"] = v161,
			["fightScale"] = v162,
			["fightShadow"] = v159,
			["fightShadowScale"] = v160,
			["pool"] = require(script.Parent.Parent.Fx).Pool(v164, 110, 7)
		}
	end
	local v_u_166 = 0
	local v_u_167 = 0
	local v_u_168 = nil
	local v_u_169 = nil
	local v_u_170 = 0
	local v_u_171 = nil
	local v_u_172 = Random.new()
	local function v_u_180(p173, p174, p175, p176, p177, p178) -- name: burst
		-- upvalues: (ref) v_u_29, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12
		local v179 = p178 or {}
		p173.pool.Pace = v_u_29
		p173.pool:Burst(p174, {
			["mode"] = "box",
			["at"] = nil,
			["box"] = nil,
			["speed"] = nil,
			["colors"] = nil,
			["white"] = nil,
			["whiteChance"] = 0.3,
			["sparkChance"] = nil,
			["grav"] = nil,
			["drag"] = nil,
			["lifeMult"] = nil,
			["at"] = p175,
			["box"] = p176,
			["speed"] = p177,
			["colors"] = v179.colors or { v_u_9, v_u_10, v_u_11 },
			["white"] = v_u_12,
			["sparkChance"] = v179.sparkChance or 0.6,
			["grav"] = v179.grav,
			["drag"] = v179.drag,
			["lifeMult"] = v179.lifeMult
		})
	end
	local v_u_181 = {}
	local function v_u_194(p182) -- name: cancelCard
		-- upvalues: (ref) v_u_107, (ref) v_u_64, (ref) v_u_168, (ref) v_u_169, (ref) v_u_166, (ref) v_u_171, (copy) v_u_50, (ref) v_u_5, (ref) v_u_29
		local v_u_183 = v_u_107
		local v184 = v_u_64
		v_u_64 = false
		v_u_168 = nil
		v_u_169 = nil
		v_u_166 = v_u_166 + 1
		local v_u_185 = v_u_166
		if v_u_183 and v_u_183.root.Visible then
			if p182 or not v184 then
				if v_u_171 then
					v_u_171()
					v_u_171 = nil
				end
				v_u_183.pool:Clear()
				v_u_183.root.Visible = false
				v_u_183.shaker.Position = UDim2.new()
				return
			end
			if v_u_171 then
				v_u_171()
				v_u_171 = nil
			end
			for _, v186 in {
				v_u_183.head,
				v_u_183.shadow,
				v_u_183.sweep,
				v_u_183.aura,
				v_u_183.digit,
				v_u_183.digitGhost,
				v_u_183.fight,
				v_u_183.fightShadow
			} do
				v_u_50(v186, 0.15, 1, Enum.EasingStyle.Quad)
			end
			for _, v187 in {
				v_u_183.band,
				v_u_183.ghost,
				v_u_183.flare,
				v_u_183.glow,
				v_u_183.ring,
				v_u_183.digitRing
			} do
				local v188 = Enum.EasingStyle.Quad
				v_u_5:Create(v187, TweenInfo.new(v_u_29 * 0.15, v188 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
					["ImageTransparency"] = 1
				}):Play()
			end
			for _, v189 in v_u_183.boxes do
				v189.box.Visible = false
			end
			v_u_183.dash.Visible = false
			local v190 = v_u_183.dim
			local v191 = Enum.EasingStyle.Quad
			v_u_5:Create(v190, TweenInfo.new(v_u_29 * 0.2, v191 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
				["BackgroundTransparency"] = 1
			}):Play()
			local function v193()
				-- upvalues: (copy) v_u_185, (ref) v_u_166, (copy) v_u_183, (ref) v_u_171
				if v_u_185 == v_u_166 then
					local v192 = v_u_183
					if v_u_171 then
						v_u_171()
						v_u_171 = nil
					end
					v192.pool:Clear()
					v192.root.Visible = false
					v192.shaker.Position = UDim2.new()
				end
			end
			task.delay(v_u_29 * 0.22, v193)
		end
	end
	function v_u_181.Stop(p195) -- name: Stop
		-- upvalues: (copy) v_u_194, (copy) v_u_104, (copy) v_u_106
		v_u_194(p195)
		v_u_104((v_u_106()))
	end
	function v_u_181.Intro(_) -- name: Intro
		-- upvalues: (ref) v_u_107, (copy) v_u_165, (ref) v_u_64, (ref) v_u_168, (ref) v_u_169, (ref) v_u_166, (ref) v_u_171, (ref) v_u_170, (copy) v_u_104, (copy) v_u_106, (copy) v_u_18, (ref) v_u_5, (ref) v_u_29, (ref) v_u_70, (ref) v_u_71, (ref) v_u_65, (ref) v_u_72, (ref) v_u_4, (ref) v_u_68, (ref) v_u_69, (copy) v_u_63, (copy) p_u_17, (ref) v_u_10, (ref) v_u_9, (ref) v_u_11, (ref) v_u_12, (copy) v_u_38, (copy) v_u_50, (copy) v_u_20, (copy) v_u_172, (copy) v_u_180, (ref) v_u_27, (ref) v_u_167, (copy) v_u_181
		local v_u_196 = v_u_107 or v_u_165()
		v_u_107 = v_u_196
		local v197 = v_u_107
		v_u_64 = false
		v_u_168 = nil
		v_u_169 = nil
		v_u_166 = v_u_166 + 1
		if v197 and v197.root.Visible then
			if v_u_171 then
				v_u_171()
				v_u_171 = nil
			end
			v197.pool:Clear()
			v197.root.Visible = false
			v197.shaker.Position = UDim2.new()
		end
		v_u_166 = v_u_166 + 1
		local v_u_198 = v_u_166
		v_u_64 = true
		v_u_170 = 0
		v_u_104((v_u_106()))
		local v199 = v_u_18.Compact
		v_u_196.stageScale.Scale = v199 and 0.68 or 1
		v_u_196.stage.Position = UDim2.fromScale(0.5, v199 and 0.235 or 0.265)
		v_u_196.shaker.Position = UDim2.new()
		v_u_196.root.Visible = true
		v_u_196.dim.BackgroundTransparency = 1
		v_u_5:Create(v_u_196.dim, TweenInfo.new(v_u_29 * 0.35, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
			["BackgroundTransparency"] = 0.72
		}):Play()
		v_u_70 = os.clock()
		v_u_71 = 0.28
		if v_u_65 ~= "off" and not v_u_72 then
			v_u_72 = v_u_4.RenderStepped:Connect(function(p200)
				-- upvalues: (ref) v_u_68, (ref) v_u_69, (ref) v_u_70, (ref) v_u_71, (ref) v_u_65, (ref) v_u_63, (ref) v_u_72
				local v201 = v_u_68
				local v202 = v_u_69 - v_u_68
				local v203 = -p200 * 3
				v_u_68 = v201 + v202 * (1 - math.exp(v203))
				local v204 = os.clock()
				local v205 = v204 - v_u_70
				local v206
				if v205 < 1 then
					local v207 = v_u_71
					local v208
					if v205 < 0 then
						v208 = 0
					elseif v205 < 0.06 then
						v208 = v205 / 0.06
					else
						local v209 = -(v205 - 0.06) / 0.14
						v208 = math.exp(v209)
					end
					local v210 = v207 * v208
					local v211 = v_u_71 * 0.6
					local v212 = v205 - 0.27
					local v213
					if v212 < 0 then
						v213 = 0
					elseif v212 < 0.06 then
						v213 = v212 / 0.06
					else
						local v214 = -(v212 - 0.06) / 0.14
						v213 = math.exp(v214)
					end
					v206 = v210 + v211 * v213
				else
					v206 = 0
				end
				local v215
				if v_u_65 == "live" then
					local v216 = v204 * 2.4
					v215 = math.sin(v216) * 0.03
				else
					v215 = 0
				end
				local v217 = v_u_63
				local v218 = v_u_68 - v206 + v215
				local v219 = v_u_68
				local v220 = math.min(v219, 0.14)
				v217.ImageTransparency = math.clamp(v218, v220, 1)
				if v_u_65 == "off" and (v_u_68 > 0.995 and v205 > 1) then
					v_u_63.ImageTransparency = 1
					v_u_63.Visible = false
					if v_u_72 then
						v_u_72:Disconnect()
						v_u_72 = nil
					end
				end
			end)
		end
		v_u_196.band.AnchorPoint = Vector2.new(0, 0.5)
		v_u_196.band.Position = UDim2.fromOffset(-750, 0)
		v_u_196.band.Size = UDim2.fromOffset(0, 124)
		v_u_196.band.ImageTransparency = 0.06
		local v221 = v_u_196.band
		local v222 = {
			["Size"] = UDim2.fromOffset(1500, 124)
		}
		v_u_5:Create(v221, TweenInfo.new(v_u_29 * 0.32, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), v222):Play()
		v_u_196.ghost.Size = UDim2.fromOffset(900, 198.4)
		v_u_196.ghost.ImageTransparency = 1
		local v223 = v_u_196.ghost
		local v224 = {
			["Size"] = nil,
			["ImageTransparency"] = 0.5,
			["Size"] = UDim2.fromOffset(1724.9999999999998, 198.4)
		}
		v_u_5:Create(v223, TweenInfo.new(v_u_29 * 0.7, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), v224):Play()
		for v225, v226 in { v_u_196.edgeTop, v_u_196.edgeBottom } do
			v226.Position = UDim2.fromOffset(v225 == 1 and -450 or 450, v225 == 1 and -64 or 64)
			v226.Size = UDim2.fromOffset(0, 3)
			v226.BackgroundTransparency = 0
			local v227 = {
				["Size"] = UDim2.fromOffset(1170, 3),
				["Position"] = UDim2.fromOffset(0, v226.Position.Y.Offset)
			}
			local v228 = Enum.EasingStyle.Quint
			local v229 = Enum.EasingDirection.Out
			v_u_5:Create(v226, TweenInfo.new(v_u_29 * 0.45, v228 or Enum.EasingStyle.Quint, v229 or Enum.EasingDirection.Out, 0, false, 0.08 * v_u_29), v227):Play()
		end
		p_u_17.Sounds.Play("Whoosh", {
			["volume"] = 0.35,
			["pitch"] = 0.8
		})
		v_u_196.pool.Pace = v_u_29
		v_u_171 = v_u_196.pool:Emit(16, {
			["mode"] = "box",
			["at"] = nil,
			["box"] = nil,
			["kind"] = "sparkle",
			["size"] = 11,
			["speedMin"] = 20,
			["speedMax"] = 70,
			["grav"] = -170,
			["drag"] = 0.6,
			["lifeMin"] = 1.3,
			["lifeMax"] = 2.2,
			["colors"] = nil,
			["white"] = nil,
			["whiteChance"] = 0.12,
			["base"] = 0.15,
			["at"] = Vector2.new(0, 150),
			["box"] = Vector2.new(1300, 60),
			["colors"] = { v_u_10, v_u_9, v_u_11 },
			["white"] = v_u_12
		})
		for _, v230 in {
			v_u_196.head,
			v_u_196.shadow,
			v_u_196.sweep,
			v_u_196.aura
		} do
			v230.TextTransparency = 1
			local v231 = v_u_38[v230]
			if v231 then
				local v232 = v231.stroke
				local _ = v_u_38[v230]
				v232.Transparency = 1
			end
			v230.Position = UDim2.fromOffset(0, 0)
		end
		for _, v233 in { v_u_196.fight, v_u_196.fightShadow } do
			v233.TextTransparency = 1
			local v234 = v_u_38[v233]
			if not v234 then
				continue
			end
			local v235 = v234.stroke
			local _ = v_u_38[v233]
			v235.Transparency = 1
		end
		v_u_196.shadow.Position = UDim2.fromOffset(0, 7)
		v_u_196.sweepGrad.Offset = Vector2.new(-1, 0)
		for _, v236 in { v_u_196.headScale, v_u_196.shadowScale, v_u_196.sweepScale } do
			v236.Scale = 2.432
			local v237 = Enum.EasingStyle.Back
			local v238 = Enum.EasingDirection.Out
			v_u_5:Create(v236, TweenInfo.new(v_u_29 * 0.26, v237 or Enum.EasingStyle.Quint, v238 or Enum.EasingDirection.Out, 0, false, 0.06 * v_u_29), {
				["Scale"] = 1.28
			}):Play()
		end
		v_u_196.auraScale.Scale = 1.28
		v_u_50(v_u_196.head, 0.1, 0, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0.06)
		local v239 = v_u_196.shadow
		local v240 = Enum.EasingStyle.Quad
		local v241 = Enum.EasingDirection.Out
		v_u_5:Create(v239, TweenInfo.new(v_u_29 * 0.2, v240 or Enum.EasingStyle.Quint, v241 or Enum.EasingDirection.Out, 0, false, 0.06 * v_u_29), {
			["TextTransparency"] = 0.5
		}):Play()
		local v242 = v_u_20.Match
		local v243 = v_u_20.MyTeam()
		for v244, v245 in v_u_196.boxes do
			local v246 = v242 and v242.teams
			if v246 then
				local v247 = v242.teams
				local v248
				if v244 == 1 then
					v248 = v243
				else
					v248 = 3 - v243
				end
				v246 = v247[v248]
			end
			local v249 = v245.digit
			local v250 = v246 and v246.score or 1
			v249.Text = tostring(v250)
			v245.box.Visible = false
		end
		v_u_196.dash.Visible = false
		local v251 = v_u_196.digit
		v251.TextTransparency = 1
		local v252 = v_u_38[v251]
		if v252 then
			local v253 = v252.stroke
			local _ = v_u_38[v251]
			v253.Transparency = 1
		end
		local v254 = v_u_196.digitGhost
		v254.TextTransparency = 1
		local v255 = v_u_38[v254]
		if v255 then
			local v256 = v255.stroke
			local _ = v_u_38[v254]
			v256.Transparency = 1
		end
		v_u_196.digitRing.ImageTransparency = 1
		v_u_196.row.Position = UDim2.fromOffset(0, 156)
		local function v321()
			-- upvalues: (copy) v_u_198, (ref) v_u_166, (copy) v_u_196, (ref) v_u_5, (ref) v_u_29, (ref) v_u_172, (ref) v_u_4, (ref) v_u_180, (ref) v_u_9, (ref) v_u_70, (ref) v_u_71, (ref) v_u_65, (ref) v_u_72, (ref) v_u_68, (ref) v_u_69, (ref) v_u_63, (ref) v_u_27, (ref) v_u_169
			if v_u_198 == v_u_166 then
				for _, v257 in { v_u_196.headScale, v_u_196.shadowScale, v_u_196.sweepScale } do
					v257.Scale = 1.3824
					local v258 = Enum.EasingStyle.Back
					v_u_5:Create(v257, TweenInfo.new(v_u_29 * 0.24, v258 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
						["Scale"] = 1.28
					}):Play()
				end
				local v_u_259 = v_u_196
				local v_u_260 = v_u_166
				local v_u_261 = 0.32
				local v_u_262 = 11
				task.spawn(function()
					-- upvalues: (copy) v_u_261, (ref) v_u_29, (copy) v_u_260, (ref) v_u_166, (copy) v_u_259, (ref) v_u_172, (copy) v_u_262, (ref) v_u_4
					local v263 = os.clock()
					while os.clock() - v263 < v_u_261 * v_u_29 and v_u_260 == v_u_166 do
						local v264 = 1 - (os.clock() - v263) / (v_u_261 * v_u_29)
						v_u_259.shaker.Position = UDim2.fromOffset(v_u_172:NextNumber(-1, 1) * v_u_262 * v264, v_u_172:NextNumber(-1, 1) * v_u_262 * v264)
						v_u_4.RenderStepped:Wait()
					end
					if v_u_260 == v_u_166 then
						v_u_259.shaker.Position = UDim2.new()
					end
				end)
				v_u_196.aura.TextTransparency = 0.3
				v_u_196.auraScale.Scale = 1.3056
				local v265 = v_u_196.auraScale
				local v266 = Enum.EasingStyle.Quart
				v_u_5:Create(v265, TweenInfo.new(v_u_29 * 0.6, v266 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
					["Scale"] = 1.6640000000000001
				}):Play()
				local v267 = v_u_196.aura
				local v268 = Enum.EasingStyle.Quad
				v_u_5:Create(v267, TweenInfo.new(v_u_29 * 0.6, v268 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
					["TextTransparency"] = 1
				}):Play()
				v_u_180(v_u_196, 44, Vector2.zero, Vector2.new(605.44, 102.4), 1250)
				v_u_196.ring.ImageColor3 = v_u_9
				v_u_196.ring.Size = UDim2.fromOffset(120, 120)
				v_u_196.ring.ImageTransparency = 0.3
				local v269 = v_u_196.ring
				local v270 = {
					["Size"] = nil,
					["ImageTransparency"] = 1,
					["Size"] = UDim2.fromOffset(1500, 1500)
				}
				local v271 = Enum.EasingStyle.Quart
				v_u_5:Create(v269, TweenInfo.new(v_u_29 * 0.65, v271 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), v270):Play()
				v_u_196.glow.Size = UDim2.fromOffset(675, 210.79999999999998)
				v_u_196.glow.ImageTransparency = 0.4
				local v272 = v_u_196.glow
				local v273 = {
					["Size"] = nil,
					["ImageTransparency"] = 1,
					["Size"] = UDim2.fromOffset(1080, 322.40000000000003)
				}
				local v274 = Enum.EasingStyle.Quad
				v_u_5:Create(v272, TweenInfo.new(v_u_29 * 0.8, v274 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), v273):Play()
				v_u_196.flare.Position = UDim2.fromOffset(-930, 0)
				v_u_196.flare.ImageTransparency = 1
				local v275 = v_u_196.flare
				local v276 = {
					["Position"] = UDim2.fromOffset(930, 0)
				}
				local v277 = Enum.EasingStyle.Quad
				local v278 = Enum.EasingDirection.InOut
				v_u_5:Create(v275, TweenInfo.new(v_u_29 * 0.55, v277 or Enum.EasingStyle.Quint, v278 or Enum.EasingDirection.Out, 0, false, 0 * v_u_29), v276):Play()
				local v279 = v_u_196.flare
				local v280 = Enum.EasingStyle.Quad
				v_u_5:Create(v279, TweenInfo.new(v_u_29 * 0.12, v280 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
					["ImageTransparency"] = 0.12
				}):Play()
				local v281 = v_u_196.flare
				local v282 = Enum.EasingStyle.Quad
				local v283 = Enum.EasingDirection.In
				v_u_5:Create(v281, TweenInfo.new(v_u_29 * 0.2, v282 or Enum.EasingStyle.Quint, v283 or Enum.EasingDirection.Out, 0, false, 0.36 * v_u_29), {
					["ImageTransparency"] = 1
				}):Play()
				v_u_70 = os.clock()
				v_u_71 = 0.32
				if v_u_65 ~= "off" and not v_u_72 then
					v_u_72 = v_u_4.RenderStepped:Connect(function(p284)
						-- upvalues: (ref) v_u_68, (ref) v_u_69, (ref) v_u_70, (ref) v_u_71, (ref) v_u_65, (ref) v_u_63, (ref) v_u_72
						local v285 = v_u_68
						local v286 = v_u_69 - v_u_68
						local v287 = -p284 * 3
						v_u_68 = v285 + v286 * (1 - math.exp(v287))
						local v288 = os.clock()
						local v289 = v288 - v_u_70
						local v290
						if v289 < 1 then
							local v291 = v_u_71
							local v292
							if v289 < 0 then
								v292 = 0
							elseif v289 < 0.06 then
								v292 = v289 / 0.06
							else
								local v293 = -(v289 - 0.06) / 0.14
								v292 = math.exp(v293)
							end
							local v294 = v291 * v292
							local v295 = v_u_71 * 0.6
							local v296 = v289 - 0.27
							local v297
							if v296 < 0 then
								v297 = 0
							elseif v296 < 0.06 then
								v297 = v296 / 0.06
							else
								local v298 = -(v296 - 0.06) / 0.14
								v297 = math.exp(v298)
							end
							v290 = v294 + v295 * v297
						else
							v290 = 0
						end
						local v299
						if v_u_65 == "live" then
							local v300 = v288 * 2.4
							v299 = math.sin(v300) * 0.03
						else
							v299 = 0
						end
						local v301 = v_u_63
						local v302 = v_u_68 - v290 + v299
						local v303 = v_u_68
						local v304 = math.min(v303, 0.14)
						v301.ImageTransparency = math.clamp(v302, v304, 1)
						if v_u_65 == "off" and (v_u_68 > 0.995 and v289 > 1) then
							v_u_63.ImageTransparency = 1
							v_u_63.Visible = false
							if v_u_72 then
								v_u_72:Disconnect()
								v_u_72 = nil
							end
						end
					end)
				end
				if v_u_27 then
					local v305 = v_u_27.Play
					pcall(v305, "Match/Final_Round", nil, nil)
				end
				if v_u_27 and v_u_27.Duck then
					local v306 = v_u_27.Duck
					pcall(v306, "Music", 0.3, 2.4)
				end
				if v_u_27 and v_u_27.Duck then
					local v307 = v_u_27.Duck
					pcall(v307, "Ambient", 0.5, 2.4)
				end
				local v308 = v_u_196.row
				local v309 = {
					["Position"] = UDim2.fromOffset(0, 132)
				}
				local v310 = Enum.EasingStyle.Quint
				local v311 = Enum.EasingDirection.Out
				v_u_5:Create(v308, TweenInfo.new(v_u_29 * 0.34, v310 or Enum.EasingStyle.Quint, v311 or Enum.EasingDirection.Out, 0, false, 0.06 * v_u_29), v309):Play()
				for v312, v313 in v_u_196.boxes do
					v313.box.Visible = true
					v313.scale.Scale = 0.2
					local v314 = v313.scale
					local v315 = Enum.EasingStyle.Back
					local v316 = Enum.EasingDirection.Out
					local v317 = 0.06 + v312 * 0.05
					v_u_5:Create(v314, TweenInfo.new(v_u_29 * 0.34, v315 or Enum.EasingStyle.Quint, v316 or Enum.EasingDirection.Out, 0, false, (v317 or 0) * v_u_29), {
						["Scale"] = 1
					}):Play()
				end
				if v_u_169 == nil then
					v_u_196.dash.Visible = true
					v_u_196.dash.BackgroundTransparency = 1
					local v318 = v_u_196.dash
					local v319 = Enum.EasingStyle.Quad
					local v320 = Enum.EasingDirection.Out
					v_u_5:Create(v318, TweenInfo.new(v_u_29 * 0.25, v319 or Enum.EasingStyle.Quint, v320 or Enum.EasingDirection.Out, 0, false, 0.1 * v_u_29), {
						["BackgroundTransparency"] = 0.15
					}):Play()
				end
			end
		end
		task.delay(v_u_29 * 0.3, v321)
		local function v327()
			-- upvalues: (copy) v_u_198, (ref) v_u_166, (copy) v_u_196, (ref) v_u_5, (ref) v_u_29
			if v_u_198 == v_u_166 then
				v_u_196.sweep.TextTransparency = 0.15
				v_u_196.sweepGrad.Offset = Vector2.new(-1, 0)
				local v322 = v_u_196.sweepGrad
				local v323 = {
					["Offset"] = Vector2.new(1, 0)
				}
				local v324 = Enum.EasingStyle.Quad
				local v325 = Enum.EasingDirection.InOut
				v_u_5:Create(v322, TweenInfo.new(v_u_29 * 0.55, v324 or Enum.EasingStyle.Quint, v325 or Enum.EasingDirection.Out, 0, false, 0 * v_u_29), v323):Play()
				local function v326()
					-- upvalues: (ref) v_u_198, (ref) v_u_166, (ref) v_u_196
					if v_u_198 == v_u_166 then
						v_u_196.sweep.TextTransparency = 1
					end
				end
				task.delay(v_u_29 * 0.6, v326)
			end
		end
		task.delay(v_u_29 * 0.58, v327)
		v_u_167 = os.clock() + v_u_29 * 0.48
		local function v329()
			-- upvalues: (copy) v_u_198, (ref) v_u_166, (ref) v_u_168, (ref) v_u_181
			if v_u_198 == v_u_166 and v_u_168 then
				local v328 = v_u_168
				v_u_168 = nil
				v_u_181.Digit(v328)
			end
		end
		task.delay(v_u_29 * 0.48, v329)
	end
	function v_u_181.Digit(p330) -- name: Digit
		-- upvalues: (ref) v_u_107, (ref) v_u_64, (ref) v_u_167, (ref) v_u_168, (ref) v_u_169, (ref) v_u_170, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_5, (ref) v_u_29, (ref) v_u_12, (copy) v_u_38, (ref) v_u_166, (copy) v_u_172, (ref) v_u_4, (copy) v_u_180, (ref) v_u_70, (ref) v_u_71, (ref) v_u_65, (ref) v_u_72, (ref) v_u_68, (ref) v_u_69, (copy) v_u_63, (ref) v_u_27
		local v_u_331 = v_u_107
		if v_u_331 and v_u_64 then
			if os.clock() < v_u_167 then
				v_u_168 = p330
				return
			elseif p330 ~= v_u_169 then
				local v332 = v_u_169
				v_u_169 = p330
				v_u_170 = v_u_170 + 1
				local v333 = 4 - p330
				local v334 = math.clamp(v333, 1, 3)
				local v335
				if p330 >= 3 then
					v335 = v_u_9
				elseif p330 == 2 then
					v335 = v_u_10
				else
					v335 = v_u_11
				end
				v_u_331.dash.Visible = false
				if v332 then
					v_u_331.digitGhost.Text = tostring(v332)
					v_u_331.digitGhost.TextTransparency = 0.25
					v_u_331.ghostScale.Scale = 1.35
					local v336 = v_u_331.ghostScale
					local v337 = Enum.EasingStyle.Quad
					v_u_5:Create(v336, TweenInfo.new(v_u_29 * 0.3, v337 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
						["Scale"] = 2
					}):Play()
					local v338 = v_u_331.digitGhost
					local v339 = Enum.EasingStyle.Quad
					v_u_5:Create(v338, TweenInfo.new(v_u_29 * 0.3, v339 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
						["TextTransparency"] = 1
					}):Play()
				end
				v_u_331.digit.Text = tostring(p330)
				v_u_331.digitGrad.Color = ColorSequence.new(v_u_12, v335)
				local v340 = v_u_331.digit
				v340.TextTransparency = 0
				local v341 = v_u_38[v340]
				if v341 then
					local v342 = v341.stroke
					local v343 = v_u_38[v340]
					v342.Transparency = not v343 and 1 or v343.base + (1 - v343.base) * 0
				end
				v_u_331.digitScale.Scale = 2.4
				local v344 = v_u_331.digitScale
				local v345 = Enum.EasingStyle.Back
				v_u_5:Create(v344, TweenInfo.new(v_u_29 * 0.26, v345 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
					["Scale"] = 1.35
				}):Play()
				v_u_331.digitRing.ImageColor3 = v335
				v_u_331.digitRing.Size = UDim2.fromOffset(90, 90)
				v_u_331.digitRing.ImageTransparency = 0.3
				local v346 = v_u_331.digitRing
				local v347 = {
					["Size"] = nil,
					["ImageTransparency"] = 1,
					["Size"] = UDim2.fromOffset(480, 480)
				}
				local v348 = Enum.EasingStyle.Quart
				v_u_5:Create(v346, TweenInfo.new(v_u_29 * 0.6, v348 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), v347):Play()
				for _, v349 in v_u_331.boxes do
					v349.scale.Scale = 1.1
					local v350 = v349.scale
					local v351 = Enum.EasingStyle.Quad
					v_u_5:Create(v350, TweenInfo.new(v_u_29 * 0.22, v351 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
						["Scale"] = 1
					}):Play()
				end
				local v_u_352 = v_u_166
				local function v356()
					-- upvalues: (copy) v_u_352, (ref) v_u_166, (copy) v_u_331, (ref) v_u_5, (ref) v_u_29
					if v_u_352 == v_u_166 then
						for _, v353 in v_u_331.boxes do
							v353.scale.Scale = 1.05
							local v354 = v353.scale
							local v355 = Enum.EasingStyle.Quad
							v_u_5:Create(v354, TweenInfo.new(v_u_29 * 0.2, v355 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
								["Scale"] = 1
							}):Play()
						end
					end
				end
				task.delay(v_u_29 * 0.27, v356)
				local v_u_357 = v334 * 2 + 3
				local v_u_358 = v_u_166
				local v_u_359 = 0.2
				task.spawn(function()
					-- upvalues: (copy) v_u_359, (ref) v_u_29, (copy) v_u_358, (ref) v_u_166, (copy) v_u_331, (ref) v_u_172, (copy) v_u_357, (ref) v_u_4
					local v360 = os.clock()
					while os.clock() - v360 < v_u_359 * v_u_29 and v_u_358 == v_u_166 do
						local v361 = 1 - (os.clock() - v360) / (v_u_359 * v_u_29)
						v_u_331.shaker.Position = UDim2.fromOffset(v_u_172:NextNumber(-1, 1) * v_u_357 * v361, v_u_172:NextNumber(-1, 1) * v_u_357 * v361)
						v_u_4.RenderStepped:Wait()
					end
					if v_u_358 == v_u_166 then
						v_u_331.shaker.Position = UDim2.new()
					end
				end)
				local v362 = {
					["sparkChance"] = 0.8,
					["colors"] = nil,
					["colors"] = { v335, v_u_10 }
				}
				v_u_180(v_u_331, v334 * 4 + 8, Vector2.new(0, 132), Vector2.new(90, 110), 700, v362)
				local v363 = v334 * 0.05 + 0.16
				v_u_70 = os.clock()
				v_u_71 = v363
				if v_u_65 ~= "off" and not v_u_72 then
					v_u_72 = v_u_4.RenderStepped:Connect(function(p364)
						-- upvalues: (ref) v_u_68, (ref) v_u_69, (ref) v_u_70, (ref) v_u_71, (ref) v_u_65, (ref) v_u_63, (ref) v_u_72
						local v365 = v_u_68
						local v366 = v_u_69 - v_u_68
						local v367 = -p364 * 3
						v_u_68 = v365 + v366 * (1 - math.exp(v367))
						local v368 = os.clock()
						local v369 = v368 - v_u_70
						local v370
						if v369 < 1 then
							local v371 = v_u_71
							local v372
							if v369 < 0 then
								v372 = 0
							elseif v369 < 0.06 then
								v372 = v369 / 0.06
							else
								local v373 = -(v369 - 0.06) / 0.14
								v372 = math.exp(v373)
							end
							local v374 = v371 * v372
							local v375 = v_u_71 * 0.6
							local v376 = v369 - 0.27
							local v377
							if v376 < 0 then
								v377 = 0
							elseif v376 < 0.06 then
								v377 = v376 / 0.06
							else
								local v378 = -(v376 - 0.06) / 0.14
								v377 = math.exp(v378)
							end
							v370 = v374 + v375 * v377
						else
							v370 = 0
						end
						local v379
						if v_u_65 == "live" then
							local v380 = v368 * 2.4
							v379 = math.sin(v380) * 0.03
						else
							v379 = 0
						end
						local v381 = v_u_63
						local v382 = v_u_68 - v370 + v379
						local v383 = v_u_68
						local v384 = math.min(v383, 0.14)
						v381.ImageTransparency = math.clamp(v382, v384, 1)
						if v_u_65 == "off" and (v_u_68 > 0.995 and v369 > 1) then
							v_u_63.ImageTransparency = 1
							v_u_63.Visible = false
							if v_u_72 then
								v_u_72:Disconnect()
								v_u_72 = nil
							end
						end
					end)
				end
				if v_u_27 then
					local v385 = v_u_27.Play
					pcall(v385, "Match/Final_Heartbeat", nil, nil)
				end
			end
		else
			return
		end
	end
	function v_u_181.Fight() -- name: Fight
		-- upvalues: (ref) v_u_107, (ref) v_u_64, (ref) v_u_166, (ref) v_u_168, (ref) v_u_169, (ref) v_u_171, (copy) v_u_104, (copy) v_u_106, (ref) v_u_5, (ref) v_u_29, (copy) v_u_50, (copy) v_u_38, (copy) v_u_172, (ref) v_u_4, (copy) v_u_180, (ref) v_u_10, (ref) v_u_70, (ref) v_u_71, (ref) v_u_65, (ref) v_u_72, (ref) v_u_68, (ref) v_u_69, (copy) v_u_63
		local v_u_386 = v_u_107
		if v_u_386 and v_u_64 then
			v_u_166 = v_u_166 + 1
			local v_u_387 = v_u_166
			v_u_64 = false
			v_u_168 = nil
			v_u_169 = nil
			if v_u_171 then
				v_u_171()
				v_u_171 = nil
			end
			v_u_104((v_u_106()))
			v_u_386.band.AnchorPoint = Vector2.new(1, 0.5)
			v_u_386.band.Position = UDim2.fromOffset(750, 0)
			local v388 = v_u_386.band
			local v389 = {
				["Size"] = nil,
				["ImageTransparency"] = 0.6,
				["Size"] = UDim2.fromOffset(0, 124)
			}
			local v390 = Enum.EasingStyle.Quint
			local v391 = Enum.EasingDirection.In
			v_u_5:Create(v388, TweenInfo.new(v_u_29 * 0.26, v390 or Enum.EasingStyle.Quint, v391 or Enum.EasingDirection.Out, 0, false, 0 * v_u_29), v389):Play()
			local v392 = v_u_386.ghost
			local v393 = Enum.EasingStyle.Quad
			v_u_5:Create(v392, TweenInfo.new(v_u_29 * 0.3, v393 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
				["ImageTransparency"] = 1
			}):Play()
			for _, v394 in { v_u_386.edgeTop, v_u_386.edgeBottom } do
				local v395 = Enum.EasingStyle.Quad
				v_u_5:Create(v394, TweenInfo.new(v_u_29 * 0.2, v395 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
					["BackgroundTransparency"] = 1
				}):Play()
			end
			for _, v396 in { v_u_386.head, v_u_386.shadow } do
				v_u_50(v396, 0.2, 1, Enum.EasingStyle.Quint, Enum.EasingDirection.In)
				local v397 = {
					["Position"] = v396.Position - UDim2.fromOffset(0, 26)
				}
				local v398 = Enum.EasingStyle.Quint
				local v399 = Enum.EasingDirection.In
				v_u_5:Create(v396, TweenInfo.new(v_u_29 * 0.2, v398 or Enum.EasingStyle.Quint, v399 or Enum.EasingDirection.Out, 0, false, 0 * v_u_29), v397):Play()
			end
			local v400 = v_u_386.sweep
			v400.TextTransparency = 1
			local v401 = v_u_38[v400]
			if v401 then
				local v402 = v401.stroke
				local _ = v_u_38[v400]
				v402.Transparency = 1
			end
			local v403 = v_u_386.row
			local v404 = {
				["Position"] = UDim2.fromOffset(0, 172)
			}
			local v405 = Enum.EasingStyle.Quint
			local v406 = Enum.EasingDirection.In
			v_u_5:Create(v403, TweenInfo.new(v_u_29 * 0.25, v405 or Enum.EasingStyle.Quint, v406 or Enum.EasingDirection.Out, 0, false, 0 * v_u_29), v404):Play()
			for _, v407 in v_u_386.boxes do
				local v408 = v407.scale
				local v409 = Enum.EasingStyle.Quint
				local v410 = Enum.EasingDirection.In
				v_u_5:Create(v408, TweenInfo.new(v_u_29 * 0.22, v409 or Enum.EasingStyle.Quint, v410 or Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
					["Scale"] = 0
				}):Play()
			end
			v_u_50(v_u_386.digit, 0.15, 1, Enum.EasingStyle.Quad)
			v_u_386.dash.Visible = false
			local v411 = v_u_386.dim
			local v412 = Enum.EasingStyle.Quad
			v_u_5:Create(v411, TweenInfo.new(v_u_29 * 0.35, v412 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), {
				["BackgroundTransparency"] = 1
			}):Play()
			v_u_386.fight.Position = UDim2.fromOffset(0, 10)
			v_u_386.fightShadow.Position = UDim2.fromOffset(0, 17)
			v_u_386.fightScale.Scale = 2.52
			v_u_386.fightShadowScale.Scale = 2.52
			local v413 = v_u_386.fightScale
			local v414 = Enum.EasingStyle.Back
			local v415 = Enum.EasingDirection.Out
			v_u_5:Create(v413, TweenInfo.new(v_u_29 * 0.24, v414 or Enum.EasingStyle.Quint, v415 or Enum.EasingDirection.Out, 0, false, 0.06 * v_u_29), {
				["Scale"] = 1.4
			}):Play()
			local v416 = v_u_386.fightShadowScale
			local v417 = Enum.EasingStyle.Back
			local v418 = Enum.EasingDirection.Out
			v_u_5:Create(v416, TweenInfo.new(v_u_29 * 0.24, v417 or Enum.EasingStyle.Quint, v418 or Enum.EasingDirection.Out, 0, false, 0.06 * v_u_29), {
				["Scale"] = 1.4
			}):Play()
			v_u_50(v_u_386.fight, 0.08, 0, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0.06)
			v_u_50(v_u_386.fightShadow, 0.15, 0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0.06)
			local function v449()
				-- upvalues: (copy) v_u_387, (ref) v_u_166, (copy) v_u_386, (ref) v_u_29, (ref) v_u_172, (ref) v_u_4, (ref) v_u_180, (ref) v_u_10, (ref) v_u_5, (ref) v_u_70, (ref) v_u_71, (ref) v_u_65, (ref) v_u_72, (ref) v_u_68, (ref) v_u_69, (ref) v_u_63
				if v_u_387 == v_u_166 then
					local v_u_419 = v_u_386
					local v_u_420 = v_u_166
					local v_u_421 = 0.28
					local v_u_422 = 9
					task.spawn(function()
						-- upvalues: (copy) v_u_421, (ref) v_u_29, (copy) v_u_420, (ref) v_u_166, (copy) v_u_419, (ref) v_u_172, (copy) v_u_422, (ref) v_u_4
						local v423 = os.clock()
						while os.clock() - v423 < v_u_421 * v_u_29 and v_u_420 == v_u_166 do
							local v424 = 1 - (os.clock() - v423) / (v_u_421 * v_u_29)
							v_u_419.shaker.Position = UDim2.fromOffset(v_u_172:NextNumber(-1, 1) * v_u_422 * v424, v_u_172:NextNumber(-1, 1) * v_u_422 * v424)
							v_u_4.RenderStepped:Wait()
						end
						if v_u_420 == v_u_166 then
							v_u_419.shaker.Position = UDim2.new()
						end
					end)
					v_u_180(v_u_386, 34, Vector2.new(0, 10), Vector2.new(361.2, 112), 1150)
					v_u_386.ring.ImageColor3 = v_u_10
					v_u_386.ring.Size = UDim2.fromOffset(120, 120)
					v_u_386.ring.ImageTransparency = 0.35
					local v425 = v_u_386.ring
					local v426 = {
						["Size"] = nil,
						["ImageTransparency"] = 1,
						["Size"] = UDim2.fromOffset(1300, 1300)
					}
					local v427 = Enum.EasingStyle.Quart
					v_u_5:Create(v425, TweenInfo.new(v_u_29 * 0.55, v427 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_29), v426):Play()
					v_u_70 = os.clock()
					v_u_71 = 0.2
					if v_u_65 ~= "off" then
						if v_u_72 then
							return
						end
						v_u_72 = v_u_4.RenderStepped:Connect(function(p428)
							-- upvalues: (ref) v_u_68, (ref) v_u_69, (ref) v_u_70, (ref) v_u_71, (ref) v_u_65, (ref) v_u_63, (ref) v_u_72
							local v429 = v_u_68
							local v430 = v_u_69 - v_u_68
							local v431 = -p428 * 3
							v_u_68 = v429 + v430 * (1 - math.exp(v431))
							local v432 = os.clock()
							local v433 = v432 - v_u_70
							local v434
							if v433 < 1 then
								local v435 = v_u_71
								local v436
								if v433 < 0 then
									v436 = 0
								elseif v433 < 0.06 then
									v436 = v433 / 0.06
								else
									local v437 = -(v433 - 0.06) / 0.14
									v436 = math.exp(v437)
								end
								local v438 = v435 * v436
								local v439 = v_u_71 * 0.6
								local v440 = v433 - 0.27
								local v441
								if v440 < 0 then
									v441 = 0
								elseif v440 < 0.06 then
									v441 = v440 / 0.06
								else
									local v442 = -(v440 - 0.06) / 0.14
									v441 = math.exp(v442)
								end
								v434 = v438 + v439 * v441
							else
								v434 = 0
							end
							local v443
							if v_u_65 == "live" then
								local v444 = v432 * 2.4
								v443 = math.sin(v444) * 0.03
							else
								v443 = 0
							end
							local v445 = v_u_63
							local v446 = v_u_68 - v434 + v443
							local v447 = v_u_68
							local v448 = math.min(v447, 0.14)
							v445.ImageTransparency = math.clamp(v446, v448, 1)
							if v_u_65 == "off" and (v_u_68 > 0.995 and v433 > 1) then
								v_u_63.ImageTransparency = 1
								v_u_63.Visible = false
								if v_u_72 then
									v_u_72:Disconnect()
									v_u_72 = nil
								end
							end
						end)
					end
				end
			end
			task.delay(v_u_29 * 0.26, v449)
			local function v456()
				-- upvalues: (copy) v_u_387, (ref) v_u_166, (copy) v_u_386, (ref) v_u_50, (ref) v_u_5, (ref) v_u_29, (ref) v_u_171
				if v_u_387 == v_u_166 then
					for _, v450 in { v_u_386.fight, v_u_386.fightShadow } do
						v_u_50(v450, 0.25, 1, Enum.EasingStyle.Quint, Enum.EasingDirection.In)
						local v451 = {
							["Position"] = v450.Position - UDim2.fromOffset(0, 18)
						}
						local v452 = Enum.EasingStyle.Quint
						local v453 = Enum.EasingDirection.In
						v_u_5:Create(v450, TweenInfo.new(v_u_29 * 0.25, v452 or Enum.EasingStyle.Quint, v453 or Enum.EasingDirection.Out, 0, false, 0 * v_u_29), v451):Play()
					end
					local function v455()
						-- upvalues: (ref) v_u_387, (ref) v_u_166, (ref) v_u_386, (ref) v_u_171
						if v_u_387 == v_u_166 then
							local v454 = v_u_386
							if v_u_171 then
								v_u_171()
								v_u_171 = nil
							end
							v454.pool:Clear()
							v454.root.Visible = false
							v454.shaker.Position = UDim2.new()
						end
					end
					task.delay(v_u_29 * 0.3, v455)
				end
			end
			task.delay(v_u_29 * 0.95, v456)
		end
	end
	v_u_181.IsDecider = v_u_58
	v_u_181.Active = v61
	function v_u_181.Showing() -- name: Showing
		-- upvalues: (ref) v_u_64
		return v_u_64
	end
	p_u_17.Decider = v_u_181
	p_u_17.OnMatchEvent(function(p457)
		-- upvalues: (copy) v_u_181, (ref) v_u_65, (ref) v_u_73, (copy) v_u_24, (ref) v_u_67, (ref) v_u_69, (ref) v_u_16, (ref) v_u_68, (ref) v_u_70, (copy) v_u_63, (ref) v_u_72, (ref) v_u_66
		if p457 == "RoundEnd" or (p457 == "MatchEnd" or (p457 == "MatchStart" or p457 == "PlayOfTheGame")) then
			v_u_181.Stop(p457 ~= "RoundEnd")
			if p457 == "MatchStart" then
				local _ = v_u_65 == "off"
				v_u_65 = "off"
				v_u_73 = v_u_73 + 1
				if v_u_24:GetAttribute("FinalRound") ~= nil then
					v_u_24:SetAttribute("FinalRound", nil)
				end
				if v_u_67 then
					v_u_67:Cancel()
					v_u_67 = nil
				end
				v_u_69 = v_u_16.off
				v_u_68 = v_u_69
				v_u_70 = (-1 / 0)
				v_u_63.ImageTransparency = 1
				v_u_63.Visible = false
				if v_u_72 then
					v_u_72:Disconnect()
					v_u_72 = nil
				end
				local v458 = v_u_66
				if not v458 then
					return
				end
				v458.Enabled = true
				v458:Destroy()
				v_u_66 = nil
			end
		end
	end)
	v_u_20.MatchChanged:Connect(function()
		-- upvalues: (copy) v_u_104, (copy) v_u_106
		v_u_104((v_u_106()))
	end)
	v_u_20.PlayerStateChanged:Connect(function(p459)
		-- upvalues: (copy) v_u_20, (copy) v_u_181, (ref) v_u_65, (ref) v_u_73, (copy) v_u_24, (ref) v_u_67, (ref) v_u_69, (ref) v_u_16, (ref) v_u_68, (ref) v_u_70, (copy) v_u_63, (ref) v_u_72, (ref) v_u_66
		if p459 ~= "Match" and not v_u_20.Watching() then
			v_u_181.Stop(true)
			local _ = v_u_65 == "off"
			v_u_65 = "off"
			v_u_73 = v_u_73 + 1
			if v_u_24:GetAttribute("FinalRound") ~= nil then
				v_u_24:SetAttribute("FinalRound", nil)
			end
			if v_u_67 then
				v_u_67:Cancel()
				v_u_67 = nil
			end
			v_u_69 = v_u_16.off
			v_u_68 = v_u_69
			v_u_70 = (-1 / 0)
			v_u_63.ImageTransparency = 1
			v_u_63.Visible = false
			if v_u_72 then
				v_u_72:Disconnect()
				v_u_72 = nil
			end
			local v460 = v_u_66
			if not v460 then
				return
			end
			v460.Enabled = true
			v460:Destroy()
			v_u_66 = nil
		end
	end)
	v_u_20.WatchChanged:Connect(function(p461)
		-- upvalues: (copy) v_u_20, (copy) v_u_181, (ref) v_u_65, (ref) v_u_73, (copy) v_u_24, (ref) v_u_67, (ref) v_u_69, (ref) v_u_16, (ref) v_u_68, (ref) v_u_70, (copy) v_u_63, (ref) v_u_72, (ref) v_u_66, (copy) v_u_104, (copy) v_u_106
		if not (p461 or v_u_20.InMatch()) then
			v_u_181.Stop(true)
			local _ = v_u_65 == "off"
			v_u_65 = "off"
			v_u_73 = v_u_73 + 1
			if v_u_24:GetAttribute("FinalRound") ~= nil then
				v_u_24:SetAttribute("FinalRound", nil)
			end
			if v_u_67 then
				v_u_67:Cancel()
				v_u_67 = nil
			end
			v_u_69 = v_u_16.off
			v_u_68 = v_u_69
			v_u_70 = (-1 / 0)
			v_u_63.ImageTransparency = 1
			v_u_63.Visible = false
			if v_u_72 then
				v_u_72:Disconnect()
				v_u_72 = nil
			end
			local v462 = v_u_66
			if v462 then
				v462.Enabled = true
				v462:Destroy()
				v_u_66 = nil
			end
		end
		v_u_104((v_u_106()))
	end)
	v_u_24:GetAttributeChangedSignal("ReplayPlaying"):Connect(function()
		-- upvalues: (copy) v_u_24, (copy) v_u_181, (ref) v_u_65, (ref) v_u_73, (ref) v_u_67, (ref) v_u_69, (ref) v_u_16, (ref) v_u_68, (ref) v_u_70, (copy) v_u_63, (ref) v_u_72, (ref) v_u_66, (copy) v_u_104, (copy) v_u_106
		if v_u_24:GetAttribute("ReplayPlaying") == true then
			v_u_181.Stop(true)
			local _ = v_u_65 == "off"
			v_u_65 = "off"
			v_u_73 = v_u_73 + 1
			if v_u_24:GetAttribute("FinalRound") ~= nil then
				v_u_24:SetAttribute("FinalRound", nil)
			end
			if v_u_67 then
				v_u_67:Cancel()
				v_u_67 = nil
			end
			v_u_69 = v_u_16.off
			v_u_68 = v_u_69
			v_u_70 = (-1 / 0)
			v_u_63.ImageTransparency = 1
			v_u_63.Visible = false
			if v_u_72 then
				v_u_72:Disconnect()
				v_u_72 = nil
			end
			local v463 = v_u_66
			if v463 then
				v463.Enabled = true
				v463:Destroy()
				v_u_66 = nil
			end
		else
			v_u_104((v_u_106()))
			return
		end
	end)
	v_u_104((v_u_106()))
	function p_u_17.Debug.finalRound(p464, p465)
		-- upvalues: (copy) v_u_181, (ref) v_u_29, (ref) v_u_65, (ref) v_u_64, (copy) v_u_20, (ref) v_u_14, (copy) v_u_58, (ref) v_u_66, (copy) v_u_63, (copy) v_u_24, (ref) v_u_107, (ref) v_u_166
		if p464 == "stop" then
			v_u_181.Stop(true)
			v_u_29 = 1
			return true
		end
		if p464 ~= "state" then
			v_u_29 = (type(p465) ~= "number" or p465 <= 0) and 1 or p465
			v_u_181.Intro(v_u_20.Match and v_u_20.Match.round or 5)
			local v_u_466 = v_u_166
			v_u_181.Digit(3)
			for v467, v_u_468 in { 2, 1 } do
				local function v469()
					-- upvalues: (ref) v_u_64, (ref) v_u_166, (ref) v_u_466, (ref) v_u_181, (copy) v_u_468
					if v_u_64 and v_u_166 == v_u_466 then
						v_u_181.Digit(v_u_468)
					end
				end
				task.delay(v467 * v_u_29, v469)
			end
			local function v470()
				-- upvalues: (ref) v_u_64, (ref) v_u_166, (ref) v_u_466, (ref) v_u_181
				if v_u_64 and v_u_166 == v_u_466 then
					v_u_181.Fight()
				end
			end
			task.delay(v_u_29 * 3, v470)
			local function v471()
				-- upvalues: (ref) v_u_29
				v_u_29 = 1
			end
			task.delay(v_u_29 * 4.4, v471)
			return true
		end
		local v472 = {
			["atmos"] = v_u_65,
			["cardUp"] = v_u_64
		}
		local v473 = v_u_20.Match
		local v474 = v_u_20.SeesMatch()
		if v474 then
			if type(v473) == "table" and v_u_14[v473.phase] == true then
				v474 = v_u_58(v473)
			else
				v474 = false
			end
		end
		v472.active = v474
		v472.decider = v_u_58()
		local v475
		if v_u_66 then
			v475 = string.format("B%.3f C%.3f S%.3f", v_u_66.Brightness, v_u_66.Contrast, v_u_66.Saturation)
		else
			v475 = false
		end
		v472.cc = v475
		local v476
		if v_u_63.Visible then
			local v477 = v_u_63.ImageTransparency * 100 + 0.5
			v476 = math.floor(v477) / 100
		else
			v476 = false
		end
		v472.vignette = v476
		v472.attr = v_u_24:GetAttribute("FinalRound") == true
		local v478
		if v_u_107 == nil then
			v478 = false
		else
			v478 = v_u_107.root.Visible
		end
		v472.cardVisible = v478
		return v472
	end
end
return v6