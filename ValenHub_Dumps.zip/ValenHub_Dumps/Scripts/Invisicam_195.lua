local v_u_1 = game:GetService("Players")
local v_u_2 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil").getUserFlag("UserRaycastUpdateAPI2")
local v_u_3 = {
	["LIMBS"] = 2,
	["MOVEMENT"] = 3,
	["CORNERS"] = 4,
	["CIRCLE1"] = 5,
	["CIRCLE2"] = 6,
	["LIMBMOVE"] = 7,
	["SMART_CIRCLE"] = 8,
	["CHAR_OUTLINE"] = 9
}
local v_u_4 = {
	["Head"] = true,
	["Left Arm"] = true,
	["Right Arm"] = true,
	["Left Leg"] = true,
	["Right Leg"] = true,
	["LeftLowerArm"] = true,
	["RightLowerArm"] = true,
	["LeftUpperLeg"] = true,
	["RightUpperLeg"] = true
}
local v_u_5 = {
	Vector3.new(1, 1, -1),
	Vector3.new(1, -1, -1),
	Vector3.new(-1, -1, -1),
	Vector3.new(-1, 1, -1)
}
local v_u_6 = RaycastParams.new()
v_u_6.FilterType = Enum.RaycastFilterType.Exclude
local v_u_7 = RaycastParams.new()
v_u_7.FilterType = Enum.RaycastFilterType.Include
local function v_u_15(p8, ...) -- name: AssertTypes
	local v9 = {}
	local v10 = ""
	for _, v11 in pairs({ ... }) do
		v9[v11] = true
		v10 = v10 .. (v10 == "" and "" or " or ") .. v11
	end
	local v12 = type(p8)
	local v13 = v9[v12]
	local v14 = v10 .. " type expected, got: " .. v12
	assert(v13, v14)
end
local function v_u_51(p16, p17, p18, p19) -- name: RayIntersection
	local v20 = p17:Cross(p19)
	local v21 = p18.X - p16.X
	local v22 = p18.Y - p16.Y
	local v23 = p18.Z - p16.Z
	local v24 = p17.X
	local v25 = -p19.X
	local v26 = v20.X
	local v27 = p17.Y
	local v28 = -p19.Y
	local v29 = v20.Y
	local v30 = p17.Z
	local v31 = -p19.Z
	local v32 = v20.Z
	local v33 = v24 * (v28 * v32 - v29 * v31) - v25 * (v27 * v32 - v29 * v30) + v26 * (v27 * v31 - v28 * v30)
	if v33 == 0 then
		return Vector3.new(0, 0, 0)
	end
	local v34 = -p19.X
	local v35 = v20.X
	local v36 = -p19.Y
	local v37 = v20.Y
	local v38 = -p19.Z
	local v39 = v20.Z
	local v40 = (v21 * (v36 * v39 - v37 * v38) - v34 * (v22 * v39 - v37 * v23) + v35 * (v22 * v38 - v36 * v23)) / v33
	local v41 = p17.X
	local v42 = v20.X
	local v43 = p17.Y
	local v44 = v20.Y
	local v45 = p17.Z
	local v46 = v20.Z
	local v47 = (v41 * (v22 * v46 - v44 * v23) - v21 * (v43 * v46 - v44 * v45) + v42 * (v43 * v23 - v22 * v45)) / v33
	local v48 = p16 + v40 * p17
	local v49 = p18 + v47 * p19
	local v50 = v48 + (v49 - v48) * 0.5
	return (v49 - v48).Magnitude >= 0.25 and Vector3.new(0, 0, 0) or v50
end
local v_u_52 = require(script.Parent:WaitForChild("BaseOcclusion"))
local v_u_53 = setmetatable({}, v_u_52)
v_u_53.__index = v_u_53
function v_u_53.new() -- name: new
	-- upvalues: (copy) v_u_52, (copy) v_u_53, (copy) v_u_3
	local v54 = v_u_52.new()
	local v55 = v_u_53
	local v56 = setmetatable(v54, v55)
	v56.char = nil
	v56.humanoidRootPart = nil
	v56.torsoPart = nil
	v56.headPart = nil
	v56.childAddedConn = nil
	v56.childRemovedConn = nil
	v56.behaviors = {}
	v56.behaviors[v_u_3.LIMBS] = v56.LimbBehavior
	v56.behaviors[v_u_3.MOVEMENT] = v56.MoveBehavior
	v56.behaviors[v_u_3.CORNERS] = v56.CornerBehavior
	v56.behaviors[v_u_3.CIRCLE1] = v56.CircleBehavior
	v56.behaviors[v_u_3.CIRCLE2] = v56.CircleBehavior
	v56.behaviors[v_u_3.LIMBMOVE] = v56.LimbMoveBehavior
	v56.behaviors[v_u_3.SMART_CIRCLE] = v56.SmartCircleBehavior
	v56.behaviors[v_u_3.CHAR_OUTLINE] = v56.CharacterOutlineBehavior
	v56.mode = v_u_3.SMART_CIRCLE
	v56.behaviorFunction = v56.SmartCircleBehavior
	v56.savedHits = {}
	v56.trackedLimbs = {}
	v56.camera = game.Workspace.CurrentCamera
	v56.enabled = false
	return v56
end
function v_u_53.Enable(p57, p58) -- name: Enable
	p57.enabled = p58
	if not p58 then
		p57:Cleanup()
	end
end
function v_u_53.GetOcclusionMode(_) -- name: GetOcclusionMode
	return Enum.DevCameraOcclusionMode.Invisicam
end
function v_u_53.LimbBehavior(p59, p60) -- name: LimbBehavior
	for v61, _ in pairs(p59.trackedLimbs) do
		p60[#p60 + 1] = v61.Position
	end
end
function v_u_53.MoveBehavior(p62, p63) -- name: MoveBehavior
	for v64 = 1, 3 do
		local v65 = p62.humanoidRootPart.Position
		local v66 = p62.humanoidRootPart.Velocity
		local v67 = v66.X
		local v68 = v66.Z
		local v69 = Vector3.new(v67, 0, v68).Magnitude / 2
		local v70 = (v64 - 1) * p62.humanoidRootPart.CFrame.lookVector * v69
		p63[#p63 + 1] = v65 + v70
	end
end
function v_u_53.CornerBehavior(p71, p72) -- name: CornerBehavior
	-- upvalues: (copy) v_u_5
	local v73 = p71.humanoidRootPart.CFrame
	local v74 = v73.Position
	local v75 = v73 - v74
	local v76 = p71.char:GetExtentsSize() / 2
	p72[#p72 + 1] = v74
	for v77 = 1, #v_u_5 do
		p72[#p72 + 1] = v74 + v75 * (v76 * v_u_5[v77])
	end
end
function v_u_53.CircleBehavior(p78, p79) -- name: CircleBehavior
	-- upvalues: (copy) v_u_3
	local v80
	if p78.mode == v_u_3.CIRCLE1 then
		v80 = p78.humanoidRootPart.CFrame
	else
		local v81 = p78.camera.CoordinateFrame
		v80 = v81 - v81.Position + p78.humanoidRootPart.Position
	end
	p79[#p79 + 1] = v80.Position
	for v82 = 0, 9 do
		local v83 = 0.6283185307179586 * v82
		local v84 = math.cos(v83)
		local v85 = math.sin(v83)
		local v86 = Vector3.new(v84, v85, 0) * 3
		p79[#p79 + 1] = v80 * v86
	end
end
function v_u_53.LimbMoveBehavior(p87, p88) -- name: LimbMoveBehavior
	p87:LimbBehavior(p88)
	p87:MoveBehavior(p88)
end
function v_u_53.CharacterOutlineBehavior(p89, p90) -- name: CharacterOutlineBehavior
	-- upvalues: (copy) v_u_2, (copy) v_u_7
	local v91 = p89.torsoPart.CFrame.upVector.unit
	local v92 = p89.torsoPart.CFrame.rightVector.unit
	p90[#p90 + 1] = p89.torsoPart.CFrame.Position
	p90[#p90 + 1] = p89.torsoPart.CFrame.Position + v91
	p90[#p90 + 1] = p89.torsoPart.CFrame.Position - v91
	p90[#p90 + 1] = p89.torsoPart.CFrame.Position + v92
	p90[#p90 + 1] = p89.torsoPart.CFrame.Position - v92
	if p89.headPart then
		p90[#p90 + 1] = p89.headPart.CFrame.Position
	end
	local v93 = CFrame.new
	local v94 = p89.camera.CoordinateFrame.lookVector.X
	local v95 = p89.camera.CoordinateFrame.lookVector.Z
	local v96 = v93(Vector3.new(0, 0, 0), (Vector3.new(v94, 0, v95)))
	local v97 = p89.torsoPart and p89.torsoPart.Position or p89.humanoidRootPart.Position
	local v98 = { p89.torsoPart }
	if p89.headPart then
		v98[#v98 + 1] = p89.headPart
	end
	for v99 = 1, 24 do
		local v100 = 6.283185307179586 * v99 / 24
		local v101 = math.cos(v100)
		local v102 = math.sin(v100)
		local v103 = v96 * (Vector3.new(v101, v102, 0) * 3)
		local v104 = v103.X
		local v105 = v103.Y
		local v106 = math.max(v105, -2.25)
		local v107 = v103.Z
		local v108 = Vector3.new(v104, v106, v107)
		if v_u_2 then
			v_u_7.FilterDescendantsInstances = v98
			local v109 = game.Workspace:Raycast(v97 + v108, -3 * v108, v_u_7)
			if not v109 then
				continue
			end
			local v110 = v109.Position
			p90[#p90 + 1] = v110 + 0.2 * (v97 - v110).unit
		else
			local v111 = Ray.new(v97 + v108, -3 * v108)
			local v112, v113 = game.Workspace:FindPartOnRayWithWhitelist(v111, v98, false)
			if not v112 then
				continue
			end
			p90[#p90 + 1] = v113 + 0.2 * (v97 - v113).unit
		end
	end
end
function v_u_53.SmartCircleBehavior(p114, p115) -- name: SmartCircleBehavior
	-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_51
	local v116 = p114.torsoPart.CFrame.upVector.unit
	local v117 = p114.torsoPart.CFrame.rightVector.unit
	p115[#p115 + 1] = p114.torsoPart.CFrame.Position
	p115[#p115 + 1] = p114.torsoPart.CFrame.Position + v116
	p115[#p115 + 1] = p114.torsoPart.CFrame.Position - v116
	p115[#p115 + 1] = p114.torsoPart.CFrame.Position + v117
	p115[#p115 + 1] = p114.torsoPart.CFrame.Position - v117
	if p114.headPart then
		p115[#p115 + 1] = p114.headPart.CFrame.Position
	end
	local v118 = p114.camera.CFrame - p114.camera.CFrame.Position
	local v119 = Vector3.new(0, 0.5, 0) + (p114.torsoPart and p114.torsoPart.Position or p114.humanoidRootPart.Position)
	for v120 = 1, 24 do
		local v121 = 0.2617993877991494 * v120 - 1.5707963267948966
		local v122 = math.cos(v121)
		local v123 = math.sin(v121)
		local v124 = v119 + v118 * (Vector3.new(v122, v123, 0) * 2.5)
		local v125 = v124 - p114.camera.CFrame.Position
		if v_u_2 then
			v_u_6.FilterDescendantsInstances = { p114.char }
			local v126 = game.Workspace:Raycast(v119, v124 - v119, v_u_6)
			if v126 then
				local v127 = v126.Position
				local v128 = v126.Normal
				local v129 = v127 + 0.1 * v128.unit
				local v130 = v129 - v119
				local v131 = v130:Cross(v125).unit:Cross(v128).unit
				local v132 = (v129 - p114.camera.CFrame.Position).unit
				if v130.unit:Dot(-v131) < v130.unit:Dot(v132) then
					v124 = v_u_51(v129, v131, v124, v125)
					if v124.Magnitude > 0 then
						local v133 = game.Workspace:Raycast(v129, v124 - v129, v_u_6)
						if v133 then
							v124 = v133.Position + 0.1 * v133.Normal.Unit
						end
					else
						v124 = v129
					end
				else
					v124 = v129
				end
				local v134 = game.Workspace:Raycast(v119, v124 - v119, v_u_6)
				if v134 then
					v124 = v134.Position - 0.1 * (v124 - v119).unit
				end
			end
			p115[#p115 + 1] = v124
		else
			local v135 = Ray.new(v119, v124 - v119)
			local v136, v137, v138 = game.Workspace:FindPartOnRayWithIgnoreList(v135, { p114.char }, false, false)
			if v136 then
				local v139 = v137 + 0.1 * v138.unit
				local v140 = v139 - v119
				local v141 = v140:Cross(v125).unit:Cross(v138).unit
				local v142 = (v139 - p114.camera.CFrame.Position).unit
				if v140.unit:Dot(-v141) < v140.unit:Dot(v142) then
					v124 = v_u_51(v139, v141, v124, v125)
					if v124.Magnitude > 0 then
						local v143 = Ray.new(v139, v124 - v139)
						local v144, v145, v146 = game.Workspace:FindPartOnRayWithIgnoreList(v143, { p114.char }, false, false)
						if v144 then
							v124 = v145 + 0.1 * v146.unit
						end
					else
						v124 = v139
					end
				else
					v124 = v139
				end
				local v147 = Ray.new(v119, v124 - v119)
				local v148, v149 = game.Workspace:FindPartOnRayWithIgnoreList(v147, { p114.char }, false, false)
				if v148 then
					v124 = v149 - 0.1 * (v124 - v119).unit
				end
			end
			p115[#p115 + 1] = v124
		end
	end
end
function v_u_53.CheckTorsoReference(p150) -- name: CheckTorsoReference
	if p150.char then
		p150.torsoPart = p150.char:FindFirstChild("Torso")
		if not p150.torsoPart then
			p150.torsoPart = p150.char:FindFirstChild("UpperTorso")
			if not p150.torsoPart then
				p150.torsoPart = p150.char:FindFirstChild("HumanoidRootPart")
			end
		end
		p150.headPart = p150.char:FindFirstChild("Head")
	end
end
function v_u_53.CharacterAdded(p_u_151, p152, p153) -- name: CharacterAdded
	-- upvalues: (copy) v_u_1, (copy) v_u_4
	if p153 == v_u_1.LocalPlayer then
		if p_u_151.childAddedConn then
			p_u_151.childAddedConn:Disconnect()
			p_u_151.childAddedConn = nil
		end
		if p_u_151.childRemovedConn then
			p_u_151.childRemovedConn:Disconnect()
			p_u_151.childRemovedConn = nil
		end
		p_u_151.char = p152
		p_u_151.trackedLimbs = {}
		local function v155(p154) -- name: childAdded
			-- upvalues: (ref) v_u_4, (copy) p_u_151
			if p154:IsA("BasePart") then
				if v_u_4[p154.Name] then
					p_u_151.trackedLimbs[p154] = true
				end
				if p154.Name == "Torso" or p154.Name == "UpperTorso" then
					p_u_151.torsoPart = p154
				end
				if p154.Name == "Head" then
					p_u_151.headPart = p154
				end
			end
		end
		p_u_151.childAddedConn = p152.ChildAdded:Connect(v155)
		p_u_151.childRemovedConn = p152.ChildRemoved:Connect(function(p156) -- name: childRemoved
			-- upvalues: (copy) p_u_151
			p_u_151.trackedLimbs[p156] = nil
			p_u_151:CheckTorsoReference()
		end)
		for _, v157 in pairs(p_u_151.char:GetChildren()) do
			if not v157:IsA("BasePart") then
				continue
			end
			if v_u_4[v157.Name] then
				p_u_151.trackedLimbs[v157] = true
			end
			if v157.Name == "Torso" or v157.Name == "UpperTorso" then
				p_u_151.torsoPart = v157
			end
			if v157.Name ~= "Head" then
				continue
			end
			p_u_151.headPart = v157
		end
	end
end
function v_u_53.SetMode(p158, p159) -- name: SetMode
	-- upvalues: (copy) v_u_15, (copy) v_u_3
	v_u_15(p159, "number")
	for _, v160 in pairs(v_u_3) do
		if v160 ~= p159 then
			continue
		end
		p158.mode = p159
		p158.behaviorFunction = p158.behaviors[p158.mode]
		return
	end
	error("Invalid mode number")
end
function v_u_53.GetObscuredParts(p161) -- name: GetObscuredParts
	return p161.savedHits
end
function v_u_53.Cleanup(p162) -- name: Cleanup
	for v163, v164 in pairs(p162.savedHits) do
		v163.LocalTransparencyModifier = v164
	end
end
function v_u_53.Update(p_u_165, _, p166, p167) -- name: Update
	if not (p_u_165.enabled and p_u_165.char) then
		return p166, p167
	end
	p_u_165.camera = game.Workspace.CurrentCamera
	if not p_u_165.humanoidRootPart then
		local v168 = p_u_165.char:FindFirstChildOfClass("Humanoid")
		if v168 and v168.RootPart then
			p_u_165.humanoidRootPart = v168.RootPart
		else
			p_u_165.humanoidRootPart = p_u_165.char:FindFirstChild("HumanoidRootPart")
			if not p_u_165.humanoidRootPart then
				return p166, p167
			end
		end
		local v_u_169 = nil
		v_u_169 = p_u_165.humanoidRootPart.AncestryChanged:Connect(function(p170, p171)
			-- upvalues: (copy) p_u_165, (ref) v_u_169
			if p170 == p_u_165.humanoidRootPart and not p171 then
				p_u_165.humanoidRootPart = nil
				if v_u_169 and v_u_169.Connected then
					v_u_169:Disconnect()
					v_u_169 = nil
				end
			end
		end)
	end
	if not p_u_165.torsoPart then
		p_u_165:CheckTorsoReference()
		if not p_u_165.torsoPart then
			return p166, p167
		end
	end
	local v172 = {}
	p_u_165.behaviorFunction(p_u_165, v172)
	local v173 = { p_u_165.char }
	local v174 = p_u_165.headPart and p_u_165.headPart.CFrame.Position or v172[1]
	local v175 = p_u_165.torsoPart and p_u_165.torsoPart.CFrame.Position or v172[2]
	local v176 = p_u_165.camera:GetPartsObscuringTarget({ v174, v175 }, v173)
	local v177 = 0
	local v178 = {}
	local v179 = 0.75
	local v180 = {}
	local v181 = 0.75
	for v182 = 1, #v176 do
		local v183 = v176[v182]
		v177 = v177 + 1
		v178[v183] = true
		for _, v184 in pairs(v183:GetChildren()) do
			if not (v184:IsA("Decal") or v184:IsA("Texture")) then
				continue
			end
			v177 = v177 + 1
		end
	end
	if v177 > 0 then
		local v185 = 0.375 / v177 + 0.375
		local v186 = 1 / v177
		v179 = math.pow(v185, v186)
		local v187 = 0.25 / v177 + 0.25
		local v188 = 1 / v177
		v181 = math.pow(v187, v188)
	end
	local v189 = p_u_165.camera:GetPartsObscuringTarget(v172, v173)
	local v190 = {}
	for v191 = 1, #v189 do
		local v192 = v189[v191]
		v190[v192] = v178[v192] and v179 and v179 or v181
		if v192.Transparency < v190[v192] then
			v180[v192] = true
			if not p_u_165.savedHits[v192] then
				p_u_165.savedHits[v192] = v192.LocalTransparencyModifier
			end
		end
		for _, v193 in pairs(v192:GetChildren()) do
			if not (v193:IsA("Decal") or v193:IsA("Texture")) or v193.Transparency >= v190[v192] then
				continue
			end
			v190[v193] = v190[v192]
			v180[v193] = true
			if p_u_165.savedHits[v193] then
				continue
			end
			p_u_165.savedHits[v193] = v193.LocalTransparencyModifier
		end
	end
	for v194, v195 in pairs(p_u_165.savedHits) do
		if v180[v194] then
			v194.LocalTransparencyModifier = v194.Transparency < 1 and ((v190[v194] - v194.Transparency) / (1 - v194.Transparency) or 0) or 0
		else
			v194.LocalTransparencyModifier = v195
			p_u_165.savedHits[v194] = nil
		end
	end
	return p166, p167
end
return v_u_53