local v1 = game:GetService("ReplicatedStorage")
local v2 = script.Parent.Parent
local v_u_3 = require(v2.Util)
local v_u_4 = require(v2.Hud)
local v_u_5 = require(v2.Effects)
local v_u_6 = require(v1:WaitForChild("Shared"):WaitForChild("Combat"))
local v_u_7 = {}
v_u_7.__index = v_u_7
function v_u_7.new(p8) -- name: new
	-- upvalues: (copy) v_u_7
	local v9 = v_u_7
	local v10 = setmetatable({}, v9)
	v10.ctx = p8
	v10.tuning = p8.tuning
	v10.preset = p8.preset
	v10.drawing = false
	v10.drawStart = 0
	v10.lastShot = (-1 / 0)
	v10.aiming = false
	v10.full = false
	v10.drawSound = nil
	v10.m1Down = false
	v10.bufferedAt = nil
	return v10
end
function v_u_7.SyncPool(p11) -- name: SyncPool
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v12 = p11.tuning.ammo
	if v12 then
		v_u_4.SetAmmoCount(v_u_3.AmmoShown(p11.ctx.char, v12))
	end
end
function v_u_7.OutOfAmmo(p13) -- name: OutOfAmmo
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v14 = p13.tuning.ammo
	if not v14 or v_u_3.AmmoLeft(p13.ctx.char, v14) >= 1 then
		return false
	end
	local v15 = os.clock()
	if v15 - (p13.lastDry or 0) > 0.4 then
		p13.lastDry = v15
		v_u_3.Sound("Dry_Fire", p13.ctx.root)
		v_u_4.Toast(v_u_3.AMMO_OUT[v14] or "OUT OF AMMO", Color3.fromRGB(255, 110, 90), 1)
	end
	return true
end
function v_u_7.Equip(p_u_16) -- name: Equip
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	v_u_4.SetStyle("Bow")
	v_u_4.SetPips(0, 0)
	v_u_3.PlayAnim(p_u_16.ctx.animator, p_u_16.preset.hold, 1, 0.2)
	if not v_u_3.InFirstPerson() then
		v_u_3.Sound(p_u_16.preset.equip or "Equip_Bow", p_u_16.ctx.root)
	end
	local v17 = p_u_16.tuning.ammo
	if v17 and p_u_16.ctx.char then
		p_u_16:SyncPool()
		p_u_16.poolConns = v_u_3.WatchAmmo(p_u_16.ctx.char, v17, function()
			-- upvalues: (copy) p_u_16
			p_u_16:SyncPool()
		end)
	end
end
function v_u_7.Unequip(p18) -- name: Unequip
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4
	local v19 = p18.ctx
	if p18.drawing then
		p18:CancelDraw()
	end
	if p18.aiming then
		p18.aiming = false
		v_u_3.SetAiming(false)
		v19.setSpeed("Aim", nil)
	end
	v_u_3.StopAnim(v19.animator, p18.preset.hold, 0.15)
	v_u_3.StopAnim(v19.animator, p18.preset.aim, 0.15)
	v_u_5.ChargeGlow(v19.tool, 0)
	v_u_3.SetCameraModifier("CombatDraw", nil)
	p18.bufferedAt = nil
	if p18.poolConns then
		for _, v20 in p18.poolConns do
			v20:Disconnect()
		end
		p18.poolConns = nil
	end
	v_u_4.SetAmmoCount(nil)
end
function v_u_7.Charge(p21) -- name: Charge
	if not p21.drawing then
		return 0
	end
	local v22 = (os.clock() - p21.drawStart) / (p21.tuning.drawTime or 1)
	return math.clamp(v22, 0, 1)
end
function v_u_7.StartDraw(p23) -- name: StartDraw
	-- upvalues: (copy) v_u_3
	local v24 = p23.ctx
	local v25 = os.clock()
	if p23.drawing or (v25 - p23.lastShot < (p23.nextCd or (p23.tuning.cooldown or 0.25)) or not v_u_3.CanAct()) then
		return false
	end
	if p23:OutOfAmmo() then
		p23.bufferedAt = nil
		return false
	end
	p23.bufferedAt = nil
	v_u_3.SetCameraModifier("CombatDraw", {
		["fov"] = -6,
		["pivot"] = Vector3.new(0.3, 0, 0)
	})
	p23.drawing = true
	p23.full = false
	p23.drawStart = v25
	v24.send("Charge", {
		["tool"] = nil,
		["kind"] = "Draw",
		["on"] = true,
		["tool"] = v24.tool
	})
	v24.emit("Draw", {
		["on"] = true,
		["time"] = nil,
		["arrow"] = nil,
		["time"] = p23.tuning.drawTime or 1,
		["arrow"] = v_u_3.ShotKind(v24.char, p23.tuning.ammo, p23.tuning.projectile or "Arrow")
	})
	v_u_3.FaceCamera()
	local v26 = p23.tuning.drawTime or 1
	local v27 = 0.88 / math.max(0.3, v26)
	v_u_3.PlayHold(v24.animator, p23.preset.draw, v27)
	p23.drawSound = v_u_3.Sound(p23.preset.drawSound or "Bow_Draw", v24.root, {
		["PlaybackSpeed"] = math.clamp(v27, 0.7, 1.3)
	})
	v24.setSpeed("Draw", p23.tuning.drawSpeedMult or 0.7)
	return true
end
function v_u_7.CancelDraw(p28) -- name: CancelDraw
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5
	local v29 = p28.ctx
	p28.drawing = false
	v29.send("Charge", {
		["tool"] = nil,
		["kind"] = "Draw",
		["on"] = false,
		["tool"] = v29.tool
	})
	v29.emit("Draw", {
		["on"] = false
	})
	v_u_3.StopAnim(v29.animator, p28.preset.draw, 0.12)
	if p28.drawSound then
		p28.drawSound:Stop()
		p28.drawSound = nil
	end
	v29.setSpeed("Draw", nil)
	v_u_4.SetCharge(0)
	v_u_5.ChargeGlow(v29.tool, 0)
	v_u_3.SetCameraModifier("CombatDraw", nil)
end
function v_u_7.Fire(p30) -- name: Fire
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_6
	local v31 = p30.ctx
	local v32 = p30.tuning
	if p30.drawing then
		if v_u_3.CanAct() then
			local v33 = p30:Charge()
			p30.drawing = false
			p30.lastShot = os.clock()
			v31.emit("Release", {
				["charge"] = v33
			})
			local v34 = p30.tuning.cooldown or 0.2
			p30.nextCd = v34 + ((p30.tuning.tapCooldown or (p30.tuning.cooldown or 0.2)) - v34) * (1 - v33)
			if p30.drawSound then
				p30.drawSound:Stop()
				p30.drawSound = nil
			end
			v_u_3.StopAnim(v31.animator, p30.preset.draw, 0.05)
			v_u_3.PlayAnim(v31.animator, p30.preset.fire, p30.preset.fireAnimSpeed or 1.2, 0.03)
			v_u_3.SetCameraModifier("CombatDraw", nil)
			v31.setSpeed("Draw", nil)
			v_u_4.SetCharge(0)
			v_u_5.ChargeGlow(v31.tool, 0)
			local v35 = v_u_3.ShotOrigin(v31.tool, "Muzzle")
			local v36 = v_u_3.AssistDirection(v35, v_u_3.AimDirection(v35), true)
			local v37, v38 = v_u_6.DrawnShot(v32, v33)
			local v39 = v31.nextId()
			v_u_5.Projectile(v_u_5.MyKey(v39), v_u_3.ShotKind(v31.char, v32.ammo, v32.projectile or "Arrow"), v35, v36 * v38, v32.gravity or 60, v31.char, {
				["damage"] = v37 * v_u_3.ItemBonus(v31.weaponId),
				["tuning"] = v32
			})
			v31.send("Shoot", {
				["tool"] = v31.tool,
				["origin"] = v35,
				["dir"] = v36,
				["id"] = v39,
				["charge"] = v33
			})
			v_u_3.Sound(p30.preset.fireSound or "Bow_Release", v31.root, {
				["PlaybackSpeed"] = 0.9 + 0.25 * v33,
				["Volume"] = 0.6 + 0.4 * v33
			})
			v_u_3.Recoil(1 + 1.8 * v33, (math.random() - 0.5) * 0.6)
			v_u_3.Shake(0.1 + 0.15 * v33, 0.12)
			v_u_4.Kick(6 * v33)
		else
			p30:CancelDraw()
		end
	else
		return
	end
end
function v_u_7.Input(p40, p41, p42) -- name: Input
	-- upvalues: (copy) v_u_3
	if p41 == "Primary" then
		p40.m1Down = p42
		if not p42 then
			p40:Fire()
			return
		end
		if not (p40:StartDraw() or (p40.drawing or p40:OutOfAmmo())) then
			p40.bufferedAt = os.clock()
			return
		end
	elseif p41 == "Secondary" then
		p40.aiming = p42
		v_u_3.SetAiming(p42, p40.tuning.aimFov)
		p40.ctx.setSpeed("Aim", p42 and 0.8 or nil)
		if p42 then
			v_u_3.PlayAnim(p40.ctx.animator, p40.preset.aim, 1, 0.15)
			return
		end
		v_u_3.StopAnim(p40.ctx.animator, p40.preset.aim, 0.15)
	end
end
function v_u_7.Update(p43, _) -- name: Update
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_3
	if p43.bufferedAt and not p43.drawing then
		if p43.m1Down or os.clock() - p43.bufferedAt <= 0.15 then
			if p43:StartDraw() and not p43.m1Down then
				p43:Fire()
			end
		else
			p43.bufferedAt = nil
		end
	end
	if p43.drawing then
		local v44 = p43:Charge()
		v_u_4.SetCharge(v44)
		local v45 = p43.preset.glow
		v_u_5.ChargeGlow(p43.ctx.tool, v44, v45)
		if v44 >= 1 and not p43.full then
			p43.full = true
			v_u_3.Sound(p43.preset.fullSound or "Bow_Full", p43.ctx.root)
			v_u_5.ChargePing(p43.ctx.tool, v45)
		end
	end
end
function v_u_7.Interrupt(p46) -- name: Interrupt
	if p46.drawing then
		p46:CancelDraw()
	end
end
function v_u_7.OnDenied(p47, p48) -- name: OnDenied
	if p48 == "NoAmmo" then
		p47.lastDry = 0
		p47:OutOfAmmo()
	end
end
return v_u_7