local v_u_1 = game:GetService("StarterGui")
local v_u_2 = game:GetService("TextChatService")
return {
	["Init"] = function(p_u_3) -- name: Init
		-- upvalues: (copy) v_u_2, (copy) v_u_1
		local v_u_4 = p_u_3.UI
		local v_u_5 = p_u_3.Theme
		local v_u_6 = v_u_5.Colors
		local v_u_7 = v_u_5.Fonts
		local v_u_8 = p_u_3.MenuManager
		local v_u_9 = UDim2.fromOffset
		local v_u_10 = {}
		local function v_u_15(p_u_11) -- name: systemLine
			-- upvalues: (ref) v_u_2, (ref) v_u_1
			local v_u_12 = v_u_2:FindFirstChild("TextChannels")
			if v_u_12 then
				v_u_12 = v_u_12:FindFirstChild("RBXSystem")
			end
			if v_u_12 and v_u_12:IsA("TextChannel") then
				return pcall(function()
					-- upvalues: (copy) v_u_12, (copy) p_u_11
					local v13 = p_u_11
					v_u_12:DisplaySystemMessage((("<font color=\"#FF7A82\"><b>[MOD]</b></font> <font color=\"#E4E8F0\">%*</font>"):format((string.gsub(string.gsub(string.gsub(v13, "&", "&amp;"), "<", "&lt;"), ">", "&gt;")))))
				end)
			end
			local function v14()
				-- upvalues: (ref) v_u_1, (copy) p_u_11
				v_u_1:SetCore("ChatMakeSystemMessage", {
					["Text"] = "[MOD] " .. p_u_11,
					["Color"] = Color3.fromRGB(255, 160, 165)
				})
			end
			return pcall(v14)
		end
		local function v_u_23(p16, p17, p18) -- name: say
			-- upvalues: (copy) v_u_10, (copy) v_u_15, (copy) p_u_3
			local v19 = false
			if type(p16) == "table" then
				for _, v20 in p16 do
					if type(v20) ~= "string" then
						continue
					end
					local v21 = v_u_10
					table.insert(v21, v20)
					v19 = v_u_15(v20) or v19
				end
				while #v_u_10 > 30 do
					table.remove(v_u_10, 1)
				end
			end
			if type(p17) == "string" and p17 ~= "" then
				p_u_3.Toast(p17, type(p18) ~= "string" and "info" or p18)
			elseif not v19 and type(p16) == "table" then
				local v22 = p16[1]
				if type(v22) == "string" then
					p_u_3.Toast(p16[1], type(p18) ~= "string" and "info" or p18)
				end
			end
		end
		local v_u_24 = nil
		local v_u_25 = {}
		local v_u_26 = nil
		local v_u_27 = false
		local function v_u_28() -- name: close
			-- upvalues: (copy) v_u_8
			v_u_8.Close("ModBan")
		end
		local function v_u_37(p29, p30, p31) -- name: row
			-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_6, (ref) v_u_24, (copy) v_u_7
			local v32 = v_u_4.new("Frame", {
				["Name"] = p29,
				["Position"] = v_u_9(0, p30),
				["Size"] = UDim2.new(1, 0, 0, 58),
				["BackgroundColor3"] = v_u_6.PanelHi,
				["BackgroundTransparency"] = 0.25,
				v_u_4.Corner(12),
				["Parent"] = v_u_24.Content
			})
			local v33 = {
				["Name"] = "Title",
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 14,
				["TextColor3"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = p31,
				["FontFace"] = v_u_7.Heavy,
				["TextColor3"] = v_u_6.TextMuted,
				["Position"] = v_u_9(18, 0),
				["Size"] = UDim2.new(0, 110, 1, 0),
				["Parent"] = v32,
				["BackgroundTransparency"] = 1
			}
			v33.TextXAlignment = v33.TextXAlignment or Enum.TextXAlignment.Left
			v33.TextColor3 = v33.TextColor3 or v_u_6.Text
			v_u_4.new("TextLabel", v33)
			local v34 = {
				["Name"] = "Value",
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 21,
				["Position"] = nil,
				["Size"] = nil,
				["TextTruncate"] = nil,
				["Parent"] = nil,
				["FontFace"] = v_u_7.Bold,
				["Position"] = v_u_9(128, 9),
				["Size"] = UDim2.new(1, -146, 0, 24),
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v32,
				["BackgroundTransparency"] = 1
			}
			v34.TextXAlignment = v34.TextXAlignment or Enum.TextXAlignment.Left
			v34.TextColor3 = v34.TextColor3 or v_u_6.Text
			local v35 = v_u_4.new("TextLabel", v34)
			local v36 = {
				["Name"] = "Sub",
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 14,
				["TextColor3"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["FontFace"] = v_u_7.SemiBold,
				["TextColor3"] = v_u_6.TextMuted,
				["Position"] = v_u_9(128, 33),
				["Size"] = UDim2.new(1, -146, 0, 16),
				["Parent"] = v32,
				["BackgroundTransparency"] = 1
			}
			v36.TextXAlignment = v36.TextXAlignment or Enum.TextXAlignment.Left
			v36.TextColor3 = v36.TextColor3 or v_u_6.Text
			return v32, v35, v_u_4.new("TextLabel", v36)
		end
		local function v_u_60() -- name: build
			-- upvalues: (ref) v_u_24, (copy) v_u_4, (copy) v_u_9, (copy) p_u_3, (copy) v_u_28, (copy) v_u_6, (copy) v_u_5, (copy) v_u_25, (copy) v_u_7, (copy) v_u_37, (ref) v_u_27, (ref) v_u_26, (copy) v_u_8
			v_u_24 = v_u_4.Window({
				["Name"] = "ModBan",
				["Title"] = "BAN PLAYER",
				["Subtitle"] = "Check it\'s the right account",
				["Size"] = nil,
				["HeaderHeight"] = 76,
				["Parent"] = nil,
				["OnCloseRequested"] = nil,
				["Size"] = v_u_9(600, 466),
				["Parent"] = p_u_3.Canvas.Menus,
				["OnCloseRequested"] = v_u_28
			})
			v_u_24.Title.TextColor3 = v_u_6.Danger
			v_u_4.SelectionRing(v_u_24.Root)
			local v38 = v_u_24.Content
			local v39 = v_u_4.new("ImageLabel", {
				["Name"] = "Head",
				["Position"] = v_u_9(0, 0),
				["Size"] = v_u_9(92, 92),
				["BackgroundColor3"] = v_u_6.Raised,
				["Image"] = "",
				v_u_4.Corner(v_u_5.Radius.Pill),
				["Parent"] = v38
			})
			v_u_4.Stroke(v_u_6.Stroke, 1.5, 0.85).Parent = v39
			v_u_25.head = v39
			local v40 = v_u_25
			local v41 = {
				["Name"] = "Name",
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 32,
				["Position"] = nil,
				["Size"] = nil,
				["TextTruncate"] = nil,
				["Parent"] = nil,
				["FontFace"] = v_u_7.Display,
				["Position"] = v_u_9(112, 2),
				["Size"] = UDim2.new(1, -112, 0, 36),
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v38,
				["BackgroundTransparency"] = 1
			}
			v41.TextXAlignment = v41.TextXAlignment or Enum.TextXAlignment.Left
			v41.TextColor3 = v41.TextColor3 or v_u_6.Text
			v40.name = v_u_4.new("TextLabel", v41)
			local v42 = v_u_25
			local v43 = {
				["Name"] = "Handle",
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 17,
				["TextColor3"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["TextTruncate"] = nil,
				["Parent"] = nil,
				["FontFace"] = v_u_7.SemiBold,
				["TextColor3"] = v_u_6.TextDim,
				["Position"] = v_u_9(112, 40),
				["Size"] = UDim2.new(1, -112, 0, 20),
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v38,
				["BackgroundTransparency"] = 1
			}
			v43.TextXAlignment = v43.TextXAlignment or Enum.TextXAlignment.Left
			v43.TextColor3 = v43.TextColor3 or v_u_6.Text
			v42.handle = v_u_4.new("TextLabel", v43)
			v_u_25.whereHolder = v_u_4.new("Frame", {
				["Name"] = "Where",
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Position"] = v_u_9(112, 66),
				["Size"] = v_u_9(300, 24),
				["Parent"] = v38
			})
			v_u_25.already = v_u_4.new("Frame", {
				["Name"] = "Already",
				["Position"] = v_u_9(0, 106),
				["Size"] = UDim2.new(1, 0, 0, 36),
				["BackgroundColor3"] = v_u_6.Warning,
				["BackgroundTransparency"] = 0.82,
				["Visible"] = false,
				v_u_4.Corner(10),
				["Parent"] = v38
			})
			v_u_4.Stroke(v_u_6.Warning, 1, 0.5).Parent = v_u_25.already
			local v44 = v_u_25
			local v45 = {
				["Name"] = "Text",
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 16,
				["TextColor3"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["TextTruncate"] = nil,
				["Parent"] = nil,
				["FontFace"] = v_u_7.Bold,
				["TextColor3"] = v_u_6.Warning,
				["Position"] = v_u_9(14, 0),
				["Size"] = UDim2.new(1, -28, 1, 0),
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v_u_25.already,
				["BackgroundTransparency"] = 1
			}
			v45.TextXAlignment = v45.TextXAlignment or Enum.TextXAlignment.Left
			v45.TextColor3 = v45.TextColor3 or v_u_6.Text
			v44.alreadyText = v_u_4.new("TextLabel", v45)
			local _, v46, v47 = v_u_37("Length", 106, "LENGTH")
			local _, v48, v49 = v_u_37("Reason", 170, "REASON")
			v_u_25.lengthRow = v46.Parent
			v_u_25.reasonRow = v48.Parent
			local v50 = v_u_25
			v_u_25.length = v46
			v50.lengthSub = v47
			local v51 = v_u_25
			v_u_25.reason = v48
			v51.reasonSub = v49
			v49.Text = "They see this when they try to join"
			local v52 = v_u_25
			local v53 = {
				["Name"] = "Note",
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 15,
				["TextColor3"] = nil,
				["TextWrapped"] = true,
				["TextYAlignment"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["FontFace"] = v_u_7.SemiBold,
				["TextColor3"] = v_u_6.TextMuted,
				["TextYAlignment"] = Enum.TextYAlignment.Top,
				["Position"] = v_u_9(0, 240),
				["Size"] = UDim2.new(1, 0, 0, 40),
				["Parent"] = v38,
				["BackgroundTransparency"] = 1
			}
			v53.TextXAlignment = v53.TextXAlignment or Enum.TextXAlignment.Left
			v53.TextColor3 = v53.TextColor3 or v_u_6.Text
			v52.note = v_u_4.new("TextLabel", v53)
			v_u_25.cancel = v_u_4.Button({
				["Name"] = "Cancel",
				["Text"] = "CANCEL",
				["TextSize"] = 20,
				["Style"] = "Dark",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.new(0, 0, 1, 0),
				["Size"] = v_u_9(272, 58),
				["Parent"] = v38
			})
			v_u_25.ban = v_u_4.Button({
				["Name"] = "Ban",
				["Text"] = "BAN",
				["TextSize"] = 20,
				["Style"] = "Danger",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(1, 1),
				["Position"] = UDim2.new(1, 0, 1, 0),
				["Size"] = v_u_9(272, 58),
				["Parent"] = v38
			})
			v_u_25.cancel.Activated:Connect(v_u_28)
			v_u_25.ban.Activated:Connect(function()
				-- upvalues: (ref) v_u_27, (ref) v_u_26, (ref) v_u_25, (ref) p_u_3, (ref) v_u_8
				if not v_u_27 and v_u_26 then
					v_u_27 = true
					v_u_25.ban:SetText("BANNING\226\128\166")
					v_u_25.ban:SetEnabled(false)
					local v_u_54 = v_u_26.token
					task.spawn(function()
						-- upvalues: (ref) p_u_3, (copy) v_u_54, (ref) v_u_27, (ref) v_u_26, (ref) v_u_8, (ref) v_u_25
						local v55, v56, v57 = p_u_3.Remotes.Invoke("ModAction", "Ban", v_u_54)
						v_u_27 = false
						if v55 and v56 then
							v_u_26 = nil
							v_u_8.Close("ModBan")
							p_u_3.Toast(type(v57) ~= "string" and "Banned" or v57, "success")
						else
							v_u_25.ban:SetEnabled(true)
							v_u_25.ban:SetText("TRY AGAIN")
							local v58 = p_u_3.Toast
							local v59
							if type(v57) == "string" then
								v59 = v57
							else
								v59 = type(v56) ~= "string" and "The ban didn\'t go through" or v56
							end
							v58(v59, "error")
							if type(v57) == "string" and string.find(v57, "expired", 1, true) then
								v_u_26 = nil
								v_u_8.Close("ModBan")
							end
						end
					end)
				end
			end)
		end
		local function v_u_84() -- name: paint
			-- upvalues: (ref) v_u_26, (copy) v_u_25, (copy) v_u_4, (copy) v_u_6, (ref) v_u_24, (copy) v_u_9
			local v61 = v_u_26
			if v61 then
				local v62 = v61.userId
				local v63 = tonumber(v62) or 0
				v_u_25.head.Image = ("rbxthumb://type=AvatarHeadShot&id=%*&w=150&h=150"):format(v63)
				local v64 = v61.display or (v61.name or "?")
				local v65 = tostring(v64)
				local v66 = v61.name or "?"
				local v67 = tostring(v66)
				v_u_25.name.Text = v65
				v_u_25.handle.Text = ("@%*  \194\183  id %*"):format(v67, v63)
				v_u_25.whereHolder:ClearAllChildren()
				local v68 = v61.where or "away"
				local v69 = tostring(v68)
				local v70 = v69 == "here" and "In this server" or (v69 == "away" and "Not in this server" or v69)
				local v71 = v_u_4.Pill
				local v72
				if v69 == "here" then
					v72 = v_u_6.SuccessDark
				else
					v72 = v_u_6.Raised
				end
				v71(v70, v72, {
					["Height"] = 24,
					["TextSize"] = 13,
					["Parent"] = nil,
					["Parent"] = v_u_25.whereHolder
				})
				local v73 = v61.already
				local v74
				if type(v73) == "string" then
					v74 = v61.already ~= ""
				else
					v74 = false
				end
				v_u_25.already.Visible = v74
				v_u_25.alreadyText.Text = not v74 and "" or ("Already %*. Banning again replaces it."):format(v61.already)
				local v75 = v74 and 152 or 106
				v_u_24.Holder.Size = v_u_9(600, (v74 and 46 or 0) + 466)
				v_u_24.Refit()
				v_u_25.lengthRow.Position = v_u_9(0, v75)
				v_u_25.reasonRow.Position = v_u_9(0, v75 + 64)
				v_u_25.note.Position = v_u_9(0, v75 + 136)
				local v76 = v61.length
				local v77 = (tonumber(v76) or -1) < 0
				local v78 = v61.lengthText or "permanent"
				local v79 = tostring(v78)
				v_u_25.length.Text = v77 and "Permanent" or string.upper((string.sub(v79, 1, 1))) .. string.sub(v79, 2)
				local v80 = v_u_25.length
				local v81
				if v77 then
					v81 = v_u_6.Danger
				else
					v81 = v_u_6.Text
				end
				v80.TextColor3 = v81
				v_u_25.lengthSub.Text = v77 and "Until a moderator unbans them (/unban)" or "Then they can play again"
				local v82 = v_u_25.reason
				local v83 = v61.reason or "Cheating"
				v82.Text = tostring(v83)
				v_u_25.note.Text = "Their alt accounts are banned too, and their device can\'t rejoin for 24 hours." .. (v61.studio and "  Studio: a test ban, it never reaches the live game." or "")
				v_u_25.ban:SetText(v77 and "BAN PERMANENTLY" or ("BAN FOR %*"):format((string.upper(v79))))
				v_u_25.ban:SetEnabled(true)
			end
		end
		local v86 = {
			["open"] = function() -- name: open
				-- upvalues: (ref) v_u_24, (copy) v_u_60, (ref) v_u_27, (copy) v_u_84
				if not v_u_24 then
					v_u_60()
				end
				v_u_27 = false
				v_u_84()
				v_u_24:Open()
			end,
			["close"] = function(p85) -- name: close
				-- upvalues: (ref) v_u_24
				if v_u_24 then
					v_u_24:Close(p85)
				end
			end,
			["select"] = function() -- name: select
				-- upvalues: (copy) v_u_25
				if v_u_25.cancel then
					return v_u_25.cancel.Instance
				else
					return nil
				end
			end
		}
		v_u_8.Register("ModBan", v86)
		p_u_3.Remotes.On("ModEvent", function(p87, p88, p89, p90)
			-- upvalues: (copy) v_u_23, (ref) v_u_26, (copy) v_u_8, (copy) v_u_84
			if p87 == "Say" then
				v_u_23(p88, p89, p90)
			elseif p87 == "Confirm" and type(p88) == "table" then
				v_u_26 = p88
				if v_u_8.IsOpen("ModBan") then
					v_u_84()
					return
				end
				v_u_8.Open("ModBan")
			end
		end)
		function p_u_3.Debug.mod(p91)
			-- upvalues: (copy) v_u_25, (copy) v_u_8, (copy) v_u_10
			if p91 == "ban" and v_u_25.ban then
				v_u_25.ban.Activated:Fire()
			end
			local v92 = {
				["open"] = v_u_8.IsOpen("ModBan")
			}
			local v93
			if v_u_25.name then
				v93 = v_u_25.name.Text
			else
				v93 = false
			end
			v92.name = v93
			local v94
			if v_u_25.length then
				v94 = v_u_25.length.Text
			else
				v94 = false
			end
			v92.length = v94
			local v95
			if v_u_25.reason then
				v95 = v_u_25.reason.Text
			else
				v95 = false
			end
			v92.reason = v95
			v92.said = v_u_10
			return v92
		end
	end
}