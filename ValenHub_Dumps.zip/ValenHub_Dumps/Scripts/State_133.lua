local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v4 = require(v_u_2:WaitForChild("Shared"):WaitForChild("Signal"))
local v_u_5 = require(script.Parent.Remotes)
local v_u_6 = v1.LocalPlayer
local v_u_7 = {
	["ProfileChanged"] = v4.new(),
	["MatchChanged"] = v4.new(),
	["MatchEvent"] = v4.new(),
	["PlayerStateChanged"] = v4.new(),
	["WatchChanged"] = v4.new(),
	["AttrChanged"] = v4.new(),
	["LeaderboardsChanged"] = v4.new(),
	["Notify"] = v4.new()
}
local v_u_8 = {
	["items"] = nil,
	["armor"] = "hide_armor",
	["ammo"] = nil,
	["items"] = { "bronze_sword", "short_bow", "bandage" },
	["ammo"] = {
		["arrows"] = 3
	}
}
v_u_7.STARTER_LOADOUT = v_u_8
local function v_u_11() -- name: defaultProfile
	-- upvalues: (copy) v_u_8
	local v9 = {
		["level"] = 1,
		["xp"] = 0,
		["xpToNext"] = 100,
		["shells"] = 0,
		["owned"] = nil,
		["loadout"] = nil,
		["stats"] = nil,
		["owned"] = {}
	}
	local v10 = v_u_8
	v9.loadout = {
		["items"] = table.clone(v10.items),
		["armor"] = v10.armor
	}
	v9.stats = {
		["matches"] = 0,
		["wins"] = 0,
		["losses"] = 0,
		["kills"] = 0,
		["deaths"] = 0,
		["streak"] = 0,
		["bestStreak"] = 0,
		["roundsWon"] = 0
	}
	return v9
end
v_u_7.Profile = v_u_11()
v_u_7.HasProfile = false
v_u_7.Match = nil
v_u_7.Leaderboards = nil
v_u_7.Mock = nil
v_u_7.DEFAULT_ROUNDS_TO_WIN = 3
v_u_7.DEFAULT_ROUND_TIME = 60
local v12 = v_u_2.Shared:FindFirstChild("Config")
if v12 and v12:IsA("ModuleScript") then
	local v13 = require
	local v14, v15 = pcall(v13, v12)
	if v14 and type(v15) == "table" then
		local v16 = v15.ROUNDS_TO_WIN
		if type(v16) == "number" then
			v_u_7.DEFAULT_ROUNDS_TO_WIN = v15.ROUNDS_TO_WIN
		end
	end
	if v14 and type(v15) == "table" then
		local v17 = v15.ROUND_TIME
		if type(v17) == "number" then
			v_u_7.DEFAULT_ROUND_TIME = v15.ROUND_TIME
		end
	end
end
local v_u_18 = nil
function v_u_7.RoundTime() -- name: RoundTime
	-- upvalues: (copy) v_u_7, (ref) v_u_18
	local v19 = v_u_7.Match
	if v19 then
		local v20 = v19.roundTime
		if type(v20) == "number" then
			return v19.roundTime
		end
	end
	return v_u_18 or v_u_7.DEFAULT_ROUND_TIME
end
local v_u_21 = nil
v_u_7.MatchChanged:Connect(function(p22)
	-- upvalues: (ref) v_u_21, (copy) v_u_7, (ref) v_u_18
	local v23
	if p22 then
		v23 = p22.phase
	else
		v23 = p22
	end
	if v23 == "Live" and v_u_21 ~= "Live" then
		local v24 = p22.phaseEndsAt
		if type(v24) == "number" then
			local v25 = p22.phaseEndsAt - v_u_7.Now() + 0.5
			local v26 = math.floor(v25)
			if v26 >= 10 and v26 <= 900 then
				v_u_18 = v26
			end
		end
	end
	v_u_21 = v23
end)
function v_u_7.RoundsToWin() -- name: RoundsToWin
	-- upvalues: (copy) v_u_7
	local v27 = v_u_7.Match
	if v27 then
		local v28 = v27.roundsToWin
		if type(v28) == "number" then
			return v27.roundsToWin
		end
	end
	return v_u_7.DEFAULT_ROUNDS_TO_WIN
end
function v_u_7.Now() -- name: Now
	-- upvalues: (copy) v_u_3
	return v_u_3:GetServerTimeNow()
end
local v_u_29 = {}
function v_u_7.Get(p30) -- name: Get
	-- upvalues: (copy) v_u_29, (copy) v_u_6
	local v31 = v_u_29[p30]
	if v31 == nil then
		return v_u_6:GetAttribute(p30)
	else
		return v31
	end
end
function v_u_7.SetMockAttr(p32, p33) -- name: SetMockAttr
	-- upvalues: (copy) v_u_29, (copy) v_u_7
	v_u_29[p32] = p33
	v_u_7.AttrChanged:Fire(p32, v_u_7.Get(p32))
	if p32 == "Spectating" then
		v_u_7.WatchChanged:Fire(v_u_7.Watching())
	end
	if p32 == "State" then
		v_u_7.PlayerStateChanged:Fire(v_u_7.GetPlayerState())
	end
end
function v_u_7.ClearMockAttrs() -- name: ClearMockAttrs
	-- upvalues: (copy) v_u_29, (copy) v_u_7
	local v34 = {}
	for v35 in v_u_29 do
		table.insert(v34, v35)
	end
	table.clear(v_u_29)
	for _, v36 in v34 do
		v_u_7.AttrChanged:Fire(v36, v_u_7.Get(v36))
	end
	v_u_7.PlayerStateChanged:Fire(v_u_7.GetPlayerState())
end
for _, v_u_37 in {
	"State",
	"MatchId",
	"Team",
	"Alive",
	"Frozen",
	"Level",
	"XP",
	"Shells",
	"Streak",
	"CombatMode",
	"Trophies",
	"RankBest",
	"Queued",
	"QueuedAt",
	"QueueFound",
	"QueueFilled",
	"Spectating"
} do
	v_u_6:GetAttributeChangedSignal(v_u_37):Connect(function()
		-- upvalues: (copy) v_u_29, (copy) v_u_37, (copy) v_u_7, (copy) v_u_6
		if v_u_29[v_u_37] == nil then
			v_u_7.AttrChanged:Fire(v_u_37, v_u_6:GetAttribute(v_u_37))
			if v_u_37 == "Spectating" then
				v_u_7.WatchChanged:Fire(v_u_7.Watching())
			end
			if v_u_37 == "State" then
				v_u_7.PlayerStateChanged:Fire(v_u_7.GetPlayerState())
			end
		end
	end)
end
function v_u_7.GetPlayerState() -- name: GetPlayerState
	-- upvalues: (copy) v_u_7
	local v38 = v_u_7.Get("State")
	return (type(v38) ~= "string" or v38 == "") and "Lobby" or v38
end
function v_u_7.InMatch() -- name: InMatch
	-- upvalues: (copy) v_u_7
	return v_u_7.GetPlayerState() == "Match"
end
function v_u_7.Watching() -- name: Watching
	-- upvalues: (copy) v_u_7
	local v39 = v_u_7.Get("Spectating")
	local v40
	if type(v39) == "string" and v39 ~= "" then
		v40 = not v_u_7.InMatch()
	else
		v40 = false
	end
	return v40
end
function v_u_7.SeesMatch() -- name: SeesMatch
	-- upvalues: (copy) v_u_7
	return v_u_7.InMatch() or v_u_7.Watching()
end
function v_u_7.SeenMatchId() -- name: SeenMatchId
	-- upvalues: (copy) v_u_7
	local v41
	if v_u_7.InMatch() then
		v41 = v_u_7.Get("MatchId")
	else
		v41 = v_u_7.Get("Spectating")
	end
	return type(v41) ~= "string" and "" or v41
end
function v_u_7.MyId() -- name: MyId
	-- upvalues: (copy) v_u_6
	local v42 = v_u_6.UserId
	return "p" .. tostring(v42)
end
function v_u_7.MyTeam() -- name: MyTeam
	-- upvalues: (copy) v_u_7
	local v43 = v_u_7.Get("Team")
	if type(v43) == "number" and (v43 == 1 or v43 == 2) then
		return v43
	end
	local v44 = v_u_7.Match
	if v44 and v44.teams then
		local v45 = v_u_7.MyId()
		for v46 = 1, 2 do
			local v47 = v44.teams[v46]
			for _, v48 in v47 and v47.members or {} do
				if v48.id ~= v45 then
					continue
				end
				return v46
			end
		end
	end
	return 1
end
function v_u_7.IsAlive() -- name: IsAlive
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	if v_u_7.InMatch() then
		local v49 = v_u_7.Get("Alive")
		if v49 ~= nil then
			return v49 == true
		end
	end
	local v50 = v_u_6.Character
	if v50 then
		v50 = v50:FindFirstChildOfClass("Humanoid")
	end
	local v51
	if v50 == nil then
		v51 = false
	else
		v51 = v50.Health > 0
	end
	return v51
end
function v_u_7.Level() -- name: Level
	-- upvalues: (copy) v_u_7
	local v52 = v_u_7.Get("Level")
	local v53 = v_u_7.Profile.level
	local v54 = type(v53) ~= "number" and 1 or v53
	if type(v52) == "number" then
		return v52
	else
		return v54
	end
end
function v_u_7.Shells() -- name: Shells
	-- upvalues: (copy) v_u_7
	local v55 = v_u_7.Get("Shells")
	local v56 = v_u_7.Profile.shells
	local v57 = type(v56) ~= "number" and 0 or v56
	if type(v55) == "number" then
		return v55
	else
		return v57
	end
end
function v_u_7.Xp() -- name: Xp
	-- upvalues: (copy) v_u_7
	local v58 = v_u_7.Get("XP")
	local v59 = v_u_7.Profile.xp
	local v60 = type(v59) ~= "number" and 0 or v59
	if type(v58) == "number" then
		return v58
	else
		return v60
	end
end
local v_u_61 = false
function v_u_7.XpToNext(p62) -- name: XpToNext
	-- upvalues: (copy) v_u_7, (ref) v_u_61, (copy) v_u_2
	local v63 = p62 or v_u_7.Level()
	if p62 == nil then
		local v64 = v_u_7.Profile.xpToNext
		if type(v64) == "number" and v_u_7.Profile.xpToNext > 0 then
			return v_u_7.Profile.xpToNext
		end
	end
	if v_u_61 == false then
		v_u_61 = nil
		local v65 = v_u_2.Shared:FindFirstChild("Progression")
		if v65 and v65:IsA("ModuleScript") then
			local v66 = require
			local v67, v68 = pcall(v66, v65)
			if v67 and type(v68) == "table" then
				v_u_61 = v68
			end
		end
	end
	if v_u_61 then
		for _, v69 in {
			"XpToNext",
			"XpForLevel",
			"XPToNext",
			"XpRequired"
		} do
			local v70 = v_u_61[v69]
			if type(v70) ~= "function" then
				continue
			end
			local v71, v72 = pcall(v70, v63)
			if not v71 or (type(v72) ~= "number" or v72 <= 0) then
				continue
			end
			return v72
		end
	end
	return 100 + (v63 - 1) * 50
end
function v_u_7.Owns(p73) -- name: Owns
	-- upvalues: (copy) v_u_7
	local v74 = v_u_7.Profile.owned
	local v75
	if type(v74) == "table" then
		v75 = v74[p73] == true
	else
		v75 = false
	end
	return v75
end
function v_u_7.LoadoutSlotCount() -- name: LoadoutSlotCount
	-- upvalues: (copy) v_u_7
	local v76 = v_u_7.Profile.loadouts
	if type(v76) ~= "table" or #v76 < 1 then
		return 1
	end
	local v77 = #v76
	return math.min(v77, 5)
end
function v_u_7.ActiveLoadout() -- name: ActiveLoadout
	-- upvalues: (copy) v_u_7
	local v78 = v_u_7.Profile.activeLoadout
	local v79 = v_u_7.LoadoutSlotCount()
	return (type(v78) ~= "number" or (v78 < 1 or v78 > v79)) and 1 or math.floor(v78)
end
function v_u_7.HasLoadoutSlots() -- name: HasLoadoutSlots
	-- upvalues: (copy) v_u_7
	local v80 = v_u_7.Profile.loadouts
	local v81
	if type(v80) == "table" then
		v81 = #v_u_7.Profile.loadouts >= 1
	else
		v81 = false
	end
	return v81
end
function v_u_7.LoadoutName(p82) -- name: LoadoutName
	-- upvalues: (copy) v_u_7
	local v83 = v_u_7.Profile.loadoutNames
	local v84
	if type(v83) == "table" then
		v84 = v83[p82]
	else
		v84 = false
	end
	if type(v84) == "string" and v84 ~= "" then
		return v84
	else
		return "LOADOUT " .. p82
	end
end
function v_u_7.LoadoutCustomName(p85) -- name: LoadoutCustomName
	-- upvalues: (copy) v_u_7
	local v86 = v_u_7.Profile.loadoutNames
	local v87
	if type(v86) == "table" then
		v87 = v86[p85]
	else
		v87 = false
	end
	return type(v87) ~= "string" and "" or v87
end
function v_u_7.LoadoutSlot(p88) -- name: LoadoutSlot
	-- upvalues: (copy) v_u_7
	local v89 = v_u_7.Profile.loadouts
	if type(v89) == "table" then
		local v90 = v89[p88]
		if type(v90) == "table" then
			return v_u_7.NormalizeLoadout(v89[p88])
		end
	end
	return v_u_7.Loadout()
end
function v_u_7.Loadout() -- name: Loadout
	-- upvalues: (copy) v_u_7
	return v_u_7.NormalizeLoadout(v_u_7.Profile.loadout)
end
function v_u_7.NormalizeLoadout(p91) -- name: NormalizeLoadout
	-- upvalues: (copy) v_u_8
	if type(p91) ~= "table" then
		local v92 = v_u_8
		return {
			["items"] = table.clone(v92.items),
			["armor"] = v92.armor
		}
	end
	local v93 = p91.items
	if type(v93) ~= "table" then
		local v94 = {}
		for _, v95 in {
			"primary",
			"secondary",
			"melee",
			"utility"
		} do
			local v96 = p91[v95]
			if type(v96) ~= "string" then
				continue
			end
			local v97 = p91[v95]
			table.insert(v94, v97)
		end
		return {
			["items"] = nil,
			["armor"] = false,
			["items"] = v94
		}
	end
	local v98 = {
		["items"] = p91.items
	}
	local v99 = p91.armor
	local v100
	if type(v99) == "string" and p91.armor ~= "" then
		v100 = p91.armor
	else
		v100 = false
	end
	v98.armor = v100
	local v101 = p91.ammo
	local v102
	if type(v101) == "table" then
		v102 = p91.ammo
	else
		v102 = nil
	end
	v98.ammo = v102
	return v98
end
function v_u_7.SetProfile(p103, p104) -- name: SetProfile
	-- upvalues: (copy) v_u_7, (copy) v_u_11, (copy) v_u_8
	if type(p103) == "table" then
		local v105
		if p104 then
			v105 = v_u_7.Profile
		else
			v105 = v_u_11()
		end
		for v106, v107 in p103 do
			v105[v106] = v107
		end
		local v108 = v105.owned
		if type(v108) ~= "table" then
			v105.owned = {}
		end
		local v109 = v105.loadout
		if type(v109) ~= "table" then
			local v110 = v_u_8
			v105.loadout = {
				["items"] = table.clone(v110.items),
				["armor"] = v110.armor
			}
		end
		local v111 = v105.stats
		if type(v111) ~= "table" then
			v105.stats = v_u_11().stats
		end
		v_u_7.Profile = v105
		v_u_7.HasProfile = true
		v_u_7.ProfileChanged:Fire(v105)
	end
end
function v_u_7.Refresh() -- name: Refresh
	-- upvalues: (copy) v_u_5, (copy) v_u_7
	task.spawn(function()
		-- upvalues: (ref) v_u_5, (ref) v_u_7
		local v112, v113 = v_u_5.Invoke("GetProfile")
		if v112 and (type(v113) == "table" and not v_u_7.Mock) then
			v_u_7.SetProfile(v113)
		end
	end)
end
v_u_5.On("ProfileChanged", function(p114)
	-- upvalues: (copy) v_u_7
	if type(p114) == "table" and not v_u_7.Mock then
		v_u_7.SetProfile(p114)
	end
end)
local function v_u_127(p115) -- name: normalizeSnapshot
	-- upvalues: (copy) v_u_7
	if type(p115) ~= "table" then
		return nil
	end
	local v116 = p115.teams
	p115.teams = type(v116) ~= "table" and {} or p115.teams
	for v117 = 1, 2 do
		local v118 = p115.teams[v117]
		if type(v118) ~= "table" then
			v118 = {
				["name"] = nil,
				["score"] = 0,
				["members"] = nil,
				["name"] = v117 == 1 and "Wolf" or "Raven",
				["members"] = {}
			}
			p115.teams[v117] = v118
		end
		local v119 = v118.members
		v118.members = type(v119) ~= "table" and {} or v118.members
		local v120 = v118.score
		v118.score = type(v120) ~= "number" and 0 or v120
		local v121 = v118.name
		local v122
		if type(v121) == "string" then
			v122 = v118.name
		else
			v122 = "Tribe " .. v117
		end
		v118.name = v122
	end
	local v123 = p115.roundsToWin
	local v124 = v_u_7.DEFAULT_ROUNDS_TO_WIN
	if type(v123) == "number" then
		v124 = v123
	end
	p115.roundsToWin = v124
	local v125 = p115.round
	p115.round = type(v125) ~= "number" and 1 or v125
	local v126 = p115.phaseEndsAt
	p115.phaseEndsAt = type(v126) ~= "number" and 0 or v126
	return p115
end
function v_u_7.InjectSnapshot(p128) -- name: InjectSnapshot
	-- upvalues: (copy) v_u_7, (copy) v_u_127
	v_u_7.Match = v_u_127(p128)
	v_u_7.MatchChanged:Fire(v_u_7.Match)
end
function v_u_7.FindMember(p129) -- name: FindMember
	-- upvalues: (copy) v_u_7
	local v130 = v_u_7.Match
	if not v130 or type(p129) ~= "string" then
		return nil, nil
	end
	for v131 = 1, 2 do
		for _, v132 in v130.teams[v131].members do
			if v132.id ~= p129 then
				continue
			end
			return v132, v131
		end
	end
	return nil, nil
end
function v_u_7.IsAllyTeam(p133) -- name: IsAllyTeam
	-- upvalues: (copy) v_u_7
	return p133 == v_u_7.MyTeam()
end
function v_u_7.InjectEvent(p134, p135) -- name: InjectEvent
	-- upvalues: (copy) v_u_7
	if type(p134) == "string" then
		local v136 = type(p135) ~= "table" and {} or p135
		local v137 = v_u_7.Match
		if p134 == "Elimination" and v137 then
			local v138 = v_u_7.FindMember(v136.victimId)
			if v138 and v138.alive ~= false then
				v138.alive = false
				v_u_7.MatchChanged:Fire(v137)
			end
		elseif p134 == "RoundStart" and v137 then
			for _, v139 in v137.teams[1].members do
				v139.alive = true
			end
			for _, v140 in v137.teams[2].members do
				v140.alive = true
			end
			v_u_7.MatchChanged:Fire(v137)
		end
		v_u_7.MatchEvent:Fire(p134, v136)
	end
end
v_u_5.On("MatchState", function(p141)
	-- upvalues: (copy) v_u_7
	if not v_u_7.Mock then
		v_u_7.InjectSnapshot(p141)
	end
end)
v_u_5.On("MatchEvent", function(p142, p143)
	-- upvalues: (copy) v_u_7
	if not v_u_7.Mock then
		v_u_7.InjectEvent(p142, p143)
	end
end)
function v_u_7.FetchMatch() -- name: FetchMatch
	-- upvalues: (copy) v_u_5, (copy) v_u_7
	task.spawn(function()
		-- upvalues: (ref) v_u_5, (ref) v_u_7
		local v144, v145 = v_u_5.Invoke("GetMatchState")
		if v144 and (type(v145) == "table" and not v_u_7.Mock) then
			v_u_7.InjectSnapshot(v145)
		end
	end)
end
function v_u_7.PhaseTimeLeft() -- name: PhaseTimeLeft
	-- upvalues: (copy) v_u_7, (copy) v_u_3
	local v146 = v_u_7.Match
	local v147 = v146 and (v146.phaseEndsAt or 0) or 0
	if (not v147 or v147 <= 0) and (v146 and v146.matchId) then
		local v148 = v_u_3:FindFirstChild("Arenas")
		if v148 then
			local v149 = v146.matchId
			v148 = v148:FindFirstChild((tostring(v149)))
		end
		if v148 then
			v148 = v148:GetAttribute("PhaseEndsAt")
		end
		v147 = type(v148) ~= "number" and 0 or v148
	end
	local v150 = (v147 or 0) - v_u_7.Now()
	return math.max(0, v150)
end
function v_u_7.Phase() -- name: Phase
	-- upvalues: (copy) v_u_7
	local v151 = v_u_7.Match
	return v151 and v151.phase or nil
end
local v_u_152 = nil
local v_u_153 = nil
function v_u_7.PhaseClock() -- name: PhaseClock
	-- upvalues: (copy) v_u_7, (ref) v_u_153, (ref) v_u_152, (copy) v_u_3
	local v154 = v_u_7.Match
	if not v_u_7.Mock then
		local v155 = v_u_7.Get("MatchId")
		if type(v155) == "string" and v155 ~= "" then
			if v_u_153 ~= v155 or (not v_u_152 or v_u_152.Parent == nil) then
				local v156 = v_u_3:FindFirstChild("Arenas")
				if v156 then
					v156 = v156:FindFirstChild(v155)
				end
				v_u_152 = v156
				if not v_u_152 then
					v155 = nil
				end
				v_u_153 = v155
			end
			local v157 = v_u_152
			if v157 then
				local v158 = v157:GetAttribute("Phase")
				if type(v158) == "string" then
					local v159 = v157:GetAttribute("PhaseEndsAt")
					local v160 = v157:GetAttribute("Round")
					local v161 = type(v159) ~= "number" and 0 or v159
					if type(v160) == "number" then
						return v158, v161, v160
					else
						return v158, v161, v154 and v154.round or 1
					end
				end
			end
		end
	end
	if v154 then
		return v154.phase, v154.phaseEndsAt or 0, v154.round or 1
	else
		return nil, 0, 1
	end
end
v_u_5.On("Leaderboards", function(p162)
	-- upvalues: (copy) v_u_7
	if type(p162) == "table" and not v_u_7.Mock then
		v_u_7.Leaderboards = p162
		v_u_7.LeaderboardsChanged:Fire(p162)
	end
end)
function v_u_7.InjectLeaderboards(p163) -- name: InjectLeaderboards
	-- upvalues: (copy) v_u_7
	v_u_7.Leaderboards = p163
	v_u_7.LeaderboardsChanged:Fire(p163)
end
v_u_5.On("Notify", function(p164, p165)
	-- upvalues: (copy) v_u_7
	v_u_7.Notify:Fire(p164, p165)
end)
function v_u_7.Start() -- name: Start
	-- upvalues: (copy) v_u_7
	v_u_7.Refresh()
	task.spawn(function()
		-- upvalues: (ref) v_u_7
		for _ = 1, 6 do
			task.wait(2.5)
			if v_u_7.HasProfile then
				break
			end
			v_u_7.Refresh()
		end
	end)
	if v_u_7.InMatch() then
		v_u_7.FetchMatch()
	end
	v_u_7.PlayerStateChanged:Connect(function(p166)
		-- upvalues: (ref) v_u_7
		if p166 == "Match" then
			v_u_7.FetchMatch()
		elseif p166 == "Lobby" and not (v_u_7.Mock or v_u_7.Watching()) then
			v_u_7.Match = nil
			v_u_7.MatchChanged:Fire(nil)
			v_u_7.Refresh()
		end
	end)
	v_u_7.WatchChanged:Connect(function(p167)
		-- upvalues: (ref) v_u_7
		if p167 then
			v_u_7.FetchMatch()
		elseif not (v_u_7.InMatch() or v_u_7.Mock) then
			v_u_7.Match = nil
			v_u_7.MatchChanged:Fire(nil)
		end
	end)
	if v_u_7.Watching() then
		v_u_7.FetchMatch()
	end
end
return v_u_7