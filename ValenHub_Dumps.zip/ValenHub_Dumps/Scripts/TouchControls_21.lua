local v_u_1 = game:GetService("GuiService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game:GetService("UserInputService")
local v_u_7 = require(v3:WaitForChild("Shared"):WaitForChild("Camera"))
local v_u_8 = require(v3:WaitForChild("Shared"):WaitForChild("TouchStart"))
local v_u_9 = require(script.Parent:WaitForChild("Movement"))
local v10 = {}
local v_u_11 = v2.LocalPlayer
local v_u_12 = Color3.fromRGB(18, 20, 26)
local v_u_13 = Color3.fromRGB(36, 40, 50)
local v_u_14 = Color3.fromRGB(40, 150, 255)
local v_u_15 = Color3.fromRGB(255, 255, 255)
local v_u_16 = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Heavy)
local v_u_17 = nil
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = false
local v_u_23 = false
local v_u_24 = false
local v_u_25 = {
	["Spectate"] = true,
	["FreeCursor"] = true
}
local function v_u_32(p26, p27, p28) -- name: makeButton
	-- upvalues: (copy) v_u_12, (copy) v_u_15, (copy) v_u_16
	local v29 = Instance.new("TextButton")
	v29.Name = p27
	v29.AnchorPoint = Vector2.new(0.5, 0.5)
	v29.BackgroundColor3 = v_u_12
	v29.BackgroundTransparency = 0.3
	v29.AutoButtonColor = false
	v29.Text = p28
	v29.TextColor3 = v_u_15
	v29.FontFace = v_u_16
	v29.Active = true
	v29.Selectable = false
	local v30 = Instance.new("UICorner")
	v30.CornerRadius = UDim.new(1, 0)
	v30.Parent = v29
	local v31 = Instance.new("UIStroke")
	v31.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v31.Thickness = 2
	v31.Color = v_u_15
	v31.Transparency = 0.8
	v31.Parent = v29
	Instance.new("UIScale").Parent = v29
	v29.Parent = p26
	return v29
end
local function v_u_39(p33, p34) -- name: setPressed
	-- upvalues: (copy) v_u_13, (copy) v_u_12, (copy) v_u_14, (copy) v_u_15, (ref) v_u_24, (copy) v_u_5
	local v35
	if p34 then
		v35 = v_u_13
	else
		v35 = v_u_12
	end
	p33.BackgroundColor3 = v35
	p33.BackgroundTransparency = p34 and 0.12 or 0.3
	local v36 = p33:FindFirstChildOfClass("UIStroke")
	if v36 then
		local v37
		if p34 then
			v37 = v_u_14
		else
			v37 = v_u_15
		end
		v36.Color = v37
		v36.Thickness = p34 and 3 or 2
		v36.Transparency = p34 and 0 or (v_u_24 and 0.92 or 0.8)
	end
	local v38 = p33:FindFirstChildOfClass("UIScale")
	if v38 then
		v_u_5:Create(v38, TweenInfo.new(p34 and 0.06 or 0.12, Enum.EasingStyle.Quad), {
			["Scale"] = p34 and 0.92 or 1
		}):Play()
	end
end
local function v_u_47(p_u_40, p_u_41, p_u_42) -- name: bindHold
	-- upvalues: (copy) v_u_8, (copy) v_u_39, (copy) v_u_6
	local v_u_43 = nil
	p_u_40.InputBegan:Connect(function(p44)
		-- upvalues: (ref) v_u_43, (ref) v_u_8, (copy) p_u_40, (ref) v_u_39, (copy) p_u_41
		local v45 = p44.UserInputType
		if v45 == Enum.UserInputType.Touch or v45 == Enum.UserInputType.MouseButton1 then
			if not v_u_43 and v_u_8.BeganOn(p_u_40, p44) then
				v_u_43 = p44
				v_u_39(p_u_40, true)
				p_u_41()
			end
		else
			return
		end
	end)
	v_u_6.InputEnded:Connect(function(p46)
		-- upvalues: (ref) v_u_43, (ref) v_u_39, (copy) p_u_40, (copy) p_u_42
		if p46 == v_u_43 then
			v_u_43 = nil
			v_u_39(p_u_40, false)
			p_u_42()
		end
	end)
	p_u_40:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) p_u_40, (ref) v_u_43, (ref) v_u_39, (copy) p_u_42
		if not p_u_40.Visible and v_u_43 then
			v_u_43 = nil
			v_u_39(p_u_40, false)
			p_u_42()
		end
	end)
end
local function v_u_58(p48, p49, p50, p51) -- name: readOverride
	local v52 = p48:GetAttribute("Override_" .. p49)
	if type(v52) ~= "string" then
		return nil, nil
	end
	local v53, v54, v55 = string.match(v52, "^(%-?%d+),(%-?%d+),(%d+)$")
	if not v53 then
		return nil, nil
	end
	local v56 = tonumber(v55) / 1000 * p51 + 0.5
	local v57 = math.floor(v56)
	return UDim2.fromOffset(tonumber(v53) / 1000 * p50.X, tonumber(v54) / 1000 * p50.Y), math.max(v57, 24)
end
local function v_u_96() -- name: layout
	-- upvalues: (ref) v_u_18, (ref) v_u_19, (ref) v_u_20, (ref) v_u_21, (ref) v_u_17, (copy) v_u_58
	local v59 = v_u_18
	local v60 = v_u_19
	local v61 = v_u_20
	local v62 = v_u_21
	if v59 and (v60 and (v61 and (v62 and v_u_17))) then
		local v63 = v59.AbsoluteSize
		if v63.X >= 10 and v63.Y >= 10 then
			local v64 = v63.X
			local v65 = v63.Y
			local v66 = math.min(v64, v65) / 360
			local v67 = math.clamp(v66, 0.85, 1.45)
			local v68 = v67 * 84
			local v69 = math.floor(v68)
			local v70 = v67 * 64
			local v71 = math.floor(v70)
			local v72 = v63.X - v67 * 18 - v69 / 2
			local v73 = v63.Y - v67 * 14 - v69 / 2
			v60.Size = UDim2.fromOffset(v69, v69)
			v60.Position = UDim2.fromOffset(v72, v73)
			local v74 = v67 * 17
			v60.TextSize = math.floor(v74)
			local v75 = v72 - v69 / 2 - v67 * 14 - v71 / 2
			local v76 = v63.Y - v67 * 14 - v71 / 2
			v61.Size = UDim2.fromOffset(v71, v71)
			v61.Position = UDim2.fromOffset(v75, v76)
			local v77 = v67 * 14
			v61.TextSize = math.floor(v77)
			local v78 = v67 * 48
			local v79 = math.floor(v78)
			local v80 = math.max(44, v79)
			v62.Size = UDim2.fromOffset(v80, v80)
			v62.Position = UDim2.fromOffset(v75 - v71 / 2 - v67 * 14 - v80 / 2, v63.Y - v67 * 14 - v80 / 2)
			local v81 = v67 * 13
			v62.TextSize = math.floor(v81)
			for _, v82 in { v60, v61, v62 } do
				v82:SetAttribute("DefaultSize", v82.Size.X.Offset)
				local v83, v84 = v_u_58(v_u_17, v82.Name, v63, v82.Size.X.Offset)
				if not (v83 and v84) then
					continue
				end
				v82.Position = v83
				v82.Size = UDim2.fromOffset(v84, v84)
				local v85 = v84 * 0.2
				v82.TextSize = math.floor(v85)
			end
			local v86 = (1 / 0)
			local v87 = (1 / 0)
			for _, v88 in { v60, v61, v62 } do
				local v89 = v88.Position.X.Offset - v88.Size.X.Offset / 2
				v86 = math.min(v86, v89)
				local v90 = v88.Position.Y.Offset - v88.Size.Y.Offset / 2
				v87 = math.min(v87, v90)
			end
			local v91 = v59.AbsolutePosition
			v_u_17:SetAttribute("Scale", v67)
			local v92 = v_u_17
			local v93 = v91.X + v86 - v67 * 10
			v92:SetAttribute("ReservedMinX", (math.floor(v93)))
			local v94 = v_u_17
			local v95 = v91.Y + v87 - v67 * 10
			v94:SetAttribute("ReservedMinY", (math.floor(v95)))
		end
	else
		return
	end
end
local function v_u_100() -- name: touchPreferred
	-- upvalues: (copy) v_u_6
	local function v97()
		-- upvalues: (ref) v_u_6
		return v_u_6.PreferredInput
	end
	local v98, v99 = pcall(v97)
	if v98 and typeof(v99) == "EnumItem" then
		return v99.Name == "Touch"
	elseif v_u_6.TouchEnabled then
		return v_u_6:GetLastInputType() == Enum.UserInputType.Touch and true or not v_u_6.KeyboardEnabled
	else
		return false
	end
end
local function v_u_102() -- name: robloxJumpButton
	-- upvalues: (copy) v_u_11
	local v101 = v_u_11:FindFirstChildOfClass("PlayerGui")
	if v101 then
		v101 = v101:FindFirstChild("TouchGui")
	end
	if v101 then
		v101 = v101:FindFirstChild("TouchControlFrame")
	end
	if v101 then
		v101 = v101:FindFirstChild("JumpButton")
	end
	if v101 and v101:IsA("GuiObject") then
		return v101
	else
		return nil
	end
end
local v_u_103 = nil
local function v_u_105() -- name: enforceRobloxJump
	-- upvalues: (copy) v_u_102, (ref) v_u_103, (ref) v_u_23
	local v_u_104 = v_u_102()
	if v_u_104 then
		if v_u_104 ~= v_u_103 then
			v_u_103 = v_u_104
			v_u_104:GetPropertyChangedSignal("Visible"):Connect(function()
				-- upvalues: (ref) v_u_23, (copy) v_u_104
				if v_u_23 and v_u_104.Visible then
					v_u_104.Visible = false
				end
			end)
		end
		if v_u_23 and v_u_104.Visible then
			v_u_104.Visible = false
		end
	end
end
local function v_u_127() -- name: refresh
	-- upvalues: (ref) v_u_17, (copy) v_u_4, (ref) v_u_23, (copy) v_u_100, (copy) v_u_11, (copy) v_u_1, (copy) v_u_7, (copy) v_u_25, (ref) v_u_22, (copy) v_u_9, (ref) v_u_21, (ref) v_u_24, (ref) v_u_19, (ref) v_u_20, (copy) v_u_14, (copy) v_u_105
	local v106 = v_u_17
	if not v106 then
		return
	end
	local v107 = v_u_4:IsStudio()
	if v107 then
		v107 = v106:GetAttribute("ForceVisible") == true
	end
	v_u_23 = v_u_100() or v107
	local v108, v109, v110, v111, v112, v113
	if v_u_23 then
		local v114 = v_u_11.Character
		if v114 then
			v114 = v114:FindFirstChildOfClass("Humanoid")
		end
		local v115
		if v114 and v114.Health > 0 then
			local v116
			if v_u_11:GetAttribute("State") == "Match" then
				v116 = v_u_11:GetAttribute("Alive") == false
			else
				v116 = false
			end
			v115 = not v116
		else
			v115 = false
		end
		if v115 then
			local v117
			if v_u_11:GetAttribute("MenuOpen") == true or v_u_1.MenuIsOpen then
				v117 = true
			else
				for _, v118 in v_u_7.GetUnlockReasons() do
					if v_u_25[v118] then
						continue
					end
					v117 = true
				end
				v117 = false
			end
			v108 = not v117
			if v108 then
				if v108 ~= v_u_22 then
					v_u_22 = v108
					v106.Enabled = v108
					if not v108 then
						v_u_9.SetJumpHeld(false)
						v_u_9.SetSlideHeld(false)
					end
				end
				v109 = v_u_21
				if v109 then
					v110 = v_u_22
					if v110 then
						v110 = v_u_7.GetMode() == "combat" and true or v106:GetAttribute("EditPreview") == true
					end
					if v109.Visible ~= v110 then
						v109.Visible = v110
					end
					v111 = v_u_7.IsFirstPerson and v_u_7.IsFirstPerson() and "1P" or "3P"
					if v109.Text ~= v111 then
						v109.Text = v111
					end
				end
				v112 = v_u_11:GetAttribute("Frozen") == true
				if v112 ~= v_u_24 then
					v_u_24 = v112
					for v125, v126 in { v_u_19, v_u_20 } do
						if not v126 then
							continue
						end
						v126.TextTransparency = v112 and 0.55 or 0
						v113 = v126:FindFirstChildOfClass("UIStroke")
						if not v113 or v113.Color == v_u_14 then
							continue
						end
						v113.Transparency = v112 and 0.92 or 0.8
					end
				end
				v_u_105()
			else
				if v106:GetAttribute("EditPreview") == true then
					v108 = true
				else
					v108 = false
				end
				if v108 ~= v_u_22 then
					v_u_22 = v108
					v106.Enabled = v108
					if not v108 then
						v_u_9.SetJumpHeld(false)
						v_u_9.SetSlideHeld(false)
					end
				end
				v109 = v_u_21
				if v109 then
					v110 = v_u_22
					if v110 then
						v110 = v_u_7.GetMode() == "combat" and true or v106:GetAttribute("EditPreview") == true
					end
					if v109.Visible ~= v110 then
						v109.Visible = v110
					end
					v111 = v_u_7.IsFirstPerson and v_u_7.IsFirstPerson() and "1P" or "3P"
					if v109.Text ~= v111 then
						v109.Text = v111
					end
				end
				v112 = v_u_11:GetAttribute("Frozen") == true
				if v112 ~= v_u_24 then
					v_u_24 = v112
					for v125, v126 in { v_u_19, v_u_20 } do
						if not v126 then
							continue
						end
						v126.TextTransparency = v112 and 0.55 or 0
						v113 = v126:FindFirstChildOfClass("UIStroke")
						if not v113 or v113.Color == v_u_14 then
							continue
						end
						v113.Transparency = v112 and 0.92 or 0.8
					end
				end
				v_u_105()
			end
		else
			if v106:GetAttribute("EditPreview") == true then
				v108 = true
			else
				v108 = false
			end
			if v108 ~= v_u_22 then
				v_u_22 = v108
				v106.Enabled = v108
				if not v108 then
					v_u_9.SetJumpHeld(false)
					v_u_9.SetSlideHeld(false)
				end
			end
			v109 = v_u_21
			if v109 then
				v110 = v_u_22
				if v110 then
					v110 = v_u_7.GetMode() == "combat" and true or v106:GetAttribute("EditPreview") == true
				end
				if v109.Visible ~= v110 then
					v109.Visible = v110
				end
				v111 = v_u_7.IsFirstPerson and v_u_7.IsFirstPerson() and "1P" or "3P"
				if v109.Text ~= v111 then
					v109.Text = v111
				end
			end
			v112 = v_u_11:GetAttribute("Frozen") == true
			if v112 ~= v_u_24 then
				v_u_24 = v112
				for v125, v126 in { v_u_19, v_u_20 } do
					if not v126 then
						continue
					end
					v126.TextTransparency = v112 and 0.55 or 0
					v113 = v126:FindFirstChildOfClass("UIStroke")
					if not v113 or v113.Color == v_u_14 then
						continue
					end
					v113.Transparency = v112 and 0.92 or 0.8
				end
			end
			v_u_105()
			return
		end
	else
		if v106:GetAttribute("EditPreview") == true then
			v108 = true
		else
			v108 = false
		end
		if v108 ~= v_u_22 then
			v_u_22 = v108
			v106.Enabled = v108
			if not v108 then
				v_u_9.SetJumpHeld(false)
				v_u_9.SetSlideHeld(false)
			end
		end
		v109 = v_u_21
		if v109 then
			v110 = v_u_22
			if v110 then
				v110 = v_u_7.GetMode() == "combat" and true or v106:GetAttribute("EditPreview") == true
			end
			if v109.Visible ~= v110 then
				v109.Visible = v110
			end
			v111 = v_u_7.IsFirstPerson and v_u_7.IsFirstPerson() and "1P" or "3P"
			if v109.Text ~= v111 then
				v109.Text = v111
			end
		end
		v112 = v_u_11:GetAttribute("Frozen") == true
		if v112 ~= v_u_24 then
			v_u_24 = v112
			for v125, v126 in { v_u_19, v_u_20 } do
				if not v126 then
					continue
				end
				v126.TextTransparency = v112 and 0.55 or 0
				v113 = v126:FindFirstChildOfClass("UIStroke")
				if not v113 or v113.Color == v_u_14 then
					continue
				end
				v113.Transparency = v112 and 0.92 or 0.8
			end
		end
		v_u_105()
		return
	end
end
function v10.IsVisible() -- name: IsVisible
	-- upvalues: (ref) v_u_22
	return v_u_22
end
local function v_u_130() -- name: gateRobloxTouch
	-- upvalues: (copy) v_u_11, (copy) v_u_4
	if v_u_11:GetAttribute("TouchControlsReady") ~= true then
		if not v_u_11.Character then
			v_u_11:SetAttribute("TouchControlsReady", false)
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_11, (ref) v_u_4
			if not v_u_11.Character then
				v_u_11.CharacterAdded:Wait()
			end
			local v128 = os.clock()
			local v129 = 0
			while v129 < 6 or os.clock() - v128 < 0.3 do
				v_u_4.RenderStepped:Wait()
				v129 = v129 + 1
			end
			v_u_11:SetAttribute("TouchControlsReady", true)
		end)
	end
end
local v_u_131 = false
function v10.Start() -- name: Start
	-- upvalues: (ref) v_u_131, (copy) v_u_130, (copy) v_u_11, (ref) v_u_18, (ref) v_u_19, (copy) v_u_32, (ref) v_u_20, (copy) v_u_47, (copy) v_u_9, (ref) v_u_21, (copy) v_u_7, (copy) v_u_127, (ref) v_u_17, (copy) v_u_96, (copy) v_u_6
	if not v_u_131 then
		v_u_131 = true
		v_u_130()
		local v132 = v_u_11:WaitForChild("PlayerGui")
		local v133 = Instance.new("ScreenGui")
		v133.Name = "CharacterTouch"
		v133.ResetOnSpawn = false
		v133.IgnoreGuiInset = true
		v133.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
		v133.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		v133.DisplayOrder = 3
		v133.Enabled = false
		local v134 = Instance.new("Frame")
		v134.Name = "Buttons"
		v134.BackgroundTransparency = 1
		v134.Size = UDim2.fromScale(1, 1)
		v134.Parent = v133
		v_u_18 = v134
		v_u_19 = v_u_32(v134, "Jump", "JUMP")
		v_u_20 = v_u_32(v134, "Slide", "SLIDE")
		v_u_47(v_u_19, function()
			-- upvalues: (ref) v_u_9
			v_u_9.SetJumpHeld(true)
		end, function()
			-- upvalues: (ref) v_u_9
			v_u_9.SetJumpHeld(false)
		end)
		v_u_47(v_u_20, function()
			-- upvalues: (ref) v_u_9
			v_u_9.SetSlideHeld(true)
		end, function()
			-- upvalues: (ref) v_u_9
			v_u_9.SetSlideHeld(false)
		end)
		v_u_21 = v_u_32(v134, "View", "3P")
		v_u_47(v_u_21, function()
			-- upvalues: (ref) v_u_7, (ref) v_u_127
			if v_u_7.ToggleFirstPerson then
				v_u_7.ToggleFirstPerson()
			end
			task.defer(v_u_127)
		end, function() end)
		v_u_17 = v133
		v133.Parent = v132
		v134:GetPropertyChangedSignal("AbsoluteSize"):Connect(v_u_96)
		v133.AttributeChanged:Connect(function(p135)
			-- upvalues: (ref) v_u_96, (ref) v_u_127
			if string.sub(p135, 1, 9) == "Override_" then
				v_u_96()
			elseif p135 == "EditPreview" then
				task.defer(v_u_127)
			end
		end)
		v134:GetPropertyChangedSignal("AbsolutePosition"):Connect(v_u_96)
		v_u_96()
		task.spawn(function()
			-- upvalues: (ref) v_u_127
			while true do
				local v136 = v_u_127
				pcall(v136)
				task.wait(0.1)
			end
		end)
		v_u_6.LastInputTypeChanged:Connect(function()
			-- upvalues: (ref) v_u_127
			task.defer(v_u_127)
		end)
	end
end
return v10