local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v3 = v1:WaitForChild("Shared")
local v_u_4 = require(v3:WaitForChild("Combat"))
local v_u_5 = {}
local v_u_6 = script.Parent.Parent
local v_u_7 = 5
local v_u_8 = 7
local v_u_9 = 21
local v_u_10 = 8
local v_u_11 = 0.03
local v_u_12 = 0.002617993877991494
local v13 = v3:FindFirstChild("Camera")
local v14 = v13
if v14 then
	v14 = v13:FindFirstChild("FirstPerson")
end
if v14 and v14:IsA("ModuleScript") then
	local v15 = require
	local v16, v17 = pcall(v15, v14)
	if v16 and type(v17) == "table" then
		local v18 = v17.EYE_EASE
		v_u_7 = tonumber(v18) or v_u_7
		local v19 = v17.STRIDE
		v_u_8 = tonumber(v19) or v_u_8
		local v20 = v17.BOB_SPEED
		v_u_9 = tonumber(v20) or v_u_9
		local v21 = v17.BOB_EASE
		v_u_10 = tonumber(v21) or v_u_10
		local v22 = v17.CAM_BOB_Y
		v_u_11 = tonumber(v22) or v_u_11
		local v23 = v17.CAM_BOB_ROLL
		v_u_12 = tonumber(v23) or v_u_12
	end
end
local v_u_24 = nil
local function v_u_30() -- name: viewModel
	-- upvalues: (ref) v_u_24, (copy) v_u_6
	if v_u_24 == nil then
		v_u_24 = false
		local v25 = v_u_6:FindFirstChild("Character")
		if v25 then
			v25 = v25:FindFirstChild("ViewModel")
		end
		if v25 and v25:IsA("ModuleScript") then
			local v26 = require
			local v27, v28 = pcall(v26, v25)
			if v27 and type(v28) == "table" then
				local v29 = v28.SetExternal
				if type(v29) == "function" then
					v_u_24 = v28
				end
			end
		end
	end
	return v_u_24 or nil
end
local v_u_31 = {
	["active"] = false,
	["params"] = nil,
	["eyeOff"] = nil,
	["phase"] = 0,
	["amount"] = 0,
	["speed"] = 0,
	["lastPos"] = nil,
	["hiddenModel"] = nil,
	["hiddenItem"] = nil,
	["lastBlock"] = false
}
local v_u_32 = {
	["valid"] = false,
	["yaw"] = 0,
	["pitch"] = 0,
	["fov"] = 70,
	["first"] = false,
	["aimCam"] = false,
	["eye"] = nil,
	["bobY"] = 0,
	["bobRoll"] = 0
}
local v_u_33 = {
	["dt"] = 0,
	["visible"] = false,
	["id"] = nil,
	["kind"] = nil,
	["charges"] = nil,
	["grounded"] = true,
	["rootY"] = 0,
	["sliding"] = false,
	["aiming"] = false,
	["bobPhase"] = 0,
	["bobAmount"] = 0,
	["wall"] = nil
}
function v_u_5.Begin(p34) -- name: Begin
	-- upvalues: (copy) v_u_5, (copy) v_u_31, (copy) v_u_30
	v_u_5.End()
	v_u_31.active = true
	v_u_31.params = p34
	v_u_31.eyeOff = nil
	local v35 = v_u_31
	local v36 = v_u_31
	local v37 = v_u_31
	v_u_31.phase = 0
	v35.amount = 0
	v36.speed = 0
	v37.lastPos = nil
	v_u_31.lastBlock = false
	local v38 = v_u_30()
	if v38 then
		local v39 = v38.SetExternal
		pcall(v39, true)
	end
end
local function v_u_43(p40, p41) -- name: setHidden
	if p40 then
		for _, v42 in p40:GetDescendants() do
			if not (v42:IsA("BasePart") or v42:IsA("Decal")) then
				continue
			end
			v42.LocalTransparencyModifier = p41 and 1 or 0
		end
	end
end
function v_u_5.End() -- name: End
	-- upvalues: (copy) v_u_31, (copy) v_u_43, (copy) v_u_30
	if v_u_31.active then
		v_u_31.active = false
		v_u_43(v_u_31.hiddenModel, false)
		v_u_31.hiddenModel = nil
		local v44 = v_u_30()
		if v44 then
			local v45 = v44.SetExternal
			pcall(v45, false)
		end
	end
end
function v_u_5.OnFighterEvent(p46, p47, p48) -- name: OnFighterEvent
	-- upvalues: (copy) v_u_31, (copy) v_u_4, (copy) v_u_30
	if v_u_31.active then
		local v49 = p47.weaponId
		local v50
		if type(v49) == "string" then
			v50 = p47.weaponId
		else
			v50 = nil
		end
		local v51 = v_u_4.Kind(v50)
		local v52 = v_u_4.Tuning
		local v53, v54 = pcall(v52, v50)
		local v55 = (not v53 or type(v54) ~= "table") and {} or v54
		if p46 == "Swing" then
			if p47.heavy == true then
				local v56 = {}
				local v57 = v_u_30()
				if v57 and v_u_31.active then
					local v58 = v57.ExternalEvent
					pcall(v58, "Heavy", v56)
					return
				end
			elseif p47.lunge == true then
				local v59 = v55.lunge
				local v60
				if type(v59) == "table" then
					local v61 = v59.distance
					if type(v61) == "number" then
						local v62 = v59.speed
						v60 = (type(v62) ~= "number" or v59.speed <= 0) and 0.25 or v59.distance / v59.speed
					else
						v60 = 0.25
					end
				else
					v60 = 0.25
				end
				local v63 = {
					["time"] = v60
				}
				local v64 = v_u_30()
				if v64 and v_u_31.active then
					local v65 = v64.ExternalEvent
					pcall(v65, "Lunge", v63)
					return
				end
			else
				local v66 = p47.step
				local v67 = tonumber(v66) or 1
				local v68 = {
					["step"] = v67,
					["finisher"] = v67 >= 3
				}
				local v69 = v_u_30()
				if v69 and v_u_31.active then
					local v70 = v69.ExternalEvent
					pcall(v70, "Swing", v68)
					return
				end
			end
		elseif p46 == "Charge" then
			local v71 = p47.kind
			local v72 = tostring(v71)
			local v73 = p47.on == true
			if v72 == "Draw" then
				local v74 = {
					["on"] = v73,
					["time"] = v55.drawTime or 1
				}
				local v75 = v_u_30()
				if v75 and v_u_31.active then
					local v76 = v75.ExternalEvent
					pcall(v76, "Draw", v74)
					return
				end
			elseif v72 == "Throw" then
				local v77 = {
					["on"] = v73,
					["time"] = v55.drawTime or 0.5
				}
				local v78 = v_u_30()
				if v78 and v_u_31.active then
					local v79 = v78.ExternalEvent
					pcall(v79, "Windup", v77)
					return
				end
			elseif v72 == "Heavy" or v72 == "Lunge" then
				local v80
				if v72 == "Heavy" then
					v80 = v55.heavy
				else
					v80 = v55.lunge
				end
				local v81 = {
					["kind"] = v72,
					["on"] = v73,
					["time"] = type(v80) == "table" and (v80.charge or 0.6) or 0.6
				}
				local v82 = v_u_30()
				if v82 and v_u_31.active then
					local v83 = v82.ExternalEvent
					pcall(v83, "Charge", v81)
					return
				end
			end
		elseif p46 == "Projectile" then
			if v51 == "Bow" then
				local v84 = {
					["charge"] = p48
				}
				local v85 = v_u_30()
				if v85 and v_u_31.active then
					local v86 = v85.ExternalEvent
					pcall(v86, "Release", v84)
					return
				end
			elseif v_u_4.UsesAmmo(v51) then
				local v87 = {
					["kick"] = nil,
					["aimed"] = false,
					["kick"] = v55.kick or 2
				}
				local v88 = v_u_30()
				if v88 and v_u_31.active then
					local v89 = v88.ExternalEvent
					pcall(v89, "Fire", v87)
					return
				end
			else
				local v90 = {
					["charge"] = p48
				}
				local v91 = v_u_30()
				if v91 and v_u_31.active then
					local v92 = v91.ExternalEvent
					pcall(v92, "Throw", v90)
					return
				end
			end
		elseif p46 == "Reload" then
			local v93 = {}
			local v94 = p47.duration
			v93.time = tonumber(v94) or (v55.reloadTime or 1.2)
			local v95 = v_u_30()
			if v95 and v_u_31.active then
				local v96 = v95.ExternalEvent
				pcall(v96, "Reload", v93)
				return
			end
		elseif p46 == "Use" then
			local v97 = p47.position
			if typeof(v97) == "Vector3" then
				local v98 = {}
				local v99 = v_u_30()
				if v99 and v_u_31.active then
					local v100 = v99.ExternalEvent
					pcall(v100, "Place", v98)
					return
				end
			else
				local v101 = {
					["on"] = true,
					["time"] = nil
				}
				local v102 = p47.duration
				v101.time = tonumber(v102) or (v55.useTime or 1)
				local v103 = v_u_30()
				if v103 and v_u_31.active then
					local v104 = v103.ExternalEvent
					pcall(v104, "Use", v101)
					return
				end
			end
		elseif p46 == "Heal" then
			local v105 = {
				["on"] = false,
				["done"] = true
			}
			local v106 = v_u_30()
			if v106 and v_u_31.active then
				local v107 = v106.ExternalEvent
				pcall(v107, "Use", v105)
			end
		end
	end
end
function v_u_5.Hurt(p108, p109) -- name: Hurt
	-- upvalues: (copy) v_u_30, (copy) v_u_31
	local v110 = {
		["amount"] = p108,
		["blocked"] = p109
	}
	local v111 = v_u_30()
	if v111 and v_u_31.active then
		local v112 = v111.ExternalEvent
		pcall(v112, "Hurt", v110)
	end
end
function v_u_5.Frame(p113, p114, p115, p116) -- name: Frame
	-- upvalues: (copy) v_u_32, (copy) v_u_31, (ref) v_u_9, (ref) v_u_10, (ref) v_u_8, (ref) v_u_7, (ref) v_u_11, (ref) v_u_12
	local v117 = v_u_32
	local v118 = v_u_31.active and p114.present
	if v118 then
		local v119 = p114.view
		if not v119 then
			p116 = v119
		end
	else
		p116 = v118
	end
	v117.valid = p116
	local v120 = v_u_32
	local v121 = v_u_32
	local v122 = v_u_32
	local v123 = p114.viewYaw
	local v124 = p114.viewPitch
	local v125 = p114.fov
	v120.yaw = v123
	v121.pitch = v124
	v122.fov = v125
	v_u_32.first = p114.first == true
	v_u_32.aimCam = p114.aimCam == true
	v_u_32.eye = nil
	local v126 = v_u_32
	v_u_32.bobY = 0
	v126.bobRoll = 0
	if not p114.present then
		v_u_31.lastPos = nil
		return v_u_32
	end
	local v127 = p114.cf.Position
	local v128 = p114.flags
	local v129 = bit32.btest(v128, 2)
	local v130 = p114.flags
	local v131 = bit32.btest(v130, 4)
	local v132 = v_u_31.lastPos
	local v133
	if v132 and p113 > 0 then
		local v134 = v127 - v132
		local v135 = v134.X
		local v136 = v134.Z
		local v137 = Vector3.new(v135, 0, v136).Magnitude / p113
		v133 = v137 > 80 and 0 or v137
	else
		v133 = 0
	end
	v_u_31.lastPos = v127
	local v138 = v_u_31
	local v139 = v138.speed
	local v140 = v133 - v_u_31.speed
	local v141 = p113 * -12
	v138.speed = v139 + v140 * (1 - math.exp(v141))
	local v142
	if v129 and not v131 then
		local v143 = (v_u_31.speed - 1) / (v_u_9 - 1)
		v142 = math.clamp(v143, 0, 1.25)
	else
		v142 = 0
	end
	local v144 = v_u_31
	local v145 = v144.amount
	local v146 = v142 - v_u_31.amount
	local v147 = -v_u_10 * p113
	v144.amount = v145 + v146 * (1 - math.exp(v147))
	if v129 then
		v_u_31.phase = (v_u_31.phase + v133 * p113 / v_u_8 * 2 * 3.141592653589793) % 12.566370614359172
	end
	if v_u_32.valid and v_u_32.first then
		if p115 then
			p115 = p115:FindFirstChild("Head")
		end
		local v148 = (not (p115 and p115:IsA("BasePart")) and 1.5 or p115.Position.Y - v127.Y) + 0.25
		local v149 = v_u_31.eyeOff
		if v149 ~= nil then
			local v150 = v148 - v149
			local v151 = -v_u_7 * p113
			v148 = v149 + v150 * (1 - math.exp(v151))
		end
		v_u_31.eyeOff = v148
		local v152 = v_u_32.yaw
		local v153 = -math.sin(v152)
		local v154 = v_u_32.yaw
		local v155 = -math.cos(v154)
		local v156 = Vector3.new(v153, 0, v155)
		v_u_32.eye = v127 + Vector3.new(0, v148, 0) - v156 * 0.3
		if p114.bobbing and v_u_31.amount > 0 then
			local v157 = v_u_32
			local v158 = v_u_31.phase * 2
			v157.bobY = -math.cos(v158) * 0.5 * v_u_11 * v_u_31.amount
			local v159 = v_u_32
			local v160 = v_u_31.phase
			v159.bobRoll = math.sin(v160) * v_u_12 * v_u_31.amount
		end
	else
		v_u_31.eyeOff = nil
	end
	return v_u_32
end
function v_u_5.AfterCamera(p161, p162, p163, p164, p165, p166, p167) -- name: AfterCamera
	-- upvalues: (copy) v_u_31, (copy) v_u_43, (copy) v_u_30, (copy) v_u_2, (copy) v_u_33, (copy) v_u_4
	if v_u_31.active then
		if p165 then
			if p164 then
				p164 = p162.present
			end
		else
			p164 = p165
		end
		if not p164 then
			p163 = nil
		end
		if p163 ~= v_u_31.hiddenModel or p163 and p166 ~= v_u_31.hiddenItem then
			if v_u_31.hiddenModel ~= p163 then
				v_u_43(v_u_31.hiddenModel, false)
			end
			v_u_43(p163, true)
			v_u_31.hiddenModel = p163
			v_u_31.hiddenItem = p166
		end
		local v168 = p162.flags
		local v169 = bit32.btest(v168, 8)
		if v169 ~= v_u_31.lastBlock then
			v_u_31.lastBlock = v169
			local v170 = {
				["on"] = v169
			}
			local v171 = v_u_30()
			if v171 and v_u_31.active then
				local v172 = v171.ExternalEvent
				pcall(v172, "Block", v170)
			end
		end
		local v173 = v_u_30()
		if v173 then
			local v174 = v_u_2.CurrentCamera
			local v175
			if p164 and (v174 and v_u_31.params) then
				local v176 = v_u_2:Spherecast(v174.CFrame.Position, 0.15, v174.CFrame.LookVector * 1.8, v_u_31.params)
				if v176 then
					v175 = v176.Distance
				else
					v175 = nil
				end
			else
				v175 = nil
			end
			v_u_33.dt = p161
			v_u_33.visible = p164
			v_u_33.id = p166
			local v177 = v_u_33
			local v178
			if p166 then
				v178 = v_u_4.Kind(p166)
			else
				v178 = nil
			end
			v177.kind = v178
			v_u_33.charges = p167
			local v179 = v_u_33
			local v180 = p162.flags
			v179.grounded = bit32.btest(v180, 2)
			v_u_33.rootY = p162.cf.Position.Y
			local v181 = v_u_33
			local v182 = p162.flags
			v181.sliding = bit32.btest(v182, 4)
			v_u_33.aiming = p162.aimCam == true
			v_u_33.bobPhase = v_u_31.phase
			v_u_33.bobAmount = v_u_31.amount
			v_u_33.wall = v175
			local v183 = v173.ExternalFrame
			local v184 = v_u_33
			pcall(v183, v184)
		end
	else
		return
	end
end
return v_u_5