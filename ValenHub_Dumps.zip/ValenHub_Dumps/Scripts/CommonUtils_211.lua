local v_u_5 = {
	["_mocks"] = {},
	["mock"] = function(p1, p2) -- name: mock
		-- upvalues: (copy) v_u_5
		v_u_5._mocks[p1] = p2
	end,
	["get"] = function(p3) -- name: get
		-- upvalues: (copy) v_u_5
		if v_u_5._mocks[p3] then
			return require(v_u_5._mocks[p3])
		end
		if script:FindFirstChild(p3) then
			return require(script:FindFirstChild(p3))
		end
		local v4 = "Util does not exist: " .. p3
		assert(false, v4)
	end
}
return v_u_5