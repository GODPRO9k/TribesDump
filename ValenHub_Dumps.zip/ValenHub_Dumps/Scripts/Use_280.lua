local v1 = script.Parent.Parent
local v_u_2 = require(v1.Util)
local v_u_3 = require(v1.Hud)
local v_u_4 = {}
v_u_4.__index = v_u_4
local v_u_5 = {
	["FullHealth"] = "ALREADY AT FULL HEALTH",
	["NoCharges"] = "NONE LEFT THIS ROUND",
	["BadSpot"] = "CAN\'T SET A TRAP THERE",
	["BadWallSpot"] = "CAN\'T BUILD THERE"
}
v_u_4.DENY_TEXT = v_u_5
function v_u_4.new(p6) -- name: new
	-- upvalues: (copy) v_u_4
	local v7 = v_u_4
	local v8 = setmetatable({}, v7)
	v8.ctx = p6
	v8.tuning = p6.tuning
	v8.preset = p6.preset
	v8.kind = p6.kind
	v8.using = false
	v8.token = 0
	v8.lastUse = (-1 / 0)
	v8.charges = 0
	v8.conns = {}
	v8.ghost = nil
	v8.spot = nil
	return v8
end
function v_u_4.Sync(p9) -- name: Sync
	-- upvalues: (copy) v_u_3
	local v10 = p9.ctx.tool:GetAttribute("Charges")
	if type(v10) == "number" then
		p9.charges = v10
	end
	v_u_3.SetPips(p9.charges, p9.tuning.charges or 0, p9.preset.color)
end
function v_u_4.Equip(p_u_11) -- name: Equip
	-- upvalues: (copy) v_u_3, (copy) v_u_2
	local v12 = p_u_11.ctx
	v_u_3.SetStyle("Use")
	p_u_11:Sync()
	v_u_2.PlayAnim(v12.animator, p_u_11.preset.hold, 1, 0.2)
	v_u_2.Sound(p_u_11.preset.equip or "Equip_Item", v12.root)
	local v13 = p_u_11.conns
	local v14 = v12.tool:GetAttributeChangedSignal("Charges")
	table.insert(v13, v14:Connect(function()
		-- upvalues: (copy) p_u_11
		p_u_11:Sync()
	end))
	if p_u_11.kind == "Trap" then
		local v15 = p_u_11.tuning.wall
		local v16 = Instance.new("Part")
		v16.Name = "TrapGhost"
		if type(v15) == "table" then
			local v17 = v15.width or 6
			local v18 = v15.height or 5
			v16.Size = Vector3.new(v17, v18, 0.9)
		else
			v16.Shape = Enum.PartType.Cylinder
			local v19 = (p_u_11.tuning.triggerRadius or 3) * 2
			local v20 = (p_u_11.tuning.triggerRadius or 3) * 2
			v16.Size = Vector3.new(0.1, v19, v20)
		end
		v16.Material = Enum.Material.SmoothPlastic
		v16.Anchored = true
		v16.CanCollide = false
		v16.CanQuery = false
		v16.CanTouch = false
		v16.CastShadow = false
		v16.Transparency = 1
		v16.Parent = workspace:FindFirstChild("FX") or workspace
		p_u_11.ghost = v16
	end
end
function v_u_4.Unequip(p21) -- name: Unequip
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	for _, v22 in p21.conns do
		v22:Disconnect()
	end
	table.clear(p21.conns)
	if p21.using then
		p21:Cancel()
	end
	if p21.ghost then
		p21.ghost:Destroy()
		p21.ghost = nil
	end
	v_u_2.StopAnim(p21.ctx.animator, p21.preset.hold, 0.15)
	v_u_3.SetPips(0, 0)
end
function v_u_4.Cancel(p23) -- name: Cancel
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v24 = p23.ctx
	p23.using = false
	p23.token = p23.token + 1
	v24.send("Use", {
		["tool"] = nil,
		["on"] = false,
		["tool"] = v24.tool
	})
	v24.emit("Use", {
		["on"] = false
	})
	v_u_2.StopAnim(v24.animator, p23.preset.use, 0.1)
	v24.setSpeed("Use", nil)
	v_u_3.StopChannel()
end
function v_u_4.TrapSpot(p25) -- name: TrapSpot
	-- upvalues: (copy) v_u_2
	local v26 = p25.ctx.root
	local v27 = p25.tuning.placeRange or 7
	local v28 = v_u_2.AimPoint(60)
	local v29 = v28.X - v26.Position.X
	local v30 = v28.Z - v26.Position.Z
	local v31 = Vector3.new(v29, 0, v30)
	if v27 < v31.Magnitude then
		v31 = v31.Unit * v27
	elseif v31.Magnitude < 2.5 then
		local v32 = v26.CFrame.LookVector.X
		local v33 = v26.CFrame.LookVector.Z
		v31 = Vector3.new(v32, 0, v33).Unit * 3.5
	end
	local v34 = v26.Position + v31 + Vector3.new(0, 3, 0)
	local v35 = workspace:Raycast(v34, Vector3.new(0, -12, 0), v_u_2.WorldParams(v_u_2.Targets()))
	if v35 and v35.Normal.Y >= (p25.tuning.wall and 0.75 or 0.6) then
		if workspace:Raycast(v26.Position, v35.Position + Vector3.new(0, 0.5, 0) - v26.Position, v_u_2.WorldParams(v_u_2.Targets())) then
			return nil
		else
			return v35.Position
		end
	else
		return nil
	end
end
function v_u_4.Activate(p_u_36) -- name: Activate
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_5
	local v_u_37 = p_u_36.ctx
	local v38 = os.clock()
	if p_u_36.using or (v38 - p_u_36.lastUse < (p_u_36.tuning.useTime or 0.5) + 0.1 or not v_u_2.CanAct()) then
		return
	elseif p_u_36.charges < 1 then
		v_u_2.Sound("Denied", v_u_37.root)
		v_u_3.Toast(v_u_5.NoCharges, Color3.fromRGB(255, 120, 90))
		return
	elseif p_u_36.kind == "Herbs" or p_u_36.kind == "Horn" then
		local v_u_39 = p_u_36.kind == "Horn"
		local v40 = v_u_37.hum
		if v_u_39 or v40.Health < v40.MaxHealth - 0.5 then
			p_u_36.lastUse = v38
			p_u_36.using = true
			p_u_36.token = p_u_36.token + 1
			local v_u_41 = p_u_36.token
			local v42 = p_u_36.tuning.useTime or 0.6
			v_u_37.send("Use", {
				["tool"] = nil,
				["on"] = true,
				["tool"] = v_u_37.tool
			})
			v_u_37.emit("Use", {
				["on"] = true,
				["time"] = nil,
				["time"] = v42
			})
			v_u_2.PlayAnim(v_u_37.animator, p_u_36.preset.use, 1, 0.1)
			v_u_2.Sound(p_u_36.preset.useSound or "Bandage_Wrap", v_u_37.root)
			v_u_37.setSpeed("Use", p_u_36.tuning.useSpeedMult or 0.6)
			v_u_3.StartChannel(p_u_36.preset.label or "USING", v42, p_u_36.preset.color)
			task.delay(v42, function()
				-- upvalues: (copy) p_u_36, (copy) v_u_41, (copy) v_u_37, (ref) v_u_2, (ref) v_u_3, (copy) v_u_39
				if p_u_36.token == v_u_41 and p_u_36.using then
					p_u_36.using = false
					v_u_37.emit("Use", {
						["on"] = false,
						["done"] = true
					})
					v_u_2.StopAnim(v_u_37.animator, p_u_36.preset.use, 0.15)
					v_u_37.setSpeed("Use", nil)
					v_u_3.StopChannel()
					if not v_u_39 then
						v_u_3.Flash(Color3.fromRGB(110, 220, 110), 0.35, 0.4)
						task.delay(p_u_36.tuning.healTime or 3, function()
							-- upvalues: (ref) v_u_37, (ref) v_u_2, (ref) p_u_36
							if v_u_37.alive() then
								v_u_2.Sound(p_u_36.preset.doneSound or "Heal_Done", v_u_37.root)
							end
						end)
					end
				else
					return
				end
			end)
		else
			v_u_2.Sound("Denied", v_u_37.root)
			v_u_3.Toast(v_u_5.FullHealth, Color3.fromRGB(255, 120, 90))
		end
	else
		if p_u_36.kind == "Trap" then
			local v43 = p_u_36:TrapSpot()
			if not v43 then
				v_u_2.Sound("Denied", v_u_37.root)
				local v44 = v_u_3.Toast
				local v45
				if p_u_36.tuning.wall then
					v45 = v_u_5.BadWallSpot
				else
					v45 = v_u_5.BadSpot
				end
				v44(v45, Color3.fromRGB(255, 120, 90))
				return
			end
			p_u_36.lastUse = v38
			local v_u_46 = v_u_2.PlayAnim(v_u_37.animator, p_u_36.preset.use, 1.6, 0.05)
			v_u_2.Sound(p_u_36.preset.useSound or "Trap_Set", v43)
			v_u_37.send("Use", {
				["tool"] = nil,
				["on"] = true,
				["position"] = nil,
				["tool"] = v_u_37.tool,
				["position"] = v43
			})
			v_u_37.emit("Place", nil)
			if v_u_2.InFirstPerson() then
				local v47 = v_u_37.char
				local v_u_48 = v47
				if v_u_48 then
					v_u_48 = v47:GetAttribute("CombatantId")
				end
				if type(v_u_48) ~= "string" or v_u_48 == "" then
					v_u_48 = "p" .. game:GetService("Players").LocalPlayer.UserId
				end
				local v_u_49 = v38 + 0.22
				local v_u_50 = {}
				local v51 = workspace:FindFirstChild("FX")
				if v51 then
					local v52 = v51.DescendantAdded
					local function v61(p53)
						-- upvalues: (ref) v_u_48, (copy) v_u_49, (copy) v_u_50
						if p53:IsA("Model") and (p53:GetAttribute("OwnerId") == v_u_48 and v_u_49 > os.clock()) then
							local function v57(p_u_54) -- name: hide
								-- upvalues: (ref) v_u_49
								if p_u_54:IsA("BasePart") then
									p_u_54.LocalTransparencyModifier = 1
									local v55 = task.delay
									local v56 = v_u_49 - os.clock()
									v55(math.max(0, v56), function()
										-- upvalues: (copy) p_u_54
										p_u_54.LocalTransparencyModifier = 0
									end)
								end
							end
							for _, v58 in p53:GetDescendants() do
								v57(v58)
							end
							local v59 = v_u_50
							local v60 = p53.DescendantAdded
							table.insert(v59, v60:Connect(v57))
						end
					end
					table.insert(v_u_50, v52:Connect(v61))
				end
				local v62 = workspace:FindFirstChild("Walls")
				if v62 then
					local v63 = v62.DescendantAdded
					table.insert(v_u_50, v63:Connect(function(p64)
						-- upvalues: (ref) v_u_48, (copy) v_u_49, (copy) v_u_50
						if p64:IsA("Model") and (p64:GetAttribute("OwnerId") == v_u_48 and v_u_49 > os.clock()) then
							local function v68(p_u_65) -- name: hide
								-- upvalues: (ref) v_u_49
								if p_u_65:IsA("BasePart") then
									p_u_65.LocalTransparencyModifier = 1
									local v66 = task.delay
									local v67 = v_u_49 - os.clock()
									v66(math.max(0, v67), function()
										-- upvalues: (copy) p_u_65
										p_u_65.LocalTransparencyModifier = 0
									end)
								end
							end
							for _, v69 in p64:GetDescendants() do
								v68(v69)
							end
							local v70 = v_u_50
							local v71 = p64.DescendantAdded
							table.insert(v70, v71:Connect(v68))
						end
					end))
				end
				task.delay(0.6, function()
					-- upvalues: (copy) v_u_50
					for _, v72 in v_u_50 do
						v72:Disconnect()
					end
				end)
				if p_u_36.tuning.wall then
					task.delay(0.2, v_u_2.Recoil, -5.5, 0)
				end
			end
			task.delay(0.45, function()
				-- upvalues: (copy) v_u_46
				if v_u_46 then
					v_u_46:Stop(0.15)
				end
			end)
		end
		return
	end
end
function v_u_4.Input(p73, p74, p75) -- name: Input
	if p74 == "Primary" and p75 then
		p73:Activate()
	end
end
function v_u_4.Update(p76, _) -- name: Update
	local v77 = p76.ghost
	if v77 then
		local v78
		if p76.charges >= 1 then
			v78 = p76:TrapSpot()
		else
			v78 = nil
		end
		local v79 = p76.tuning.wall
		if v78 and type(v79) == "table" then
			local v80 = p76.ctx.root
			local v81 = v78.X - v80.Position.X
			local v82 = v78.Z - v80.Position.Z
			local v83 = Vector3.new(v81, 0, v82)
			local v84
			if v83.Magnitude > 0.1 then
				v84 = v83.Unit
			else
				local v85 = v80.CFrame.LookVector.X
				local v86 = v80.CFrame.LookVector.Z
				v84 = Vector3.new(v85, 0, v86).Unit
			end
			v77.CFrame = CFrame.lookAt(v78, v78 + v84) * CFrame.new(0, (v79.height or 5) / 2, 0)
			v77.Color = Color3.fromRGB(214, 180, 130)
			v77.Transparency = 0.7
			return
		end
		if v78 then
			v77.CFrame = CFrame.new(v78 + Vector3.new(0, 0.06, 0)) * CFrame.Angles(0, 0, 1.5707963267948966)
			v77.Color = Color3.fromRGB(228, 232, 240)
			v77.Transparency = 0.55
			return
		end
		v77.Transparency = 1
	end
end
function v_u_4.OnDenied(p87, p88) -- name: OnDenied
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_5
	if p87.using then
		p87.using = false
		p87.token = p87.token + 1
		p87.ctx.emit("Use", {
			["on"] = false
		})
		v_u_2.StopAnim(p87.ctx.animator, p87.preset.use, 0.1)
		p87.ctx.setSpeed("Use", nil)
		v_u_3.StopChannel()
	end
	local v89
	if p88 == "BadSpot" and p87.tuning.wall then
		v89 = v_u_5.BadWallSpot
	else
		v89 = v_u_5[p88]
	end
	if v89 then
		v_u_3.Toast(v89, Color3.fromRGB(255, 120, 90))
	end
	p87:Sync()
end
function v_u_4.Interrupt(p90) -- name: Interrupt
	if p90.using then
		p90:Cancel()
	end
end
return v_u_4