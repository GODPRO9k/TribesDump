local v_u_1 = game:GetService("Lighting")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game:GetService("ContextActionService")
local v_u_7 = game:GetService("ProximityPromptService")
local v_u_8 = game:GetService("Workspace")
local v9 = {}
local v_u_10 = Font.new("rbxasset://fonts/families/Oswald.json", Enum.FontWeight.Bold)
local v_u_11 = Color3.fromRGB
local v_u_12 = {
	["drop"] = {
		["title"] = "DROP",
		["model"] = "Drop",
		["primary"] = nil,
		["deep"] = nil,
		["light"] = nil,
		["fit"] = 0.84,
		["rays"] = 0.8,
		["burst"] = 20,
		["sparkle"] = 5,
		["idle"] = 1.2,
		["wiggle"] = 5,
		["primary"] = v_u_11(116, 158, 222),
		["deep"] = v_u_11(16, 28, 54),
		["light"] = v_u_11(186, 212, 246)
	},
	["victory"] = {
		["title"] = "VICTORY DROP",
		["model"] = "Victory",
		["primary"] = nil,
		["deep"] = nil,
		["light"] = nil,
		["fit"] = 1,
		["rays"] = 0.68,
		["burst"] = 30,
		["sparkle"] = 8,
		["idle"] = 1.2,
		["wiggle"] = 6,
		["primary"] = v_u_11(40, 150, 255),
		["deep"] = v_u_11(8, 32, 84),
		["light"] = v_u_11(148, 206, 255)
	},
	["golden"] = {
		["title"] = "GOLDEN DROP",
		["model"] = "Golden",
		["primary"] = nil,
		["deep"] = nil,
		["light"] = nil,
		["fit"] = 0.98,
		["rays"] = 0.52,
		["burst"] = 54,
		["sparkle"] = 16,
		["idle"] = 1.55,
		["wiggle"] = 8,
		["legendary"] = true,
		["primary"] = v_u_11(255, 186, 46),
		["deep"] = v_u_11(92, 50, 4),
		["light"] = v_u_11(255, 226, 150)
	}
}
local v_u_13 = {
	["fall"] = 0.42,
	["settle"] = 0.5,
	["openCrouch"] = 0.1,
	["openHold"] = 0.6,
	["toCards"] = 0.42,
	["cardFly"] = 0.32,
	["flip"] = 0.2,
	["count"] = 0.42,
	["bar"] = 0.5,
	["dwell"] = 0.45,
	["cardOut"] = 0.16,
	["newItem"] = 2,
	["summaryAuto"] = nil,
	["hold"] = 0.55,
	["summaryAuto"] = {
		["match"] = 15,
		["lobby"] = 20,
		["robux"] = 20
	}
}
local v_u_14 = {
	["stageH"] = 780,
	["stageW"] = 1200,
	["titleY"] = -335,
	["chestY"] = 20,
	["chestCardY"] = 290,
	["chestCardScale"] = 0.46,
	["cardY"] = -64,
	["cardW"] = 232,
	["cardH"] = 322,
	["barY"] = 128,
	["barW"] = 330,
	["promptY"] = 332
}
local v_u_15 = {
	["small"] = 10,
	["medium"] = 20,
	["large"] = 40,
	["starter"] = 0
}
local v_u_16 = {
	["small"] = {
		10,
		20,
		40,
		80
	},
	["medium"] = {
		20,
		40,
		80,
		160
	},
	["large"] = {
		40,
		80,
		160,
		320
	},
	["starter"] = {
		10,
		20,
		40,
		80
	}
}
function v9.Init(p_u_17) -- name: Init
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_15, (copy) v_u_16, (copy) v_u_5, (copy) v_u_11, (copy) v_u_10, (copy) v_u_1, (copy) v_u_13, (copy) v_u_14, (copy) v_u_8, (copy) v_u_7, (copy) v_u_12, (copy) v_u_4, (copy) v_u_6
	local v_u_18 = p_u_17.UI
	local v_u_19 = p_u_17.Theme
	local v_u_20 = p_u_17.State
	local v_u_21 = p_u_17.WeaponInfo
	local v_u_22 = p_u_17.WeaponIcon
	local v_u_23 = v_u_19.Colors
	local v_u_24 = v_u_19.Fonts
	local v_u_25 = v_u_18.Assets.Fx or {}
	local v_u_26 = require(script.Parent.Parent.Fx)
	local v27 = require(v_u_3:WaitForChild("Shared"):WaitForChild("Signal"))
	local v_u_28 = v_u_2.LocalPlayer
	local v_u_29 = {
		["Changed"] = v27.new()
	}
	p_u_17.DropReveal = v_u_29
	local v_u_30 = v_u_3:WaitForChild("Shared")
	local v_u_31 = nil
	local v_u_32 = (-1 / 0)
	local function v_u_37() -- name: shards
		-- upvalues: (ref) v_u_31, (ref) v_u_32, (copy) v_u_30
		if v_u_31 then
			return v_u_31
		end
		if os.clock() - v_u_32 < 5 then
			return nil
		end
		v_u_32 = os.clock()
		local v33 = v_u_30:FindFirstChild("Shards")
		if v33 and v33:IsA("ModuleScript") then
			local v34 = require
			local v35, v36 = pcall(v34, v33)
			if v35 and type(v36) == "table" then
				v_u_31 = v36
			end
		end
		return v_u_31
	end
	local v_u_38 = nil
	local function v_u_48(p39) -- name: sizeOf
		-- upvalues: (ref) v_u_38, (copy) v_u_30
		if not v_u_38 then
			local v40 = v_u_30:FindFirstChild("Unlocks")
			local v41 = require
			local v42, v43 = pcall(v41, v40)
			v_u_38 = (not v42 or type(v43) ~= "table") and {} or v43
		end
		local v44 = v_u_38.SizeOf
		if type(v44) == "function" then
			local v45 = v_u_38.SizeOf
			local v46, v47 = pcall(v45, p39)
			if v46 and type(v47) == "string" then
				return v47
			end
		end
		return "medium"
	end
	local function v_u_56(p49, p50) -- name: upgradeCost
		-- upvalues: (copy) v_u_37, (ref) v_u_16, (copy) v_u_48
		local v51 = v_u_37()
		if v51 then
			local v52 = v51.UpgradeCost
			if type(v52) == "function" then
				local v53 = v51.UpgradeCost
				local v54, v55 = pcall(v53, p49, p50)
				if v54 then
					if type(v55) == "number" then
						return v55
					else
						return nil
					end
				end
			end
		end
		return (v_u_16[v_u_48(p49)] or v_u_16.medium)[p50]
	end
	local function v_u_64(p57) -- name: catColor
		-- upvalues: (copy) p_u_17, (copy) v_u_21, (copy) v_u_23
		local v58 = p_u_17.Economy
		if v58 then
			local v59 = v58.CategoryColor
			if type(v59) == "function" then
				local v60 = v58.CategoryColor
				local v61, v62 = pcall(v60, p57)
				if v61 and typeof(v62) == "Color3" then
					return v62
				end
			end
		end
		local v63 = v_u_21.Get(p57)
		return v63 and (v_u_21.CATEGORY_COLORS and v_u_21.CATEGORY_COLORS[v63.category]) or v_u_23.Accent
	end
	local function v_u_92(p65) -- name: normStack
		-- upvalues: (copy) v_u_37, (ref) v_u_15, (copy) v_u_48, (copy) v_u_56
		if type(p65) == "table" then
			local v66 = p65.item
			if type(v66) == "string" then
				local v67 = p65.item
				local v68 = p65.shards
				local v69 = tonumber(v68) or 0
				local v70 = math.floor(v69)
				local v71 = math.max(0, v70)
				local v72 = p65.before
				local v73 = tonumber(v72) or 0
				local v74 = math.floor(v73)
				local v75 = math.max(0, v74)
				local v76 = p65.levelBefore
				local v77 = tonumber(v76) or 0
				local v78 = math.floor(v77)
				local v79 = math.max(0, v78)
				local v80 = {
					["item"] = nil,
					["shards"] = nil,
					["before"] = nil,
					["levelBefore"] = nil,
					["need"] = nil,
					["unlocked"] = false,
					["ready"] = false,
					["surplus"] = 0,
					["needAfter"] = nil,
					["total"] = nil,
					["bonus"] = nil,
					["item"] = v67,
					["shards"] = v71,
					["before"] = v75,
					["levelBefore"] = v79,
					["total"] = v75 + v71,
					["bonus"] = p65.bonus == true
				}
				local v81 = p65.need
				local v82 = tonumber(v81)
				if v79 <= 0 then
					local v83, v84
					if v82 and v82 > 0 then
						v80.need = math.max(1, v82)
						v80.unlocked = p65.unlocked == true and true or v80.total >= v80.need
						if v80.unlocked then
							v83 = v80.total - v80.need
							v80.surplus = math.max(0, v83)
							v80.needAfter = v_u_56(v67, 1)
							if p65.ready == true then
								v84 = true
							elseif v80.needAfter == nil then
								v84 = false
							else
								v84 = v80.surplus >= v80.needAfter
							end
							v80.ready = v84
							return v80
						end
						return v80
					end
					local v85 = v_u_37()
					if v85 then
						local v86 = v85.UnlockCost
						if type(v86) == "function" then
							local v87 = v85.UnlockCost
							local v88
							v88, v82 = pcall(v87, v67)
							if v88 and type(v82) == "number" then
								v80.need = math.max(1, v82)
								v80.unlocked = p65.unlocked == true and true or v80.total >= v80.need
								if v80.unlocked then
									v83 = v80.total - v80.need
									v80.surplus = math.max(0, v83)
									v80.needAfter = v_u_56(v67, 1)
									if p65.ready == true then
										v84 = true
									elseif v80.needAfter == nil then
										v84 = false
									else
										v84 = v80.surplus >= v80.needAfter
									end
									v80.ready = v84
									return v80
								end
								return v80
							end
							v82 = v_u_15[v_u_48(v67)] or 20
						else
							v82 = v_u_15[v_u_48(v67)] or 20
						end
					else
						v82 = v_u_15[v_u_48(v67)] or 20
					end
					v80.need = math.max(1, v82)
					v80.unlocked = p65.unlocked == true and true or v80.total >= v80.need
					if v80.unlocked then
						v83 = v80.total - v80.need
						v80.surplus = math.max(0, v83)
						v80.needAfter = v_u_56(v67, 1)
						if p65.ready == true then
							v84 = true
						elseif v80.needAfter == nil then
							v84 = false
						else
							v84 = v80.surplus >= v80.needAfter
						end
						v80.ready = v84
						return v80
					end
					return v80
				else
					if v82 == nil then
						v80.need = v_u_56(v67, v79)
					else
						if v82 <= 0 then
							v82 = nil
						end
						v80.need = v82
					end
					local v89 = p65.after
					local v90 = tonumber(v89)
					if v90 and v75 <= v90 then
						v80.total = v90
					end
					local v91
					if p65.ready == true then
						v91 = true
					elseif v80.need == nil then
						v91 = false
					else
						v91 = v80.total >= v80.need
					end
					v80.ready = v91
					return v80
				end
			else
				return nil
			end
		else
			return nil
		end
	end
	local function v_u_103(p93) -- name: normReveal
		-- upvalues: (copy) v_u_92
		if type(p93) ~= "table" then
			return nil
		end
		local v94 = p93.kind ~= "golden" and p93.kind ~= "victory" and "drop" or p93.kind
		local v95 = {}
		local v96 = p93.stacks
		if type(v96) == "table" then
			for _, v97 in p93.stacks do
				local v98 = v_u_92(v97)
				if not v98 then
					continue
				end
				table.insert(v95, v98)
			end
		end
		local v99 = {}
		local v100 = p93.id or ""
		v99.id = tostring(v100)
		v99.kind = v94
		local v101 = p93.source
		v99.source = type(v101) ~= "string" and "match" or p93.source
		v99.stacks = v95
		local v102 = p93.xp
		v99.xp = tonumber(v102)
		v99.raw = p93
		return v99
	end
	v_u_29.Normalize = v_u_103
	local v104 = nil
	local v105 = script.Parent.Parent:FindFirstChild("DropModels")
	local v_u_106
	if v105 then
		local v107 = require
		local v108
		v108, v_u_106 = pcall(v107, v105)
		if not v108 or type(v_u_106) ~= "table" then
			v_u_106 = v104
		end
	else
		v_u_106 = v104
	end
	local v_u_109 = 1
	local v_u_110 = false
	local v_u_111 = {}
	local v_u_112 = nil
	local v_u_113 = 0
	local v_u_114 = false
	local function v_u_119(p115, p116) -- name: strokeFor
		local v117
		if p115:IsA("TextLabel") then
			v117 = p115:FindFirstChildWhichIsA("UIStroke")
		else
			v117 = nil
		end
		if v117 then
			local v118 = v117:GetAttribute("Authored")
			if type(v118) ~= "number" then
				v118 = v117.Transparency
				v117:SetAttribute("Authored", v118)
			end
			if p116 >= 0.99 then
				return v117, 1
			else
				return v117, v118 + (1 - v118) * p116
			end
		else
			return nil, 1
		end
	end
	local function v_u_135(p120, p121, p122, p123, p124, p125) -- name: tw
		-- upvalues: (ref) v_u_109, (ref) v_u_5, (ref) v_u_112, (copy) v_u_119
		local v126 = TweenInfo.new
		local v127 = p121 * v_u_109
		local v128 = v126(math.max(0, v127), p123 or Enum.EasingStyle.Quint, p124 or Enum.EasingDirection.Out, 0, false, (p125 or 0) * v_u_109)
		local v129 = v_u_5:Create(p120, v128, p122)
		v129:Play()
		if v_u_112 and v_u_112.group then
			local v130 = v_u_112.group
			table.insert(v130, { v129, p120, p122 })
		end
		if p122.TextTransparency ~= nil then
			local v131, v132 = v_u_119(p120, p122.TextTransparency)
			if v131 then
				local v133 = {
					["Transparency"] = v132
				}
				v_u_5:Create(v131, v128, v133):Play()
				if v_u_112 and v_u_112.group then
					local v134 = v_u_112.group
					table.insert(v134, { nil, v131, v133 })
				end
			end
		end
		return v129
	end
	local function v_u_139() -- name: finishGroup
		-- upvalues: (ref) v_u_112
		if v_u_112 and v_u_112.group then
			for _, v_u_136 in v_u_112.group do
				if v_u_136[1] then
					v_u_136[1]:Cancel()
				end
				for v_u_137, v_u_138 in v_u_136[3] do
					pcall(function()
						-- upvalues: (copy) v_u_136, (copy) v_u_137, (copy) v_u_138
						v_u_136[2][v_u_137] = v_u_138
					end)
				end
			end
			table.clear(v_u_112.group)
		end
	end
	local v_u_140 = {
		["y"] = 0,
		["yaw"] = 0,
		["roll"] = 0,
		["pitch"] = 0,
		["sq"] = 0,
		["lid"] = 0,
		["s"] = 1,
		["raysSpin"] = 8,
		["glow"] = 0
	}
	local v_u_141 = {}
	local v_u_149 = {
		["linear"] = function(p142) -- name: linear
			return p142
		end,
		["outQuad"] = function(p143) -- name: outQuad
			return 1 - (1 - p143) * (1 - p143)
		end,
		["inQuad"] = function(p144) -- name: inQuad
			return p144 * p144
		end,
		["outCubic"] = function(p145) -- name: outCubic
			return 1 - (1 - p145) ^ 3
		end,
		["inOutSine"] = function(p146) -- name: inOutSine
			local v147 = 3.141592653589793 * p146
			return -(math.cos(v147) - 1) / 2
		end,
		["outBack"] = function(p148) -- name: outBack
			return 1 + 2.9 * (p148 - 1) ^ 3 + 1.9 * (p148 - 1) ^ 2
		end
	}
	local function v_u_156(p150, p151) -- name: animate
		-- upvalues: (copy) v_u_149, (copy) v_u_141
		local v152 = {}
		for _, v153 in p151 do
			local v154 = {
				["to"] = nil,
				["dur"] = nil,
				["ease"] = nil,
				["delay"] = nil,
				["t"] = 0,
				["from"] = nil,
				["to"] = v153[1]
			}
			local v155 = v153[2]
			v154.dur = math.max(0.001, v155)
			v154.ease = v_u_149[v153[3] or "outQuad"] or v_u_149.outQuad
			v154.delay = v153[4] or 0
			table.insert(v152, v154)
		end
		v_u_141[p150] = v152
	end
	local function v_u_163(p157) -- name: stepAnims
		-- upvalues: (copy) v_u_141, (copy) v_u_140
		for v158, v159 in v_u_141 do
			local v160 = v159[1]
			if v160 then
				if v160.delay > 0 then
					v160.delay = v160.delay - p157
					if v160.delay > 0 then
						continue
					end
					p157 = -v160.delay
					v160.delay = 0
				end
				if v160.from == nil then
					v160.from = v_u_140[v158]
				end
				v160.t = v160.t + p157
				local v161 = v160.t / v160.dur
				local v162 = math.min(1, v161)
				v_u_140[v158] = v160.from + (v160.to - v160.from) * v160.ease(v162)
				if v162 < 1 then
					continue
				end
				table.remove(v159, 1)
				if #v159 ~= 0 then
					continue
				end
				v_u_141[v158] = nil
			else
				v_u_141[v158] = nil
			end
		end
	end
	local v_u_164 = {}
	local v_u_165 = nil
	local v_u_166 = CFrame.new()
	local v_u_167 = CFrame.new()
	local v_u_168 = CFrame.lookAt(Vector3.new(0, 4.8, -14), Vector3.new(0, 2.8, 0))
	local function v_u_215() -- name: build
		-- upvalues: (ref) v_u_110, (copy) v_u_18, (copy) p_u_17, (copy) v_u_111, (copy) v_u_23, (copy) v_u_25, (copy) v_u_26, (ref) v_u_11, (copy) v_u_168, (copy) v_u_19, (copy) v_u_24, (ref) v_u_10
		if not v_u_110 then
			v_u_110 = true
			local v169, v170 = v_u_18.Screen("TR_Reveal", 30, p_u_17.PlayerGui, {
				["fullBleed"] = true
			})
			v169.Enabled = true
			v_u_111.gui = v169
			v_u_111.canvas = v170
			local v171 = v_u_18.new("Frame", {
				["Name"] = "Reveal",
				["Size"] = nil,
				["Visible"] = false,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v170
			})
			v_u_111.root = v171
			v_u_111.dim = v_u_18.new("Frame", {
				["Name"] = "Dim",
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 1,
				["ZIndex"] = 1,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["BackgroundColor3"] = v_u_23.Void,
				["Parent"] = v171
			})
			v_u_111.tint = v_u_18.new("ImageLabel", {
				["Name"] = "Tint",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Image"] = nil,
				["ImageTransparency"] = 1,
				["ZIndex"] = 1,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromScale(1.3, 1.6),
				["Image"] = v_u_18.Assets.Icons.Glow or "",
				["Parent"] = v171
			})
			v_u_111.vignette = v_u_18.new("ImageLabel", {
				["Name"] = "Vignette",
				["Size"] = nil,
				["Image"] = nil,
				["ImageColor3"] = nil,
				["ImageTransparency"] = 1,
				["ScaleType"] = nil,
				["ZIndex"] = 2,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Image"] = v_u_25.Vignette or "",
				["ImageColor3"] = v_u_23.Void,
				["ScaleType"] = Enum.ScaleType.Stretch,
				["Parent"] = v171
			})
			v_u_111.flash = v_u_18.new("Frame", {
				["Name"] = "Flash",
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 1,
				["ZIndex"] = 20,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["BackgroundColor3"] = v_u_23.Accent,
				["Parent"] = v171
			})
			v_u_111.catcher = v_u_18.new("TextButton", {
				["Name"] = "Input",
				["Size"] = nil,
				["Modal"] = true,
				["Selectable"] = false,
				["ZIndex"] = 3,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v171
			})
			local v172 = v_u_18.new("Frame", {
				["Name"] = "Stage",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 4,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromOffset(0, 0),
				["Parent"] = v171
			})
			v_u_111.stage = v172
			v_u_111.stageScale = v_u_18.new("UIScale", {
				["Parent"] = v172
			})
			local v_u_173 = v_u_18.new("Frame", {
				["Name"] = "Shaker",
				["Size"] = nil,
				["ZIndex"] = 4,
				["Parent"] = nil,
				["Size"] = UDim2.fromOffset(0, 0),
				["Parent"] = v172
			})
			v_u_111.shaker = v_u_173
			local function v179(p174, p175, p176, p177) -- name: img
				-- upvalues: (copy) v_u_173, (ref) v_u_18
				local v178 = p177 or {}
				v178.Name = p174
				v178.AnchorPoint = v178.AnchorPoint or Vector2.new(0.5, 0.5)
				v178.Image = p175 or ""
				v178.ImageTransparency = v178.ImageTransparency == nil and 1 or v178.ImageTransparency
				v178.ZIndex = p176
				v178.Parent = v178.Parent or v_u_173
				return v_u_18.new("ImageLabel", v178)
			end
			v_u_111.raysHolder = v_u_18.new("Frame", {
				["Name"] = "RaysHolder",
				["Size"] = nil,
				["ZIndex"] = 4,
				["Parent"] = nil,
				["Size"] = UDim2.fromOffset(0, 0),
				["Parent"] = v_u_173
			})
			v_u_111.raysScale = v_u_18.new("UIScale", {
				["Parent"] = v_u_111.raysHolder
			})
			v_u_111.raysA = v179("RaysA", v_u_25.Rays, 4, {
				["Size"] = UDim2.fromOffset(1100, 1100),
				["Parent"] = v_u_111.raysHolder
			})
			v_u_111.raysB = v179("RaysB", v_u_25.RaysThin, 4, {
				["Size"] = UDim2.fromOffset(1250, 1250),
				["Parent"] = v_u_111.raysHolder
			})
			v_u_111.halo = v179("Halo", v_u_18.Assets.Icons.Glow, 5, {
				["Size"] = UDim2.fromOffset(620, 620),
				["Parent"] = v_u_111.raysHolder
			})
			v_u_111.backLayer = v_u_18.new("Frame", {
				["Name"] = "BackFx",
				["Size"] = nil,
				["ZIndex"] = 6,
				["Parent"] = nil,
				["Size"] = UDim2.fromOffset(0, 0),
				["Parent"] = v_u_173
			})
			v_u_111.backPool = v_u_26.Pool(v_u_111.backLayer, 60, 6)
			v_u_111.floorRing = v179("FloorRing", v_u_25.GlowRing, 6, {
				["Size"] = UDim2.fromOffset(200, 50)
			})
			v_u_111.shadow = v179("Shadow", v_u_18.Assets.Icons.Glow, 6, {
				["Size"] = UDim2.fromOffset(380, 76),
				["ImageColor3"] = v_u_23.Void
			})
			v_u_111.beam = v179("Beam", v_u_25.Beam, 7, {
				["AnchorPoint"] = Vector2.new(0.5, 1),
				["Size"] = UDim2.fromOffset(220, 620)
			})
			v_u_111.chestHolder = v_u_18.new("Frame", {
				["Name"] = "Chest",
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["ZIndex"] = 8,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Size"] = UDim2.fromOffset(600, 600),
				["Parent"] = v_u_173
			})
			v_u_111.chestScale = v_u_18.new("UIScale", {
				["Parent"] = v_u_111.chestHolder
			})
			v_u_111.chestGlow = v179("ChestGlow", v_u_18.Assets.Icons.Glow, 7, {
				["Size"] = UDim2.fromOffset(540, 460),
				["Position"] = UDim2.fromScale(0.5, 0.6),
				["Parent"] = v_u_111.chestHolder
			})
			local v180 = v_u_18.new("ViewportFrame", {
				["Name"] = "View",
				["Size"] = nil,
				["Ambient"] = nil,
				["LightColor"] = nil,
				["LightDirection"] = Vector3.new(0.45, -1, 0.55),
				["ZIndex"] = 8,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Ambient"] = v_u_11(150, 146, 150),
				["LightColor"] = v_u_11(255, 244, 228),
				["Parent"] = v_u_111.chestHolder
			})
			v_u_111.vpf = v180
			local v181 = Instance.new("Camera")
			v181.FieldOfView = 28
			v181.CFrame = v_u_168
			v181.Parent = v180
			v180.CurrentCamera = v181
			v_u_111.cam = v181
			v_u_111.leak = v179("Leak", v_u_18.Assets.Icons.Glow, 9, {
				["Size"] = UDim2.fromOffset(300, 90),
				["Parent"] = v_u_111.chestHolder
			})
			v_u_111.leakFlare = v179("LeakFlare", v_u_25.Flare, 9, {
				["Size"] = UDim2.fromOffset(420, 44),
				["Parent"] = v_u_111.chestHolder
			})
			v_u_111.counter = v_u_18.new("Frame", {
				["Name"] = "Counter",
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Size"] = UDim2.fromOffset(74, 50),
				["BackgroundColor3"] = v_u_23.Panel,
				["BackgroundTransparency"] = 0.05,
				["Visible"] = false,
				["ZIndex"] = 10,
				v_u_18.Corner(v_u_19.Radius.Pill),
				["Parent"] = v_u_173
			})
			v_u_111.counterStroke = v_u_18.Stroke(v_u_23.Accent, 2, 0.2)
			v_u_111.counterStroke.Parent = v_u_111.counter
			v_u_111.counterText = v_u_18.new("TextLabel", {
				["Size"] = nil,
				["Text"] = "x3",
				["FontFace"] = nil,
				["TextSize"] = 30,
				["ZIndex"] = 11,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["FontFace"] = v_u_24.Display,
				["Parent"] = v_u_111.counter
			})
			v_u_111.frontLayer = v_u_18.new("Frame", {
				["Name"] = "FrontFx",
				["Size"] = nil,
				["ZIndex"] = 14,
				["Parent"] = nil,
				["Size"] = UDim2.fromOffset(0, 0),
				["Parent"] = v_u_173
			})
			v_u_111.frontPool = v_u_26.Pool(v_u_111.frontLayer, 120, 14)
			local function v185(p182, p183, p184) -- name: headline
				-- upvalues: (ref) v_u_18, (ref) v_u_10, (ref) v_u_23, (copy) v_u_173
				return v_u_18.new("TextLabel", {
					["Name"] = nil,
					["AnchorPoint"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextTransparency"] = 1,
					["ZIndex"] = nil,
					["Parent"] = nil,
					["Name"] = p182,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Size"] = UDim2.fromOffset(1200, p183 * 1.2),
					["FontFace"] = v_u_10,
					["TextSize"] = p183,
					["TextColor3"] = v_u_23.Text,
					["ZIndex"] = p184,
					["Parent"] = v_u_173
				})
			end
			v_u_111.titleShadow = v185("TitleShadow", 64, 15)
			v_u_111.titleShadow.TextColor3 = v_u_23.Void
			v_u_111.title = v185("Title", 64, 16)
			v_u_111.titleScale = v_u_18.new("UIScale", {
				["Parent"] = v_u_111.title
			})
			v_u_111.titleShadowScale = v_u_18.new("UIScale", {
				["Parent"] = v_u_111.titleShadow
			})
			v_u_111.titleGrad = v_u_18.new("UIGradient", {
				["Rotation"] = 90,
				["Parent"] = nil,
				["Parent"] = v_u_111.title
			})
			v_u_111.subtitle = v_u_18.new("TextLabel", {
				["Name"] = "Subtitle",
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 22,
				["TextColor3"] = nil,
				["TextTransparency"] = 1,
				["ZIndex"] = 16,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Size"] = UDim2.fromOffset(800, 30),
				["FontFace"] = v_u_24.Heavy,
				["TextColor3"] = v_u_23.TextDim,
				["Parent"] = v_u_173
			})
			v_u_18.TextStroke(v_u_23.Void, 1.5, 0.5).Parent = v_u_111.subtitle
			local v186 = v_u_111.subtitle
			v186.TextTransparency = 1
			local v187
			if v186:IsA("TextLabel") then
				v187 = v186:FindFirstChildWhichIsA("UIStroke")
			else
				v187 = nil
			end
			local v188
			if v187 then
				local v189 = v187:GetAttribute("Authored")
				if type(v189) == "number" then
					v188 = 1
				else
					v187:SetAttribute("Authored", v187.Transparency)
					v188 = 1
				end
			else
				v187 = nil
				v188 = 1
			end
			if v187 then
				v187.Transparency = v188
			end
			v_u_111.prompt = v_u_18.new("Frame", {
				["Name"] = "OpenPrompt",
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Size"] = UDim2.fromOffset(190, 52),
				["BackgroundColor3"] = v_u_23.Panel,
				["BackgroundTransparency"] = 0.15,
				["Visible"] = false,
				["ZIndex"] = 16,
				["ClipsDescendants"] = true,
				v_u_18.Corner(v_u_19.Radius.Pill),
				["Parent"] = v_u_173
			})
			v_u_111.promptScale = v_u_18.GetScaleObj(v_u_111.prompt, "AnimScale")
			v_u_111.promptStroke = v_u_18.Stroke(v_u_23.Accent, 2, 0.25)
			v_u_111.promptStroke.Parent = v_u_111.prompt
			v_u_111.promptFill = v_u_18.new("Frame", {
				["Name"] = "Auto",
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.55,
				["ZIndex"] = 16,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(0, 1),
				["BackgroundColor3"] = v_u_23.Accent,
				["Parent"] = v_u_111.prompt
			})
			v_u_111.promptText = v_u_18.new("TextLabel", {
				["Size"] = nil,
				["Text"] = "OPEN",
				["FontFace"] = nil,
				["TextSize"] = 26,
				["ZIndex"] = 17,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["FontFace"] = v_u_24.Display,
				["Parent"] = v_u_111.prompt
			})
			local v190 = v_u_18.new("Frame", {
				["Name"] = "Card",
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["Visible"] = false,
				["ZIndex"] = 12,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Size"] = UDim2.fromOffset(232, 322),
				["Parent"] = v_u_173
			})
			v_u_111.card = v190
			v_u_111.cardScale = v_u_18.new("UIScale", {
				["Parent"] = v190
			})
			v_u_111.cardGlow = v179("CardGlow", v_u_18.Assets.Icons.Glow, 11, {
				["Size"] = UDim2.fromOffset(487.20000000000005, 611.8),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Parent"] = v190
			})
			local v191 = v_u_18.new("Frame", {
				["Name"] = "Back",
				["Size"] = UDim2.fromScale(1, 1),
				["BackgroundColor3"] = Color3.new(1, 1, 1),
				["ZIndex"] = 12,
				v_u_18.Corner(18),
				["Parent"] = v190
			})
			v_u_111.backGrad = v_u_18.new("UIGradient", {
				["Rotation"] = 90,
				["Parent"] = nil,
				["Parent"] = v191
			})
			v_u_111.backStroke = v_u_18.Stroke(v_u_23.Accent, 3, 0.1)
			v_u_111.backStroke.Parent = v191
			v_u_111.backArt = v179("Art", v_u_25.CardBack, 13, {
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["ImageTransparency"] = 0.15,
				["ScaleType"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.zero,
				["Size"] = UDim2.fromScale(1, 1),
				["ScaleType"] = Enum.ScaleType.Stretch,
				["Parent"] = v191
			})
			v_u_111.back = v191
			local v192 = v_u_18.new("Frame", {
				["Name"] = "Face",
				["Size"] = UDim2.fromScale(1, 1),
				["BackgroundColor3"] = Color3.new(1, 1, 1),
				["Visible"] = false,
				["ZIndex"] = 12,
				v_u_18.Corner(18),
				["Parent"] = v190
			})
			v_u_111.faceGrad = v_u_18.new("UIGradient", {
				["Rotation"] = 90,
				["Parent"] = nil,
				["Parent"] = v192
			})
			v_u_111.faceStroke = v_u_18.Stroke(v_u_23.Accent, 3, 0.05)
			v_u_111.faceStroke.Parent = v192
			v_u_111.face = v192
			local v193 = v_u_18.new("Frame", {
				["Name"] = "Well",
				["Position"] = UDim2.fromOffset(10, 10),
				["Size"] = UDim2.new(1, -20, 0, 206),
				["BackgroundColor3"] = v_u_23.Void,
				["BackgroundTransparency"] = 0.45,
				["ZIndex"] = 13,
				v_u_18.Corner(12),
				["Parent"] = v192
			})
			v_u_111.well = v193
			v_u_111.wellGlow = v179("WellGlow", v_u_18.Assets.Icons.Glow, 13, {
				["Size"] = nil,
				["Position"] = nil,
				["ImageTransparency"] = 0.5,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1.1, 1.1),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Parent"] = v193
			})
			v_u_111.icon = v_u_18.new("Frame", {
				["Name"] = "Icon",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 14,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromOffset(196, 196),
				["Parent"] = v193
			})
			v_u_111.iconScale = v_u_18.new("UIScale", {
				["Parent"] = v_u_111.icon
			})
			v_u_111.tag = v_u_18.new("Frame", {
				["Name"] = "Tag",
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.new(1, -6, 0, 6),
				["Size"] = UDim2.fromOffset(74, 26),
				["BackgroundColor3"] = v_u_23.Gold,
				["ZIndex"] = 15,
				v_u_18.Corner(v_u_19.Radius.Pill),
				["Parent"] = v193
			})
			v_u_111.tagText = v_u_18.new("TextLabel", {
				["Size"] = nil,
				["Text"] = "NEW",
				["FontFace"] = nil,
				["TextSize"] = 16,
				["TextColor3"] = nil,
				["ZIndex"] = 16,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["FontFace"] = v_u_24.Display,
				["TextColor3"] = v_u_23.TextDark,
				["Parent"] = v_u_111.tag
			})
			v_u_111.cat = v_u_18.new("TextLabel", {
				["Name"] = "Category",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "BOW",
				["FontFace"] = nil,
				["TextSize"] = 14,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["ZIndex"] = 16,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(10, 8),
				["Size"] = UDim2.fromOffset(150, 22),
				["FontFace"] = v_u_24.Heavy,
				["TextColor3"] = v_u_23.TextDim,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Parent"] = v193
			})
			v_u_111.name = v_u_18.new("TextLabel", {
				["Name"] = "ItemName",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 26,
				["TextColor3"] = nil,
				["TextTruncate"] = nil,
				["ZIndex"] = 14,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(12, 222),
				["Size"] = UDim2.new(1, -24, 0, 30),
				["FontFace"] = v_u_24.Display,
				["TextColor3"] = v_u_23.Text,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v192
			})
			v_u_18.TextStroke(v_u_23.Void, 1.5, 0.4).Parent = v_u_111.name
			v_u_111.count = v_u_18.new("Frame", {
				["Name"] = "Count",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 14,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 258),
				["Size"] = UDim2.fromOffset(160, 50),
				["Parent"] = v192
			})
			v_u_111.countScale = v_u_18.new("UIScale", {
				["Parent"] = v_u_111.count
			})
			v_u_111.gem = v179("Gem", v_u_25.Gem, 15, {
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ImageTransparency"] = 0,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 10, 0.5, 0),
				["Size"] = UDim2.fromOffset(40, 40),
				["Parent"] = v_u_111.count
			})
			v_u_111.countText = v_u_18.new("TextLabel", {
				["Name"] = "N",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "x0",
				["FontFace"] = nil,
				["TextSize"] = 40,
				["TextXAlignment"] = nil,
				["ZIndex"] = 15,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(54, 0),
				["Size"] = UDim2.new(1, -54, 1, 0),
				["FontFace"] = v_u_24.Display,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Parent"] = v_u_111.count
			})
			v_u_18.TextStroke(v_u_23.Void, 2, 0.35).Parent = v_u_111.countText
			v_u_111.sheen = v_u_18.new("Frame", {
				["Name"] = "Sheen",
				["Size"] = UDim2.fromScale(1, 1),
				["BackgroundColor3"] = Color3.new(1, 1, 1),
				["BackgroundTransparency"] = 1,
				["ZIndex"] = 17,
				v_u_18.Corner(18),
				["Parent"] = v190
			})
			v_u_111.sheenGrad = v_u_18.new("UIGradient", {
				["Rotation"] = 25,
				["Transparency"] = nil,
				["Offset"] = nil,
				["Parent"] = nil,
				["Transparency"] = NumberSequence.new({
					NumberSequenceKeypoint.new(0, 1),
					NumberSequenceKeypoint.new(0.42, 1),
					NumberSequenceKeypoint.new(0.5, 0.35),
					NumberSequenceKeypoint.new(0.58, 1),
					NumberSequenceKeypoint.new(1, 1)
				}),
				["Offset"] = Vector2.new(-1, 0),
				["Parent"] = v_u_111.sheen
			})
			v_u_111.stamp = v_u_18.new("Frame", {
				["Name"] = "Stamp",
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.new(0.5, 0, 0, 158),
				["Size"] = UDim2.fromOffset(250, 52),
				["BackgroundColor3"] = v_u_23.Success,
				["Rotation"] = -8,
				["Visible"] = false,
				["ZIndex"] = 18,
				v_u_18.Corner(12),
				["Parent"] = v190
			})
			v_u_18.Gradient(v_u_19.Lighten(v_u_23.Success, 0.12), v_u_23.SuccessDark, 90).Parent = v_u_111.stamp
			v_u_18.Stroke(v_u_11(200, 255, 214), 3, 0.15).Parent = v_u_111.stamp
			v_u_111.stampScale = v_u_18.new("UIScale", {
				["Parent"] = v_u_111.stamp
			})
			v_u_18.Icon("chevUp", 26, v_u_23.Text, {
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["ZIndex"] = 19,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 12, 0.5, -1),
				["Parent"] = v_u_111.stamp
			})
			v_u_18.new("TextLabel", {
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "UPGRADE READY",
				["FontFace"] = nil,
				["TextSize"] = 25,
				["ZIndex"] = 19,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(40, 0),
				["Size"] = UDim2.new(1, -46, 1, 0),
				["FontFace"] = v_u_24.Display,
				["Parent"] = v_u_111.stamp
			})
			local v194 = v_u_18.new("Frame", {
				["Name"] = "Bar",
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["Visible"] = false,
				["ZIndex"] = 12,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Size"] = UDim2.fromOffset(330, 62),
				["Parent"] = v_u_173
			})
			v_u_111.barBox = v194
			v_u_111.barCaption = v_u_18.new("TextLabel", {
				["Name"] = "Caption",
				["Size"] = nil,
				["Text"] = "",
				["RichText"] = true,
				["FontFace"] = nil,
				["TextSize"] = 17,
				["TextColor3"] = nil,
				["ZIndex"] = 12,
				["Parent"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 22),
				["FontFace"] = v_u_24.Heavy,
				["TextColor3"] = v_u_23.TextDim,
				["Parent"] = v194
			})
			v_u_18.TextStroke(v_u_23.Void, 1.5, 0.45).Parent = v_u_111.barCaption
			local v195 = v_u_18.new("Frame", {
				["Name"] = "Track",
				["Position"] = UDim2.fromOffset(0, 28),
				["Size"] = UDim2.new(1, 0, 0, 30),
				["BackgroundColor3"] = v_u_23.Void,
				["BackgroundTransparency"] = 0.2,
				["ClipsDescendants"] = true,
				["ZIndex"] = 12,
				v_u_18.Corner(v_u_19.Radius.Pill),
				v_u_18.Stroke(v_u_23.Stroke, 1.5, 0.75),
				["Parent"] = v194
			})
			v_u_111.track = v195
			v_u_111.barFill = v_u_18.new("Frame", {
				["Name"] = "Fill",
				["Size"] = UDim2.fromScale(0, 1),
				["BackgroundColor3"] = Color3.new(1, 1, 1),
				["ZIndex"] = 13,
				v_u_18.Corner(v_u_19.Radius.Pill),
				["Parent"] = v195
			})
			v_u_111.barGrad = v_u_18.new("UIGradient", {
				["Rotation"] = 90,
				["Parent"] = nil,
				["Parent"] = v_u_111.barFill
			})
			v_u_111.barText = v_u_18.new("TextLabel", {
				["Name"] = "N",
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 20,
				["ZIndex"] = 15,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["FontFace"] = v_u_24.Display,
				["Parent"] = v195
			})
			v_u_18.TextStroke(v_u_23.Void, 2, 0.3).Parent = v_u_111.barText
			v_u_111.barHead = v179("Head", v_u_25.Sparkle, 14, {
				["Position"] = UDim2.fromOffset(0, 43),
				["Size"] = UDim2.fromOffset(54, 54),
				["Parent"] = v194
			})
			v_u_111.barFlash = v_u_18.new("Frame", {
				["Name"] = "Flash",
				["Size"] = UDim2.fromScale(1, 1),
				["BackgroundColor3"] = v_u_23.Gold,
				["BackgroundTransparency"] = 1,
				["ZIndex"] = 14,
				v_u_18.Corner(v_u_19.Radius.Pill),
				["Parent"] = v195
			})
			local v_u_196 = v_u_18.new("Frame", {
				["Name"] = "NewItem",
				["Size"] = nil,
				["Visible"] = false,
				["ZIndex"] = 13,
				["Parent"] = nil,
				["Size"] = UDim2.fromOffset(0, 0),
				["Parent"] = v_u_173
			})
			v_u_111.newRoot = v_u_196
			v_u_111.newDim = v_u_18.new("Frame", {
				["Name"] = "Dim",
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 1,
				["ZIndex"] = 20,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Size"] = UDim2.fromOffset(6000, 4000),
				["BackgroundColor3"] = v_u_23.Void,
				["Parent"] = v_u_196
			})
			v_u_111.newRaysA = v179("RaysA", v_u_25.Rays, 21, {
				["Size"] = UDim2.fromOffset(1300, 1300),
				["Position"] = UDim2.fromOffset(0, -40),
				["Parent"] = v_u_196
			})
			v_u_111.newRaysB = v179("RaysB", v_u_25.RaysThin, 21, {
				["Size"] = UDim2.fromOffset(1500, 1500),
				["Position"] = UDim2.fromOffset(0, -40),
				["Parent"] = v_u_196
			})
			v_u_111.newGlow = v179("Glow", v_u_18.Assets.Icons.Glow, 22, {
				["Size"] = UDim2.fromOffset(760, 760),
				["Position"] = UDim2.fromOffset(0, -40),
				["Parent"] = v_u_196
			})
			v_u_111.newRing = v179("Ring", v_u_25.GlowRing, 22, {
				["Size"] = UDim2.fromOffset(200, 200),
				["Position"] = UDim2.fromOffset(0, -40),
				["Parent"] = v_u_196
			})
			v_u_111.newFlare = v179("Flare", v_u_25.Flare, 25, {
				["Size"] = UDim2.fromOffset(1400, 140),
				["Position"] = UDim2.fromOffset(0, -270),
				["Parent"] = v_u_196
			})
			v_u_111.newItem = v_u_18.new("Frame", {
				["Name"] = "Item",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 23,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(0, -40),
				["Size"] = UDim2.fromOffset(400, 400),
				["Parent"] = v_u_196
			})
			v_u_111.newItemScale = v_u_18.new("UIScale", {
				["Parent"] = v_u_111.newItem
			})
			local function v201(p197, p198, p199, p200) -- name: newText
				-- upvalues: (ref) v_u_18, (ref) v_u_10, (ref) v_u_23, (copy) v_u_196
				return v_u_18.new("TextLabel", {
					["Name"] = nil,
					["AnchorPoint"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextTransparency"] = 1,
					["ZIndex"] = nil,
					["Parent"] = nil,
					["Name"] = p197,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Size"] = UDim2.fromOffset(1400, p198 * 1.25),
					["FontFace"] = p200 or v_u_10,
					["TextSize"] = p198,
					["TextColor3"] = v_u_23.Text,
					["ZIndex"] = p199,
					["Parent"] = v_u_196
				})
			end
			v_u_111.newAura = v201("Aura", 104, 24)
			v_u_111.newAuraScale = v_u_18.new("UIScale", {
				["Parent"] = v_u_111.newAura
			})
			v_u_111.newShadow = v201("Shadow", 104, 24)
			v_u_111.newShadow.TextColor3 = v_u_23.Void
			v_u_111.newShadowScale = v_u_18.new("UIScale", {
				["Parent"] = v_u_111.newShadow
			})
			v_u_111.newHead = v201("Headline", 104, 26)
			v_u_111.newHeadScale = v_u_18.new("UIScale", {
				["Parent"] = v_u_111.newHead
			})
			v_u_111.newHeadGrad = v_u_18.new("UIGradient", {
				["Rotation"] = 90,
				["Parent"] = nil,
				["Parent"] = v_u_111.newHead
			})
			v_u_111.newName = v201("ItemName", 50, 26, v_u_24.Display)
			v_u_18.TextStroke(v_u_23.Void, 2, 0.35).Parent = v_u_111.newName
			v_u_111.newSub = v201("Sub", 20, 26, v_u_24.Heavy)
			v_u_111.newSub.TextColor3 = v_u_23.TextDim
			v_u_18.TextStroke(v_u_23.Void, 1.5, 0.45).Parent = v_u_111.newSub
			local v202 = v_u_111.newName
			v202.TextTransparency = 1
			local v203
			if v202:IsA("TextLabel") then
				v203 = v202:FindFirstChildWhichIsA("UIStroke")
			else
				v203 = nil
			end
			local v204
			if v203 then
				local v205 = v203:GetAttribute("Authored")
				if type(v205) == "number" then
					v204 = 1
				else
					v203:SetAttribute("Authored", v203.Transparency)
					v204 = 1
				end
			else
				v203 = nil
				v204 = 1
			end
			if v203 then
				v203.Transparency = v204
			end
			local v206 = v_u_111.newSub
			v206.TextTransparency = 1
			local v207
			if v206:IsA("TextLabel") then
				v207 = v206:FindFirstChildWhichIsA("UIStroke")
			else
				v207 = nil
			end
			local v208
			if v207 then
				local v209 = v207:GetAttribute("Authored")
				if type(v209) == "number" then
					v208 = 1
				else
					v207:SetAttribute("Authored", v207.Transparency)
					v208 = 1
				end
			else
				v207 = nil
				v208 = 1
			end
			if v207 then
				v207.Transparency = v208
			end
			local v210 = v_u_18.new("Frame", {
				["Name"] = "Summary",
				["Size"] = nil,
				["Visible"] = false,
				["ZIndex"] = 12,
				["Parent"] = nil,
				["Size"] = UDim2.fromOffset(0, 0),
				["Parent"] = v_u_173
			})
			v_u_111.sumRoot = v210
			v_u_111.sumRow = v_u_18.new("Frame", {
				["Name"] = "Row",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 12,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(0, -40),
				["Size"] = UDim2.fromOffset(0, 0),
				["Parent"] = v210
			})
			v_u_111.sumTotals = v_u_18.new("TextLabel", {
				["Name"] = "Totals",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["RichText"] = true,
				["FontFace"] = nil,
				["TextSize"] = 28,
				["ZIndex"] = 13,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(0, 150),
				["Size"] = UDim2.fromOffset(900, 34),
				["FontFace"] = v_u_24.Display,
				["Parent"] = v210
			})
			v_u_18.TextStroke(v_u_23.Void, 2, 0.35).Parent = v_u_111.sumTotals
			local v211 = v_u_111.sumTotals
			v211.TextTransparency = 1
			local v212
			if v211:IsA("TextLabel") then
				v212 = v211:FindFirstChildWhichIsA("UIStroke")
			else
				v212 = nil
			end
			local v213
			if v212 then
				local v214 = v212:GetAttribute("Authored")
				if type(v214) == "number" then
					v213 = 1
				else
					v212:SetAttribute("Authored", v212.Transparency)
					v213 = 1
				end
			else
				v212 = nil
				v213 = 1
			end
			if v212 then
				v212.Transparency = v213
			end
			v_u_111.cont = v_u_18.new("TextButton", {
				["Name"] = "Continue",
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(0, 236),
				["Size"] = UDim2.fromOffset(280, 60),
				["BackgroundColor3"] = v_u_23.Accent,
				["ClipsDescendants"] = true,
				["ZIndex"] = 16,
				v_u_18.Corner(v_u_19.Radius.Pill),
				["Parent"] = v210
			})
			v_u_111.contGrad = v_u_18.Gradient(v_u_19.Lighten(v_u_23.Accent, 0.12), v_u_23.AccentDark, 90)
			v_u_111.contGrad.Parent = v_u_111.cont
			v_u_111.contScale = v_u_18.new("UIScale", {
				["Parent"] = v_u_111.cont
			})
			v_u_111.contFill = v_u_18.new("Frame", {
				["Name"] = "Auto",
				["Size"] = UDim2.fromScale(1, 1),
				["BackgroundColor3"] = v_u_23.Void,
				["BackgroundTransparency"] = 0.8,
				["ZIndex"] = 16,
				v_u_18.Corner(v_u_19.Radius.Pill),
				["Parent"] = v_u_111.cont
			})
			v_u_111.contFillGrad = v_u_18.new("UIGradient", {
				["Transparency"] = NumberSequence.new({
					NumberSequenceKeypoint.new(0, 0),
					NumberSequenceKeypoint.new(0.5, 0),
					NumberSequenceKeypoint.new(0.501, 1),
					NumberSequenceKeypoint.new(1, 1)
				}),
				["Offset"] = Vector2.new(-0.5, 0),
				["Parent"] = v_u_111.contFill
			})
			v_u_18.new("TextLabel", {
				["Size"] = nil,
				["Text"] = "CONTINUE",
				["FontFace"] = nil,
				["TextSize"] = 28,
				["ZIndex"] = 17,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["FontFace"] = v_u_24.Display,
				["Parent"] = v_u_111.cont
			})
			v_u_111.tiles = {}
			v_u_111.skip = v_u_18.new("TextButton", {
				["Name"] = "Skip",
				["AnchorPoint"] = Vector2.new(1, 0),
				["Size"] = UDim2.fromOffset(128, 46),
				["BackgroundColor3"] = v_u_23.Panel,
				["BackgroundTransparency"] = 0.25,
				["Visible"] = false,
				["ZIndex"] = 30,
				["ClipsDescendants"] = true,
				v_u_18.Corner(v_u_19.Radius.Pill),
				v_u_18.Stroke(v_u_23.Stroke, 1.5, 0.75),
				["Parent"] = v171
			})
			v_u_111.skipFill = v_u_18.new("Frame", {
				["Name"] = "Hold",
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.82,
				["ZIndex"] = 30,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(0, 1),
				["BackgroundColor3"] = v_u_23.Text,
				["Parent"] = v_u_111.skip
			})
			v_u_18.new("TextLabel", {
				["Size"] = nil,
				["Text"] = "SKIP",
				["FontFace"] = nil,
				["TextSize"] = 22,
				["TextColor3"] = nil,
				["ZIndex"] = 31,
				["Parent"] = nil,
				["Size"] = UDim2.new(1, -30, 1, 0),
				["FontFace"] = v_u_24.Display,
				["TextColor3"] = v_u_23.TextDim,
				["Parent"] = v_u_111.skip
			})
			v_u_18.Icon("chevRight", 18, v_u_23.TextDim, {
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["ZIndex"] = 31,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(1, 0.5),
				["Position"] = UDim2.new(1, -14, 0.5, 0),
				["Parent"] = v_u_111.skip
			})
			v_u_18.Icon("chevRight", 18, v_u_23.TextDim, {
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["ZIndex"] = 31,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(1, 0.5),
				["Position"] = UDim2.new(1, -24, 0.5, 0),
				["Parent"] = v_u_111.skip
			})
		end
	end
	local function v_u_228() -- name: layout
		-- upvalues: (ref) v_u_110, (copy) v_u_18, (copy) v_u_111
		if v_u_110 then
			local v216 = v_u_18.CanvasSize()
			local v217 = v_u_18.TopInset()
			local v218 = (v216.Y - v217 * 0.5 - 6) / 780
			local v219 = (v216.X - 20) / 1200
			local v220 = math.min(1, v218, v219)
			v_u_111.stageScale.Scale = v220
			local v221 = v_u_111.stage
			local v222 = UDim2.new
			local v223 = v217 * 0.25
			v221.Position = v222(0.5, 0, 0.5, (math.floor(v223)))
			local v224 = v_u_18.Compact and 54 or 24
			v_u_111.skip.Position = UDim2.new(1, -v224, 0, v217 + 6)
			local v225 = v_u_18.Compact
			v_u_111.subtitle.TextSize = v225 and 28 or 22
			v_u_111.barCaption.TextSize = v225 and 23 or 17
			v_u_111.barText.TextSize = v225 and 25 or 20
			v_u_111.cat.TextSize = v225 and 18 or 14
			v_u_111.tagText.TextSize = v225 and 19 or 16
			local v226 = v_u_111.tag
			local v227
			if v225 then
				v227 = UDim2.fromOffset(92, 30)
			else
				v227 = UDim2.fromOffset(74, 26)
			end
			v226.Size = v227
			v_u_111.sumTotals.TextSize = v225 and 34 or 28
			v_u_111.newSub.TextSize = v225 and 26 or 20
		end
	end
	local function v_u_250(p229, p230) -- name: buildChest
		-- upvalues: (copy) v_u_164, (ref) v_u_165, (ref) v_u_106, (ref) v_u_166, (ref) v_u_167, (ref) v_u_11, (copy) v_u_111
		for _, v231 in v_u_164 do
			v231.part:Destroy()
		end
		table.clear(v_u_164)
		v_u_165 = nil
		local v232 = v_u_106
		if v232 then
			v232 = v_u_106[p229]
		end
		local v233 = v232 or {
			["size"] = { 5, 3.6, 3.4 },
			["hinge"] = { 0, 2.2, 1.7 },
			["parts"] = {
				{
					["lid"] = false,
					["mesh"] = "",
					["tex"] = "",
					["size"] = nil,
					["scale"] = nil,
					["cf"] = nil,
					["color"] = nil,
					["material"] = "Wood",
					["size"] = { 5, 2.2, 3.4 },
					["scale"] = { 1, 1, 1 },
					["cf"] = {
						0,
						1.1,
						0,
						1,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						1
					},
					["color"] = { 150, 96, 52 }
				},
				{
					["lid"] = true,
					["mesh"] = "",
					["tex"] = "",
					["size"] = nil,
					["scale"] = nil,
					["cf"] = nil,
					["color"] = nil,
					["material"] = "Wood",
					["size"] = { 5.1, 1.4, 3.5 },
					["scale"] = { 1, 1, 1 },
					["cf"] = {
						0,
						2.9,
						0,
						1,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						1
					},
					["color"] = { 172, 112, 60 }
				}
			}
		}
		v_u_165 = v233
		v_u_166 = CFrame.new(v233.hinge[1] * p230, v233.hinge[2] * p230, v233.hinge[3] * p230)
		v_u_167 = v_u_166:Inverse()
		for _, v_u_234 in v233.parts do
			local v_u_235 = Instance.new("Part")
			v_u_235.Anchored = true
			v_u_235.CanCollide = false
			v_u_235.CanQuery = false
			v_u_235.CanTouch = false
			v_u_235.CastShadow = false
			local v236 = v_u_234.size[1] * p230
			local v237 = v_u_234.size[2] * p230
			local v238 = v_u_234.size[3] * p230
			v_u_235.Size = Vector3.new(v236, v237, v238)
			v_u_235.Color = v_u_11(v_u_234.color[1], v_u_234.color[2], v_u_234.color[3])
			pcall(function()
				-- upvalues: (copy) v_u_235, (copy) v_u_234
				v_u_235.Material = Enum.Material[v_u_234.material]
			end)
			v_u_235.TopSurface = Enum.SurfaceType.Smooth
			v_u_235.BottomSurface = Enum.SurfaceType.Smooth
			local v239 = CFrame.new
			local v240 = v_u_234.cf
			local v241 = v239(table.unpack(v240))
			local v242 = v241.Rotation + v241.Position * p230
			local v243 = v_u_234.scale[1]
			local v244 = v_u_234.scale[2]
			local v245 = v_u_234.scale[3]
			local v246 = Vector3.new(v243, v244, v245) * p230
			local v247
			if v_u_234.mesh == "" then
				v247 = nil
			else
				v247 = Instance.new("SpecialMesh")
				v247.MeshType = Enum.MeshType.FileMesh
				v247.MeshId = v_u_234.mesh
				v247.TextureId = v_u_234.tex
				v247.Scale = v246
				v247.Parent = v_u_235
			end
			v_u_235.Parent = v_u_111.vpf
			local v248 = v_u_164
			local v249 = {
				["part"] = v_u_235,
				["mesh"] = v247,
				["cf"] = v242,
				["lid"] = v_u_234.lid == true,
				["scale"] = v246,
				["size"] = v_u_235.Size
			}
			table.insert(v248, v249)
		end
	end
	local function v_u_277() -- name: applyPose
		-- upvalues: (ref) v_u_165, (copy) v_u_140, (copy) v_u_164, (ref) v_u_166, (ref) v_u_167
		if v_u_165 then
			local v251 = v_u_140.sq
			local v252 = (1 - v251) * v_u_140.s
			local v253 = (1 + v251 * 0.55) * v_u_140.s
			local v254 = CFrame.new(0, v_u_140.y, 0) * CFrame.Angles(0, 0.4188790204786391 + v_u_140.yaw, 0) * CFrame.Angles(v_u_140.pitch, 0, v_u_140.roll)
			local v255 = CFrame.Angles
			local v256 = v_u_140.lid
			local v257 = v255(math.rad(v256), 0, 0)
			for _, v258 in v_u_164 do
				local v259 = v258.cf
				if v258.lid then
					v259 = v_u_166 * v257 * v_u_167 * v259
				end
				local v260 = v259.Position
				local v261 = v259.Rotation
				v258.part.CFrame = v254 * (CFrame.new(v260.X * v253, v260.Y * v252, v260.Z * v253) * v261)
				local v262 = v261.RightVector
				local v263 = v261.UpVector
				local v264 = v261.LookVector
				local v265 = v262.Y
				local v266 = math.abs(v265) * v252
				local v267 = v262.Y
				local v268 = v266 + (1 - math.abs(v267)) * v253
				local v269 = v263.Y
				local v270 = math.abs(v269) * v252
				local v271 = v263.Y
				local v272 = v270 + (1 - math.abs(v271)) * v253
				local v273 = v264.Y
				local v274 = math.abs(v273) * v252
				local v275 = v264.Y
				local v276 = v274 + (1 - math.abs(v275)) * v253
				if v258.mesh then
					v258.mesh.Scale = v258.scale * Vector3.new(v268, v272, v276)
				else
					v258.part.Size = v258.size * Vector3.new(v268, v272, v276)
				end
			end
		end
	end
	local function v_u_287(p278) -- name: project
		-- upvalues: (copy) v_u_140, (copy) v_u_168, (copy) v_u_111
		local v279 = v_u_168:PointToObjectSpace(CFrame.new(0, v_u_140.y, 0) * CFrame.Angles(0, 0.4188790204786391 + v_u_140.yaw, 0) * p278)
		local v280 = v_u_111.chestHolder.Size
		local v281 = v280.X.Offset
		local v282 = v280.Y.Offset
		local v283 = -v279.Z
		local v284 = math.max(v283, 0.1)
		local v285 = v279.X / (v284 * 0.24932800284318068 * (v281 / v282))
		local v286 = v279.Y / (v284 * 0.24932800284318068)
		return Vector2.new(v285 * v281 / 2, -v286 * v282 / 2)
	end
	local v_u_288 = nil
	local v_u_289 = nil
	local function v_u_295(p290) -- name: gradeIn
		-- upvalues: (ref) v_u_288, (copy) v_u_18, (ref) v_u_1, (ref) v_u_289, (copy) v_u_135
		if not v_u_288 then
			local v291 = {
				["Name"] = "TR_RevealCC",
				["Parent"] = nil,
				["Parent"] = v_u_1
			}
			v_u_288 = v_u_18.new("ColorCorrectionEffect", v291)
		end
		if not v_u_289 then
			local v292 = {
				["Name"] = "TR_RevealBlur",
				["Size"] = 0,
				["Parent"] = nil,
				["Parent"] = v_u_1
			}
			v_u_289 = v_u_18.new("BlurEffect", v292)
		end
		local v293 = v_u_288
		local v294 = Color3.new(1, 1, 1)
		v293.Brightness = 0
		v293.Contrast = 0
		v293.Saturation = 0
		v293.TintColor = v294
		v_u_135(v293, 0.4, {
			["Contrast"] = 0.1,
			["Saturation"] = nil,
			["Brightness"] = -0.02,
			["TintColor"] = nil,
			["Saturation"] = p290.legendary and 0.22 or 0.14,
			["TintColor"] = p290.light:Lerp(Color3.new(1, 1, 1), 0.85)
		})
		v_u_289.Size = 0
		v_u_135(v_u_289, 0.45, {
			["Size"] = 14
		})
	end
	local function v_u_297(p296) -- name: gradeOut
		-- upvalues: (ref) v_u_288, (copy) v_u_135, (ref) v_u_289
		if v_u_288 then
			v_u_135(v_u_288, p296, {
				["Contrast"] = 0,
				["Saturation"] = 0,
				["Brightness"] = 0,
				["TintColor"] = nil,
				["TintColor"] = Color3.new(1, 1, 1)
			}, Enum.EasingStyle.Quad)
		end
		if v_u_289 then
			v_u_135(v_u_289, p296, {
				["Size"] = 0
			}, Enum.EasingStyle.Quad)
		end
	end
	local v_u_298 = nil
	local v_u_299 = Random.new()
	local v_u_300 = 0
	local v_u_301 = 0
	local v_u_302 = 0
	local v_u_303 = {
		["on"] = false,
		["t"] = 0,
		["nextWiggle"] = 0.5,
		["wiggleT"] = -1,
		["interval"] = 0.9,
		["build"] = 0
	}
	local function v_u_354(p304) -- name: onRender
		-- upvalues: (ref) v_u_109, (copy) v_u_163, (ref) v_u_112, (copy) v_u_303, (copy) p_u_17, (copy) v_u_299, (copy) v_u_111, (ref) v_u_166, (ref) v_u_165, (copy) v_u_287, (copy) v_u_140, (copy) v_u_277, (ref) v_u_300, (ref) v_u_301, (ref) v_u_302, (ref) v_u_13, (copy) v_u_29
		local v305 = p304 / v_u_109
		v_u_163(v305)
		if v_u_112 then
			local v306 = v_u_112.look
			if v_u_303.on then
				local v307 = v_u_303
				v307.t = v307.t + v305
				local v308 = v_u_303
				local v309 = v_u_303.build
				local v310 = v306.idle
				local v311 = v309 + v305 / math.max(v310, 0.1)
				v308.build = math.min(1, v311)
				local v312 = v_u_303.t * 2.4
				local v313 = math.sin(v312) * 0.07
				local v314 = 0
				local v315 = 0
				if v_u_303.t >= v_u_303.nextWiggle and v_u_303.wiggleT < 0 then
					v_u_303.wiggleT = 0
					p_u_17.Sounds.Play("Drop_Rattle", {
						["pitch"] = 0.95 + v_u_299:NextNumber() * 0.1 + v_u_303.build * 0.08
					})
					local v316 = v_u_111.backPool
					local v317 = v306.legendary and 5 or 3
					local v318 = {
						["mode"] = "point",
						["at"] = nil,
						["jitter"] = 60,
						["dir"] = -90,
						["spread"] = 55,
						["speedMin"] = 90,
						["speedMax"] = 220,
						["kind"] = "sparkle",
						["size"] = 26,
						["grav"] = 120,
						["drag"] = 1.6,
						["lifeMin"] = 0.45,
						["lifeMax"] = 0.8,
						["colors"] = nil,
						["whiteChance"] = 0
					}
					local v319 = v_u_166.Position.Y
					local v320 = v_u_165
					local v321 = -(not v320 and 1.7 or v320.size[3] * (v_u_112 and v_u_112.look.fit or 1) / 2)
					local v322 = v_u_287((Vector3.new(0, v319, v321)))
					local v323 = v_u_111.chestHolder.Position
					local v324 = v_u_111.chestScale.Scale
					v318.at = Vector2.new(v323.X.Offset + v322.X * v324, v323.Y.Offset + v322.Y * v324)
					v318.colors = { v306.light, v306.primary }
					v316:Burst(v317, v318)
				end
				if v_u_303.wiggleT >= 0 then
					local v325 = v_u_303
					v325.wiggleT = v325.wiggleT + v305
					local v326 = v_u_303.wiggleT / 0.36
					if v326 >= 1 then
						v_u_303.wiggleT = -1
						local v327 = v_u_303
						local v328
						if v306.legendary then
							local v329 = 0.9 - v_u_303.build * 0.6
							v328 = math.max(0.32, v329)
						else
							v328 = 0.9
						end
						v327.interval = v328
						v_u_303.nextWiggle = v_u_303.t + v_u_303.interval
					else
						local v330 = v306.wiggle
						local v331 = math.rad(v330) * (1 + v_u_303.build * (v306.legendary and 0.8 or 0.2))
						local v332 = v326 * 3.141592653589793 * 5
						v314 = math.sin(v332) * (1 - v326) * v331
						local v333 = v326 * 3.141592653589793
						v315 = math.sin(v333) * (v306.legendary and 9 or 5)
					end
				end
				v_u_140.y = v313 + (not v306.legendary and 0 or v_u_303.build * 0.25)
				v_u_140.roll = v314
				v_u_140.yaw = v314 * 0.6
				v_u_140.lid = v315
				local v334 = v_u_287
				local v335 = v_u_166.Position.Y
				local v336 = v_u_165
				local v337 = -(not v336 and 1.7 or v336.size[3] * (v_u_112 and v_u_112.look.fit or 1) / 2)
				local v338 = v334((Vector3.new(0, v335, v337)))
				v_u_111.leak.Position = UDim2.new(0.5, v338.X, 0.5, v338.Y)
				v_u_111.leakFlare.Position = v_u_111.leak.Position
				local v339 = v315 / 9
				local v340 = math.clamp(v339, 0, 1)
				v_u_111.leak.ImageTransparency = 1 - v340 * 0.75
				v_u_111.leakFlare.ImageTransparency = 1 - v340 * 0.6
				local v341 = v_u_303.t * 4.2
				local v342 = math.sin(v341) * 0.5 + 0.5
				v_u_111.chestGlow.ImageTransparency = 0.62 - v342 * 0.14 - v_u_303.build * (v306.legendary and 0.2 or 0.05)
				v_u_111.promptScale.Scale = v342 * 0.04 + 1
				if v306.legendary then
					v_u_111.raysA.ImageTransparency = 1 - v_u_303.build * 0.28
					v_u_111.raysB.ImageTransparency = 1 - v_u_303.build * 0.22
				end
			end
			v_u_111.raysA.Rotation = (v_u_111.raysA.Rotation + v305 * v_u_140.raysSpin) % 360
			v_u_111.raysB.Rotation = (v_u_111.raysB.Rotation - v305 * v_u_140.raysSpin * 0.6) % 360
			if v_u_111.newRoot.Visible then
				v_u_111.newRaysA.Rotation = (v_u_111.newRaysA.Rotation + v305 * v_u_140.raysSpin * 1.6) % 360
				v_u_111.newRaysB.Rotation = (v_u_111.newRaysB.Rotation - v305 * v_u_140.raysSpin) % 360
			end
			if v_u_111.chestHolder.Visible then
				v_u_277()
			end
			if v_u_300 > 0 then
				v_u_301 = v_u_301 + v305
				local v343 = v_u_302
				local v344 = 1 - v_u_301 / math.max(v343, 0.001)
				if v344 <= 0 then
					v_u_300 = 0
					v_u_111.shaker.Position = UDim2.new()
				else
					v_u_111.shaker.Position = UDim2.fromOffset(v_u_299:NextNumber(-1, 1) * v_u_300 * v344, v_u_299:NextNumber(-1, 1) * v_u_300 * v344)
				end
			end
			if v_u_112.barNeed and v_u_111.barBox.Visible then
				local v345 = v_u_111.barFill.Size.X.Scale * v_u_112.barNeed + 0.5
				local v346 = math.floor(v345)
				local v347 = v_u_112.barMin
				local v348 = v_u_112.barMax
				local v349 = math.clamp(v346, v347, v348)
				if v349 ~= v_u_112.barShown then
					v_u_112.barShown = v349
					v_u_111.barText.Text = string.format("%d / %d", v349, v_u_112.barNeed)
				end
			end
			if v_u_112.fallOpts then
				v_u_112.fallOpts.at = Vector2.new(0, v_u_111.chestHolder.Position.Y.Offset + 40)
			end
			if v_u_112.headOpts then
				v_u_112.headOpts.at = Vector2.new(-165 + v_u_111.barFill.Size.X.Scale * 330, 171)
			end
			if v_u_112.holdAt then
				local v350 = os.clock() - v_u_112.holdAt
				local v351 = v_u_111.skipFill
				local v352 = UDim2.fromScale
				local v353 = v350 / v_u_13.hold
				v351.Size = v352(math.clamp(v353, 0, 1), 1)
				if v_u_13.hold <= v350 and (not v_u_112.skip and v_u_112.phase ~= "summary") then
					v_u_112.holdAt = nil
					v_u_111.skipFill.Size = UDim2.fromScale(0, 1)
					v_u_29.Skip()
				end
			end
		end
	end
	local function v_u_362(p355, p356, p357) -- name: sleep
		-- upvalues: (ref) v_u_109, (ref) v_u_112
		local v358 = os.clock()
		local v359 = p356 * v_u_109
		while os.clock() - v358 < v359 do
			local v360
			if v_u_112 == nil then
				v360 = false
			else
				v360 = v_u_112.token == p355
			end
			if not v360 or v_u_112.skip then
				return false
			end
			if v_u_112.hurry and p357 ~= false then
				return true
			end
			if p357 and v_u_112.tapped then
				v_u_112.tapped = false
				return true
			end
			task.wait()
		end
		local v361
		if v_u_112 == nil then
			v361 = false
		else
			v361 = v_u_112.token == p355
		end
		if v361 then
			v361 = not v_u_112.skip
		end
		return v361
	end
	local function v_u_364(p363) -- name: paletteOf
		-- upvalues: (copy) v_u_111, (copy) v_u_23
		v_u_111.backGrad.Color = ColorSequence.new(p363.primary:Lerp(v_u_23.Void, 0.25), p363.deep)
		v_u_111.backStroke.Color = p363.light
		v_u_111.backArt.ImageColor3 = p363.light
		v_u_111.counterStroke.Color = p363.primary
		v_u_111.promptStroke.Color = p363.primary
		v_u_111.promptFill.BackgroundColor3 = p363.primary
		v_u_111.cont.BackgroundColor3 = p363.primary
		v_u_111.contGrad.Color = ColorSequence.new(p363.primary:Lerp(Color3.new(1, 1, 1), 0.08), p363.primary:Lerp(v_u_23.Void, 0.35))
		v_u_111.flash.BackgroundColor3 = p363.primary
		v_u_111.tint.ImageColor3 = p363.primary
		v_u_111.halo.ImageColor3 = p363.primary
		v_u_111.raysA.ImageColor3 = p363.light:Lerp(p363.primary, 0.35)
		v_u_111.raysB.ImageColor3 = p363.primary
		v_u_111.chestGlow.ImageColor3 = p363.primary
		v_u_111.leak.ImageColor3 = p363.light
		v_u_111.leakFlare.ImageColor3 = p363.light
		v_u_111.beam.ImageColor3 = p363.light
		v_u_111.floorRing.ImageColor3 = p363.light
		v_u_111.titleGrad.Color = ColorSequence.new(p363.light:Lerp(Color3.new(1, 1, 1), 0.3), p363.primary)
	end
	local function v_u_375(p365, p366) -- name: titleIn
		-- upvalues: (copy) v_u_111, (copy) v_u_135
		local v367 = v_u_111.title
		local v368 = v_u_111.titleShadow
		local v369 = v_u_111.subtitle
		v367.Visible = true
		v368.Visible = true
		v369.Visible = true
		for _, v370 in { v_u_111.title, v_u_111.titleShadow } do
			v370.Text = p365
			v370.TextTransparency = 1
		end
		v_u_111.title.Position = UDim2.fromOffset(0, -335)
		v_u_111.titleShadow.Position = UDim2.fromOffset(0, -330)
		v_u_111.titleScale.Scale = 1.8
		v_u_111.titleShadowScale.Scale = 1.8
		v_u_135(v_u_111.titleScale, 0.3, {
			["Scale"] = 1
		}, Enum.EasingStyle.Back)
		v_u_135(v_u_111.titleShadowScale, 0.3, {
			["Scale"] = 1
		}, Enum.EasingStyle.Back)
		v_u_135(v_u_111.title, 0.12, {
			["TextTransparency"] = 0
		}, Enum.EasingStyle.Quad)
		v_u_135(v_u_111.titleShadow, 0.2, {
			["TextTransparency"] = 0.55
		}, Enum.EasingStyle.Quad)
		v_u_111.subtitle.Text = p366
		v_u_111.subtitle.Position = UDim2.fromOffset(0, -279)
		local v371 = v_u_111.subtitle
		v371.TextTransparency = 1
		local v372
		if v371:IsA("TextLabel") then
			v372 = v371:FindFirstChildWhichIsA("UIStroke")
		else
			v372 = nil
		end
		local v373
		if v372 then
			local v374 = v372:GetAttribute("Authored")
			if type(v374) == "number" then
				v373 = 1
			else
				v372:SetAttribute("Authored", v372.Transparency)
				v373 = 1
			end
		else
			v372 = nil
			v373 = 1
		end
		if v372 then
			v372.Transparency = v373
		end
		v_u_135(v_u_111.subtitle, 0.3, {
			["TextTransparency"] = 0,
			["Position"] = nil,
			["Position"] = UDim2.fromOffset(0, -289)
		}, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0.15)
	end
	local function v_u_400(p376) -- name: phaseLand
		-- upvalues: (ref) v_u_112, (copy) v_u_140, (copy) v_u_277, (copy) v_u_111, (copy) v_u_135, (ref) v_u_13, (copy) v_u_156, (copy) p_u_17, (copy) v_u_287, (copy) v_u_362, (ref) v_u_300, (ref) v_u_301, (ref) v_u_302, (ref) v_u_165, (copy) v_u_23, (copy) v_u_375
		local v377 = v_u_112.look
		v_u_112.phase = "land"
		local v378 = v_u_140
		local v379 = v_u_140
		local v380 = v_u_140
		local v381 = v_u_140
		local v382 = v_u_140
		local v383 = v_u_140
		v_u_140.y = 0
		v378.yaw = -0.24434609527920614
		v379.roll = 0
		v380.pitch = 0
		v381.sq = -0.16
		v382.lid = 0
		v383.s = 1
		v_u_277()
		v_u_111.chestHolder.Visible = true
		v_u_111.chestHolder.Position = UDim2.fromOffset(0, -800)
		v_u_111.chestScale.Scale = 1
		v_u_135(v_u_111.chestHolder, v_u_13.fall, {
			["Position"] = UDim2.fromOffset(0, 20)
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		v_u_156("yaw", {
			{ 0, v_u_13.fall + 0.25, "outQuad" }
		})
		p_u_17.Sounds.Play("Whoosh", {
			["volume"] = 0.3,
			["pitch"] = 0.75
		})
		v_u_112.fallOpts = {
			["mode"] = "point",
			["at"] = nil,
			["jitter"] = 150,
			["dir"] = -90,
			["spread"] = 3,
			["speedMin"] = 1100,
			["speedMax"] = 1700,
			["kind"] = "spark",
			["size"] = 190,
			["grav"] = 0,
			["drag"] = 0,
			["lifeMin"] = 0.12,
			["lifeMax"] = 0.22,
			["colors"] = nil,
			["whiteChance"] = 0,
			["base"] = 0.55,
			["at"] = Vector2.new(0, -800),
			["colors"] = { v377.light }
		}
		local v384 = v_u_111.backPool:Emit(40, v_u_112.fallOpts)
		local v385 = v_u_287(Vector3.new(0, 0, 0))
		local v386 = v_u_111.chestHolder.Position
		local v387 = Vector2.new(v386.X.Offset + v385.X * 1, 20 + v385.Y * 1)
		v_u_111.shadow.Position = UDim2.fromOffset(v387.X, v387.Y + 4)
		v_u_111.shadow.Size = UDim2.fromOffset(120, 24)
		v_u_111.shadow.ImageTransparency = 0.9
		v_u_135(v_u_111.shadow, v_u_13.fall, {
			["Size"] = nil,
			["ImageTransparency"] = 0.35,
			["Size"] = UDim2.fromOffset(420, 84)
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		local v388 = v_u_362(p376, v_u_13.fall, false)
		v384()
		if v_u_112 then
			v_u_112.fallOpts = nil
		end
		if not v388 then
			return false
		end
		p_u_17.Sounds.Play("Drop_Land", {
			["pitch"] = v377.legendary and 0.9 or 1
		})
		v_u_156("sq", {
			{ 0.3, 0.06, "outQuad" },
			{ -0.12, 0.13, "inOutSine" },
			{ 0.05, 0.12, "inOutSine" },
			{ 0, 0.14, "outQuad" }
		})
		v_u_300 = v377.legendary and 16 or 11
		v_u_301 = 0
		v_u_302 = 0.32
		local v389 = v_u_287(Vector3.new(0, 0.1, 0))
		local v390 = v_u_111.chestHolder.Position
		local v391 = v_u_111.chestScale.Scale
		local v392 = Vector2.new(v390.X.Offset + v389.X * v391, v390.Y.Offset + v389.Y * v391)
		local v393 = v_u_165
		local v394 = -(not v393 and 1.7 or v393.size[3] * (v_u_112 and v_u_112.look.fit or 1) / 2)
		local v395 = v_u_287((Vector3.new(0, 0, v394)))
		local v396 = v_u_111.chestHolder.Position
		local v397 = v_u_111.chestScale.Scale
		local v398 = Vector2.new(v396.X.Offset + v395.X * v397, v396.Y.Offset + v395.Y * v397)
		for _, v399 in { 180, 0 } do
			v_u_111.frontPool:Burst(v377.legendary and 9 or 7, {
				["mode"] = "point",
				["at"] = nil,
				["jitter"] = 30,
				["dir"] = nil,
				["spread"] = 14,
				["speedMin"] = 180,
				["speedMax"] = 480,
				["kind"] = "dust",
				["size"] = 70,
				["grav"] = -40,
				["drag"] = 3.2,
				["lifeMin"] = 0.5,
				["lifeMax"] = 0.9,
				["color"] = nil,
				["base"] = 0.6,
				["grow"] = 2.6,
				["at"] = v398 + Vector2.new(v399 == 0 and 120 or -120, -6),
				["dir"] = v399,
				["color"] = v377.light:Lerp(v_u_23.TextDim, 0.55)
			})
		end
		v_u_111.frontPool:Burst(v377.legendary and 16 or 9, {
			["mode"] = "point",
			["at"] = nil,
			["jitter"] = 120,
			["dir"] = -90,
			["spread"] = 70,
			["speedMin"] = 260,
			["speedMax"] = 620,
			["kind"] = "sparkle",
			["size"] = 24,
			["grav"] = 900,
			["drag"] = 1.2,
			["lifeMin"] = 0.4,
			["lifeMax"] = 0.75,
			["colors"] = nil,
			["whiteChance"] = 0,
			["at"] = v392 + Vector2.new(0, -20),
			["colors"] = { v377.light, v377.primary }
		})
		v_u_111.floorRing.Position = UDim2.fromOffset(v392.X, v392.Y + 4)
		v_u_111.floorRing.Size = UDim2.fromOffset(160, 40)
		v_u_111.floorRing.ImageTransparency = 0.2
		v_u_135(v_u_111.floorRing, 0.55, {
			["Size"] = nil,
			["ImageTransparency"] = 1,
			["Size"] = UDim2.fromOffset(900, 210)
		}, Enum.EasingStyle.Quart)
		v_u_111.halo.ImageTransparency = 1
		v_u_111.raysHolder.Position = UDim2.fromOffset(0, 0)
		v_u_135(v_u_111.halo, 0.5, {
			["ImageTransparency"] = 0.55
		}, Enum.EasingStyle.Quad)
		v_u_375(v377.title, v_u_112.subtitle)
		return v_u_362(p376, v_u_13.settle, false)
	end
	local function v_u_420(p401) -- name: phaseIdle
		-- upvalues: (ref) v_u_112, (copy) v_u_303, (copy) v_u_111, (copy) v_u_135, (ref) v_u_165, (copy) v_u_287, (copy) p_u_17, (copy) v_u_140, (copy) v_u_362, (ref) v_u_109
		local v402 = v_u_112.look
		v_u_112.phase = "idle"
		local v403 = v_u_303
		local v404 = v_u_303
		local v405 = v_u_303
		local v406 = v_u_303
		v_u_303.on = true
		v403.t = 0
		v404.nextWiggle = 0.18
		v405.wiggleT = -1
		v406.build = 0
		v_u_111.prompt.Visible = true
		v_u_111.prompt.Position = UDim2.fromOffset(0, 332)
		v_u_111.promptFill.Size = UDim2.fromScale(0, 1)
		local v407 = v_u_112.opts.autoOpen == true
		local v408 = not v407 and 86400 or v402.idle
		if v407 then
			v_u_135(v_u_111.promptFill, v408, {
				["Size"] = UDim2.fromScale(1, 1)
			}, Enum.EasingStyle.Linear)
		end
		local v409 = v_u_112
		local v410 = v_u_111.backPool
		local v411 = v402.sparkle
		local v412 = {
			["mode"] = "point",
			["at"] = nil,
			["jitter"] = 170,
			["dir"] = -90,
			["spread"] = 15,
			["speedMin"] = 26,
			["speedMax"] = 70,
			["grav"] = -30,
			["drag"] = 0.2,
			["kind"] = "sparkle",
			["size"] = 24,
			["lifeMin"] = 0.9,
			["lifeMax"] = 1.6,
			["colors"] = nil,
			["whiteChance"] = 0
		}
		local v413 = v_u_165
		local v414 = (not v413 and 4 or v413.size[2] * (v_u_112 and v_u_112.look.fit or 1)) * 0.5
		local v415 = v_u_287((Vector3.new(0, v414, 0)))
		local v416 = v_u_111.chestHolder.Position
		local v417 = v_u_111.chestScale.Scale
		v412.at = Vector2.new(v416.X.Offset + v415.X * v417, v416.Y.Offset + v415.Y * v417)
		v412.colors = { v402.light, v402.primary }
		v409.stopSparkles = v410:Emit(v411, v412)
		if v402.legendary then
			p_u_17.Sounds.Play("Drop_BuildUp")
			v_u_111.raysHolder.Position = UDim2.fromOffset(0, 0)
			v_u_111.raysScale.Scale = 0.75
			v_u_135(v_u_111.raysScale, v402.idle, {
				["Scale"] = 0.95
			}, Enum.EasingStyle.Quad)
			v_u_140.raysSpin = 14
			v_u_135(v_u_111.vignette, v402.idle, {
				["ImageTransparency"] = 0.25,
				["ImageColor3"] = nil,
				["ImageColor3"] = v402.deep
			}, Enum.EasingStyle.Quad)
		end
		if v_u_112.tapped then
			v_u_112.tapped = false
			if v_u_362(p401, 0.15, false) == false then
				return false
			end
		elseif not v_u_362(p401, v408, true) then
			return false
		end
		v_u_303.on = false
		local v418 = v_u_140
		local v419 = v_u_140
		v_u_140.roll = 0
		v418.yaw = 0
		v419.lid = 0
		v_u_111.leak.ImageTransparency = 1
		v_u_111.leakFlare.ImageTransparency = 1
		v_u_135(v_u_111.prompt, 0.15, {
			["BackgroundTransparency"] = 1
		}, Enum.EasingStyle.Quad)
		task.delay(v_u_109 * 0.16, function()
			-- upvalues: (ref) v_u_111
			if v_u_111.prompt then
				v_u_111.prompt.Visible = false
				v_u_111.prompt.BackgroundTransparency = 0.15
			end
		end)
		return true
	end
	local function v_u_436(p421) -- name: phaseOpen
		-- upvalues: (ref) v_u_112, (copy) v_u_156, (ref) v_u_13, (copy) v_u_362, (copy) p_u_17, (ref) v_u_300, (ref) v_u_301, (ref) v_u_302, (ref) v_u_288, (copy) v_u_135, (copy) v_u_111, (ref) v_u_166, (copy) v_u_287, (copy) v_u_140, (copy) v_u_23
		local v422 = v_u_112.look
		v_u_112.phase = "open"
		v_u_156("sq", {
			{ 0.2, v_u_13.openCrouch, "outQuad" }
		})
		if not v_u_362(p421, v_u_13.openCrouch, false) then
			return false
		end
		v_u_156("sq", {
			{ -0.14, 0.1, "outQuad" },
			{ 0.06, 0.14, "inOutSine" },
			{ 0, 0.2, "outQuad" }
		})
		v_u_156("y", {
			{ 0.45, 0.12, "outQuad" },
			{ 0, 0.26, "inQuad" }
		})
		v_u_156("lid", {
			{ v422.model == "Drop" and 140 or 118, 0.34, "outBack" }
		})
		v_u_156("s", {
			{ 1.06, 0.1, "outQuad" },
			{ 1, 0.3, "outQuad" }
		})
		p_u_17.Sounds.Play("Drop_Open")
		if v422.legendary then
			p_u_17.Sounds.Play("Drop_Open_Golden")
		end
		v_u_300 = v422.legendary and 20 or 13
		v_u_301 = 0
		v_u_302 = 0.4
		local v423 = v422.legendary and 0.45 or 0.32
		if v_u_288 then
			local v424 = v_u_288
			v424.Saturation = v423
			v_u_135(v424, 0.6, {
				["Saturation"] = 0.16
			}, Enum.EasingStyle.Quad)
		end
		v_u_111.flash.BackgroundTransparency = v422.legendary and 0.55 or 0.64
		v_u_135(v_u_111.flash, 0.45, {
			["BackgroundTransparency"] = 1
		}, Enum.EasingStyle.Quad)
		v_u_135(v_u_111.dim, 0.3, {
			["BackgroundTransparency"] = 0.12
		}, Enum.EasingStyle.Quad)
		v_u_111.tint.ImageTransparency = 0.45
		v_u_135(v_u_111.tint, 1.2, {
			["ImageTransparency"] = 0.72
		}, Enum.EasingStyle.Quad)
		local v425 = v_u_166.Position.Y + 0.2
		local v426 = v_u_287((Vector3.new(0, v425, 0)))
		local v427 = v_u_111.chestHolder.Position
		local v428 = v_u_111.chestScale.Scale
		local v429 = Vector2.new(v427.X.Offset + v426.X * v428, v427.Y.Offset + v426.Y * v428)
		v_u_111.raysHolder.Position = UDim2.fromOffset(v429.X, v429.Y)
		v_u_111.raysScale.Scale = v422.legendary and 0.8 or 0.25
		v_u_135(v_u_111.raysScale, 0.55, {
			["Scale"] = v422.legendary and 1.15 or 1
		}, Enum.EasingStyle.Back)
		v_u_111.raysA.ImageTransparency = v422.legendary and 0.3 or 0.5
		v_u_111.raysB.ImageTransparency = v422.legendary and 0.4 or 0.6
		v_u_135(v_u_111.raysA, 1.1, {
			["ImageTransparency"] = v422.rays
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0.3)
		local v430 = v_u_135
		local v431 = v_u_111.raysB
		local v432 = {}
		local v433 = v422.rays + 0.12
		v432.ImageTransparency = math.min(0.92, v433)
		v430(v431, 1.1, v432, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0.3)
		v_u_140.raysSpin = v422.legendary and 60 or 40
		v_u_156("raysSpin", {
			{ v422.legendary and 12 or 8, 1.4, "outQuad" }
		})
		v_u_111.halo.ImageTransparency = 0.2
		v_u_111.halo.Size = UDim2.fromOffset(380, 380)
		v_u_135(v_u_111.halo, 0.8, {
			["ImageTransparency"] = 0.5,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(720, 720)
		}, Enum.EasingStyle.Quart)
		v_u_111.beam.Position = UDim2.fromOffset(v429.X, v429.Y + 30)
		v_u_111.beam.Size = UDim2.fromOffset(120, 300)
		v_u_111.beam.ImageTransparency = 0.25
		v_u_135(v_u_111.beam, 0.25, {
			["Size"] = UDim2.fromOffset(260, 760)
		}, Enum.EasingStyle.Quart)
		v_u_135(v_u_111.beam, 0.9, {
			["ImageTransparency"] = 1
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.In, 0.15)
		v_u_111.floorRing.Position = UDim2.fromOffset(v429.X, v429.Y)
		v_u_111.floorRing.Size = UDim2.fromOffset(160, 160)
		v_u_111.floorRing.ImageTransparency = 0.15
		v_u_135(v_u_111.floorRing, 0.6, {
			["Size"] = nil,
			["ImageTransparency"] = 1,
			["Size"] = UDim2.fromOffset(1500, 1500)
		}, Enum.EasingStyle.Quart)
		v_u_111.frontPool:Burst(v422.burst, {
			["mode"] = "point",
			["at"] = nil,
			["jitter"] = 50,
			["dir"] = -90,
			["spread"] = 62,
			["speedMin"] = 700,
			["speedMax"] = 1500,
			["sparkChance"] = 0.7,
			["sparkLen"] = 170,
			["size"] = 26,
			["grav"] = 900,
			["drag"] = 1.5,
			["lifeMin"] = 0.5,
			["lifeMax"] = 1,
			["colors"] = nil,
			["white"] = nil,
			["whiteChance"] = 0.3,
			["at"] = v429,
			["colors"] = { v422.primary, v422.light },
			["white"] = v422.light
		})
		local v434 = v_u_111.frontPool
		local v435 = v422.burst * 0.6
		v434:Burst(math.floor(v435), {
			["mode"] = "point",
			["at"] = nil,
			["jitter"] = 70,
			["dir"] = -90,
			["spread"] = 80,
			["speedMin"] = 250,
			["speedMax"] = 700,
			["kind"] = "sparkle",
			["size"] = 32,
			["grav"] = 500,
			["drag"] = 1.4,
			["lifeMin"] = 0.7,
			["lifeMax"] = 1.3,
			["colors"] = nil,
			["whiteChance"] = 0,
			["at"] = v429,
			["colors"] = { v422.light, v422.primary }
		})
		if v422.legendary then
			v_u_111.frontPool:Burst(24, {
				["mode"] = "point",
				["at"] = nil,
				["jitter"] = 40,
				["speedMin"] = 500,
				["speedMax"] = 1100,
				["kind"] = "shard",
				["size"] = 26,
				["grav"] = 700,
				["drag"] = 1.2,
				["lifeMin"] = 0.6,
				["lifeMax"] = 1.2,
				["colors"] = nil,
				["whiteChance"] = 0,
				["at"] = v429,
				["colors"] = { v_u_23.Gold, v422.light }
			})
		end
		v_u_111.chestGlow.ImageTransparency = 0.25
		v_u_135(v_u_111.chestGlow, 0.9, {
			["ImageTransparency"] = 0.55
		}, Enum.EasingStyle.Quad)
		if v_u_112.stopSparkles then
			v_u_112.stopSparkles()
			v_u_112.stopSparkles = nil
		end
		return v_u_362(p421, v_u_13.openHold, false) and true or false
	end
	local function v_u_440() -- name: chestToCards
		-- upvalues: (copy) v_u_135, (copy) v_u_111, (ref) v_u_13, (copy) v_u_287
		v_u_135(v_u_111.chestHolder, v_u_13.toCards, {
			["Position"] = UDim2.fromOffset(0, 290)
		})
		v_u_135(v_u_111.chestScale, v_u_13.toCards, {
			["Scale"] = 0.46
		})
		local v437 = v_u_287(Vector3.new(0, 0, 0))
		local v438 = v_u_111.chestHolder.Position
		local v439 = Vector2.new(v438.X.Offset + v437.X * 0.46, 290 + v437.Y * 0.46)
		v_u_135(v_u_111.shadow, v_u_13.toCards, {
			["Position"] = UDim2.fromOffset(v439.X, v439.Y + 3),
			["Size"] = UDim2.fromOffset(250, 50)
		})
		v_u_135(v_u_111.raysHolder, v_u_13.toCards + 0.1, {
			["Position"] = UDim2.fromOffset(0, -64)
		})
		v_u_135(v_u_111.halo, v_u_13.toCards, {
			["ImageTransparency"] = 0.6
		}, Enum.EasingStyle.Quad)
	end
	local function v_u_447(p441, p442, p443, p444, p445, p446) -- name: paintBar
		-- upvalues: (copy) v_u_111, (ref) v_u_112, (copy) v_u_23, (copy) v_u_21
		if p443 then
			v_u_111.barText.Text = string.format("%d / %d", p442, p443)
		else
			v_u_111.barText.Text = "MAX"
		end
		if v_u_112 then
			v_u_112.barNeed = p443
			v_u_112.barMin = p442
			v_u_112.barMax = math.max(p442, p446 or p442)
			v_u_112.barShown = p442
		end
		v_u_111.barGrad.Color = ColorSequence.new(p445:Lerp(Color3.new(1, 1, 1), 0.18), p445:Lerp(v_u_23.Void, 0.18))
		if p444 <= 0 then
			v_u_111.barCaption.Text = string.format("<font color=\"#%s\">UNLOCK</font>  %s", v_u_23.Gold:ToHex(), string.upper(v_u_21.Name(p441.item)))
			return
		elseif p443 then
			v_u_111.barCaption.Text = string.format("LEVEL %d  <font color=\"#%s\">\226\128\186</font>  %d", p444, p445:Lerp(Color3.new(1, 1, 1), 0.3):ToHex(), p444 + 1)
		else
			v_u_111.barCaption.Text = string.format("LEVEL %d  \194\183  MAX", p444)
		end
	end
	local function v_u_452(p448, p449, p450) -- name: setBar
		-- upvalues: (copy) v_u_111, (copy) v_u_135, (ref) v_u_13
		local v451 = math.clamp(p448, 0, 1)
		if p449 then
			v_u_111.barFill.Size = UDim2.fromScale(v451, 1)
			v_u_111.barHead.Position = UDim2.fromOffset(v451 * 330, 43)
		else
			v_u_135(v_u_111.barFill, p450 or v_u_13.bar, {
				["Size"] = UDim2.fromScale(v451, 1)
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
			v_u_135(v_u_111.barHead, p450 or v_u_13.bar, {
				["Position"] = UDim2.fromOffset(v451 * 330, 43)
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
		end
	end
	local function v_u_461(p453) -- name: paintFace
		-- upvalues: (copy) v_u_64, (copy) v_u_111, (copy) v_u_23, (copy) v_u_21
		local v454 = v_u_64(p453.item)
		v_u_111.faceGrad.Color = ColorSequence.new(v454:Lerp(Color3.new(1, 1, 1), 0.1), v454:Lerp(v_u_23.Void, 0.55))
		v_u_111.faceStroke.Color = v454:Lerp(Color3.new(1, 1, 1), 0.45)
		v_u_111.wellGlow.ImageColor3 = v454
		local v455 = v_u_111.cat
		local v456
		if p453.bonus then
			local v457 = p453.item
			local v458 = v_u_21.Get(v457)
			v456 = (v458 and (v_u_21.CATEGORY_SINGULAR and v_u_21.CATEGORY_SINGULAR[v458.category]) or "ITEM") .. "  \194\183  MVP BONUS"
		else
			local v459 = p453.item
			local v460 = v_u_21.Get(v459)
			v456 = v460 and (v_u_21.CATEGORY_SINGULAR and v_u_21.CATEGORY_SINGULAR[v460.category]) or "ITEM"
		end
		v455.Text = v456
		v_u_111.name.Text = string.upper(v_u_21.Name(p453.item))
		v_u_111.countText.Text = "x0"
		v_u_111.gem.ImageColor3 = v454:Lerp(Color3.new(1, 1, 1), 0.25)
		v_u_111.cardGlow.ImageColor3 = v454
		if p453.levelBefore <= 0 then
			v_u_111.tag.Visible = true
			v_u_111.tag.BackgroundColor3 = v_u_23.Raised
			v_u_111.tagText.Text = "LOCKED"
			v_u_111.tagText.TextColor3 = v_u_23.TextDim
		else
			v_u_111.tag.Visible = true
			v_u_111.tag.BackgroundColor3 = v_u_23.Raised
			v_u_111.tagText.Text = "LV " .. p453.levelBefore
			v_u_111.tagText.TextColor3 = v_u_23.Text
		end
		v_u_111.stamp.Visible = false
	end
	local function v_u_500(p_u_462, p463) -- name: phaseNewItem
		-- upvalues: (ref) v_u_112, (copy) v_u_64, (copy) v_u_111, (copy) v_u_135, (copy) v_u_140, (copy) v_u_156, (ref) v_u_288, (copy) v_u_22, (copy) v_u_23, (copy) v_u_21, (copy) p_u_17, (ref) v_u_109, (copy) v_u_362, (ref) v_u_300, (ref) v_u_301, (ref) v_u_302, (ref) v_u_13
		v_u_112.phase = "newitem"
		local v464 = v_u_64(p463.item)
		local v465 = v464:Lerp(Color3.new(1, 1, 1), 0.4)
		v_u_111.newRoot.Visible = true
		v_u_111.newRoot.Position = UDim2.fromOffset(0, 0)
		local v466 = v_u_111.card
		local v467 = v_u_111.barBox
		local v468 = v_u_111.counter
		v466.Visible = false
		v467.Visible = false
		v468.Visible = false
		v_u_111.newDim.BackgroundTransparency = 1
		v_u_135(v_u_111.newDim, 0.25, {
			["BackgroundTransparency"] = 0.18
		}, Enum.EasingStyle.Quad)
		v_u_111.newRaysA.ImageColor3 = v465
		v_u_111.newRaysB.ImageColor3 = v464
		local v469 = v_u_111.newRaysA
		local v470 = v_u_111.newRaysB
		v469.ImageTransparency = 0.25
		v470.ImageTransparency = 0.35
		v_u_111.newRaysA.Size = UDim2.fromOffset(300, 300)
		v_u_111.newRaysB.Size = UDim2.fromOffset(300, 300)
		v_u_135(v_u_111.newRaysA, 0.6, {
			["Size"] = nil,
			["ImageTransparency"] = 0.5,
			["Size"] = UDim2.fromOffset(1300, 1300)
		}, Enum.EasingStyle.Back)
		v_u_135(v_u_111.newRaysB, 0.7, {
			["Size"] = nil,
			["ImageTransparency"] = 0.62,
			["Size"] = UDim2.fromOffset(1500, 1500)
		}, Enum.EasingStyle.Back)
		v_u_140.raysSpin = 70
		v_u_156("raysSpin", {
			{ 10, 1.6, "outQuad" }
		})
		v_u_111.newGlow.ImageColor3 = v464
		v_u_111.newGlow.ImageTransparency = 0.4
		v_u_111.newGlow.Size = UDim2.fromOffset(300, 300)
		v_u_135(v_u_111.newGlow, 0.7, {
			["Size"] = nil,
			["ImageTransparency"] = 0.55,
			["Size"] = UDim2.fromOffset(820, 820)
		}, Enum.EasingStyle.Quart)
		v_u_111.newRing.ImageColor3 = v464
		v_u_111.newRing.Size = UDim2.fromOffset(200, 200)
		v_u_111.newRing.ImageTransparency = 0.3
		v_u_135(v_u_111.newRing, 0.7, {
			["Size"] = nil,
			["ImageTransparency"] = 1,
			["Size"] = UDim2.fromOffset(1700, 1700)
		}, Enum.EasingStyle.Quart)
		v_u_111.flash.BackgroundColor3 = v464
		v_u_111.flash.BackgroundTransparency = 0.7
		v_u_135(v_u_111.flash, 0.5, {
			["BackgroundTransparency"] = 1
		}, Enum.EasingStyle.Quad)
		if v_u_288 then
			local v471 = v_u_288
			v471.Saturation = 0.5
			v_u_135(v471, 0.6, {
				["Saturation"] = 0.16
			}, Enum.EasingStyle.Quad)
		end
		v_u_22.Set(v_u_111.newItem, p463.item, {
			["spin"] = true,
			["outline"] = true,
			["glow"] = false,
			["outlineColor"] = nil,
			["outlineScale"] = 1.04,
			["outlineTransparency"] = 0.4,
			["outlineColor"] = v465
		})
		v_u_111.newItemScale.Scale = 0.2
		v_u_135(v_u_111.newItemScale, 0.55, {
			["Scale"] = 1
		}, Enum.EasingStyle.Back)
		for _, v472 in { v_u_111.newHead, v_u_111.newShadow, v_u_111.newAura } do
			v472.Text = "NEW ITEM!"
			v472.TextTransparency = 1
			v472.Position = UDim2.fromOffset(0, -300)
		end
		v_u_111.newShadow.Position = UDim2.fromOffset(0, -293)
		v_u_111.newHeadGrad.Color = ColorSequence.new(v_u_23.Text, v465)
		v_u_111.newAura.TextColor3 = v465
		v_u_111.newHeadScale.Scale = 2.2
		v_u_111.newShadowScale.Scale = 2.2
		v_u_135(v_u_111.newHeadScale, 0.26, {
			["Scale"] = 1
		}, Enum.EasingStyle.Back, Enum.EasingDirection.Out, 0.08)
		v_u_135(v_u_111.newShadowScale, 0.26, {
			["Scale"] = 1
		}, Enum.EasingStyle.Back, Enum.EasingDirection.Out, 0.08)
		v_u_135(v_u_111.newHead, 0.1, {
			["TextTransparency"] = 0
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0.08)
		v_u_135(v_u_111.newShadow, 0.2, {
			["TextTransparency"] = 0.5
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0.08)
		v_u_111.newName.Text = string.upper(v_u_21.Name(p463.item))
		v_u_111.newName.Position = UDim2.fromOffset(0, 230)
		local v473 = v_u_111.newName
		v473.TextTransparency = 1
		local v474
		if v473:IsA("TextLabel") then
			v474 = v473:FindFirstChildWhichIsA("UIStroke")
		else
			v474 = nil
		end
		local v475
		if v474 then
			local v476 = v474:GetAttribute("Authored")
			if type(v476) == "number" then
				v475 = 1
			else
				v474:SetAttribute("Authored", v474.Transparency)
				v475 = 1
			end
		else
			v474 = nil
			v475 = 1
		end
		if v474 then
			v474.Transparency = v475
		end
		v_u_135(v_u_111.newName, 0.35, {
			["TextTransparency"] = 0,
			["Position"] = nil,
			["Position"] = UDim2.fromOffset(0, 210)
		}, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0.3)
		local v477 = v_u_111.newSub
		local v478 = string.format
		local v479 = p463.item
		local v480 = v_u_21.Get(v479)
		v477.Text = v478("%s  \194\183  UNLOCKED  \194\183  EQUIP IT IN YOUR LOADOUT", v480 and (v_u_21.CATEGORY_SINGULAR and v_u_21.CATEGORY_SINGULAR[v480.category]) or "ITEM")
		v_u_111.newSub.Position = UDim2.fromOffset(0, 272)
		local v481 = v_u_111.newSub
		v481.TextTransparency = 1
		local v482
		if v481:IsA("TextLabel") then
			v482 = v481:FindFirstChildWhichIsA("UIStroke")
		else
			v482 = nil
		end
		local v483
		if v482 then
			local v484 = v482:GetAttribute("Authored")
			if type(v484) == "number" then
				v483 = 1
			else
				v482:SetAttribute("Authored", v482.Transparency)
				v483 = 1
			end
		else
			v482 = nil
			v483 = 1
		end
		if v482 then
			v482.Transparency = v483
		end
		v_u_135(v_u_111.newSub, 0.35, {
			["TextTransparency"] = 0,
			["Position"] = nil,
			["Position"] = UDim2.fromOffset(0, 256)
		}, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0.42)
		p_u_17.Sounds.Play("NewItem_Fanfare")
		for _, v485 in { v_u_111.title, v_u_111.titleShadow, v_u_111.subtitle } do
			v_u_135(v485, 0.15, {
				["TextTransparency"] = 1
			}, Enum.EasingStyle.Quad)
		end
		task.delay(v_u_109 * 0.16, function()
			-- upvalues: (copy) p_u_462, (ref) v_u_112, (ref) v_u_111
			local v486 = p_u_462
			local v487
			if v_u_112 == nil then
				v487 = false
			else
				v487 = v_u_112.token == v486
			end
			if v487 and v_u_112.phase == "newitem" then
				local v488 = v_u_111.title
				local v489 = v_u_111.titleShadow
				local v490 = v_u_111.subtitle
				v488.Visible = false
				v489.Visible = false
				v490.Visible = false
			end
		end)
		if not v_u_362(p_u_462, 0.3, false) then
			return false
		end
		v_u_300 = 18
		v_u_301 = 0
		v_u_302 = 0.35
		v_u_111.newHeadScale.Scale = 1.08
		v_u_135(v_u_111.newHeadScale, 0.22, {
			["Scale"] = 1
		}, Enum.EasingStyle.Back)
		v_u_111.newAura.TextTransparency = 0.3
		v_u_111.newAuraScale.Scale = 1.02
		v_u_135(v_u_111.newAuraScale, 0.6, {
			["Scale"] = 1.35
		}, Enum.EasingStyle.Quart)
		v_u_135(v_u_111.newAura, 0.6, {
			["TextTransparency"] = 1
		}, Enum.EasingStyle.Quad)
		v_u_111.newFlare.ImageColor3 = v465
		v_u_111.newFlare.ImageTransparency = 0.2
		v_u_111.newFlare.Size = UDim2.fromOffset(300, 120)
		v_u_135(v_u_111.newFlare, 0.5, {
			["Size"] = nil,
			["ImageTransparency"] = 1,
			["Size"] = UDim2.fromOffset(1600, 150)
		}, Enum.EasingStyle.Quart)
		v_u_111.frontPool:Burst(40, {
			["mode"] = "box",
			["box"] = nil,
			["at"] = nil,
			["speed"] = 1300,
			["sparkChance"] = 0.6,
			["colors"] = nil,
			["white"] = nil,
			["whiteChance"] = 0.3,
			["box"] = Vector2.new(560, 90),
			["at"] = Vector2.new(0, -300),
			["colors"] = { v464, v465 },
			["white"] = v465
		})
		v_u_111.frontPool:Burst(36, {
			["mode"] = "point",
			["at"] = nil,
			["jitter"] = 90,
			["speedMin"] = 500,
			["speedMax"] = 1300,
			["sparkChance"] = 0.55,
			["sparkLen"] = 150,
			["size"] = 26,
			["grav"] = 500,
			["drag"] = 1.6,
			["lifeMin"] = 0.6,
			["lifeMax"] = 1.2,
			["colors"] = nil,
			["whiteChance"] = 0,
			["at"] = Vector2.new(0, -40),
			["colors"] = { v464, v465, v_u_23.Gold }
		})
		v_u_111.frontPool:Burst(20, {
			["mode"] = "point",
			["at"] = nil,
			["jitter"] = 160,
			["speedMin"] = 60,
			["speedMax"] = 260,
			["kind"] = "sparkle",
			["size"] = 36,
			["grav"] = -60,
			["drag"] = 0.8,
			["lifeMin"] = 1,
			["lifeMax"] = 1.8,
			["colors"] = nil,
			["whiteChance"] = 0,
			["at"] = Vector2.new(0, -40),
			["colors"] = { v465, v_u_23.Gold }
		})
		if not v_u_362(p_u_462, 0.5, false) then
			return false
		end
		v_u_112.tapped = false
		v_u_362(p_u_462, v_u_13.newItem - 0.8, true)
		local v491
		if v_u_112 == nil then
			v491 = false
		else
			v491 = v_u_112.token == p_u_462
		end
		if not v491 or v_u_112.skip then
			return false
		end
		v_u_135(v_u_111.newItemScale, 0.25, {
			["Scale"] = 0
		}, Enum.EasingStyle.Quint, Enum.EasingDirection.In)
		for _, v492 in {
			v_u_111.newHead,
			v_u_111.newShadow,
			v_u_111.newName,
			v_u_111.newSub
		} do
			v_u_135(v492, 0.2, {
				["TextTransparency"] = 1
			}, Enum.EasingStyle.Quad)
		end
		v_u_135(v_u_111.newRaysA, 0.3, {
			["ImageTransparency"] = 1
		}, Enum.EasingStyle.Quad)
		v_u_135(v_u_111.newRaysB, 0.3, {
			["ImageTransparency"] = 1
		}, Enum.EasingStyle.Quad)
		v_u_135(v_u_111.newGlow, 0.3, {
			["ImageTransparency"] = 1
		}, Enum.EasingStyle.Quad)
		v_u_135(v_u_111.newDim, 0.3, {
			["BackgroundTransparency"] = 1
		}, Enum.EasingStyle.Quad)
		local v493 = v_u_111.title
		local v494 = v_u_111.titleShadow
		local v495 = v_u_111.subtitle
		v493.Visible = true
		v494.Visible = true
		v495.Visible = true
		v_u_135(v_u_111.title, 0.25, {
			["TextTransparency"] = 0
		}, Enum.EasingStyle.Quad)
		v_u_135(v_u_111.titleShadow, 0.25, {
			["TextTransparency"] = 0.55
		}, Enum.EasingStyle.Quad)
		v_u_135(v_u_111.subtitle, 0.25, {
			["TextTransparency"] = 0
		}, Enum.EasingStyle.Quad)
		v_u_362(p_u_462, 0.22, false)
		v_u_111.newRoot.Visible = false
		v_u_22.Set(v_u_111.newItem, nil)
		local v496 = v_u_111.card
		local v497 = v_u_111.barBox
		v496.Visible = true
		v497.Visible = true
		local v498 = #v_u_112.reveal.stacks - (v_u_112.cardIndex or 0)
		v_u_111.counter.Visible = v498 > 0
		v_u_111.counterText.Text = "x" .. v498
		v_u_140.raysSpin = 8
		local v499
		if v_u_112 == nil then
			v499 = false
		else
			v499 = v_u_112.token == p_u_462
		end
		if v499 then
			v499 = not v_u_112.skip
		end
		return v499
	end
	local function v_u_551(p_u_501, p502, p503) -- name: phaseCard
		-- upvalues: (ref) v_u_112, (copy) v_u_64, (copy) v_u_461, (ref) v_u_166, (copy) v_u_287, (copy) v_u_111, (copy) v_u_22, (copy) p_u_17, (copy) v_u_299, (copy) v_u_18, (copy) v_u_156, (copy) v_u_135, (ref) v_u_13, (copy) v_u_362, (copy) v_u_447, (ref) v_u_14, (ref) v_u_109, (copy) v_u_452, (copy) v_u_139, (copy) v_u_23, (copy) v_u_500, (ref) v_u_300, (ref) v_u_301, (ref) v_u_302, (copy) v_u_19
		local v504 = v_u_112.look
		v_u_112.phase = "card"
		v_u_112.cardIndex = p502
		v_u_112.hurry = false
		v_u_112.tapped = false
		v_u_112.group = {}
		local v505 = v_u_64(p503.item)
		v_u_461(p503)
		local v506 = v_u_166.Position.Y + 0.2
		local v507 = v_u_287((Vector3.new(0, v506, 0)))
		local v508 = v_u_111.chestHolder.Position
		local v509 = Vector2.new(v508.X.Offset + v507.X * 0.46, 290 + v507.Y * 0.46)
		local v510 = #v_u_112.reveal.stacks >= 4 and 0.82 or 1
		local v511 = v_u_111.card
		v511.Visible = true
		v_u_111.back.Visible = true
		v_u_111.face.Visible = false
		v511.Size = UDim2.fromOffset(232, 322)
		v511.Position = UDim2.fromOffset(v509.X, v509.Y)
		v511.Rotation = p502 % 2 == 0 and -200 or 200
		v_u_111.cardScale.Scale = 0.22799999999999998
		v_u_111.cardGlow.ImageTransparency = 1
		v_u_111.sheen.BackgroundTransparency = 1
		v_u_22.Set(v_u_111.icon, nil)
		p_u_17.Sounds.Play("Card_Whoosh", {
			["pitch"] = 0.95 + v_u_299:NextNumber() * 0.1
		})
		local v512 = #v_u_112.reveal.stacks - p502
		v_u_111.counter.Visible = v512 > 0
		v_u_111.counterText.Text = "x" .. v512
		v_u_18.Pop(v_u_111.counter, 1.35)
		v_u_156("sq", {
			{ 0.1, 0.06, "outQuad" },
			{ 0, 0.16, "outQuad" }
		})
		v_u_111.chestGlow.ImageTransparency = 0.3
		v_u_135(v_u_111.chestGlow, 0.5, {
			["ImageTransparency"] = 0.6
		}, Enum.EasingStyle.Quad)
		v_u_111.backPool:Burst(8, {
			["mode"] = "point",
			["at"] = nil,
			["jitter"] = 30,
			["dir"] = -90,
			["spread"] = 40,
			["speedMin"] = 250,
			["speedMax"] = 600,
			["kind"] = "sparkle",
			["size"] = 26,
			["grav"] = 700,
			["drag"] = 1.3,
			["lifeMin"] = 0.4,
			["lifeMax"] = 0.8,
			["colors"] = nil,
			["whiteChance"] = 0,
			["at"] = v509,
			["colors"] = { v504.light, v504.primary }
		})
		v_u_135(v511, v_u_13.cardFly * v510, {
			["Position"] = UDim2.fromOffset(0, -64)
		}, Enum.EasingStyle.Quint)
		v_u_135(v511, v_u_13.cardFly * v510, {
			["Rotation"] = 0
		}, Enum.EasingStyle.Quart)
		v_u_135(v_u_111.cardScale, v_u_13.cardFly * v510, {
			["Scale"] = 1.14
		}, Enum.EasingStyle.Back)
		v_u_111.barBox.Visible = false
		if not v_u_362(p_u_501, v_u_13.cardFly * v510, true) then
			return false
		end
		p_u_17.Sounds.Play("Card_Flip")
		v_u_135(v511, v_u_13.flip / 2, {
			["Size"] = UDim2.fromOffset(0, 322)
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		v_u_135(v_u_111.cardScale, v_u_13.flip / 2, {
			["Scale"] = 1.254
		}, Enum.EasingStyle.Quad)
		if not v_u_362(p_u_501, v_u_13.flip / 2, true) then
			return false
		end
		v_u_111.back.Visible = false
		v_u_111.face.Visible = true
		local v513 = v_u_111.well
		local v514 = v_u_111.name
		local v515 = v_u_111.count
		v513.Visible = false
		v514.Visible = false
		v515.Visible = false
		v_u_135(v511, v_u_13.flip / 2, {
			["Size"] = UDim2.fromOffset(232, 322)
		}, Enum.EasingStyle.Quad)
		v_u_135(v_u_111.cardScale, 0.3, {
			["Scale"] = 1.14
		}, Enum.EasingStyle.Back, Enum.EasingDirection.Out, v_u_13.flip / 2)
		v_u_111.icon.Visible = false
		v_u_22.Set(v_u_111.icon, p503.item, {
			["spin"] = true,
			["outline"] = true,
			["glow"] = false,
			["outlineColor"] = nil,
			["outlineScale"] = 1.04,
			["outlineTransparency"] = 0.45,
			["outlineColor"] = v505:Lerp(Color3.new(1, 1, 1), 0.5)
		})
		if not v_u_362(p_u_501, v_u_13.flip / 2, true) then
			return false
		end
		local v516 = v_u_111.well
		local v517 = v_u_111.name
		local v518 = v_u_111.count
		v516.Visible = true
		v517.Visible = true
		v518.Visible = true
		v_u_111.icon.Visible = true
		v_u_111.iconScale.Scale = 0.6
		v_u_135(v_u_111.iconScale, 0.3, {
			["Scale"] = 1
		}, Enum.EasingStyle.Back)
		local v519 = p_u_17.Sounds.Play
		local v520 = {}
		local v521 = p502 - 1
		v520.pitch = math.min(v521, 4) * 0.04 + 1
		v519("Card_Reveal", v520)
		v_u_111.sheen.BackgroundTransparency = 0.55
		v_u_111.sheenGrad.Offset = Vector2.new(-1, 0)
		v_u_135(v_u_111.sheenGrad, 0.45, {
			["Offset"] = Vector2.new(1, 0)
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
		v_u_111.cardGlow.ImageTransparency = 0.35
		v_u_135(v_u_111.cardGlow, 0.8, {
			["ImageTransparency"] = 0.62
		}, Enum.EasingStyle.Quad)
		v_u_111.frontPool:Burst(14, {
			["mode"] = "point",
			["at"] = nil,
			["jitter"] = 130,
			["speedMin"] = 250,
			["speedMax"] = 700,
			["sparkChance"] = 0.5,
			["sparkLen"] = 110,
			["size"] = 20,
			["grav"] = 400,
			["drag"] = 2,
			["lifeMin"] = 0.4,
			["lifeMax"] = 0.8,
			["colors"] = nil,
			["whiteChance"] = 0,
			["at"] = Vector2.new(0, -64),
			["colors"] = { v505, v505:Lerp(Color3.new(1, 1, 1), 0.4) }
		})
		local v522 = p503.levelBefore
		local v523 = p503.need
		local v524 = v_u_447
		local v525 = p503.before
		local v526 = p503.total
		local v527 = v523 or p503.total
		v524(p503, v525, v523, v522, v505, (math.min(v526, v527)))
		local v528 = not v523 and 1 or p503.before / v523
		local v529 = math.clamp(v528, 0, 1)
		v_u_111.barFill.Size = UDim2.fromScale(v529, 1)
		v_u_111.barHead.Position = UDim2.fromOffset(v529 * v_u_14.barW, 43)
		v_u_111.barBox.Visible = true
		v_u_111.barBox.Position = UDim2.fromOffset(0, 128)
		v_u_18.FadeIn(v_u_111.barBox, TweenInfo.new(v_u_109 * 0.18))
		local v_u_530 = p503.shards
		task.spawn(function()
			-- upvalues: (copy) v_u_530, (ref) v_u_13, (copy) p_u_501, (ref) v_u_112, (ref) v_u_111, (ref) p_u_17, (ref) v_u_109, (ref) v_u_135
			local v531 = v_u_530
			local v532 = math.min(v531, 12)
			local v533 = v_u_13.count / math.max(v532, 1)
			for v534 = 1, v532 do
				local v535 = p_u_501
				local v536
				if v_u_112 == nil then
					v536 = false
				else
					v536 = v_u_112.token == v535
				end
				if not v536 or (v_u_112.hurry or v_u_112.skip) then
					break
				end
				local v537 = v_u_111.countText
				local v538 = v_u_530 * v534 / v532 + 0.5
				v537.Text = "x" .. math.floor(v538)
				p_u_17.Sounds.Play("Tick", {
					["pitch"] = nil,
					["volume"] = 0.8,
					["pitch"] = v534 * 0.045 + 1
				})
				task.wait(v533 * v_u_109)
			end
			local v539 = p_u_501
			local v540
			if v_u_112 == nil then
				v540 = false
			else
				v540 = v_u_112.token == v539
			end
			if v540 then
				v_u_111.countText.Text = "x" .. v_u_530
				v_u_111.countScale.Scale = 1.35
				v_u_135(v_u_111.countScale, 0.25, {
					["Scale"] = 1
				}, Enum.EasingStyle.Back)
			end
		end)
		p_u_17.Sounds.Play("XP_Tick", {
			["volume"] = 0.9
		})
		local v541
		if v523 then
			local v542 = p503.total / v523
			v541 = math.min(1, v542)
		else
			v541 = 1
		end
		v_u_111.barHead.ImageColor3 = v505:Lerp(Color3.new(1, 1, 1), 0.45)
		v_u_111.barHead.ImageTransparency = 0.05
		v_u_452(v541, false)
		v_u_135(v_u_111.barHead, v_u_13.bar + 0.25, {
			["ImageTransparency"] = 1
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.In, 0.1)
		v_u_112.headOpts = {
			["mode"] = "point",
			["at"] = nil,
			["jitter"] = 6,
			["dir"] = -90,
			["spread"] = 70,
			["speedMin"] = 60,
			["speedMax"] = 200,
			["kind"] = "sparkle",
			["size"] = 16,
			["grav"] = 300,
			["drag"] = 1,
			["lifeMin"] = 0.3,
			["lifeMax"] = 0.6,
			["colors"] = nil,
			["whiteChance"] = 0,
			["at"] = Vector2.new(-165 + 330 * (not v523 and 0 or p503.before / v523), 171),
			["colors"] = { v505:Lerp(Color3.new(1, 1, 1), 0.4) }
		}
		local v543 = v_u_111.frontPool:Emit(34, v_u_112.headOpts)
		local v544 = v_u_362
		local v545 = v_u_13.bar
		local v546 = v_u_13.count
		local v547 = v544(p_u_501, math.max(v545, v546) * v510, true)
		v543()
		if v_u_112 then
			v_u_112.headOpts = nil
		end
		if not v547 then
			return false
		end
		v_u_111.countText.Text = "x" .. v_u_530
		v_u_139()
		v_u_112.group = nil
		v_u_112.hurry = false
		v_u_112.tapped = false
		if p503.unlocked then
			v_u_111.barFlash.BackgroundColor3 = v_u_23.Gold
			v_u_111.barFlash.BackgroundTransparency = 0.2
			v_u_135(v_u_111.barFlash, 0.4, {
				["BackgroundTransparency"] = 1
			}, Enum.EasingStyle.Quad)
			if not v_u_362(p_u_501, 0.18, false) then
				return false
			end
			if not v_u_500(p_u_501, p503) then
				return false
			end
			v_u_112.phase = "card"
			v_u_111.tag.BackgroundColor3 = v_u_23.Gold
			v_u_111.tagText.Text = "NEW"
			v_u_111.tagText.TextColor3 = v_u_23.TextDark
			v_u_18.Pop(v_u_111.tag, 1.6)
			v_u_447(p503, p503.surplus, p503.needAfter, 1, v505, p503.surplus)
			local v548 = not p503.needAfter and 1 or p503.surplus / p503.needAfter
			local v549 = math.clamp(v548, 0, 1)
			v_u_111.barFill.Size = UDim2.fromScale(v549, 1)
			v_u_111.barHead.Position = UDim2.fromOffset(v549 * v_u_14.barW, 43)
		end
		if p503.ready then
			v_u_111.stamp.Visible = true
			v_u_111.stampScale.Scale = 2.4
			v_u_111.stamp.Rotation = -18
			v_u_135(v_u_111.stampScale, 0.22, {
				["Scale"] = 1
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			v_u_135(v_u_111.stamp, 0.22, {
				["Rotation"] = -8
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			p_u_17.Sounds.Play("Upgrade_Ready")
			if not v_u_362(p_u_501, 0.22, false) then
				return false
			end
			v_u_300 = 8
			v_u_301 = 0
			v_u_302 = 0.2
			v_u_111.barGrad.Color = ColorSequence.new(v_u_19.Lighten(v_u_23.Success, 0.15), v_u_23.SuccessDark)
			v_u_111.barFlash.BackgroundColor3 = v_u_23.Success
			v_u_111.barFlash.BackgroundTransparency = 0.25
			v_u_135(v_u_111.barFlash, 0.4, {
				["BackgroundTransparency"] = 1
			}, Enum.EasingStyle.Quad)
			v_u_111.frontPool:Burst(16, {
				["mode"] = "point",
				["at"] = nil,
				["jitter"] = 110,
				["speedMin"] = 250,
				["speedMax"] = 650,
				["sparkChance"] = 0.5,
				["sparkLen"] = 110,
				["size"] = 20,
				["grav"] = 500,
				["drag"] = 1.8,
				["lifeMin"] = 0.4,
				["lifeMax"] = 0.8,
				["colors"] = nil,
				["whiteChance"] = 0,
				["at"] = Vector2.new(0, -67.42),
				["colors"] = { v_u_23.Success, v_u_19.Lighten(v_u_23.Success, 0.4) }
			})
		end
		v_u_112.hurry = false
		v_u_112.tapped = false
		v_u_362(p_u_501, v_u_13.dwell * v510 + (p503.ready and 0.35 or 0), true)
		local v550
		if v_u_112 == nil then
			v550 = false
		else
			v550 = v_u_112.token == p_u_501
		end
		if not v550 or v_u_112.skip then
			return false
		end
		if p502 ~= #v_u_112.reveal.stacks then
			v_u_135(v511, v_u_13.cardOut, {
				["Position"] = UDim2.fromOffset(p502 % 2 == 0 and 520 or -520, -104),
				["Rotation"] = p502 % 2 == 0 and 14 or -14
			}, Enum.EasingStyle.Quint, Enum.EasingDirection.In)
			v_u_135(v_u_111.cardScale, v_u_13.cardOut, {
				["Scale"] = 0.6839999999999999
			}, Enum.EasingStyle.Quint, Enum.EasingDirection.In)
			v_u_18.FadeOut(v_u_111.barBox, TweenInfo.new(v_u_13.cardOut * 0.8 * v_u_109))
			if not v_u_362(p_u_501, v_u_13.cardOut, false) then
				return false
			end
			v511.Visible = false
			v_u_18.Unfade(v_u_111.barBox)
			v_u_111.barBox.Visible = false
		end
		return true
	end
	local function v_u_566(p552) -- name: tileFor
		-- upvalues: (copy) v_u_111, (copy) v_u_18, (copy) v_u_23, (copy) v_u_24, (copy) v_u_19
		local v553 = v_u_111.tiles[p552]
		if v553 then
			return v553
		end
		local v554 = v_u_18.new("Frame", {
			["Name"] = "Tile" .. p552,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Size"] = UDim2.fromOffset(168, 236),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["ZIndex"] = 12,
			v_u_18.Corner(14),
			["Parent"] = v_u_111.sumRow
		})
		local v555 = v_u_18.new("UIGradient", {
			["Rotation"] = 90,
			["Parent"] = nil,
			["Parent"] = v554
		})
		local v556 = v_u_18.Stroke(v_u_23.Accent, 2.5, 0.1)
		v556.Parent = v554
		local v557 = v_u_18.new("UIScale", {
			["Parent"] = v554
		})
		local v558 = v_u_18.new("Frame", {
			["Position"] = UDim2.fromOffset(8, 8),
			["Size"] = UDim2.new(1, -16, 0, 132),
			["BackgroundColor3"] = v_u_23.Void,
			["BackgroundTransparency"] = 0.45,
			["ZIndex"] = 13,
			v_u_18.Corner(10),
			["Parent"] = v554
		})
		local v559 = v_u_18.new("Frame", {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 14,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(126, 126),
			["Parent"] = v558
		})
		local v560 = v_u_18.new("TextLabel", {
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 17,
			["TextTruncate"] = nil,
			["ZIndex"] = 14,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(8, 146),
			["Size"] = UDim2.new(1, -16, 0, 22),
			["FontFace"] = v_u_24.Heavy,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v554
		})
		v_u_18.TextStroke(v_u_23.Void, 1.5, 0.45).Parent = v560
		local v561 = v_u_18.new("TextLabel", {
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 28,
			["ZIndex"] = 14,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(8, 168),
			["Size"] = UDim2.new(1, -16, 0, 30),
			["FontFace"] = v_u_24.Display,
			["Parent"] = v554
		})
		v_u_18.TextStroke(v_u_23.Void, 1.5, 0.4).Parent = v561
		local v562 = v_u_18.new("Frame", {
			["Position"] = UDim2.fromOffset(12, 206),
			["Size"] = UDim2.new(1, -24, 0, 12),
			["BackgroundColor3"] = v_u_23.Void,
			["BackgroundTransparency"] = 0.25,
			["ClipsDescendants"] = true,
			["ZIndex"] = 14,
			v_u_18.Corner(v_u_19.Radius.Pill),
			["Parent"] = v554
		})
		local v563 = v_u_18.new("Frame", {
			["Size"] = UDim2.fromScale(0, 1),
			["BackgroundColor3"] = v_u_23.Accent,
			["ZIndex"] = 15,
			v_u_18.Corner(v_u_19.Radius.Pill),
			["Parent"] = v562
		})
		local v564 = v_u_18.new("Frame", {
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(0.5, 0, 0, 8),
			["Size"] = UDim2.fromOffset(120, 28),
			["BackgroundColor3"] = v_u_23.Gold,
			["ZIndex"] = 16,
			v_u_18.Corner(v_u_19.Radius.Pill),
			["Parent"] = v554
		})
		local v565 = {
			["frame"] = v554,
			["grad"] = v555,
			["stroke"] = v556,
			["scale"] = v557,
			["icon"] = v559,
			["name"] = v560,
			["count"] = v561,
			["barFill"] = v563,
			["tag"] = v564,
			["tagText"] = v_u_18.new("TextLabel", {
				["Size"] = nil,
				["Text"] = "NEW",
				["FontFace"] = nil,
				["TextSize"] = 16,
				["TextColor3"] = nil,
				["ZIndex"] = 17,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["FontFace"] = v_u_24.Display,
				["TextColor3"] = v_u_23.TextDark,
				["Parent"] = v564
			})
		}
		v_u_111.tiles[p552] = v565
		return v565
	end
	local function v_u_614(p567) -- name: phaseSummary
		-- upvalues: (ref) v_u_112, (copy) v_u_303, (copy) v_u_111, (copy) v_u_22, (copy) v_u_135, (copy) v_u_375, (copy) v_u_140, (copy) v_u_566, (copy) v_u_64, (copy) v_u_23, (copy) v_u_21, (copy) v_u_19, (copy) p_u_17, (ref) v_u_13, (copy) v_u_362
		local v568 = v_u_112.reveal
		local v569 = v_u_112.look
		v_u_112.phase = "summary"
		v_u_112.skip = false
		v_u_112.hurry = false
		v_u_112.tapped = false
		v_u_303.on = false
		if v_u_112.stopSparkles then
			v_u_112.stopSparkles()
			v_u_112.stopSparkles = nil
		end
		v_u_111.card.Visible = false
		v_u_111.barBox.Visible = false
		v_u_111.newRoot.Visible = false
		v_u_22.Set(v_u_111.newItem, nil)
		v_u_22.Set(v_u_111.icon, nil)
		v_u_111.prompt.Visible = false
		v_u_111.counter.Visible = false
		v_u_111.skip.Visible = false
		v_u_111.leak.ImageTransparency = 1
		v_u_111.leakFlare.ImageTransparency = 1
		v_u_111.beam.ImageTransparency = 1
		if not v_u_112.summaryOnly then
			v_u_135(v_u_111.chestHolder, 0.3, {
				["Position"] = UDim2.fromOffset(0, 350)
			}, Enum.EasingStyle.Quint, Enum.EasingDirection.In)
			v_u_135(v_u_111.vpf, 0.25, {
				["ImageTransparency"] = 1
			}, Enum.EasingStyle.Quad)
			v_u_135(v_u_111.chestGlow, 0.25, {
				["ImageTransparency"] = 1
			}, Enum.EasingStyle.Quad)
			v_u_135(v_u_111.shadow, 0.25, {
				["ImageTransparency"] = 1
			}, Enum.EasingStyle.Quad)
		end
		if v_u_111.title.TextTransparency > 0.5 then
			v_u_375(v569.title, v_u_112.subtitle)
		end
		v_u_135(v_u_111.dim, 0.3, {
			["BackgroundTransparency"] = 0.12
		}, Enum.EasingStyle.Quad)
		v_u_111.raysHolder.Position = UDim2.fromOffset(0, -40)
		v_u_111.raysScale.Scale = 1
		local v570 = v_u_135
		local v571 = v_u_111.raysA
		local v572 = {}
		local v573 = v569.rays + 0.1
		v572.ImageTransparency = math.min(0.9, v573)
		v570(v571, 0.4, v572, Enum.EasingStyle.Quad)
		local v574 = v_u_135
		local v575 = v_u_111.raysB
		local v576 = {}
		local v577 = v569.rays + 0.2
		v576.ImageTransparency = math.min(0.94, v577)
		v574(v575, 0.4, v576, Enum.EasingStyle.Quad)
		v_u_135(v_u_111.halo, 0.4, {
			["ImageTransparency"] = 0.62,
			["Size"] = nil,
			["Size"] = UDim2.fromOffset(900, 700)
		}, Enum.EasingStyle.Quad)
		v_u_140.raysSpin = 6
		local v578 = #v568.stacks
		local v579 = v578 * 186 - 18
		local v580 = 1040 / math.max(1, v579)
		local v581 = math.min(1.14, v580)
		local v582 = #v_u_111.tiles
		for v583 = 1, math.max(v578, v582) do
			local v584 = v568.stacks[v583]
			if v584 then
				local v585 = v_u_566(v583)
				local v586 = v_u_64(v584.item)
				v585.frame.Visible = true
				v585.grad.Color = ColorSequence.new(v586:Lerp(v_u_23.Void, 0.2), v586:Lerp(v_u_23.Void, 0.7))
				v585.stroke.Color = v586:Lerp(Color3.new(1, 1, 1), 0.4)
				v585.name.Text = string.upper(v_u_21.Name(v584.item))
				v585.count.Text = "x" .. v584.shards
				local v587 = v584.levelBefore
				local v588 = v584.total
				local v589 = v584.need
				if v584.unlocked then
					v588 = v584.surplus
					v589 = v584.needAfter
					v587 = 1
				end
				local v590 = v585.barFill
				local v591 = UDim2.fromScale
				local v592
				if v589 then
					local v593 = v588 / v589
					v592 = math.clamp(v593, 0, 1)
				else
					v592 = 1
				end
				v590.Size = v591(v592, 1)
				local v594 = v585.barFill
				if v584.ready then
					v586 = v_u_23.Success
				end
				v594.BackgroundColor3 = v586
				if v584.unlocked then
					v585.tag.Visible = true
					v585.tag.BackgroundColor3 = v_u_23.Gold
					v585.tagText.Text = "NEW ITEM"
					v585.tagText.TextColor3 = v_u_23.TextDark
				elseif v584.ready then
					v585.tag.Visible = true
					v585.tag.BackgroundColor3 = v_u_23.Success
					v585.tagText.Text = "UPGRADE"
					v585.tagText.TextColor3 = v_u_23.Text
				elseif v587 <= 0 then
					v585.tag.Visible = true
					v585.tag.BackgroundColor3 = v_u_23.Raised
					v585.tagText.Text = string.format("%d / %d", v588, v589 or 0)
					v585.tagText.TextColor3 = v_u_23.TextDim
				else
					v585.tag.Visible = true
					v585.tag.BackgroundColor3 = v_u_23.Raised
					v585.tagText.Text = "LV " .. v587
					v585.tagText.TextColor3 = v_u_23.Text
				end
				v_u_22.Set(v585.icon, v584.item, {
					["outline"] = false,
					["glow"] = false
				})
				local v595 = (v583 - 1 - (v578 - 1) / 2) * 186 * v581
				v585.frame.Position = UDim2.fromOffset(v595, 60)
				v585.scale.Scale = 0
				v_u_135(v585.frame, 0.4, {
					["Position"] = UDim2.fromOffset(v595, 0)
				}, Enum.EasingStyle.Back, Enum.EasingDirection.Out, (v583 - 1) * 0.07 + 0.05)
				v_u_135(v585.scale, 0.4, {
					["Scale"] = v581
				}, Enum.EasingStyle.Back, Enum.EasingDirection.Out, (v583 - 1) * 0.07 + 0.05)
			else
				local v596 = v_u_111.tiles[v583]
				if not v596 then
					continue
				end
				v596.frame.Visible = false
				v_u_22.Set(v596.icon, nil)
			end
		end
		local v597 = 0
		local v598 = 0
		local v599 = 0
		for _, v600 in v568.stacks do
			v597 = v597 + v600.shards
			if v600.unlocked then
				v598 = v598 + 1
			end
			if not v600.ready then
				continue
			end
			v599 = v599 + 1
		end
		local v601 = { string.format("<font color=\"#%s\">+%d</font> SHARDS", v569.light:ToHex(), v597) }
		if v598 > 0 then
			local v602 = string.format
			local v603 = v_u_23.Gold:ToHex()
			local v604 = v598 > 1 and "S" or ""
			table.insert(v601, v602("<font color=\"#%s\">%d NEW ITEM%s</font>", v603, v598, v604))
		end
		if v599 > 0 then
			local v605 = string.format
			local v606 = v_u_19.Lighten(v_u_23.Success, 0.2):ToHex()
			local v607 = v599 > 1 and "S" or ""
			table.insert(v601, v605("<font color=\"#%s\">%d UPGRADE%s READY</font>", v606, v599, v607))
		end
		local v608 = v578 == 0 and { not v568.xp and "EVERYTHING MAXED" or string.format("EVERYTHING MAXED  \194\183  +%d XP", v568.xp) } or v601
		v_u_111.sumTotals.Text = table.concat(v608, "   \194\183   ")
		local v609 = v_u_111.sumTotals
		v609.TextTransparency = 1
		local v610
		if v609:IsA("TextLabel") then
			v610 = v609:FindFirstChildWhichIsA("UIStroke")
		else
			v610 = nil
		end
		local v611
		if v610 then
			local v612 = v610:GetAttribute("Authored")
			if type(v612) == "number" then
				v611 = 1
			else
				v610:SetAttribute("Authored", v610.Transparency)
				v611 = 1
			end
		else
			v610 = nil
			v611 = 1
		end
		if v610 then
			v610.Transparency = v611
		end
		v_u_135(v_u_111.sumTotals, 0.3, {
			["TextTransparency"] = 0
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, v578 * 0.07 + 0.25)
		v_u_111.sumRoot.Visible = true
		v_u_111.cont.Visible = true
		v_u_111.contScale.Scale = 0
		v_u_135(v_u_111.contScale, 0.35, {
			["Scale"] = 1
		}, Enum.EasingStyle.Back, Enum.EasingDirection.Out, v578 * 0.07 + 0.35)
		p_u_17.Sounds.Play("Reward")
		v_u_111.frontPool:Burst(v569.legendary and 34 or 20, {
			["mode"] = "point",
			["at"] = nil,
			["jitter"] = 380,
			["speedMin"] = 40,
			["speedMax"] = 180,
			["kind"] = "sparkle",
			["size"] = 28,
			["grav"] = -40,
			["drag"] = 0.6,
			["lifeMin"] = 0.9,
			["lifeMax"] = 1.7,
			["colors"] = nil,
			["whiteChance"] = 0,
			["at"] = Vector2.new(0, -40),
			["colors"] = { v569.light, v569.primary }
		})
		local v613 = v_u_112.opts.autoContinue or (v_u_13.summaryAuto[v_u_112.source] or 6)
		v_u_111.contFillGrad.Offset = Vector2.new(-0.5, 0)
		v_u_135(v_u_111.contFillGrad, v613, {
			["Offset"] = Vector2.new(0.5, 0)
		}, Enum.EasingStyle.Linear)
		if v_u_362(p567, 0.45, false) then
			v_u_362(p567, v613 - 0.45, true)
		end
	end
	local function v_u_617() -- name: hideAll
		-- upvalues: (copy) v_u_111, (copy) v_u_22, (copy) v_u_164, (ref) v_u_165
		v_u_111.root.Visible = false
		v_u_111.card.Visible = false
		v_u_111.barBox.Visible = false
		v_u_111.newRoot.Visible = false
		v_u_111.sumRoot.Visible = false
		v_u_111.prompt.Visible = false
		v_u_111.counter.Visible = false
		v_u_111.skip.Visible = false
		v_u_111.chestHolder.Visible = false
		v_u_22.Set(v_u_111.icon, nil)
		v_u_22.Set(v_u_111.newItem, nil)
		for _, v615 in v_u_111.tiles do
			v_u_22.Set(v615.icon, nil)
			v615.frame.Visible = false
		end
		v_u_111.backPool:Clear()
		v_u_111.frontPool:Clear()
		for _, v616 in v_u_164 do
			v616.part:Destroy()
		end
		table.clear(v_u_164)
		v_u_165 = nil
	end
	local v_u_618 = {}
	local function v_u_649(p619) -- name: fadeOut
		-- upvalues: (copy) v_u_618, (ref) v_u_5, (copy) v_u_111
		for _, v620 in v_u_618 do
			v620:Cancel()
		end
		table.clear(v_u_618)
		local v621 = TweenInfo.new(p619, Enum.EasingStyle.Quad)
		local v622 = v_u_5:Create(v_u_111.dim, v621, {
			["BackgroundTransparency"] = 1
		})
		v622:Play()
		local v623 = v_u_618
		table.insert(v623, v622)
		local v624 = v_u_5:Create(v_u_111.vignette, v621, {
			["ImageTransparency"] = 1
		})
		v624:Play()
		local v625 = v_u_618
		table.insert(v625, v624)
		local v626 = v_u_5:Create(v_u_111.tint, v621, {
			["ImageTransparency"] = 1
		})
		v626:Play()
		local v627 = v_u_618
		table.insert(v627, v626)
		local v628 = v_u_5:Create(v_u_111.flash, v621, {
			["BackgroundTransparency"] = 1
		})
		v628:Play()
		local v629 = v_u_618
		table.insert(v629, v628)
		for _, v630 in {
			v_u_111.raysA,
			v_u_111.raysB,
			v_u_111.halo,
			v_u_111.vpf,
			v_u_111.chestGlow,
			v_u_111.shadow
		} do
			local v631 = v_u_5:Create(v630, v621, {
				["ImageTransparency"] = 1
			})
			v631:Play()
			local v632 = v_u_618
			table.insert(v632, v631)
		end
		for _, v633 in {
			v_u_111.title,
			v_u_111.titleShadow,
			v_u_111.subtitle,
			v_u_111.sumTotals
		} do
			local v634 = v_u_5:Create(v633, v621, {
				["TextTransparency"] = 1
			})
			v634:Play()
			local v635 = v_u_618
			table.insert(v635, v634)
			local v636
			if v633:IsA("TextLabel") then
				v636 = v633:FindFirstChildWhichIsA("UIStroke")
			else
				v636 = nil
			end
			if v636 then
				local v637 = v636:GetAttribute("Authored")
				if type(v637) ~= "number" then
					v636:SetAttribute("Authored", v636.Transparency)
				end
			else
				v636 = nil
			end
			if not v636 then
				continue
			end
			local v638 = v_u_5:Create(v636, v621, {
				["Transparency"] = 1
			})
			v638:Play()
			local v639 = v_u_618
			table.insert(v639, v638)
		end
		local v640 = v_u_5:Create(v_u_111.contScale, v621, {
			["Scale"] = 0
		})
		v640:Play()
		local v641 = v_u_618
		table.insert(v641, v640)
		local v642 = v_u_5:Create(v_u_111.cardScale, v621, {
			["Scale"] = 0
		})
		v642:Play()
		local v643 = v_u_618
		table.insert(v643, v642)
		local v644 = v_u_5:Create(v_u_111.skip, v621, {
			["BackgroundTransparency"] = 1
		})
		v644:Play()
		local v645 = v_u_618
		table.insert(v645, v644)
		for _, v646 in v_u_111.tiles do
			local v647 = v_u_5:Create(v646.scale, v621, {
				["Scale"] = 0
			})
			v647:Play()
			local v648 = v_u_618
			table.insert(v648, v647)
		end
	end
	local v_u_650 = {
		["TR_TopbarSettings"] = true,
		["CombatHUD"] = true,
		["CombatTouch"] = true,
		["CharacterTouch"] = true,
		["TouchGui"] = true,
		["Chat"] = true,
		["BubbleChat"] = true
	}
	local v_u_651 = {
		["TR_Replay"] = true,
		["TR_ReplayFrame"] = true,
		["TR_ReplayHud"] = true
	}
	local v_u_652 = {}
	local v_u_653 = {}
	local v_u_654 = false
	local function v_u_659(p_u_655) -- name: hideCollector
		-- upvalues: (copy) v_u_111, (copy) v_u_650, (copy) p_u_17, (copy) v_u_651, (copy) v_u_652, (copy) v_u_653
		if p_u_655 == v_u_111.gui or v_u_650[p_u_655.Name] then
			return
		else
			local v656 = p_u_655:FindFirstAncestorWhichIsA("ScreenGui")
			if not v656 or v656.Name ~= "Chat" and v656.Name ~= "BubbleChat" then
				if p_u_655:IsA("ScreenGui") then
					if p_u_655.Parent == p_u_17.PlayerGui and p_u_655.Enabled then
						p_u_655.Enabled = false
						if not v_u_651[p_u_655.Name] then
							v_u_652[p_u_655] = true
							return
						end
					end
				elseif (p_u_655:IsA("BillboardGui") or p_u_655:IsA("SurfaceGui")) and v_u_653[p_u_655] == nil then
					local function v658()
						-- upvalues: (copy) p_u_655, (ref) v_u_653
						local v657 = p_u_655.MaxDistance
						p_u_655.MaxDistance = 0.001
						v_u_653[p_u_655] = v657
					end
					pcall(v658)
				end
			end
		end
	end
	local function v_u_663() -- name: sweepUi
		-- upvalues: (copy) p_u_17, (copy) v_u_659, (ref) v_u_8
		for _, v660 in p_u_17.PlayerGui:GetDescendants() do
			if not v660:IsA("LayerCollector") then
				continue
			end
			v_u_659(v660)
		end
		local v661 = v_u_8:FindFirstChild("TR_ContractDisplay")
		if v661 then
			for _, v662 in v661:GetDescendants() do
				if not v662:IsA("LayerCollector") then
					continue
				end
				v_u_659(v662)
			end
		end
	end
	local function v_u_668(p664) -- name: setAllUiHidden
		-- upvalues: (ref) v_u_654, (copy) v_u_663, (ref) v_u_7, (copy) v_u_652, (copy) v_u_653, (copy) p_u_17
		if v_u_654 == p664 then
			return
		else
			v_u_654 = p664
			if p664 then
				v_u_663()
				v_u_7.Enabled = false
			else
				for v665 in v_u_652 do
					if not v665.Parent then
						continue
					end
					v665.Enabled = true
				end
				table.clear(v_u_652)
				for v_u_666, v_u_667 in v_u_653 do
					if not v_u_666.Parent then
						continue
					end
					pcall(function()
						-- upvalues: (copy) v_u_666, (copy) v_u_667
						v_u_666.MaxDistance = v_u_667
					end)
				end
				table.clear(v_u_653)
				v_u_7.Enabled = not p_u_17.MenuManager.IsOpen()
			end
		end
	end
	function v_u_29._SweepUi()
		-- upvalues: (ref) v_u_654, (copy) v_u_663
		if v_u_654 then
			v_u_663()
		end
	end
	local v_u_669 = nil
	local v_u_670 = false
	local function v_u_677(p671) -- name: setPlaying
		-- upvalues: (ref) v_u_114, (copy) p_u_17, (ref) v_u_670, (copy) v_u_29, (copy) v_u_668
		if v_u_114 ~= p671 then
			v_u_114 = p671
			p_u_17.SetHudHidden("Reveal", p671)
			p_u_17.MenuManager.HoldChat("Reveal", p671)
			if p671 then
				p_u_17.MenuManager.PushMouse("DropReveal")
				if p_u_17.Canvas.Menus.Visible then
					p_u_17.Canvas.Menus.Visible = false
					v_u_670 = true
				end
			else
				p_u_17.MenuManager.PopMouse("DropReveal")
				if v_u_670 then
					p_u_17.Canvas.Menus.Visible = true
					v_u_670 = false
				end
			end
			v_u_29.Changed:Fire(p671)
			if p_u_17.TopbarSettings then
				local v672 = p_u_17.TopbarSettings.SetHidden
				if type(v672) == "function" then
					local v673 = p_u_17.TopbarSettings.SetHidden
					pcall(v673, "Reveal", p671)
				end
			end
			v_u_668(p671)
			local v674 = p_u_17.Economy
			if v674 then
				local v675 = v674.SetRevealShowing
				if type(v675) == "function" then
					local v676 = v674.SetRevealShowing
					pcall(v676, p671)
				end
			end
		end
	end
	local function v_u_682(p678, p679) -- name: finish
		-- upvalues: (ref) v_u_112, (ref) v_u_113, (copy) v_u_303, (copy) v_u_141, (ref) v_u_669, (copy) v_u_617, (ref) v_u_288, (ref) v_u_289, (ref) v_u_298, (ref) v_u_109, (copy) v_u_649, (copy) v_u_297, (copy) v_u_677, (copy) v_u_29
		if v_u_112 then
			local v680 = v_u_112
			v_u_112 = nil
			v_u_113 = v_u_113 + 1
			local v_u_681 = v_u_113
			v_u_303.on = false
			table.clear(v_u_141)
			if v_u_669 then
				v_u_669()
				v_u_669 = nil
			end
			if p679 then
				if v_u_681 == v_u_113 then
					v_u_617()
					if v_u_288 then
						v_u_288:Destroy()
						v_u_288 = nil
					end
					if v_u_289 then
						v_u_289:Destroy()
						v_u_289 = nil
					end
					if v_u_298 then
						v_u_298:Disconnect()
						v_u_298 = nil
					end
					v_u_109 = 1
				end
			else
				v_u_649(0.28)
				v_u_297(0.3)
				task.delay(0.3, function()
					-- upvalues: (copy) v_u_681, (ref) v_u_113, (ref) v_u_617, (ref) v_u_288, (ref) v_u_289, (ref) v_u_298, (ref) v_u_109
					if v_u_681 == v_u_113 then
						if v_u_681 ~= v_u_113 then
							return
						end
						v_u_617()
						if v_u_288 then
							v_u_288:Destroy()
							v_u_288 = nil
						end
						if v_u_289 then
							v_u_289:Destroy()
							v_u_289 = nil
						end
						if v_u_298 then
							v_u_298:Disconnect()
							v_u_298 = nil
						end
						v_u_109 = 1
					end
				end)
			end
			v_u_677(false)
			if v680.opts.onDone then
				task.spawn(v680.opts.onDone, p678, v680.reveal.raw)
			end
			if p678 ~= "interrupted" and (v680.reveal.id ~= "" and not v680.summaryOnly) then
				v_u_29._Seen(v680.reveal.id)
			end
			v_u_29._Pump()
		end
	end
	function v_u_29.Skip() -- name: Skip
		-- upvalues: (ref) v_u_112, (copy) p_u_17
		if v_u_112 and (v_u_112.phase ~= "summary" and not v_u_112.skip) then
			v_u_112.skip = true
			p_u_17.Sounds.Play("Click")
		end
	end
	local function v_u_686() -- name: tap
		-- upvalues: (ref) v_u_112, (ref) v_u_109, (copy) v_u_139, (copy) v_u_141, (copy) v_u_140
		if v_u_112 then
			if v_u_112.phase == "land" then
				v_u_112.tapped = true
			elseif v_u_112.phase == "summary" then
				if os.clock() - (v_u_112.summaryAt or 0) > v_u_109 * 0.35 then
					v_u_112.tapped = true
					return
				end
			else
				if v_u_112.phase == "card" then
					if v_u_112.hurry or not v_u_112.group then
						v_u_112.tapped = true
					else
						v_u_112.hurry = true
						v_u_139()
						for v683, v684 in v_u_141 do
							local v685 = v684[#v684]
							if not v685 then
								continue
							end
							v_u_140[v683] = v685.to
						end
						table.clear(v_u_141)
					end
				end
				v_u_112.tapped = true
			end
		else
			return
		end
	end
	v_u_29.Tap = v_u_686
	function v_u_29.Play(p_u_687, p688) -- name: Play
		-- upvalues: (copy) v_u_103, (copy) p_u_17, (copy) v_u_29, (ref) v_u_112, (copy) v_u_682, (copy) v_u_215, (copy) v_u_228, (ref) v_u_109, (copy) v_u_111, (ref) v_u_113, (ref) v_u_12, (copy) v_u_618, (copy) v_u_141, (copy) v_u_140, (ref) v_u_5, (copy) v_u_23, (ref) v_u_300, (copy) v_u_364, (copy) v_u_250, (copy) v_u_677, (copy) v_u_135, (copy) v_u_295, (ref) v_u_298, (ref) v_u_4, (copy) v_u_354, (ref) v_u_6, (copy) v_u_686, (ref) v_u_669, (copy) v_u_375, (copy) v_u_614, (copy) v_u_400, (copy) v_u_420, (copy) v_u_436, (copy) v_u_440, (ref) v_u_14, (copy) v_u_362, (ref) v_u_13, (copy) v_u_551
		local v_u_689 = v_u_103(p_u_687)
		if not v_u_689 then
			return false
		end
		local v690 = p688 or {}
		if v_u_689.source == "rank" and v690.rankShown ~= true then
			if not p_u_17.RankUp then
				p_u_17.EnsureScreen("RankUp")
			end
			if p_u_17.RankUp then
				local v_u_691 = table.clone(v690)
				v_u_691.rankShown = true
				return p_u_17.RankUp.Play(p_u_687, function(p692)
					-- upvalues: (copy) v_u_691, (copy) p_u_687, (ref) v_u_29
					if p692 == "interrupted" then
						if v_u_691.onDone then
							v_u_691.onDone("interrupted", p_u_687)
						end
					else
						v_u_29.Play(p_u_687, v_u_691)
					end
				end)
			end
		end
		if v_u_112 then
			v_u_682("interrupted", true)
		end
		v_u_215()
		v_u_228()
		local v693 = v690.pace
		v_u_109 = (type(v693) ~= "number" or v690.pace <= 0) and 1 or v690.pace
		v_u_111.backPool.Pace = v_u_109
		v_u_111.frontPool.Pace = v_u_109
		v_u_113 = v_u_113 + 1
		local v_u_694 = v_u_113
		local v_u_695 = v_u_12[v_u_689.kind] or v_u_12.drop
		if v_u_689.source == "rank" then
			v_u_695 = table.clone(v_u_695)
			v_u_695.title = "RANK REWARD"
		end
		local v696 = 0
		for _, v697 in v_u_689.stacks do
			v696 = v696 + v697.shards
		end
		v_u_112 = {
			["token"] = nil,
			["reveal"] = nil,
			["look"] = nil,
			["opts"] = nil,
			["source"] = nil,
			["phase"] = "start",
			["tapped"] = false,
			["skip"] = false,
			["hurry"] = false,
			["summaryOnly"] = nil,
			["subtitle"] = nil,
			["token"] = v_u_694,
			["reveal"] = v_u_689,
			["look"] = v_u_695,
			["opts"] = v690,
			["source"] = v690.source or (v_u_689.source or "lobby"),
			["summaryOnly"] = v690.summaryOnly == true,
			["subtitle"] = string.format("%d ITEM%s  \194\183  %d SHARDS", #v_u_689.stacks, #v_u_689.stacks == 1 and "" or "S", v696)
		}
		for _, v698 in v_u_618 do
			v698:Cancel()
		end
		table.clear(v_u_618)
		table.clear(v_u_141)
		local v699 = v_u_140
		local v700 = v_u_140
		local v701 = v_u_140
		local v702 = v_u_140
		local v703 = v_u_140
		local v704 = v_u_140
		local v705 = v_u_140
		v_u_140.y = 0
		v699.yaw = 0
		v700.roll = 0
		v701.pitch = 0
		v702.sq = 0
		v703.lid = 0
		v704.s = 1
		v705.raysSpin = 8
		v_u_111.backPool:Clear()
		v_u_111.frontPool:Clear()
		v_u_111.root.Visible = true
		local v706 = v_u_111.dim
		local v707 = {
			["BackgroundTransparency"] = 1
		}
		v_u_5:Create(v706, TweenInfo.new(0), v707):Play()
		for v708, v709 in v707 do
			v706[v708] = v709
		end
		local v710 = v_u_111.flash
		local v711 = {
			["BackgroundTransparency"] = 1
		}
		v_u_5:Create(v710, TweenInfo.new(0), v711):Play()
		for v712, v713 in v711 do
			v710[v712] = v713
		end
		local v714 = v_u_111.vignette
		local v715 = {
			["ImageTransparency"] = 1,
			["ImageColor3"] = nil,
			["ImageColor3"] = v_u_23.Void
		}
		v_u_5:Create(v714, TweenInfo.new(0), v715):Play()
		for v716, v717 in v715 do
			v714[v716] = v717
		end
		local v718 = v_u_111.skip
		local v719 = {
			["BackgroundTransparency"] = 0.25
		}
		v_u_5:Create(v718, TweenInfo.new(0), v719):Play()
		for v720, v721 in v719 do
			v718[v720] = v721
		end
		for _, v722 in {
			v_u_111.tint,
			v_u_111.raysA,
			v_u_111.raysB,
			v_u_111.halo,
			v_u_111.beam,
			v_u_111.floorRing,
			v_u_111.shadow,
			v_u_111.leak,
			v_u_111.leakFlare,
			v_u_111.chestGlow
		} do
			local v723 = {
				["ImageTransparency"] = 1
			}
			v_u_5:Create(v722, TweenInfo.new(0), v723):Play()
			for v724, v725 in v723 do
				v722[v724] = v725
			end
		end
		local v726 = v_u_111.vpf
		local v727 = {
			["ImageTransparency"] = 0
		}
		v_u_5:Create(v726, TweenInfo.new(0), v727):Play()
		for v728, v729 in v727 do
			v726[v728] = v729
		end
		for _, v730 in {
			v_u_111.title,
			v_u_111.titleShadow,
			v_u_111.subtitle,
			v_u_111.sumTotals
		} do
			local v731 = {
				["TextTransparency"] = 1
			}
			v_u_5:Create(v730, TweenInfo.new(0), v731):Play()
			for v732, v733 in v731 do
				v730[v732] = v733
			end
			local v734
			if v730:IsA("TextLabel") then
				v734 = v730:FindFirstChildWhichIsA("UIStroke")
			else
				v734 = nil
			end
			if v734 then
				local v735 = v734:GetAttribute("Authored")
				if type(v735) ~= "number" then
					v734:SetAttribute("Authored", v734.Transparency)
				end
			else
				v734 = nil
			end
			if not v734 then
				break
			end
			local v736 = {
				["Transparency"] = 1
			}
			v_u_5:Create(v734, TweenInfo.new(0), v736):Play()
			for v737, v738 in v736 do
				v734[v737] = v738
			end
		end
		local v739 = v_u_111.raysScale
		local v740 = {
			["Scale"] = 1
		}
		v_u_5:Create(v739, TweenInfo.new(0), v740):Play()
		for v741, v742 in v740 do
			v739[v741] = v742
		end
		local v743 = v_u_111.contScale
		local v744 = {
			["Scale"] = 0
		}
		v_u_5:Create(v743, TweenInfo.new(0), v744):Play()
		for v745, v746 in v744 do
			v743[v745] = v746
		end
		local v747 = v_u_111.cardScale
		local v748 = {
			["Scale"] = 1.14
		}
		v_u_5:Create(v747, TweenInfo.new(0), v748):Play()
		for v749, v750 in v748 do
			v747[v749] = v750
		end
		local v751 = v_u_111.card
		local v752 = v_u_111.barBox
		local v753 = v_u_111.newRoot
		local v754 = v_u_111.sumRoot
		v751.Visible = false
		v752.Visible = false
		v753.Visible = false
		v754.Visible = false
		local v755 = v_u_111.prompt
		local v756 = v_u_111.counter
		v755.Visible = false
		v756.Visible = false
		v_u_111.shaker.Position = UDim2.new()
		v_u_300 = 0
		v_u_111.chestHolder.Visible = false
		v_u_364(v_u_695)
		v_u_250(v_u_695.model, v_u_695.fit)
		v_u_677(true)
		v_u_135(v_u_111.dim, 0.35, {
			["BackgroundTransparency"] = 0.2
		}, Enum.EasingStyle.Quad)
		v_u_135(v_u_111.vignette, 0.4, {
			["ImageTransparency"] = 0.25
		}, Enum.EasingStyle.Quad)
		v_u_135(v_u_111.tint, 0.6, {
			["ImageTransparency"] = 0.8
		}, Enum.EasingStyle.Quad)
		v_u_295(v_u_695)
		if not v_u_298 then
			v_u_298 = v_u_4.RenderStepped:Connect(v_u_354)
		end
		v_u_111.skip.Visible = not v_u_112.summaryOnly
		v_u_111.skipFill.Size = UDim2.fromScale(0, 1)
		v_u_6:BindActionAtPriority("TR_RevealKeys", function(_, p757, p758)
			-- upvalues: (ref) v_u_29, (ref) v_u_686
			if p757 ~= Enum.UserInputState.Begin then
				return Enum.ContextActionResult.Sink
			end
			if p758.KeyCode == Enum.KeyCode.ButtonB or p758.KeyCode == Enum.KeyCode.ButtonY then
				v_u_29.Skip()
			else
				v_u_686()
			end
			return Enum.ContextActionResult.Sink
		end, false, Enum.ContextActionPriority.High.Value + 50, Enum.KeyCode.Space, Enum.KeyCode.Return, Enum.KeyCode.ButtonA, Enum.KeyCode.ButtonB, Enum.KeyCode.ButtonY)
		v_u_669 = function()
			-- upvalues: (ref) v_u_6
			v_u_6:UnbindAction("TR_RevealKeys")
		end
		task.spawn(xpcall, function()
			-- upvalues: (ref) v_u_112, (ref) v_u_375, (ref) v_u_695, (ref) v_u_614, (copy) v_u_694, (ref) v_u_682, (ref) v_u_400, (ref) v_u_420, (ref) v_u_436, (copy) v_u_689, (ref) v_u_440, (ref) v_u_111, (ref) v_u_14, (ref) v_u_362, (ref) v_u_13, (ref) v_u_551
			if v_u_112 and v_u_112.summaryOnly then
				v_u_375(v_u_695.title, v_u_112.subtitle)
				v_u_112.summaryAt = os.clock()
				v_u_614(v_u_694)
				local v759 = v_u_694
				local v760
				if v_u_112 == nil then
					v760 = false
				else
					v760 = v_u_112.token == v759
				end
				if v760 then
					v_u_682("done")
				end
				return
			else
				local v761 = v_u_400(v_u_694)
				if v761 then
					v761 = v_u_420(v_u_694)
				end
				if v761 then
					v761 = v_u_436(v_u_694)
				end
				if v761 and #v_u_689.stacks > 0 then
					v_u_440()
					local v762 = #v_u_689.stacks
					v_u_111.counter.Visible = v762 > 0
					v_u_111.counterText.Text = "x" .. v762
					if v_u_112 then
						v_u_111.counter.Position = UDim2.fromOffset(128, v_u_14.chestCardY - 62)
					end
					if v_u_362(v_u_694, v_u_13.toCards * 0.6, false) then
						for v763, v764 in v_u_689.stacks do
							if v_u_551(v_u_694, v763, v764) then
								continue
							end
							v761 = false
						end
					else
						v761 = false
					end
				end
				local v765 = v_u_694
				local v766
				if v_u_112 == nil then
					v766 = false
				else
					v766 = v_u_112.token == v765
				end
				if v766 then
					local v767 = v_u_112.skip
					v_u_112.summaryAt = os.clock()
					v_u_614(v_u_694)
					local v768 = v_u_694
					local v769
					if v_u_112 == nil then
						v769 = false
					else
						v769 = v_u_112.token == v768
					end
					if v769 then
						v_u_682(v767 and "skipped" or "done")
					end
				end
			end
		end, function(p770)
			-- upvalues: (ref) v_u_112, (copy) v_u_694, (ref) v_u_682
			warn("[DropReveal] " .. tostring(p770) .. "\n" .. debug.traceback())
			if v_u_112 and v_u_112.token == v_u_694 then
				v_u_682("interrupted", true)
			end
		end)
		return true
	end
	function v_u_29.ShowSummary(p771, p772) -- name: ShowSummary
		-- upvalues: (copy) v_u_29
		local v773 = p772 and table.clone(p772) or {}
		v773.summaryOnly = true
		return v_u_29.Play(p771, v773)
	end
	function v_u_29.Stop(p774) -- name: Stop
		-- upvalues: (ref) v_u_112, (copy) v_u_682
		if v_u_112 then
			v_u_682("interrupted", p774 ~= false)
		end
	end
	function v_u_29.IsPlaying() -- name: IsPlaying
		-- upvalues: (ref) v_u_112
		return v_u_112 ~= nil
	end
	function v_u_29.State() -- name: State
		-- upvalues: (ref) v_u_112, (ref) v_u_109
		return {
			["playing"] = v_u_112 ~= nil,
			["phase"] = v_u_112 and v_u_112.phase or nil,
			["id"] = v_u_112 and v_u_112.reveal.id or nil,
			["kind"] = v_u_112 and v_u_112.reveal.kind or nil,
			["pace"] = v_u_109
		}
	end
	local v_u_775 = false
	local function v_u_780() -- name: wire
		-- upvalues: (ref) v_u_775, (ref) v_u_110, (copy) v_u_111, (ref) v_u_112, (copy) v_u_686, (copy) v_u_29, (copy) v_u_18, (copy) v_u_228
		if not v_u_775 and v_u_110 then
			v_u_775 = true
			v_u_111.catcher.InputBegan:Connect(function(p776)
				-- upvalues: (ref) v_u_112
				local v777 = p776.UserInputType
				if (v777 == Enum.UserInputType.MouseButton1 or v777 == Enum.UserInputType.Touch) and v_u_112 then
					v_u_112.holdAt = os.clock()
				end
			end)
			v_u_111.catcher.InputEnded:Connect(function(p778)
				-- upvalues: (ref) v_u_112, (ref) v_u_111, (ref) v_u_686
				local v779 = p778.UserInputType
				if (v779 == Enum.UserInputType.MouseButton1 or v779 == Enum.UserInputType.Touch) and (v_u_112 and v_u_112.holdAt) then
					v_u_112.holdAt = nil
					v_u_111.skipFill.Size = UDim2.fromScale(0, 1)
					v_u_686()
				end
			end)
			v_u_111.skip.Activated:Connect(function()
				-- upvalues: (ref) v_u_29
				v_u_29.Skip()
			end)
			v_u_111.cont.Activated:Connect(function()
				-- upvalues: (ref) v_u_112
				if v_u_112 and v_u_112.phase == "summary" then
					v_u_112.tapped = true
				end
			end)
			v_u_18.ScaleChanged:Connect(v_u_228)
			v_u_18.TopInsetChanged:Connect(v_u_228)
		end
	end
	local v_u_781 = v_u_29.Play
	function v_u_29.Play(p782, p783)
		-- upvalues: (copy) v_u_781, (copy) v_u_780
		local v784 = v_u_781(p782, p783)
		if v784 then
			v_u_780()
		end
		return v784
	end
	v_u_20.MatchEvent:Connect(function(p785)
		-- upvalues: (ref) v_u_112, (copy) v_u_682
		if p785 == "MatchStart" and v_u_112 then
			v_u_682("interrupted", true)
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_112, (copy) v_u_28, (copy) p_u_17, (copy) v_u_682, (copy) v_u_29
		while true do
			while true do
				task.wait(0.25)
				if v_u_112 and (v_u_28:GetAttribute("ReplayPlaying") == true or (p_u_17.IsHudHiddenFor("Intro") or p_u_17.IsHudHiddenFor("Celebrate"))) then
					break
				end
				if not v_u_112 then
					continue
				end
				v_u_29._SweepUi()
			end
			v_u_682("interrupted", true)
		end
	end)
	local v_u_786 = {}
	local v_u_787 = {}
	local v_u_788 = {}
	local v_u_789 = {}
	local v_u_790 = v_u_20.GetPlayerState() ~= "Lobby" and (1 / 0) or os.clock()
	local function v_u_794(p_u_791) -- name: tryAck
		-- upvalues: (copy) v_u_787, (copy) v_u_788, (copy) v_u_20, (copy) p_u_17
		if v_u_787[p_u_791] or ((v_u_788[p_u_791] or 0) >= 4 or v_u_20.Mock) then
			return
		elseif v_u_20.GetPlayerState() == "Lobby" or (v_u_788[p_u_791] or 0) <= 0 then
			v_u_788[p_u_791] = (v_u_788[p_u_791] or 0) + 1
			task.spawn(function()
				-- upvalues: (ref) p_u_17, (copy) p_u_791, (ref) v_u_787
				local v792, v793 = p_u_17.Remotes.Invoke("ProfileAction", "AckReveal", p_u_791)
				if v792 and v793 == true then
					v_u_787[p_u_791] = true
				end
			end)
		end
	end
	function v_u_29._Seen(p795) -- name: _Seen
		-- upvalues: (copy) v_u_786, (copy) v_u_794
		v_u_786[p795] = true
		v_u_794(p795)
	end
	local function v_u_797(p796) -- name: canPlayLobby
		-- upvalues: (ref) v_u_112, (copy) v_u_20, (copy) v_u_28, (copy) p_u_17, (ref) v_u_790
		if v_u_112 or v_u_20.GetPlayerState() ~= "Lobby" or (v_u_28:GetAttribute("ReplayPlaying") == true or (p_u_17.IsHudHiddenFor("Intro") or p_u_17.IsHudHiddenFor("Celebrate"))) then
			return false
		end
		if p_u_17.RankUp and p_u_17.RankUp.IsPlaying() then
			return false
		end
		if p_u_17.IsHudHiddenFor("MatchEnd") then
			return false
		end
		if not p796 then
			if p_u_17.MenuManager.IsOpen() or (os.clock() - v_u_790 < 1.5 or not v_u_28.Character) then
				return false
			end
			if v_u_20.Get("CombatMode") == true then
				return false
			end
		end
		return true
	end
	local function v_u_804() -- name: pump
		-- upvalues: (ref) v_u_112, (copy) v_u_789, (copy) v_u_20, (copy) v_u_28, (copy) p_u_17, (copy) v_u_29, (copy) v_u_797, (copy) v_u_786, (copy) v_u_787, (copy) v_u_794
		if v_u_112 then
			return
		else
			if #v_u_789 > 0 then
				local v798
				if v_u_112 or v_u_20.GetPlayerState() ~= "Lobby" or (v_u_28:GetAttribute("ReplayPlaying") == true or (p_u_17.IsHudHiddenFor("Intro") or p_u_17.IsHudHiddenFor("Celebrate")) or p_u_17.RankUp and p_u_17.RankUp.IsPlaying()) then
					v798 = false
				else
					v798 = not p_u_17.IsHudHiddenFor("MatchEnd")
				end
				if v798 then
					local v799 = table.remove(v_u_789, 1)
					v_u_29.Play(v799, {
						["source"] = "robux"
					})
					return
				end
			end
			if v_u_797(false) then
				local v800 = v_u_20.Profile
				if v800 then
					v800 = v_u_20.Profile.reveals
				end
				if type(v800) == "table" then
					for _, v801 in v800 do
						local v802
						if type(v801) == "table" and v801.id ~= nil then
							local v803 = v801.id
							v802 = tostring(v803) or nil
						else
							v802 = nil
						end
						if v802 and not v_u_786[v802] then
							v_u_29.Play(v801, {
								["source"] = "lobby"
							})
							return
						end
						if not v802 or (not v_u_786[v802] or v_u_787[v802]) then
							continue
						end
						v_u_794(v802)
					end
				end
			else
				return
			end
		end
	end
	function v_u_29._Pump()
		-- upvalues: (copy) v_u_804
		task.delay(0.6, v_u_804)
	end
	function v_u_29.Queue(p805) -- name: Queue
		-- upvalues: (copy) v_u_789, (copy) v_u_804
		if type(p805) == "table" then
			local v806 = v_u_789
			table.insert(v806, p805)
			v_u_804()
		end
	end
	v_u_20.PlayerStateChanged:Connect(function(p807)
		-- upvalues: (ref) v_u_790, (copy) v_u_804
		v_u_790 = p807 ~= "Lobby" and (1 / 0) or os.clock()
		if p807 == "Lobby" then
			task.delay(1.6, v_u_804)
		end
	end)
	v_u_20.ProfileChanged:Connect(function()
		-- upvalues: (copy) v_u_804
		task.defer(v_u_804)
	end)
	p_u_17.MenuManager.Changed:Connect(function()
		-- upvalues: (copy) v_u_804
		task.defer(v_u_804)
	end)
	task.spawn(function()
		-- upvalues: (copy) v_u_804
		while true do
			task.wait(1)
			v_u_804()
		end
	end)
	local v808 = p_u_17.Economy
	if v808 and v808.Event then
		v808.Event:Connect(function(p809, p810)
			-- upvalues: (copy) v_u_29
			if p809 == "Drop" and type(p810) == "table" then
				local v811 = p810.reveals
				if type(v811) == "table" then
					for _, v812 in p810.reveals do
						v_u_29.Queue(v812)
					end
				else
					v_u_29.Queue(p810)
				end
			else
				return
			end
		end)
	end
	local v_u_813 = {
		["drop"] = {
			["kind"] = "drop",
			["stacks"] = nil,
			["stacks"] = {
				{
					["item"] = "crossbow",
					["shards"] = 6,
					["before"] = 4,
					["levelBefore"] = 0
				},
				{
					["item"] = "bronze_sword",
					["shards"] = 4,
					["before"] = 6,
					["levelBefore"] = 1
				}
			}
		},
		["victory"] = {
			["kind"] = "victory",
			["stacks"] = nil,
			["stacks"] = {
				{
					["item"] = "spear",
					["shards"] = 8,
					["before"] = 3,
					["levelBefore"] = 0
				},
				{
					["item"] = "short_bow",
					["shards"] = 7,
					["before"] = 1,
					["levelBefore"] = 2
				},
				{
					["item"] = "throwing_knives",
					["shards"] = 5,
					["before"] = 1,
					["levelBefore"] = 1
				}
			}
		},
		["golden"] = {
			["kind"] = "golden",
			["stacks"] = nil,
			["stacks"] = {
				{
					["item"] = "longbow",
					["shards"] = 18,
					["before"] = 26,
					["levelBefore"] = 0
				},
				{
					["item"] = "battle_axe",
					["shards"] = 16,
					["before"] = 2,
					["levelBefore"] = 0
				},
				{
					["item"] = "fire_bomb",
					["shards"] = 14,
					["before"] = 0,
					["levelBefore"] = 0
				},
				{
					["item"] = "bandage",
					["shards"] = 12,
					["before"] = 3,
					["levelBefore"] = 1
				}
			}
		},
		["newitem"] = {
			["kind"] = "victory",
			["stacks"] = nil,
			["stacks"] = {
				{
					["item"] = "crossbow",
					["shards"] = 9,
					["before"] = 14,
					["levelBefore"] = 0
				},
				{
					["item"] = "war_club",
					["shards"] = 6,
					["before"] = 2,
					["levelBefore"] = 1
				},
				{
					["item"] = "sling",
					["shards"] = 5,
					["before"] = 12,
					["levelBefore"] = 2
				}
			}
		}
	}
	function v_u_29.Mock(p814)
		-- upvalues: (copy) v_u_813
		local v815 = v_u_813[p814 or "victory"] or v_u_813.victory
		local v816 = table.clone(v815)
		local v817 = tostring(p814 or "victory")
		local v818 = os.clock() * 1000
		local v819 = math.floor(v818)
		v816.id = "mock-" .. v817 .. "-" .. tostring(v819)
		v816.source = "match"
		v816.stacks = table.clone(v815.stacks)
		for v820, v821 in v816.stacks do
			local v822 = table.clone(v821)
			v822.after = v822.before + v822.shards
			v816.stacks[v820] = v822
		end
		return v816
	end
	function p_u_17.Debug.reveal(p823, p824, p825)
		-- upvalues: (copy) v_u_29
		if type(p823) ~= "table" then
			p823 = v_u_29.Mock(type(p823) ~= "string" and "victory" or p823)
		end
		local v826 = type(p825) ~= "table" and {} or table.clone(p825)
		v826.pace = tonumber(p824) or 1
		v826.source = v826.source or "lobby"
		return v_u_29.Play(p823, v826)
	end
	function p_u_17.Debug.revealStop()
		-- upvalues: (copy) v_u_29
		v_u_29.Stop(true)
		return true
	end
	function p_u_17.Debug.revealTap()
		-- upvalues: (copy) v_u_686, (copy) v_u_29
		v_u_686()
		return v_u_29.State()
	end
	function p_u_17.Debug.revealSkip()
		-- upvalues: (copy) v_u_29
		v_u_29.Skip()
		return v_u_29.State()
	end
	function p_u_17.Debug.revealState()
		-- upvalues: (copy) v_u_29, (copy) v_u_789, (copy) v_u_786
		local v827 = v_u_29.State()
		v827.queue = #v_u_789
		local v828 = {}
		for v829 in v_u_786 do
			table.insert(v828, v829)
		end
		v827.seen = v828
		return v827
	end
	function p_u_17.Debug.revealSummary(p830)
		-- upvalues: (copy) v_u_29
		if type(p830) ~= "table" then
			p830 = v_u_29.Mock(type(p830) ~= "string" and "victory" or p830)
		end
		return v_u_29.ShowSummary(p830, {
			["source"] = "lobby"
		})
	end
end
return v9