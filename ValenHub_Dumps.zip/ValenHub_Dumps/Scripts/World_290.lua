local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("TweenService")
local v4 = {}
local v_u_5 = v2.LocalPlayer
local v_u_6 = {}
local function v_u_11(p7) -- name: isAlly
	-- upvalues: (copy) v_u_5
	local v8 = v_u_5.Character
	if p7:GetAttribute("OwnerUserId") == v_u_5.UserId then
		return true
	end
	if not v8 then
		return false
	end
	local v9 = v8:GetAttribute("MatchId")
	if type(v9) ~= "string" or v9 == "" then
		return false
	end
	local v10
	if p7:GetAttribute("MatchId") == v9 then
		v10 = p7:GetAttribute("Team") == v8:GetAttribute("Team")
	else
		v10 = false
	end
	return v10
end
local function v_u_21(p12) -- name: close
	-- upvalues: (copy) v_u_3
	if not p12.closed then
		p12.closed = true
		p12.model:GetPivot()
		for v13, v14 in { "JawA", "JawB" } do
			local v_u_15 = p12.model:FindFirstChild(v14)
			if not (v_u_15 and v_u_15:IsA("Model")) then
				continue
			end
			local v16 = v_u_15:GetPivot()
			local v17 = v13 == 1 and 1 or -1
			local v18 = v16 * CFrame.Angles(v17 * 1.4311699866353502, 0, 0)
			local v_u_19 = Instance.new("CFrameValue")
			v_u_19.Value = v16
			v_u_19.Changed:Connect(function(p20)
				-- upvalues: (copy) v_u_15
				if v_u_15.Parent then
					v_u_15:PivotTo(p20)
				end
			end)
			v_u_3:Create(v_u_19, TweenInfo.new(0.07, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				["Value"] = v18
			}):Play()
			task.delay(0.2, function()
				-- upvalues: (copy) v_u_19
				v_u_19:Destroy()
			end)
		end
	end
end
local function v_u_27(p_u_22) -- name: register
	-- upvalues: (copy) v_u_6, (copy) v_u_11, (copy) v_u_5, (copy) v_u_21
	if p_u_22:IsA("Model") and not v_u_6[p_u_22] then
		local v23 = {}
		for _, v24 in p_u_22:GetDescendants() do
			if not v24:IsA("BasePart") then
				continue
			end
			table.insert(v23, v24)
		end
		local v_u_25 = {
			["model"] = nil,
			["parts"] = nil,
			["ring"] = nil,
			["closed"] = false,
			["lastAlpha"] = -1,
			["model"] = p_u_22,
			["parts"] = v23
		}
		v_u_6[p_u_22] = v_u_25
		if v_u_11(p_u_22) then
			local v26 = Instance.new("Part")
			v26.Name = "AllyRing"
			v26.Shape = Enum.PartType.Cylinder
			v26.Size = Vector3.new(0.05, 6.4, 6.4)
			v26.Material = Enum.Material.SmoothPlastic
			v26.Color = Color3.fromRGB(90, 170, 240)
			v26.Transparency = 0.8
			v26.Anchored = true
			v26.CanCollide = false
			v26.CanQuery = false
			v26.CanTouch = false
			v26.CastShadow = false
			v26.CFrame = CFrame.new(p_u_22:GetPivot().Position + Vector3.new(0, 0.05, 0)) * CFrame.Angles(0, 0, 1.5707963267948966)
			v26.Parent = p_u_22
			v_u_25.ring = v26
		end
		if p_u_22:GetAttribute("OwnerUserId") == v_u_5.UserId then
			p_u_22:GetAttributeChangedSignal("Armed"):Connect(function()
				-- upvalues: (copy) p_u_22
				if p_u_22:GetAttribute("Armed") == true and p_u_22:GetAttribute("Sprung") ~= true then
					require(script.Parent.Util).Sound("Trap_Armed", p_u_22:GetPivot().Position)
				end
			end)
		end
		p_u_22:GetAttributeChangedSignal("Sprung"):Connect(function()
			-- upvalues: (copy) p_u_22, (ref) v_u_21, (copy) v_u_25
			if p_u_22:GetAttribute("Sprung") == true then
				v_u_21(v_u_25)
			end
		end)
		if p_u_22:GetAttribute("Sprung") == true then
			v_u_21(v_u_25)
		end
	end
end
local function v_u_29(p28) -- name: unregister
	-- upvalues: (copy) v_u_6
	if p28:IsA("Model") then
		v_u_6[p28] = nil
	end
end
local function v_u_41() -- name: update
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_11
	local v30 = workspace.CurrentCamera
	local v31 = v_u_5.Character
	if v31 then
		v31 = v31:FindFirstChild("HumanoidRootPart")
	end
	local v32
	if v31 then
		v32 = v31.Position
	else
		v32 = v30.CFrame.Position
	end
	for v33, v34 in v_u_6 do
		if v33.Parent then
			local v35
			if v_u_11(v33) or v33:GetAttribute("Sprung") == true then
				v35 = 0
			else
				local v36 = v33:GetAttribute("HiddenBeyond")
				local v37 = type(v36) ~= "number" and 25 or v36
				local v38 = ((v33:GetPivot().Position - v32).Magnitude - v37 * 0.7) / (v37 * 0.3)
				v35 = math.clamp(v38, 0, 1)
			end
			local v39 = v35 - v34.lastAlpha
			if math.abs(v39) <= 0.02 then
				continue
			end
			v34.lastAlpha = v35
			for _, v40 in v34.parts do
				v40.LocalTransparencyModifier = v35
			end
		else
			v_u_6[v33] = nil
		end
	end
end
function v4.Init() -- name: Init
	-- upvalues: (copy) v_u_1, (copy) v_u_27, (copy) v_u_29, (copy) v_u_6, (copy) v_u_41
	v_u_1:GetInstanceAddedSignal("BearTrap"):Connect(v_u_27)
	v_u_1:GetInstanceRemovedSignal("BearTrap"):Connect(v_u_29)
	for _, v42 in v_u_1:GetTagged("BearTrap") do
		v_u_27(v42)
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_6, (ref) v_u_41
		while true do
			repeat
				task.wait(0.1)
			until next(v_u_6)
			local v43 = v_u_41
			local v44, v45 = pcall(v43)
			if v44 then
				continue
			end
			warn("[Combat] trap visuals:", v45)
		end
	end)
end
return v4