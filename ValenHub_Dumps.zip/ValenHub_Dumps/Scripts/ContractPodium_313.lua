local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
return {
	["Init"] = function(p5) -- name: Init
		-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_1, (copy) v_u_3
		local v_u_6 = p5.UI
		local v_u_7 = p5.Theme
		local v_u_8 = p5.State
		local v_u_9 = p5.WeaponInfo
		local v_u_10 = p5.Economy
		local v_u_11 = v_u_7.Colors
		local v_u_12 = v_u_7.Fonts
		local v_u_13 = Instance.new("Folder")
		v_u_13.Name = "TR_ContractDisplay"
		v_u_13.Parent = v_u_4
		local function v_u_17(p14) -- name: modelSource
			-- upvalues: (ref) v_u_2
			local v15 = v_u_2:FindFirstChild("Assets")
			local v16
			if v15 then
				v16 = v15:FindFirstChild("Weapons")
			else
				v16 = v15
			end
			if v16 then
				v16 = v16:FindFirstChild(p14)
			end
			if v16 then
				v15 = v16
			else
				if v15 then
					v15 = v15:FindFirstChild("Armor")
				end
				if v15 then
					v15 = v15:FindFirstChild(p14)
				end
			end
			return v15
		end
		local function v_u_31(p18) -- name: cloneVisual
			local v19 = p18:GetAttribute("Armor") == true
			local v_u_20 = Instance.new("Model")
			v_u_20.Name = "ContractItem"
			local v_u_21 = false
			local function v26(p_u_22) -- name: copy
				-- upvalues: (copy) v_u_20, (ref) v_u_21
				local v23, v24 = pcall(function()
					-- upvalues: (copy) p_u_22
					return p_u_22:Clone()
				end)
				if v23 and v24 then
					for _, v25 in v24:GetDescendants() do
						if v25:IsA("DataModelMesh") or (v25:IsA("Decal") or (v25:IsA("Texture") or v25:IsA("SurfaceAppearance"))) then
							continue
						end
						v25:Destroy()
					end
					v24.Anchored = true
					v24.CanCollide = false
					v24.CanQuery = false
					v24.CanTouch = false
					v24.CastShadow = false
					v24.Massless = true
					if v24.Material == Enum.Material.Neon then
						v24.Material = Enum.Material.SmoothPlastic
					end
					v24.Parent = v_u_20
					v_u_21 = true
				end
			end
			if p18:IsA("BasePart") then
				v26(p18)
			end
			local v27 = v_u_21
			for _, v28 in p18:GetDescendants() do
				if not v28:IsA("BasePart") or (v28.Transparency >= 1 or v19 and string.find(string.lower(v28.Name), "boots", 1, true)) then
					continue
				end
				v26(v28)
			end
			if v27 then
				if v19 then
					for _, v29 in v_u_20:GetChildren() do
						if not (v29:IsA("BasePart") and string.find(string.lower(v29.Name), "shoulder", 1, true)) then
							continue
						end
						local v30 = v29.Position.X > 0 and -0.5 or 0.5
						v29.CFrame = v29.CFrame + Vector3.new(v30, -0.12, 0)
					end
				end
				return v_u_20, v19
			else
				v_u_20:Destroy()
				return nil, v19
			end
		end
		local function v_u_50(p32, p33) -- name: buildItem
			-- upvalues: (copy) v_u_17, (copy) v_u_31
			local v34 = v_u_17(p32)
			if not v34 then
				return nil, CFrame.identity, 1
			end
			local v_u_35, v36 = v_u_31(v34)
			if not v_u_35 then
				return nil, CFrame.identity, 1
			end
			local v37, v38 = v_u_35:GetBoundingBox()
			v_u_35.WorldPivot = v37
			local v39 = v38.X
			local v40 = v38.Y
			local v41 = v38.Z
			local v42 = math.max(v39, v40, v41)
			local v43 = { v38.X, v38.Y, v38.Z }
			table.sort(v43)
			local v44 = not v36
			if v44 then
				local v45 = v43[3]
				local v46 = v43[2]
				v44 = v45 / math.max(v46, 0.01) < 1.8
			end
			local v_u_47 = (v36 and 2.8 or (v44 and 2.2 or 3.4)) * p33 / math.max(v42, 0.1)
			pcall(function()
				-- upvalues: (copy) v_u_35, (copy) v_u_47
				v_u_35:ScaleTo(v_u_47)
			end)
			local v48 = CFrame.identity
			local v49
			if v36 then
				v49 = CFrame.Angles(0, 3.141592653589793, 0)
			else
				if v38.X >= v38.Y and v38.X >= v38.Z then
					v48 = CFrame.Angles(0, 0, 1.5707963267948966)
				elseif v38.Z >= v38.X and v38.Z >= v38.Y then
					v48 = CFrame.Angles(1.5707963267948966, 0, 0)
				end
				v49 = CFrame.Angles(0, 0, 0.3141592653589793) * v48
			end
			return v_u_35, v49, v_u_47
		end
		local v_u_51 = {}
		local v_u_52 = {}
		local v_u_53 = 1
		local function v_u_59() -- name: rebuildCycle
			-- upvalues: (ref) v_u_52, (ref) v_u_53, (copy) v_u_10
			local v54 = v_u_52[v_u_53]
			local v55 = {}
			for _, v56 in v_u_10.Unlocks.AllIds() do
				if not v_u_10.IsLocked(v56) then
					continue
				end
				table.insert(v55, v56)
			end
			if #v55 == 0 then
				v55 = table.clone(v_u_10.Unlocks.AllIds())
			end
			v_u_52 = v55
			v_u_53 = 1
			for v57, v58 in v55 do
				if v58 ~= v54 then
					continue
				end
				v_u_53 = v57
				return
			end
		end
		local function v_u_77(p60) -- name: build
			-- upvalues: (copy) v_u_13, (copy) v_u_6, (copy) v_u_11, (copy) v_u_12, (copy) v_u_7
			local v61 = Instance.new("Folder")
			v61.Name = p60:GetFullName()
			v61.Parent = v_u_13
			local v62 = Instance.new("Part")
			v62.Name = "Root"
			v62.Size = Vector3.new(0.2, 0.2, 0.2)
			v62.Anchored = true
			v62.CanCollide = false
			v62.CanQuery = false
			v62.CanTouch = false
			v62.CastShadow = false
			v62.Transparency = 1
			v62.Parent = v61
			local v63 = Instance.new("ParticleEmitter")
			v63.Texture = "rbxasset://textures/particles/sparkles_main.dds"
			v63.Rate = 3
			v63.Lifetime = NumberRange.new(2, 3.2)
			v63.Speed = NumberRange.new(0.2, 0.5)
			v63.SpreadAngle = Vector2.new(180, 180)
			v63.Acceleration = Vector3.new(0, 0.35, 0)
			v63.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.18), NumberSequenceKeypoint.new(1, 0) })
			v63.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.35), NumberSequenceKeypoint.new(1, 1) })
			v63.LightEmission = 0.3
			v63.LightInfluence = 0
			v63.Shape = Enum.ParticleEmitterShape.Sphere
			v63.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v63.Parent = v62
			v62.Size = Vector3.new(3, 3, 3)
			local v64 = Instance.new("BillboardGui")
			v64.Name = "Halo"
			v64.Size = UDim2.fromScale(5.5, 5.5)
			v64.StudsOffset = Vector3.new(0, 0, -2)
			v64.LightInfluence = 0
			v64.Brightness = 1
			v64.MaxDistance = 140
			v64.ResetOnSpawn = false
			v64.Adornee = v62
			v64.Parent = v61
			local v65 = Instance.new("ImageLabel")
			v65.BackgroundTransparency = 1
			v65.Size = UDim2.fromScale(1, 1)
			v65.Image = v_u_6.Assets.Icons.Glow
			v65.ImageTransparency = 0.5
			v65.Parent = v64
			local v66 = Instance.new("Part")
			v66.Name = "Ring"
			v66.Size = Vector3.new(3.4, 0.05, 3.4)
			v66.Anchored = true
			v66.CanCollide = false
			v66.CanQuery = false
			v66.CanTouch = false
			v66.CastShadow = false
			v66.Transparency = 1
			v66.Parent = v61
			local v67 = Instance.new("SurfaceGui")
			v67.Face = Enum.NormalId.Top
			v67.LightInfluence = 0
			v67.Brightness = 1
			v67.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
			v67.PixelsPerStud = 60
			v67.MaxDistance = 140
			v67.Adornee = v66
			v67.Parent = v66
			local v68 = Instance.new("ImageLabel")
			v68.BackgroundTransparency = 1
			v68.Size = UDim2.fromScale(1, 1)
			v68.Image = v_u_6.Assets.Fx.Ring
			v68.ImageTransparency = 0.55
			v68.Parent = v67
			local v69 = v67:Clone()
			v69.Face = Enum.NormalId.Bottom
			v69.Parent = v66
			local v70 = Instance.new("BillboardGui")
			v70.Name = "Info"
			v70.Size = UDim2.new(5.2, 0, 1.45, 0)
			v70.StudsOffset = Vector3.new(4.8, -0.6, 0)
			v70.LightInfluence = 0
			v70.MaxDistance = 55
			v70.ResetOnSpawn = false
			v70.Adornee = v62
			v70.Parent = v61
			local v71 = Instance.new("Frame")
			v71.Size = UDim2.fromScale(1, 1)
			v71.BackgroundColor3 = v_u_11.Void
			v71.BackgroundTransparency = 0.35
			v71.BorderSizePixel = 0
			v71.Parent = v70
			v_u_6.Corner(UDim.new(0.22, 0)).Parent = v71
			local v72 = v_u_6.new("TextLabel", {
				["Name"] = "ItemName",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextScaled"] = true,
				["TextColor3"] = nil,
				["Parent"] = nil,
				["Position"] = UDim2.fromScale(0.05, 0.06),
				["Size"] = UDim2.fromScale(0.9, 0.36),
				["FontFace"] = v_u_12.Heavy,
				["TextColor3"] = v_u_11.Text,
				["Parent"] = v71
			})
			v_u_6.new("UITextSizeConstraint", {
				["MaxTextSize"] = 30,
				["Parent"] = nil,
				["Parent"] = v72
			})
			local v73 = v_u_6.new("TextLabel", {
				["Name"] = "Line",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["RichText"] = true,
				["FontFace"] = nil,
				["TextScaled"] = true,
				["TextColor3"] = nil,
				["Parent"] = nil,
				["Position"] = UDim2.fromScale(0.05, 0.42),
				["Size"] = UDim2.fromScale(0.9, 0.2),
				["FontFace"] = v_u_12.Heavy,
				["TextColor3"] = v_u_11.TextDim,
				["Parent"] = v71
			})
			v_u_6.new("UITextSizeConstraint", {
				["MaxTextSize"] = 16,
				["Parent"] = nil,
				["Parent"] = v73
			})
			local v74 = Instance.new("Frame")
			v74.Name = "Bar"
			v74.Position = UDim2.fromScale(0.07, 0.7)
			v74.Size = UDim2.fromScale(0.46, 0.13)
			v74.BackgroundColor3 = v_u_11.Inset
			v74.BackgroundTransparency = 0.1
			v74.BorderSizePixel = 0
			v74.ClipsDescendants = true
			v74.Parent = v71
			v_u_6.Corner(v_u_7.Radius.Pill).Parent = v74
			local v75 = Instance.new("Frame")
			v75.Size = UDim2.fromScale(0, 1)
			v75.BackgroundColor3 = v_u_11.Accent
			v75.BorderSizePixel = 0
			v75.Parent = v74
			v_u_6.Corner(v_u_7.Radius.Pill).Parent = v75
			local v76 = v_u_6.new("TextLabel", {
				["Name"] = "Points",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextScaled"] = true,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["Parent"] = nil,
				["Position"] = UDim2.fromScale(0.56, 0.64),
				["Size"] = UDim2.fromScale(0.39, 0.25),
				["FontFace"] = v_u_12.Bold,
				["TextColor3"] = v_u_11.TextDim,
				["TextXAlignment"] = Enum.TextXAlignment.Right,
				["Parent"] = v71
			})
			v_u_6.new("UITextSizeConstraint", {
				["MaxTextSize"] = 16,
				["Parent"] = nil,
				["Parent"] = v76
			})
			return {
				["podium"] = nil,
				["anchor"] = nil,
				["root"] = nil,
				["halo"] = nil,
				["haloImg"] = nil,
				["ring"] = nil,
				["ringImg"] = nil,
				["motes"] = nil,
				["info"] = nil,
				["name"] = nil,
				["line"] = nil,
				["fill"] = nil,
				["pts"] = nil,
				["barBg"] = nil,
				["item"] = nil,
				["itemId"] = nil,
				["orient"] = nil,
				["scale"] = 1,
				["mul"] = 1,
				["popAt"] = (-1 / 0),
				["conns"] = nil,
				["podium"] = p60,
				["root"] = v62,
				["halo"] = v64,
				["haloImg"] = v65,
				["ring"] = v66,
				["ringImg"] = v68,
				["motes"] = v63,
				["info"] = v70,
				["name"] = v72,
				["line"] = v73,
				["fill"] = v75,
				["pts"] = v76,
				["barBg"] = v74,
				["orient"] = CFrame.identity,
				["conns"] = {}
			}
		end
		local function v_u_98(p78, p79) -- name: paint
			-- upvalues: (ref) v_u_52, (copy) v_u_10, (copy) v_u_59, (ref) v_u_53, (copy) v_u_11, (copy) v_u_9, (copy) v_u_50
			if #v_u_52 == 0 and v_u_10.HasData() then
				v_u_59()
			end
			local v80
			if v_u_10.HasData() then
				v80 = v_u_52[v_u_53] or false
			else
				v80 = false
			end
			local v81 = v_u_11.Accent
			if v80 then
				local v82, v83, v84 = v_u_10.Progress(v80)
				local v85 = v_u_10.Level(v80)
				p78.name.Text = string.upper(v_u_9.Name(v80))
				if v84 == "unlock" then
					local v86 = v83 - v82
					local v87 = math.max(0, v86)
					p78.line.Text = v82 <= 0 and "LOCKED  \194\183  FIND ITS SHARDS IN DROPS" or string.format("LOCKED  \194\183  FIND %d MORE SHARDS", v87)
				elseif v_u_10.CanUpgrade(v80) then
					p78.line.Text = string.format("UPGRADE READY  \194\183  LV %d \226\134\146 %d", v85, v85 + 1)
					v81 = v_u_11.Success
				elseif v84 == "max" then
					p78.line.Text = "MAX LEVEL"
				else
					local v88 = v_u_10.Shards.BonusText(v80, v85)
					local v89 = p78.line
					local v90
					if v88 == "" then
						v90 = string.format("LV %d", v85)
					else
						v90 = string.format("LV %d  \194\183  %s", v85, string.upper(v88))
					end
					v89.Text = v90
				end
				local v91 = p78.fill
				local v92 = UDim2.fromScale
				local v93
				if v84 == "max" then
					v93 = 1
				else
					local v94 = v82 / math.max(v83, 1)
					v93 = math.clamp(v94, 0, 1)
				end
				v91.Size = v92(v93, 1)
				p78.fill.BackgroundColor3 = v81
				p78.pts.Text = v84 == "max" and "MAX" or string.format("%d / %d SHARDS", v82, v83)
				p78.barBg.Visible = true
				p78.pts.Visible = true
			else
				p78.name.Text = v_u_10.HasData() and "ALL MAXED" or ""
				p78.line.Text = v_u_10.HasData() and "EVERY ITEM AT MAX LEVEL" or ""
				p78.barBg.Visible = false
				p78.pts.Visible = false
			end
			p78.haloImg.ImageColor3 = v81
			p78.ringImg.ImageColor3 = v81
			p78.motes.Color = ColorSequence.new(v81:Lerp(Color3.new(1, 1, 1), 0.35))
			if p78.itemId ~= v80 then
				p78.itemId = v80
				if p78.item then
					p78.item:Destroy()
					p78.item = nil
				end
				if v80 then
					local v95, v96, v97 = v_u_50(v80, p78.mul)
					if v95 then
						p78.item = v95
						p78.orient = v96
						p78.scale = v97
						v95.Parent = p78.root.Parent
					end
				end
				if p79 then
					p78.popAt = os.clock()
				end
			end
		end
		local function v_u_112(p99) -- name: applyAnchor
			-- upvalues: (copy) v_u_98
			local v100 = p99.anchor
			local v101
			if v100 then
				v101 = v100:GetAttribute("ItemScale")
			else
				v101 = v100
			end
			local v102 = tonumber(v101) or 1
			local v103 = math.clamp(v102, 0.5, 4)
			local v104
			if v100 then
				v104 = v100:GetAttribute("CardScale")
			else
				v104 = v100
			end
			local v105 = tonumber(v104) or 1
			local v106 = math.clamp(v105, 0.5, 3)
			if v100 then
				v100 = v100:GetAttribute("CardOffset")
			end
			p99.halo.Size = UDim2.fromScale(v103 * 5.5, v103 * 5.5)
			local v107 = p99.halo
			local v108 = v103 * -2
			v107.StudsOffset = Vector3.new(0, 0, v108)
			local v109 = p99.ring
			local v110 = v103 * 3.4
			local v111 = v103 * 3.4
			v109.Size = Vector3.new(v110, 0.05, v111)
			p99.root.Size = Vector3.new(3, 3, 3) * v103
			p99.info.StudsOffset = typeof(v100) ~= "Vector3" and Vector3.new(4.8, -0.6, 0) or v100
			p99.info.Size = UDim2.new(v106 * 5.2, 0, v106 * 1.45, 0)
			if v103 ~= p99.mul then
				p99.mul = v103
				if p99.item then
					p99.itemId = nil
					v_u_98(p99, false)
				end
			end
		end
		local function v126(p_u_113) -- name: attach
			-- upvalues: (copy) v_u_51, (ref) v_u_4, (copy) v_u_77, (copy) v_u_112, (copy) v_u_98
			if not v_u_51[p_u_113] and p_u_113:IsDescendantOf(v_u_4) then
				local v_u_114 = v_u_77(p_u_113)
				v_u_51[p_u_113] = v_u_114
				local v115 = p_u_113:FindFirstChild("ItemAnchor", true)
				if not (v115 and v115:IsA("Attachment")) then
					v115 = nil
				end
				v_u_114.anchor = v115
				v_u_112(v_u_114)
				for _, v116 in p_u_113:GetDescendants() do
					if not v116:IsA("ProximityPrompt") or v116.Name ~= "ContractPrompt" then
						continue
					end
					v116.ActionText = "Collection"
					v116.ObjectText = ""
				end
				local v117 = v_u_114.conns
				local v118 = p_u_113.DescendantAdded
				local function v120(p119)
					-- upvalues: (copy) v_u_114, (ref) v_u_112
					if p119:IsA("ProximityPrompt") and p119.Name == "ContractPrompt" then
						p119.ActionText = "Collection"
						p119.ObjectText = ""
					end
					if p119.Name == "ItemAnchor" and p119:IsA("Attachment") then
						v_u_114.anchor = p119
						v_u_112(v_u_114)
					end
				end
				table.insert(v117, v118:Connect(v120))
				local v121 = v_u_114.conns
				local v122 = p_u_113.AncestryChanged
				local function v125()
					-- upvalues: (copy) p_u_113, (ref) v_u_4, (ref) v_u_51
					local v123 = not p_u_113:IsDescendantOf(v_u_4) and v_u_51[p_u_113]
					if v123 then
						for _, v124 in v123.conns do
							v124:Disconnect()
						end
						v123.root.Parent:Destroy()
						v_u_51[p_u_113] = nil
					end
				end
				table.insert(v121, v122:Connect(v125))
				v_u_98(v_u_114, false)
			end
		end
		local v_u_127 = v_u_52
		local v_u_128 = v_u_53
		local function v132(p129) -- name: detach
			-- upvalues: (copy) v_u_51
			local v130 = v_u_51[p129]
			if v130 then
				for _, v131 in v130.conns do
					v131:Disconnect()
				end
				v130.root.Parent:Destroy()
				v_u_51[p129] = nil
			end
		end
		for _, v133 in v_u_1:GetTagged("ContractPodium") do
			task.spawn(v126, v133)
		end
		v_u_1:GetInstanceAddedSignal("ContractPodium"):Connect(v126)
		v_u_1:GetInstanceRemovedSignal("ContractPodium"):Connect(v132)
		v_u_10.Changed:Connect(function()
			-- upvalues: (copy) v_u_59, (copy) v_u_51, (copy) v_u_98
			v_u_59()
			for _, v134 in v_u_51 do
				v_u_98(v134, true)
			end
		end)
		task.spawn(function()
			-- upvalues: (copy) v_u_51, (ref) v_u_127, (copy) v_u_8, (ref) v_u_128, (copy) v_u_98
			while true do
				repeat
					task.wait(7)
				until next(v_u_51) ~= nil and (#v_u_127 > 1 and not v_u_8.InMatch())
				v_u_128 = v_u_128 % #v_u_127 + 1
				for _, v135 in v_u_51 do
					v_u_98(v135, true)
				end
			end
		end)
		local v_u_136 = CFrame.new(0, -5000, 0)
		v_u_3.RenderStepped:Connect(function()
			-- upvalues: (copy) v_u_51, (copy) v_u_8, (copy) v_u_10, (ref) v_u_4, (copy) v_u_136
			if next(v_u_51) ~= nil then
				local v137 = not v_u_8.InMatch()
				if v137 then
					v137 = v_u_10.HasData()
				end
				local v138 = v_u_4.CurrentCamera
				local v139 = v138 and v138.CFrame.Position or Vector3.new(0, 0, 0)
				local v140 = os.clock()
				for _, v_u_141 in v_u_51 do
					local v142 = v_u_141.anchor
					local v143
					if v137 then
						if v142 == nil then
							v143 = false
						else
							v143 = v142.Parent ~= nil
						end
					else
						v143 = v137
					end
					local v144
					if v143 then
						v144 = v142.WorldCFrame
					else
						v144 = v_u_136
					end
					if v143 and (v144.Position - v139).Magnitude > 160 then
						v143 = false
					end
					v_u_141.halo.Enabled = v143
					v_u_141.info.Enabled = v143
					v_u_141.motes.Enabled = v143
					if v143 then
						local v145 = CFrame.new(v144.Position) * CFrame.Angles(0, select(2, v144:ToEulerAnglesYXZ()), 0)
						local v146 = v140 * 1.6
						local v147 = math.sin(v146) * 0.18 * v_u_141.mul
						local v148 = v145 * CFrame.new(0, v147, 0)
						v_u_141.root.CFrame = v148
						v_u_141.ring.CFrame = v148 * CFrame.Angles(0.20943951023931956, v140 * 0.6, 0) * CFrame.new(0, v_u_141.mul * -0.35, 0)
						local v149 = v140 - v_u_141.popAt
						local v_u_150 = 1
						if v149 < 0.5 then
							local v151 = v149 / 0.5
							local v152 = 1 + 2.70158 * (v151 - 1) ^ 3 + 1.70158 * (v151 - 1) ^ 2
							v_u_150 = math.max(0.05, v152)
							v_u_141.haloImg.ImageTransparency = 0.5 - 0.3 * (1 - v151)
						elseif v149 < 0.6 then
							v_u_141.haloImg.ImageTransparency = 0.5
						end
						local v_u_153 = v_u_141.item
						if not v_u_153 then
							continue
						end
						if v149 < 0.6 then
							pcall(function()
								-- upvalues: (copy) v_u_153, (copy) v_u_141, (ref) v_u_150
								v_u_153:ScaleTo(v_u_141.scale * v_u_150)
							end)
						end
						v_u_153:PivotTo(v148 * CFrame.Angles(0, v140 * 0.4886921905584123, 0) * v_u_141.orient)
					else
						if v_u_141.root.CFrame == v_u_136 then
							continue
						end
						v_u_141.root.CFrame = v_u_136
						v_u_141.ring.CFrame = v_u_136
						if not v_u_141.item then
							continue
						end
						v_u_141.item:PivotTo(v_u_136)
					end
				end
			end
		end)
		function p5.Debug.podium()
			-- upvalues: (copy) v_u_51
			local v154 = {}
			for v155, v156 in v_u_51 do
				local v157 = {
					["podium"] = v155:GetFullName()
				}
				local v158
				if v156.anchor then
					v158 = v156.anchor:GetFullName() or false
				else
					v158 = false
				end
				v157.anchor = v158
				v157.item = v156.itemId or false
				v157.hasModel = v156.item ~= nil
				table.insert(v154, v157)
			end
			return v154
		end
	end
}