local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent:WaitForChild("Characters"))
local v_u_5 = require(script.Parent:WaitForChild("Perf"))
local v_u_6 = require(script.Parent:WaitForChild("AnimationIds"))
local v_u_7 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("AnimGuard"))
local v_u_8 = v1.LocalPlayer
local v_u_9 = v_u_2:IsStudio()
local v_u_10 = {}
local v11 = {}
for _, v12 in { v_u_6.R15, v_u_6.R6 } do
	for _, v13 in {
		"idle",
		"idle2",
		"walk",
		"run",
		"jump",
		"fall"
	} do
		local v14 = v12[v13]
		if type(v14) ~= "string" or v14 == "" then
			continue
		end
		v_u_10[v14] = true
	end
end
local v_u_15 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_16 = {}
local v_u_17 = RaycastParams.new()
v_u_17.FilterType = Enum.RaycastFilterType.Exclude
v_u_17.RespectCanCollide = true
local v_u_18 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_26(p_u_19, p20, p21, p22) -- name: load
	-- upvalues: (copy) v_u_18, (copy) v_u_15
	if p20 == "" then
		return nil
	end
	local v_u_23 = Instance.new("Animation")
	v_u_23.Name = p22
	v_u_23.AnimationId = p20
	local v24, v25 = pcall(function()
		-- upvalues: (copy) p_u_19, (copy) v_u_23
		return p_u_19:LoadAnimation(v_u_23)
	end)
	if not (v24 and v25) then
		return nil
	end
	v25.Priority = p21
	v25.Looped = true
	v_u_18[v25] = p21
	v_u_15[v25] = true
	return v25
end
local function v_u_36(p27, p28) -- name: build
	-- upvalues: (copy) v_u_6, (copy) v_u_26
	local v29 = p27:FindFirstChildOfClass("Humanoid")
	local v30 = p27:FindFirstChild("HumanoidRootPart")
	local v31
	if v29 then
		v31 = v29:FindFirstChildOfClass("Animator")
	else
		v31 = v29
	end
	if not (v29 and (v30 and (v30:IsA("BasePart") and v31))) then
		return nil
	end
	local v32
	if v29.RigType == Enum.HumanoidRigType.R6 then
		v32 = v_u_6.R6
	else
		v32 = v_u_6.R15
	end
	local v33 = {
		["character"] = nil,
		["humanoid"] = nil,
		["root"] = nil,
		["tracks"] = nil,
		["weights"] = nil,
		["targets"] = nil,
		["legs"] = nil,
		["upper"] = nil,
		["sliding"] = false,
		["groundedAt"] = 0,
		["jumpAt"] = -1,
		["active"] = false,
		["character"] = p27,
		["humanoid"] = v29,
		["root"] = v30,
		["tracks"] = {},
		["weights"] = {},
		["targets"] = {}
	}
	for _, v34 in {
		"idle",
		"walk",
		"run",
		"jump",
		"fall"
	} do
		local v35 = v_u_26(v31, v32[v34], Enum.AnimationPriority.Core, v34)
		if not v35 then
			continue
		end
		v33.tracks[v34] = v35
		v33.weights[v34] = 0
	end
	if p28 then
		v33.legs = v_u_26(v31, v_u_6.SlideLegs, Enum.AnimationPriority.Action2, "SlideLegs") or v_u_26(v31, v_u_6.SlideFallback, Enum.AnimationPriority.Movement, "SlideFallback")
		v33.upper = v_u_26(v31, v_u_6.SlideUpper, Enum.AnimationPriority.Movement, "SlideUpper")
	end
	return v33
end
local function v_u_41(p37) -- name: muteReplicated
	-- upvalues: (copy) v_u_15, (copy) v_u_10
	local v38 = p37.humanoid:FindFirstChildOfClass("Animator")
	if v38 then
		for _, v39 in v38:GetPlayingAnimationTracks() do
			if v_u_15[v39] then
				continue
			end
			local v40 = v39.Animation
			if not (v40 and v_u_10[v40.AnimationId]) then
				continue
			end
			v39:Stop(0)
		end
	end
end
local v_u_42 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_46(p43) -- name: stopAll
	for v44, v45 in p43.tracks do
		v45:Stop(0.2)
		p43.weights[v44] = 0
	end
	if p43.legs then
		p43.legs:Stop(0.15)
	end
	if p43.upper then
		p43.upper:Stop(0.15)
	end
	p43.sliding = false
	p43.active = false
end
local function v_u_51(p47) -- name: destroyRig
	for _, v_u_48 in p47.tracks do
		if not v_u_48 then
			continue
		end
		pcall(function()
			-- upvalues: (copy) v_u_48
			v_u_48:Stop(0)
			v_u_48:Destroy()
		end)
	end
	local v_u_49 = p47.legs
	if v_u_49 then
		pcall(function()
			-- upvalues: (copy) v_u_49
			v_u_49:Stop(0)
			v_u_49:Destroy()
		end)
	end
	local v_u_50 = p47.upper
	if v_u_50 then
		pcall(function()
			-- upvalues: (copy) v_u_50
			v_u_50:Stop(0)
			v_u_50:Destroy()
		end)
	end
	table.clear(p47.tracks)
	p47.legs = nil
	p47.upper = nil
	p47.active = false
end
local function v_u_95(p52, p53, p54) -- name: step
	-- upvalues: (copy) v_u_46, (copy) v_u_17, (copy) v_u_3, (copy) v_u_18
	local v55 = p52.humanoid
	local v56 = p52.root
	if v55.Health <= 0 then
		if p52.active then
			v_u_46(p52)
		end
	else
		p52.active = true
		local v57 = p52.targets
		for v58 in p52.tracks do
			v57[v58] = 0
		end
		local v59 = v56.AssemblyLinearVelocity
		local v60 = v59.X
		local v61 = v59.Z
		local v62 = Vector3.new(v60, 0, v61).Magnitude
		local v63 = v56:GetAttribute("SHipBase")
		local v64 = 0.5
		if type(v63) ~= "number" then
			v63 = v55.HipHeight
		end
		local v65 = v63 / 2
		local v66 = math.max(v64, v65)
		v_u_17.FilterDescendantsInstances = { p52.character }
		local v67 = v55.HipHeight + v56.Size.Y / 2 + 0.9
		local v68 = v59.Y
		local v69
		if math.abs(v68) < 12 then
			local v70 = v_u_3
			local v71 = v56.Position
			local v72 = -v67
			v69 = v70:Raycast(v71, Vector3.new(0, v72, 0), v_u_17) ~= nil
		else
			v69 = false
		end
		if v69 then
			p52.groundedAt = p54
		elseif v59.Y > 8 and p54 - p52.groundedAt < 0.25 then
			p52.jumpAt = p54
		end
		if v69 or p54 - p52.groundedAt < 0.1 then
			local v73 = (v62 - 0.6) / 2.5
			local v74 = math.clamp(v73, 0, 1)
			local v75 = (v62 / v66 - 9) / 5
			local v76 = math.clamp(v75, 0, 1)
			v57.idle = 1 - v74
			v57.walk = v74 * (1 - v76)
			v57.run = v74 * v76
			local v77 = 1
			if v62 > 1 then
				local v78 = v56.CFrame.LookVector
				v77 = (v59.X * v78.X + v59.Z * v78.Z) / v62 < -0.35 and -1 or v77
			end
			local v79 = p52.tracks.walk
			local v80 = p52.tracks.run
			if v79 then
				local v81 = v62 / (v66 * 7.5)
				v79:AdjustSpeed(v77 * math.clamp(v81, 0.4, 1.8))
			end
			if v80 then
				local v82 = v62 / (v66 * 16.5)
				v80:AdjustSpeed(v77 * math.clamp(v82, 0.55, 1.7))
			end
		elseif p52.jumpAt > 0 and (p54 - p52.jumpAt < 0.45 and v59.Y > -12) then
			v57.jump = 1
		else
			v57.fall = 1
		end
		local v83 = p53 * -14
		local v84 = 1 - math.exp(v83)
		local v85 = p52.legs
		if v85 then
			local v86 = v_u_18[v85]
			if v86 and v85.Priority ~= v86 then
				v85.Priority = v86
			end
			if not v85.Looped then
				v85.Looped = true
			end
		end
		local v87 = p52.upper
		if v87 then
			local v88 = v_u_18[v87]
			if v88 and v87.Priority ~= v88 then
				v87.Priority = v88
			end
			if not v87.Looped then
				v87.Looped = true
			end
		end
		for v89, v90 in p52.tracks do
			if v90 then
				local v91 = v_u_18[v90]
				if v91 and v90.Priority ~= v91 then
					v90.Priority = v91
				end
				if not v90.Looped then
					v90.Looped = true
				end
			end
			local v92 = p52.weights[v89] + ((v57[v89] or 0) - p52.weights[v89]) * v84
			local v93 = v92 < 0.001 and 0.0001 or v92
			p52.weights[v89] = v93
			if v90.IsPlaying then
				v90:AdjustWeight(v93, 0)
			else
				v90:Play(0, v93, v90.Speed)
			end
		end
		local v94 = v56:GetAttribute("SSlide") ~= nil
		if v94 ~= p52.sliding then
			p52.sliding = v94
			if v94 then
				if p52.legs then
					p52.legs:Play(0.08, 1, 1)
				end
				if p52.upper then
					p52.upper:Play(0.12, 1, 1)
					return
				end
			else
				if p52.legs then
					p52.legs:Stop(0.15)
				end
				if p52.upper then
					p52.upper:Stop(0.15)
				end
			end
		end
	end
end
local v_u_96 = 0
local function v_u_113(p97) -- name: update
	-- upvalues: (ref) v_u_96, (copy) v_u_3, (copy) v_u_4, (copy) v_u_9, (copy) v_u_8, (copy) v_u_42, (copy) v_u_7, (copy) v_u_16, (copy) v_u_46, (copy) v_u_36, (copy) v_u_41, (copy) v_u_95, (copy) v_u_51
	v_u_96 = v_u_96 + p97
	if v_u_96 < 0.03333333333333333 then
		return
	else
		local v98 = v_u_96
		local v99 = math.min(v98, 0.1)
		v_u_96 = 0
		local v100 = v_u_3.CurrentCamera
		if v100 then
			local v101 = v100.CFrame.Position
			local v102 = os.clock()
			local v103 = {}
			for _, v104 in v_u_4.List() do
				local v105 = v_u_4.PlayerOf(v104)
				local v106 = v_u_9
				if v106 then
					v106 = v104:HasTag("CharacterLoadTest")
				end
				if v105 == v_u_8 or not (v105 or (v106 or v104:HasTag("Combatant"))) then
					continue
				end
				local v107 = (v105 == nil or v_u_3:GetAttribute("TribesAuthority") ~= "Client") and v_u_9
				if v107 then
					v107 = v104:HasTag("ClientAuthorityTest")
				end
				if v107 and not v_u_42[v104] then
					local v108 = v104:FindFirstChildOfClass("Humanoid")
					if v108 then
						v108 = v108:FindFirstChildOfClass("Animator")
					end
					if v108 then
						v_u_42[v104] = true
						v_u_7.Watch(v108)
					end
				end
				local v109 = v104:FindFirstChild("HumanoidRootPart")
				if not (v109 and v109:IsA("BasePart")) then
					continue
				end
				local v110 = v_u_16[v104]
				if (v109.Position - v101).Magnitude > 160 then
					if not (v110 and v110.active) then
						continue
					end
					v_u_46(v110)
				else
					if not v110 then
						v110 = v_u_36(v104, not v107)
						if not v110 then
							continue
						end
						v_u_16[v104] = v110
					end
					v103[v104] = true
					if v107 then
						v_u_41(v110)
					end
					v_u_95(v110, v99, v102)
				end
			end
			for v111, v112 in v_u_16 do
				if v111.Parent then
					if v103[v111] or not v112.active then
						continue
					end
					v_u_46(v112)
				else
					v_u_51(v112)
					v_u_16[v111] = nil
				end
			end
		end
	end
end
local v_u_114 = false
function v11.Start() -- name: Start
	-- upvalues: (ref) v_u_114, (copy) v_u_2, (copy) v_u_5, (copy) v_u_113
	if not v_u_114 then
		v_u_114 = true
		v_u_2.Heartbeat:Connect(function(p115)
			-- upvalues: (ref) v_u_5, (ref) v_u_113
			local v116 = v_u_5.Begin()
			v_u_113(p115)
			v_u_5.End("RemoteAnimate", v116)
		end)
	end
end
return v11