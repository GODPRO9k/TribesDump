local v_u_1 = game:GetService("Lighting")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = Font.new("rbxasset://fonts/families/Oswald.json", Enum.FontWeight.Bold)
local v_u_6 = {
	["ace"] = {
		["word"] = "ACE",
		["named"] = true,
		["style"] = "stamp",
		["headS"] = 2.05,
		["lead"] = 0
	},
	["teamace"] = {
		["word"] = "TEAM ACE",
		["named"] = false,
		["style"] = "stamp",
		["headS"] = 1.5,
		["lead"] = 4
	},
	["flawless"] = {
		["word"] = "FLAWLESS",
		["named"] = false,
		["style"] = "shine",
		["headS"] = 1.5,
		["lead"] = 0
	},
	["clutch"] = {
		["word"] = "CLUTCH",
		["named"] = true,
		["style"] = "hold",
		["headS"] = 1.8,
		["lead"] = 0
	}
}
local v7 = {}
for _, v8 in v_u_6 do
	v8.centres = {}
	v8.ends = {}
	local v9 = {}
	local v10 = 0
	local v11 = 0
	for v12 = 1, #v8.word do
		local v13 = v8.word
		local v14 = string.sub(v13, v12, v12)
		if v14 == " " then
			table.insert(v9, "   ")
			v10 = v10 + 3
			v11 = v11 + 72
		else
			if v12 > 1 then
				local v15 = v8.word
				local v16 = v12 - 1
				local v17 = v12 - 1
				if string.sub(v15, v16, v17) ~= " " then
					table.insert(v9, " ")
					v10 = v10 + 1
					v11 = v11 + 24
				end
			end
			table.insert(v9, v14)
			v10 = v10 + 1
			local v18 = v8.ends
			table.insert(v18, v10)
			local v19 = v8.centres
			local v20 = v11 + 21.5
			table.insert(v19, v20)
			v11 = v11 + 43
		end
	end
	v8.text = table.concat(v9)
	v8.width = v11
end
local function v_u_35(p21) -- name: readMoment
	-- upvalues: (copy) v_u_6
	if type(p21) == "table" then
		local v22 = p21.kind
		if type(v22) == "string" and v_u_6[p21.kind] then
			local v23 = p21.team
			local v24 = tonumber(v23)
			if v24 ~= 1 and v24 ~= 2 then
				return nil
			end
			local v25 = {
				["kind"] = p21.kind
			}
			local v26 = p21.id
			local v27
			if type(v26) == "string" then
				v27 = p21.id
			else
				v27 = nil
			end
			v25.id = v27
			local v28 = p21.name
			local v29
			if type(v28) == "string" and p21.name ~= "" then
				local v30 = p21.name
				v29 = string.sub(v30, 1, 32)
			else
				v29 = nil
			end
			v25.name = v29
			v25.team = v24
			local v31 = p21.vs
			local v32
			if type(v31) == "number" then
				local v33 = p21.vs
				local v34 = math.floor(v33)
				v32 = math.clamp(v34, 0, 9)
			else
				v32 = 0
			end
			v25.vs = v32
			return v25
		end
	end
	return nil
end
function v7.Init(p_u_36) -- name: Init
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_5, (copy) v_u_1, (copy) v_u_3, (copy) v_u_6, (copy) v_u_35
	local v_u_37 = p_u_36.UI
	local v_u_38 = p_u_36.Theme
	local v_u_39 = p_u_36.State
	local v_u_40 = p_u_36.Portraits
	local v_u_41 = v_u_38.Colors
	local v_u_42 = v_u_38.Fonts
	local v43 = v_u_37.Assets.Fx or {}
	local v_u_44 = v_u_2:WaitForChild("Shared"):FindFirstChild("Sfx")
	local v45, v_u_46 = pcall(function()
		-- upvalues: (copy) v_u_44
		if v_u_44 then
			return require(v_u_44)
		else
			return nil
		end
	end)
	if not v45 or type(v_u_46) ~= "table" then
		v_u_46 = nil
	end
	if v_u_46 and v_u_46.Preload then
		local v47 = v_u_46.Preload
		pcall(v47, {
			"Match/Elimination",
			"Kill_Triple",
			"Kill_Ally",
			"Match/Final_Round",
			"Match/Final_Heartbeat",
			"UI/Card_Reveal"
		})
	end
	local v_u_48 = 1
	local function v_u_56(p49, p50, p51, p52, p53, p54) -- name: tw
		-- upvalues: (ref) v_u_4, (ref) v_u_48
		local v55 = v_u_4:Create(p49, TweenInfo.new(p50 * v_u_48, p52 or Enum.EasingStyle.Quint, p53 or Enum.EasingDirection.Out, 0, false, (p54 or 0) * v_u_48), p51)
		v55:Play()
		return v55
	end
	local v_u_57 = v_u_37.new("Frame", {
		["Name"] = "Celebration",
		["Size"] = nil,
		["ZIndex"] = 5,
		["Visible"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = p_u_36.Canvas.Overlay
	})
	local v_u_58 = v_u_37.new("Frame", {
		["Name"] = "Dim",
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundColor3"] = v_u_41.Void,
		["Parent"] = v_u_57
	})
	local v_u_59 = v_u_37.new("Frame", {
		["Name"] = "Flash",
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundColor3"] = v_u_41.Ally,
		["Parent"] = v_u_57
	})
	local v_u_60 = v_u_37.new("ImageLabel", {
		["Name"] = "Vignette",
		["Size"] = nil,
		["Image"] = nil,
		["ImageTransparency"] = 1,
		["ScaleType"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Image"] = v43.Vignette or "",
		["ScaleType"] = Enum.ScaleType.Stretch,
		["Parent"] = v_u_57
	})
	local v_u_61 = v_u_37.new("Frame", {
		["Name"] = "Stage",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.36),
		["Size"] = UDim2.fromOffset(0, 0),
		["Parent"] = v_u_57
	})
	local v_u_62 = v_u_37.new("UIScale", {
		["Name"] = "StageScale",
		["Parent"] = nil,
		["Parent"] = v_u_61
	})
	local v_u_63 = v_u_37.new("Frame", {
		["Name"] = "Shaker",
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(0, 0),
		["Parent"] = v_u_61
	})
	local v_u_64 = v_u_37.new("ImageLabel", {
		["Name"] = "Glow",
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Image"] = nil,
		["ImageTransparency"] = 1,
		["ZIndex"] = 1,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(1000, 340),
		["Image"] = v_u_37.Assets.Icons.Glow,
		["Parent"] = v_u_63
	})
	local v_u_65 = v_u_37.new("ImageLabel", {
		["Name"] = "Ring",
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Image"] = nil,
		["ImageTransparency"] = 1,
		["ZIndex"] = 1,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(100, 100),
		["Image"] = v43.Ring or "",
		["Parent"] = v_u_63
	})
	local v_u_66 = v_u_37.new("ImageLabel", {
		["Name"] = "Band",
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Image"] = nil,
		["ImageTransparency"] = 0.1,
		["ScaleType"] = nil,
		["ZIndex"] = 2,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Size"] = UDim2.fromOffset(0, 150),
		["Image"] = v43.Band or "",
		["ScaleType"] = Enum.ScaleType.Stretch,
		["Parent"] = v_u_63
	})
	local v_u_67 = v_u_37.new("UIGradient", {
		["Transparency"] = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.14, 0.04),
			NumberSequenceKeypoint.new(0.86, 0.04),
			NumberSequenceKeypoint.new(1, 1)
		}),
		["Parent"] = v_u_66
	})
	local v_u_68 = v_u_37.new("ImageLabel", {
		["Name"] = "GhostBand",
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Image"] = nil,
		["ImageTransparency"] = 1,
		["ScaleType"] = nil,
		["ZIndex"] = 1,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(0, 230),
		["Image"] = v43.Band or "",
		["ScaleType"] = Enum.ScaleType.Stretch,
		["Parent"] = v_u_63
	})
	v_u_37.new("UIGradient", {
		["Transparency"] = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.25, 0.2),
			NumberSequenceKeypoint.new(0.75, 0.2),
			NumberSequenceKeypoint.new(1, 1)
		}),
		["Parent"] = v_u_68
	})
	local v_u_69 = v_u_37.new("Frame", {
		["Name"] = "Edge",
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Size"] = UDim2.fromOffset(0, 5),
		["Parent"] = v_u_63
	})
	v_u_37.new("UIGradient", {
		["Transparency"] = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.2, 0),
			NumberSequenceKeypoint.new(0.8, 0),
			NumberSequenceKeypoint.new(1, 1)
		}),
		["Parent"] = v_u_69
	})
	local function v72(p70, p71) -- name: headlineLabel
		-- upvalues: (copy) v_u_37, (ref) v_u_5, (copy) v_u_41, (copy) v_u_63
		return v_u_37.new("TextLabel", {
			["Name"] = nil,
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 100,
			["TextColor3"] = nil,
			["TextTransparency"] = 1,
			["ZIndex"] = nil,
			["Parent"] = nil,
			["Name"] = p70,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Size"] = UDim2.fromOffset(1400, 120),
			["FontFace"] = v_u_5,
			["TextColor3"] = v_u_41.Text,
			["ZIndex"] = p71,
			["Parent"] = v_u_63
		})
	end
	local v_u_73 = v72("Aura", 4)
	local v_u_74 = v_u_37.new("UIScale", {
		["Name"] = "HeadScale",
		["Parent"] = nil,
		["Parent"] = v_u_73
	})
	local v_u_75 = v72("Headline", 5)
	local v_u_76 = v_u_37.new("UIScale", {
		["Name"] = "HeadScale",
		["Parent"] = nil,
		["Parent"] = v_u_75
	})
	local v_u_77 = v_u_37.new("UIGradient", {
		["Rotation"] = 90,
		["Parent"] = nil,
		["Parent"] = v_u_75
	})
	local v_u_78 = v72("Shadow", 4)
	v_u_78.TextColor3 = v_u_41.Void
	local v_u_79 = v_u_37.new("UIScale", {
		["Name"] = "HeadScale",
		["Parent"] = nil,
		["Parent"] = v_u_78
	})
	local v_u_80 = v72("Sweep", 6)
	local v_u_81 = v_u_37.new("UIScale", {
		["Name"] = "HeadScale",
		["Parent"] = nil,
		["Parent"] = v_u_80
	})
	local v_u_82 = v_u_37.new("UIGradient", {
		["Rotation"] = 18,
		["Transparency"] = nil,
		["Offset"] = nil,
		["Parent"] = nil,
		["Transparency"] = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.44, 1),
			NumberSequenceKeypoint.new(0.5, 0),
			NumberSequenceKeypoint.new(0.56, 1),
			NumberSequenceKeypoint.new(1, 1)
		}),
		["Offset"] = Vector2.new(-1, 0),
		["Parent"] = v_u_80
	})
	local v_u_83 = v_u_37.new("TextLabel", {
		["Name"] = "Caption",
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 26,
		["TextColor3"] = nil,
		["TextTransparency"] = 1,
		["ZIndex"] = 6,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Size"] = UDim2.fromOffset(700, 32),
		["FontFace"] = v_u_42.Heavy,
		["TextColor3"] = v_u_41.TextDim,
		["Parent"] = v_u_63
	})
	local v_u_84 = v_u_37.TextStroke(v_u_41.Void, 1.5, 0.5)
	v_u_84.Parent = v_u_83
	local v_u_85 = v_u_37.new("Frame", {
		["Name"] = "Score",
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Size"] = UDim2.fromOffset(300, 80),
		["Parent"] = v_u_63
	})
	local v_u_86 = v_u_37.new("UIScale", {
		["Parent"] = v_u_85
	})
	local function v91(p87) -- name: digitSlot
		-- upvalues: (copy) v_u_37, (copy) v_u_85, (ref) v_u_5, (copy) v_u_41
		local v_u_88 = v_u_37.new("Frame", {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ClipsDescendants"] = true,
			["ZIndex"] = 6,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(0.5, p87, 0.5, 0),
			["Size"] = UDim2.fromOffset(90, 80),
			["Parent"] = v_u_85
		})
		local v89 = v_u_37.new("UIScale", {
			["Parent"] = v_u_88
		})
		local function v90() -- name: digit
			-- upvalues: (ref) v_u_37, (ref) v_u_5, (ref) v_u_41, (copy) v_u_88
			return v_u_37.new("TextLabel", {
				["Size"] = nil,
				["Text"] = "0",
				["FontFace"] = nil,
				["TextSize"] = 72,
				["TextColor3"] = nil,
				["ZIndex"] = 6,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["FontFace"] = v_u_5,
				["TextColor3"] = v_u_41.Text,
				["Parent"] = v_u_88
			})
		end
		return v_u_88, v90(), v90(), v89
	end
	local v_u_92, v_u_93, v_u_94, v_u_95 = v91(-76)
	local v_u_96, v_u_97, v_u_98, v_u_99 = v91(76)
	local v_u_100 = v_u_37.new("Frame", {
		["Name"] = "Dash",
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(34, 6),
		["BackgroundColor3"] = v_u_41.TextDim,
		["ZIndex"] = 6,
		v_u_37.Corner(3),
		["Parent"] = v_u_85
	})
	local v_u_101 = v_u_37.new("Frame", {
		["Name"] = "Team",
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Size"] = UDim2.fromOffset(480, 170),
		["Parent"] = v_u_63
	})
	local v_u_102 = v_u_48
	local v_u_103 = {}
	for v104 = 1, 3 do
		local v105 = v_u_37.new("Frame", {
			["Name"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 6,
			["Parent"] = nil,
			["Name"] = "P" .. v104,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, (v104 - 2) * 150, 0, 0),
			["Size"] = UDim2.fromOffset(124, 168),
			["Parent"] = v_u_101
		})
		local v106 = v_u_37.new("ImageLabel", {
			["Name"] = "Img",
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.fromScale(0.5, 0),
			["Size"] = UDim2.fromOffset(112, 112),
			["BackgroundColor3"] = v_u_41.Panel,
			["BackgroundTransparency"] = 0.1,
			["ScaleType"] = Enum.ScaleType.Crop,
			["ZIndex"] = 6,
			v_u_37.Corner(v_u_38.Radius.Pill),
			["Parent"] = v105
		})
		local v107 = v_u_37.Stroke(v_u_41.Ally, 3, 0)
		v107.Parent = v106
		local v108 = v_u_37.new("TextLabel", {
			["Name"] = "Name",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 20,
			["TextColor3"] = nil,
			["TextTruncate"] = nil,
			["ZIndex"] = 6,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 120),
			["Size"] = UDim2.fromOffset(150, 26),
			["FontFace"] = v_u_42.Bold,
			["TextColor3"] = v_u_41.Text,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v105
		})
		v_u_37.TextStroke(v_u_41.Void, 1.5, 0.4).Parent = v108
		v_u_103[v104] = {
			["frame"] = v105,
			["img"] = v106,
			["name"] = v108,
			["star"] = v_u_37.Image(v_u_37.Assets.Icons.Star, {
				["Name"] = "Star",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ImageColor3"] = nil,
				["Visible"] = false,
				["ZIndex"] = 7,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.new(0.5, 44, 0, 10),
				["Size"] = UDim2.fromOffset(34, 34),
				["ImageColor3"] = v_u_41.Gold,
				["Parent"] = v105
			}),
			["stroke"] = v107
		}
	end
	local v_u_109 = v_u_37.new("ImageLabel", {
		["Name"] = "CeremonyFlare",
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Image"] = nil,
		["ImageTransparency"] = 1,
		["ZIndex"] = 6,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(820, 56),
		["Image"] = v43.Flare or "",
		["Parent"] = v_u_63
	})
	local v_u_110 = v_u_37.new("Frame", {
		["Name"] = "CeremonyPlate",
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.fromOffset(0, 66),
		["BackgroundColor3"] = v_u_41.Panel,
		["BackgroundTransparency"] = 1,
		["Visible"] = false,
		["ZIndex"] = 5,
		v_u_37.Corner(v_u_38.Radius.Pill),
		["Parent"] = v_u_63
	})
	local v_u_111 = v_u_37.Padding(0, 22, 0, 5)
	v_u_111.Parent = v_u_110
	local v_u_112 = v_u_37.Stroke(v_u_41.Ally, 2, 1)
	v_u_112.Parent = v_u_110
	v_u_37.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["HorizontalAlignment"] = Enum.HorizontalAlignment.Center,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Padding"] = UDim.new(0, 14),
		["Parent"] = v_u_110
	})
	local function v120(p113, p114, p115) -- name: face
		-- upvalues: (copy) v_u_37, (copy) v_u_41, (copy) v_u_38
		local v116 = v_u_37.new("Frame", {
			["Name"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["ZIndex"] = 6,
			["Parent"] = nil,
			["Name"] = "Face" .. p115,
			["Size"] = UDim2.fromOffset(p114, p114),
			["LayoutOrder"] = p115,
			["Parent"] = p113
		})
		local v117 = v_u_37.new("ImageLabel", {
			["Name"] = "Img",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = v_u_41.Panel,
			["BackgroundTransparency"] = 0.1,
			["ScaleType"] = Enum.ScaleType.Crop,
			["ZIndex"] = 6,
			v_u_37.Corner(v_u_38.Radius.Pill),
			["Parent"] = v116
		})
		local v118 = v_u_37.Stroke(v_u_41.Ally, 3, 0)
		v118.Parent = v117
		local v119 = {
			["holder"] = v116,
			["img"] = v117,
			["stroke"] = v118,
			["scale"] = v_u_37.new("UIScale", {
				["Parent"] = v116
			})
		}
		return v119
	end
	local v_u_121 = { v120(v_u_110, 56, 1), v120(v_u_110, 56, 2), v120(v_u_110, 56, 3) }
	local function v127(p122, p123, p124) -- name: nameLabel
		-- upvalues: (copy) v_u_37, (copy) v_u_42, (copy) v_u_41
		local v125 = v_u_37.new("TextLabel", {
			["Name"] = "Name",
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["TextTransparency"] = 1,
			["LayoutOrder"] = nil,
			["ZIndex"] = 6,
			["Parent"] = nil,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromOffset(0, p123 + 8),
			["FontFace"] = v_u_42.Heavy,
			["TextSize"] = p123,
			["TextColor3"] = v_u_41.Text,
			["LayoutOrder"] = p124,
			["Parent"] = p122
		})
		local v126 = v_u_37.TextStroke(v_u_41.Void, 2, 1)
		v126.Parent = v125
		return v125, v126
	end
	local function v133(p128, p129, p130, p131) -- name: vsPill
		-- upvalues: (copy) v_u_37, (copy) v_u_41, (copy) v_u_38, (ref) v_u_5
		local v132 = v_u_37.new("Frame", {
			["Name"] = "Vs",
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromOffset(0, p129),
			["BackgroundColor3"] = v_u_41.Ally,
			["BackgroundTransparency"] = 1,
			["LayoutOrder"] = p131,
			["ZIndex"] = 6,
			v_u_37.Corner(v_u_38.Radius.Pill),
			v_u_37.Padding(0, 12, 0, 12),
			["Parent"] = p128
		})
		return v132, v_u_37.new("TextLabel", {
			["Name"] = "Text",
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["TextTransparency"] = 1,
			["ZIndex"] = 7,
			["Parent"] = nil,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromScale(0, 1),
			["FontFace"] = v_u_5,
			["TextSize"] = p130,
			["TextColor3"] = v_u_41.Text,
			["Parent"] = v132
		}), v_u_37.new("UIScale", {
			["Parent"] = v132
		})
	end
	local v_u_134, v_u_135 = v127(v_u_110, 36, 4)
	local v_u_136, v_u_137, v_u_138 = v133(v_u_110, 34, 26, 5)
	local v_u_139 = v_u_37.new("ImageLabel", {
		["Name"] = "CeremonyRibbon",
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Image"] = nil,
		["ImageTransparency"] = 1,
		["ScaleType"] = nil,
		["ZIndex"] = 5,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(0, 92),
		["Image"] = v43.Band or "",
		["ScaleType"] = Enum.ScaleType.Stretch,
		["Parent"] = v_u_63
	})
	v_u_37.new("UIGradient", {
		["Transparency"] = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.16, 0),
			NumberSequenceKeypoint.new(0.84, 0),
			NumberSequenceKeypoint.new(1, 1)
		}),
		["Parent"] = v_u_139
	})
	local v_u_140 = v_u_37.new("Frame", {
		["Name"] = "CeremonyAccolade",
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 6,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Size"] = UDim2.fromOffset(900, 84),
		["Parent"] = v_u_63
	})
	local v_u_141 = v_u_37.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["HorizontalAlignment"] = Enum.HorizontalAlignment.Center,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Padding"] = UDim.new(0, 20),
		["Parent"] = v_u_140
	})
	local v_u_142 = v_u_37.new("TextLabel", {
		["Name"] = "Word",
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 80,
		["TextColor3"] = nil,
		["TextTransparency"] = 1,
		["LayoutOrder"] = 1,
		["ZIndex"] = 6,
		["Parent"] = nil,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.fromOffset(0, 84),
		["FontFace"] = v_u_5,
		["TextColor3"] = v_u_41.Text,
		["Parent"] = v_u_140
	})
	local v_u_143 = v_u_37.new("UIGradient", {
		["Rotation"] = 90,
		["Parent"] = nil,
		["Parent"] = v_u_142
	})
	local v_u_144 = v_u_37.TextStroke(v_u_41.Void, 2, 1)
	v_u_144.Parent = v_u_142
	local v_u_145 = v_u_37.new("Frame", {
		["Name"] = "Bar",
		["Size"] = UDim2.fromOffset(4, 46),
		["BackgroundColor3"] = v_u_41.Ally,
		["BackgroundTransparency"] = 1,
		["LayoutOrder"] = 2,
		["ZIndex"] = 6,
		v_u_37.Corner(2),
		["Parent"] = v_u_140
	})
	local v_u_146 = v120(v_u_140, 58, 3)
	local v_u_147, v_u_148 = v127(v_u_140, 38, 4)
	local v_u_149, v_u_150, v_u_151 = v133(v_u_140, 34, 26, 5)
	local v152 = v_u_37.new("Frame", {
		["Name"] = "Particles",
		["Size"] = nil,
		["ZIndex"] = 7,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(0, 0),
		["Parent"] = v_u_63
	})
	local v_u_153 = require(script.Parent.Parent.Fx).Pool(v152, 72, 7)
	local v_u_154 = Random.new()
	local function v_u_162(p155, p156, p157, p158, p159, p160) -- name: burst
		-- upvalues: (copy) v_u_153, (ref) v_u_102, (copy) v_u_41
		local v161 = p160 or {}
		v_u_153.Pace = v_u_102
		v_u_153:Burst(p155, {
			["mode"] = "box",
			["box"] = nil,
			["speed"] = nil,
			["color"] = nil,
			["white"] = nil,
			["whiteChance"] = 0.35,
			["sparkChance"] = nil,
			["grav"] = nil,
			["drag"] = nil,
			["base"] = nil,
			["lifeMult"] = nil,
			["box"] = Vector2.new(p157, p158),
			["speed"] = p159,
			["color"] = p156,
			["white"] = v_u_41.Text,
			["sparkChance"] = v161.sparkChance or 0.55,
			["grav"] = v161.grav,
			["drag"] = v161.drag,
			["base"] = v161.base,
			["lifeMult"] = v161.lifeMult
		})
	end
	local v_u_163 = nil
	local v_u_164 = nil
	local function v_u_174(p165, p166) -- name: screenFx
		-- upvalues: (ref) v_u_163, (copy) v_u_37, (ref) v_u_1, (ref) v_u_4, (ref) v_u_102, (ref) v_u_164
		if not v_u_163 then
			local v167 = {
				["Name"] = "TR_CelebrateCC",
				["Parent"] = nil,
				["Parent"] = v_u_1
			}
			v_u_163 = v_u_37.new("ColorCorrectionEffect", v167)
		end
		local v168 = v_u_163
		v168.Enabled = true
		local v169 = Color3.new(1, 1, 1)
		v168.Brightness = 0
		v168.Contrast = 0
		v168.Saturation = 0
		v168.TintColor = v169
		if p165 == "win" then
			local v170 = {
				["Contrast"] = 0.12,
				["Saturation"] = 0.18,
				["TintColor"] = nil,
				["TintColor"] = Color3.fromRGB(236, 244, 255)
			}
			v_u_4:Create(v168, TweenInfo.new(v_u_102 * 0.25, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v170):Play()
		elseif p165 == "lose" then
			local v171 = {
				["Contrast"] = 0.05,
				["Saturation"] = -0.65,
				["Brightness"] = -0.05,
				["TintColor"] = nil,
				["TintColor"] = Color3.fromRGB(255, 232, 232)
			}
			v_u_4:Create(v168, TweenInfo.new(v_u_102 * 0.45, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v171):Play()
		else
			v_u_4:Create(v168, TweenInfo.new(v_u_102 * 0.35, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
				["Saturation"] = -0.3,
				["Brightness"] = -0.02
			}):Play()
		end
		if p166 then
			if not v_u_164 then
				local v172 = {
					["Name"] = "TR_CelebrateBlur",
					["Size"] = 0,
					["Parent"] = nil,
					["Parent"] = v_u_1
				}
				v_u_164 = v_u_37.new("BlurEffect", v172)
			end
			local v173 = v_u_164
			v173.Enabled = true
			v173.Size = 0
			v_u_4:Create(v173, TweenInfo.new(v_u_102 * 0.5, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
				["Size"] = 10
			}):Play()
		end
	end
	local function v_u_181(p175) -- name: screenFxOut
		-- upvalues: (ref) v_u_163, (ref) v_u_4, (ref) v_u_102, (ref) v_u_164
		if v_u_163 then
			local v176 = v_u_163
			local v177 = {
				["Contrast"] = 0,
				["Saturation"] = 0,
				["Brightness"] = 0,
				["TintColor"] = nil,
				["TintColor"] = Color3.new(1, 1, 1)
			}
			local v178 = Enum.EasingStyle.Quad
			v_u_4:Create(v176, TweenInfo.new(p175 * v_u_102, v178 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v177):Play()
		end
		if v_u_164 then
			local v179 = v_u_164
			local v180 = Enum.EasingStyle.Quad
			v_u_4:Create(v179, TweenInfo.new(p175 * v_u_102, v180 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
				["Size"] = 0
			}):Play()
		end
	end
	local v_u_182 = 0
	local v_u_183 = false
	local v_u_184 = false
	local function v_u_200(_, p_u_185, p_u_186, p_u_187, p_u_188, p_u_189) -- name: rollDigit
		-- upvalues: (ref) v_u_4, (ref) v_u_102
		p_u_186.Text = tostring(p_u_188)
		p_u_186.TextColor3 = p_u_189
		p_u_186.Visible = true
		p_u_186.TextTransparency = 0
		p_u_186.Position = UDim2.fromScale(0, 1)
		local v190 = {
			["Position"] = UDim2.fromScale(0, -1)
		}
		local v191 = Enum.EasingStyle.Quint
		local v192 = Enum.EasingDirection.In
		v_u_4:Create(p_u_185, TweenInfo.new(v_u_102 * 0.28, v191 or Enum.EasingStyle.Quint, v192 or Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v190):Play()
		local v193 = {
			["Position"] = UDim2.new()
		}
		local v194 = Enum.EasingStyle.Back
		local v195 = Enum.EasingDirection.Out
		v_u_4:Create(p_u_186, TweenInfo.new(v_u_102 * 0.34, v194 or Enum.EasingStyle.Quint, v195 or Enum.EasingDirection.Out, 0, false, 0.08 * v_u_102), v193):Play()
		local function v199()
			-- upvalues: (copy) p_u_185, (copy) p_u_188, (copy) p_u_189, (copy) p_u_186, (copy) p_u_187, (ref) v_u_4, (ref) v_u_102
			local v196 = p_u_188
			p_u_185.Text = tostring(v196)
			p_u_185.TextColor3 = p_u_189
			p_u_185.Position = UDim2.new()
			p_u_186.Visible = false
			p_u_187.Scale = 1.35
			local v197 = p_u_187
			local v198 = Enum.EasingStyle.Back
			v_u_4:Create(v197, TweenInfo.new(v_u_102 * 0.35, v198 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
				["Scale"] = 1
			}):Play()
		end
		task.delay(v_u_102 * 0.42, v199)
	end
	local function v_u_222(p201) -- name: ceremonyFade
		-- upvalues: (copy) v_u_134, (copy) v_u_137, (copy) v_u_142, (copy) v_u_147, (copy) v_u_150, (ref) v_u_4, (ref) v_u_102, (copy) v_u_135, (copy) v_u_144, (copy) v_u_148, (copy) v_u_136, (copy) v_u_149, (copy) v_u_145, (copy) v_u_110, (copy) v_u_112, (copy) v_u_121, (copy) v_u_146, (copy) v_u_109, (copy) v_u_139
		for _, v202 in {
			v_u_134,
			v_u_137,
			v_u_142,
			v_u_147,
			v_u_150
		} do
			local v203 = Enum.EasingStyle.Quad
			v_u_4:Create(v202, TweenInfo.new(p201 * v_u_102, v203 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
				["TextTransparency"] = 1
			}):Play()
		end
		for _, v204 in { v_u_135, v_u_144, v_u_148 } do
			local v205 = Enum.EasingStyle.Quad
			v_u_4:Create(v204, TweenInfo.new(p201 * v_u_102, v205 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
				["Transparency"] = 1
			}):Play()
		end
		for _, v206 in { v_u_136, v_u_149 } do
			local v207 = Enum.EasingStyle.Quad
			v_u_4:Create(v206, TweenInfo.new(p201 * v_u_102, v207 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
				["BackgroundTransparency"] = 1
			}):Play()
		end
		local v208 = v_u_145
		local v209 = Enum.EasingStyle.Quad
		v_u_4:Create(v208, TweenInfo.new(p201 * v_u_102, v209 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
			["BackgroundTransparency"] = 1
		}):Play()
		local v210 = v_u_110
		local v211 = Enum.EasingStyle.Quad
		v_u_4:Create(v210, TweenInfo.new(p201 * v_u_102, v211 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
			["BackgroundTransparency"] = 1
		}):Play()
		local v212 = v_u_112
		local v213 = Enum.EasingStyle.Quad
		v_u_4:Create(v212, TweenInfo.new(p201 * v_u_102, v213 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
			["Transparency"] = 1
		}):Play()
		for _, v214 in {
			v_u_121[1],
			v_u_121[2],
			v_u_121[3],
			v_u_146
		} do
			local v215 = v214.scale
			local v216 = Enum.EasingStyle.Quint
			local v217 = Enum.EasingDirection.In
			v_u_4:Create(v215, TweenInfo.new(p201 * v_u_102, v216 or Enum.EasingStyle.Quint, v217 or Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
				["Scale"] = 0
			}):Play()
		end
		local v218 = v_u_109
		local v219 = Enum.EasingStyle.Quad
		v_u_4:Create(v218, TweenInfo.new(p201 * v_u_102, v219 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
			["ImageTransparency"] = 1
		}):Play()
		local v220 = v_u_139
		local v221 = Enum.EasingStyle.Quad
		v_u_4:Create(v220, TweenInfo.new(p201 * v_u_102, v221 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
			["ImageTransparency"] = 1
		}):Play()
	end
	local function v_u_240(p223) -- name: stop
		-- upvalues: (ref) v_u_183, (ref) v_u_182, (ref) v_u_184, (copy) p_u_36, (copy) v_u_153, (copy) v_u_110, (copy) v_u_140, (copy) v_u_109, (copy) v_u_139, (copy) v_u_75, (copy) v_u_78, (copy) v_u_80, (copy) v_u_73, (copy) v_u_57, (ref) v_u_163, (ref) v_u_164, (copy) v_u_83, (ref) v_u_4, (ref) v_u_102, (copy) v_u_84, (copy) v_u_66, (copy) v_u_68, (copy) v_u_60, (copy) v_u_58, (copy) v_u_222, (copy) v_u_181
		if v_u_183 then
			v_u_182 = v_u_182 + 1
			local v_u_224 = v_u_182
			v_u_183 = false
			if v_u_184 then
				p_u_36.SetHudHidden("Celebrate", false)
			end
			v_u_184 = false
			if p223 then
				v_u_153:Clear()
				v_u_110.Visible = false
				v_u_140.Visible = false
				v_u_109.ImageTransparency = 1
				v_u_139.ImageTransparency = 1
				for _, v225 in {
					v_u_75,
					v_u_78,
					v_u_80,
					v_u_73
				} do
					v225.MaxVisibleGraphemes = -1
				end
				v_u_57.Visible = false
				if v_u_163 then
					v_u_163:Destroy()
					v_u_163 = nil
				end
				if v_u_164 then
					v_u_164:Destroy()
					v_u_164 = nil
				end
			else
				for _, v226 in {
					v_u_75,
					v_u_78,
					v_u_80,
					v_u_83,
					v_u_73
				} do
					local v227 = Enum.EasingStyle.Quad
					v_u_4:Create(v226, TweenInfo.new(v_u_102 * 0.15, v227 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
						["TextTransparency"] = 1
					}):Play()
				end
				local v228 = v_u_84
				local v229 = Enum.EasingStyle.Quad
				v_u_4:Create(v228, TweenInfo.new(v_u_102 * 0.15, v229 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
					["Transparency"] = 1
				}):Play()
				local v230 = v_u_66
				local v231 = Enum.EasingStyle.Quad
				v_u_4:Create(v230, TweenInfo.new(v_u_102 * 0.15, v231 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
					["ImageTransparency"] = 1
				}):Play()
				local v232 = v_u_68
				local v233 = Enum.EasingStyle.Quad
				v_u_4:Create(v232, TweenInfo.new(v_u_102 * 0.15, v233 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
					["ImageTransparency"] = 1
				}):Play()
				local v234 = v_u_60
				local v235 = Enum.EasingStyle.Quad
				v_u_4:Create(v234, TweenInfo.new(v_u_102 * 0.2, v235 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
					["ImageTransparency"] = 1
				}):Play()
				local v236 = v_u_58
				local v237 = Enum.EasingStyle.Quad
				v_u_4:Create(v236, TweenInfo.new(v_u_102 * 0.2, v237 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
					["BackgroundTransparency"] = 1
				}):Play()
				v_u_222(0.15)
				v_u_181(0.2)
				local function v239()
					-- upvalues: (copy) v_u_224, (ref) v_u_182, (ref) v_u_153, (ref) v_u_110, (ref) v_u_140, (ref) v_u_109, (ref) v_u_139, (ref) v_u_75, (ref) v_u_78, (ref) v_u_80, (ref) v_u_73, (ref) v_u_57, (ref) v_u_163, (ref) v_u_164
					if v_u_224 == v_u_182 then
						v_u_153:Clear()
						v_u_110.Visible = false
						v_u_140.Visible = false
						v_u_109.ImageTransparency = 1
						v_u_139.ImageTransparency = 1
						for _, v238 in {
							v_u_75,
							v_u_78,
							v_u_80,
							v_u_73
						} do
							v238.MaxVisibleGraphemes = -1
						end
						v_u_57.Visible = false
						if v_u_163 then
							v_u_163:Destroy()
							v_u_163 = nil
						end
						if v_u_164 then
							v_u_164:Destroy()
							v_u_164 = nil
						end
					end
				end
				task.delay(v_u_102 * 0.22, v239)
			end
		else
			return
		end
	end
	local function v_u_250(p_u_241, p_u_242, p_u_243, p244, p_u_245) -- name: portraitWhenGrown
		-- upvalues: (copy) v_u_40, (ref) v_u_182, (ref) v_u_102
		local function v_u_248() -- name: apply
			-- upvalues: (copy) p_u_241, (ref) v_u_40, (copy) p_u_242, (copy) p_u_243
			for _, v246 in { "RigHead", "RigBack" } do
				local v247 = p_u_241:FindFirstChild(v246)
				if not v247 then
					continue
				end
				v247:Destroy()
			end
			v_u_40.Apply(p_u_241, p_u_242, 150)
			v_u_40.SetTint(p_u_241, p_u_243, 0)
		end
		v_u_248()
		if v_u_40.ThumbFor(p_u_242, 150) == "" then
			local function v249()
				-- upvalues: (copy) p_u_245, (ref) v_u_182, (copy) v_u_248
				if p_u_245 == v_u_182 then
					v_u_248()
				end
			end
			task.delay(p244 * v_u_102, v249)
		end
	end
	local function v_u_258(p251, p252, p253, p254, p255, p256) -- name: pointBurst
		-- upvalues: (copy) v_u_153, (ref) v_u_102
		local v257 = p256 or {}
		v_u_153.Pace = v_u_102
		v_u_153:Burst(p251, {
			["mode"] = "point",
			["at"] = nil,
			["jitter"] = nil,
			["speed"] = nil,
			["color"] = nil,
			["white"] = nil,
			["whiteChance"] = nil,
			["sparkChance"] = nil,
			["kind"] = nil,
			["size"] = nil,
			["grav"] = nil,
			["drag"] = nil,
			["lifeMult"] = nil,
			["at"] = Vector2.new(p253, p254),
			["jitter"] = v257.jitter or 30,
			["speed"] = p255,
			["color"] = p252,
			["white"] = v257.white,
			["whiteChance"] = v257.whiteChance or 0.3,
			["sparkChance"] = v257.sparkChance or 0.75,
			["kind"] = v257.kind,
			["size"] = v257.size,
			["grav"] = v257.grav,
			["drag"] = v257.drag,
			["lifeMult"] = v257.lifeMult
		})
	end
	local function v_u_704(p259, p_u_260, p_u_261, p_u_262, p_u_263, p_u_264, p265, p266, p_u_267) -- name: play
		-- upvalues: (ref) v_u_183, (ref) v_u_182, (ref) v_u_184, (copy) p_u_36, (copy) v_u_153, (copy) v_u_110, (copy) v_u_140, (copy) v_u_109, (copy) v_u_139, (copy) v_u_75, (copy) v_u_78, (copy) v_u_80, (copy) v_u_73, (copy) v_u_57, (ref) v_u_163, (ref) v_u_164, (ref) v_u_6, (copy) v_u_41, (copy) v_u_37, (copy) v_u_62, (copy) v_u_61, (copy) v_u_63, (copy) v_u_58, (ref) v_u_4, (ref) v_u_102, (copy) v_u_59, (copy) v_u_60, (copy) v_u_174, (copy) v_u_66, (copy) v_u_67, (copy) v_u_68, (copy) v_u_69, (copy) v_u_38, (copy) v_u_77, (copy) v_u_82, (copy) v_u_74, (copy) v_u_65, (copy) v_u_76, (copy) v_u_79, (copy) v_u_81, (copy) v_u_56, (copy) v_u_154, (ref) v_u_3, (copy) v_u_162, (copy) v_u_64, (ref) v_u_46, (copy) v_u_258, (copy) v_u_83, (copy) v_u_84, (copy) v_u_39, (copy) v_u_121, (copy) v_u_250, (copy) v_u_134, (copy) v_u_135, (copy) v_u_136, (copy) v_u_137, (copy) v_u_138, (copy) v_u_111, (copy) v_u_112, (copy) v_u_85, (copy) v_u_86, (copy) v_u_93, (copy) v_u_94, (copy) v_u_97, (copy) v_u_98, (copy) v_u_100, (copy) v_u_200, (copy) v_u_92, (copy) v_u_95, (copy) v_u_96, (copy) v_u_99, (copy) v_u_101, (copy) v_u_103, (copy) v_u_142, (copy) v_u_143, (copy) v_u_144, (copy) v_u_145, (copy) v_u_146, (copy) v_u_147, (copy) v_u_149, (copy) v_u_148, (copy) v_u_150, (copy) v_u_151, (copy) v_u_141, (copy) v_u_222, (copy) v_u_181
		if v_u_183 then
			v_u_182 = v_u_182 + 1
			v_u_183 = false
			if v_u_184 then
				p_u_36.SetHudHidden("Celebrate", false)
			end
			v_u_184 = false
			v_u_153:Clear()
			v_u_110.Visible = false
			v_u_140.Visible = false
			v_u_109.ImageTransparency = 1
			v_u_139.ImageTransparency = 1
			for _, v268 in {
				v_u_75,
				v_u_78,
				v_u_80,
				v_u_73
			} do
				v268.MaxVisibleGraphemes = -1
			end
			v_u_57.Visible = false
			if v_u_163 then
				v_u_163:Destroy()
				v_u_163 = nil
			end
			if v_u_164 then
				v_u_164:Destroy()
				v_u_164 = nil
			end
		end
		v_u_182 = v_u_182 + 1
		local v_u_269 = v_u_182
		v_u_183 = true
		v_u_184 = p_u_260
		local v270 = p259 == "win"
		local v_u_271 = p259 == "lose"
		if not (v270 or v_u_271) then
			p_u_267 = nil
		end
		local v_u_272
		if p_u_267 and not p_u_260 then
			v_u_272 = v_u_6[p_u_267.kind]
		else
			v_u_272 = nil
		end
		local v_u_273
		if p_u_267 and p_u_260 then
			v_u_273 = v_u_6[p_u_267.kind]
		else
			v_u_273 = nil
		end
		local v_u_274
		if v270 then
			v_u_274 = v_u_41.Ally
		elseif v_u_271 then
			v_u_274 = v_u_41.Enemy
		else
			v_u_274 = v_u_41.Bone
		end
		local v_u_275 = v_u_274:Lerp(v_u_41.Void, v_u_271 and 0.55 or 0.4)
		local v276 = v_u_37.Compact
		v_u_62.Scale = v276 and (v_u_272 and 0.7 or 0.74) or 1
		local v277
		if p_u_260 then
			if v276 then
				v277 = v_u_273 and 0.36 or 0.33
			else
				v277 = v_u_273 and 0.385 or 0.36
			end
		elseif v_u_272 then
			v277 = v276 and 0.2867 or 0.265
		else
			v277 = v276 and 0.27 or 0.29
		end
		v_u_61.Position = UDim2.fromScale(0.5, v277)
		v_u_63.Position = UDim2.new()
		v_u_110.Visible = false
		v_u_140.Visible = false
		v_u_109.ImageTransparency = 1
		v_u_139.ImageTransparency = 1
		for _, v278 in {
			v_u_75,
			v_u_78,
			v_u_80,
			v_u_73
		} do
			v278.MaxVisibleGraphemes = -1
		end
		v_u_57.Visible = true
		if p_u_260 then
			p_u_36.SetHudHidden("Celebrate", true)
		end
		local v_u_279 = p_u_260 and 2000 or (v_u_272 and 1600 or 1500)
		local v_u_280 = p_u_260 and 210 or (v_u_272 and (v276 and 156 or 172) or 150)
		local v_u_281 = p_u_260 and 2.35 or (not v_u_272 and 1.55 or v_u_272.headS)
		local v_u_282
		if v_u_272 then
			v_u_282 = v_u_272.text
		elseif p_u_260 then
			v_u_282 = v270 and "VICTORY" or (v_u_271 and "DEFEAT" or "DRAW")
		else
			v_u_282 = v270 and "ROUND WON" or (v_u_271 and "ROUND LOST" or "DRAW")
		end
		local v283
		if v_u_272 then
			v283 = v_u_272.style
		else
			v283 = nil
		end
		local v_u_284 = v_u_271 and 0.6 or 1
		v_u_58.BackgroundTransparency = 1
		if p_u_260 then
			v_u_4:Create(v_u_58, TweenInfo.new(v_u_102 * 0.4, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
				["BackgroundTransparency"] = v_u_271 and 0.4 or 0.5
			}):Play()
		end
		v_u_59.BackgroundColor3 = v_u_274
		v_u_59.BackgroundTransparency = v_u_271 and 0.84 or 0.6
		local v285 = v_u_59
		local v286 = Enum.EasingStyle.Quad
		v_u_4:Create(v285, TweenInfo.new((v_u_271 and 0.6 or 0.45) * v_u_102, v286 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
			["BackgroundTransparency"] = 1
		}):Play()
		local v_u_287 = v_u_271 and 0.2 or 0.3
		local v288 = v_u_60
		local v289
		if v_u_271 then
			v289 = v_u_274:Lerp(v_u_41.Void, 0.78)
		else
			v289 = v_u_274:Lerp(v_u_41.Void, 0.25)
		end
		v288.ImageColor3 = v289
		v_u_60.ImageTransparency = 1
		v_u_4:Create(v_u_60, TweenInfo.new(v_u_102 * 0.25, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
			["ImageTransparency"] = v_u_287
		}):Play()
		v_u_174(p259, p_u_260)
		v_u_66.ImageColor3 = Color3.new(1, 1, 1)
		v_u_67.Color = ColorSequence.new({
			ColorSequenceKeypoint.new(0, v_u_275),
			ColorSequenceKeypoint.new(0.35, v_u_274:Lerp(v_u_41.Void, v_u_271 and 0.4 or 0.18)),
			ColorSequenceKeypoint.new(0.65, v_u_275),
			ColorSequenceKeypoint.new(1, v_u_275:Lerp(v_u_41.Void, 0.3))
		})
		v_u_66.ImageTransparency = v_u_271 and 0.18 or 0.04
		v_u_68.ImageColor3 = v_u_275
		v_u_68.Size = UDim2.fromOffset(v_u_279 * 0.6, v_u_280 * 1.55)
		v_u_68.ImageTransparency = 1
		local v290 = v_u_68
		local v291 = {
			["Size"] = UDim2.fromOffset(v_u_279 * 1.15, v_u_280 * 1.55),
			["ImageTransparency"] = v_u_271 and 0.7 or 0.55
		}
		v_u_4:Create(v290, TweenInfo.new(v_u_102 * 0.7, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v291):Play()
		v_u_66.AnchorPoint = Vector2.new(0, 0.5)
		v_u_66.Position = UDim2.fromOffset(-v_u_279 / 2, 0)
		v_u_66.Size = UDim2.fromOffset(0, v_u_280)
		local v292 = v_u_66
		local v293 = (v_u_271 or v283 == "hold") and 0.45 or 0.3
		local v294 = {
			["Size"] = UDim2.fromOffset(v_u_279, v_u_280)
		}
		v_u_4:Create(v292, TweenInfo.new(v293 * v_u_102, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v294):Play()
		v_u_69.BackgroundColor3 = v_u_38.Lighten(v_u_274, 0.25)
		v_u_69.AnchorPoint = Vector2.new(1, 0.5)
		v_u_69.Position = UDim2.fromOffset(v_u_279 / 2 - 60, v_u_280 / 2 - 2)
		v_u_69.Size = UDim2.fromOffset(0, p_u_260 and 6 or 5)
		v_u_69.BackgroundTransparency = 0
		local v295 = v_u_69
		local v296 = {
			["Size"] = UDim2.fromOffset(v_u_279 * 0.8, p_u_260 and 6 or 5)
		}
		local v297 = Enum.EasingStyle.Quint
		local v298 = Enum.EasingDirection.Out
		v_u_4:Create(v295, TweenInfo.new(v_u_102 * 0.35, v297 or Enum.EasingStyle.Quint, v298 or Enum.EasingDirection.Out, 0, false, 0.06 * v_u_102), v296):Play()
		p_u_36.Sounds.Play("Whoosh", {
			["volume"] = 0.35,
			["pitch"] = nil,
			["pitch"] = v_u_271 and 0.85 or 1
		})
		for _, v299 in {
			v_u_75,
			v_u_78,
			v_u_80,
			v_u_73
		} do
			v299.Text = v_u_282
			v299.TextTransparency = 1
			v299.Position = UDim2.fromOffset(0, 0)
		end
		v_u_73.TextColor3 = v_u_38.Lighten(v_u_274, 0.35)
		v_u_78.Position = UDim2.fromOffset(0, 7)
		v_u_77.Color = ColorSequence.new(v_u_41.Text, v_u_38.Lighten(v_u_274, v270 and 0.55 or 0.7))
		v_u_82.Offset = Vector2.new(-1, 0)
		v_u_74.Scale = v_u_281
		v_u_65.Position = UDim2.new()
		local v300, v301
		if v_u_272 then
			local v_u_302 = not v_u_271
			local function v_u_340(p303) -- name: ceremonyImpact
				-- upvalues: (copy) p_u_267, (ref) v_u_76, (ref) v_u_79, (ref) v_u_81, (copy) v_u_281, (copy) v_u_302, (ref) v_u_4, (ref) v_u_102, (ref) v_u_182, (ref) v_u_63, (ref) v_u_154, (ref) v_u_3, (ref) v_u_73, (ref) v_u_74, (copy) v_u_272, (ref) v_u_153, (ref) v_u_38, (copy) v_u_274, (ref) v_u_162, (ref) v_u_41, (ref) v_u_65, (ref) v_u_64, (copy) v_u_279, (copy) v_u_280, (copy) v_u_284, (ref) v_u_46
				local v304 = p_u_267.kind
				for _, v305 in { v_u_76, v_u_79, v_u_81 } do
					v305.Scale = v_u_281 * (v304 == "flawless" and 1.03 or (v_u_302 and 1.1 or 1.05))
					local v306 = {
						["Scale"] = v_u_281
					}
					local v307 = Enum.EasingStyle.Back
					v_u_4:Create(v305, TweenInfo.new(v_u_102 * 0.26, v307 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v306):Play()
				end
				if v304 ~= "flawless" then
					local v_u_308 = v_u_302 and (v304 == "clutch" and 13 or 10) or 3
					local v_u_309 = v304 == "clutch" and 0.32 or 0.24
					local v_u_310 = v_u_182
					task.spawn(function()
						-- upvalues: (copy) v_u_309, (ref) v_u_102, (copy) v_u_310, (ref) v_u_182, (ref) v_u_63, (ref) v_u_154, (copy) v_u_308, (ref) v_u_3
						local v311 = os.clock()
						while os.clock() - v311 < v_u_309 * v_u_102 and v_u_310 == v_u_182 do
							local v312 = 1 - (os.clock() - v311) / (v_u_309 * v_u_102)
							v_u_63.Position = UDim2.fromOffset(v_u_154:NextNumber(-1, 1) * v_u_308 * v312, v_u_154:NextNumber(-1, 1) * v_u_308 * v312)
							v_u_3.RenderStepped:Wait()
						end
						v_u_63.Position = UDim2.new()
					end)
				end
				v_u_73.MaxVisibleGraphemes = -1
				v_u_73.TextTransparency = v_u_302 and 0.2 or 0.55
				v_u_74.Scale = v_u_281 * 1.02
				local v313 = v_u_74
				local v314 = {
					["Scale"] = v_u_281 * (v_u_302 and 1.32 or 1.18)
				}
				local v315 = Enum.EasingStyle.Quart
				v_u_4:Create(v313, TweenInfo.new(v_u_102 * 0.6, v315 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v314):Play()
				local v316 = v_u_73
				local v317 = Enum.EasingStyle.Quad
				v_u_4:Create(v316, TweenInfo.new(v_u_102 * 0.6, v317 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
					["TextTransparency"] = 1
				}):Play()
				local v318 = v_u_272.width * v_u_281
				if v304 == "flawless" then
					v_u_153.Pace = v_u_102
					v_u_153:Burst(v_u_302 and 28 or 12, {
						["mode"] = "box",
						["box"] = nil,
						["kind"] = "sparkle",
						["size"] = 32,
						["speed"] = 240,
						["color"] = nil,
						["white"] = nil,
						["whiteChance"] = 0.45,
						["grav"] = -60,
						["drag"] = 1.5,
						["lifeMult"] = 1.7,
						["box"] = Vector2.new(v318, 70 * v_u_281),
						["color"] = v_u_38.Lighten(v_u_274, 0.45),
						["white"] = v_u_38.Lighten(v_u_274, 0.72)
					})
				else
					local v319 = v_u_162
					local v320 = v_u_302 and (v304 == "clutch" and 50 or 44) or 14
					local v321
					if v_u_302 then
						v321 = v_u_38.Lighten(v_u_274, 0.25)
					else
						v321 = v_u_274:Lerp(v_u_41.Void, 0.3)
					end
					v319(v320, v321, v318, 80 * v_u_281, v_u_302 and 1500 or 700)
				end
				v_u_65.ImageColor3 = v_u_38.Lighten(v_u_274, 0.3)
				v_u_65.Position = UDim2.fromOffset((v304 == "flawless" or v304 == "clutch") and 0 or p303, 0)
				v_u_65.Size = UDim2.fromOffset(120, 120)
				v_u_65.ImageTransparency = v_u_302 and 0.2 or 0.55
				local v322 = v_u_65
				local v323 = {
					["Size"] = nil,
					["ImageTransparency"] = 1,
					["Size"] = UDim2.fromOffset(1500, 1500)
				}
				local v324 = Enum.EasingStyle.Quart
				v_u_4:Create(v322, TweenInfo.new(v_u_102 * 0.65, v324 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v323):Play()
				v_u_64.ImageColor3 = v_u_274
				v_u_64.Size = UDim2.fromOffset(v_u_279 * 0.45, v_u_280 * 1.6)
				v_u_64.ImageTransparency = v_u_302 and 0.3 or 0.6
				local v325 = v_u_64
				local v326 = {
					["Size"] = nil,
					["ImageTransparency"] = 1,
					["Size"] = UDim2.fromOffset(v_u_279 * 0.7, v_u_280 * 2.4)
				}
				local v327 = Enum.EasingStyle.Quad
				v_u_4:Create(v325, TweenInfo.new(v_u_102 * 0.8, v327 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v326):Play()
				if v304 == "ace" then
					local v328 = {
						["volume"] = nil,
						["pitch"] = 1.16,
						["volume"] = v_u_284
					}
					if v_u_46 then
						local v329 = v_u_46.Play
						pcall(v329, "Match/Elimination", nil, v328)
					end
					local v330 = {
						["volume"] = v_u_284
					}
					if v_u_46 then
						local v331 = v_u_46.Play
						pcall(v331, "Kill_Triple", nil, v330)
						return
					end
				elseif v304 == "teamace" then
					local v332 = {
						["volume"] = nil,
						["pitch"] = 1.2,
						["volume"] = v_u_284
					}
					if v_u_46 then
						local v333 = v_u_46.Play
						pcall(v333, "Kill_Ally", nil, v332)
					end
					local v334 = {
						["volume"] = v_u_284
					}
					if v_u_46 then
						local v335 = v_u_46.Play
						pcall(v335, "Kill_Triple", nil, v334)
						return
					end
				elseif v304 == "clutch" then
					local v336 = {
						["volume"] = v_u_284
					}
					if v_u_46 then
						local v337 = v_u_46.Play
						pcall(v337, "Match/Final_Round", nil, v336)
						return
					end
				else
					local v338 = {
						["volume"] = v_u_284
					}
					if v_u_46 then
						local v339 = v_u_46.Play
						pcall(v339, "UI/Card_Reveal", nil, v338)
					end
				end
			end
			if v_u_272.style == "stamp" then
				local v341 = v_u_272.lead
				local v342 = p_u_267
				local v343 = {}
				for v344 = math.max(v341, 1), #v_u_272.ends do
					table.insert(v343, v344)
				end
				local v345 = 0.1
				for _, v346 in { v_u_76, v_u_79, v_u_81 } do
					v346.Scale = v_u_281
				end
				for _, v347 in {
					v_u_75,
					v_u_78,
					v_u_80,
					v_u_73
				} do
					v347.MaxVisibleGraphemes = 0
				end
				v300 = v345
				v301 = v300
				local v348 = v300
				v300 = v301
				v348 = v301
				local v_u_349 = 0
				p_u_267 = v342
				for v_u_350, v_u_351 in v343 do
					local v_u_352 = v_u_272.ends[v_u_351]
					local v_u_353
					if v_u_350 == 1 then
						v_u_353 = v_u_351 > 1
					else
						v_u_353 = false
					end
					local v_u_354 = v_u_350 == #v343
					local function v385()
						-- upvalues: (copy) v_u_269, (ref) v_u_182, (ref) v_u_75, (ref) v_u_78, (ref) v_u_80, (copy) v_u_352, (copy) v_u_272, (copy) v_u_349, (copy) v_u_351, (copy) v_u_281, (copy) v_u_353, (ref) v_u_4, (ref) v_u_102, (ref) v_u_76, (ref) v_u_79, (copy) v_u_354, (copy) v_u_340, (copy) v_u_302, (ref) v_u_63, (ref) v_u_154, (ref) v_u_3, (ref) v_u_258, (ref) v_u_38, (copy) v_u_274, (ref) v_u_41, (ref) v_u_65, (copy) p_u_267, (copy) v_u_284, (copy) v_u_350, (ref) v_u_46
						if v_u_269 == v_u_182 then
							for _, v355 in { v_u_75, v_u_78, v_u_80 } do
								v355.MaxVisibleGraphemes = v_u_352
							end
							local v356 = v_u_272
							local v357 = v_u_349 + 1
							local v358 = v_u_351
							local v359 = v_u_281
							local v360 = (((v356.centres[v357] or 0) + (v356.centres[v358] or v356.width)) / 2 - v356.width / 2) * v359
							if v_u_353 then
								v_u_75.TextTransparency = 1
								v_u_78.TextTransparency = 1
								local v361 = v_u_75
								local v362 = Enum.EasingStyle.Quad
								v_u_4:Create(v361, TweenInfo.new(v_u_102 * 0.12, v362 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
									["TextTransparency"] = 0
								}):Play()
								local v363 = v_u_78
								local v364 = Enum.EasingStyle.Quad
								v_u_4:Create(v363, TweenInfo.new(v_u_102 * 0.18, v364 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
									["TextTransparency"] = 0.55
								}):Play()
								for _, v365 in { v_u_76, v_u_79 } do
									v365.Scale = v_u_281 * 1.12
									local v366 = {
										["Scale"] = v_u_281
									}
									local v367 = Enum.EasingStyle.Quint
									v_u_4:Create(v365, TweenInfo.new(v_u_102 * 0.2, v367 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v366):Play()
								end
								return
							else
								v_u_75.TextTransparency = 0
								v_u_78.TextTransparency = 0.55
								if v_u_354 then
									v_u_340(v360)
								else
									for _, v368 in { v_u_76, v_u_79 } do
										v368.Scale = v_u_281 * 1.06
										local v369 = {
											["Scale"] = v_u_281
										}
										local v370 = Enum.EasingStyle.Back
										v_u_4:Create(v368, TweenInfo.new(v_u_102 * 0.14, v370 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v369):Play()
									end
									local v_u_371 = v_u_302 and 5 or 2
									local v_u_372 = v_u_182
									local v_u_373 = 0.12
									task.spawn(function()
										-- upvalues: (copy) v_u_373, (ref) v_u_102, (copy) v_u_372, (ref) v_u_182, (ref) v_u_63, (ref) v_u_154, (copy) v_u_371, (ref) v_u_3
										local v374 = os.clock()
										while os.clock() - v374 < v_u_373 * v_u_102 and v_u_372 == v_u_182 do
											local v375 = 1 - (os.clock() - v374) / (v_u_373 * v_u_102)
											v_u_63.Position = UDim2.fromOffset(v_u_154:NextNumber(-1, 1) * v_u_371 * v375, v_u_154:NextNumber(-1, 1) * v_u_371 * v375)
											v_u_3.RenderStepped:Wait()
										end
										v_u_63.Position = UDim2.new()
									end)
									local v376 = v_u_258
									local v377 = v_u_302 and 12 or 5
									local v378
									if v_u_302 then
										v378 = v_u_38.Lighten(v_u_274, 0.3)
									else
										v378 = v_u_274:Lerp(v_u_41.Void, 0.3)
									end
									v376(v377, v378, v360, 0, v_u_302 and 950 or 500, {
										["jitter"] = 34 * v_u_281,
										["white"] = v_u_38.Lighten(v_u_274, 0.7)
									})
									v_u_65.ImageColor3 = v_u_38.Lighten(v_u_274, 0.35)
									v_u_65.Position = UDim2.fromOffset(v360, 0)
									v_u_65.Size = UDim2.fromOffset(60, 60)
									v_u_65.ImageTransparency = v_u_302 and 0.3 or 0.6
									local v379 = v_u_65
									local v380 = {
										["Size"] = nil,
										["ImageTransparency"] = 1,
										["Size"] = UDim2.fromOffset(380, 380)
									}
									local v381 = Enum.EasingStyle.Quart
									v_u_4:Create(v379, TweenInfo.new(v_u_102 * 0.32, v381 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v380):Play()
									local v382 = p_u_267.kind == "teamace" and "Kill_Ally" or "Match/Elimination"
									local v383 = {
										["volume"] = v_u_284 * 0.9,
										["pitch"] = 0.9 + 0.08 * v_u_350
									}
									if v_u_46 then
										local v384 = v_u_46.Play
										pcall(v384, v382, nil, v383)
									end
								end
							end
						else
							return
						end
					end
					task.delay(v345 * v_u_102, v385)
					local v386 = v345 + (v_u_353 and 0.2 or 0.15)
					v300 = v345
					v345 = v386
					v342 = p_u_267
					v_u_349 = v_u_351
					p_u_267 = v342
				end
			elseif v_u_272.style == "hold" then
				local v387 = v_u_281 * 1.45
				v301 = 0.02
				for _, v388 in { v_u_76, v_u_79, v_u_81 } do
					v388.Scale = v_u_281 * 2.1
					local v389 = Enum.EasingStyle.Quad
					local v390 = Enum.EasingDirection.Out
					v_u_4:Create(v388, TweenInfo.new(v_u_102 * 0.34, v389 or Enum.EasingStyle.Quint, v390 or Enum.EasingDirection.Out, 0, false, (v301 or 0) * v_u_102), {
						["Scale"] = v387
					}):Play()
				end
				local v391 = v_u_75
				local v392 = Enum.EasingStyle.Quad
				local v393 = Enum.EasingDirection.Out
				v_u_4:Create(v391, TweenInfo.new(v_u_102 * 0.3, v392 or Enum.EasingStyle.Quint, v393 or Enum.EasingDirection.Out, 0, false, (v301 or 0) * v_u_102), {
					["TextTransparency"] = 0.62
				}):Play()
				v_u_58.BackgroundTransparency = 1
				local v394 = v_u_58
				local v395 = Enum.EasingStyle.Quad
				v_u_4:Create(v394, TweenInfo.new(v_u_102 * 0.3, v395 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
					["BackgroundTransparency"] = v_u_302 and 0.72 or 0.8
				}):Play()
				local v396 = {
					["volume"] = v_u_284
				}
				if v_u_46 then
					local v397 = v_u_46.Play
					pcall(v397, "Match/Final_Heartbeat", nil, v396)
				end
				for _, v_u_398 in {
					{ 0.04, 0.02 },
					{ 0.26, 0.08 }
				} do
					local v399 = v_u_398[1]
					local function v403()
						-- upvalues: (copy) v_u_269, (ref) v_u_182, (ref) v_u_60, (copy) v_u_398, (copy) v_u_287, (ref) v_u_4, (ref) v_u_102
						if v_u_269 == v_u_182 then
							v_u_60.ImageTransparency = v_u_398[2]
							local v400 = v_u_60
							local v401 = {
								["ImageTransparency"] = v_u_287
							}
							local v402 = Enum.EasingStyle.Quad
							v_u_4:Create(v400, TweenInfo.new(v_u_102 * 0.18, v402 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v401):Play()
						end
					end
					task.delay(v399 * v_u_102, v403)
				end
				local function v414()
					-- upvalues: (copy) v_u_269, (ref) v_u_182, (ref) v_u_76, (ref) v_u_79, (ref) v_u_81, (copy) v_u_281, (ref) v_u_4, (ref) v_u_102, (ref) v_u_75, (ref) v_u_78
					if v_u_269 == v_u_182 then
						for _, v404 in { v_u_76, v_u_79, v_u_81 } do
							local v405 = {
								["Scale"] = v_u_281
							}
							local v406 = Enum.EasingStyle.Quint
							local v407 = Enum.EasingDirection.In
							v_u_4:Create(v404, TweenInfo.new(v_u_102 * 0.12, v406 or Enum.EasingStyle.Quint, v407 or Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v405):Play()
						end
						local v408 = v_u_75
						local v409 = Enum.EasingStyle.Quad
						local v410 = Enum.EasingDirection.In
						v_u_4:Create(v408, TweenInfo.new(v_u_102 * 0.1, v409 or Enum.EasingStyle.Quint, v410 or Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
							["TextTransparency"] = 0
						}):Play()
						local v411 = v_u_78
						local v412 = Enum.EasingStyle.Quad
						local v413 = Enum.EasingDirection.In
						v_u_4:Create(v411, TweenInfo.new(v_u_102 * 0.12, v412 or Enum.EasingStyle.Quint, v413 or Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
							["TextTransparency"] = 0.55
						}):Play()
					end
				end
				task.delay(v_u_102 * 0.42, v414)
				v300 = 0.54
				local function v417()
					-- upvalues: (copy) v_u_269, (ref) v_u_182, (ref) v_u_58, (ref) v_u_4, (ref) v_u_102, (copy) v_u_340
					if v_u_269 == v_u_182 then
						local v415 = v_u_58
						local v416 = Enum.EasingStyle.Quad
						v_u_4:Create(v415, TweenInfo.new(v_u_102 * 0.35, v416 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
							["BackgroundTransparency"] = 1
						}):Play()
						v_u_340(0)
					end
				end
				task.delay(v300 * v_u_102, v417)
			else
				v301 = 0.08
				for _, v418 in { v_u_76, v_u_79, v_u_81 } do
					v418.Scale = v_u_281 * 1.28
					local v419 = Enum.EasingStyle.Quint
					local v420 = Enum.EasingDirection.Out
					v_u_4:Create(v418, TweenInfo.new(v_u_102 * 0.42, v419 or Enum.EasingStyle.Quint, v420 or Enum.EasingDirection.Out, 0, false, (v301 or 0) * v_u_102), {
						["Scale"] = v_u_281
					}):Play()
				end
				local v421 = v_u_75
				local v422 = Enum.EasingStyle.Quad
				local v423 = Enum.EasingDirection.Out
				v_u_4:Create(v421, TweenInfo.new(v_u_102 * 0.22, v422 or Enum.EasingStyle.Quint, v423 or Enum.EasingDirection.Out, 0, false, (v301 or 0) * v_u_102), {
					["TextTransparency"] = 0
				}):Play()
				local v424 = v_u_78
				local v425 = Enum.EasingStyle.Quad
				local v426 = Enum.EasingDirection.Out
				v_u_4:Create(v424, TweenInfo.new(v_u_102 * 0.3, v425 or Enum.EasingStyle.Quint, v426 or Enum.EasingDirection.Out, 0, false, (v301 or 0) * v_u_102), {
					["TextTransparency"] = 0.55
				}):Play()
				v300 = v301 + 0.24
				local function v434()
					-- upvalues: (copy) v_u_269, (ref) v_u_182, (copy) v_u_340, (ref) v_u_109, (ref) v_u_38, (copy) v_u_274, (copy) v_u_279, (copy) v_u_280, (copy) v_u_302, (ref) v_u_4, (ref) v_u_102
					if v_u_269 == v_u_182 then
						v_u_340(0)
						v_u_109.ImageColor3 = v_u_38.Lighten(v_u_274, 0.55)
						v_u_109.Position = UDim2.fromOffset(-v_u_279 * 0.32, -v_u_280 / 2 + 4)
						v_u_109.ImageTransparency = v_u_302 and 0.25 or 0.6
						local v427 = v_u_109
						local v428 = {
							["Position"] = UDim2.fromOffset(v_u_279 * 0.32, -v_u_280 / 2 + 4)
						}
						local v429 = Enum.EasingStyle.Quad
						local v430 = Enum.EasingDirection.InOut
						v_u_4:Create(v427, TweenInfo.new(v_u_102 * 0.75, v429 or Enum.EasingStyle.Quint, v430 or Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v428):Play()
						local v431 = v_u_109
						local v432 = Enum.EasingStyle.Quad
						local v433 = Enum.EasingDirection.In
						v_u_4:Create(v431, TweenInfo.new(v_u_102 * 0.3, v432 or Enum.EasingStyle.Quint, v433 or Enum.EasingDirection.Out, 0, false, 0.5 * v_u_102), {
							["ImageTransparency"] = 1
						}):Play()
					end
				end
				task.delay(v300 * v_u_102, v434)
			end
		else
			local v435 = v_u_271 and 1.12 or 1.75
			v_u_76.Scale = v_u_281 * v435
			v_u_79.Scale = v_u_281 * v435
			v_u_81.Scale = v_u_281 * v435
			local v436 = v_u_271 and 0.5 or 0.26
			local v437
			if v_u_271 then
				v437 = Enum.EasingStyle.Quint
			else
				v437 = Enum.EasingStyle.Back
			end
			v301 = v_u_271 and 0.1 or 0.08
			for _, v438 in { v_u_76, v_u_79, v_u_81 } do
				v_u_56(v438, v436, {
					["Scale"] = v_u_281
				}, v437, Enum.EasingDirection.Out, v301)
			end
			local v439 = v_u_75
			local v440 = Enum.EasingStyle.Quad
			local v441 = Enum.EasingDirection.Out
			v_u_4:Create(v439, TweenInfo.new(v_u_102 * 0.12, v440 or Enum.EasingStyle.Quint, v441 or Enum.EasingDirection.Out, 0, false, (v301 or 0) * v_u_102), {
				["TextTransparency"] = 0
			}):Play()
			local v442 = v_u_78
			local v443 = Enum.EasingStyle.Quad
			local v444 = Enum.EasingDirection.Out
			v_u_4:Create(v442, TweenInfo.new(v_u_102 * 0.2, v443 or Enum.EasingStyle.Quint, v444 or Enum.EasingDirection.Out, 0, false, (v301 or 0) * v_u_102), {
				["TextTransparency"] = 0.55
			}):Play()
			v300 = v301 + (v_u_271 and 0.3 or 0.2)
			local function v467()
				-- upvalues: (copy) v_u_269, (ref) v_u_182, (copy) v_u_271, (ref) v_u_76, (ref) v_u_79, (ref) v_u_81, (copy) v_u_281, (ref) v_u_4, (ref) v_u_102, (copy) p_u_260, (ref) v_u_63, (ref) v_u_154, (ref) v_u_3, (ref) v_u_73, (ref) v_u_74, (copy) v_u_282, (ref) v_u_162, (ref) v_u_38, (copy) v_u_274, (ref) v_u_65, (ref) v_u_64, (copy) v_u_279, (copy) v_u_280, (ref) v_u_41
				if v_u_269 == v_u_182 then
					if v_u_271 then
						v_u_64.ImageColor3 = v_u_274:Lerp(v_u_41.Void, 0.4)
						v_u_64.Size = UDim2.fromOffset(v_u_279 * 0.5, v_u_280 * 1.8)
						v_u_64.ImageTransparency = 0.6
						local v445 = v_u_64
						local v446 = Enum.EasingStyle.Quad
						v_u_4:Create(v445, TweenInfo.new(v_u_102 * 1.2, v446 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
							["ImageTransparency"] = 1
						}):Play()
						if p_u_260 then
							v_u_162(10, v_u_274:Lerp(v_u_41.Void, 0.3), 700, 80, 260, {
								["sparkChance"] = 0,
								["grav"] = 520,
								["drag"] = 1.2,
								["base"] = 0.35,
								["lifeMult"] = 1.6
							})
						end
					else
						for _, v447 in { v_u_76, v_u_79, v_u_81 } do
							v447.Scale = v_u_281 * 1.07
							local v448 = {
								["Scale"] = v_u_281
							}
							local v449 = Enum.EasingStyle.Back
							v_u_4:Create(v447, TweenInfo.new(v_u_102 * 0.22, v449 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v448):Play()
						end
						local v_u_450 = p_u_260 and 9 or 6
						local v_u_451 = v_u_182
						local v_u_452 = 0.22
						task.spawn(function()
							-- upvalues: (copy) v_u_452, (ref) v_u_102, (copy) v_u_451, (ref) v_u_182, (ref) v_u_63, (ref) v_u_154, (copy) v_u_450, (ref) v_u_3
							local v453 = os.clock()
							while os.clock() - v453 < v_u_452 * v_u_102 and v_u_451 == v_u_182 do
								local v454 = 1 - (os.clock() - v453) / (v_u_452 * v_u_102)
								v_u_63.Position = UDim2.fromOffset(v_u_154:NextNumber(-1, 1) * v_u_450 * v454, v_u_154:NextNumber(-1, 1) * v_u_450 * v454)
								v_u_3.RenderStepped:Wait()
							end
							v_u_63.Position = UDim2.new()
						end)
						v_u_73.TextTransparency = 0.25
						v_u_74.Scale = v_u_281 * 1.02
						local v455 = v_u_74
						local v456 = {
							["Scale"] = v_u_281 * 1.28
						}
						local v457 = Enum.EasingStyle.Quart
						v_u_4:Create(v455, TweenInfo.new(v_u_102 * 0.55, v457 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v456):Play()
						local v458 = v_u_73
						local v459 = Enum.EasingStyle.Quad
						v_u_4:Create(v458, TweenInfo.new(v_u_102 * 0.55, v459 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
							["TextTransparency"] = 1
						}):Play()
						local v460 = #v_u_282 * 43 * v_u_281
						v_u_162(p_u_260 and 48 or 34, v_u_38.Lighten(v_u_274, 0.25), v460, 80 * v_u_281, p_u_260 and 1400 or 1150)
						v_u_65.ImageColor3 = v_u_38.Lighten(v_u_274, 0.3)
						v_u_65.Size = UDim2.fromOffset(120, 120)
						v_u_65.ImageTransparency = 0.25
						local v461 = v_u_65
						local v462 = {
							["Size"] = nil,
							["ImageTransparency"] = 1,
							["Size"] = UDim2.fromOffset(p_u_260 and 1700 or 1200, p_u_260 and 1700 or 1200)
						}
						local v463 = Enum.EasingStyle.Quart
						v_u_4:Create(v461, TweenInfo.new(v_u_102 * 0.6, v463 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v462):Play()
						v_u_64.ImageColor3 = v_u_274
						v_u_64.Size = UDim2.fromOffset(v_u_279 * 0.45, v_u_280 * 1.6)
						v_u_64.ImageTransparency = 0.35
						local v464 = v_u_64
						local v465 = {
							["Size"] = nil,
							["ImageTransparency"] = 1,
							["Size"] = UDim2.fromOffset(v_u_279 * 0.7, v_u_280 * 2.4)
						}
						local v466 = Enum.EasingStyle.Quad
						v_u_4:Create(v464, TweenInfo.new(v_u_102 * 0.7, v466 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v465):Play()
					end
				else
					return
				end
			end
			task.delay(v300 * v_u_102, v467)
		end
		local v468
		if v_u_272 then
			v468 = v300 + 0.08
		else
			v468 = v301 + (v_u_271 and 0.55 or 0.34)
		end
		local v_u_469 = v283 == "shine" and 0.85 or (v_u_271 and 0.9 or 0.55)
		local function v477()
			-- upvalues: (copy) v_u_269, (ref) v_u_182, (ref) v_u_80, (copy) v_u_271, (ref) v_u_82, (copy) v_u_469, (ref) v_u_4, (ref) v_u_102
			if v_u_269 == v_u_182 then
				v_u_80.MaxVisibleGraphemes = -1
				v_u_80.TextTransparency = v_u_271 and 0.55 or 0
				v_u_82.Offset = Vector2.new(-1, 0)
				local v470 = v_u_82
				local v471 = v_u_469
				local v472 = {
					["Offset"] = Vector2.new(1, 0)
				}
				local v473 = Enum.EasingStyle.Quad
				local v474 = Enum.EasingDirection.InOut
				v_u_4:Create(v470, TweenInfo.new(v471 * v_u_102, v473 or Enum.EasingStyle.Quint, v474 or Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v472):Play()
				local v475 = v_u_469 + 0.05
				local function v476()
					-- upvalues: (ref) v_u_269, (ref) v_u_182, (ref) v_u_80
					if v_u_269 == v_u_182 then
						v_u_80.TextTransparency = 1
					end
				end
				task.delay(v475 * v_u_102, v476)
			end
		end
		task.delay(v468 * v_u_102, v477)
		local v478 = -v_u_280 / 2 - 8
		local v479 = v_u_83
		local v480
		if p_u_260 then
			v480 = v270 and "MATCH WON" or (v_u_271 and "MATCH LOST" or "MATCH DRAWN")
		elseif v_u_272 then
			v480 = v270 and "ROUND WON" or "ROUND LOST"
		else
			v480 = string.format("ROUND %d", p265 or 1)
		end
		v479.Text = v480
		local v481 = v_u_83
		local v482
		if v270 then
			v482 = v_u_38.Lighten(v_u_274, 0.45)
		else
			v482 = v_u_41.TextDim
		end
		v481.TextColor3 = v482
		v_u_83.Position = UDim2.fromOffset(0, v478 + 14)
		v_u_83.TextTransparency = 1
		local v483 = v_u_83
		local v484
		if v_u_273 == nil then
			v484 = p_u_260 or not v276
		else
			v484 = false
		end
		v483.Visible = v484
		local v485 = v_u_83
		local v486 = {
			["Position"] = nil,
			["TextTransparency"] = 0,
			["Position"] = UDim2.fromOffset(0, v478)
		}
		local v487 = Enum.EasingStyle.Quint
		local v488 = Enum.EasingDirection.Out
		local v489 = v301 + 0.3
		v_u_4:Create(v485, TweenInfo.new(v_u_102 * 0.3, v487 or Enum.EasingStyle.Quint, v488 or Enum.EasingDirection.Out, 0, false, (v489 or 0) * v_u_102), v486):Play()
		v_u_84.Transparency = 1
		local v490 = v_u_84
		local v491 = Enum.EasingStyle.Quint
		local v492 = Enum.EasingDirection.Out
		local v493 = v301 + 0.3
		v_u_4:Create(v490, TweenInfo.new(v_u_102 * 0.3, v491 or Enum.EasingStyle.Quint, v492 or Enum.EasingDirection.Out, 0, false, (v493 or 0) * v_u_102), {
			["Transparency"] = 0.5
		}):Play()
		local v494 = v_u_280 / 2 + (v276 and 8 or 10)
		local v_u_495
		if v_u_272 and p_u_267 then
			local v496 = v300 + 0.12
			local v497 = v_u_272.named
			local v498
			if v497 then
				v498 = {}
				local v499
				if p_u_267.id then
					v499 = v_u_39.FindMember(p_u_267.id)
				else
					v499 = nil
				end
				__set_list(v498, 1, {v499 or {
	["id"] = nil,
	["name"] = nil,
	["userId"] = false,
	["id"] = p_u_267.id or "",
	["name"] = p_u_267.name or ""
}})
			else
				local v500 = p_u_267.team
				local v501 = v_u_39.Match
				local v502 = v501 and v501.teams
				if v502 then
					v502 = v501.teams[v500]
				end
				v498 = v502 and v502.members or {}
			end
			v_u_495 = p_u_267
			for v503, v504 in v_u_121 do
				local v505 = v498[v503]
				v504.holder.Visible = v505 ~= nil
				v504.scale.Scale = 0
				if not v505 then
					continue
				end
				local v506 = v504.stroke
				local v507
				if v_u_271 then
					v507 = v_u_274:Lerp(v_u_41.Void, 0.2)
				else
					v507 = v_u_274
				end
				v506.Color = v507
				local v508 = v496 + (v503 - 1) * 0.06
				local v509 = v504.scale
				local v510 = Enum.EasingStyle.Back
				local v511 = Enum.EasingDirection.Out
				v_u_4:Create(v509, TweenInfo.new(v_u_102 * 0.4, v510 or Enum.EasingStyle.Quint, v511 or Enum.EasingDirection.Out, 0, false, (v508 or 0) * v_u_102), {
					["Scale"] = 1
				}):Play()
				local v512 = v_u_250
				local v513 = v504.img
				local v514
				if v_u_271 then
					v514 = Color3.fromRGB(200, 200, 200)
				else
					v514 = Color3.new(1, 1, 1)
				end
				v512(v513, v505, v514, v508 + 0.42, v_u_269)
			end
			v_u_134.Visible = v497
			local v515 = v_u_134
			local v516 = not v497 or p_u_267.name
			if not v516 then
				local v517 = v498[1] and v498[1].name or ""
				v516 = tostring(v517)
			end
			v515.Text = v516
			v_u_134.TextTransparency = 1
			v_u_135.Transparency = 1
			local v518 = v_u_134
			local v519 = Enum.EasingStyle.Quad
			local v520 = Enum.EasingDirection.Out
			local v521 = v496 + 0.06
			v_u_4:Create(v518, TweenInfo.new(v_u_102 * 0.3, v519 or Enum.EasingStyle.Quint, v520 or Enum.EasingDirection.Out, 0, false, (v521 or 0) * v_u_102), {
				["TextTransparency"] = 0
			}):Play()
			local v522 = v_u_135
			local v523 = Enum.EasingStyle.Quad
			local v524 = Enum.EasingDirection.Out
			local v525 = v496 + 0.06
			v_u_4:Create(v522, TweenInfo.new(v_u_102 * 0.3, v523 or Enum.EasingStyle.Quint, v524 or Enum.EasingDirection.Out, 0, false, (v525 or 0) * v_u_102), {
				["Transparency"] = 0.35
			}):Play()
			local v526 = v_u_136
			local v527
			if p_u_267.kind == "clutch" then
				v527 = p_u_267.vs >= 2
			else
				v527 = false
			end
			v526.Visible = v527
			local v528 = v_u_137
			local v529 = p_u_267.vs
			v528.Text = "1v" .. tostring(v529)
			v_u_136.BackgroundColor3 = v_u_274:Lerp(v_u_41.Void, v_u_271 and 0.45 or 0.15)
			v_u_136.BackgroundTransparency = 1
			v_u_137.TextTransparency = 1
			v_u_138.Scale = 0.6
			local v530 = v_u_136
			local v531 = Enum.EasingStyle.Quad
			local v532 = Enum.EasingDirection.Out
			local v533 = v496 + 0.18
			v_u_4:Create(v530, TweenInfo.new(v_u_102 * 0.22, v531 or Enum.EasingStyle.Quint, v532 or Enum.EasingDirection.Out, 0, false, (v533 or 0) * v_u_102), {
				["BackgroundTransparency"] = 0.05
			}):Play()
			local v534 = v_u_137
			local v535 = Enum.EasingStyle.Quad
			local v536 = Enum.EasingDirection.Out
			local v537 = v496 + 0.18
			v_u_4:Create(v534, TweenInfo.new(v_u_102 * 0.22, v535 or Enum.EasingStyle.Quint, v536 or Enum.EasingDirection.Out, 0, false, (v537 or 0) * v_u_102), {
				["TextTransparency"] = 0
			}):Play()
			local v538 = v_u_138
			local v539 = Enum.EasingStyle.Back
			local v540 = Enum.EasingDirection.Out
			local v541 = v496 + 0.18
			v_u_4:Create(v538, TweenInfo.new(v_u_102 * 0.35, v539 or Enum.EasingStyle.Quint, v540 or Enum.EasingDirection.Out, 0, false, (v541 or 0) * v_u_102), {
				["Scale"] = 1
			}):Play()
			v_u_111.PaddingRight = UDim.new(0, v497 and 24 or 6)
			v_u_111.PaddingLeft = UDim.new(0, 6)
			v_u_110.BackgroundTransparency = 1
			v_u_112.Color = v_u_274
			v_u_112.Transparency = 1
			local v542 = v_u_110
			local v543 = Enum.EasingStyle.Quad
			local v544 = Enum.EasingDirection.Out
			v_u_4:Create(v542, TweenInfo.new(v_u_102 * 0.3, v543 or Enum.EasingStyle.Quint, v544 or Enum.EasingDirection.Out, 0, false, (v496 or 0) * v_u_102), {
				["BackgroundTransparency"] = v_u_271 and 0.3 or 0.35
			}):Play()
			local v545 = v_u_112
			local v546 = Enum.EasingStyle.Quad
			local v547 = Enum.EasingDirection.Out
			v_u_4:Create(v545, TweenInfo.new(v_u_102 * 0.3, v546 or Enum.EasingStyle.Quint, v547 or Enum.EasingDirection.Out, 0, false, (v496 or 0) * v_u_102), {
				["Transparency"] = v_u_271 and 0.75 or 0.55
			}):Play()
			v_u_110.Position = UDim2.fromOffset(0, v494 + 14)
			v_u_110.Visible = true
			local v548 = v_u_110
			local v549 = {
				["Position"] = UDim2.fromOffset(0, v494)
			}
			local v550 = Enum.EasingStyle.Quint
			local v551 = Enum.EasingDirection.Out
			v_u_4:Create(v548, TweenInfo.new(v_u_102 * 0.4, v550 or Enum.EasingStyle.Quint, v551 or Enum.EasingDirection.Out, 0, false, (v496 or 0) * v_u_102), v549):Play()
		else
			v_u_495 = p_u_267
		end
		v_u_85.Visible = not (v_u_272 and v276)
		local v552
		if v_u_272 then
			v552 = v494 + 60 + 8
		else
			v552 = v_u_280 / 2 + (v276 and not p_u_260 and 0 or 6)
		end
		local v553
		if v_u_272 then
			v553 = v300 + 0.24
		else
			v553 = v301 + 0.38
		end
		v_u_86.Scale = p_u_260 and 1.3 or 1
		v_u_85.Position = UDim2.fromOffset(0, v552 + 16)
		local v554 = v_u_93
		local v555 = v_u_94
		local v556 = v_u_41.Ally
		v554.Text = tostring(p_u_263)
		v554.Position = UDim2.new()
		v554.TextColor3 = v556
		v554.TextTransparency = 0
		v555.Visible = false
		local v557 = v_u_97
		local v558 = v_u_98
		local v559 = v_u_41.Enemy
		v557.Text = tostring(p_u_264)
		v557.Position = UDim2.new()
		v557.TextColor3 = v559
		v557.TextTransparency = 0
		v558.Visible = false
		for _, v560 in { v_u_93, v_u_97 } do
			v560.TextTransparency = 1
			local v561 = Enum.EasingStyle.Quad
			local v562 = Enum.EasingDirection.Out
			v_u_4:Create(v560, TweenInfo.new(v_u_102 * 0.3, v561 or Enum.EasingStyle.Quint, v562 or Enum.EasingDirection.Out, 0, false, (v553 or 0) * v_u_102), {
				["TextTransparency"] = 0
			}):Play()
		end
		v_u_100.BackgroundTransparency = 1
		local v563 = v_u_100
		local v564 = Enum.EasingStyle.Quad
		local v565 = Enum.EasingDirection.Out
		v_u_4:Create(v563, TweenInfo.new(v_u_102 * 0.3, v564 or Enum.EasingStyle.Quint, v565 or Enum.EasingDirection.Out, 0, false, (v553 or 0) * v_u_102), {
			["BackgroundTransparency"] = 0.2
		}):Play()
		local v566 = v_u_85
		local v567 = {
			["Position"] = UDim2.fromOffset(0, v552)
		}
		local v568 = Enum.EasingStyle.Quint
		local v569 = Enum.EasingDirection.Out
		v_u_4:Create(v566, TweenInfo.new(v_u_102 * 0.34, v568 or Enum.EasingStyle.Quint, v569 or Enum.EasingDirection.Out, 0, false, (v553 or 0) * v_u_102), v567):Play()
		local v570 = v553 + 0.24
		local function v571()
			-- upvalues: (copy) v_u_269, (ref) v_u_182, (copy) p_u_261, (copy) p_u_263, (ref) v_u_200, (ref) v_u_92, (ref) v_u_93, (ref) v_u_94, (ref) v_u_95, (ref) v_u_41, (copy) p_u_262, (copy) p_u_264, (ref) v_u_96, (ref) v_u_97, (ref) v_u_98, (ref) v_u_99
			if v_u_269 == v_u_182 then
				if p_u_261 ~= p_u_263 then
					v_u_200(v_u_92, v_u_93, v_u_94, v_u_95, p_u_261, v_u_41.Ally)
				end
				if p_u_262 ~= p_u_264 then
					v_u_200(v_u_96, v_u_97, v_u_98, v_u_99, p_u_262, v_u_41.Enemy)
				end
			end
		end
		task.delay(v570 * v_u_102, v571)
		v_u_101.Visible = p_u_260
		if p_u_260 then
			v_u_101.Position = UDim2.fromOffset(0, v552 + 116)
			local v572 = v_u_39.Match
			local v573 = v572 and v572.teams
			if v573 then
				v573 = v572.teams[v_u_39.MyTeam()]
			end
			local v574 = v573 and v573.members or {}
			for v575, v576 in v_u_103 do
				local v577 = v574[v575]
				v576.frame.Visible = v577 ~= nil
				if not v577 then
					continue
				end
				local v578 = v576.name
				local v579 = v577.name or "?"
				v578.Text = tostring(v579)
				local v580 = v576.name
				local v581
				if v577.id == v_u_39.MyId() then
					v581 = v_u_38.Lighten(v_u_41.Accent, 0.2)
				else
					v581 = v_u_41.Text
				end
				v580.TextColor3 = v581
				local v582 = v576.stroke
				local v583
				if v_u_271 then
					v583 = v_u_41.TextMuted
				else
					v583 = v_u_274
				end
				v582.Color = v583
				local v584 = v576.star
				local v585
				if p266 == nil or v577.id ~= p266 then
					v585 = false
				else
					v585 = not v_u_271
				end
				v584.Visible = v585
				local v586 = UDim2.new(0.5, (v575 - 2) * 150, 0, 0)
				v576.frame.Position = v586 + UDim2.fromOffset(0, 60)
				v_u_37.GetScaleObj(v576.frame).Scale = 0
				local v587 = v576.frame
				local v588 = Enum.EasingStyle.Back
				local v589 = Enum.EasingDirection.Out
				local v590 = v301 + 0.75 + v575 * 0.09
				v_u_4:Create(v587, TweenInfo.new(v_u_102 * 0.5, v588 or Enum.EasingStyle.Quint, v589 or Enum.EasingDirection.Out, 0, false, (v590 or 0) * v_u_102), {
					["Position"] = v586
				}):Play()
				local v591 = v_u_37.GetScaleObj(v576.frame)
				local v592 = Enum.EasingStyle.Back
				local v593 = Enum.EasingDirection.Out
				local v594 = v301 + 0.75 + v575 * 0.09
				v_u_4:Create(v591, TweenInfo.new(v_u_102 * 0.5, v592 or Enum.EasingStyle.Quint, v593 or Enum.EasingDirection.Out, 0, false, (v594 or 0) * v_u_102), {
					["Scale"] = 1
				}):Play()
				local v595 = v_u_250
				local v596 = v576.img
				local v597
				if v_u_271 then
					v597 = Color3.fromRGB(170, 170, 170)
				else
					v597 = Color3.new(1, 1, 1)
				end
				v595(v596, v577, v597, v301 + 0.75 + v575 * 0.09 + 0.52, v_u_269)
			end
			if v270 then
				local function v598()
					-- upvalues: (copy) v_u_269, (ref) v_u_182, (ref) v_u_162, (ref) v_u_41
					if v_u_269 == v_u_182 then
						v_u_162(22, v_u_41.Gold, 900, 120, 700, {
							["sparkChance"] = 0.3,
							["grav"] = 620,
							["drag"] = 1.6,
							["lifeMult"] = 1.5
						})
					end
				end
				task.delay(v_u_102 * 1.05, v598)
			end
		end
		if v_u_273 and v_u_495 then
			local v_u_599 = -v_u_280 / 2 - 6
			v_u_142.Text = v_u_273.text
			v_u_143.Color = ColorSequence.new(v_u_41.Text, v_u_38.Lighten(v_u_274, v270 and 0.5 or 0.7))
			v_u_142.TextTransparency = 1
			v_u_144.Transparency = 1
			local v600 = v_u_142
			local v601 = Enum.EasingStyle.Quad
			local v602 = Enum.EasingDirection.Out
			v_u_4:Create(v600, TweenInfo.new(v_u_102 * 0.25, v601 or Enum.EasingStyle.Quint, v602 or Enum.EasingDirection.Out, 0, false, 0.7 * v_u_102), {
				["TextTransparency"] = 0
			}):Play()
			local v603 = v_u_144
			local v604 = Enum.EasingStyle.Quad
			local v605 = Enum.EasingDirection.Out
			v_u_4:Create(v603, TweenInfo.new(v_u_102 * 0.25, v604 or Enum.EasingStyle.Quint, v605 or Enum.EasingDirection.Out, 0, false, 0.7 * v_u_102), {
				["Transparency"] = 0.4
			}):Play()
			local v_u_606 = v_u_273.named
			v_u_145.Visible = v_u_606
			v_u_146.holder.Visible = v_u_606
			v_u_147.Visible = v_u_606
			local v607 = v_u_149
			local v608
			if v_u_606 then
				if v_u_495.kind == "clutch" then
					v608 = v_u_495.vs >= 2
				else
					v608 = false
				end
			else
				v608 = v_u_606
			end
			v607.Visible = v608
			if v_u_606 then
				v_u_145.BackgroundColor3 = v_u_274
				v_u_145.BackgroundTransparency = 1
				local v609 = v_u_145
				local v610 = Enum.EasingStyle.Quad
				local v611 = Enum.EasingDirection.Out
				v_u_4:Create(v609, TweenInfo.new(v_u_102 * 0.25, v610 or Enum.EasingStyle.Quint, v611 or Enum.EasingDirection.Out, 0, false, 0.7799999999999999 * v_u_102), {
					["BackgroundTransparency"] = 0.15
				}):Play()
				local v612
				if v_u_495.id then
					v612 = v_u_39.FindMember(v_u_495.id)
				else
					v612 = nil
				end
				local v613 = v612 or {
					["id"] = nil,
					["name"] = nil,
					["userId"] = false,
					["id"] = v_u_495.id or "",
					["name"] = v_u_495.name or ""
				}
				local v614 = v_u_146.stroke
				local v615
				if v_u_271 then
					v615 = v_u_274:Lerp(v_u_41.Void, 0.2)
				else
					v615 = v_u_274
				end
				v614.Color = v615
				v_u_146.scale.Scale = 0
				local v616 = v_u_146.scale
				local v617 = Enum.EasingStyle.Back
				local v618 = Enum.EasingDirection.Out
				v_u_4:Create(v616, TweenInfo.new(v_u_102 * 0.4, v617 or Enum.EasingStyle.Quint, v618 or Enum.EasingDirection.Out, 0, false, 0.7999999999999999 * v_u_102), {
					["Scale"] = 1
				}):Play()
				local v619 = v_u_250
				local v620 = v_u_146.img
				local v621
				if v_u_271 then
					v621 = Color3.fromRGB(200, 200, 200)
				else
					v621 = Color3.new(1, 1, 1)
				end
				v619(v620, v613, v621, 1.22, v_u_269)
				local v622 = v_u_147
				local v623 = v_u_495.name
				if not v623 then
					local v624 = v613.name or ""
					v623 = tostring(v624)
				end
				v622.Text = v623
				v_u_147.TextTransparency = 1
				v_u_148.Transparency = 1
				local v625 = v_u_147
				local v626 = Enum.EasingStyle.Quad
				local v627 = Enum.EasingDirection.Out
				v_u_4:Create(v625, TweenInfo.new(v_u_102 * 0.3, v626 or Enum.EasingStyle.Quint, v627 or Enum.EasingDirection.Out, 0, false, 0.84 * v_u_102), {
					["TextTransparency"] = 0
				}):Play()
				local v628 = v_u_148
				local v629 = Enum.EasingStyle.Quad
				local v630 = Enum.EasingDirection.Out
				v_u_4:Create(v628, TweenInfo.new(v_u_102 * 0.3, v629 or Enum.EasingStyle.Quint, v630 or Enum.EasingDirection.Out, 0, false, 0.84 * v_u_102), {
					["Transparency"] = 0.35
				}):Play()
				local v631 = v_u_150
				local v632 = v_u_495.vs
				v631.Text = "1v" .. tostring(v632)
				v_u_149.BackgroundColor3 = v_u_274:Lerp(v_u_41.Void, v_u_271 and 0.45 or 0.15)
				v_u_149.BackgroundTransparency = 1
				v_u_150.TextTransparency = 1
				v_u_151.Scale = 0.6
				local v633 = v_u_149
				local v634 = Enum.EasingStyle.Quad
				local v635 = Enum.EasingDirection.Out
				v_u_4:Create(v633, TweenInfo.new(v_u_102 * 0.22, v634 or Enum.EasingStyle.Quint, v635 or Enum.EasingDirection.Out, 0, false, 0.8999999999999999 * v_u_102), {
					["BackgroundTransparency"] = 0.05
				}):Play()
				local v636 = v_u_150
				local v637 = Enum.EasingStyle.Quad
				local v638 = Enum.EasingDirection.Out
				v_u_4:Create(v636, TweenInfo.new(v_u_102 * 0.22, v637 or Enum.EasingStyle.Quint, v638 or Enum.EasingDirection.Out, 0, false, 0.8999999999999999 * v_u_102), {
					["TextTransparency"] = 0
				}):Play()
				local v639 = v_u_151
				local v640 = Enum.EasingStyle.Back
				local v641 = Enum.EasingDirection.Out
				v_u_4:Create(v639, TweenInfo.new(v_u_102 * 0.35, v640 or Enum.EasingStyle.Quint, v641 or Enum.EasingDirection.Out, 0, false, 0.8999999999999999 * v_u_102), {
					["Scale"] = 1
				}):Play()
			end
			v_u_140.Position = UDim2.fromOffset(0, v_u_599 + 16)
			v_u_140.Visible = true
			local v642 = v_u_140
			local v643 = {
				["Position"] = UDim2.fromOffset(0, v_u_599)
			}
			local v644 = Enum.EasingStyle.Quint
			local v645 = Enum.EasingDirection.Out
			v_u_4:Create(v642, TweenInfo.new(v_u_102 * 0.4, v644 or Enum.EasingStyle.Quint, v645 or Enum.EasingDirection.Out, 0, false, 0.7 * v_u_102), v643):Play()
			local function v662()
				-- upvalues: (copy) v_u_269, (ref) v_u_182, (ref) v_u_140, (ref) v_u_141, (ref) v_u_139, (copy) v_u_275, (copy) v_u_274, (copy) v_u_599, (copy) v_u_271, (ref) v_u_4, (ref) v_u_102, (copy) v_u_273, (copy) v_u_606, (ref) v_u_162, (ref) v_u_41, (ref) v_u_38, (copy) v_u_495, (copy) v_u_284, (ref) v_u_46
				if v_u_269 == v_u_182 then
					local v646 = v_u_140.AbsoluteSize.X / 900
					local v647 = v646 <= 0 and 420 or v_u_141.AbsoluteContentSize.X / v646
					v_u_139.ImageColor3 = v_u_275:Lerp(v_u_274, 0.25)
					v_u_139.Position = UDim2.fromOffset(0, v_u_599 - 42)
					v_u_139.Size = UDim2.fromOffset(v647 * 0.5, 92)
					v_u_139.ImageTransparency = 1
					local v648 = v_u_139
					local v649 = {
						["Size"] = UDim2.fromOffset(v647 + 260, 92),
						["ImageTransparency"] = v_u_271 and 0.3 or 0.15
					}
					v_u_4:Create(v648, TweenInfo.new(v_u_102 * 0.35, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v649):Play()
					local v650 = v_u_273.width * 0.58 + (v_u_606 and 260 or 0)
					local v651 = v_u_162
					local v652 = v_u_271 and 6 or 16
					local v653
					if v_u_271 then
						v653 = v_u_274:Lerp(v_u_41.Void, 0.3)
					else
						v653 = v_u_38.Lighten(v_u_274, 0.3)
					end
					v651(v652, v653, v650, 50, v_u_271 and 360 or 800, {
						["sparkChance"] = 0.7
					})
					local v654 = v_u_495.kind
					local v655 = v_u_284 * 0.75
					if v654 == "ace" or v654 == "teamace" then
						local v656 = {
							["volume"] = v655
						}
						if v_u_46 then
							local v657 = v_u_46.Play
							pcall(v657, "Kill_Triple", nil, v656)
							return
						end
					elseif v654 == "clutch" then
						local v658 = {
							["volume"] = v655 * 0.8
						}
						if v_u_46 then
							local v659 = v_u_46.Play
							pcall(v659, "Match/Final_Round", nil, v658)
							return
						end
					else
						local v660 = {
							["volume"] = v655
						}
						if v_u_46 then
							local v661 = v_u_46.Play
							pcall(v661, "UI/Card_Reveal", nil, v660)
						end
					end
				end
			end
			task.delay(v_u_102 * 0.7, v662)
		end
		local v663
		if p_u_260 then
			v663 = 3.35
		elseif v_u_272 then
			v663 = v_u_271 and 2.95 or 2.85
		else
			v663 = v_u_271 and 2.05 or 1.95
		end
		local function v703()
			-- upvalues: (copy) v_u_269, (ref) v_u_182, (ref) v_u_66, (copy) v_u_279, (copy) v_u_280, (ref) v_u_4, (ref) v_u_102, (ref) v_u_69, (ref) v_u_68, (ref) v_u_75, (ref) v_u_78, (ref) v_u_83, (ref) v_u_84, (ref) v_u_93, (ref) v_u_97, (ref) v_u_100, (copy) v_u_272, (ref) v_u_110, (copy) v_u_273, (ref) v_u_222, (copy) p_u_260, (ref) v_u_103, (ref) v_u_37, (ref) v_u_58, (ref) v_u_60, (ref) v_u_181, (ref) v_u_183, (ref) v_u_184, (ref) p_u_36, (ref) v_u_153, (ref) v_u_140, (ref) v_u_109, (ref) v_u_139, (ref) v_u_80, (ref) v_u_73, (ref) v_u_57, (ref) v_u_163, (ref) v_u_164
			if v_u_269 == v_u_182 then
				v_u_66.AnchorPoint = Vector2.new(1, 0.5)
				v_u_66.Position = UDim2.fromOffset(v_u_279 / 2, 0)
				local v664 = v_u_66
				local v665 = {
					["Size"] = nil,
					["ImageTransparency"] = 0.6,
					["Size"] = UDim2.fromOffset(0, v_u_280)
				}
				local v666 = Enum.EasingStyle.Quint
				local v667 = Enum.EasingDirection.In
				v_u_4:Create(v664, TweenInfo.new(v_u_102 * 0.28, v666 or Enum.EasingStyle.Quint, v667 or Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v665):Play()
				local v668 = v_u_69
				local v669 = Enum.EasingStyle.Quad
				v_u_4:Create(v668, TweenInfo.new(v_u_102 * 0.2, v669 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
					["BackgroundTransparency"] = 1
				}):Play()
				local v670 = v_u_68
				local v671 = {
					["ImageTransparency"] = 1,
					["Size"] = nil,
					["Size"] = UDim2.fromOffset(v_u_279 * 1.3, v_u_280 * 1.2)
				}
				local v672 = Enum.EasingStyle.Quad
				v_u_4:Create(v670, TweenInfo.new(v_u_102 * 0.3, v672 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v671):Play()
				for _, v673 in { v_u_75, v_u_78 } do
					local v674 = {
						["TextTransparency"] = 1,
						["Position"] = nil,
						["Position"] = v673.Position - UDim2.fromOffset(0, 18)
					}
					local v675 = Enum.EasingStyle.Quint
					local v676 = Enum.EasingDirection.In
					v_u_4:Create(v673, TweenInfo.new(v_u_102 * 0.24, v675 or Enum.EasingStyle.Quint, v676 or Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v674):Play()
				end
				local v677 = v_u_83
				local v678 = Enum.EasingStyle.Quad
				v_u_4:Create(v677, TweenInfo.new(v_u_102 * 0.2, v678 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
					["TextTransparency"] = 1
				}):Play()
				local v679 = v_u_84
				local v680 = Enum.EasingStyle.Quad
				v_u_4:Create(v679, TweenInfo.new(v_u_102 * 0.2, v680 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
					["Transparency"] = 1
				}):Play()
				for _, v681 in { v_u_93, v_u_97 } do
					local v682 = Enum.EasingStyle.Quad
					v_u_4:Create(v681, TweenInfo.new(v_u_102 * 0.2, v682 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
						["TextTransparency"] = 1
					}):Play()
				end
				local v683 = v_u_100
				local v684 = Enum.EasingStyle.Quad
				v_u_4:Create(v683, TweenInfo.new(v_u_102 * 0.2, v684 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
					["BackgroundTransparency"] = 1
				}):Play()
				if v_u_272 then
					local v685 = v_u_110
					local v686 = {
						["Position"] = v_u_110.Position + UDim2.fromOffset(0, -10)
					}
					local v687 = Enum.EasingStyle.Quint
					local v688 = Enum.EasingDirection.In
					v_u_4:Create(v685, TweenInfo.new(v_u_102 * 0.25, v687 or Enum.EasingStyle.Quint, v688 or Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v686):Play()
				end
				if v_u_272 or v_u_273 then
					v_u_222(0.25)
				end
				if p_u_260 then
					for _, v689 in v_u_103 do
						local v690 = v689.frame
						local v691 = {
							["Position"] = v689.frame.Position + UDim2.fromOffset(0, 40)
						}
						local v692 = Enum.EasingStyle.Quint
						local v693 = Enum.EasingDirection.In
						v_u_4:Create(v690, TweenInfo.new(v_u_102 * 0.25, v692 or Enum.EasingStyle.Quint, v693 or Enum.EasingDirection.Out, 0, false, 0 * v_u_102), v691):Play()
						local v694 = v_u_37.GetScaleObj(v689.frame)
						local v695 = Enum.EasingStyle.Quint
						local v696 = Enum.EasingDirection.In
						v_u_4:Create(v694, TweenInfo.new(v_u_102 * 0.25, v695 or Enum.EasingStyle.Quint, v696 or Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
							["Scale"] = 0
						}):Play()
					end
					local v697 = v_u_58
					local v698 = Enum.EasingStyle.Quad
					v_u_4:Create(v697, TweenInfo.new(v_u_102 * 0.4, v698 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
						["BackgroundTransparency"] = 1
					}):Play()
				end
				local v699 = v_u_60
				local v700 = Enum.EasingStyle.Quad
				v_u_4:Create(v699, TweenInfo.new(v_u_102 * 0.45, v700 or Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0 * v_u_102), {
					["ImageTransparency"] = 1
				}):Play()
				v_u_181(0.45)
				local function v702()
					-- upvalues: (ref) v_u_269, (ref) v_u_182, (ref) v_u_183, (ref) v_u_184, (ref) p_u_36, (ref) v_u_153, (ref) v_u_110, (ref) v_u_140, (ref) v_u_109, (ref) v_u_139, (ref) v_u_75, (ref) v_u_78, (ref) v_u_80, (ref) v_u_73, (ref) v_u_57, (ref) v_u_163, (ref) v_u_164
					if v_u_269 == v_u_182 then
						v_u_183 = false
						if v_u_184 then
							p_u_36.SetHudHidden("Celebrate", false)
						end
						v_u_184 = false
						v_u_153:Clear()
						v_u_110.Visible = false
						v_u_140.Visible = false
						v_u_109.ImageTransparency = 1
						v_u_139.ImageTransparency = 1
						for _, v701 in {
							v_u_75,
							v_u_78,
							v_u_80,
							v_u_73
						} do
							v701.MaxVisibleGraphemes = -1
						end
						v_u_57.Visible = false
						if v_u_163 then
							v_u_163:Destroy()
							v_u_163 = nil
						end
						if v_u_164 then
							v_u_164:Destroy()
							v_u_164 = nil
						end
					end
				end
				task.delay(v_u_102 * 0.48, v702)
			end
		end
		task.delay(v663 * v_u_102, v703)
	end
	p_u_36.OnMatchEvent(function(p705, p706)
		-- upvalues: (copy) v_u_39, (ref) v_u_102, (copy) v_u_704, (ref) v_u_35, (copy) v_u_240
		local v707 = type(p706) ~= "table" and {} or p706
		if p705 == "RoundEnd" then
			local v708 = v707.winnerTeam
			local v709 = v_u_39.Match
			local v710 = v_u_39.MyTeam()
			local v711 = v709 and (v709.teams and v709.teams[v710]) and (v709.teams[v710].score or 0) or 0
			local v712 = v709 and (v709.teams and v709.teams[3 - v710]) and (v709.teams[3 - v710].score or 0) or 0
			local v713, v714
			if v709 and (v709.phase ~= "RoundEnd" and (v708 == 1 or v708 == 2)) then
				if v708 == v710 then
					v713 = v711 + 1
					v714 = v712
				else
					local v715 = v712 + 1
					v714 = v712
					v712 = v715
					v713 = v711
				end
			elseif v708 == v710 then
				local v716 = v711 - 1
				local v717 = math.max(0, v716)
				v714 = v712
				v713 = v711
				v711 = v717
			elseif v708 == 3 - v710 then
				local v718 = v712 - 1
				v714 = math.max(0, v718)
				v713 = v711
			else
				v714 = v712
				v713 = v711
			end
			local v719 = (v708 == 0 or v708 == nil) and "draw" or (v708 == v710 and "win" or "lose")
			local v720 = v_u_39.RoundsToWin()
			local v721 = v720 <= v713 and true or v720 <= v712
			v_u_102 = 1
			local v722 = v_u_704
			local v723 = v707.round
			if v723 then
				v709 = v723
			elseif v709 then
				v709 = v709.round
			end
			v722(v719, v721, v713, v712, v711, v714, v709, v707.mvpId, (v_u_35(v707.moment)))
		elseif p705 == "PlayOfTheGame" or (p705 == "MatchEnd" or (p705 == "MatchStart" or p705 == "RoundStart")) then
			v_u_240(false)
		end
	end)
	v_u_39.PlayerStateChanged:Connect(function(p724)
		-- upvalues: (ref) v_u_183, (ref) v_u_182, (ref) v_u_184, (copy) p_u_36, (copy) v_u_153, (copy) v_u_110, (copy) v_u_140, (copy) v_u_109, (copy) v_u_139, (copy) v_u_75, (copy) v_u_78, (copy) v_u_80, (copy) v_u_73, (copy) v_u_57, (ref) v_u_163, (ref) v_u_164
		if p724 ~= "Match" then
			if not v_u_183 then
				return
			end
			v_u_182 = v_u_182 + 1
			v_u_183 = false
			if v_u_184 then
				p_u_36.SetHudHidden("Celebrate", false)
			end
			v_u_184 = false
			v_u_153:Clear()
			v_u_110.Visible = false
			v_u_140.Visible = false
			v_u_109.ImageTransparency = 1
			v_u_139.ImageTransparency = 1
			for _, v725 in {
				v_u_75,
				v_u_78,
				v_u_80,
				v_u_73
			} do
				v725.MaxVisibleGraphemes = -1
			end
			v_u_57.Visible = false
			if v_u_163 then
				v_u_163:Destroy()
				v_u_163 = nil
			end
			if v_u_164 then
				v_u_164:Destroy()
				v_u_164 = nil
			end
		end
	end)
	function p_u_36.Debug.celebrate(p726, p727, p728, p729, p730)
		-- upvalues: (ref) v_u_102, (copy) v_u_704, (copy) v_u_39
		v_u_102 = (type(p730) ~= "number" or p730 <= 0) and 1 or p730
		local v731 = p726 ~= "lose" and p726 ~= "draw" and "win" or p726
		local v732 = tonumber(p728) or (v731 == "win" and 1 or 0)
		local v733 = tonumber(p729) or (v731 == "lose" and 1 or 0)
		local v734
		if v731 == "win" then
			local v735 = v732 - 1
			v734 = math.max(0, v735)
		else
			v734 = v732
		end
		local v736
		if v731 == "lose" then
			local v737 = v733 - 1
			v736 = math.max(0, v737)
		else
			v736 = v733
		end
		v_u_704(v731, p727 == true, v732, v733, v734, v736, 1, v_u_39.MyId())
		return true
	end
	function p_u_36.Debug.celebrateStop()
		-- upvalues: (ref) v_u_183, (ref) v_u_182, (ref) v_u_184, (copy) p_u_36, (copy) v_u_153, (copy) v_u_110, (copy) v_u_140, (copy) v_u_109, (copy) v_u_139, (copy) v_u_75, (copy) v_u_78, (copy) v_u_80, (copy) v_u_73, (copy) v_u_57, (ref) v_u_163, (ref) v_u_164
		if v_u_183 then
			v_u_182 = v_u_182 + 1
			v_u_183 = false
			if v_u_184 then
				p_u_36.SetHudHidden("Celebrate", false)
			end
			v_u_184 = false
			v_u_153:Clear()
			v_u_110.Visible = false
			v_u_140.Visible = false
			v_u_109.ImageTransparency = 1
			v_u_139.ImageTransparency = 1
			for _, v738 in {
				v_u_75,
				v_u_78,
				v_u_80,
				v_u_73
			} do
				v738.MaxVisibleGraphemes = -1
			end
			v_u_57.Visible = false
			if v_u_163 then
				v_u_163:Destroy()
				v_u_163 = nil
			end
			if v_u_164 then
				v_u_164:Destroy()
				v_u_164 = nil
			end
		end
		return true
	end
	function p_u_36.Debug.ceremony(p739, p740, p741, p742)
		-- upvalues: (ref) v_u_102, (ref) v_u_6, (copy) v_u_39, (ref) v_u_35, (copy) v_u_704
		v_u_102 = (type(p742) ~= "number" or p742 <= 0) and 1 or p742
		local v743 = (type(p739) ~= "string" or not v_u_6[p739]) and "ace" or p739
		local v744 = v_u_39.MyTeam()
		local v745
		if p740 == "enemy" then
			v745 = 3 - v744
		else
			v745 = v744
		end
		local v746 = nil
		local v747 = v_u_39.Match
		local v748 = v747 and v747.teams
		if v748 then
			v748 = v747.teams[v745]
		end
		for _, v749 in v748 and v748.members or {} do
			if v746 ~= nil and v749.id ~= v_u_39.MyId() then
				continue
			end
			v746 = v749
		end
		local v750 = v_u_39.Match
		local v751 = v750 and v750.round or 2
		local v752 = v_u_39.RoundsToWin()
		local v753 = v745 == v744
		local v754 = not (p741 and v753) and 1 or v752
		local v755 = (not p741 or v753) and 1 or v752
		local v756 = v_u_35
		local v757 = {
			["kind"] = v743
		}
		local v758
		if v746 then
			v758 = v746.id
		else
			v758 = false
		end
		v757.id = v758
		v757.name = not v746 and "Player" or v746.name
		v757.team = v745
		v757.vs = v743 == "clutch" and 2 or 0
		local v759 = v756(v757)
		local v760 = v_u_704
		local v761 = v753 and "win" or "lose"
		local v762 = p741 == true
		local v763
		if v753 then
			v763 = v754 - 1
		else
			v763 = v754
		end
		local v764
		if v753 then
			v764 = v755
		else
			v764 = v755 - 1
		end
		v760(v761, v762, v754, v755, v763, v764, v751, nil, v759)
		return true
	end
	function p_u_36.Debug.ceremonyState()
		-- upvalues: (ref) v_u_183, (copy) v_u_57, (copy) v_u_75, (copy) v_u_83, (copy) v_u_110, (copy) v_u_134, (copy) v_u_136, (copy) v_u_137, (copy) v_u_140, (copy) v_u_142, (copy) v_u_147
		local v765 = {
			["active"] = v_u_183
		}
		local v766
		if v_u_57.Visible then
			v766 = v_u_75.Text
		else
			v766 = false
		end
		v765.headline = v766
		local v767
		if v_u_57.Visible and v_u_83.Visible then
			v767 = v_u_83.Text
		else
			v767 = false
		end
		v765.caption = v767
		v765.plate = v_u_110.Visible
		local v768
		if v_u_110.Visible and v_u_134.Visible then
			v768 = v_u_134.Text
		else
			v768 = false
		end
		v765.plateName = v768
		local v769
		if v_u_110.Visible and v_u_136.Visible then
			v769 = v_u_137.Text
		else
			v769 = false
		end
		v765.vs = v769
		local v770
		if v_u_140.Visible then
			v770 = v_u_142.Text
		else
			v770 = false
		end
		v765.accolade = v770
		local v771
		if v_u_140.Visible and v_u_147.Visible then
			v771 = v_u_147.Text
		else
			v771 = false
		end
		v765.accoladeName = v771
		return v765
	end
end
return v7