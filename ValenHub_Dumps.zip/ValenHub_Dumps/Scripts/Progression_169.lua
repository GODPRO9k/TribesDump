local v_u_73 = {
	["MAX_LEVEL"] = 200,
	["REWARDS"] = {
		["participation"] = {
			["xp"] = 40,
			["shells"] = 10
		},
		["win"] = {
			["xp"] = 60,
			["shells"] = 20
		},
		["kill"] = {
			["xp"] = 15,
			["shells"] = 3
		},
		["assist"] = {
			["xp"] = 5,
			["shells"] = 1
		},
		["roundWon"] = {
			["xp"] = 15,
			["shells"] = 3
		},
		["mvp"] = {
			["xp"] = 25,
			["shells"] = 8
		},
		["streak"] = {
			["xp"] = 8,
			["shells"] = 0
		}
	},
	["KILL_CAP"] = 12,
	["ASSIST_CAP"] = 12,
	["STREAK_CAP"] = 5,
	["ROOKIE_MATCHES"] = 3,
	["ROOKIE_XP_MULT"] = 1.5,
	["XpToNext"] = function(p1) -- name: XpToNext
		local v2 = math.floor(p1)
		local v3 = math.max(1, v2) - 1
		local v4 = (v3 * 150 + 200 + v3 * 10 * v3) / 5 + 0.5
		return math.floor(v4) * 5
	end,
	["LevelUpShells"] = function(p5) -- name: LevelUpShells
		return p5 <= 10 and 25 or (p5 <= 30 and 40 or 60)
	end,
	["AddXp"] = function(p6, p7, p8) -- name: AddXp
		-- upvalues: (copy) v_u_73
		local v9 = math.floor(p6)
		local v10 = v_u_73.MAX_LEVEL
		local v11 = math.clamp(v9, 1, v10)
		local v12 = math.floor(p7)
		local v13 = math.max(0, v12)
		local v14 = math.floor(p8)
		local v15 = v13 + math.max(0, v14)
		local v16 = 0
		local v17 = 0
		while v11 < v_u_73.MAX_LEVEL and v_u_73.XpToNext(v11) <= v15 do
			v15 = v15 - v_u_73.XpToNext(v11)
			v11 = v11 + 1
			v16 = v16 + 1
			v17 = v17 + v_u_73.LevelUpShells(v11)
		end
		if v_u_73.MAX_LEVEL <= v11 then
			local v18 = v_u_73.XpToNext
			v15 = math.min(v15, v18(v11))
		end
		return {
			["level"] = v11,
			["xp"] = v15,
			["levelsGained"] = v16,
			["shells"] = v17
		}
	end,
	["MatchRewards"] = function(p19) -- name: MatchRewards
		-- upvalues: (copy) v_u_73
		local v20 = v_u_73.REWARDS
		local v21 = {}
		local v22 = v20.participation
		local v23 = {
			["label"] = "Match played",
			["xp"] = nil,
			["shells"] = nil,
			["xp"] = v22.xp * 1,
			["shells"] = v22.shells * 1
		}
		table.insert(v21, v23)
		if p19.won then
			local v24 = v20.win
			local v25 = {
				["label"] = "Victory",
				["xp"] = nil,
				["shells"] = nil,
				["xp"] = v24.xp * 1,
				["shells"] = v24.shells * 1
			}
			table.insert(v21, v25)
		end
		local v26 = p19.kills
		local v27 = math.floor(v26)
		local v28 = v_u_73.KILL_CAP
		local v29 = math.clamp(v27, 0, v28)
		local v30 = v20.kill
		if v29 > 0 then
			local v31 = {
				["label"] = "Eliminations",
				["xp"] = nil,
				["shells"] = nil,
				["xp"] = v30.xp * v29,
				["shells"] = v30.shells * v29
			}
			table.insert(v21, v31)
		end
		local v32 = p19.assists or 0
		local v33 = math.floor(v32)
		local v34 = v_u_73.ASSIST_CAP
		local v35 = math.clamp(v33, 0, v34)
		local v36 = v20.assist
		if v35 > 0 then
			local v37 = {
				["label"] = "Assists",
				["xp"] = nil,
				["shells"] = nil,
				["xp"] = v36.xp * v35,
				["shells"] = v36.shells * v35
			}
			table.insert(v21, v37)
		end
		local v38 = p19.roundsWon
		local v39 = math.floor(v38)
		local v40 = math.clamp(v39, 0, 20)
		local v41 = v20.roundWon
		if v40 > 0 then
			local v42 = {
				["label"] = "Rounds won",
				["xp"] = nil,
				["shells"] = nil,
				["xp"] = v41.xp * v40,
				["shells"] = v41.shells * v40
			}
			table.insert(v21, v42)
		end
		if p19.mvp then
			local v43 = v20.mvp
			local v44 = {
				["label"] = "MVP",
				["xp"] = nil,
				["shells"] = nil,
				["xp"] = v43.xp * 1,
				["shells"] = v43.shells * 1
			}
			table.insert(v21, v44)
		end
		if p19.won and p19.streak >= 2 then
			local v45 = p19.streak
			local v46 = v_u_73.STREAK_CAP
			local v47 = math.min(v45, v46)
			local v48 = v20.streak
			if v47 > 0 then
				local v49 = {
					["label"] = "Win streak",
					["xp"] = nil,
					["shells"] = nil,
					["xp"] = v48.xp * v47,
					["shells"] = v48.shells * v47
				}
				table.insert(v21, v49)
			end
		end
		local v50 = 0
		local v51 = 0
		for _, v52 in v21 do
			v50 = v50 + v52.xp
			v51 = v51 + v52.shells
		end
		if p19.matchesPlayed < v_u_73.ROOKIE_MATCHES then
			local v53 = v50 * (v_u_73.ROOKIE_XP_MULT - 1)
			local v54 = math.floor(v53)
			table.insert(v21, {
				["label"] = "Rookie bonus",
				["xp"] = nil,
				["shells"] = 0,
				["xp"] = v54
			})
			v50 = v50 + v54
		end
		return {
			["xp"] = v50,
			["shells"] = v51,
			["lines"] = v21
		}
	end,
	["MMR_MIN"] = 0,
	["MMR_MAX"] = 4000,
	["MmrDelta"] = function(p55, p56, p57, p58, p59) -- name: MmrDelta
		local v60 = math.clamp(p59 or 0, 0, 1)
		local v61 = (p57 - p58) * 2
		local v62 = math.clamp(v61, -10, 10)
		local v63
		if p55 then
			v63 = (1 - v60 * 0.35) * 22 + v62
		else
			v63 = v62 * 0.5 + -18
		end
		local v64 = (p56 - 1000) / 1500
		local v65 = math.clamp(v64, -0.5, 0.5)
		local v66
		if v63 > 0 then
			v66 = v63 * (1 - v65)
		else
			v66 = v63 * (v65 + 1)
		end
		local v67 = v66 + 0.5
		return math.floor(v67)
	end,
	["FIRST_MATCH_BOT_DIFFICULTY"] = 0.03,
	["BotDifficulty"] = function(p68, p69) -- name: BotDifficulty
		-- upvalues: (copy) v_u_73
		local v70 = p69 or 99
		if v70 < 1 then
			return v_u_73.FIRST_MATCH_BOT_DIFFICULTY
		end
		if v70 < 3 then
			return 0.1
		end
		local v71 = (p68 - 1000) / 1400 + 0.3
		local v72 = math.clamp(v71, 0.1, 0.95)
		if v70 < 6 then
			v72 = math.min(v72, 0.16)
		end
		return v72
	end
}
return v_u_73