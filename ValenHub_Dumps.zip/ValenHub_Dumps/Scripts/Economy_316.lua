local v_u_1 = game:GetService("MarketplaceService")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("PolicyService")
local v_u_4 = game:GetService("ReplicatedStorage")
local v5 = game:GetService("RunService")
local v_u_6 = game:GetService("Workspace")
local v7 = v_u_4:WaitForChild("Shared")
local v8 = require(v7:WaitForChild("Signal"))
local v_u_9 = require(v7:WaitForChild("Unlocks"))
local v_u_10 = require(v7:WaitForChild("Ranks"))
local v_u_11 = require(v7:WaitForChild("Products"))
local v_u_12 = nil
local v13 = v7:FindFirstChild("Shards")
if v13 and v13:IsA("ModuleScript") then
	local v14 = require
	local v15, v16 = pcall(v14, v13)
	if v15 and type(v16) == "table" then
		v_u_12 = v16
	else
		warn("[UI] Shared.Shards failed to load: " .. tostring(v16))
	end
end
if not v_u_12 then
	local v_u_17 = {
		["small"] = {
			["unlock"] = 10,
			["up"] = nil,
			["up"] = {
				10,
				20,
				40,
				80
			}
		},
		["medium"] = {
			["unlock"] = 20,
			["up"] = nil,
			["up"] = {
				20,
				40,
				80,
				160
			}
		},
		["large"] = {
			["unlock"] = 40,
			["up"] = nil,
			["up"] = {
				40,
				80,
				160,
				320
			}
		},
		["starter"] = {
			["unlock"] = 0,
			["up"] = nil,
			["up"] = {
				10,
				20,
				40,
				80
			}
		}
	}
	v_u_12 = {
		["MAX_LEVEL"] = 5,
		["BONUS_PER_LEVEL"] = 0.02,
		["FALLBACK"] = true,
		["Size"] = function(p18) -- name: Size
			-- upvalues: (copy) v_u_9, (copy) v_u_17
			local v19 = v_u_9.SizeOf
			local v20, v21 = pcall(v19, p18)
			return (not v20 or (type(v21) ~= "string" or not v_u_17[v21])) and (v_u_9.IsStarter(p18) and "starter" or "medium") or v21
		end,
		["UnlockCost"] = function(p22) -- name: UnlockCost
			-- upvalues: (copy) v_u_17, (copy) v_u_12
			return v_u_17[v_u_12.Size(p22)].unlock
		end,
		["UpgradeCost"] = function(p23, p24) -- name: UpgradeCost
			-- upvalues: (copy) v_u_12, (copy) v_u_17
			if v_u_12.MAX_LEVEL <= p24 then
				return nil
			else
				return v_u_17[v_u_12.Size(p23)].up[math.max(1, p24)]
			end
		end,
		["Level"] = function(p25, p26) -- name: Level
			-- upvalues: (copy) v_u_12, (copy) v_u_9
			local v27
			if type(p25) == "table" then
				v27 = p25[p26]
			else
				v27 = false
			end
			if type(v27) == "table" then
				local v28 = v27.level
				if type(v28) == "number" then
					local v29 = v27.level
					local v30 = math.floor(v29)
					local v31 = v_u_12.MAX_LEVEL
					return math.clamp(v30, 0, v31)
				end
			end
			return v_u_9.IsStarter(p26) and 1 or 0
		end,
		["Owns"] = function(p32, p33) -- name: Owns
			-- upvalues: (copy) v_u_12
			return v_u_12.Level(p32, p33) >= 1
		end,
		["Progress"] = function(p34, p35) -- name: Progress
			-- upvalues: (copy) v_u_12
			local v36
			if type(p34) == "table" then
				v36 = p34[p35]
			else
				v36 = false
			end
			local v37
			if type(v36) == "table" then
				local v38 = v36.shards
				v37 = type(v38) ~= "number" and 0 or v36.shards
			else
				v37 = 0
			end
			local v39 = v_u_12.Level(p34, p35)
			if v39 <= 0 then
				return v37, v_u_12.UnlockCost(p35), "unlock"
			else
				local v40 = v_u_12.UpgradeCost(p35, v39)
				if v40 then
					return v37, v40, "upgrade"
				else
					return 0, 0, "max"
				end
			end
		end,
		["CanUpgrade"] = function(p41, p42) -- name: CanUpgrade
			-- upvalues: (copy) v_u_12
			local v43, v44, v45 = v_u_12.Progress(p41, p42)
			local v46
			if v45 == "upgrade" then
				v46 = v44 <= v43
			else
				v46 = false
			end
			return v46
		end,
		["Bonus"] = function(p47) -- name: Bonus
			-- upvalues: (copy) v_u_12
			local v48 = v_u_12.BONUS_PER_LEVEL
			local v49 = v_u_12.MAX_LEVEL
			return 1 + v48 * (math.clamp(p47, 1, v49) - 1)
		end,
		["Odds"] = function() -- name: Odds
			return {}
		end
	}
end
local v_u_50 = {
	["Unlocks"] = v_u_9,
	["Shards"] = v_u_12,
	["ROBUX"] = utf8.char(57346)
}
local v51 = v_u_12.MAX_LEVEL
v_u_50.MAX_LEVEL = tonumber(v51) or 5
local v52 = v_u_12.BONUS_PER_LEVEL
v_u_50.BONUS_PER_LEVEL = tonumber(v52) or 0.02
v_u_50.Changed = v8.new()
v_u_50.Event = v8.new()
v_u_50.Upgraded = v8.new()
v_u_50.Celebrate = v8.new()
v_u_50.CelebrationChanged = v8.new()
v_u_50.RevealChanged = v8.new()
v_u_50.ForceMock = false
v_u_50.Mock = nil
local v_u_53 = v2.LocalPlayer
local v_u_54 = v5:IsStudio()
local v55 = Color3.fromRGB
local v_u_56 = {
	["ammo"] = Color3.fromRGB(240, 96, 48),
	["bow"] = v55(56, 189, 248),
	["gun"] = v55(251, 146, 60),
	["melee"] = v55(248, 113, 113),
	["throwable"] = v55(167, 139, 250),
	["utility"] = v55(250, 204, 21),
	["healing"] = v55(74, 222, 128),
	["armor"] = v55(148, 197, 255)
}
function v_u_50.Init(p_u_57) -- name: Init
	-- upvalues: (copy) v_u_50, (copy) v_u_56, (ref) v_u_12, (copy) v_u_9, (copy) v_u_10, (copy) v_u_3, (copy) v_u_53, (copy) v_u_6, (copy) v_u_4, (copy) v_u_11, (copy) v_u_1, (copy) v_u_54
	local v_u_58 = p_u_57.State
	local v_u_59 = p_u_57.WeaponInfo
	p_u_57.Economy = v_u_50
	function v_u_50.CategoryColor(p60) -- name: CategoryColor
		-- upvalues: (copy) v_u_59, (ref) v_u_56, (copy) p_u_57
		local v61 = v_u_59.Get(p60)
		return v61 and v_u_56[v61.category] or p_u_57.Theme.Colors.Accent
	end
	local v_u_62 = nil
	local v_u_63 = nil
	local function v_u_70() -- name: items
		-- upvalues: (ref) v_u_50, (copy) v_u_58, (ref) v_u_63, (ref) v_u_62
		local v64 = v_u_50.Mock
		if v64 then
			return v64.items
		end
		local v65 = v_u_58.Profile
		local v66 = v65.items
		if type(v66) == "table" then
			return v65.items
		end
		local v67 = v65.owned
		if type(v67) ~= "table" then
			return {}
		end
		if v_u_63 ~= v67 then
			v_u_63 = v67
			v_u_62 = {}
			for v68, v69 in v67 do
				if v69 ~= true or type(v68) ~= "string" then
					continue
				end
				v_u_62[v68] = {
					["shards"] = 0,
					["level"] = 1
				}
			end
		end
		return v_u_62
	end
	v_u_50.Items = v_u_70
	function v_u_50.HasData() -- name: HasData
		-- upvalues: (ref) v_u_50, (copy) v_u_58
		if v_u_50.Mock then
			return true
		end
		local v71 = v_u_58.Profile
		local v72 = v_u_58.HasProfile
		if v72 then
			local v73 = v71.items
			if type(v73) == "table" then
				v72 = true
			else
				local v74 = v71.owned
				v72 = type(v74) == "table"
			end
		end
		return v72
	end
	function v_u_50.Level(p75) -- name: Level
		-- upvalues: (ref) v_u_12, (copy) v_u_70, (ref) v_u_50, (copy) v_u_58, (ref) v_u_9
		if type(p75) ~= "string" then
			return 0
		end
		local v76 = v_u_12.Level
		local v77 = v_u_70()
		local v78, v79 = pcall(v76, v77, p75)
		local v80 = (not v78 or type(v79) ~= "number") and 0 or v79
		if v80 <= 0 and not v_u_50.Mock then
			local v81 = v_u_58.Profile.owned
			v80 = type(v81) == "table" and v81[p75] == true and 1 or (v_u_9.IsStarter(p75) and 1 or v80)
		end
		local v82 = math.floor(v80)
		local v83 = v_u_50.MAX_LEVEL
		return math.clamp(v82, 0, v83)
	end
	function v_u_50.Owns(p84) -- name: Owns
		-- upvalues: (ref) v_u_50
		return v_u_50.Level(p84) >= 1
	end
	function v_u_59.OwnsAmmo(p85)
		-- upvalues: (ref) v_u_50
		return v_u_50.Owns(p85)
	end
	function v_u_50.MaxLevel(p86) -- name: MaxLevel
		-- upvalues: (ref) v_u_12, (ref) v_u_50
		local v87 = v_u_12.MaxLevel
		if type(v87) == "function" and type(p86) == "string" then
			local v88 = v_u_12.MaxLevel
			local v89, v90 = pcall(v88, p86)
			if v89 and type(v90) == "number" then
				local v91 = math.floor(v90)
				local v92 = v_u_50.MAX_LEVEL
				return math.clamp(v91, 1, v92)
			end
		end
		return v_u_50.MAX_LEVEL
	end
	function v_u_50.IsLocked(p93) -- name: IsLocked
		-- upvalues: (ref) v_u_50
		local v94
		if type(p93) == "string" then
			v94 = not v_u_50.Owns(p93)
		else
			v94 = false
		end
		return v94
	end
	function v_u_50.RankBest() -- name: RankBest
		-- upvalues: (copy) v_u_58, (ref) v_u_10
		local v95 = v_u_58.Profile
		local v96 = v95.rankBest
		local v97 = tonumber(v96) or 1
		local v98 = v_u_10.RankOf
		local v99 = v95.trophies
		local v100 = tonumber(v99) or 0
		return math.max(v97, v98(v100))
	end
	function v_u_50.ItemRank(p101) -- name: ItemRank
		-- upvalues: (ref) v_u_10
		return v_u_10.ItemRank(p101)
	end
	function v_u_50.RankAllows(p102) -- name: RankAllows
		-- upvalues: (ref) v_u_9, (ref) v_u_50, (ref) v_u_10
		if type(p102) == "string" then
			return v_u_9.EVERYTHING_OWNED == true and true or (v_u_50.Owns(p102) or v_u_10.Allows(v_u_50.RankBest(), p102))
		else
			return false
		end
	end
	function v_u_50.Progress(p103) -- name: Progress
		-- upvalues: (ref) v_u_50, (ref) v_u_12, (copy) v_u_70
		local v104 = v_u_50.Level(p103)
		local v105 = v_u_12.Progress
		local v106 = v_u_70()
		local v107, v108, v109, v110 = pcall(v105, v106, p103)
		if not v107 or type(v108) ~= "number" then
			v108 = 0
			v109 = 0
			if v_u_50.MAX_LEVEL <= v104 then
				v110 = "max"
			else
				v110 = "unlock"
			end
		end
		if v104 >= 1 and v110 == "unlock" then
			v109 = v_u_12.UpgradeCost(p103, v104)
			if v109 then
				v110 = "upgrade"
			else
				v108 = 0
				v109 = 0
				v110 = "max"
			end
		elseif v_u_50.MaxLevel(p103) <= v104 then
			v110 = "max"
		end
		local v111 = math.floor(v108)
		local v112 = math.max(0, v111)
		local v113 = math.floor(v109 or 0)
		return v112, math.max(0, v113), v110
	end
	function v_u_50.CanUpgrade(p114) -- name: CanUpgrade
		-- upvalues: (ref) v_u_50
		if type(p114) ~= "string" then
			return false
		end
		local v115, v116, v117 = v_u_50.Progress(p114)
		local v118
		if v117 == "upgrade" and v116 > 0 then
			v118 = v116 <= v115
		else
			v118 = false
		end
		return v118
	end
	function v_u_50.ReadyList() -- name: ReadyList
		-- upvalues: (copy) v_u_59, (ref) v_u_50
		local v119 = {}
		for _, v120 in v_u_59.AllItems() do
			if not v_u_50.CanUpgrade(v120.id) then
				continue
			end
			local v121 = v120.id
			table.insert(v119, v121)
		end
		return v119
	end
	function v_u_50.UpgradesReady() -- name: UpgradesReady
		-- upvalues: (ref) v_u_50
		return #v_u_50.ReadyList()
	end
	function v_u_50.Bonus(p122) -- name: Bonus
		-- upvalues: (ref) v_u_12, (ref) v_u_50
		local v123 = v_u_12.Bonus
		local v124, v125 = pcall(v123, p122)
		if v124 and type(v125) == "number" then
			return v125
		end
		local v126 = v_u_50.BONUS_PER_LEVEL
		local v127 = v_u_50.MAX_LEVEL
		return 1 + v126 * (math.clamp(p122, 1, v127) - 1)
	end
	function v_u_50.BonusPercent(p128) -- name: BonusPercent
		-- upvalues: (ref) v_u_50
		if p128 <= 1 then
			return 0
		end
		local v129 = (v_u_50.Bonus(p128) - 1) * 100 + 0.5
		return math.floor(v129)
	end
	function v_u_50.MaxBonusPercent() -- name: MaxBonusPercent
		-- upvalues: (ref) v_u_50
		return v_u_50.BonusPercent(v_u_50.MAX_LEVEL)
	end
	function v_u_50.StatWord(p130) -- name: StatWord
		-- upvalues: (ref) v_u_12, (copy) v_u_59
		local v131 = v_u_12.Stat
		if type(v131) == "function" and type(p130) == "string" then
			local v132 = v_u_12.Stat
			local v133, v134 = pcall(v132, p130)
			if v133 and (type(v134) == "string" or v134 == false) then
				return v134
			end
		end
		local v135 = v_u_59.Get(p130)
		return v135 and v135.category == "armor" and "armor" or (v135 and v135.category == "healing" and "healing" or "damage")
	end
	function v_u_50.BonusText(p136, p137) -- name: BonusText
		-- upvalues: (ref) v_u_12, (ref) v_u_50
		local v138 = v_u_12.BonusText
		if type(v138) == "function" then
			local v139 = v_u_12.BonusText
			local v140, v141 = pcall(v139, p136, p137)
			if v140 and type(v141) == "string" then
				return v141
			end
		end
		local v142 = v_u_50.StatWord(p136)
		return not v142 and "" or string.format("+%d%% %s", v_u_50.BonusPercent(p137), v142)
	end
	function v_u_50.Reveals() -- name: Reveals
		-- upvalues: (copy) v_u_58
		local v143 = v_u_58.Profile.reveals
		return type(v143) ~= "table" and {} or v143
	end
	local v_u_144 = nil
	local function v_u_150(p145) -- name: noteDrop
		-- upvalues: (ref) v_u_144
		if type(p145) == "table" then
			local v146 = p145.stacks
			if type(v146) == "table" then
				local v147 = nil
				for _, v148 in p145.stacks do
					if type(v148) ~= "table" then
						continue
					end
					local v149 = v148.item
					if type(v149) ~= "string" then
						continue
					end
					if v148.unlocked == true then
						v147 = v148.item
						break
					end
					v147 = v147 or v148.item
				end
				if v147 then
					v_u_144 = v147
				end
				return
			end
		end
	end
	function v_u_50.LastFound() -- name: LastFound
		-- upvalues: (ref) v_u_144, (ref) v_u_50, (copy) v_u_150
		if v_u_144 then
			return v_u_144
		end
		local v151 = v_u_50.Reveals()
		local v152 = v151[#v151]
		if type(v152) == "table" then
			v_u_150(v152)
		end
		return v_u_144
	end
	function v_u_50.Spotlight() -- name: Spotlight
		-- upvalues: (copy) v_u_59, (ref) v_u_50
		local v153 = v_u_59.AllItems()
		local v154 = -1
		local v155 = (1 / 0)
		local v156 = nil
		local v157 = false
		for _, v158 in v153 do
			if not (v_u_50.IsLocked(v158.id) and v_u_50.RankAllows(v158.id)) then
				continue
			end
			v157 = true
			local v159, v160 = v_u_50.Progress(v158.id)
			local v161 = v159 / math.max(v160, 1)
			if v159 <= 0 or v154 >= v161 and (v161 ~= v154 or v160 >= v155) then
				continue
			end
			v156 = v158.id
			v155 = v160
			v154 = v161
		end
		if v156 then
			return v156, "unlock"
		else
			local v162 = v_u_50.LastFound()
			if v162 and (v_u_59.Get(v162) and (v_u_50.RankAllows(v162) and (v_u_50.IsLocked(v162) or v_u_50.Progress(v162) > 0))) then
				if v_u_50.IsLocked(v162) then
					return v162, "unlock"
				else
					return v162, "found"
				end
			elseif v157 then
				local v163 = (1 / 0)
				local v164 = nil
				for _, v165 in v153 do
					if not (v_u_50.IsLocked(v165.id) and v_u_50.RankAllows(v165.id)) then
						continue
					end
					local _, v166 = v_u_50.Progress(v165.id)
					if v166 >= v163 then
						continue
					end
					v164 = v165.id
					v163 = v166
				end
				return v164, "unlock"
			else
				local v167 = v_u_50.ReadyList()
				if v167[1] then
					return v167[1], "ready"
				else
					local v168 = -1
					local v169 = nil
					for _, v170 in v153 do
						local v171, v172, v173 = v_u_50.Progress(v170.id)
						if v173 ~= "upgrade" or v168 >= v171 / math.max(v172, 1) then
							continue
						end
						v169 = v170.id
						v168 = v171 / math.max(v172, 1)
					end
					if v169 then
						return v169, "upgrade"
					else
						return v169, "max"
					end
				end
			end
		end
	end
	local v_u_174 = nil
	task.spawn(function()
		-- upvalues: (ref) v_u_3, (ref) v_u_53, (ref) v_u_174, (ref) v_u_50
		local function v175()
			-- upvalues: (ref) v_u_3, (ref) v_u_53
			return v_u_3:GetPolicyInfoForPlayerAsync(v_u_53)
		end
		local v176, v177 = pcall(v175)
		if v176 and type(v177) == "table" then
			local v178 = v177.ArePaidRandomItemsRestricted
			if type(v178) == "boolean" then
				v_u_174 = v177.ArePaidRandomItemsRestricted
				v_u_50.Changed:Fire()
			else
				v_u_174 = true
				v_u_50.Changed:Fire()
			end
		else
			v_u_174 = true
			v_u_50.Changed:Fire()
			return
		end
	end)
	function v_u_50.DropsAllowed() -- name: DropsAllowed
		-- upvalues: (ref) v_u_50, (copy) v_u_58, (ref) v_u_174
		local v179 = v_u_50.Mock
		if v179 and v179.restricted ~= nil then
			return v179.restricted ~= true
		else
			local v180 = v_u_58.Profile.canBuyDrops
			if type(v180) ~= "boolean" then
				v180 = nil
			end
			if v180 == nil then
				return v_u_174 == false
			else
				return v180
			end
		end
	end
	function v_u_50.Odds(p181) -- name: Odds
		-- upvalues: (ref) v_u_12, (copy) v_u_58, (ref) v_u_50, (copy) v_u_70
		local v182 = v_u_12.Odds
		if type(v182) == "function" then
			local v183 = {
				["loadout"] = v_u_58.Loadout()
			}
			local v184 = v_u_12.Context
			local v185
			if type(v184) == "function" and not v_u_50.Mock then
				local v186 = v_u_12.Context
				local v187 = v_u_58.Profile
				local v188
				v188, v185 = pcall(v186, v187)
				if v188 then
					if type(v185) ~= "table" then
						v185 = v183
					end
				else
					v185 = v183
				end
			else
				v185 = v183
			end
			local v189 = v_u_12.Odds
			local v190 = v_u_70()
			local v191, v192 = pcall(v189, v190, p181 or "golden", v185)
			if v191 and type(v192) == "table" then
				return v192
			end
		end
		return {}
	end
	function v_u_50.GoldenOffer() -- name: GoldenOffer
		-- upvalues: (copy) v_u_58, (ref) v_u_50, (ref) v_u_6
		local v193 = v_u_58.Profile.goldenOffer
		if type(v193) == "table" and v_u_50.DropsAllowed() then
			if v193.state == "active" then
				local v194 = v193.endsAt
				if type(v194) == "number" and v_u_6:GetServerTimeNow() < v193.endsAt then
					return v193
				else
					return false
				end
			elseif v193.state == "ready" then
				return v193
			else
				return false
			end
		else
			return false
		end
	end
	function v_u_50.OfferLeft() -- name: OfferLeft
		-- upvalues: (ref) v_u_50, (ref) v_u_6
		local v195 = v_u_50.GoldenOffer()
		if not v195 or v195.state ~= "active" then
			return nil
		end
		local v196 = v195.endsAt - v_u_6:GetServerTimeNow()
		return math.max(0, v196)
	end
	function v_u_50.OfferDiscount() -- name: OfferDiscount
		-- upvalues: (ref) v_u_50, (ref) v_u_9
		local v197 = v_u_50.GoldenOffer()
		local v198 = v197 and v197.key or v_u_9.FIRST_DROP.key
		local v199 = v_u_50.Price("drop_golden")
		local v200 = v_u_50.Price(v198)
		if not v199 or (not v200 or (v199 <= 0 or v199 <= v200)) then
			return nil
		end
		local v201 = (1 - v200 / v199) * 100 + 0.5
		return math.floor(v201)
	end
	local v_u_202 = (-1 / 0)
	function v_u_50.OfferSeen() -- name: OfferSeen
		-- upvalues: (ref) v_u_50, (ref) v_u_202, (ref) v_u_4
		local v203 = v_u_50.GoldenOffer()
		if v203 and (v203.state == "ready" and os.clock() - v_u_202 >= 5) then
			v_u_202 = os.clock()
			task.spawn(function()
				-- upvalues: (ref) v_u_4
				local v_u_204 = v_u_4:WaitForChild("Remotes", 30)
				if v_u_204 then
					v_u_204 = v_u_204:WaitForChild("StoreAction", 30)
				end
				if v_u_204 and v_u_204:IsA("RemoteFunction") then
					pcall(function()
						-- upvalues: (copy) v_u_204
						return v_u_204:InvokeServer("OfferSeen")
					end)
				end
			end)
		end
	end
	function v_u_50.FormatLeft(p205) -- name: FormatLeft
		local v206 = math.floor(p205)
		local v207 = math.max(0, v206)
		local v208 = v207 / 3600
		local v209 = math.floor(v208)
		local v210 = v207 % 3600 / 60
		local v211 = math.floor(v210)
		local v212 = v207 % 60
		if v209 > 0 then
			return string.format("%d:%02d:%02d", v209, v211, v212)
		else
			return string.format("%d:%02d", v211, v212)
		end
	end
	function v_u_50.DropKey(p213) -- name: DropKey
		-- upvalues: (ref) v_u_50
		if p213 < 5 then
			local v214 = v_u_50.GoldenOffer()
			if v214 and v214.state == "active" then
				return v214.key
			end
		end
		return p213 >= 5 and "drop_golden5" or "drop_golden"
	end
	function v_u_50.DropInfo(p215) -- name: DropInfo
		-- upvalues: (ref) v_u_12
		local v216 = v_u_12.DROPS
		local v217 = p215 or "golden"
		local v218
		if type(v216) == "table" then
			local v219 = v216.kinds
			v218 = type(v219) == "table" and v216.kinds[v217] or (v216[v217] or nil)
		else
			v218 = nil
		end
		return type(v218) ~= "table" and {} or v218
	end
	local v_u_220 = {}
	local v_u_221 = {}
	local v_u_222 = {
		2,
		5,
		15,
		30
	}
	function v_u_50.ProductId(p223) -- name: productId
		-- upvalues: (ref) v_u_11
		local v224 = v_u_11.ids[p223]
		return type(v224) ~= "number" and 0 or v224
	end
	function v_u_50.Price(p_u_225) -- name: Price
		-- upvalues: (copy) v_u_220, (ref) v_u_11, (copy) v_u_221, (copy) v_u_222, (ref) v_u_1, (ref) v_u_50
		local v226 = v_u_220[p_u_225]
		if v226 then
			return v226
		end
		local v227 = v_u_11.ids[p_u_225]
		local v_u_228 = type(v227) ~= "number" and 0 or v227
		if v_u_228 > 0 and not (v_u_220[p_u_225] or v_u_221[p_u_225]) then
			v_u_221[p_u_225] = true
			task.spawn(function()
				-- upvalues: (ref) v_u_222, (ref) v_u_1, (copy) v_u_228, (ref) v_u_220, (copy) p_u_225, (ref) v_u_221, (ref) v_u_50
				for v229 = 1, #v_u_222 + 1 do
					local function v230()
						-- upvalues: (ref) v_u_1, (ref) v_u_228
						return v_u_1:GetProductInfo(v_u_228, Enum.InfoType.Product)
					end
					local v231, v232 = pcall(v230)
					if v231 and type(v232) == "table" then
						local v233 = v232.PriceInRobux
						if type(v233) == "number" then
							v_u_220[p_u_225] = v232.PriceInRobux
							v_u_221[p_u_225] = nil
							v_u_50.Changed:Fire()
							return
						end
					end
					local v234 = v_u_222[v229]
					if not v234 then
						break
					end
					task.wait(v234)
				end
				v_u_221[p_u_225] = nil
			end)
		end
		return nil
	end
	function v_u_50.PriceAmount(p235) -- name: PriceAmount
		-- upvalues: (ref) v_u_50
		local v236 = v_u_50.Price(p235)
		return not v236 and "\226\128\166" or tostring(v236)
	end
	function v_u_50.PriceText(p237) -- name: PriceText
		-- upvalues: (ref) v_u_50
		return v_u_50.ROBUX .. " " .. v_u_50.PriceAmount(p237)
	end
	function v_u_50.ItemKey(p238) -- name: ItemKey
		return "unlock_" .. p238
	end
	function v_u_50.CanBuy(p239) -- name: CanBuy
		-- upvalues: (ref) v_u_11, (ref) v_u_54
		local v240 = v_u_11.ids[p239]
		return (type(v240) ~= "number" and 0 or v240) > 0 and true or v_u_54
	end
	task.delay(3, function()
		-- upvalues: (ref) v_u_11, (copy) v_u_220, (copy) v_u_221, (copy) v_u_222, (ref) v_u_1, (ref) v_u_50
		for v_u_241 in v_u_11.ids do
			local v242 = v_u_11.ids[v_u_241]
			local v_u_243 = type(v242) ~= "number" and 0 or v242
			if v_u_243 <= 0 or v_u_220[v_u_241] then
				continue
			end
			if v_u_221[v_u_241] then
				continue
			end
			v_u_221[v_u_241] = true
			task.spawn(function()
				-- upvalues: (ref) v_u_222, (ref) v_u_1, (copy) v_u_243, (ref) v_u_220, (copy) v_u_241, (ref) v_u_221, (ref) v_u_50
				for v244 = 1, #v_u_222 + 1 do
					local function v245()
						-- upvalues: (ref) v_u_1, (ref) v_u_243
						return v_u_1:GetProductInfo(v_u_243, Enum.InfoType.Product)
					end
					local v246, v247 = pcall(v245)
					if v246 and type(v247) == "table" then
						local v248 = v247.PriceInRobux
						if type(v248) == "number" then
							v_u_220[v_u_241] = v247.PriceInRobux
							v_u_221[v_u_241] = nil
							v_u_50.Changed:Fire()
							return
						end
					end
					local v249 = v_u_222[v244]
					if not v249 then
						break
					end
					task.wait(v249)
				end
				v_u_221[v_u_241] = nil
			end)
		end
	end)
	local v_u_250 = {}
	function v_u_50.Pending(p251) -- name: Pending
		-- upvalues: (copy) v_u_250
		if p251 then
			return v_u_250[p251] ~= nil
		else
			return next(v_u_250) ~= nil
		end
	end
	local v_u_252 = nil
	task.spawn(function()
		-- upvalues: (ref) v_u_4, (ref) v_u_252
		local v253 = v_u_4:WaitForChild("Remotes", 30)
		if v253 then
			v253 = v253:WaitForChild("StoreAction", 30)
		end
		if v253 and v253:IsA("RemoteFunction") then
			v_u_252 = v253
		end
	end)
	function v_u_50.Buy(p_u_254) -- name: Buy
		-- upvalues: (copy) v_u_250, (ref) v_u_50, (ref) v_u_11, (ref) v_u_54, (ref) v_u_252, (copy) p_u_57, (ref) v_u_1, (ref) v_u_53
		if v_u_250[p_u_254] then
			return false
		end
		if string.sub(p_u_254, 1, 5) == "drop_" and not v_u_50.DropsAllowed() then
			return false
		end
		local v255 = v_u_11.ids[p_u_254]
		local v_u_256 = type(v255) ~= "number" and 0 or v255
		if v_u_54 and (v_u_256 == 0 or (game.GameId ~= v_u_11.universe or v_u_50.ForceMock)) then
			local v_u_257 = v_u_252
			if not v_u_257 then
				p_u_57.Toast("Store not ready yet", "error")
				return false
			end
			v_u_250[p_u_254] = os.clock()
			v_u_50.Changed:Fire()
			task.spawn(function()
				-- upvalues: (copy) v_u_257, (copy) p_u_254, (ref) v_u_250, (ref) v_u_50, (ref) p_u_57
				local function v258()
					-- upvalues: (ref) v_u_257, (ref) p_u_254
					return v_u_257:InvokeServer("Mock", p_u_254)
				end
				local v259, v260, v261 = pcall(v258)
				v_u_250[p_u_254] = nil
				v_u_50.Changed:Fire()
				if not (v259 and v260) then
					p_u_57.Toast("(Studio) mock purchase failed: " .. tostring(v261 or v260), "error")
				end
			end)
			return true
		end
		if v_u_256 == 0 then
			p_u_57.Toast("Not available yet", "warning")
			return false
		end
		v_u_250[p_u_254] = os.clock()
		v_u_50.Changed:Fire()
		local function v262()
			-- upvalues: (ref) v_u_1, (ref) v_u_53, (copy) v_u_256
			v_u_1:PromptProductPurchase(v_u_53, v_u_256)
		end
		local v263, v264 = pcall(v262)
		if v263 then
			return true
		end
		v_u_250[p_u_254] = nil
		v_u_50.Changed:Fire()
		p_u_57.Toast("Couldn\'t open the purchase: " .. tostring(v264), "error")
		return false
	end
	v_u_1.PromptProductPurchaseFinished:Connect(function(p265, p266, p267)
		-- upvalues: (ref) v_u_53, (copy) v_u_250, (ref) v_u_11, (ref) v_u_50, (copy) p_u_57
		if p265 == v_u_53.UserId then
			for v_u_268 in v_u_250 do
				local v269 = v_u_11.ids[v_u_268]
				if (type(v269) ~= "number" and 0 or v269) ~= p266 then
					continue
				end
				if p267 then
					task.delay(20, function()
						-- upvalues: (ref) v_u_250, (copy) v_u_268, (ref) v_u_50, (ref) p_u_57
						if v_u_250[v_u_268] then
							v_u_250[v_u_268] = nil
							v_u_50.Changed:Fire()
							p_u_57.Toast("Your purchase is still processing: it will arrive shortly", "info")
						end
					end)
				else
					v_u_250[v_u_268] = nil
					v_u_50.Changed:Fire()
				end
			end
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_4, (copy) v_u_250, (ref) v_u_50, (copy) v_u_150
		local v270 = v_u_4:WaitForChild("Remotes", 30)
		if v270 then
			v270 = v270:WaitForChild("EconomyEvent", 30)
		end
		if v270 and v270:IsA("RemoteEvent") then
			v270.OnClientEvent:Connect(function(p271, p272)
				-- upvalues: (ref) v_u_250, (ref) v_u_50, (ref) v_u_150
				if type(p271) == "string" then
					local v273 = type(p272) ~= "table" and {} or p272
					if p271 == "Unlocked" or p271 == "Credit" then
						for v274 in v_u_250 do
							if string.sub(v274, 1, 7) ~= "unlock_" then
								continue
							end
							v_u_250[v274] = nil
							v_u_50.Changed:Fire()
						end
					elseif p271 == "Drop" then
						for v275 in v_u_250 do
							if string.sub(v275, 1, 5) ~= "drop_" then
								continue
							end
							v_u_250[v275] = nil
							v_u_50.Changed:Fire()
						end
						v_u_150(v273)
					elseif p271 == "StreakRestored" or p271 == "StreakCredit" then
						for v276 in v_u_250 do
							if string.sub(v276, 1, 7) ~= "streak_" then
								continue
							end
							v_u_250[v276] = nil
							v_u_50.Changed:Fire()
						end
					elseif p271 == "TribePass" then
						for v277 in v_u_250 do
							if string.sub(v277, 1, 6) ~= "tribe_" then
								continue
							end
							v_u_250[v277] = nil
							v_u_50.Changed:Fire()
						end
					end
					v_u_50.Event:Fire(p271, v273)
					if p271 == "Unlocked" then
						local v278 = v273.item
						if type(v278) == "string" then
							v_u_50.Celebrate:Fire(v273.item)
						end
					end
					v_u_50.Changed:Fire()
				end
			end)
		end
	end)
	v_u_58.MatchEvent:Connect(function(p279, p280)
		-- upvalues: (copy) v_u_150
		if p279 == "MatchEnd" and type(p280) == "table" then
			local v281 = p280.you
			if type(v281) == "table" then
				v_u_150(p280.you.drop)
			end
		end
	end)
	local v_u_282 = {}
	function v_u_50.Upgrading(p283) -- name: Upgrading
		-- upvalues: (copy) v_u_282
		return v_u_282[p283] == true
	end
	function v_u_50.Upgrade() -- name: Upgrade
		-- upvalues: (copy) v_u_282, (ref) v_u_50, (copy) v_u_58, (copy) p_u_57, (copy) v_u_70
		-- failed to decompile function 73: called `Option::unwrap()` on a `None` value
	end
	function v_u_50.StreakOffer() -- name: StreakOffer
		-- upvalues: (copy) v_u_58, (ref) v_u_9, (ref) v_u_6
		local v284 = v_u_58.Profile.streakRestore
		if type(v284) == "table" then
			local v285 = v284.lost
			if type(v285) == "number" and v284.lost >= v_u_9.RESTORE_MIN_STREAK then
				local v286 = v284.expiresAt
				if type(v286) == "number" and v_u_6:GetServerTimeNow() >= v284.expiresAt then
					return false
				else
					return v284
				end
			end
		end
		return false
	end
	local v_u_287 = false
	function v_u_50.SetRevealShowing(p288) -- name: SetRevealShowing
		-- upvalues: (ref) v_u_287, (ref) v_u_50
		if v_u_287 ~= p288 then
			v_u_287 = p288
			v_u_50.RevealChanged:Fire(p288)
		end
	end
	function v_u_50.RevealShowing() -- name: RevealShowing
		-- upvalues: (ref) v_u_287
		return v_u_287
	end
	v_u_58.ProfileChanged:Connect(function()
		-- upvalues: (ref) v_u_50
		v_u_50.Changed:Fire()
	end)
	local v_u_294 = {
		["new"] = function() -- name: new
			local v289 = {
				["items"] = nil,
				["restricted"] = false,
				["items"] = {
					["crossbow"] = {
						["shards"] = 6,
						["level"] = 0
					}
				}
			}
			return v289
		end,
		["mid"] = function() -- name: mid
			local v290 = {
				["restricted"] = false,
				["items"] = nil,
				["items"] = {
					["short_bow"] = {
						["shards"] = 40,
						["level"] = 3
					},
					["bronze_sword"] = {
						["shards"] = 12,
						["level"] = 2
					},
					["throwing_knives"] = {
						["shards"] = 10,
						["level"] = 1
					},
					["bandage"] = {
						["shards"] = 30,
						["level"] = 4
					},
					["war_club"] = {
						["shards"] = 3,
						["level"] = 1
					},
					["crossbow"] = {
						["shards"] = 8,
						["level"] = 1
					},
					["obsidian_dagger"] = {
						["shards"] = 0,
						["level"] = 5
					},
					["bear_trap"] = {
						["shards"] = 4,
						["level"] = 1
					},
					["spear"] = {
						["shards"] = 14,
						["level"] = 0
					},
					["longbow"] = {
						["shards"] = 30,
						["level"] = 0
					},
					["musket"] = {
						["shards"] = 4,
						["level"] = 0
					},
					["healing_herbs"] = {
						["shards"] = 9,
						["level"] = 0
					}
				}
			}
			return v290
		end,
		["maxed"] = function() -- name: maxed
			-- upvalues: (copy) v_u_59, (ref) v_u_50
			local v291 = {}
			for _, v292 in v_u_59.AllItems() do
				v291[v292.id] = {
					["shards"] = 0,
					["level"] = nil,
					["level"] = v_u_50.MAX_LEVEL
				}
			end
			return {
				["items"] = nil,
				["restricted"] = false,
				["items"] = v291
			}
		end,
		["restricted"] = function()
			-- upvalues: (copy) v_u_294
			local v293 = v_u_294.mid()
			v293.restricted = true
			return v293
		end
	}
	function v_u_50.SetMock(p295) -- name: SetMock
		-- upvalues: (copy) v_u_294, (ref) v_u_50
		if type(p295) == "string" and v_u_294[p295] then
			v_u_50.Mock = v_u_294[p295]()
		elseif type(p295) == "table" then
			local v296 = v_u_50
			local v297 = {}
			local v298 = p295.items
			v297.items = type(v298) ~= "table" and {} or p295.items
			v297.restricted = p295.restricted
			v296.Mock = v297
		else
			v_u_50.Mock = nil
		end
		v_u_50.Changed:Fire()
	end
	function p_u_57.Debug.store(p299, p300)
		-- upvalues: (ref) v_u_50, (copy) v_u_250, (ref) v_u_174, (copy) v_u_58, (ref) v_u_12
		if p299 == "mock" then
			v_u_50.ForceMock = p300 == true
		elseif p299 == "buy" then
			v_u_50.Buy(p300)
		elseif p299 == "celebrate" then
			v_u_50.Celebrate:Fire(p300)
		end
		local v301 = {}
		for v302 in v_u_250 do
			table.insert(v301, v302)
		end
		local v303 = {
			["mock"] = v_u_50.ForceMock,
			["pending"] = v301,
			["offer"] = v_u_50.StreakOffer(),
			["dropsAllowed"] = v_u_50.DropsAllowed(),
			["policy"] = v_u_174 == nil and "?" or v_u_174
		}
		local v304 = v_u_58.Profile.canBuyDrops
		if type(v304) ~= "boolean" then
			v304 = nil
		end
		local v305
		if v304 == nil then
			v305 = "none"
		else
			v305 = v_u_58.Profile.canBuyDrops
			if type(v305) ~= "boolean" then
				v305 = nil
			end
		end
		v303.canBuyDrops = v305
		v303.shards = v_u_12.FALLBACK and "fallback" or "Shared.Shards"
		return v303
	end
end
return v_u_50