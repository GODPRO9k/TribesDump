local v_u_1 = game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("TextService")
local v_u_4 = game:GetService("TextChatService")
local v_u_5 = game:GetService("StarterGui")
local v_u_6 = nil
local function v_u_11() -- name: restoreChat
	-- upvalues: (ref) v_u_6, (copy) v_u_4, (copy) v_u_5
	local v_u_7 = v_u_6
	if v_u_7 then
		v_u_6 = nil
		local function v10()
			-- upvalues: (ref) v_u_4, (copy) v_u_7, (ref) v_u_5
			local v8 = v_u_4:FindFirstChildOfClass("ChatWindowConfiguration")
			local v9 = v_u_4:FindFirstChildOfClass("ChatInputBarConfiguration")
			if v8 and v_u_7.window ~= nil then
				v8.Enabled = v_u_7.window
			end
			if v9 and v_u_7.bar ~= nil then
				v9.Enabled = v_u_7.bar
			end
			if v_u_7.core ~= nil then
				v_u_5:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, v_u_7.core)
			end
		end
		pcall(v10)
	end
end
local v_u_12 = {}
local v13 = Color3.fromRGB
local v_u_14 = {
	["bow"] = v13(56, 189, 248),
	["gun"] = v13(251, 146, 60),
	["melee"] = v13(248, 113, 113),
	["throwable"] = v13(167, 139, 250),
	["utility"] = v13(250, 204, 21),
	["healing"] = v13(74, 222, 128),
	["armor"] = v13(148, 197, 255)
}
function v_u_12.Init(p_u_15) -- name: Init
	-- upvalues: (copy) v_u_14, (copy) v_u_3, (copy) v_u_12, (copy) v_u_2, (copy) v_u_1, (ref) v_u_6, (copy) v_u_4, (copy) v_u_5, (copy) v_u_11
	local v_u_16 = p_u_15.UI
	local v_u_17 = p_u_15.Theme
	local v_u_18 = p_u_15.State
	local v_u_19 = p_u_15.WeaponInfo
	local v_u_20 = p_u_15.WeaponIcon
	local v_u_21 = v_u_17.Colors
	local v_u_22 = v_u_17.Fonts
	local v_u_23 = p_u_15.Economy
	local function v_u_30(p24, p25) -- name: iconOpts
		-- upvalues: (copy) v_u_19, (ref) v_u_14, (copy) v_u_21
		local v26 = {
			["outline"] = false,
			["glow"] = false,
			["outlineColor"] = nil,
			["outlineScale"] = 1.035,
			["outlineTransparency"] = 0.5
		}
		local v27 = v_u_19.Get(p24)
		v26.outlineColor = (v27 and v_u_14[v27.category] or v_u_21.Accent):Lerp(Color3.new(1, 1, 1), 0.55)
		if p25 then
			for v28, v29 in p25 do
				v26[v28] = v29
			end
		end
		return v26
	end
	local v_u_31 = v_u_16.Window({
		["Name"] = "Loadout",
		["Title"] = "LOADOUT",
		["Subtitle"] = "Pick any gear up to 12 points.",
		["Size"] = nil,
		["HeaderHeight"] = 80,
		["OpenSound"] = "Armory_Open",
		["Parent"] = nil,
		["OnCloseRequested"] = nil,
		["Size"] = UDim2.fromOffset(1280, 720),
		["Parent"] = p_u_15.Canvas.Menus,
		["OnCloseRequested"] = function() -- name: OnCloseRequested
			-- upvalues: (copy) p_u_15
			p_u_15.MenuManager.Close("Loadout")
		end
	})
	local v32 = v_u_31.Content
	local v_u_33 = {
		["items"] = nil,
		["armor"] = false,
		["ammo"] = nil,
		["items"] = {},
		["ammo"] = {}
	}
	local function v_u_41(p34) -- name: missingAmmo
		-- upvalues: (copy) v_u_19
		local v35 = v_u_19.AmmoNeeded(p34)
		local v36 = {}
		for _, v37 in v_u_19.AmmoTypes() do
			if v37.optional or (not v35[v37.id] or (p34.ammo[v37.id] or 0) >= 1) then
				continue
			end
			local v38 = false
			for _, v39 in v_u_19.AmmoTypes() do
				if v38 then
					continue
				end
				if v39.as == v37.id then
					v38 = (p34.ammo[v39.id] or 0) >= 1
				else
					v38 = false
				end
			end
			if v38 then
				break
			end
			local v40 = v37.id
			table.insert(v36, v40)
		end
		return v36
	end
	local function v_u_46(p42) -- name: ammoExtra
		-- upvalues: (copy) v_u_19, (ref) v_u_33, (copy) v_u_41
		local v43
		if v_u_19.IsArmor(p42) then
			v43 = nil
		else
			v43 = v_u_19.AmmoOf(p42)
		end
		if v43 then
			v43 = v_u_19.AmmoDef(v43)
		end
		if not v43 then
			return 0, nil
		end
		local v44 = {
			["items"] = table.clone(v_u_33.items),
			["armor"] = v_u_33.armor,
			["ammo"] = v_u_33.ammo
		}
		local v45 = v44.items
		table.insert(v45, p42)
		return not table.find(v_u_41(v44), v43.id) and 0 or v43.points, v43
	end
	local function v_u_51(p47) -- name: ammoUser
		-- upvalues: (copy) v_u_19, (ref) v_u_33
		local v48 = v_u_19.AmmoDef(p47)
		for _, v49 in v_u_33.items do
			local v50 = v_u_19.AmmoOf(v49)
			if not v50 or v50 ~= p47 and (not v48 or v48.as ~= v50) then
				continue
			end
			return v49
		end
		return nil
	end
	local function v_u_54(p52) -- name: ammoFloor
		-- upvalues: (ref) v_u_33, (copy) v_u_41
		if (v_u_33.ammo[p52] or 0) ~= 1 then
			return false
		end
		local v53 = {
			["items"] = v_u_33.items,
			["armor"] = v_u_33.armor,
			["ammo"] = table.clone(v_u_33.ammo)
		}
		v53.ammo[p52] = nil
		return #v_u_41(v53) > #v_u_41(v_u_33)
	end
	local function v_u_60(p55) -- name: canAdd
		-- upvalues: (ref) v_u_33, (copy) v_u_23, (copy) v_u_19, (copy) v_u_46
		if table.find(v_u_33.items, p55) ~= nil and true or v_u_33.armor == p55 then
			return false, "in", 0
		elseif v_u_23.IsLocked(p55) then
			return false, "locked", 0
		else
			local v56 = v_u_19.Points(p55)
			local v57 = v_u_19.Cost(v_u_33)
			if v_u_19.IsArmor(p55) and v_u_33.armor then
				v57 = v57 - v_u_19.Points(v_u_33.armor)
			elseif not v_u_19.IsArmor(p55) and #v_u_33.items >= v_u_19.MaxItems() then
				return false, "full", 0
			end
			local v58 = v_u_46(p55)
			local v59 = v57 + v56 + v58 - v_u_19.Budget()
			if v59 > 0 then
				return false, v57 + v56 <= v_u_19.Budget() and "ammo" or "points", v59
			else
				return true, nil, 0
			end
		end
	end
	local v_u_61 = v_u_16.new("Frame", {
		["Name"] = "Slots",
		["Position"] = UDim2.fromOffset(300, 12),
		["Size"] = UDim2.new(0, 700, 0, 56),
		v_u_16.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
		["Parent"] = v_u_31.Header
	})
	local v_u_62 = v_u_33
	local v_u_63 = nil
	local v_u_64 = nil
	local v_u_65 = {}
	local v_u_66 = 1
	local v_u_67 = nil
	local v_u_68 = {}
	local v_u_69 = nil
	local v_u_70 = nil
	local v_u_71 = nil
	local v_u_72 = nil
	local v_u_73 = nil
	local v_u_74 = 1
	local function v_u_75() -- name: budget
		-- upvalues: (copy) v_u_19
		return v_u_19.Budget()
	end
	local v_u_76 = 0
	local v_u_77 = false
	local function v_u_80(p78) -- name: copyDraft
		-- upvalues: (copy) v_u_19
		local v79 = v_u_19.Normalize(p78)
		return {
			["items"] = table.clone(v79.items),
			["armor"] = v79.armor,
			["ammo"] = table.clone(v79.ammo)
		}
	end
	local v_u_81 = "all"
	for v_u_82 = 1, 5 do
		local v_u_83 = v_u_16.new("TextButton", {
			["Name"] = "Slot" .. v_u_82,
			["Size"] = UDim2.fromOffset(140, 56),
			["BackgroundColor3"] = v_u_21.Raised,
			["BackgroundTransparency"] = 0.35,
			["LayoutOrder"] = v_u_82,
			v_u_16.Corner(12),
			["Parent"] = v_u_61
		})
		local v84 = v_u_16.Stroke(v_u_21.Stroke, 1, 0.9)
		v84.Parent = v_u_83
		local v85 = v_u_16.new("Frame", {
			["Name"] = "Tile",
			["Position"] = UDim2.fromOffset(6, 6),
			["Size"] = UDim2.fromOffset(44, 44),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			v_u_16.Corner(9),
			["Parent"] = v_u_83
		})
		local v86 = v_u_21.Accent
		local v87 = v_u_16.Gradient(v86:Lerp(v_u_21.Panel, 0.7), v_u_21.PanelHi:Lerp(v_u_21.Panel, 0.6), 115)
		v87.Parent = v85
		local v88 = v_u_16.new("Frame", {
			["Name"] = "Icon",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromScale(0.95, 0.95),
			["Parent"] = v85
		})
		local v_u_89 = v_u_16.new("TextLabel", {
			["Name"] = "SlotName",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 15,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(58, 8),
			["Size"] = UDim2.new(1, -86, 0, 20),
			["FontFace"] = v_u_22.Bold,
			["TextColor3"] = v_u_21.Text,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v_u_83
		})
		local v90 = v_u_16.new("TextLabel", {
			["Name"] = "Sub",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 12,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(58, 30),
			["Size"] = UDim2.new(1, -62, 0, 16),
			["FontFace"] = v_u_22.Heavy,
			["TextColor3"] = v_u_21.TextMuted,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v_u_83
		})
		local v_u_91 = v_u_16.new("TextButton", {
			["Name"] = "Rename",
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(1, -4, 1, -4),
			["Size"] = UDim2.fromOffset(26, 26),
			["BackgroundColor3"] = v_u_21.Void,
			["BackgroundTransparency"] = 0.6,
			["Visible"] = false,
			["ZIndex"] = 3,
			v_u_16.Corner(v_u_17.Radius.Pill),
			["Parent"] = v_u_83
		})
		v_u_16.Icon("pencil", 16, v_u_21.Text, {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Parent"] = v_u_91
		})
		local v_u_92 = v_u_16.new("TextBox", {
			["Name"] = "NameBox",
			["Position"] = UDim2.fromOffset(54, 5),
			["Size"] = UDim2.new(1, -58, 0, 26),
			["Text"] = "",
			["PlaceholderText"] = "LOADOUT " .. v_u_82,
			["PlaceholderColor3"] = v_u_21.TextMuted,
			["ClearTextOnFocus"] = false,
			["FontFace"] = v_u_22.Bold,
			["TextSize"] = 15,
			["TextColor3"] = v_u_21.Text,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["BackgroundColor3"] = v_u_21.Inset,
			["BackgroundTransparency"] = 0.05,
			["Visible"] = false,
			["ZIndex"] = 4,
			v_u_16.Corner(6),
			v_u_16.Padding(0, 6, 0, 6),
			["Parent"] = v_u_83
		})
		v88.Visible = false
		v_u_68[v_u_82] = {
			["btn"] = nil,
			["stroke"] = nil,
			["tile"] = nil,
			["tileGrad"] = nil,
			["icon"] = nil,
			["name"] = nil,
			["sub"] = nil,
			["pencil"] = nil,
			["box"] = nil,
			["shownIcon"] = nil,
			["numL"] = nil,
			["btn"] = v_u_83,
			["stroke"] = v84,
			["tile"] = v85,
			["tileGrad"] = v87,
			["icon"] = v88,
			["name"] = v_u_89,
			["sub"] = v90,
			["pencil"] = v_u_91,
			["box"] = v_u_92,
			["numL"] = v_u_16.new("TextLabel", {
				["Name"] = "Num",
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 22,
				["TextColor3"] = nil,
				["ZIndex"] = 2,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Text"] = tostring(v_u_82),
				["FontFace"] = v_u_22.Display,
				["TextColor3"] = v_u_21.TextDim,
				["Parent"] = v85
			})
		}
		v_u_83.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_82, (ref) v_u_66, (copy) v_u_16, (copy) v_u_83, (copy) p_u_15
			if v_u_82 ~= v_u_66 and not v_u_16.Touch then
				v_u_83.BackgroundTransparency = 0.15
				p_u_15.Sounds.Play("Hover")
			end
		end)
		v_u_83.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_67
			v_u_67()
		end)
		v_u_83.Activated:Connect(function()
			-- upvalues: (ref) v_u_63, (copy) v_u_82, (ref) v_u_66, (copy) v_u_16, (copy) v_u_83, (ref) v_u_64
			if v_u_63 == v_u_82 then
				return
			elseif v_u_82 == v_u_66 then
				v_u_16.Bump(v_u_83, 0.04)
			else
				v_u_64(v_u_82)
			end
		end)
		v_u_91.Activated:Connect(function()
			-- upvalues: (ref) v_u_63, (copy) v_u_82, (copy) v_u_92, (copy) v_u_65, (copy) v_u_18, (copy) v_u_89, (copy) v_u_91, (copy) p_u_15
			if not v_u_63 then
				v_u_63 = v_u_82
				v_u_92.Text = v_u_65[v_u_82] or v_u_18.LoadoutCustomName(v_u_82)
				v_u_92.Visible = true
				v_u_89.Visible = false
				v_u_91.Visible = false
				v_u_92:CaptureFocus()
				p_u_15.Sounds.Play("Click")
			end
		end)
		v_u_92:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (copy) v_u_92
			if utf8.len(v_u_92.Text) and utf8.len(v_u_92.Text) > 16 then
				local v93 = v_u_92
				local v94 = v_u_92.Text
				local v95 = (utf8.offset(v_u_92.Text, 17) or 17) - 1
				v93.Text = string.sub(v94, 1, v95)
			end
		end)
		v_u_92.FocusLost:Connect(function()
			-- upvalues: (ref) v_u_69, (copy) v_u_82
			v_u_69(v_u_82)
		end)
	end
	local function v_u_114() -- name: layoutSlots
		-- upvalues: (copy) v_u_18, (copy) v_u_31, (copy) v_u_16, (copy) v_u_61, (copy) v_u_68, (ref) v_u_66
		local v96 = v_u_18.LoadoutSlotCount()
		local v97 = v_u_31.Holder.Size.X.Offset
		local v98 = v_u_16.Compact and 250 or 290
		local v99 = v_u_16.Compact and 66 or 56
		local v100 = v_u_16.Compact and 7 or 12
		local v101 = v_u_31.CloseButton
		if v101 then
			v101.Size = UDim2.fromOffset(v99, v99)
			v101.Position = UDim2.new(1, -14, 0, v100)
		end
		local v102 = v99 + 26 + 16
		local v103 = v97 - v98 - v102
		local v104 = v96 > 1 and 34 or 0
		local v105 = (v103 - v104 - 6 * (v96 - 1)) / v96
		local v106 = math.floor(v105)
		local v107 = math.clamp(v106, 92, 260)
		v_u_61.Position = UDim2.fromOffset(v98, v100)
		v_u_61.Size = UDim2.fromOffset(v103, v99)
		for v108, v109 in v_u_68 do
			v109.btn.Visible = v108 <= v96
			local v110 = v109.btn
			local v111 = UDim2.fromOffset
			local v112
			if v108 == v_u_66 then
				v112 = v107 + v104
			else
				v112 = v107
			end
			v110.Size = v111(v112, v99)
			local v113 = v99 - 20
			v109.tile.Size = UDim2.fromOffset(v113, v113)
			v109.tile.Position = UDim2.fromOffset(8, 10)
			v109.name.Position = UDim2.fromOffset(v113 + 16, v99 / 2 - 20)
			v109.sub.Position = UDim2.fromOffset(v113 + 16, v99 / 2 + 2)
			v109.box.Position = UDim2.fromOffset(v113 + 12, v99 / 2 - 23)
		end
		v_u_31.Subtitle.Visible = not v_u_16.Compact
	end
	v_u_16.TouchChanged:Connect(function()
		-- upvalues: (copy) v_u_114
		task.defer(v_u_114)
	end)
	local function v145()
		-- upvalues: (copy) v_u_114, (copy) v_u_18, (copy) v_u_19, (copy) v_u_68, (ref) v_u_66, (ref) v_u_62, (copy) v_u_21, (ref) v_u_63, (copy) v_u_65, (copy) v_u_17, (ref) v_u_70, (copy) v_u_16
		v_u_114()
		local v115 = v_u_18.LoadoutSlotCount()
		local v116 = v_u_18.HasLoadoutSlots()
		local v117 = v_u_19.Budget()
		local v118 = math.max(v117, 1)
		for v119, v120 in v_u_68 do
			if v115 < v119 then
				continue
			end
			local v121 = v119 == v_u_66
			local v122
			if v121 then
				v122 = v_u_62
			else
				v122 = v_u_18.LoadoutSlot(v119)
			end
			local v123 = v120.tileGrad
			local v124
			if v121 then
				v124 = ColorSequence.new(v_u_21.AccentDark, v_u_21.AccentDark)
			else
				v124 = ColorSequence.new(v_u_21.Panel, v_u_21.Panel)
			end
			v123.Color = v124
			local v125 = v120.numL
			local v126
			if v121 then
				v126 = v_u_21.Text
			else
				v126 = v_u_21.TextDim
			end
			v125.TextColor3 = v126
			if v_u_63 ~= v119 then
				local v127 = v_u_65[v119]
				local v128 = v120.name
				if not v127 or v127 == "" then
					if v127 == "" then
						v127 = "LOADOUT " .. v119
					else
						v127 = v_u_18.LoadoutName(v119)
					end
				end
				v128.Text = v127
			end
			local v129 = v_u_19.Cost(v122)
			local v130 = v120.btn
			local v131
			if v121 then
				v131 = v_u_21.Accent
			else
				v131 = v_u_21.Raised
			end
			v130.BackgroundColor3 = v131
			v120.btn.BackgroundTransparency = v121 and 0 or 0.35
			local v132 = v120.stroke
			local v133
			if v121 then
				v133 = v_u_17.Lighten(v_u_21.Accent, 0.35)
			else
				v133 = v_u_21.Stroke
			end
			v132.Color = v133
			v120.stroke.Transparency = v121 and 0.2 or 0.9
			local v134 = v120.name
			local v135
			if v121 then
				v135 = v_u_21.Text
			else
				v135 = v_u_21.TextDim
			end
			v134.TextColor3 = v135
			v120.sub.Text = v121 and "\226\156\147 EQUIPPED" or string.format("%d / %d PTS", v129, v118)
			local v136 = v120.sub
			local v137
			if v121 then
				v137 = v_u_21.Text
			else
				v137 = v_u_21.TextMuted
			end
			v136.TextColor3 = v137
			local v138 = v120.pencil
			local v139
			if v121 then
				if v116 then
					v139 = v_u_63 ~= v119
				else
					v139 = v116
				end
			else
				v139 = v121
			end
			v138.Visible = v139
			local v140 = v120.tile.Size.X.Offset + 18
			v120.name.Size = UDim2.new(1, -v140, 0, 20)
			local v141 = v120.sub
			local v142 = UDim2.new
			local v143 = 1
			local v144
			if v121 and v116 then
				v144 = -(v140 + 30)
			else
				v144 = -v140
			end
			v141.Size = v142(v143, v144, 0, 16)
		end
		v_u_70.Text = v_u_16.Gamepad and "YOUR ITEMS  \194\183  HOTBAR ORDER" or "YOUR ITEMS  \194\183  HOTBAR KEYS 1\226\128\1476"
	end
	local v_u_146 = v_u_16.new("Frame", {
		["Name"] = "Left",
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(0, 400, 1, 0),
		["Parent"] = v32
	})
	local v147 = v_u_16.new("TextLabel", {
		["Name"] = "Heading",
		["Size"] = nil,
		["Text"] = "YOUR ITEMS  \194\183  HOTBAR KEYS 1\226\128\1476",
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, -120, 0, 18),
		["FontFace"] = v_u_22.Heavy,
		["TextColor3"] = v_u_21.TextMuted,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_146
	})
	local v_u_148 = v_u_16.new("TextLabel", {
		["Name"] = "Save",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, 0, 0, 0),
		["Size"] = UDim2.fromOffset(120, 18),
		["FontFace"] = v_u_22.Bold,
		["TextColor3"] = v_u_21.TextMuted,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_146
	})
	local v_u_149 = v_u_16.new("Frame", {
		["Name"] = "Points",
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 22),
		["Size"] = UDim2.new(1, 0, 0, 58),
		["Parent"] = v_u_146
	})
	local v_u_150 = v_u_16.new("Frame", {
		["Name"] = "Line",
		["Size"] = UDim2.new(1, -110, 0, 36),
		v_u_16.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Bottom),
		["Parent"] = v_u_149
	})
	local v_u_151 = v_u_16.new("TextLabel", {
		["Name"] = "Number",
		["Size"] = nil,
		["TextXAlignment"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 34,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(112, 36),
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["FontFace"] = v_u_22.Display,
		["Parent"] = v_u_150
	})
	local v_u_152 = 0
	local function v163() -- name: measureNum
		-- upvalues: (ref) v_u_152, (copy) v_u_151, (copy) v_u_22, (ref) v_u_3
		v_u_152 = v_u_152 + 1
		local v_u_153 = v_u_152
		local v_u_154 = v_u_151.Text
		local v_u_155 = v_u_151.TextSize
		task.spawn(function()
			-- upvalues: (copy) v_u_154, (ref) v_u_22, (copy) v_u_155, (ref) v_u_3, (copy) v_u_153, (ref) v_u_152, (ref) v_u_151
			local v_u_156 = Instance.new("GetTextBoundsParams")
			v_u_156.Text = v_u_154
			v_u_156.Font = v_u_22.Display
			v_u_156.Size = v_u_155
			v_u_156.Width = 1000
			local function v157()
				-- upvalues: (ref) v_u_3, (copy) v_u_156
				return v_u_3:GetTextBoundsAsync(v_u_156)
			end
			local v158, v159 = pcall(v157)
			if v158 and (v_u_153 == v_u_152 and v159.X > 4) then
				local v160 = v_u_151
				local v161 = UDim2.fromOffset
				local v162 = v159.X
				v160.Size = v161(math.ceil(v162) + 2, v_u_151.Size.Y.Offset)
			end
		end)
	end
	v_u_151:GetPropertyChangedSignal("Text"):Connect(v163)
	local v_u_164 = v_u_16.new("TextLabel", {
		["Name"] = "Word",
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Text"] = "POINTS",
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(0, 30),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["FontFace"] = v_u_22.Heavy,
		["TextColor3"] = v_u_21.TextDim,
		["Parent"] = v_u_150
	})
	local v_u_165 = v_u_16.new("TextLabel", {
		["Name"] = "Left",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, 0, 0, 12),
		["Size"] = UDim2.fromOffset(110, 22),
		["FontFace"] = v_u_22.Heavy,
		["TextColor3"] = v_u_21.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_149
	})
	local v_u_166 = v_u_16.new("TextLabel", {
		["Name"] = "Helper",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 60),
		["Size"] = UDim2.new(1, 0, 0, 18),
		["FontFace"] = v_u_22.SemiBold,
		["TextColor3"] = v_u_21.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_149
	})
	local v_u_167 = v_u_16.new("Frame", {
		["Name"] = "Bar",
		["Position"] = UDim2.fromOffset(0, 44),
		["Size"] = UDim2.new(1, 0, 0, 10),
		["BackgroundColor3"] = v_u_21.Inset,
		["ClipsDescendants"] = true,
		v_u_16.Corner(v_u_17.Radius.Pill),
		v_u_16.Stroke(v_u_21.Stroke, 1, 0.92),
		["Parent"] = v_u_149
	})
	local v_u_168 = v_u_16.new("Frame", {
		["Name"] = "Ghost",
		["Size"] = UDim2.fromScale(0, 1),
		["BackgroundColor3"] = v_u_21.Accent,
		["BackgroundTransparency"] = 0.6,
		v_u_16.Corner(v_u_17.Radius.Pill),
		["Parent"] = v_u_167
	})
	local v_u_169 = v_u_16.new("Frame", {
		["Name"] = "Fill",
		["Size"] = UDim2.fromScale(0, 1),
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		v_u_16.Corner(v_u_17.Radius.Pill),
		["Parent"] = v_u_167
	})
	local v_u_170 = v_u_16.Gradient(v_u_17.Lighten(v_u_21.Accent, 0.15), v_u_21.Accent, 0)
	v_u_170.Parent = v_u_169
	local v_u_171 = v_u_16.new("Frame", {
		["Name"] = "Ticks",
		["Size"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_167
	})
	local v_u_172 = 0
	local function v_u_175(p173) -- name: buildTicks
		-- upvalues: (ref) v_u_172, (copy) v_u_171, (copy) v_u_16, (copy) v_u_21
		if p173 ~= v_u_172 then
			v_u_172 = p173
			v_u_171:ClearAllChildren()
			for v174 = 1, p173 - 1 do
				v_u_16.new("Frame", {
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.35,
					["ZIndex"] = 3,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0),
					["Position"] = UDim2.fromScale(v174 / p173, 0),
					["Size"] = UDim2.new(0, 2, 1, 0),
					["BackgroundColor3"] = v_u_21.Void,
					["Parent"] = v_u_171
				})
			end
		end
	end
	local v_u_176 = v_u_16.new("Frame", {
		["Name"] = "Rows",
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 88),
		["Size"] = UDim2.new(1, 0, 1, -88),
		["Parent"] = v_u_146
	})
	local v_u_177 = {}
	local v_u_178 = 48
	local v_u_179 = 6
	local v_u_180 = nil
	local function v197(p181) -- name: makeRow
		-- upvalues: (copy) v_u_16, (ref) v_u_178, (copy) v_u_21, (copy) v_u_176, (copy) v_u_22, (copy) v_u_17, (ref) v_u_180
		local v182 = p181 == "armor"
		local v183 = v_u_16.new("Frame", {
			["Name"] = v182 and "Armor" or "Row" .. p181,
			["Size"] = UDim2.new(1, 0, 0, v_u_178),
			["BackgroundColor3"] = v_u_21.Raised,
			["BackgroundTransparency"] = 0.5,
			v_u_16.Corner(12),
			["Parent"] = v_u_176
		})
		v_u_16.Stroke(v_u_21.Stroke, 1, 0.93).Parent = v183
		local v184 = v_u_16.new("Frame", {
			["Name"] = "Tile",
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 4, 0.5, 0),
			["Size"] = UDim2.fromOffset(v_u_178 - 8, v_u_178 - 8),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["BackgroundTransparency"] = 0,
			v_u_16.Corner(9),
			["Parent"] = v183
		})
		local v185 = v_u_21.Accent
		local v186 = v_u_16.Gradient(v185:Lerp(v_u_21.Panel, 0.7), v_u_21.PanelHi:Lerp(v_u_21.Panel, 0.6), 115)
		v186.Parent = v184
		local v187 = v_u_16.Stroke(v_u_21.Stroke, 1, 0.88)
		v187.Parent = v184
		local v188 = v_u_16.new("Frame", {
			["Name"] = "Icon",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 2,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromScale(0.92, 0.92),
			["Parent"] = v184
		})
		local v189 = nil
		local v190 = nil
		local v191 = nil
		if v182 then
			v191 = v_u_16.Image(v_u_16.Assets.Icons.Shield, {
				["Name"] = "Shield",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ImageColor3"] = nil,
				["ImageTransparency"] = 0.3,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromScale(0.45, 0.45),
				["ImageColor3"] = v_u_21.TextMuted,
				["Parent"] = v184
			})
		else
			v189 = v_u_16.new("TextLabel", {
				["Name"] = "Num",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 12,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["ZIndex"] = 3,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(4, 2),
				["Size"] = UDim2.fromOffset(14, 14),
				["Text"] = tostring(p181),
				["FontFace"] = v_u_22.Heavy,
				["TextColor3"] = v_u_21.TextDim,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Parent"] = v184
			})
			v_u_16.TextStroke(v_u_21.Void, 1, 0.4).Parent = v189
			v190 = v_u_16.Icon("plus", 16, v_u_21.TextMuted, {
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Parent"] = v184
			})
		end
		local v192 = v_u_16.new("TextLabel", {
			["Name"] = "ItemName",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 17,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(v_u_178 + 8, 0),
			["Size"] = UDim2.new(1, -(v_u_178 + 130), 1, 0),
			["FontFace"] = v_u_22.Bold,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v183
		})
		local v193 = v_u_16.new("Frame", {
			["Name"] = "Cost",
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -52, 0.5, 0),
			["Size"] = UDim2.fromOffset(52, 24),
			["BackgroundColor3"] = v_u_21.Void,
			["BackgroundTransparency"] = 0.45,
			v_u_16.Corner(v_u_17.Radius.Pill),
			["Parent"] = v183
		})
		local v194 = v_u_16.new("TextLabel", {
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 13,
			["TextColor3"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["FontFace"] = v_u_22.Heavy,
			["TextColor3"] = v_u_21.TextDim,
			["Parent"] = v193
		})
		local v195 = v_u_16.IconButton({
			["Name"] = "RemoveButton",
			["IconName"] = "cross",
			["IconScale"] = 0.4,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Color"] = nil,
			["HoverColor"] = nil,
			["Transparency"] = 0.5,
			["Sound"] = "Close",
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -6, 0.5, 0),
			["Size"] = UDim2.fromOffset(36, 32),
			["Color"] = v_u_21.Raised,
			["HoverColor"] = v_u_21.Danger,
			["Parent"] = v183
		})
		local v_u_196 = {
			["frame"] = nil,
			["tile"] = nil,
			["tileGrad"] = nil,
			["tileStroke"] = nil,
			["num"] = nil,
			["plus"] = nil,
			["shield"] = nil,
			["icon"] = nil,
			["name"] = nil,
			["costPill"] = nil,
			["costLabel"] = nil,
			["remove"] = nil,
			["id"] = nil,
			["frame"] = v183,
			["tile"] = v184,
			["tileGrad"] = v186,
			["tileStroke"] = v187,
			["num"] = v189,
			["plus"] = v190,
			["shield"] = v191,
			["icon"] = v188,
			["name"] = v192,
			["costPill"] = v193,
			["costLabel"] = v194,
			["remove"] = v195
		}
		v195.Activated:Connect(function()
			-- upvalues: (copy) v_u_196, (ref) v_u_180
			if v_u_196.id then
				v_u_180(v_u_196.id)
			end
		end)
		return v_u_196
	end
	v_u_177[1] = v197(1)
	v_u_177[2] = v197(2)
	v_u_177[3] = v197(3)
	v_u_177[4] = v197(4)
	v_u_177[5] = v197(5)
	v_u_177[6] = v197(6)
	local v_u_198 = v197("armor")
	local v_u_199 = v_u_16.new("Frame", {
		["Name"] = "Ammo",
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["Parent"] = v_u_176
	})
	local v_u_200 = v_u_16.new("TextLabel", {
		["Name"] = "Head",
		["Size"] = nil,
		["Text"] = "AMMO  \194\183  1 POINT PER BUNDLE",
		["FontFace"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 18),
		["FontFace"] = v_u_22.Heavy,
		["TextColor3"] = v_u_21.TextMuted,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_199
	})
	local v_u_201 = {}
	local v_u_202 = nil
	local function v_u_228(p_u_203) -- name: ammoRow
		-- upvalues: (copy) v_u_201, (copy) v_u_19, (ref) v_u_14, (copy) v_u_16, (ref) v_u_178, (copy) v_u_21, (copy) v_u_199, (copy) v_u_20, (copy) v_u_22, (ref) v_u_202
		local v204 = v_u_201[p_u_203]
		if v204 then
			return v204
		end
		local v205 = v_u_19.AmmoDef(p_u_203)
		local v206
		if p_u_203 == "arrows" then
			v206 = v_u_14.bow
		else
			v206 = v_u_14.gun
		end
		local v_u_207 = v_u_16.new("Frame", {
			["Name"] = p_u_203,
			["Size"] = UDim2.new(1, 0, 0, v_u_178),
			["BackgroundColor3"] = v_u_21.Raised,
			["BackgroundTransparency"] = 0.35,
			v_u_16.Corner(12),
			["Parent"] = v_u_199
		})
		v_u_16.Stroke(v_u_21.Stroke, 1, 0.93).Parent = v_u_207
		local v208 = v_u_16.new("Frame", {
			["Name"] = "Tile",
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 4, 0.5, 0),
			["Size"] = UDim2.fromOffset(v_u_178 - 8, v_u_178 - 8),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			v_u_16.Corner(9),
			["Parent"] = v_u_207
		})
		v_u_16.Gradient(v206:Lerp(v_u_21.Panel, 0.7), v_u_21.PanelHi:Lerp(v_u_21.Panel, 0.6), 115).Parent = v208
		local v209 = v_u_16.new("Frame", {
			["Name"] = "Icon",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromScale(0.86, 0.86),
			["Parent"] = v208
		})
		v_u_20.Set(v209, "ammo_" .. p_u_203, {
			["outline"] = true,
			["glow"] = false,
			["outlineColor"] = nil,
			["outlineScale"] = 1.04,
			["outlineTransparency"] = 0.5,
			["outlineColor"] = v206:Lerp(Color3.new(1, 1, 1), 0.55)
		})
		if not v209:FindFirstChild("WeaponIcon") or v209:FindFirstChildOfClass("ImageLabel") then
			for _, v210 in v209:GetChildren() do
				v210:Destroy()
			end
			local v211 = v_u_16.Image
			local v212
			if p_u_203 == "arrows" then
				v212 = v_u_16.Assets.Icons.CrossedArrows
			else
				v212 = v_u_16.Assets.Icons.Headshot
			end
			v211(v212, {
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromScale(0.62, 0.62),
				["ImageColor3"] = v206:Lerp(Color3.new(1, 1, 1), 0.35),
				["Parent"] = v209
			})
		end
		local v213 = v_u_16.new("Frame", {
			["Name"] = "NameRow",
			["Position"] = UDim2.fromOffset(v_u_178 + 8, 4),
			["Size"] = UDim2.new(1, -(v_u_178 + 150), 0.55, -4),
			v_u_16.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Bottom),
			["Parent"] = v_u_207
		})
		local v214 = v_u_16.new
		local v215 = "TextLabel"
		local v216 = {
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 17,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(0, 1),
			["AutomaticSize"] = Enum.AutomaticSize.X
		}
		local v217
		if v205 then
			v217 = v205.name or p_u_203
		else
			v217 = p_u_203
		end
		v216.Text = v217
		v216.FontFace = v_u_22.Bold
		v216.Parent = v213
		local v218 = v214(v215, v216)
		local v219 = v_u_16.new("TextLabel", {
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 16,
			["TextColor3"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(0, 1),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["FontFace"] = v_u_22.Heavy,
			["TextColor3"] = v206,
			["Parent"] = v213
		})
		local v220 = v_u_16.new("TextLabel", {
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 12,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextYAlignment"] = nil,
			["TextTruncate"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.new(0, v_u_178 + 8, 0.55, 1),
			["Size"] = UDim2.new(1, -(v_u_178 + 150), 0.45, -4),
			["FontFace"] = v_u_22.SemiBold,
			["TextColor3"] = v_u_21.TextMuted,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextYAlignment"] = Enum.TextYAlignment.Top,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v_u_207
		})
		local function v223(p221, p222) -- name: stepBtn
			-- upvalues: (ref) v_u_16, (ref) v_u_21, (copy) v_u_207
			return v_u_16.IconButton({
				["Name"] = nil,
				["IconName"] = nil,
				["IconScale"] = 0.42,
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["Color"] = nil,
				["Transparency"] = 0.1,
				["Parent"] = nil,
				["Name"] = p221,
				["IconName"] = p222,
				["AnchorPoint"] = Vector2.new(1, 0.5),
				["Size"] = UDim2.fromOffset(38, 34),
				["Color"] = v_u_21.Raised,
				["Parent"] = v_u_207
			})
		end
		local v224 = v223("Plus", "plus")
		local v225 = v_u_16.new("TextLabel", {
			["Name"] = "Count",
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Text"] = "0",
			["FontFace"] = nil,
			["TextSize"] = 22,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Size"] = UDim2.fromOffset(34, 30),
			["FontFace"] = v_u_22.Display,
			["Parent"] = v_u_207
		})
		local v226 = v223("Minus", "minus")
		local v227 = {
			["frame"] = v_u_207,
			["tile"] = v208,
			["icon"] = v209,
			["name"] = v218,
			["amount"] = v219,
			["sub"] = v220,
			["count"] = v225,
			["minus"] = v226,
			["plus"] = v224,
			["t"] = p_u_203
		}
		v_u_201[p_u_203] = v227
		v226.Activated:Connect(function()
			-- upvalues: (ref) v_u_202, (copy) p_u_203
			v_u_202(p_u_203, -1)
		end)
		v224.Activated:Connect(function()
			-- upvalues: (ref) v_u_202, (copy) p_u_203
			v_u_202(p_u_203, 1)
		end)
		return v227
	end
	local v_u_229 = v_u_16.new("Frame", {
		["Name"] = "Right",
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(418, 0),
		["Size"] = UDim2.new(1, -418, 1, 0),
		["Parent"] = v32
	})
	local v230 = v_u_16.new("Frame", {
		["Name"] = "Tabs",
		["Size"] = UDim2.new(1, 0, 0, 40),
		["ZIndex"] = 2,
		v_u_16.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
		["Parent"] = v_u_229
	})
	local v_u_231 = {}
	local v_u_232 = v_u_16.new("ScrollingFrame", {
		["Name"] = "Grid",
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = 5,
		["ScrollBarImageColor3"] = nil,
		["ScrollBarImageTransparency"] = 0.4,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 50),
		["Size"] = UDim2.new(1, 0, 1, -210),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.None,
		["ScrollBarImageColor3"] = v_u_21.TextMuted,
		["Parent"] = v_u_229
	})
	local v_u_233 = v_u_16.new("Frame", {
		["Name"] = "LockedHeader",
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, -8, 0, 44),
		["Parent"] = v_u_232
	})
	v_u_16.new("Frame", {
		["Name"] = "Line",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.88,
		["BorderSizePixel"] = 0,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 4, 0.5, 0),
		["Size"] = UDim2.new(1, -8, 0, 1),
		["BackgroundColor3"] = v_u_21.Text,
		["Parent"] = v_u_233
	})
	v_u_16.new("TextLabel", {
		["Name"] = "Label",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Text"] = "  LOCKED  \194\183  find shards in drops  ",
		["FontFace"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["ZIndex"] = 2,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 4, 0.5, 0),
		["Size"] = UDim2.fromOffset(0, 26),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["FontFace"] = v_u_22.Heavy,
		["TextColor3"] = v_u_21.TextMuted,
		["BackgroundColor3"] = v_u_21.Panel,
		["Parent"] = v_u_233
	})
	v_u_16.Button({
		["Name"] = "OpenCollection",
		["Text"] = "COLLECTION",
		["TextSize"] = 14,
		["Style"] = "Dark",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Parent"] = nil,
		["OnClick"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -4, 0.5, 0),
		["Size"] = UDim2.fromOffset(150, 34),
		["Parent"] = v_u_233,
		["OnClick"] = function() -- name: OnClick
			-- upvalues: (ref) v_u_12
			if v_u_12._openCollection then
				v_u_12._openCollection(nil)
			end
		end
	})
	local v_u_234 = {}
	local v_u_235 = {}
	local v_u_236 = nil
	local function v_u_262(p_u_237) -- name: makeCard
		-- upvalues: (ref) v_u_14, (copy) v_u_21, (copy) v_u_16, (copy) v_u_232, (copy) v_u_22, (copy) v_u_17, (ref) v_u_71, (ref) v_u_72, (copy) p_u_15, (ref) v_u_12, (ref) v_u_236
		local v238 = v_u_14[p_u_237.category] or v_u_21.Accent
		local v239 = v_u_16.new("TextButton", {
			["Name"] = p_u_237.id,
			["Size"] = UDim2.fromOffset(160, v_u_16.Compact and 128 or 164),
			["Parent"] = v_u_232
		})
		local v_u_240 = v_u_16.GetScaleObj(v239, "HoverScale")
		local v241 = v_u_16.new("Frame", {
			["Name"] = "Inner",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["BackgroundTransparency"] = 0.08,
			["ClipsDescendants"] = true,
			v_u_16.Corner(14),
			["Parent"] = v239
		})
		local v242 = v_u_16.Gradient(v238:Lerp(v_u_21.Panel, 0.8), v_u_21.PanelHi:Lerp(v_u_21.Panel, 0.6), 115)
		v242.Parent = v241
		local v243 = v_u_16.Stroke(v_u_21.Stroke, 1, 0.9)
		v243.Parent = v241
		local v244 = v_u_16.Image(v_u_16.Assets.Icons.Glow, {
			["Name"] = "Glow",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 0.72,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(0.5, 0, 0, 58),
			["Size"] = UDim2.fromOffset(170, 150),
			["ImageColor3"] = v238,
			["Parent"] = v241
		})
		local v245 = v_u_16.new("Frame", {
			["Name"] = "Icon",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 2,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 10),
			["Size"] = UDim2.new(1, -22, 1, -62),
			["Parent"] = v241
		})
		local v246 = v_u_16.new("TextLabel", {
			["Name"] = "ItemName",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 17,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Position"] = UDim2.new(0, 12, 1, -48),
			["Size"] = UDim2.new(1, -24, 0, 22),
			["Text"] = p_u_237.name,
			["FontFace"] = v_u_22.Bold,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v241
		})
		local v247 = v_u_16.new("TextLabel", {
			["Name"] = "Status",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 12,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Position"] = UDim2.new(0, 12, 1, -26),
			["Size"] = UDim2.new(1, -24, 0, 16),
			["FontFace"] = v_u_22.Heavy,
			["TextColor3"] = v_u_21.TextMuted,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v241
		})
		local v248 = v_u_16.new("Frame", {
			["Name"] = "Cost",
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, -8, 0, 8),
			["Size"] = UDim2.fromOffset(30, 30),
			["BackgroundColor3"] = v_u_21.Void,
			["BackgroundTransparency"] = 0.3,
			["ZIndex"] = 4,
			v_u_16.Corner(v_u_17.Radius.Pill),
			["Parent"] = v241
		})
		local v249 = v_u_16.new
		local v250 = {
			["Size"] = nil,
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 17,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1)
		}
		local v251 = p_u_237.points
		v250.Text = tostring(v251)
		v250.FontFace = v_u_22.Display
		v250.Parent = v248
		local v252 = v249("TextLabel", v250)
		local v253 = v_u_16.new("Frame", {
			["Name"] = "Check",
			["Position"] = UDim2.fromOffset(8, 8),
			["Size"] = UDim2.fromOffset(26, 26),
			["BackgroundColor3"] = v_u_21.Accent,
			["Visible"] = false,
			["ZIndex"] = 4,
			v_u_16.Corner(v_u_17.Radius.Pill),
			["Parent"] = v241
		})
		v_u_16.Icon("check", 18, v_u_21.Text, {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Parent"] = v253
		})
		local v254 = v_u_16.new("Frame", {
			["Name"] = "Lock",
			["Position"] = UDim2.fromOffset(8, 8),
			["Size"] = UDim2.fromOffset(28, 28),
			["BackgroundColor3"] = v_u_21.Void,
			["BackgroundTransparency"] = 0.25,
			["Visible"] = false,
			["ZIndex"] = 4,
			v_u_16.Corner(v_u_17.Radius.Pill),
			["Parent"] = v241
		})
		v_u_16.Image(v_u_16.Assets.Icons.Lock, {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ImageColor3"] = nil,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(15, 15),
			["ImageColor3"] = v_u_21.TextDim,
			["Parent"] = v254
		})
		local v255 = v_u_16.new("Frame", {
			["Name"] = "ShardBar",
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 12, 1, -8),
			["Size"] = UDim2.new(1, -24, 0, 4),
			["BackgroundColor3"] = v_u_21.Inset,
			["BackgroundTransparency"] = 0.1,
			["Visible"] = false,
			["ZIndex"] = 5,
			v_u_16.Corner(v_u_17.Radius.Pill),
			["Parent"] = v241
		})
		local v256 = v_u_16.new("Frame", {
			["Name"] = "Fill",
			["Size"] = UDim2.fromScale(0, 1),
			["BackgroundColor3"] = v_u_21.Accent,
			["ZIndex"] = 5,
			v_u_16.Corner(v_u_17.Radius.Pill),
			["Parent"] = v255
		})
		local v257 = v_u_16.new("Frame", {
			["Name"] = "Level",
			["Position"] = UDim2.fromOffset(8, 8),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromOffset(0, 24),
			["BackgroundColor3"] = v_u_21.Void,
			["BackgroundTransparency"] = 0.3,
			["Visible"] = false,
			["ZIndex"] = 4,
			v_u_16.Corner(v_u_17.Radius.Pill),
			v_u_16.Padding(0, 8, 0, 8),
			v_u_16.List(Enum.FillDirection.Horizontal, 3, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
			["Parent"] = v241
		})
		local v258 = v_u_16.Icon("chevUp", 11, v_u_21.Text, {
			["Name"] = "Ready",
			["LayoutOrder"] = 0,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["Parent"] = v257
		})
		v258.Visible = false
		local v259 = v_u_16.new("TextLabel", {
			["Name"] = "Text",
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["Text"] = "LV 1",
			["RichText"] = true,
			["FontFace"] = nil,
			["TextSize"] = 14,
			["LayoutOrder"] = 1,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromScale(0, 1),
			["FontFace"] = v_u_22.Display,
			["Parent"] = v257
		})
		local v260 = v_u_16.new("Frame", {
			["Name"] = "Flash",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["BackgroundTransparency"] = 1,
			["ZIndex"] = 6,
			v_u_16.Corner(14),
			["Parent"] = v241
		})
		local v_u_261 = {
			["id"] = nil,
			["holder"] = nil,
			["scale"] = nil,
			["inner"] = nil,
			["grad"] = nil,
			["stroke"] = nil,
			["glow"] = nil,
			["icon"] = nil,
			["costBadge"] = nil,
			["costText"] = nil,
			["check"] = nil,
			["lock"] = nil,
			["lv"] = nil,
			["lvText"] = nil,
			["readyDot"] = nil,
			["cbar"] = nil,
			["cfill"] = nil,
			["nameL"] = nil,
			["status"] = nil,
			["flash"] = nil,
			["rendered"] = false,
			["visible"] = true,
			["hover"] = false,
			["y"] = 0,
			["id"] = p_u_237.id,
			["holder"] = v239,
			["scale"] = v_u_240,
			["inner"] = v241,
			["grad"] = v242,
			["stroke"] = v243,
			["glow"] = v244,
			["icon"] = v245,
			["costBadge"] = v248,
			["costText"] = v252,
			["check"] = v253,
			["lock"] = v254,
			["lv"] = v257,
			["lvText"] = v259,
			["readyDot"] = v258,
			["cbar"] = v255,
			["cfill"] = v256,
			["nameL"] = v246,
			["status"] = v247,
			["flash"] = v260
		}
		v239.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_16, (copy) v_u_261, (ref) v_u_71, (copy) p_u_237, (ref) v_u_72, (ref) p_u_15, (copy) v_u_240, (ref) v_u_17, (ref) v_u_12
			if not v_u_16.Touch then
				v_u_261.hover = true
				v_u_71 = p_u_237.id
				v_u_72 = p_u_237.id
				p_u_15.Sounds.Play("Hover")
				v_u_16.Tween(v_u_240, v_u_17.Tween.PopSmall, {
					["Scale"] = 1.035
				})
				v_u_12._paintCard(v_u_261)
				v_u_12._paintDetail()
				v_u_12._paintPoints()
			end
		end)
		v239.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_261, (ref) v_u_71, (copy) p_u_237, (ref) v_u_16, (copy) v_u_240, (ref) v_u_17, (ref) v_u_12
			v_u_261.hover = false
			if v_u_71 == p_u_237.id then
				v_u_71 = nil
			end
			v_u_16.Tween(v_u_240, v_u_17.Tween.Fast, {
				["Scale"] = 1
			})
			v_u_12._paintCard(v_u_261)
			v_u_12._paintPoints()
		end)
		v239.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_16, (copy) v_u_240, (ref) v_u_17
			v_u_16.Tween(v_u_240, v_u_17.Tween.Instant, {
				["Scale"] = 0.97
			})
		end)
		v239.MouseButton1Up:Connect(function()
			-- upvalues: (ref) v_u_16, (copy) v_u_240, (ref) v_u_17, (copy) v_u_261
			v_u_16.Tween(v_u_240, v_u_17.Tween.PopSmall, {
				["Scale"] = v_u_261.hover and 1.035 or 1
			})
		end)
		v239.SelectionGained:Connect(function()
			-- upvalues: (copy) v_u_261, (ref) v_u_71, (copy) p_u_237, (ref) v_u_72, (ref) v_u_12
			v_u_261.hover = true
			v_u_71 = p_u_237.id
			v_u_72 = p_u_237.id
			v_u_12._paintCard(v_u_261)
			v_u_12._paintDetail()
			v_u_12._paintPoints()
		end)
		v239.SelectionLost:Connect(function()
			-- upvalues: (copy) v_u_261, (ref) v_u_71, (copy) p_u_237, (ref) v_u_12
			v_u_261.hover = false
			if v_u_71 == p_u_237.id then
				v_u_71 = nil
			end
			v_u_12._paintCard(v_u_261)
			v_u_12._paintPoints()
		end)
		v239.Activated:Connect(function()
			-- upvalues: (ref) v_u_72, (copy) p_u_237, (ref) v_u_236, (copy) v_u_261
			v_u_72 = p_u_237.id
			v_u_236(p_u_237.id, v_u_261)
		end)
		return v_u_261
	end
	local v_u_263 = v_u_16.Panel({
		["Name"] = "Detail",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundTransparency"] = 0.2,
		["Radius"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, 156),
		["Radius"] = UDim.new(0, 14),
		["Parent"] = v_u_229
	})
	local v_u_264 = v_u_16.new("Frame", {
		["Name"] = "Preview",
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 8, 0.5, 0),
		["Size"] = UDim2.fromOffset(140, 140),
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["ClipsDescendants"] = true,
		v_u_16.Corner(12),
		["Parent"] = v_u_263
	})
	local v265 = v_u_21.Accent
	local v_u_266 = v_u_16.Gradient(v265:Lerp(v_u_21.Panel, 0.75), v_u_21.PanelHi:Lerp(v_u_21.Panel, 0.6), 115)
	v_u_266.Parent = v_u_264
	local v_u_267 = v_u_16.Image(v_u_16.Assets.Icons.Glow, {
		["Name"] = "Glow",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ImageColor3"] = nil,
		["ImageTransparency"] = 0.6,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(1.3, 1.3),
		["ImageColor3"] = v_u_21.Accent,
		["Parent"] = v_u_264
	})
	local v_u_268 = v_u_16.new("Frame", {
		["Name"] = "Icon",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(0.92, 0.92),
		["Parent"] = v_u_264
	})
	local v_u_269 = v_u_16.new("Frame", {
		["Name"] = "Text",
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(160, 12),
		["Size"] = UDim2.new(1, -600, 1, -24),
		["Parent"] = v_u_263
	})
	local v_u_270 = v_u_16.new("TextLabel", {
		["Name"] = "ItemName",
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 24,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 28),
		["FontFace"] = v_u_22.Display,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Parent"] = v_u_269
	})
	local v_u_271 = v_u_16.new("TextLabel", {
		["Name"] = "Sub",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 12,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 30),
		["Size"] = UDim2.new(1, 0, 0, 16),
		["FontFace"] = v_u_22.Heavy,
		["TextColor3"] = v_u_21.TextMuted,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Parent"] = v_u_269
	})
	local v_u_272 = v_u_16.new("TextLabel", {
		["Name"] = "Desc",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextTruncate"] = nil,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 54),
		["Size"] = UDim2.new(1, 0, 1, -54),
		["FontFace"] = v_u_22.Medium,
		["TextColor3"] = v_u_21.TextDim,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextYAlignment"] = Enum.TextYAlignment.Top,
		["Parent"] = v_u_269
	})
	local v_u_273 = v_u_16.new("Frame", {
		["Name"] = "Stats",
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -168, 0.5, 0),
		["Size"] = UDim2.fromOffset(262, 84),
		v_u_16.List(Enum.FillDirection.Vertical, 8, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
		["Parent"] = v_u_263
	})
	local v_u_274 = v147
	local v_u_275 = v_u_178
	local v_u_276 = v_u_152
	local v_u_277 = v145
	local v_u_278 = {}
	for v279 = 1, 3 do
		local v280 = v_u_16.new("Frame", {
			["Name"] = "Stat" .. v279,
			["Size"] = UDim2.new(1, 0, 0, 20),
			["LayoutOrder"] = v279,
			["Parent"] = v_u_273
		})
		v_u_278[v279] = {
			["frame"] = v280,
			["label"] = v_u_16.new("TextLabel", {
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 12,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["Parent"] = nil,
				["Size"] = UDim2.fromOffset(70, 20),
				["FontFace"] = v_u_22.Heavy,
				["TextColor3"] = v_u_21.TextMuted,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Parent"] = v280
			}),
			["bar"] = v_u_16.Bar({
				["Position"] = nil,
				["Size"] = nil,
				["Color"] = nil,
				["Stroke"] = false,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(72, 7),
				["Size"] = UDim2.fromOffset(92, 7),
				["Color"] = v_u_21.Accent,
				["Parent"] = v280
			}),
			["value"] = v_u_16.new("TextLabel", {
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 12,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.new(1, 0, 0, 0),
				["Size"] = UDim2.fromOffset(92, 20),
				["FontFace"] = v_u_22.Bold,
				["TextColor3"] = v_u_21.TextDim,
				["TextXAlignment"] = Enum.TextXAlignment.Right,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v280
			})
		}
	end
	local v_u_281 = v_u_16.Button({
		["Name"] = "Action",
		["Text"] = "ADD",
		["TextSize"] = 20,
		["Style"] = "Primary",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -12, 0.5, 0),
		["Size"] = UDim2.fromOffset(144, 56),
		["Parent"] = v_u_263
	})
	local function v_u_309() -- name: layoutWindow
		-- upvalues: (copy) v_u_16, (copy) v_u_31, (copy) v_u_114, (ref) v_u_274, (copy) v_u_149, (copy) v_u_148, (copy) v_u_229, (copy) v_u_146, (copy) v_u_151, (copy) v_u_150, (copy) v_u_164, (copy) v_u_165, (copy) v_u_167, (copy) v_u_166, (copy) v_u_176, (ref) v_u_276, (copy) v_u_22, (ref) v_u_3, (copy) v_u_263, (copy) v_u_264, (copy) v_u_269, (copy) v_u_272, (copy) v_u_232
		local v282 = v_u_16.CanvasSize()
		if v_u_16.Compact then
			local v283 = v282.X - 24
			local v284 = math.clamp(v283, 340, 1280)
			local v285 = math.floor(v284)
			local v286 = v282.Y - v_u_16.TopInset() - 12
			local v287 = math.clamp(v286, 300, 720)
			local v288 = math.floor(v287)
			v_u_31.Holder.Size = UDim2.fromOffset(v285, v288)
		else
			local v289 = v_u_16.TopInset()
			local v290 = v282.X - 96
			local v291 = math.clamp(v290, 1280, 1500)
			local v292 = math.floor(v291)
			local v293 = v282.Y - v289 - 22
			local v294 = math.clamp(v293, 720, 980)
			local v295 = math.floor(v294)
			v_u_31.Holder.Size = UDim2.fromOffset(v292, v295)
		end
		v_u_114()
		local v296 = v_u_16.Compact
		v_u_274.Visible = not v296
		v_u_149.Position = UDim2.fromOffset(0, v296 and 0 or 22)
		if v296 then
			v_u_148.Parent = v_u_229
			v_u_148.Position = UDim2.new(1, -4, 0, 11)
		else
			v_u_148.Parent = v_u_146
			v_u_148.Position = UDim2.new(1, 0, 0, 0)
		end
		v_u_151.TextSize = v296 and 28 or 34
		v_u_151.Size = UDim2.fromOffset(v_u_151.Size.X.Offset, v296 and 30 or 36)
		v_u_150.Size = UDim2.new(1, -110, 0, v296 and 30 or 36)
		v_u_164.TextSize = v296 and 14 or 15
		v_u_165.Position = UDim2.new(1, 0, 0, v296 and 8 or 12)
		v_u_167.Position = UDim2.fromOffset(0, v296 and 36 or 44)
		v_u_166.Position = UDim2.fromOffset(0, v296 and 50 or 60)
		v_u_166.TextSize = v296 and 13 or 14
		local v297 = v296 and 70 or 108
		v_u_176.Position = UDim2.fromOffset(0, v297)
		v_u_176.Size = UDim2.new(1, 0, 1, -v297)
		v_u_276 = v_u_276 + 1
		local v_u_298 = v_u_276
		local v_u_299 = v_u_151.Text
		local v_u_300 = v_u_151.TextSize
		task.spawn(function()
			-- upvalues: (copy) v_u_299, (ref) v_u_22, (copy) v_u_300, (ref) v_u_3, (copy) v_u_298, (ref) v_u_276, (ref) v_u_151
			local v_u_301 = Instance.new("GetTextBoundsParams")
			v_u_301.Text = v_u_299
			v_u_301.Font = v_u_22.Display
			v_u_301.Size = v_u_300
			v_u_301.Width = 1000
			local function v302()
				-- upvalues: (ref) v_u_3, (copy) v_u_301
				return v_u_3:GetTextBoundsAsync(v_u_301)
			end
			local v303, v304 = pcall(v302)
			if v303 and (v_u_298 == v_u_276 and v304.X > 4) then
				local v305 = v_u_151
				local v306 = UDim2.fromOffset
				local v307 = v304.X
				v305.Size = v306(math.ceil(v307) + 2, v_u_151.Size.Y.Offset)
			end
		end)
		local v308 = v_u_16.Compact and 104 or 156
		v_u_263.Size = UDim2.new(1, 0, 0, v308)
		v_u_264.Size = UDim2.fromOffset(v308 - 16, v308 - 16)
		v_u_269.Position = UDim2.fromOffset(v308 + 4, v296 and 8 or 12)
		v_u_269.Size = UDim2.new(1, -(v308 + 4 + 262 + 168 + 12), 1, v296 and -16 or -24)
		v_u_272.TextSize = v296 and 13 or 14
		v_u_232.Size = UDim2.new(1, 0, 1, -(v308 + 50 + 12))
	end
	local function v_u_340() -- name: layoutRows
		-- upvalues: (copy) v_u_176, (copy) v_u_19, (ref) v_u_62, (copy) v_u_16, (ref) v_u_179, (ref) v_u_275, (copy) v_u_177, (ref) v_u_198, (copy) v_u_199, (copy) v_u_200, (copy) v_u_201, (copy) v_u_228
		local v310 = v_u_176.AbsoluteSize.Y
		local v311 = v_u_176.AbsoluteSize.X / 400
		local v312 = v310 / math.max(v311, 0.01)
		local v313 = v_u_19.AmmoNeeded(v_u_62)
		local v314 = 0
		for _, v315 in v_u_19.AmmoTypes() do
			if not v313[v315.id] and (v_u_62.ammo[v315.id] or 0) <= 0 then
				continue
			end
			v314 = v314 + 1
		end
		local v316 = v314 + 7
		local v317 = v314 > 0 and not v_u_16.Compact and 22 or 0
		v_u_179 = v312 < 400 and 4 or 6
		local v318 = (v312 - v317 - (v316 - 1) * v_u_179) / v316
		local v319 = math.floor(v318)
		v_u_275 = math.clamp(v319, 30, 66)
		local v_u_320 = not v_u_16.Touch and 36 or v_u_275 + 10
		local v_u_321
		if v_u_16.Touch then
			v_u_321 = v_u_275 - 2
		else
			local v322 = v_u_275 - 8
			v_u_321 = math.min(32, v322)
		end
		local v_u_323 = v_u_275 - 8
		local function v326(p324, p325) -- name: fitRow
			-- upvalues: (ref) v_u_275, (copy) v_u_323, (copy) v_u_320, (copy) v_u_321, (ref) v_u_16
			p324.frame.Position = UDim2.fromOffset(0, p325)
			p324.frame.Size = UDim2.new(1, 0, 0, v_u_275)
			p324.tile.Size = UDim2.fromOffset(v_u_323, v_u_323)
			p324.name.Position = UDim2.fromOffset(v_u_323 + 16, 0)
			p324.remove.Size = UDim2.fromOffset(v_u_320, v_u_321)
			p324.remove.Position = UDim2.new(1, v_u_16.Touch and -1 or -6, 0.5, 0)
			p324.costPill.Position = UDim2.new(1, -(v_u_320 + (v_u_16.Touch and 8 or 12)), 0.5, 0)
			p324.name.Size = UDim2.new(1, -(v_u_323 + 16 + v_u_320 + 12 + 60), 1, 0)
			p324.name.TextSize = v_u_275 < 40 and 15 or 17
			if p324.num then
				p324.num.Visible = v_u_323 >= 34
			end
		end
		local v327 = 0
		for _, v328 in v_u_177 do
			v326(v328, v327)
			v327 = v327 + (v_u_275 + v_u_179)
		end
		v326(v_u_198, v327)
		local v329 = v327 + (v_u_275 + v_u_179)
		v_u_199.Position = UDim2.fromOffset(0, v329)
		v_u_199.Visible = v314 > 0
		local v330 = v_u_200
		local v331
		if v314 > 0 then
			v331 = not v_u_16.Compact
		else
			v331 = false
		end
		v330.Visible = v331
		for _, v332 in v_u_19.AmmoTypes() do
			local v333 = v313[v332.id] or (v_u_62.ammo[v332.id] or 0) > 0
			local v334
			if v333 or v_u_201[v332.id] then
				v334 = v_u_228(v332.id)
			else
				v334 = nil
			end
			if not v334 then
				continue
			end
			v334.frame.Visible = v333
			if not v333 then
				continue
			end
			v334.frame.Position = UDim2.fromOffset(0, v317)
			v334.frame.Size = UDim2.new(1, 0, 0, v_u_275)
			v334.tile.Size = UDim2.fromOffset(v_u_323, v_u_323)
			local v335
			if v_u_16.Touch then
				local v336 = v_u_275 - 2
				v335 = math.max(38, v336)
			else
				v335 = 38
			end
			local v337 = v334.plus
			local v338 = UDim2.fromOffset
			local v339 = v_u_275 - 6
			v337.Size = v338(v335, (math.min(34, v339)))
			v334.plus.Position = UDim2.new(1, -5, 0.5, 0)
			v334.count.Position = UDim2.new(1, -(v335 + 7), 0.5, 0)
			v334.minus.Size = v334.plus.Size
			v334.minus.Position = UDim2.new(1, -(v335 + 45), 0.5, 0)
			v317 = v317 + (v_u_275 + v_u_179)
		end
		v_u_199.Size = UDim2.new(1, 0, 0, v317)
	end
	local function v_u_365(p341) -- name: layoutGrid
		-- upvalues: (copy) v_u_31, (copy) v_u_16, (copy) v_u_19, (ref) v_u_81, (copy) v_u_234, (copy) v_u_23, (copy) v_u_233, (copy) v_u_232
		local v342 = v_u_31.Holder.Size.X.Offset - 44 - 400 - 18
		local v_u_343 = v_u_16.Compact and 128 or 164
		local v344 = (v342 - 8 + 12) / 170
		local v345 = math.floor(v344)
		local v_u_346 = math.clamp(v345, 2, 5)
		local v347 = (v342 - 8 - (v_u_346 - 1) * 12) / v_u_346
		local v_u_348 = math.floor(v347)
		local v349 = nil
		for _, v350 in v_u_19.FILTERS do
			if v350.id ~= v_u_81 then
				continue
			end
			v349 = v350
		end
		local v351 = {}
		local v352 = {}
		for _, v353 in v_u_234 do
			local v354 = v_u_19.Get(v353.id)
			local v355
			if v354 == nil then
				v355 = false
			else
				v355 = (v349 == nil or v349.cats == nil) and true or v349.cats[v354.category] == true
			end
			v353.holder.Visible = v355
			v353.visible = v355
			if not v355 then
				continue
			end
			local v356
			if v_u_23.IsLocked(v353.id) then
				v356 = v351
			else
				v356 = v352
			end
			table.insert(v356, v353)
		end
		local v_u_357 = 0
		local function v364(p358) -- name: place
			-- upvalues: (copy) v_u_346, (ref) v_u_357, (copy) v_u_343, (copy) v_u_348
			for v359, v360 in p358 do
				local v361 = (v359 - 1) % v_u_346
				v360.y = v_u_357 + (v359 - 1) // v_u_346 * (v_u_343 + 12)
				v360.holder.Position = UDim2.fromOffset(v361 * (v_u_348 + 12) + 4, v360.y + 4)
				v360.holder.Size = UDim2.fromOffset(v_u_348, v_u_343)
				v360.glow.Size = UDim2.fromOffset(v_u_348 * 1.05, v_u_343 * 0.95)
				v360.glow.Position = UDim2.new(0.5, 0, 0, (v_u_343 - 60) / 2 + 6)
			end
			local v362 = v_u_357
			local v363 = #p358 / v_u_346
			v_u_357 = v362 + math.ceil(v363) * (v_u_343 + 12)
		end
		v364(v352)
		v_u_233.Visible = #v351 > 0
		if #v351 > 0 then
			v_u_233.Position = UDim2.fromOffset(4, v_u_357 + (#v352 > 0 and 6 or 0))
			v_u_357 = v_u_357 + ((#v352 > 0 and 14 or 8) + 44)
			v364(v351)
		end
		v_u_232.CanvasSize = UDim2.fromOffset(0, v_u_357 + 8)
		if not p341 then
			v_u_232.CanvasPosition = Vector2.zero
		end
	end
	local function v_u_370() -- name: staggerCards
		-- upvalues: (copy) v_u_234, (copy) v_u_16
		local v366 = 0
		for _, v367 in v_u_234 do
			if not v367.visible then
				continue
			end
			local v368 = v366 * 0.018
			local v369 = math.min(v368, 0.22)
			v367.inner.Position = UDim2.fromOffset(0, 14)
			v367.scale.Scale = 0.94
			v_u_16.Tween(v367.inner, TweenInfo.new(0.32, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, v369), {
				["Position"] = UDim2.new()
			})
			v_u_16.Tween(v367.scale, TweenInfo.new(0.32, Enum.EasingStyle.Back, Enum.EasingDirection.Out, 0, false, v369), {
				["Scale"] = 1
			})
			v366 = v366 + 1
		end
	end
	local v_u_371 = {}
	local function v_u_382() -- name: queueVisible
		-- upvalues: (copy) v_u_232, (copy) v_u_31, (copy) v_u_16, (copy) v_u_234, (copy) v_u_371, (copy) v_u_20
		local v372 = v_u_232.AbsoluteSize.X
		local v373 = v_u_31.Holder.Size.X.Offset - 44 - 400 - 18
		local v374 = v372 / math.max(v373, 1)
		local v375 = math.max(v374, 0.01)
		local v376 = v_u_16.Compact and 128 or 164
		local v377 = v_u_232.CanvasPosition.Y / v375
		local v378 = v377 + v_u_232.AbsoluteWindowSize.Y / v375
		for _, v379 in v_u_234 do
			if v379.visible and (not v379.rendered and (v379.y + v376 >= v377 - v376 and v379.y <= v378 + v376)) then
				v379.rendered = true
				local v380 = v_u_371
				table.insert(v380, v379)
			else
				if not v379.rendered or v379.visible and (v379.y + v376 >= v377 - v376 * 2 and v379.y <= v378 + v376 * 2) then
					continue
				end
				v379.rendered = false
				local v381 = table.find(v_u_371, v379)
				if v381 then
					table.remove(v_u_371, v381)
				end
				v_u_20.Set(v379.icon, nil)
			end
		end
	end
	v_u_2.Heartbeat:Connect(function()
		-- upvalues: (copy) v_u_371, (copy) v_u_31, (copy) v_u_16, (copy) v_u_20, (copy) v_u_19, (ref) v_u_14, (copy) v_u_21, (ref) v_u_12
		if #v_u_371 == 0 or not v_u_31.IsOpen then
			return
		end
		for _ = 1, v_u_16.Touch and 2 or 4 do
			local v383 = table.remove(v_u_371, 1)
			if not v383 then
				break
			end
			local v384 = v_u_20.Set
			local v385 = v383.icon
			local v386 = v383.id
			local v387 = v383.id
			local v388 = {
				["outline"] = false,
				["glow"] = false,
				["outlineColor"] = nil,
				["outlineScale"] = 1.035,
				["outlineTransparency"] = 0.5
			}
			local v389 = v_u_19.Get(v387)
			v388.outlineColor = (v389 and v_u_14[v389.category] or v_u_21.Accent):Lerp(Color3.new(1, 1, 1), 0.55)
			v384(v385, v386, v388)
			v_u_12._paintCard(v383)
		end
	end)
	v_u_232:GetPropertyChangedSignal("CanvasPosition"):Connect(v_u_382)
	local v_u_390 = -1
	local v_u_391 = TweenInfo.new(0.35, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
	function v_u_12._paintPoints() -- name: _paintPoints
		-- upvalues: (copy) v_u_19, (ref) v_u_62, (copy) v_u_175, (copy) v_u_151, (ref) v_u_390, (copy) v_u_16, (copy) v_u_169, (copy) v_u_391, (copy) v_u_21, (copy) v_u_170, (copy) v_u_17, (copy) v_u_165, (copy) v_u_166, (ref) v_u_71, (copy) v_u_60, (copy) v_u_46, (copy) v_u_168
		local v392 = v_u_19.Cost(v_u_62)
		local v393 = v_u_19.Budget()
		local v394 = math.max(v393, 1)
		v_u_175(v394)
		v_u_151.Text = string.format("%d / %d", v392, v394)
		if v392 ~= v_u_390 then
			if v_u_390 >= 0 then
				v_u_16.Bump(v_u_151, 0.08)
			end
			v_u_390 = v392
		end
		local v395 = v394 <= v392
		local v396 = v_u_16.Tween
		local v397 = v_u_169
		local v398 = v_u_391
		local v399 = {}
		local v400 = UDim2.fromScale
		local v401 = v392 / v394
		v399.Size = v400(math.clamp(v401, 0, 1), 1)
		v396(v397, v398, v399)
		local v402
		if v395 then
			v402 = v_u_21.Success
		else
			v402 = v_u_21.Accent
		end
		v_u_170.Color = ColorSequence.new(v_u_17.Lighten(v402, 0.18), v402)
		local v403 = v394 - v392
		v_u_165.Text = ""
		local v404 = v_u_166
		local v405
		if v395 then
			v405 = string.format("All %d points used", v394)
		elseif v392 == 0 then
			v405 = string.format("0 of %d points used  \194\183  pick items on the right", v394)
		else
			v405 = string.format("%d of %d points used  \194\183  %d left", v392, v394, v403)
		end
		v404.Text = v405
		local v406 = v_u_166
		local v407
		if v395 then
			v407 = v_u_21.Success
		else
			v407 = v_u_21.TextDim
		end
		v406.TextColor3 = v407
		local v408 = false
		local v409 = v_u_71
		if v409 and (table.find(v_u_62.items, v409) == nil and v_u_62.armor ~= v409) then
			local v410, v411, v412 = v_u_60(v409)
			if v410 then
				v392 = v392 + v_u_19.Points(v409) + v_u_46(v409) - (not (v_u_19.IsArmor(v409) and v_u_62.armor) and 0 or v_u_19.Points(v_u_62.armor))
			elseif v411 == "points" or v411 == "ammo" then
				v408 = true
				local _, v413 = v_u_46(v409)
				local v414 = v_u_166
				local v415
				if v411 == "ammo" and v413 then
					v415 = string.format("%s needs %s too: %d more point%s, remove something first", v_u_19.Name(v409), string.lower(v413.name), v412, v412 == 1 and "" or "s")
				else
					v415 = string.format("%s needs %d more point%s: remove something first", v_u_19.Name(v409), v412, v412 == 1 and "" or "s")
				end
				v414.Text = v415
				v_u_166.TextColor3 = v_u_21.Danger
				v392 = v394
			end
		end
		local v416 = v_u_16.Tween
		local v417 = v_u_168
		local v418 = v_u_17.Tween.Fast
		local v419 = {}
		local v420 = UDim2.fromScale
		local v421 = v392 / v394
		v419.Size = v420(math.clamp(v421, 0, 1), 1)
		v416(v417, v418, v419)
		local v422 = v_u_168
		local v423
		if v408 then
			v423 = v_u_21.Danger
		else
			v423 = v_u_21.Accent
		end
		v422.BackgroundColor3 = v423
		v_u_168.BackgroundTransparency = v408 and 0.35 or 0.6
	end
	local function v_u_439(p424, p425) -- name: paintRow
		-- upvalues: (copy) v_u_19, (ref) v_u_14, (copy) v_u_21, (copy) v_u_20, (ref) v_u_198, (copy) v_u_177, (ref) v_u_62
		p424.id = p425
		local v426 = v_u_19.Get(p425)
		p424.remove.Visible = v426 ~= nil
		p424.costPill.Visible = v426 ~= nil
		p424.frame.BackgroundTransparency = v426 and 0.3 or 0.72
		local v427
		if v426 then
			v427 = v_u_14[v426.category] or v_u_21.Accent
		else
			v427 = v_u_21.Raised
		end
		local v428 = p424.tileGrad
		local v429
		if v426 then
			v429 = ColorSequence.new(v427:Lerp(v_u_21.Panel, 0.62), v_u_21.PanelHi:Lerp(v_u_21.Panel, 0.6))
		else
			v429 = ColorSequence.new(v_u_21.Panel, v_u_21.Panel)
		end
		v428.Color = v429
		p424.tile.BackgroundTransparency = v426 and 0 or 0.6
		p424.tileStroke.Transparency = v426 and 0.88 or 0.75
		if p424.plus then
			p424.plus.Visible = v426 == nil
		end
		if p424.shield then
			p424.shield.Visible = v426 == nil
		end
		if v426 then
			p424.name.Text = v426.name
			p424.name.TextColor3 = v_u_21.Text
			p424.costLabel.Text = v426.points .. (v426.points == 1 and " PT" or " PTS")
			local v430 = v_u_20.Set
			local v431 = p424.icon
			local v432 = {
				["outline"] = false,
				["glow"] = false,
				["outlineColor"] = nil,
				["outlineScale"] = 1.035,
				["outlineTransparency"] = 0.5
			}
			local v433 = v_u_19.Get(p425)
			v432.outlineColor = (v433 and v_u_14[v433.category] or v_u_21.Accent):Lerp(Color3.new(1, 1, 1), 0.55)
			v430(v431, p425, v432)
		else
			local v434
			if p424 == v_u_198 then
				v434 = false
			else
				v434 = v_u_177[#v_u_62.items + 1] == p424
			end
			p424.name.Text = p424 == v_u_198 and "Armor (optional)" or (v434 and "Pick an item on the right" or "Empty")
			local v435 = p424.name
			local v436
			if v434 then
				v436 = v_u_21.TextDim
			else
				v436 = v_u_21.TextMuted
			end
			v435.TextColor3 = v436
			v_u_20.Set(p424.icon, nil)
		end
		if p424.num then
			local v437 = p424.num
			local v438
			if v426 then
				v438 = v_u_21.TextDim
			else
				v438 = v_u_21.TextMuted
			end
			v437.TextColor3 = v438
			p424.num.TextTransparency = v426 and 0.1 or 0.3
		end
	end
	local function v_u_447() -- name: paintAmmo
		-- upvalues: (copy) v_u_19, (ref) v_u_62, (copy) v_u_201, (copy) v_u_21, (ref) v_u_14, (copy) v_u_54
		local v440 = v_u_19.AmmoNeeded(v_u_62)
		for _, v441 in v_u_19.AmmoTypes() do
			local v442 = v_u_201[v441.id]
			if not (v442 and v442.frame.Visible) then
				continue
			end
			local v443 = v_u_62.ammo[v441.id] or 0
			v442.count.Text = tostring(v443)
			v442.amount.Text = "\195\151" .. v443 * v441.perBundle
			if v443 == 0 and (v440[v441.id] and not v441.optional) then
				v442.sub.Text = "No " .. string.lower(v441.name) .. ": you can\'t shoot!"
				v442.sub.TextColor3 = v_u_21.Danger
				v442.amount.TextColor3 = v_u_21.Danger
			else
				v442.sub.Text = string.format("%d %s per bundle", v441.perBundle, string.lower(v441.name))
				v442.sub.TextColor3 = v_u_21.TextMuted
				local v444 = v442.amount
				local v445
				if v441.id == "arrows" or v441.as == "arrows" then
					v445 = v_u_14.bow
				else
					v445 = v_u_14.gun
				end
				v444.TextColor3 = v445
			end
			local v446
			if v443 < v_u_19.MaxAmmoBundles() then
				v446 = v_u_19.Cost(v_u_62) + v441.points <= v_u_19.Budget()
			else
				v446 = false
			end
			v442.plus.BackgroundTransparency = v446 and 0.1 or 0.6
			v442.minus.BackgroundTransparency = v443 > 0 and not v_u_54(v441.id) and 0.1 or 0.6
		end
	end
	function v_u_12._paintCard(p448) -- name: _paintCard
		-- upvalues: (copy) v_u_60, (ref) v_u_62, (copy) v_u_19, (ref) v_u_14, (copy) v_u_21, (copy) v_u_23, (copy) v_u_20, (copy) v_u_46
		local v449, v450, v451 = v_u_60(p448.id)
		local v452 = p448.id
		local v453 = table.find(v_u_62.items, v452) ~= nil and true or v_u_62.armor == v452
		local v454 = v_u_19.Get(p448.id)
		local v455 = v454 and v_u_14[v454.category] or v_u_21.Accent
		local v456 = v450 == "locked"
		local v457 = not v453
		if v457 then
			v457 = not v449
		end
		local v458, v459 = v_u_23.Progress(p448.id)
		local v460 = v_u_23.Level(p448.id)
		p448.check.Visible = false
		p448.lock.Visible = v456
		p448.costBadge.Visible = not v456
		local v461 = p448.lv
		local v462 = not v456
		if v462 then
			v462 = v460 >= 1
		end
		v461.Visible = v462
		local v463 = not v456
		if v463 then
			v463 = v_u_23.CanUpgrade(p448.id)
		end
		p448.readyDot.Visible = v463
		if v_u_23.MAX_LEVEL <= v460 then
			p448.lvText.Text = "MAX"
			p448.lvText.TextColor3 = v_u_21.TextDark
			p448.lv.BackgroundColor3 = v_u_21.Gold
			p448.lv.BackgroundTransparency = 0
		else
			p448.lvText.Text = string.format("<font size=\"11\">LV</font> %d", v460)
			p448.lvText.TextColor3 = v_u_21.Text
			local v464 = p448.lv
			local v465
			if v463 then
				v465 = v_u_21.SuccessDark
			else
				v465 = v_u_21.Void
			end
			v464.BackgroundColor3 = v465
			p448.lv.BackgroundTransparency = v463 and 0 or 0.3
		end
		p448.cbar.Visible = v456
		p448.cfill.Visible = v458 > 0
		local v466 = p448.cfill
		local v467 = UDim2.fromScale
		local v468 = v458 / math.max(v459, 1)
		v466.Size = v467(math.clamp(v468, 0, 1), 1)
		p448.cfill.BackgroundColor3 = v_u_21.Accent
		local v469 = p448.stroke
		local v470
		if v453 then
			v470 = v_u_21.Accent
		elseif p448.hover then
			if v456 then
				v470 = v_u_21.Stroke
			else
				v470 = v455
			end
		else
			v470 = v_u_21.Stroke
		end
		v469.Color = v470
		p448.stroke.Thickness = v453 and 2 or 1
		p448.stroke.Transparency = v453 and 0 or (p448.hover and (v456 and 0.7 or 0.4) or 0.9)
		local v471 = p448.grad
		local v472
		if v456 then
			v472 = ColorSequence.new(v_u_21.Panel, v_u_21.Panel)
		else
			v472 = ColorSequence.new(v455:Lerp(v_u_21.Panel, p448.hover and 0.8 or 0.9), v_u_21.PanelHi:Lerp(v_u_21.Panel, 0.6))
		end
		v471.Color = v472
		p448.inner.BackgroundTransparency = v456 and 0.35 or 0.08
		p448.glow.ImageTransparency = (v456 or v457) and 1 or ((p448.hover or v453) and 0.7 or 0.85)
		p448.costBadge.BackgroundColor3 = v_u_21.Void
		p448.costBadge.BackgroundTransparency = 0.3
		if p448.rendered then
			v_u_20.SetDim(p448.icon, v457)
		end
		local v473 = p448.nameL
		local v474
		if v456 then
			v474 = v_u_21.TextMuted
		elseif v457 then
			v474 = v_u_21.TextDim
		else
			v474 = v_u_21.Text
		end
		v473.TextColor3 = v474
		if v453 then
			p448.status.Text = "\226\156\147 IN LOADOUT"
			p448.status.TextColor3 = v_u_21.Accent
			return
		elseif v456 then
			p448.status.Text = string.format("%d / %d SHARDS", v458, v459)
			local v475 = p448.status
			local v476
			if v458 > 0 then
				v476 = v_u_21.TextDim
			else
				v476 = v_u_21.TextMuted
			end
			v475.TextColor3 = v476
			return
		elseif v450 == "points" then
			p448.status.Text = string.format("NEEDS %d MORE PT%s", v451, v451 == 1 and "" or "S")
			local v477 = p448.status
			local v478
			if p448.hover then
				v478 = v_u_21.Danger
			else
				v478 = v_u_21.TextMuted
			end
			v477.TextColor3 = v478
			return
		elseif v450 == "ammo" then
			local _, v479 = v_u_46(p448.id)
			p448.status.Text = string.format("NEEDS %d PT%s FOR %s", v451, v451 == 1 and "" or "S", string.upper(v479 and v479.name or "AMMO"))
			local v480 = p448.status
			local v481
			if p448.hover then
				v481 = v_u_21.Danger
			else
				v481 = v_u_21.TextMuted
			end
			v480.TextColor3 = v481
			return
		elseif v450 == "full" then
			p448.status.Text = "6 ITEMS MAX"
			p448.status.TextColor3 = v_u_21.TextMuted
		else
			p448.status.Text = ""
		end
	end
	local function v_u_495(p482, p483, p484) -- name: statValue
		-- upvalues: (copy) v_u_19
		local v485 = p482.details
		if type(v485) == "table" then
			for _, v486 in p482.details do
				if type(v486) ~= "table" then
					continue
				end
				local v487 = v486[1]
				if type(v487) ~= "string" or string.upper(v486[1]) ~= p483 then
					continue
				end
				local v488 = v486[2]
				return tostring(v488)
			end
		end
		if p482.category == "armor" then
			local v489, v490 = v_u_19.ArmorStats(p482)
			if p483 == "ARMOR" then
				return "+" .. v489
			end
			if p483 == "SPEED" then
				local v491 = string.format
				local v492 = (1 - v490) * 100 + 0.5
				return v491("\226\136\146%d%%", (math.floor(v492)))
			end
		end
		local v493 = string.format
		local v494 = p484 * 10 + 0.5
		return v493("%d / 10", (math.floor(v494)))
	end
	local v_u_496 = nil
	function v_u_12._paintDetail() -- name: _paintDetail
		-- upvalues: (copy) v_u_19, (ref) v_u_72, (copy) v_u_263, (ref) v_u_14, (copy) v_u_21, (ref) v_u_496, (copy) v_u_20, (copy) v_u_268, (copy) v_u_30, (copy) v_u_266, (copy) v_u_267, (copy) v_u_16, (copy) v_u_17, (copy) v_u_270, (copy) v_u_23, (copy) v_u_271, (copy) v_u_272, (copy) v_u_278, (copy) v_u_495, (copy) v_u_60, (copy) v_u_273, (copy) v_u_281, (ref) v_u_62
		local v497 = v_u_19.Get(v_u_72)
		v_u_263.Visible = v497 ~= nil
		if v497 then
			local v498 = v_u_14[v497.category] or v_u_21.Accent
			if v_u_496 ~= v497.id then
				v_u_496 = v497.id
				v_u_20.Set(v_u_268, v497.id, (v_u_30(v497.id, {
					["spin"] = true,
					["outline"] = true
				})))
				v_u_266.Color = ColorSequence.new(v498:Lerp(v_u_21.Panel, 0.62), v_u_21.PanelHi:Lerp(v_u_21.Panel, 0.6))
				v_u_267.ImageColor3 = v498
				v_u_16.Pop(v_u_268, 0.9, v_u_17.Tween.PopSmall)
			end
			v_u_270.Text = v497.name
			local v499 = v_u_19.CATEGORY_SINGULAR[v497.category] or ""
			local v500 = v_u_19.AmmoOf(v497.id)
			if v500 then
				v500 = v_u_19.AmmoDef(v500)
			end
			local v501 = v_u_23.Level(v497.id)
			local v502 = v501 < 1 and "" or string.format("LV %d%s  \194\183  ", v501, v501 <= 1 and "" or " " .. string.upper(v_u_23.BonusText(v497.id, v501)))
			v_u_271.Text = string.format("%s%s  \194\183  %d POINT%s%s", v502, v499, v497.points, v497.points == 1 and "" or "S", not v500 and "" or "  \194\183  USES " .. string.upper(v500.name))
			v_u_271.TextColor3 = v498:Lerp(v_u_21.TextDim, 0.35)
			local v503 = v497.description
			if v497.category == "armor" then
				local v504, v505 = v_u_19.ArmorStats(v497)
				local v506 = string.format
				local v507 = (1 - v505) * 100 + 0.5
				v503 = v506("+%d armor, %d%% slower. %s", v504, math.floor(v507), v503)
			end
			v_u_272.Text = v503
			local v508 = v_u_19.Bars(v497)
			for v509, v510 in v_u_278 do
				local v511 = v508[v509]
				v510.frame.Visible = v511 ~= nil
				if not v511 then
					continue
				end
				v510.label.Text = v511.label
				v510.bar.Set(v511.frac)
				v510.bar.SetColor(v498)
				v510.value.Text = v_u_495(v497, v511.label, v511.frac)
			end
			local v512, v513, v514 = v_u_60(v497.id)
			local v515 = v513 == "locked"
			v_u_273.Visible = true
			if v515 then
				local v516, v517 = v_u_23.Progress(v497.id)
				if v_u_23.RankAllows(v497.id) then
					v_u_271.Text = string.format("LOCKED  \194\183  %d / %d SHARDS  \194\183  FIND SHARDS IN DROPS", v516, v517)
				else
					local v518 = require(game:GetService("ReplicatedStorage").Shared.Ranks)
					v_u_271.Text = string.format("LOCKED  \194\183  JOINS YOUR DROPS AT %s", string.upper(v518.Get(v_u_23.ItemRank(v497.id)).name))
				end
				v_u_271.TextColor3 = v_u_21.TextMuted
				v_u_281.Instance.AnchorPoint = Vector2.new(1, 0.5)
				v_u_281.Instance.Position = UDim2.new(1, -12, 0.5, 0)
				v_u_281.Instance.Size = UDim2.fromOffset(144, 56)
				v_u_281.Label.TextSize = 17
				v_u_281:SetStyle("Dark")
				v_u_281:SetEnabled(true)
				v_u_281:SetText("COLLECTION")
				return
			else
				v_u_281.Instance.AnchorPoint = Vector2.new(1, 0.5)
				v_u_281.Instance.Position = UDim2.new(1, -12, 0.5, 0)
				v_u_281.Instance.Size = UDim2.fromOffset(144, 56)
				v_u_281.Label.TextSize = 20
				local v519 = v497.id
				if table.find(v_u_62.items, v519) ~= nil and true or v_u_62.armor == v519 then
					v_u_281:SetStyle("Dark")
					v_u_281:SetEnabled(true)
					v_u_281:SetText("REMOVE")
					return
				elseif v512 then
					v_u_281:SetStyle("Primary")
					v_u_281:SetEnabled(true)
					v_u_281:SetText(v_u_19.IsArmor(v497.id) and v_u_62.armor and "SWAP" or "ADD")
				else
					v_u_281:SetStyle("Dark")
					v_u_281:SetEnabled(false)
					v_u_281:SetText(v513 ~= "points" and v513 ~= "ammo" and "6 ITEMS MAX" or "NEED " .. v514 .. (v514 == 1 and " PT" or " PTS"))
				end
			end
		else
			return
		end
	end
	local function v_u_526() -- name: paintAll
		-- upvalues: (copy) v_u_177, (copy) v_u_439, (ref) v_u_62, (ref) v_u_198, (copy) v_u_340, (copy) v_u_447, (ref) v_u_12, (copy) v_u_234, (ref) v_u_277, (copy) v_u_31, (copy) v_u_19, (copy) v_u_75
		for v520, v521 in v_u_177 do
			v_u_439(v521, v_u_62.items[v520])
		end
		local v522 = v_u_439
		local v523 = v_u_198
		local v524
		if v_u_62.armor then
			v524 = v_u_62.armor
		else
			v524 = nil
		end
		v522(v523, v524)
		v_u_340()
		v_u_447()
		v_u_12._paintPoints()
		for _, v525 in v_u_234 do
			v_u_12._paintCard(v525)
		end
		v_u_12._paintDetail()
		v_u_277()
		v_u_31.Subtitle.Text = string.format("Pick up to %d items worth %d points.", v_u_19.MaxItems(), v_u_75())
	end
	local function v_u_533(p527, p528) -- name: save
		-- upvalues: (ref) v_u_76, (ref) v_u_77, (ref) v_u_62, (ref) v_u_74, (copy) v_u_148, (copy) v_u_21, (copy) v_u_19, (copy) p_u_15, (copy) v_u_18, (ref) v_u_277
		v_u_76 = v_u_76 + 1
		if not p527 then
			if not v_u_77 then
				return
			end
			p527 = v_u_62
			p528 = v_u_74
		end
		v_u_77 = false
		if #p527.items == 0 then
			v_u_148.Text = "Add an item to save"
			v_u_148.TextColor3 = v_u_21.TextMuted
			return
		else
			v_u_148.Text = "Saving\226\128\166"
			v_u_148.TextColor3 = v_u_21.TextMuted
			local _, _, v529 = v_u_19.Validate(p527)
			local v530, _ = p_u_15.ProfileAction("SetLoadout", v529, p528)
			if v530 then
				v_u_148.Text = "\226\156\147 Saved"
				v_u_148.TextColor3 = v_u_21.Success
				local v531 = {
					["items"] = table.clone(v529.items),
					["armor"] = v529.armor,
					["ammo"] = table.clone(v529.ammo or {})
				}
				local v532 = v_u_18.Profile.loadouts
				if type(v532) == "table" and (p528 and v532[p528] ~= nil) then
					v532[p528] = v531
				end
				if not v_u_18.HasLoadoutSlots() or p528 == v_u_18.ActiveLoadout() then
					v_u_18.Profile.loadout = v531
				end
				v_u_277()
			else
				v_u_148.Text = "Not saved"
				v_u_148.TextColor3 = v_u_21.Danger
			end
		end
	end
	local function v_u_542() -- name: topUpAmmo
		-- upvalues: (copy) v_u_41, (ref) v_u_62, (copy) v_u_19, (copy) v_u_51, (ref) v_u_77, (ref) v_u_74, (ref) v_u_66, (ref) v_u_76, (copy) v_u_148, (copy) v_u_533, (copy) p_u_15
		local v534 = {}
		local v535 = {}
		for _, v536 in v_u_41(v_u_62) do
			local v537 = v_u_19.AmmoDef(v536)
			if v537 and v_u_19.Cost(v_u_62) + v537.points <= v_u_19.Budget() then
				v_u_62.ammo[v536] = 1
				table.insert(v534, v536)
			else
				if not v537 then
					continue
				end
				table.insert(v535, v536)
			end
		end
		local function v540(p538) -- name: line
			-- upvalues: (ref) v_u_51, (ref) v_u_19
			local v539 = v_u_51(p538)
			return string.format("%s for your %s", string.lower(v_u_19.AmmoDef(p538).name), not v539 and "weapon" or v_u_19.Name(v539))
		end
		if #v534 > 0 then
			v_u_77 = true
			v_u_74 = v_u_66
			v_u_76 = v_u_76 + 1
			local v_u_541 = v_u_76
			v_u_148.Text = ""
			task.delay(1.2, function()
				-- upvalues: (copy) v_u_541, (ref) v_u_76, (ref) v_u_533
				if v_u_541 == v_u_76 then
					v_u_533()
				end
			end)
			p_u_15.Toast("Added " .. v540(v534[1]) .. ": it had none", "info")
		elseif #v535 > 0 then
			p_u_15.Toast("No " .. v540(v535[1]) .. ": you can\'t shoot it! Make room for some", "warning")
		end
	end
	local v_u_543 = false
	local function v545(p544) -- name: openCollection
		-- upvalues: (ref) v_u_543, (copy) p_u_15
		v_u_543 = true
		p_u_15.MenuManager.Open("Collection", p544 and {
			["focus"] = p544
		} or nil)
	end
	p_u_15.MenuManager.Changed:Connect(function(p546)
		-- upvalues: (ref) v_u_543, (copy) p_u_15, (copy) v_u_18
		if p546 == nil and v_u_543 then
			v_u_543 = false
			task.defer(function()
				-- upvalues: (ref) p_u_15, (ref) v_u_18
				if not (p_u_15.MenuManager.IsOpen() or v_u_18.InMatch()) then
					p_u_15.MenuManager.Open("Loadout")
				end
			end)
		elseif p546 ~= nil and p546 ~= "Collection" then
			v_u_543 = false
		end
	end)
	v_u_12._openCollection = v545
	local function v_u_554(p_u_547)
		-- upvalues: (ref) v_u_66, (copy) v_u_18, (ref) v_u_77, (copy) v_u_80, (ref) v_u_62, (ref) v_u_74, (ref) v_u_76, (copy) v_u_533, (ref) v_u_73, (copy) v_u_19, (copy) v_u_542, (ref) v_u_72, (ref) v_u_71, (copy) p_u_15, (copy) v_u_526, (copy) v_u_16, (copy) v_u_68, (copy) v_u_177
		if p_u_547 ~= v_u_66 and (v_u_18.HasLoadoutSlots() and v_u_18.LoadoutSlotCount() >= p_u_547) then
			if v_u_77 then
				local v548 = v_u_80(v_u_62)
				local v549 = v_u_74
				v_u_77 = false
				v_u_76 = v_u_76 + 1
				task.spawn(v_u_533, v548, v549)
			end
			v_u_66 = p_u_547
			v_u_73 = p_u_547
			local _, _, v550 = v_u_19.Validate(v_u_18.LoadoutSlot(p_u_547))
			v_u_62 = v_u_80(v550)
			v_u_77 = false
			v_u_542()
			v_u_72 = v_u_62.items[1] or v_u_72
			v_u_71 = nil
			p_u_15.Sounds.Play("Equip")
			v_u_526()
			v_u_16.Pop(v_u_68[p_u_547].tile, 1.2)
			for v551, v_u_552 in v_u_177 do
				if not v_u_62.items[v551] then
					continue
				end
				task.delay(v551 * 0.03, function()
					-- upvalues: (ref) v_u_16, (copy) v_u_552
					v_u_16.Pop(v_u_552.tile, 1.12)
				end)
			end
			task.spawn(function()
				-- upvalues: (ref) p_u_15, (copy) p_u_547, (ref) v_u_18, (ref) v_u_73
				local v553 = p_u_15.ProfileAction("SelectLoadout", p_u_547)
				if v553 then
					v_u_18.Profile.activeLoadout = p_u_547
					v_u_18.Profile.loadout = v_u_18.Profile.loadouts and v_u_18.Profile.loadouts[p_u_547] or v_u_18.Profile.loadout
				end
				if v_u_73 == p_u_547 then
					v_u_73 = nil
				end
				if v553 then
					v_u_18.ProfileChanged:Fire(v_u_18.Profile)
				end
			end)
		end
	end
	v_u_180 = function(p555)
		-- upvalues: (ref) v_u_62, (copy) v_u_19, (copy) p_u_15, (ref) v_u_77, (ref) v_u_74, (ref) v_u_66, (ref) v_u_76, (copy) v_u_148, (copy) v_u_533, (copy) v_u_526
		local v556 = table.find(v_u_62.items, p555)
		if v556 then
			table.remove(v_u_62.items, v556)
			local v557 = v_u_19.AmmoNeeded(v_u_62)
			for v558 in v_u_62.ammo do
				if v557[v558] then
					continue
				end
				v_u_62.ammo[v558] = nil
			end
		else
			if v_u_62.armor ~= p555 then
				return
			end
			v_u_62.armor = false
		end
		p_u_15.Sounds.Play("Close")
		v_u_77 = true
		v_u_74 = v_u_66
		v_u_76 = v_u_76 + 1
		local v_u_559 = v_u_76
		v_u_148.Text = ""
		task.delay(1.2, function()
			-- upvalues: (copy) v_u_559, (ref) v_u_76, (ref) v_u_533
			if v_u_559 == v_u_76 then
				v_u_533()
			end
		end)
		v_u_526()
	end
	v_u_202 = function(p560, p561)
		-- upvalues: (copy) v_u_19, (ref) v_u_62, (copy) p_u_15, (copy) v_u_16, (copy) v_u_149, (copy) v_u_54, (copy) v_u_201, (copy) v_u_51, (ref) v_u_77, (ref) v_u_74, (ref) v_u_66, (ref) v_u_76, (copy) v_u_148, (copy) v_u_533, (copy) v_u_526, (copy) v_u_17
		local v562 = v_u_19.AmmoDef(p560)
		if v562 then
			local v563 = v_u_62.ammo[p560] or 0
			if p561 > 0 then
				if v_u_19.MaxAmmoBundles() <= v563 then
					p_u_15.Sounds.Play("Error")
					return
				end
				if v_u_19.Cost(v_u_62) + v562.points > v_u_19.Budget() then
					p_u_15.Sounds.Play("Error")
					v_u_16.Shake(v_u_149, 5)
					p_u_15.Toast("Not enough points for more " .. string.lower(v562.name), "warning")
					return
				end
			else
				if v563 <= 0 then
					return
				end
				if v_u_54(p560) then
					p_u_15.Sounds.Play("Error")
					local v564 = v_u_201[p560]
					if v564 then
						v_u_16.Shake(v564.frame, 5)
					end
					local v565 = v_u_51(p560)
					p_u_15.Toast(string.format("Your %s needs %s: remove it to free these points", not v565 and "weapon" or v_u_19.Name(v565), string.lower(v562.name)), "warning")
					return
				end
			end
			local v566 = v_u_62.ammo
			local v567 = v563 + p561
			v566[p560] = math.max(0, v567)
			if v_u_62.ammo[p560] == 0 then
				v_u_62.ammo[p560] = nil
			end
			p_u_15.Sounds.Play("Tick", {
				["pitch"] = p561 > 0 and 1.2 or 0.9
			})
			v_u_77 = true
			v_u_74 = v_u_66
			v_u_76 = v_u_76 + 1
			local v_u_568 = v_u_76
			v_u_148.Text = ""
			task.delay(1.2, function()
				-- upvalues: (copy) v_u_568, (ref) v_u_76, (ref) v_u_533
				if v_u_568 == v_u_76 then
					v_u_533()
				end
			end)
			v_u_526()
			local v569 = v_u_201[p560]
			if v569 then
				v_u_16.Bump(v569.count, 0.15)
				v_u_16.Pop(v569.icon, 0.85, v_u_17.Tween.PopSmall)
			end
		end
	end
	local function v_u_575(p570, p571, p572) -- name: denied
		-- upvalues: (copy) p_u_15, (copy) v_u_16, (copy) v_u_149, (copy) v_u_46, (copy) v_u_19
		p_u_15.Sounds.Play("Error")
		if p570 then
			v_u_16.Shake(p570.holder, 6)
		end
		v_u_16.Shake(v_u_149, 4)
		local v573
		if p570 and p571 == "ammo" then
			local v574
			v574, v573 = v_u_46(p570.id)
		else
			v573 = nil
		end
		if v573 then
			p_u_15.Toast(string.format("%s needs %s too: %d more point%s, remove something first", v_u_19.Name(p570.id), string.lower(v573.name), p572, p572 == 1 and "" or "s"), "warning")
			return
		elseif p571 == "points" or p571 == "ammo" then
			p_u_15.Toast(string.format("Needs %d more point%s: remove something first", p572, p572 == 1 and "" or "s"), "warning")
		elseif p571 == "full" then
			p_u_15.Toast("6 items max: remove one first", "warning")
		end
	end
	local function v_u_577(p576) -- name: flashCard
		-- upvalues: (copy) v_u_16, (copy) v_u_17
		if p576 then
			p576.flash.BackgroundTransparency = 0.7
			v_u_16.Tween(p576.flash, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["BackgroundTransparency"] = 1
			})
			v_u_16.Pop(p576.icon, 0.85, v_u_17.Tween.PopSmall)
		end
	end
	v_u_236 = function(p578, p579)
		-- upvalues: (ref) v_u_62, (ref) v_u_180, (copy) v_u_60, (ref) v_u_72, (copy) p_u_15, (ref) v_u_543, (copy) v_u_575, (copy) v_u_235, (ref) v_u_12, (copy) v_u_19, (ref) v_u_198, (copy) v_u_177, (ref) v_u_77, (ref) v_u_74, (ref) v_u_66, (ref) v_u_76, (copy) v_u_148, (copy) v_u_533, (copy) v_u_526, (copy) v_u_577, (copy) v_u_16
		if table.find(v_u_62.items, p578) ~= nil and true or v_u_62.armor == p578 then
			v_u_180(p578)
			return
		else
			local v580, v581, v582 = v_u_60(p578)
			if v580 or v581 ~= "locked" then
				if v580 then
					local v583
					if v_u_19.IsArmor(p578) then
						v_u_62.armor = p578
						v583 = v_u_198
					else
						local v584 = v_u_62.items
						table.insert(v584, p578)
						v583 = v_u_177[#v_u_62.items]
						local v585 = v_u_19.AmmoOf(p578)
						if v585 then
							v585 = v_u_19.AmmoDef(v585)
						end
						if v585 and ((v_u_62.ammo[v585.id] or 0) == 0 and v_u_19.Cost(v_u_62) + v585.points <= v_u_19.Budget()) then
							v_u_62.ammo[v585.id] = 1
						end
					end
					p_u_15.Sounds.Play("Equip")
					v_u_77 = true
					v_u_74 = v_u_66
					v_u_76 = v_u_76 + 1
					local v_u_586 = v_u_76
					v_u_148.Text = ""
					task.delay(1.2, function()
						-- upvalues: (copy) v_u_586, (ref) v_u_76, (ref) v_u_533
						if v_u_586 == v_u_76 then
							v_u_533()
						end
					end)
					v_u_526()
					v_u_577(p579 or v_u_235[p578])
					v_u_16.Pop(v583.tile, 1.18)
				else
					v_u_575(p579 or v_u_235[p578], v581, v582)
					v_u_12._paintDetail()
				end
			else
				v_u_72 = p578
				p_u_15.Sounds.Play("Select")
				v_u_543 = true
				p_u_15.MenuManager.Open("Collection", p578 and {
					["focus"] = p578
				} or nil)
				return
			end
		end
	end
	v_u_281.Activated:Connect(function()
		-- upvalues: (ref) v_u_72, (copy) v_u_23, (ref) v_u_543, (copy) p_u_15, (ref) v_u_236, (copy) v_u_235
		local v587 = v_u_72
		if v587 then
			if v_u_23.IsLocked(v587) then
				v_u_543 = true
				p_u_15.MenuManager.Open("Collection", v587 and {
					["focus"] = v587
				} or nil)
			else
				v_u_236(v587, v_u_235[v587])
			end
		else
			return
		end
	end)
	local v_u_588 = v_u_16.new("Frame", {
		["Name"] = "Highlight",
		["Size"] = UDim2.fromOffset(60, 36),
		["BackgroundColor3"] = v_u_21.Accent,
		["ZIndex"] = 1,
		v_u_16.Corner(v_u_17.Radius.Pill),
		["Parent"] = v_u_229
	})
	local v_u_589 = v_u_236
	local v_u_590 = v_u_496
	local v_u_591 = v_u_202
	local function v_u_604(p_u_592) -- name: paintTabs
		-- upvalues: (copy) v_u_231, (ref) v_u_81, (copy) v_u_21, (copy) v_u_229, (copy) v_u_31, (copy) v_u_16, (copy) v_u_588, (copy) v_u_17
		for v593, v_u_594 in v_u_231 do
			local v595 = v593 == v_u_81
			v_u_594.btn.BackgroundTransparency = v595 and 1 or 0.4
			local v596 = v_u_594.label
			local v597
			if v595 then
				v597 = v_u_21.Text
			else
				v597 = v_u_21.TextDim
			end
			v596.TextColor3 = v597
			if not v595 then
				continue
			end
			task.defer(function()
				-- upvalues: (copy) v_u_594, (ref) v_u_229, (ref) v_u_31, (copy) p_u_592, (ref) v_u_16, (ref) v_u_588, (ref) v_u_17
				local v598 = v_u_594.btn.AbsolutePosition - v_u_229.AbsolutePosition
				local v599 = v_u_229.AbsoluteSize.X
				local v600 = v_u_31.Holder.Size.X.Offset - 44 - 400 - 18
				local v601 = v599 / math.max(v600, 1)
				local v602 = math.max(v601, 0.01)
				local v603 = {
					["Position"] = UDim2.fromOffset(v598.X / v602, v598.Y / v602),
					["Size"] = UDim2.fromOffset(v_u_594.btn.AbsoluteSize.X / v602, v_u_594.btn.AbsoluteSize.Y / v602)
				}
				if p_u_592 then
					v_u_16.Tween(v_u_588, v_u_17.Tween.Smooth, v603)
				else
					v_u_588.Position = v603.Position
					v_u_588.Size = v603.Size
				end
			end)
		end
	end
	for v605, v_u_606 in v_u_19.FILTERS do
		local v_u_607 = v_u_16.new("TextButton", {
			["Name"] = v_u_606.id,
			["Size"] = UDim2.fromOffset(0, 36),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["BackgroundColor3"] = v_u_21.Raised,
			["BackgroundTransparency"] = 0.4,
			["LayoutOrder"] = v605,
			["ZIndex"] = 2,
			v_u_16.Corner(v_u_17.Radius.Pill),
			v_u_16.Padding(0, 16, 0, 16),
			["Parent"] = v230
		})
		local v608 = {
			["btn"] = v_u_607,
			["label"] = v_u_16.new("TextLabel", {
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 15,
				["TextColor3"] = nil,
				["ZIndex"] = 2,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(0, 1),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["Text"] = v_u_606.name,
				["FontFace"] = v_u_22.Heavy,
				["TextColor3"] = v_u_21.TextDim,
				["Parent"] = v_u_607
			})
		}
		v_u_231[v_u_606.id] = v608
		v_u_607.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_81, (copy) v_u_606, (copy) v_u_607
			if v_u_81 ~= v_u_606.id then
				v_u_607.BackgroundTransparency = 0.2
			end
		end)
		v_u_607.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_607, (ref) v_u_81, (copy) v_u_606
			v_u_607.BackgroundTransparency = v_u_81 == v_u_606.id and 1 or 0.4
		end)
		v_u_607.Activated:Connect(function()
			-- upvalues: (ref) v_u_81, (copy) v_u_606, (copy) p_u_15, (copy) v_u_604, (copy) v_u_365, (copy) v_u_370, (copy) v_u_382
			if v_u_81 ~= v_u_606.id then
				v_u_81 = v_u_606.id
				p_u_15.Sounds.Play("Tab")
				v_u_604(true)
				v_u_365()
				v_u_370()
				task.defer(v_u_382)
			end
		end)
	end
	v_u_604()
	local v_u_609 = false
	local v_u_610 = nil
	local v_u_611 = nil
	local v_u_612 = v_u_16.new("Frame", {
		["Name"] = "InsertMarker",
		["Size"] = UDim2.new(1, 0, 0, 3),
		["BackgroundColor3"] = v_u_21.Accent,
		["Visible"] = false,
		["ZIndex"] = 8,
		v_u_16.Corner(2),
		["Parent"] = v_u_176
	})
	local function v_u_614() -- name: sweepGhosts
		-- upvalues: (ref) v_u_611, (copy) p_u_15, (copy) v_u_612
		if v_u_611 then
			v_u_611:Destroy()
			v_u_611 = nil
		end
		for _, v613 in p_u_15.Canvas.Top:GetChildren() do
			if v613.Name ~= "DragGhost" then
				continue
			end
			v613:Destroy()
		end
		v_u_612.Visible = false
	end
	local v_u_615 = nil
	local function v_u_639(p616) -- name: endPress
		-- upvalues: (ref) v_u_610, (copy) v_u_614, (ref) v_u_615, (copy) v_u_16, (copy) v_u_176, (ref) v_u_275, (ref) v_u_179, (ref) v_u_62, (copy) p_u_15, (ref) v_u_77, (ref) v_u_74, (ref) v_u_66, (ref) v_u_76, (copy) v_u_148, (copy) v_u_533, (copy) v_u_526, (copy) v_u_177, (ref) v_u_72, (ref) v_u_12
		local v617 = v_u_610
		v_u_610 = nil
		local v618
		if v617 == nil then
			v618 = false
		else
			v618 = v617.dragging
		end
		v_u_614()
		if v617 then
			local v619 = {
				["commit"] = p616,
				["dragging"] = v618,
				["from"] = v617.index
			}
			local v620 = v617.input
			local v621
			if v620.UserInputType == Enum.UserInputType.Touch then
				v621 = Vector2.new(v620.Position.X, v620.Position.Y)
			else
				v621 = v_u_16.PointerAbs()
			end
			local v622 = v_u_176.AbsoluteSize.X / 400
			local v623 = (v621.Y - v_u_176.AbsolutePosition.Y) / math.max(v622, 0.01) / (v_u_275 + v_u_179)
			local v624 = math.floor(v623) + 1
			local v625 = #v_u_62.items
			local v626 = math.max(v625, 1)
			v619.to = math.clamp(v624, 1, v626)
			v_u_615 = v619
			if v618 then
				local v627 = v617.input
				local v628
				if v627.UserInputType == Enum.UserInputType.Touch then
					v628 = Vector2.new(v627.Position.X, v627.Position.Y)
				else
					v628 = v_u_16.PointerAbs()
				end
				local v629 = v_u_176.AbsoluteSize.X / 400
				local v630 = (v628.Y - v_u_176.AbsolutePosition.Y) / math.max(v629, 0.01) / (v_u_275 + v_u_179)
				local v631 = math.floor(v630) + 1
				local v632 = #v_u_62.items
				local v633 = math.max(v632, 1)
				local v634 = math.clamp(v631, 1, v633)
				if p616 and (v634 ~= v617.index and v_u_62.items[v617.index]) then
					local v635 = table.remove(v_u_62.items, v617.index)
					local v636 = v_u_62.items
					table.insert(v636, v634, v635)
					p_u_15.Sounds.Play("Equip")
					v_u_77 = true
					v_u_74 = v_u_66
					v_u_76 = v_u_76 + 1
					local v_u_637 = v_u_76
					v_u_148.Text = ""
					task.delay(1.2, function()
						-- upvalues: (copy) v_u_637, (ref) v_u_76, (ref) v_u_533
						if v_u_637 == v_u_76 then
							v_u_533()
						end
					end)
					v_u_526()
					v_u_16.Pop(v_u_177[v634].tile, 1.18)
				else
					v_u_526()
				end
			else
				if p616 and not v617.armed then
					local v638 = v_u_62.items[v617.index]
					if v638 then
						v_u_72 = v638
						v_u_12._paintDetail()
						return
					end
				else
					v_u_526()
				end
				return
			end
		else
			return
		end
	end
	local function v_u_648(p640) -- name: liftGhost
		-- upvalues: (copy) v_u_614, (ref) v_u_62, (copy) v_u_16, (ref) v_u_275, (copy) v_u_21, (copy) p_u_15, (copy) v_u_19, (ref) v_u_14, (copy) v_u_20, (copy) v_u_22, (ref) v_u_611, (copy) v_u_177
		v_u_614()
		p640.dragging = true
		local v641 = v_u_62.items[p640.index]
		local v642 = v_u_16.new("Frame", {
			["Name"] = "DragGhost",
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Size"] = UDim2.fromOffset(320, v_u_275),
			["BackgroundColor3"] = v_u_21.Raised,
			["BackgroundTransparency"] = 0.05,
			["ZIndex"] = 50,
			v_u_16.Corner(12),
			v_u_16.Stroke(v_u_21.Accent, 2, 0),
			["Parent"] = p_u_15.Canvas.Top
		})
		local v643 = v_u_16.new
		local v644 = {
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 4, 0.5, 0),
			["Size"] = UDim2.fromOffset(v_u_275 - 8, v_u_275 - 8)
		}
		local v645 = v_u_19.Get(v641)
		v644.BackgroundColor3 = (v645 and v_u_14[v645.category] or v_u_21.Accent):Lerp(v_u_21.Panel, 0.6)
		v644.ZIndex = 51
		__set_list(v644, 1, {(v_u_16.Corner(9))})
		v644.Parent = v642
		local v646 = v643("Frame", v644)
		local v647 = v_u_16.new("Frame", {
			["Size"] = nil,
			["ZIndex"] = 52,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v646
		})
		v_u_20.Set(v647, v641, {
			["outline"] = false,
			["glow"] = false
		})
		v_u_16.new("TextLabel", {
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 17,
			["TextXAlignment"] = nil,
			["ZIndex"] = 51,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(v_u_275 + 8, 0),
			["Size"] = UDim2.new(1, -(v_u_275 + 16), 1, 0),
			["Text"] = v_u_19.Name(v641),
			["FontFace"] = v_u_22.Bold,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v642
		})
		v_u_611 = v642
		v_u_177[p640.index].frame.BackgroundTransparency = 0.85
	end
	local function v_u_663(p649, p650) -- name: moveGhost
		-- upvalues: (ref) v_u_611, (copy) p_u_15, (copy) v_u_16, (copy) v_u_176, (ref) v_u_275, (ref) v_u_179, (ref) v_u_62, (copy) v_u_612
		local v651 = v_u_611
		if v651 then
			local v652 = p_u_15.Canvas.Top
			local v653 = v_u_16.Scale
			local v654 = math.max(v653, 0.01)
			local v655 = (p650 - v652.AbsolutePosition) / v654
			v651.Position = UDim2.fromOffset(v655.X - 40, v655.Y)
			local v656 = v_u_176.AbsoluteSize.X / 400
			local v657 = (p650.Y - v_u_176.AbsolutePosition.Y) / math.max(v656, 0.01) / (v_u_275 + v_u_179)
			local v658 = math.floor(v657) + 1
			local v659 = #v_u_62.items
			local v660 = math.max(v659, 1)
			local v661 = math.clamp(v658, 1, v660)
			v_u_612.Visible = v661 ~= p649.index
			local v662
			if v661 < p649.index then
				v662 = (v661 - 1) * (v_u_275 + v_u_179) - 4
			else
				v662 = v661 * (v_u_275 + v_u_179) - 4
			end
			v_u_612.Position = UDim2.fromOffset(0, v662)
		end
	end
	local v_u_664 = v_u_611
	local v_u_665 = v_u_615
	local v_u_666 = v_u_610
	for v_u_667, v_u_668 in v_u_177 do
		v_u_668.frame.InputBegan:Connect(function(p669)
			-- upvalues: (ref) v_u_666, (ref) v_u_62, (copy) v_u_667, (copy) v_u_31, (copy) v_u_16, (copy) v_u_668, (copy) v_u_614, (ref) v_u_665, (copy) v_u_176, (ref) v_u_275, (ref) v_u_179, (copy) v_u_526, (ref) v_u_609
			local v670 = p669.UserInputType
			if v670 == Enum.UserInputType.MouseButton1 or v670 == Enum.UserInputType.Touch then
				if p669.UserInputState == Enum.UserInputState.Begin and (not v_u_666 or v_u_666.input ~= p669) then
					if v_u_62.items[v_u_667] and v_u_31.IsOpen then
						local v671
						if p669.UserInputType == Enum.UserInputType.Touch then
							v671 = Vector2.new(p669.Position.X, p669.Position.Y)
						else
							v671 = v_u_16.PointerAbs()
						end
						if v_u_668.remove.Visible then
							local v672 = v_u_668.remove
							local v673 = v672.AbsolutePosition
							local v674 = v672.AbsoluteSize
							local v675
							if v671.X >= v673.X and (v671.X <= v673.X + v674.X and v671.Y >= v673.Y) then
								v675 = v671.Y <= v673.Y + v674.Y
							else
								v675 = false
							end
							if v675 then
								return
							end
						end
						if v_u_666 then
							local v676 = v_u_666
							v_u_666 = nil
							local v677
							if v676 == nil then
								v677 = false
							else
								v677 = v676.dragging
							end
							v_u_614()
							if v676 then
								local v678 = {
									["commit"] = false,
									["dragging"] = nil,
									["from"] = nil,
									["to"] = nil,
									["dragging"] = v677,
									["from"] = v676.index
								}
								local v679 = v676.input
								local v680
								if v679.UserInputType == Enum.UserInputType.Touch then
									v680 = Vector2.new(v679.Position.X, v679.Position.Y)
								else
									v680 = v_u_16.PointerAbs()
								end
								local v681 = v_u_176.AbsoluteSize.X / 400
								local v682 = (v680.Y - v_u_176.AbsolutePosition.Y) / math.max(v681, 0.01) / (v_u_275 + v_u_179)
								local v683 = math.floor(v682) + 1
								local v684 = #v_u_62.items
								local v685 = math.max(v684, 1)
								v678.to = math.clamp(v683, 1, v685)
								v_u_665 = v678
								if v677 then
									local v686 = v676.input
									local v687
									if v686.UserInputType == Enum.UserInputType.Touch then
										v687 = Vector2.new(v686.Position.X, v686.Position.Y)
									else
										v687 = v_u_16.PointerAbs()
									end
									local v688 = v_u_176.AbsoluteSize.X / 400
									local v689 = (v687.Y - v_u_176.AbsolutePosition.Y) / math.max(v688, 0.01) / (v_u_275 + v_u_179)
									local v690 = math.floor(v689) + 1
									local v691 = #v_u_62.items
									local v692 = math.max(v691, 1)
									math.clamp(v690, 1, v692)
									v_u_526()
								else
									v_u_526()
								end
							end
						end
						v_u_666 = {
							["index"] = nil,
							["input"] = nil,
							["start"] = nil,
							["at"] = nil,
							["hold"] = nil,
							["armed"] = false,
							["dragging"] = false,
							["index"] = v_u_667,
							["input"] = p669,
							["start"] = v671,
							["at"] = os.clock(),
							["hold"] = v670 == Enum.UserInputType.Touch and true or (v_u_16.Touch or v_u_609)
						}
					end
				else
					return
				end
			else
				return
			end
		end)
	end
	v_u_1.InputChanged:Connect(function(p693)
		-- upvalues: (ref) v_u_666, (copy) v_u_16, (copy) v_u_614, (ref) v_u_665, (copy) v_u_176, (ref) v_u_275, (ref) v_u_179, (ref) v_u_62, (copy) v_u_526, (copy) v_u_648, (copy) v_u_663
		local v694 = v_u_666
		if v694 then
			local v695 = v694.input.UserInputType == Enum.UserInputType.Touch
			if v695 then
				if p693 ~= v694.input then
					return
				end
			elseif p693.UserInputType ~= Enum.UserInputType.MouseMovement then
				return
			end
			if v695 then
				p693 = v694.input
			end
			local v696
			if p693.UserInputType == Enum.UserInputType.Touch then
				v696 = Vector2.new(p693.Position.X, p693.Position.Y)
			else
				v696 = v_u_16.PointerAbs()
			end
			local v697 = (v696 - v694.start).Magnitude
			if not v694.dragging then
				if v694.hold then
					if not v694.armed then
						if v697 > 12 then
							local v698 = v_u_666
							v_u_666 = nil
							local v699
							if v698 == nil then
								v699 = false
							else
								v699 = v698.dragging
							end
							v_u_614()
							if not v698 then
								return
							end
							local v700 = {
								["commit"] = false,
								["dragging"] = nil,
								["from"] = nil,
								["to"] = nil,
								["dragging"] = v699,
								["from"] = v698.index
							}
							local v701 = v698.input
							local v702
							if v701.UserInputType == Enum.UserInputType.Touch then
								v702 = Vector2.new(v701.Position.X, v701.Position.Y)
							else
								v702 = v_u_16.PointerAbs()
							end
							local v703 = v_u_176.AbsoluteSize.X / 400
							local v704 = (v702.Y - v_u_176.AbsolutePosition.Y) / math.max(v703, 0.01) / (v_u_275 + v_u_179)
							local v705 = math.floor(v704) + 1
							local v706 = #v_u_62.items
							local v707 = math.max(v706, 1)
							v700.to = math.clamp(v705, 1, v707)
							v_u_665 = v700
							if v699 then
								local v708 = v698.input
								local v709
								if v708.UserInputType == Enum.UserInputType.Touch then
									v709 = Vector2.new(v708.Position.X, v708.Position.Y)
								else
									v709 = v_u_16.PointerAbs()
								end
								local v710 = v_u_176.AbsoluteSize.X / 400
								local v711 = (v709.Y - v_u_176.AbsolutePosition.Y) / math.max(v710, 0.01) / (v_u_275 + v_u_179)
								local v712 = math.floor(v711) + 1
								local v713 = #v_u_62.items
								local v714 = math.max(v713, 1)
								math.clamp(v712, 1, v714)
								v_u_526()
								return
							end
							v_u_526()
						end
						return
					end
					if v697 > 6 then
						v_u_648(v694)
					end
				elseif v697 > 12 then
					v_u_648(v694)
				end
			end
			if v694.dragging then
				v_u_663(v694, v696)
			end
		end
	end)
	local function v717(p715) -- name: onEnded
		-- upvalues: (ref) v_u_666, (copy) v_u_639
		local v716 = v_u_666
		if v716 then
			if v716.input.UserInputType == Enum.UserInputType.Touch then
				if p715 ~= v716.input then
					return
				end
			elseif p715.UserInputType ~= Enum.UserInputType.MouseButton1 then
				return
			end
			v_u_639(true)
		end
	end
	v_u_1.InputEnded:Connect(v717)
	v_u_1.TouchEnded:Connect(v717)
	v_u_1.WindowFocusReleased:Connect(function()
		-- upvalues: (ref) v_u_666, (copy) v_u_614, (ref) v_u_665, (copy) v_u_16, (copy) v_u_176, (ref) v_u_275, (ref) v_u_179, (ref) v_u_62, (copy) v_u_526
		local v718 = v_u_666
		v_u_666 = nil
		local v719
		if v718 == nil then
			v719 = false
		else
			v719 = v718.dragging
		end
		v_u_614()
		if v718 then
			local v720 = {
				["commit"] = false,
				["dragging"] = nil,
				["from"] = nil,
				["to"] = nil,
				["dragging"] = v719,
				["from"] = v718.index
			}
			local v721 = v718.input
			local v722
			if v721.UserInputType == Enum.UserInputType.Touch then
				v722 = Vector2.new(v721.Position.X, v721.Position.Y)
			else
				v722 = v_u_16.PointerAbs()
			end
			local v723 = v_u_176.AbsoluteSize.X / 400
			local v724 = (v722.Y - v_u_176.AbsolutePosition.Y) / math.max(v723, 0.01) / (v_u_275 + v_u_179)
			local v725 = math.floor(v724) + 1
			local v726 = #v_u_62.items
			local v727 = math.max(v726, 1)
			v720.to = math.clamp(v725, 1, v727)
			v_u_665 = v720
			if v719 then
				local v728 = v718.input
				local v729
				if v728.UserInputType == Enum.UserInputType.Touch then
					v729 = Vector2.new(v728.Position.X, v728.Position.Y)
				else
					v729 = v_u_16.PointerAbs()
				end
				local v730 = v_u_176.AbsoluteSize.X / 400
				local v731 = (v729.Y - v_u_176.AbsolutePosition.Y) / math.max(v730, 0.01) / (v_u_275 + v_u_179)
				local v732 = math.floor(v731) + 1
				local v733 = #v_u_62.items
				local v734 = math.max(v733, 1)
				math.clamp(v732, 1, v734)
				v_u_526()
			else
				v_u_526()
			end
		else
			return
		end
	end)
	v_u_16.Every(v_u_176, 0.1, function()
		-- upvalues: (ref) v_u_666, (ref) v_u_664, (copy) v_u_612, (copy) v_u_614, (copy) v_u_526, (copy) v_u_31, (ref) v_u_665, (copy) v_u_16, (copy) v_u_176, (ref) v_u_275, (ref) v_u_179, (ref) v_u_62, (copy) v_u_639, (ref) v_u_1, (copy) v_u_177, (copy) p_u_15
		local v735 = v_u_666
		if v735 then
			local v736 = v735.input.UserInputState
			if v_u_31.IsOpen and v736 ~= Enum.UserInputState.Cancel then
				if v736 == Enum.UserInputState.End then
					v_u_639(true)
					return
				elseif v735.input.UserInputType == Enum.UserInputType.MouseButton1 and not v_u_1:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) then
					v_u_639(true)
				elseif v735.hold and (not v735.armed and os.clock() - v735.at >= 0.28) then
					v735.armed = true
					v_u_177[v735.index].frame.BackgroundTransparency = 0.12
					v_u_16.Bump(v_u_177[v735.index].tile, 0.08)
					p_u_15.Sounds.Play("Select")
				end
			else
				local v737 = v_u_666
				v_u_666 = nil
				local v738
				if v737 == nil then
					v738 = false
				else
					v738 = v737.dragging
				end
				v_u_614()
				if v737 then
					local v739 = {
						["commit"] = false,
						["dragging"] = nil,
						["from"] = nil,
						["to"] = nil,
						["dragging"] = v738,
						["from"] = v737.index
					}
					local v740 = v737.input
					local v741
					if v740.UserInputType == Enum.UserInputType.Touch then
						v741 = Vector2.new(v740.Position.X, v740.Position.Y)
					else
						v741 = v_u_16.PointerAbs()
					end
					local v742 = v_u_176.AbsoluteSize.X / 400
					local v743 = (v741.Y - v_u_176.AbsolutePosition.Y) / math.max(v742, 0.01) / (v_u_275 + v_u_179)
					local v744 = math.floor(v743) + 1
					local v745 = #v_u_62.items
					local v746 = math.max(v745, 1)
					v739.to = math.clamp(v744, 1, v746)
					v_u_665 = v739
					if v738 then
						local v747 = v737.input
						local v748
						if v747.UserInputType == Enum.UserInputType.Touch then
							v748 = Vector2.new(v747.Position.X, v747.Position.Y)
						else
							v748 = v_u_16.PointerAbs()
						end
						local v749 = v_u_176.AbsoluteSize.X / 400
						local v750 = (v748.Y - v_u_176.AbsolutePosition.Y) / math.max(v749, 0.01) / (v_u_275 + v_u_179)
						local v751 = math.floor(v750) + 1
						local v752 = #v_u_62.items
						local v753 = math.max(v752, 1)
						math.clamp(v751, 1, v753)
						v_u_526()
					else
						v_u_526()
					end
				else
					return
				end
			end
		else
			if v_u_664 or v_u_612.Visible then
				v_u_614()
				v_u_526()
			end
			return
		end
	end)
	function p_u_15.Debug.drag(p754, p755)
		-- upvalues: (ref) v_u_609, (copy) p_u_15, (ref) v_u_666, (ref) v_u_665
		if p754 == "hold" then
			v_u_609 = p755 == true
		end
		local v756 = 0
		for _, v757 in p_u_15.Canvas.Top:GetChildren() do
			if v757.Name ~= "DragGhost" then
				continue
			end
			v756 = v756 + 1
		end
		local v758 = {
			["press"] = v_u_666 ~= nil
		}
		local v759
		if v_u_666 == nil then
			v759 = false
		else
			v759 = v_u_666.dragging
		end
		v758.dragging = v759
		local v760
		if v_u_666 == nil then
			v760 = false
		else
			v760 = v_u_666.armed
		end
		v758.armed = v760
		v758.ghosts = v756
		v758.lastEnd = v_u_665
		return v758
	end
	function p_u_15.Debug.gear(p761, p762, p763)
		-- upvalues: (ref) v_u_72, (ref) v_u_589, (copy) v_u_235, (copy) v_u_19, (ref) v_u_62, (copy) v_u_80, (ref) v_u_77, (ref) v_u_74, (ref) v_u_66, (ref) v_u_76, (copy) v_u_148, (copy) v_u_533, (copy) v_u_526, (ref) v_u_591, (ref) v_u_81, (copy) v_u_604, (copy) v_u_365, (copy) v_u_370, (copy) v_u_382, (ref) v_u_71, (ref) v_u_554, (copy) v_u_18
		if p761 == "toggle" then
			v_u_72 = p762
			v_u_589(p762, v_u_235[p762])
		elseif p761 == "set" and type(p762) == "table" then
			local _, _, v764 = v_u_19.Validate(p762)
			v_u_62 = v_u_80(v764)
			v_u_72 = v_u_62.items[1] or v_u_72
			v_u_77 = true
			v_u_74 = v_u_66
			v_u_76 = v_u_76 + 1
			local v_u_765 = v_u_76
			v_u_148.Text = ""
			task.delay(1.2, function()
				-- upvalues: (copy) v_u_765, (ref) v_u_76, (ref) v_u_533
				if v_u_765 == v_u_76 then
					v_u_533()
				end
			end)
			v_u_526()
		elseif p761 == "ammo" then
			v_u_591(p762, p763)
		elseif p761 == "filter" then
			v_u_81 = p762
			v_u_604(true)
			v_u_365()
			v_u_370()
			task.defer(v_u_382)
		elseif p761 == "hover" then
			v_u_71 = p762
			v_u_72 = p762 or v_u_72
			v_u_526()
		elseif p761 == "slot" then
			v_u_554(p762)
		end
		return {
			["items"] = v_u_62.items,
			["armor"] = v_u_62.armor,
			["ammo"] = v_u_62.ammo,
			["cost"] = v_u_19.Cost(v_u_62),
			["saved"] = v_u_148.Text,
			["slot"] = v_u_66,
			["active"] = v_u_18.ActiveLoadout(),
			["slots"] = v_u_18.LoadoutSlotCount()
		}
	end
	local v_u_766 = false
	v_u_18.ProfileChanged:Connect(function()
		-- upvalues: (copy) v_u_31, (copy) v_u_65, (copy) v_u_18, (ref) v_u_77, (ref) v_u_277, (ref) v_u_66, (ref) v_u_73, (ref) v_u_62, (copy) v_u_80, (copy) v_u_526
		if v_u_31.IsOpen then
			for v767, v768 in v_u_65 do
				if v_u_18.LoadoutCustomName(v767) ~= v768 then
					continue
				end
				v_u_65[v767] = nil
			end
			if v_u_77 then
				v_u_277()
			else
				v_u_66 = v_u_73 or v_u_18.ActiveLoadout()
				v_u_62 = v_u_80(v_u_18.LoadoutSlot(v_u_66))
				v_u_526()
			end
		else
			return
		end
	end)
	local v815 = {
		["open"] = function(p769) -- name: open
			-- upvalues: (copy) v_u_309, (ref) v_u_766, (copy) v_u_19, (copy) v_u_262, (copy) v_u_234, (copy) v_u_235, (ref) v_u_66, (copy) v_u_18, (ref) v_u_73, (ref) v_u_62, (copy) v_u_80, (ref) v_u_77, (copy) v_u_542, (ref) v_u_72, (ref) v_u_81, (ref) v_u_71, (ref) v_u_590, (copy) v_u_148, (ref) v_u_6, (ref) v_u_4, (ref) v_u_5, (copy) v_u_31, (copy) v_u_365, (copy) v_u_526, (copy) v_u_604, (copy) v_u_370, (copy) v_u_382, (copy) v_u_232, (copy) v_u_577
			v_u_309()
			if not v_u_766 then
				v_u_766 = true
				for _, v770 in v_u_19.AllItems() do
					if v770.category == "ammo" then
						continue
					end
					local v771 = v_u_262(v770)
					local v772 = v_u_234
					table.insert(v772, v771)
					v_u_235[v770.id] = v771
				end
			end
			v_u_66 = v_u_18.ActiveLoadout()
			v_u_73 = nil
			local _, _, v773 = v_u_19.Validate(v_u_18.LoadoutSlot(v_u_66))
			v_u_62 = v_u_80(v773)
			v_u_77 = false
			v_u_542()
			v_u_72 = v_u_62.items[1] or v_u_19.DefaultLoadout().items[1]
			local v_u_774
			if type(p769) == "table" then
				local v775 = p769.focus
				v_u_774 = type(v775) == "string" and (v_u_19.Get(p769.focus) and p769.focus) or nil
			else
				v_u_774 = nil
			end
			if v_u_774 then
				v_u_72 = v_u_774
				if v_u_81 ~= "all" then
					v_u_81 = "all"
				end
			end
			v_u_71 = nil
			v_u_590 = nil
			v_u_148.Text = ""
			if not v_u_6 then
				local v_u_776 = {}
				local function v779()
					-- upvalues: (ref) v_u_4, (copy) v_u_776, (ref) v_u_5
					if v_u_4.ChatVersion == Enum.ChatVersion.TextChatService then
						local v777 = v_u_4:FindFirstChildOfClass("ChatWindowConfiguration")
						local v778 = v_u_4:FindFirstChildOfClass("ChatInputBarConfiguration")
						if v777 then
							v_u_776.window = v777.Enabled
							v777.Enabled = false
						end
						if v778 then
							v_u_776.bar = v778.Enabled
							v778.Enabled = false
							return
						end
					else
						v_u_776.core = v_u_5:GetCoreGuiEnabled(Enum.CoreGuiType.Chat)
						v_u_5:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, false)
					end
				end
				pcall(v779)
				v_u_6 = v_u_776
			end
			v_u_31:Open()
			task.defer(function()
				-- upvalues: (ref) v_u_365, (ref) v_u_526, (ref) v_u_604, (ref) v_u_370, (ref) v_u_382, (copy) v_u_774, (ref) v_u_235, (ref) v_u_232, (ref) v_u_31, (ref) v_u_577
				v_u_365()
				v_u_526()
				v_u_604()
				v_u_370()
				v_u_382()
				local v_u_780 = v_u_774
				if v_u_780 then
					v_u_780 = v_u_235[v_u_774]
				end
				if v_u_780 then
					local v781 = v_u_232.AbsoluteSize.X
					local v782 = v_u_31.Holder.Size.X.Offset - 44 - 400 - 18
					local v783 = v781 / math.max(v782, 1)
					local v784 = math.max(v783, 0.01)
					local v785 = v_u_780.y - 8
					local v786 = math.max(0, v785) * v784
					local v787 = v_u_232.AbsoluteCanvasSize.Y - v_u_232.AbsoluteWindowSize.Y
					local v788 = math.max(0, v787)
					v_u_232.CanvasPosition = Vector2.new(0, (math.min(v786, v788)))
					v_u_382()
					task.delay(0.3, function()
						-- upvalues: (ref) v_u_577, (copy) v_u_780
						v_u_577(v_u_780)
					end)
				end
			end)
		end,
		["close"] = function(p789) -- name: close
			-- upvalues: (ref) v_u_6, (ref) v_u_4, (ref) v_u_5, (ref) v_u_77, (copy) v_u_80, (ref) v_u_62, (ref) v_u_74, (ref) v_u_76, (copy) v_u_533, (copy) p_u_15, (ref) v_u_666, (copy) v_u_614, (ref) v_u_665, (copy) v_u_16, (copy) v_u_176, (ref) v_u_275, (ref) v_u_179, (copy) v_u_526, (copy) v_u_31
			local v_u_790 = v_u_6
			if v_u_790 then
				v_u_6 = nil
				local function v793()
					-- upvalues: (ref) v_u_4, (copy) v_u_790, (ref) v_u_5
					local v791 = v_u_4:FindFirstChildOfClass("ChatWindowConfiguration")
					local v792 = v_u_4:FindFirstChildOfClass("ChatInputBarConfiguration")
					if v791 and v_u_790.window ~= nil then
						v791.Enabled = v_u_790.window
					end
					if v792 and v_u_790.bar ~= nil then
						v792.Enabled = v_u_790.bar
					end
					if v_u_790.core ~= nil then
						v_u_5:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, v_u_790.core)
					end
				end
				pcall(v793)
			end
			if v_u_77 then
				local v794 = v_u_80(v_u_62)
				local v795 = v_u_74
				v_u_77 = false
				v_u_76 = v_u_76 + 1
				task.spawn(v_u_533, v794, v795)
			end
			if #v_u_62.items == 0 then
				p_u_15.Toast("A loadout needs at least one item. Your last one was kept.", "info")
			end
			local v796 = v_u_666
			v_u_666 = nil
			local v797
			if v796 == nil then
				v797 = false
			else
				v797 = v796.dragging
			end
			v_u_614()
			if v796 then
				local v798 = {
					["commit"] = false,
					["dragging"] = nil,
					["from"] = nil,
					["to"] = nil,
					["dragging"] = v797,
					["from"] = v796.index
				}
				local v799 = v796.input
				local v800
				if v799.UserInputType == Enum.UserInputType.Touch then
					v800 = Vector2.new(v799.Position.X, v799.Position.Y)
				else
					v800 = v_u_16.PointerAbs()
				end
				local v801 = v_u_176.AbsoluteSize.X / 400
				local v802 = (v800.Y - v_u_176.AbsolutePosition.Y) / math.max(v801, 0.01) / (v_u_275 + v_u_179)
				local v803 = math.floor(v802) + 1
				local v804 = #v_u_62.items
				local v805 = math.max(v804, 1)
				v798.to = math.clamp(v803, 1, v805)
				v_u_665 = v798
				if v797 then
					local v806 = v796.input
					local v807
					if v806.UserInputType == Enum.UserInputType.Touch then
						v807 = Vector2.new(v806.Position.X, v806.Position.Y)
					else
						v807 = v_u_16.PointerAbs()
					end
					local v808 = v_u_176.AbsoluteSize.X / 400
					local v809 = (v807.Y - v_u_176.AbsolutePosition.Y) / math.max(v808, 0.01) / (v_u_275 + v_u_179)
					local v810 = math.floor(v809) + 1
					local v811 = #v_u_62.items
					local v812 = math.max(v811, 1)
					math.clamp(v810, 1, v812)
					v_u_526()
				else
					v_u_526()
				end
			end
			v_u_31:Close(p789)
		end,
		["select"] = function() -- name: select
			-- upvalues: (ref) v_u_72, (copy) v_u_235, (copy) v_u_234
			local v813 = v_u_72
			if v813 then
				v813 = v_u_235[v_u_72]
			end
			if v813 and v813.holder.Visible then
				return v813.holder
			end
			for _, v814 in v_u_234 do
				if not v814.holder.Visible then
					continue
				end
				return v814.holder
			end
			return nil
		end
	}
	p_u_15.MenuManager.Register("Loadout", v815)
	v_u_18.PlayerStateChanged:Connect(function(p816)
		-- upvalues: (copy) p_u_15
		if p816 == "Match" and p_u_15.MenuManager.IsOpen("Loadout") then
			p_u_15.MenuManager.Close("Loadout", true)
		end
	end)
	v_u_31.Closed:Connect(v_u_11)
	v_u_23.Changed:Connect(function()
		-- upvalues: (copy) v_u_31, (ref) v_u_766, (copy) v_u_365, (copy) v_u_382, (copy) v_u_234, (ref) v_u_12
		if v_u_31.IsOpen and v_u_766 then
			v_u_365(true)
			v_u_382()
			for _, v817 in v_u_234 do
				v_u_12._paintCard(v817)
			end
			v_u_12._paintDetail()
		end
	end)
	v_u_23.Event:Connect(function(p818, _)
		-- upvalues: (copy) v_u_31, (copy) v_u_526
		if p818 == "Unlocked" and v_u_31.IsOpen then
			task.delay(0.2, function()
				-- upvalues: (ref) v_u_526
				v_u_526()
			end)
		end
	end)
	local v_u_819 = false
	v_u_23.CelebrationChanged:Connect(function(p820)
		-- upvalues: (copy) v_u_31, (ref) v_u_819, (copy) v_u_526, (copy) v_u_577, (ref) v_u_72, (copy) v_u_235
		if p820 and (v_u_31.IsOpen and not v_u_819) then
			v_u_819 = true
			v_u_31.Holder.Visible = false
		elseif not p820 and v_u_819 then
			v_u_819 = false
			v_u_31.Holder.Visible = true
			if v_u_31.IsOpen then
				v_u_526()
				v_u_577(v_u_72 and v_u_235[v_u_72] or nil)
			end
		end
	end)
	local function v821() -- name: relayout
		-- upvalues: (copy) v_u_31, (copy) v_u_309, (copy) v_u_365, (copy) v_u_526, (copy) v_u_604, (copy) v_u_382
		if v_u_31.IsOpen then
			v_u_309()
			v_u_31.Refit()
			task.defer(function()
				-- upvalues: (ref) v_u_365, (ref) v_u_526, (ref) v_u_604, (ref) v_u_382
				v_u_365()
				v_u_526()
				v_u_604()
				v_u_382()
			end)
		end
	end
	v_u_16.LayoutChanged:Connect(v821)
	v_u_16.OnResize(v821)
end
return v_u_12