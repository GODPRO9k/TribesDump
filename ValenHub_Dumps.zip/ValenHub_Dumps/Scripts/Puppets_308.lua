local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("RunService")
local v5 = v_u_3:WaitForChild("Shared")
local v_u_6 = require(v5:WaitForChild("Weapons"))
local v_u_7 = v_u_2.LocalPlayer
local v_u_8 = {}
local v_u_9 = {}
for _, v10 in {
	"LinearVelocity",
	"VectorForce",
	"AlignOrientation",
	"AlignPosition",
	"AngularVelocity",
	"BodyVelocity",
	"BodyGyro",
	"BodyPosition",
	"BodyForce",
	"BodyAngularVelocity",
	"Torque"
} do
	v_u_8[v10] = true
end
local v_u_11 = {
	["Tool"] = true,
	["ForceField"] = true,
	["Highlight"] = true,
	["BillboardGui"] = true,
	["SurfaceGui"] = true,
	["Sound"] = true,
	["SelectionBox"] = true,
	["ProximityPrompt"] = true,
	["ClickDetector"] = true,
	["Explosion"] = true,
	["Fire"] = true,
	["Smoke"] = true,
	["Sparkles"] = true
}
local function v_u_19(p12) -- name: strip
	-- upvalues: (copy) v_u_11, (copy) v_u_8
	for _, v13 in p12:GetTags() do
		p12:RemoveTag(v13)
	end
	for _, v14 in {
		"MatchId",
		"Team",
		"CombatantId",
		"IsBot",
		"Frozen",
		"Blocking",
		"ShotNonce"
	} do
		p12:SetAttribute(v14, nil)
	end
	for _, v15 in p12:GetDescendants() do
		local v16 = v15.ClassName
		local v17 = v15:IsA("ParticleEmitter") or (v15:IsA("Trail") or v15:IsA("Beam")) or v15:IsA("Light")
		if v17 then
			v17 = v15:FindFirstAncestorOfClass("Accessory") == nil
		end
		if v15:IsA("LuaSourceContainer") or (v_u_11[v16] or (v_u_8[v16] or v17)) then
			v15:Destroy()
		else
			for _, v18 in v15:GetTags() do
				v15:RemoveTag(v18)
			end
			if v15:IsA("BasePart") then
				v15.CanCollide = false
				v15.CanQuery = false
				v15.CanTouch = false
				v15.LocalTransparencyModifier = 0
			else
				if not v15:IsA("Decal") then
					break
				end
				v15.LocalTransparencyModifier = 0
			end
		end
	end
end
local function v_u_27(p20) -- name: rigidJoints
	for _, v21 in p20:GetDescendants() do
		if v21:IsA("AnimationConstraint") or v21:IsA("RigidConstraint") then
			local v22 = v21.Attachment0
			local v23 = v21.Attachment1
			local v24
			if v22 then
				v24 = v22.Parent
			else
				v24 = v22
			end
			local v25
			if v23 then
				v25 = v23.Parent
			else
				v25 = v23
			end
			if v22 and (v23 and (v24 and (v25 and (v24:IsA("BasePart") and v25:IsA("BasePart"))))) then
				local v26
				if v21:IsA("AnimationConstraint") then
					v26 = Instance.new("Motor6D")
				else
					v26 = Instance.new("Weld")
				end
				v26.Name = v21.Name
				v26.Part0 = v24
				v26.Part1 = v25
				v26.C0 = v22.CFrame
				v26.C1 = v23.CFrame
				v26.Parent = v25
			end
			v21:Destroy()
		elseif v21:IsA("BallSocketConstraint") or (v21:IsA("HingeConstraint") or v21:IsA("NoCollisionConstraint")) then
			v21:Destroy()
		else
			if not v21:IsA("Motor6D") then
				continue
			end
			v21.Transform = CFrame.identity
		end
	end
end
local function v_u_32(p28) -- name: hasBody
	local v29 = p28:FindFirstChild("Head")
	local v30 = p28:FindFirstChild("UpperTorso") or p28:FindFirstChild("Torso")
	local v31 = v29 ~= nil and v29:IsA("BasePart")
	if v31 then
		if v30 == nil then
			v31 = false
		else
			v31 = v30:IsA("BasePart")
		end
	end
	return v31
end
function v_u_9.Snapshot(p_u_33) -- name: Snapshot
	-- upvalues: (copy) v_u_32, (copy) v_u_19, (copy) v_u_27
	if not p_u_33.Parent then
		return nil, "gone"
	end
	if not p_u_33:FindFirstChildOfClass("Humanoid") then
		return nil, "nohum"
	end
	if not p_u_33:FindFirstChild("HumanoidRootPart") then
		return nil, "noroot"
	end
	if not v_u_32(p_u_33) then
		return nil, "nobody"
	end
	local v34 = p_u_33.Archivable
	p_u_33.Archivable = true
	local v35, v36 = pcall(function()
		-- upvalues: (copy) p_u_33
		return p_u_33:Clone()
	end)
	p_u_33.Archivable = v34
	if not (v35 and v36) then
		return nil, "noclone"
	end
	if not (v_u_32(v36) and v36:FindFirstChild("HumanoidRootPart")) then
		v36:Destroy()
		return nil, "noclone"
	end
	v_u_19(v36)
	v_u_27(v36)
	return v36, nil
end
function v_u_9.FindLive(p37) -- name: FindLive
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	for _, v38 in v_u_1:GetTagged("Combatant") do
		if not v38:IsA("Model") or (v38:GetAttribute("CombatantId") ~= p37 or not v38.Parent) then
			continue
		end
		return v38
	end
	for _, v39 in v_u_2:GetPlayers() do
		local v40 = v39.Character
		if not v40 or (v40:GetAttribute("CombatantId") ~= p37 or not v40.Parent) then
			continue
		end
		return v40
	end
	return nil
end
local v_u_41 = {}
local v_u_42 = ""
local v_u_43 = {}
local v_u_44 = {}
local v_u_45 = false
local function v_u_47() -- name: clearCache
	-- upvalues: (copy) v_u_41, (copy) v_u_43, (copy) v_u_44
	for _, v46 in v_u_41 do
		v46:Destroy()
	end
	table.clear(v_u_41)
	table.clear(v_u_43)
	table.clear(v_u_44)
end
function v_u_9.CacheMatch() -- name: CacheMatch
	-- upvalues: (copy) v_u_7, (ref) v_u_42, (copy) v_u_47, (copy) v_u_44, (copy) v_u_43, (copy) v_u_1, (copy) v_u_2, (ref) v_u_45, (copy) v_u_9, (copy) v_u_32, (copy) v_u_41
	local v_u_48 = v_u_7:GetAttribute("MatchId")
	if type(v_u_48) == "string" and v_u_48 ~= "" then
		if v_u_48 ~= v_u_42 then
			v_u_47()
			v_u_42 = v_u_48
		end
		local function v52(p49) -- name: consider
			-- upvalues: (copy) v_u_48, (ref) v_u_44, (ref) v_u_43
			if p49 and (p49:IsA("Model") and p49:GetAttribute("MatchId") == v_u_48) then
				local v50 = p49:GetAttribute("CombatantId")
				if type(v50) == "string" and (v50 ~= "" and not v_u_44[v50]) then
					v_u_44[v50] = true
					local v51 = v_u_43
					table.insert(v51, v50)
				end
			end
		end
		for _, v53 in v_u_1:GetTagged("Combatant") do
			v52(v53)
		end
		for _, v54 in v_u_2:GetPlayers() do
			v52(v54.Character)
		end
		if not v_u_45 then
			v_u_45 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_43, (ref) v_u_44, (ref) v_u_9, (ref) v_u_32, (ref) v_u_41, (ref) v_u_45
				while #v_u_43 > 0 do
					local v55 = table.remove(v_u_43, 1)
					v_u_44[v55] = nil
					local v56 = v_u_9.FindLive(v55)
					if v56 then
						local v57 = v56:FindFirstChildOfClass("Humanoid")
						local v58
						if v57 == nil or (v57.Health <= 0 or v56:FindFirstChild("HumanoidRootPart") == nil) then
							v58 = false
						else
							v58 = v_u_32(v56)
						end
						local v59 = v58 and v_u_9.Snapshot(v56)
						if v59 then
							local v60 = v_u_41[v55]
							v_u_41[v55] = v59
							if v60 then
								v60:Destroy()
							end
						end
					end
					task.wait()
				end
				v_u_45 = false
			end)
		end
	else
		return
	end
end
function v_u_9.ClearCache() -- name: ClearCache
	-- upvalues: (copy) v_u_47, (ref) v_u_42
	v_u_47()
	v_u_42 = ""
end
local v_u_61 = nil
local function v_u_72(p62) -- name: makeTool
	-- upvalues: (copy) v_u_6, (ref) v_u_61, (copy) v_u_3
	local v63 = v_u_6.Get(p62)
	if not (v_u_61 and v_u_61.Parent) then
		local v64 = v_u_3:FindFirstChild("Assets")
		if v64 then
			v64 = v64:FindFirstChild("Weapons")
		end
		v_u_61 = v64
	end
	local v65 = v_u_61
	if v65 then
		v65 = v_u_61:FindFirstChild(p62)
	end
	if not v63 or (not v65 or v63.hotbar == false) then
		return nil
	end
	local v66 = Instance.new("Tool")
	v66.Name = v63.name or p62
	v66.CanBeDropped = false
	v66.ManualActivationOnly = true
	v66.RequiresHandle = true
	v66:SetAttribute("WeaponId", p62)
	v66:SetAttribute("Kind", v63.kind)
	local v67 = v65:Clone()
	for _, v68 in v67:GetChildren() do
		v68.Parent = v66
	end
	v67:Destroy()
	local v69 = v66:FindFirstChild("Handle")
	if not (v69 and v69:IsA("BasePart")) then
		v66:Destroy()
		return nil
	end
	local v70 = v69:FindFirstChild("RightGripAttachment")
	if v70 and v70:IsA("Attachment") then
		v66.Grip = v70.CFrame
	end
	for _, v71 in v66:GetDescendants() do
		if v71:IsA("BasePart") then
			v71.Anchored = false
			v71.CanCollide = false
			v71.CanQuery = false
			v71.CanTouch = false
			v71.Massless = true
		else
			if not v71:IsA("LuaSourceContainer") then
				continue
			end
			v71:Destroy()
		end
	end
	return v66
end
local function v_u_80(p73, p74) -- name: attach
	local v75 = p73.rightHand
	local v76 = p74:FindFirstChild("Handle")
	if v75 and v76 then
		if not v76:FindFirstChild("ReplayGrip") then
			local v77 = Instance.new("Weld")
			v77.Name = "ReplayGrip"
			v77.Part0 = v75
			v77.Part1 = v76
			local v78 = v75:FindFirstChild("RightGripAttachment")
			local v79
			if v78 and v78:IsA("Attachment") then
				v79 = v78.CFrame
			else
				v79 = CFrame.new(0, -v75.Size.Y / 2, 0) * CFrame.Angles(-1.5707963267948966, 0, 0)
			end
			v77.C0 = v79
			v77.C1 = p74.Grip
			v77.Parent = v76
		end
		p74.Parent = p73.model
	end
end
function v_u_9.SetItem(p81, p82) -- name: SetItem
	-- upvalues: (copy) v_u_72, (copy) v_u_80
	if p81.itemId == p82 then
		return false
	end
	local v83 = p81.itemId
	if v83 then
		v83 = p81.tools[p81.itemId]
	end
	if v83 then
		v83.Parent = nil
	end
	p81.itemId = p82
	if p82 then
		local v84 = p81.tools[p82]
		if v84 == nil then
			v84 = v_u_72(p82) or false
			p81.tools[p82] = v84
		end
		if v84 then
			v_u_80(p81, v84)
		end
	end
	return true
end
local function v_u_94(p_u_85, p86) -- name: greyCopy
	-- upvalues: (copy) v_u_9
	if not p_u_85 then
		return nil
	end
	local v87
	if p_u_85.Parent and not p86 then
		v87 = v_u_9.Snapshot(p_u_85)
	else
		local v88
		v88, v87 = pcall(function()
			-- upvalues: (copy) p_u_85
			local v89 = p_u_85.Archivable
			p_u_85.Archivable = true
			local v90 = p_u_85:Clone()
			p_u_85.Archivable = v89
			return v90
		end)
		if not v88 then
			v87 = nil
		end
		if v87 and p86 then
			for _, v91 in v87:GetDescendants() do
				if not (v91:IsA("Tool") or v91:IsA("Highlight")) then
					continue
				end
				v91:Destroy()
			end
		end
	end
	if not v87 then
		return nil
	end
	for _, v92 in v87:GetDescendants() do
		if v92:IsA("Accessory") or (v92:IsA("Clothing") or (v92:IsA("ShirtGraphic") or v92:IsA("Decal") and v92.Name ~= "face")) then
			v92:Destroy()
		else
			if not v92:IsA("BodyColors") then
				continue
			end
			local v93 = Color3.fromRGB(150, 150, 156)
			v92.HeadColor3 = v93
			v92.TorsoColor3 = v93
			v92.LeftArmColor3 = v93
			v92.RightArmColor3 = v93
			v92.LeftLegColor3 = v93
			v92.RightLegColor3 = v93
		end
	end
	return v87
end
local function v_u_98() -- name: standIn
	-- upvalues: (copy) v_u_7, (copy) v_u_94, (copy) v_u_41
	local v95 = v_u_7.Character
	local v96
	if v95 and v95.Parent then
		v96 = v_u_94(v95, false)
	else
		v96 = nil
	end
	if v96 then
		return v96
	end
	for _, v97 in v_u_41 do
		return v_u_94(v97, true)
	end
	return nil
end
local function v_u_111(p99, p100, p101, p102, p103, p104) -- name: assemble
	local v105 = p99:FindFirstChild("HumanoidRootPart")
	local v_u_106 = p99:FindFirstChildOfClass("Humanoid")
	if v105 and (v105:IsA("BasePart") and v_u_106) then
		pcall(function()
			-- upvalues: (copy) v_u_106
			v_u_106.EvaluateStateMachine = false
		end)
		v_u_106.BreakJointsOnDeath = false
		v_u_106.RequiresNeck = false
		if v_u_106.MaxHealth <= 0 then
			v_u_106.MaxHealth = 100
		end
		v_u_106.Health = v_u_106.MaxHealth
		v_u_106.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
		v_u_106.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
		v105.Anchored = true
		v105.Transparency = 1
		local v107 = v_u_106:FindFirstChildOfClass("Animator")
		if not v107 then
			v107 = Instance.new("Animator")
			v107.Parent = v_u_106
		end
		p99.Name = ("ReplayPuppet_%*"):format(p100)
		p99:SetAttribute("ReplayPuppet", p101)
		p99:SetAttribute("DisplayName", p102)
		local v108 = {}
		for _, v109 in p99:GetChildren() do
			if not v109:IsA("BasePart") then
				continue
			end
			v108[v109.Name] = v109
		end
		return {
			["index"] = nil,
			["id"] = nil,
			["name"] = nil,
			["team"] = nil,
			["model"] = nil,
			["root"] = nil,
			["hum"] = nil,
			["animator"] = nil,
			["rightHand"] = nil,
			["parts"] = nil,
			["tools"] = nil,
			["itemId"] = nil,
			["hold"] = nil,
			["visible"] = false,
			["alive"] = true,
			["blocking"] = false,
			["folder"] = nil,
			["loco"] = nil,
			["standIn"] = false,
			["src"] = "",
			["liveParts"] = -1,
			["index"] = p100,
			["id"] = p101,
			["name"] = p102,
			["team"] = p103,
			["model"] = p99,
			["root"] = v105,
			["hum"] = v_u_106,
			["animator"] = v107,
			["rightHand"] = v108.RightHand or v108["Right Arm"],
			["parts"] = v108,
			["tools"] = {},
			["folder"] = p104
		}, nil
	else
		p99:Destroy()
		local v110 = nil
		if v_u_106 then
			return v110, "noroot"
		else
			return v110, "nohum"
		end
	end
end
local function v_u_117(p112) -- name: bodyCount
	local v113 = 0
	for _, v114 in p112:GetDescendants() do
		local v115
		if v114:IsA("BasePart") and (v114.Name ~= "HumanoidRootPart" and v114.Name ~= "TribesHull") then
			local v116 = v114:FindFirstAncestorOfClass("Tool")
			v115 = v116 == nil and true or not v116:IsDescendantOf(p112)
		else
			v115 = false
		end
		if not v115 then
			continue
		end
		v113 = v113 + 1
	end
	return v113
end
local v_u_118 = v4:IsStudio()
local function v_u_130(p119, p120) -- name: debugBreak
	-- upvalues: (copy) v_u_118
	if not v_u_118 or string.sub(p120, 1, 1) ~= "p" then
		return nil
	end
	local v121 = workspace:GetAttribute("ReplayDiagBreak")
	if type(v121) ~= "string" or v121 == "" then
		return nil
	end
	if v121 == "noroot" then
		local v122 = p119:FindFirstChild("HumanoidRootPart")
		if v122 then
			v122:Destroy()
			return v121
		end
	else
		if v121 == "tr" or v121 == "ltm" then
			for _, v123 in p119:GetDescendants() do
				local v124
				if v123:IsA("BasePart") and (v123.Name ~= "HumanoidRootPart" and v123.Name ~= "TribesHull") then
					local v125 = v123:FindFirstAncestorOfClass("Tool")
					v124 = v125 == nil and true or not v125:IsDescendantOf(p119)
				else
					v124 = false
				end
				if not v124 then
					continue
				end
				if v121 == "tr" then
					v123.Transparency = 1
				else
					v123.LocalTransparencyModifier = 1
				end
			end
			return v121
		end
		if v121 == "loose" or v121 == "far" then
			for _, v126 in p119:GetDescendants() do
				if (not v126:IsA("JointInstance") or v126.Name ~= "Root") and (not v126:IsA("Attachment") or v126.Name ~= "RootRigAttachment") then
					continue
				end
				v126:Destroy()
			end
			if v121 == "far" then
				for _, v127 in p119:GetDescendants() do
					local v128
					if v127:IsA("BasePart") and (v127.Name ~= "HumanoidRootPart" and v127.Name ~= "TribesHull") then
						local v129 = v127:FindFirstAncestorOfClass("Tool")
						v128 = v129 == nil and true or not v129:IsDescendantOf(p119)
					else
						v128 = false
					end
					if not v128 then
						continue
					end
					v127.Anchored = true
					v127.CFrame = v127.CFrame + Vector3.new(0, 60, 0)
				end
			end
		end
	end
	return v121
end
local v_u_131 = {
	"live",
	"cache",
	"standin",
	"donor"
}
local v_u_132 = {
	"cache",
	"live",
	"standin",
	"donor"
}
function v_u_9.Build(p133, p134, p135, p136, p137, p138, p139) -- name: Build
	-- upvalues: (copy) v_u_9, (copy) v_u_117, (copy) v_u_41, (copy) v_u_32, (copy) v_u_132, (copy) v_u_131, (copy) v_u_98, (copy) v_u_94, (copy) v_u_130, (copy) v_u_111
	local v140 = v_u_9.FindLive(p134)
	local v141 = not v140 and -1 or v_u_117(v140)
	local v142, v143, v144, v145, v146, v147, v148, v149, v150
	if v140 and v_u_41[p134] then
		local v151 = v140:FindFirstChildOfClass("Humanoid")
		local v152
		if v151 == nil or (v151.Health <= 0 or v140:FindFirstChild("HumanoidRootPart") == nil) then
			v152 = false
		else
			v152 = v_u_32(v140)
		end
		if v152 then
			v142 = v_u_131
			v143 = 1
			if p138 then
				for v159, v160 in v142 do
					if v160 ~= p138 then
						continue
					end
					v143 = v159 + 1
				end
			end
			v144 = nil
			for v161 = v143, #v142 do
				v145 = v142[v161]
				v146 = nil
				v147 = nil
				if v145 == "live" then
					if v140 then
						v146, v147 = v_u_9.Snapshot(v140)
					end
				elseif v145 == "cache" then
					v148 = v_u_41[p134]
					if v148 then
						v146 = v148:Clone()
					else
						v146 = nil
					end
				elseif v145 == "standin" then
					v146 = v_u_98()
				elseif p139 then
					v146 = v_u_94(p139, true)
				end
				if v146 and v145 == "live" then
					v149 = v_u_130(v146, p134)
				else
					v149 = nil
				end
				if v146 then
					v150, v147 = v_u_111(v146, p133, p134, p135, p136, p137)
				else
					v150 = nil
				end
				if v147 and not v144 then
					v144 = v147 .. ":" .. v145
				end
				if not v150 then
					continue
				end
				v150.skipped = v144
				v150.src = v145
				v150.standIn = v145 == "standin" and true or v145 == "donor"
				v150.liveParts = v141
				if v149 == "unparent" then
					v150.debugUnparent = true
				end
				return v150, v144, v141
			end
			return nil, v144, v141
		else
			v142 = v_u_132
			v143 = 1
			if p138 then
				for v159, v160 in v142 do
					if v160 ~= p138 then
						continue
					end
					v143 = v159 + 1
				end
			end
			v144 = nil
			for v161 = v143, #v142 do
				v145 = v142[v161]
				v146 = nil
				v147 = nil
				if v145 == "live" then
					if v140 then
						v146, v147 = v_u_9.Snapshot(v140)
					end
				elseif v145 == "cache" then
					v148 = v_u_41[p134]
					if v148 then
						v146 = v148:Clone()
					else
						v146 = nil
					end
				elseif v145 == "standin" then
					v146 = v_u_98()
				elseif p139 then
					v146 = v_u_94(p139, true)
				end
				if v146 and v145 == "live" then
					v149 = v_u_130(v146, p134)
				else
					v149 = nil
				end
				if v146 then
					v150, v147 = v_u_111(v146, p133, p134, p135, p136, p137)
				else
					v150 = nil
				end
				if v147 and not v144 then
					v144 = v147 .. ":" .. v145
				end
				if not v150 then
					continue
				end
				v150.skipped = v144
				v150.src = v145
				v150.standIn = v145 == "standin" and true or v145 == "donor"
				v150.liveParts = v141
				if v149 == "unparent" then
					v150.debugUnparent = true
				end
				return v150, v144, v141
			end
			return nil, v144, v141
		end
	else
		v142 = v_u_131
		v143 = 1
		if p138 then
			for v159, v160 in v142 do
				if v160 ~= p138 then
					continue
				end
				v143 = v159 + 1
			end
		end
		v144 = nil
		for v161 = v143, #v142 do
			v145 = v142[v161]
			v146 = nil
			v147 = nil
			if v145 == "live" then
				if v140 then
					v146, v147 = v_u_9.Snapshot(v140)
				end
			elseif v145 == "cache" then
				v148 = v_u_41[p134]
				if v148 then
					v146 = v148:Clone()
				else
					v146 = nil
				end
			elseif v145 == "standin" then
				v146 = v_u_98()
			elseif p139 then
				v146 = v_u_94(p139, true)
			end
			if v146 and v145 == "live" then
				v149 = v_u_130(v146, p134)
			else
				v149 = nil
			end
			if v146 then
				v150, v147 = v_u_111(v146, p133, p134, p135, p136, p137)
			else
				v150 = nil
			end
			if v147 and not v144 then
				v144 = v147 .. ":" .. v145
			end
			if not v150 then
				continue
			end
			v150.skipped = v144
			v150.src = v145
			v150.standIn = v145 == "standin" and true or v145 == "donor"
			v150.liveParts = v141
			if v149 == "unparent" then
				v150.debugUnparent = true
			end
			return v150, v144, v141
		end
		return nil, v144, v141
	end
end
function v_u_9.Inspect(p162, p163) -- name: Inspect
	local v164 = p162.model
	local v165 = p162.root.Position
	local v166 = v164:IsDescendantOf(workspace)
	local v167 = {
		["parts"] = 0,
		["vis"] = 0,
		["tr"] = 0,
		["ltm"] = 0,
		["far"] = 0,
		["loose"] = 0,
		["wrap"] = 0,
		["parented"] = nil,
		["parented"] = v166
	}
	for _, v168 in v164:GetDescendants() do
		if v168:IsA("WrapLayer") then
			v167.wrap = v167.wrap + 1
		else
			local v169
			if v168:IsA("BasePart") and (v168.Name ~= "HumanoidRootPart" and v168.Name ~= "TribesHull") then
				local v170 = v168:FindFirstAncestorOfClass("Tool")
				v169 = v170 == nil and true or not v170:IsDescendantOf(v164)
			else
				v169 = false
			end
			if not v169 then
				continue
			end
			v167.parts = v167.parts + 1
			local v171
			if v168.Transparency >= 0.95 then
				v167.tr = v167.tr + 1
				v171 = true
			else
				v171 = false
			end
			if v168.LocalTransparencyModifier >= 0.95 then
				v167.ltm = v167.ltm + 1
				v171 = true
			end
			if not v171 then
				v167.vis = v167.vis + 1
			end
			if p163 < (v168.Position - v165).Magnitude then
				v167.far = v167.far + 1
			end
			if not v166 or v168:IsGrounded() then
				continue
			end
			v167.loose = v167.loose + 1
		end
	end
	return v167
end
function v_u_9.SetVisible(p172, p173) -- name: SetVisible
	if p172.visible ~= p173 then
		p172.visible = p173
		local v174 = p172.model
		local v175
		if p173 then
			v175 = p172.folder
		else
			v175 = nil
		end
		v174.Parent = v175
	end
end
function v_u_9.Part(p176, p177) -- name: Part
	if p177 == "Handle" then
		return p176.parts.Head or p176.root
	end
	local v178 = p176.parts[p177]
	if not v178 then
		local v179 = p176.model
		local v180 = v179:FindFirstChild(p177)
		if not (v180 and v180:IsA("BasePart")) then
			v180 = v179:FindFirstChild(p177, true)
			if not (v180 and v180:IsA("BasePart")) then
				v180 = nil
			end
		end
		v178 = v180 or (p176.parts.UpperTorso or p176.root)
	end
	return v178
end
function v_u_9.Destroy(p181) -- name: Destroy
	for _, v182 in p181.tools do
		if not v182 then
			continue
		end
		v182:Destroy()
	end
	p181.model:Destroy()
end
return v_u_9