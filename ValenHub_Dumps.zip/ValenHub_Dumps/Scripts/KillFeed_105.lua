return {
	["Init"] = function(p_u_1) -- name: Init
		local v_u_2 = p_u_1.UI
		local v_u_3 = p_u_1.Theme
		local v_u_4 = p_u_1.State
		local v_u_5 = p_u_1.WeaponIcon
		local v_u_6 = v_u_3.Colors
		local v_u_7 = v_u_3.Fonts
		local v_u_8 = v_u_2.new("Frame", {
			["Name"] = "KillFeed",
			["AnchorPoint"] = Vector2.new(1, 0),
			["Size"] = UDim2.fromOffset(460, 190),
			v_u_2.List(Enum.FillDirection.Vertical, 5, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Top),
			["Parent"] = p_u_1.Canvas.HUD
		})
		local function v10() -- name: layout
			-- upvalues: (copy) p_u_1, (copy) v_u_8, (copy) v_u_2
			local v9
			if p_u_1.MatchHud and p_u_1.MatchHud.KillFeedTop then
				v9 = p_u_1.MatchHud.KillFeedTop()
			else
				v9 = nil
			end
			v_u_8.Position = UDim2.new(1, v_u_2.Compact and -14 or -22, 0, v9 or v_u_2.TopInset())
		end
		p_u_1.KillFeedRelayout = v10
		local v11
		if p_u_1.MatchHud and p_u_1.MatchHud.KillFeedTop then
			v11 = p_u_1.MatchHud.KillFeedTop()
		else
			v11 = nil
		end
		v_u_8.Position = UDim2.new(1, v_u_2.Compact and -14 or -22, 0, v11 or v_u_2.TopInset())
		v_u_2.LayoutChanged:Connect(v10)
		v_u_2.TopInsetChanged:Connect(v10)
		local v_u_12 = {}
		local v_u_13 = {}
		local v_u_14 = 0
		local function v_u_22() -- name: newRow
			-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_7
			local v15 = v_u_2.new("Frame", {
				["Name"] = "Row",
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["Size"] = UDim2.fromOffset(0, 33),
				["AutomaticSize"] = Enum.AutomaticSize.X
			})
			local v16 = v_u_2.new("Frame", {
				["Name"] = "Inner",
				["Size"] = UDim2.fromOffset(0, 33),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["BackgroundColor3"] = v_u_6.Void,
				["BackgroundTransparency"] = 0.4,
				v_u_2.Corner(8),
				v_u_2.Padding(0, 10, 0, 10),
				v_u_2.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
				["Parent"] = v15
			})
			local v17 = v_u_2.Stroke(v_u_6.Accent, 2, 0.1)
			v17.Parent = v16
			local v18 = v_u_2.new("TextLabel", {
				["Name"] = "Killer",
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 18,
				["LayoutOrder"] = 1,
				["Parent"] = nil,
				["Size"] = UDim2.fromOffset(0, 26),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["FontFace"] = v_u_7.Heavy,
				["Parent"] = v16
			})
			v_u_2.TextStroke(v_u_6.Void, 1.5, 0.3).Parent = v18
			local v19 = v_u_2.new("Frame", {
				["Name"] = "Weapon",
				["Size"] = nil,
				["LayoutOrder"] = 2,
				["Parent"] = nil,
				["Size"] = UDim2.fromOffset(38, 28),
				["Parent"] = v16
			})
			local v20 = v_u_2.Image(v_u_2.Assets.Icons.Headshot, {
				["Name"] = "Headshot",
				["Size"] = nil,
				["ImageColor3"] = nil,
				["LayoutOrder"] = 3,
				["Parent"] = nil,
				["Size"] = UDim2.fromOffset(20, 20),
				["ImageColor3"] = v_u_6.Accent,
				["Parent"] = v16
			})
			local v21 = v_u_2.new("TextLabel", {
				["Name"] = "Victim",
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 18,
				["LayoutOrder"] = 4,
				["Parent"] = nil,
				["Size"] = UDim2.fromOffset(0, 26),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["FontFace"] = v_u_7.Heavy,
				["Parent"] = v16
			})
			v_u_2.TextStroke(v_u_6.Void, 1.5, 0.3).Parent = v21
			v_u_2.new("UISizeConstraint", {
				["MaxSize"] = Vector2.new(170, 30),
				["Parent"] = v18
			})
			v_u_2.new("UISizeConstraint", {
				["MaxSize"] = Vector2.new(170, 30),
				["Parent"] = v21
			})
			v18.TextTruncate = Enum.TextTruncate.AtEnd
			v21.TextTruncate = Enum.TextTruncate.AtEnd
			return {
				["holder"] = nil,
				["inner"] = nil,
				["stroke"] = nil,
				["killer"] = nil,
				["victim"] = nil,
				["icon"] = nil,
				["hs"] = nil,
				["token"] = 0,
				["holder"] = v15,
				["inner"] = v16,
				["stroke"] = v17,
				["killer"] = v18,
				["victim"] = v21,
				["icon"] = v19,
				["hs"] = v20
			}
		end
		local function v_u_55(p23) -- name: push
			-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_13, (copy) v_u_12, (copy) v_u_22, (ref) v_u_14, (copy) v_u_6, (copy) v_u_3, (copy) v_u_5, (copy) v_u_8
			local v24 = v_u_4.MyId()
			local v25
			if v_u_2.Compact then
				v25 = 3
			else
				v25 = 5
			end
			while v25 < #v_u_13 do
				local v26 = table.remove(v_u_13, 1)
				v26.token = v26.token + 1
				v26.holder.Parent = nil
				local v27 = v_u_12
				table.insert(v27, v26)
			end
			local v_u_28
			if v25 <= #v_u_13 then
				v_u_28 = v_u_13[1]
				table.remove(v_u_13, 1)
			else
				v_u_28 = table.remove(v_u_12) or v_u_22()
			end
			v_u_28.token = v_u_28.token + 1
			local v_u_29 = v_u_28.token
			v_u_14 = v_u_14 + 1
			local v30 = p23.killerName
			local v31
			if type(v30) == "string" and p23.killerName ~= "" then
				v31 = p23.killerId ~= p23.victimId
			else
				v31 = false
			end
			v_u_28.killer.Visible = v31
			local v32 = v_u_28.killer
			local v33
			if v31 then
				local v34 = p23.killerId
				v33 = p23.killerName
				local v35 = v_u_4.FindMember(v34)
				if v35 then
					v35 = v35.tribe
				end
				if type(v35) == "table" then
					local v36 = v35.tag
					if type(v36) == "string" then
						v33 = "[" .. v35.tag .. "] " .. v33
					end
				end
			else
				v33 = ""
			end
			v32.Text = v33
			local v37 = v_u_28.killer
			local v38 = p23.killerTeam
			local v39
			if v38 == nil or (v38 == 0 or v38 == false) then
				v39 = v_u_6.TextDim
			elseif v_u_4.IsAllyTeam(v38) then
				v39 = v_u_3.Lighten(v_u_6.Ally, 0.15)
			else
				v39 = v_u_3.Lighten(v_u_6.Enemy, 0.1)
			end
			v37.TextColor3 = v39
			local v40 = v_u_28.victim
			local v41 = p23.victimId
			local v42 = p23.victimName or "?"
			local v43 = tostring(v42)
			local v44 = v_u_4.FindMember(v41)
			if v44 then
				v44 = v44.tribe
			end
			if type(v44) == "table" then
				local v45 = v44.tag
				if type(v45) == "string" then
					v43 = "[" .. v44.tag .. "] " .. v43
				end
			end
			v40.Text = v43
			local v46 = v_u_28.victim
			local v47 = p23.victimTeam
			local v48
			if v47 == nil or (v47 == 0 or v47 == false) then
				v48 = v_u_6.TextDim
			elseif v_u_4.IsAllyTeam(v47) then
				v48 = v_u_3.Lighten(v_u_6.Ally, 0.15)
			else
				v48 = v_u_3.Lighten(v_u_6.Enemy, 0.1)
			end
			v46.TextColor3 = v48
			v_u_28.hs.Visible = p23.headshot == true
			local v49 = p23.weaponId
			if type(v49) == "string" and p23.weaponId ~= "" then
				v_u_5.Set(v_u_28.icon, p23.weaponId, {
					["glow"] = false
				})
			else
				v_u_5.Set(v_u_28.icon, nil)
				if not v_u_28.icon:FindFirstChild("WeaponIcon") then
					v_u_2.Image(v_u_2.Assets.Icons.Skull, {
						["Name"] = "WeaponIcon",
						["Size"] = nil,
						["ImageColor3"] = nil,
						["Parent"] = nil,
						["Size"] = UDim2.fromScale(1, 1),
						["ImageColor3"] = v_u_6.TextDim,
						["Parent"] = v_u_28.icon
					})
				end
			end
			v_u_2.Unfade(v_u_28.inner)
			local v50 = p23.killerId == v24 and true or p23.victimId == v24
			v_u_28.stroke.Enabled = v50
			v_u_28.stroke.Transparency = 0.1
			v_u_28.inner.BackgroundTransparency = v50 and 0.2 or 0.4
			v_u_28.holder.LayoutOrder = v_u_14
			v_u_28.holder.Parent = v_u_8
			local v51 = v_u_13
			table.insert(v51, v_u_28)
			v_u_2.SlideIn(v_u_28.inner, Vector2.new(40, 0), v_u_3.Tween.PopSmall, UDim2.new())
			task.delay(5, function()
				-- upvalues: (ref) v_u_28, (copy) v_u_29, (ref) v_u_2, (ref) v_u_13, (ref) v_u_12
				if v_u_28.token == v_u_29 then
					v_u_2.FadeOut(v_u_28.inner, TweenInfo.new(0.3))
					task.delay(0.32, function()
						-- upvalues: (ref) v_u_28, (ref) v_u_29, (ref) v_u_13, (ref) v_u_12
						if v_u_28.token == v_u_29 then
							local v52 = v_u_28
							local v53 = table.find(v_u_13, v52)
							if v53 then
								table.remove(v_u_13, v53)
							end
							v52.holder.Parent = nil
							local v54 = v_u_12
							table.insert(v54, v52)
						end
					end)
				end
			end)
		end
		p_u_1.OnMatchEvent(function(p56, p57)
			-- upvalues: (copy) v_u_55, (copy) v_u_13, (copy) v_u_12
			if p56 == "Elimination" and type(p57) == "table" then
				v_u_55(p57)
			elseif p56 == "MatchStart" then
				for v58 = #v_u_13, 1, -1 do
					local v59 = v_u_13[v58]
					v59.token = v59.token + 1
					local v60 = v_u_13[v58]
					local v61 = table.find(v_u_13, v60)
					if v61 then
						table.remove(v_u_13, v61)
					end
					v60.holder.Parent = nil
					local v62 = v_u_12
					table.insert(v62, v60)
				end
			end
		end)
		local function v65() -- name: vis
			-- upvalues: (copy) v_u_8, (copy) v_u_4, (copy) p_u_1
			local v63 = v_u_8
			local v64 = v_u_4.SeesMatch()
			if v64 then
				v64 = not p_u_1.HudHidden
			end
			v63.Visible = v64
		end
		local v66 = v_u_4.SeesMatch()
		if v66 then
			v66 = not p_u_1.HudHidden
		end
		v_u_8.Visible = v66
		v_u_4.PlayerStateChanged:Connect(v65)
		v_u_4.WatchChanged:Connect(v65)
		p_u_1.HudHiddenChanged:Connect(v65)
		function p_u_1.Debug.killfeed(p67)
			-- upvalues: (copy) v_u_55, (copy) v_u_4, (copy) p_u_1
			v_u_55(p67 or {
				["killerId"] = nil,
				["killerName"] = nil,
				["killerTeam"] = nil,
				["victimId"] = "b2",
				["victimName"] = "Grimtooth",
				["victimTeam"] = nil,
				["weaponId"] = "short_bow",
				["headshot"] = true,
				["killerId"] = v_u_4.MyId(),
				["killerName"] = p_u_1.Player.DisplayName,
				["killerTeam"] = v_u_4.MyTeam(),
				["victimTeam"] = 3 - v_u_4.MyTeam()
			})
			return true
		end
	end
}