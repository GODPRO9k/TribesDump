local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v5 = v_u_2:WaitForChild("Shared")
local v_u_6 = require(v5:WaitForChild("Camera"))
local v7 = require(v5:WaitForChild("Camera"):WaitForChild("Spring"))
local v_u_8 = require(v5:WaitForChild("Combat"))
local v_u_9 = require(v5:WaitForChild("Sfx"))
local v_u_10 = require(script.Parent:WaitForChild("BladeClips"))
local v_u_11 = require(script.Parent:WaitForChild("BladeSmear"))
local v_u_12 = require(script.Parent:WaitForChild("ItemClips"))
local v_u_13 = require(script.Parent:WaitForChild("ViewFx"))
local v_u_14 = {}
local v_u_15 = v1.LocalPlayer
local v_u_16 = {
	["fovRef"] = 70,
	["hand"] = Vector3.new(0.32, -0.29, -0.6),
	["touchHand"] = Vector3.new(-0.06, 0.05, 0),
	["poseHz"] = 7,
	["poseDamp"] = 0.82,
	["idleHz"] = 0.3,
	["idlePos"] = 0.005,
	["idleRot"] = 1,
	["bobX"] = 0.03,
	["bobY"] = 0.045,
	["bobRoll"] = 4,
	["bobPitch"] = 2.6,
	["airK"] = 0.0024,
	["airMax"] = 0.07,
	["airTiltK"] = 0.3,
	["airTiltMax"] = 9,
	["airHz"] = 2.6,
	["airDamp"] = 0.55,
	["landK"] = 0.05,
	["landMax"] = 1.8,
	["landHz"] = 5,
	["landDamp"] = 0.42,
	["landDist"] = 0.07,
	["swayK"] = 0.35,
	["swayMax"] = 9,
	["swayHz"] = 5,
	["swayDamp"] = 0.75,
	["swayShift"] = 0.15,
	["kickHz"] = 9,
	["kickDamp"] = 0.5,
	["equipHz"] = 4.2,
	["equipDamp"] = 0.52,
	["equipDrop"] = 0.42,
	["equipTilt"] = 55,
	["dropTime"] = 0.14,
	["slidePos"] = Vector3.new(-0.02, -0.08, 0.03),
	["slideRot"] = Vector3.new(8, 4, 16),
	["slideShake"] = 0.004,
	["wallMin"] = 0.78,
	["wallMargin"] = 0.16,
	["wallPos"] = Vector3.new(0.02, -0.14, 0.05),
	["wallRotMax"] = 70,
	["hurtRot"] = 40,
	["hurtPos"] = 0.35,
	["retHz"] = 4.6,
	["retDamp"] = 0.74,
	["smearLen"] = 0.055
}
local v17 = {
	["Sword"] = {
		{
			["at"] = 0.56,
			["width"] = 0.82,
			["alpha"] = 0.6,
			["color"] = nil,
			["color"] = Color3.fromRGB(200, 212, 230)
		},
		{
			["at"] = 0.9,
			["width"] = 0.2,
			["alpha"] = 0.28,
			["color"] = nil,
			["color"] = Color3.fromRGB(226, 233, 243)
		}
	},
	["Dagger"] = {
		{
			["at"] = 0.56,
			["width"] = 0.82,
			["alpha"] = 0.58,
			["color"] = nil,
			["color"] = Color3.fromRGB(176, 222, 236)
		},
		{
			["at"] = 0.9,
			["width"] = 0.22,
			["alpha"] = 0.26,
			["color"] = nil,
			["color"] = Color3.fromRGB(206, 238, 246)
		}
	},
	["Axe"] = {
		{
			["at"] = 0.62,
			["width"] = 0.6,
			["alpha"] = 0.62,
			["color"] = nil,
			["color"] = Color3.fromRGB(196, 204, 218)
		},
		{
			["at"] = 0.88,
			["width"] = 0.26,
			["alpha"] = 0.5,
			["color"] = nil,
			["color"] = Color3.fromRGB(214, 196, 150)
		}
	},
	["Club"] = {
		{
			["at"] = 0.66,
			["width"] = 0.56,
			["alpha"] = 0.64,
			["color"] = nil,
			["color"] = Color3.fromRGB(196, 182, 160)
		},
		{
			["at"] = 0.88,
			["width"] = 0.26,
			["alpha"] = 0.5,
			["color"] = nil,
			["color"] = Color3.fromRGB(200, 182, 150)
		}
	},
	["Knives"] = {
		{
			["at"] = 0.6,
			["width"] = 0.8,
			["alpha"] = 0.6,
			["color"] = nil,
			["color"] = Color3.fromRGB(170, 180, 194)
		}
	},
	["Javelin"] = {
		{
			["at"] = 0.85,
			["width"] = 0.3,
			["alpha"] = 0.55,
			["color"] = nil,
			["color"] = Color3.fromRGB(176, 172, 160)
		}
	},
	["Bomb"] = {
		{
			["at"] = 0.5,
			["width"] = 0.9,
			["alpha"] = 0.6,
			["color"] = nil,
			["color"] = Color3.fromRGB(196, 166, 128)
		}
	},
	["Scythe"] = {
		{
			["at"] = 0.34,
			["width"] = 0.62,
			["alpha"] = 0.62,
			["color"] = nil,
			["color"] = Color3.fromRGB(186, 194, 210)
		},
		{
			["at"] = 0.6,
			["width"] = 0.18,
			["alpha"] = 0.45,
			["color"] = nil,
			["color"] = Color3.fromRGB(210, 216, 228)
		}
	},
	["Katana"] = {
		{
			["at"] = 0.58,
			["width"] = 0.8,
			["alpha"] = 0.6,
			["color"] = nil,
			["color"] = Color3.fromRGB(178, 204, 230)
		},
		{
			["at"] = 0.9,
			["width"] = 0.2,
			["alpha"] = 0.28,
			["color"] = nil,
			["color"] = Color3.fromRGB(204, 224, 242)
		}
	}
}
v_u_16.smear = v17
v_u_16.smearAlong = {
	["Scythe"] = {
		["root"] = 0.97
	}
}
local v18 = {
	["bolas"] = {
		{
			["at"] = 0.85,
			["width"] = 0.25,
			["alpha"] = 0.6,
			["color"] = nil,
			["color"] = Color3.fromRGB(150, 116, 80)
		}
	},
	["chakram"] = {
		{
			["at"] = 0.7,
			["width"] = 0.5,
			["alpha"] = 0.5,
			["color"] = nil,
			["color"] = Color3.fromRGB(170, 176, 186)
		}
	}
}
v_u_16.smearItem = v18
local v_u_19 = {
	["Sword"] = {
		["len"] = 0.62,
		["pos"] = Vector3.new(0.03, 0, 0),
		["rot"] = Vector3.new(-26, 6, -4),
		["act"] = "slash",
		["blockFrame"] = nil,
		["blockFrame"] = {
			["pos"] = Vector3.new(0.3, -0.27, -0.55),
			["tip"] = Vector3.new(-0.82, 0.38, -0.42),
			["edge"] = Vector3.new(0.1, 0.3, -1)
		}
	},
	["Shield"] = {
		["len"] = 0.355,
		["pos"] = Vector3.new(-0.02, -0.06, 0.02),
		["rot"] = Vector3.new(0, 18, 4),
		["act"] = "stab",
		["block"] = nil,
		["block"] = { Vector3.new(-0.3, 0.052, 0.24), Vector3.new(2, -16, -11) }
	},
	["Dagger"] = {
		["len"] = 0.33,
		["pos"] = Vector3.new(0.02, 0.02, 0.02),
		["rot"] = Vector3.new(-18, 8, 18),
		["act"] = "stab"
	},
	["Axe"] = {
		["len"] = 0.55,
		["pos"] = Vector3.new(0, 0, 0),
		["rot"] = Vector3.new(-26, 14, 14),
		["act"] = "chop",
		["charge"] = nil,
		["charge"] = { Vector3.new(0.06, 0.14, 0.02), Vector3.new(42, -6, -30) }
	},
	["Club"] = {
		["len"] = 0.3,
		["pos"] = Vector3.new(0.02, -0.02, 0),
		["rot"] = Vector3.new(-26, 14, 24),
		["act"] = "smash",
		["charge"] = nil,
		["charge"] = { Vector3.new(0.02, 0.04, 0.02), Vector3.new(36, 0, 12) }
	},
	["Gauntlets"] = {
		["len"] = 0.24,
		["pos"] = Vector3.new(0.01, -0.05, 0.02),
		["rot"] = Vector3.new(62, 14, 24),
		["act"] = "stab"
	},
	["Katana"] = {
		["len"] = 0.68,
		["pos"] = Vector3.new(0.03, 0, 0),
		["rot"] = Vector3.new(-26, 6, 4),
		["act"] = "slash"
	},
	["Hatchets"] = {
		["len"] = 0.34,
		["pos"] = Vector3.new(0.02, -0.02, 0.02),
		["rot"] = Vector3.new(-24, 12, 16),
		["act"] = "chop"
	},
	["Scythe"] = {
		["len"] = 0.95,
		["pos"] = Vector3.new(0.04, -0.06, 0.04),
		["rot"] = Vector3.new(-18, 93, -24),
		["act"] = "chop",
		["charge"] = nil,
		["chargeIn"] = 0.15,
		["charge"] = { Vector3.new(0.09, 0.02, 0.05), Vector3.new(0, -12, -37) }
	},
	["Spear"] = {
		["len"] = 0.9,
		["pos"] = Vector3.new(0.02, -0.04, 0.02),
		["rot"] = Vector3.new(-72, 4, -4),
		["act"] = "thrust",
		["charge"] = nil,
		["charge"] = { Vector3.new(0.02, 0, 0.2), Vector3.new(-6, 0, 0) }
	}
}
local v20 = {
	["len"] = 0.54,
	["pos"] = Vector3.new(0, -0.02, 0),
	["rot"] = Vector3.new(0, 55, 18),
	["act"] = "bow",
	["aimPos"] = Vector3.new(-0.16, 0.05, 0.03),
	["aimRot"] = Vector3.new(0, 6, -6),
	["draw"] = nil,
	["drawFrame"] = nil,
	["stock"] = nil,
	["draw"] = { Vector3.new(-0.13, 0.06, 0.05), Vector3.new(0, 10, -24) },
	["drawFrame"] = {
		["pos"] = Vector3.new(0.16, -0.16, -0.52),
		["tip"] = Vector3.new(0.47, 0.88, 0.04),
		["edge"] = Vector3.new(-0.045, 0.045, -1)
	},
	["stock"] = {
		["len"] = 0.68,
		["pos"] = Vector3.new(0, 0, 0.02),
		["rot"] = Vector3.new(-6, 6, 0),
		["kick"] = 1.5,
		["drawFrame"] = false,
		["aimPos"] = Vector3.new(-0.18, 0.1, 0.04),
		["aimRot"] = Vector3.new(2, 0, -4),
		["draw"] = nil,
		["draw"] = { Vector3.new(-0.14, 0.06, 0.12), Vector3.new(5, -4, -10) }
	}
}
v_u_19.Bow = v20
v_u_19.Crossbow = {
	["len"] = 0.48,
	["pos"] = Vector3.new(-0.01, 0, 0),
	["rot"] = Vector3.new(8, 8, -6),
	["act"] = "gun",
	["kick"] = 1,
	["aimPos"] = Vector3.new(-0.26, 0.04, 0.04),
	["aimRot"] = Vector3.new(-8, -8, 4)
}
v_u_19.Musket = {
	["len"] = 0.82,
	["pos"] = Vector3.new(-0.01, 0, 0.02),
	["rot"] = Vector3.new(2, 6, 0),
	["act"] = "gun",
	["kick"] = 1.3,
	["aimPos"] = Vector3.new(-0.26, 0.07, 0.04),
	["aimRot"] = Vector3.new(0, -6, 0)
}
v_u_19.Pistol = {
	["len"] = 0.6,
	["pos"] = Vector3.new(-0.03, 0.03, 0),
	["rot"] = Vector3.new(2, 6, 0),
	["act"] = "gun",
	["kick"] = 1,
	["aimPos"] = Vector3.new(-0.28, 0.02, 0.04),
	["aimRot"] = Vector3.new(0, -6, 0)
}
v_u_19.Blunderbuss = {
	["len"] = 0.6,
	["pos"] = Vector3.new(-0.01, 0, 0.02),
	["rot"] = Vector3.new(2, 6, 0),
	["act"] = "gun",
	["kick"] = 1.4,
	["aimPos"] = Vector3.new(-0.26, 0.07, 0.04),
	["aimRot"] = Vector3.new(0, -6, 0)
}
v_u_19.Knives = {
	["len"] = 0.3,
	["pos"] = Vector3.new(0.02, 0, 0),
	["rot"] = Vector3.new(-40, 10, -10),
	["act"] = "throw",
	["aimPos"] = Vector3.new(-0.12, 0.04, 0.04),
	["aimRot"] = Vector3.new(0, 0, 0),
	["windup"] = nil,
	["windup"] = { Vector3.new(0.05, 0.1, 0.16), Vector3.new(70, 0, 16) }
}
v_u_19.Javelin = {
	["len"] = 0.74,
	["pos"] = Vector3.new(0.02, 0.02, 0.04),
	["rot"] = Vector3.new(-80, 6, 0),
	["act"] = "throw",
	["windup"] = nil,
	["windup"] = { Vector3.new(0.1, 0.22, 0.1), Vector3.new(-5, 14, 10) }
}
v_u_19.Sling = {
	["len"] = 0.66,
	["pos"] = Vector3.new(-0.04, 0.28, 0.02),
	["rot"] = Vector3.new(0, 14, 38),
	["act"] = "throw",
	["aimPos"] = Vector3.new(-0.12, 0.04, 0.04),
	["aimRot"] = Vector3.new(0, 0, 0),
	["windup"] = nil,
	["windup"] = { Vector3.new(0.05, 0.1, 0.16), Vector3.new(40, 0, 16) }
}
v_u_19.Bomb = {
	["len"] = 0.28,
	["pos"] = Vector3.new(0.02, 0.02, 0),
	["rot"] = Vector3.new(-10, 20, 0),
	["act"] = "throw",
	["windup"] = nil,
	["windup"] = { Vector3.new(0.12, 0.28, 0.05), Vector3.new(35, -10, 20) }
}
v_u_19.Herbs = {
	["len"] = 0.25,
	["pos"] = Vector3.new(0.02, 0.02, 0),
	["rot"] = Vector3.new(-10, 25, 0),
	["act"] = "eat",
	["use"] = nil,
	["use"] = { Vector3.new(-0.22, 0.085, 0.17), Vector3.new(-28, 30, 10) }
}
v_u_19.Trap = {
	["len"] = 0.38,
	["pos"] = Vector3.new(-0.02, 0, 0),
	["rot"] = Vector3.new(58, 24, 8),
	["act"] = "trap"
}
v_u_19.Horn = {
	["len"] = 0.4,
	["pos"] = Vector3.new(0.02, 0.02, 0),
	["rot"] = Vector3.new(-10, 25, 0),
	["act"] = "eat",
	["use"] = nil,
	["use"] = { Vector3.new(-0.22, 0, 0.2), Vector3.new(-35, -15, -30) }
}
local v_u_21 = {
	["crossbow"] = {
		["barrel"] = Vector3.new(0, 0, 1)
	},
	["beehive"] = {
		["len"] = 0.2,
		["pos"] = Vector3.new(0.03, -0.01, 0),
		["windup"] = nil,
		["windup"] = { Vector3.new(0.22, 0.3, 0.05), Vector3.new(35, -10, 24) }
	},
	["flintlock"] = {
		["barrel"] = Vector3.new(0.9272, -0.3746, 0),
		["pan"] = Vector3.new(0.5326, 0.3866, 0.198)
	},
	["musket"] = {
		["pan"] = Vector3.new(0.384, 0.382, 0.19)
	},
	["blunderbuss"] = {
		["barrel"] = Vector3.new(0, 0, 1),
		["muzzle"] = Vector3.new(0, 0.257, 1.775),
		["pan"] = Vector3.new(-0.12, 0.48, 0.112)
	},
	["bolas"] = {
		["len"] = 0.37,
		["pos"] = Vector3.new(-0.03, 0.24, 0),
		["rot"] = Vector3.new(30, 0, 0)
	},
	["javelins"] = {
		["len"] = 1.17,
		["pos"] = Vector3.new(0, 0, 0.05)
	},
	["harpoon"] = {
		["len"] = 0.8
	},
	["healing_tonic"] = {
		["pos"] = Vector3.new(0.03, -0.06, 0.03),
		["use"] = nil,
		["use"] = { Vector3.new(-0.22, 0.085, 0.21), Vector3.new(-28, 30, 10) }
	},
	["bandage"] = {
		["use"] = { Vector3.new(-0.22, 0.18, 0.18), Vector3.new(-35, 20, 25) }
	},
	["war_horn"] = {
		["use"] = { Vector3.new(-0.3, 0, 0.23), Vector3.new(-35, -15, -18) }
	},
	["chakram"] = {
		["pos"] = Vector3.new(-0.08, -0.03, 0.02),
		["rot"] = Vector3.new(20, 35, 18)
	},
	["palisade"] = {
		["len"] = 0.36,
		["pos"] = Vector3.new(0, 0.06, 0),
		["rot"] = Vector3.new(-58, 0, -10)
	},
	["smoke_bomb"] = {
		["windup"] = { Vector3.new(0.16, 0.28, 0.05), Vector3.new(35, -10, 20) }
	},
	["healing_flask"] = {
		["windup"] = { Vector3.new(0.12, 0.28, 0.05), Vector3.new(12, -10, 20) }
	}
}
local v_u_22 = {
	["stab"] = {
		["dur"] = 0.2,
		["keys"] = nil,
		["keys"] = {
			{ 0, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0) },
			{ 0.25, Vector3.new(0.01, 0.01, 0.05), Vector3.new(8, 0, 0) },
			{ 0.5, Vector3.new(-0.05, 0.02, -0.18), Vector3.new(-40, 0, -6) },
			{ 1, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0) }
		}
	},
	["chop"] = {
		["dur"] = 0.4,
		["keys"] = nil,
		["keys"] = {
			{ 0, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0) },
			{ 0.24, Vector3.new(0.02, 0.1, 0.06), Vector3.new(44, 0, 10) },
			{ 0.52, Vector3.new(-0.05, -0.13, -0.09), Vector3.new(-64, 6, -10) },
			{ 1, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0) }
		}
	},
	["smash"] = {
		["dur"] = 0.46,
		["keys"] = nil,
		["keys"] = {
			{ 0, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0) },
			{ 0.28, Vector3.new(0.02, 0.12, 0.07), Vector3.new(52, 0, 6) },
			{ 0.55, Vector3.new(-0.06, -0.16, -0.08), Vector3.new(-74, 4, -6) },
			{ 1, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0) }
		}
	},
	["heavy"] = {
		["dur"] = 0.5,
		["keys"] = nil,
		["keys"] = {
			{ 0, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0) },
			{ 0.3, Vector3.new(-0.06, -0.2, -0.12), Vector3.new(-90, 6, -8) },
			{ 0.55, Vector3.new(-0.05, -0.17, -0.1), Vector3.new(-80, 6, -8) },
			{ 1, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0) }
		}
	},
	["thrust"] = {
		["dur"] = 0.34,
		["keys"] = nil,
		["keys"] = {
			{ 0, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0) },
			{ 0.25, Vector3.new(0.01, 0.01, 0.1), Vector3.new(4, 0, 0) },
			{ 0.48, Vector3.new(-0.06, 0.03, -0.3), Vector3.new(-4, 0, 0) },
			{ 1, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0) }
		}
	},
	["lunge"] = {
		["dur"] = 0.6,
		["keys"] = nil,
		["keys"] = {
			{ 0, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0) },
			{ 0.15, Vector3.new(-0.08, 0.04, -0.4), Vector3.new(-4, 0, 0) },
			{ 0.62, Vector3.new(-0.08, 0.04, -0.38), Vector3.new(-4, 0, 0) },
			{ 1, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0) }
		}
	},
	["throw"] = {
		["dur"] = 0.34,
		["keys"] = nil,
		["keys"] = {
			{ 0, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0) },
			{ 0.4, Vector3.new(-0.06, 0.02, -0.34), Vector3.new(-60, 0, -8) },
			{ 1, Vector3.new(-0.06, -0.1, -0.3), Vector3.new(-70, 0, -8) }
		}
	},
	["place"] = {
		["dur"] = 0.36,
		["keys"] = nil,
		["keys"] = {
			{ 0, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0) },
			{ 0.5, Vector3.new(-0.04, -0.22, -0.16), Vector3.new(-40, 0, 0) },
			{ 1, Vector3.new(-0.04, -0.3, -0.2), Vector3.new(-50, 0, 0) }
		}
	}
}
local v_u_23 = {}
local v_u_24 = nil
local v_u_25 = nil
local function v_u_52(p26, p27, p28, p29, p30, p31, p32) -- name: canonical
	if p26 == "Gauntlets" then
		return CFrame.identity, nil
	end
	local v33 = p28:FindFirstChild("Muzzle", true) or p28:FindFirstChild("Tip", true)
	local v34 = nil
	local v35 = nil
	local v36 = nil
	if p27 == "gun" and (p32 and p32.Magnitude > 0.05) then
		v35 = p29:VectorToObjectSpace(p32.Unit)
		v34 = p29:VectorToObjectSpace(Vector3.new(0, 1, 0))
	elseif p27 == "gun" and (v33 and v33:IsA("Attachment")) then
		local v37 = v33.WorldPosition
		local v38 = p29:PointToObjectSpace(p28.CFrame:PointToObjectSpace(v37))
		if v38.Magnitude > 0.05 then
			v35 = v38.Unit
			v34 = p29:VectorToObjectSpace(Vector3.new(0, 1, 0))
		end
	elseif p26 == "Bow" then
		local v39 = {
			{ p30.X, Vector3.new(1, 0, 0) },
			{ p30.Y, Vector3.new(0, 1, 0) },
			{ p30.Z, Vector3.new(0, 0, 1) }
		}
		table.sort(v39, function(p40, p41)
			return p40[1] > p41[1]
		end)
		local v42 = v39[1][2]
		local v43 = (p29.Position - p31.Position):Dot(v42)
		if math.abs(v43) > v39[1][1] * 0.12 then
			v36 = "stock"
			local v44
			if v43 > 0 then
				v44 = -v42
			else
				v44 = v42
			end
			v35 = p29:VectorToObjectSpace(v44)
			v34 = p29:VectorToObjectSpace(v42 ~= Vector3.new(0, 1, 0) and Vector3.new(0, 1, 0) or v39[2][2])
		else
			v34 = p29:VectorToObjectSpace(v42)
			v35 = p29:VectorToObjectSpace(v39[2][2])
			if v34.Y < -0.01 then
				v34 = -v34
			end
			if v35.Z > 0.01 then
				v35 = -v35
			end
		end
	elseif p26 ~= "Sling" and p26 ~= "Trap" then
		local v45 = p28:FindFirstChild("Tip", true)
		if v45 and v45:IsA("Attachment") then
			local v46 = v45.WorldPosition
			local v47 = p29:PointToObjectSpace(p28.CFrame:PointToObjectSpace(v46))
			if v47.Magnitude > 0.1 and v47.Unit.Y > 0.2 then
				v34 = v47.Unit
				v35 = Vector3.new(0, 0, -1)
			end
		end
	end
	if not (v34 and v35) then
		return CFrame.identity, v36
	end
	local v48 = v34.Unit
	local v49 = v35 - v48 * v35:Dot(v48)
	if v49.Magnitude < 0.05 then
		return CFrame.identity, v36
	end
	local v50 = v49.Unit
	if p27 == "gun" or v36 == "stock" then
		v50 = v35.Unit
		local v51 = v48 - v50 * v48:Dot(v50)
		if v51.Magnitude < 0.05 then
			return CFrame.identity, v36
		end
		v48 = v51.Unit
	end
	return CFrame.fromMatrix(Vector3.new(0, 0, 0), v50:Cross(v48), v48, -v50):Inverse(), v36
end
local function v_u_60(p53, p54, p55, p56, p57) -- name: hammerOf
	local v58 = p53:FindFirstChild(p55 or "Hammer", true)
	local v59 = p54:FindFirstChild(p56 or "HammerPivot")
	return v58 and (v58:IsA("BasePart") and (v59 and v59:IsA("Attachment"))) and {
		["part"] = v58,
		["rest"] = p54.CFrame:ToObjectSpace(v58.CFrame),
		["pivot"] = p54.CFrame:PointToObjectSpace(v59.WorldPosition),
		["axis"] = p54.CFrame:VectorToObjectSpace(v59.WorldAxis).Unit,
		["fired"] = tonumber(v58:GetAttribute(p57 or "Fired")) or 35
	} or nil
end
local function v_u_68(p61, p62, p63) -- name: rodOf
	local v64 = p61:FindFirstChild("Ramrod", true)
	if not (v64 and (v64:IsA("BasePart") and p63)) then
		return nil
	end
	local v65 = v64.Size.X
	local v66 = v64.Size.Y * 1.4
	local v67 = v64.Size.Z * 1.4
	v64.Size = Vector3.new(v65, v66, v67)
	return {
		["part"] = v64,
		["rest"] = p62.CFrame:ToObjectSpace(v64.CFrame),
		["len"] = v64.Size.X,
		["fwd"] = p62.CFrame:VectorToObjectSpace(v64.CFrame.XVector).Unit,
		["up"] = p62.CFrame:VectorToObjectSpace(v64.CFrame.YVector).Unit,
		["muzzle"] = p62.CFrame:PointToObjectSpace(p63.WorldPosition)
	}
end
local function v_u_78(p69, p70) -- name: evalTrack
	if p70 <= p69[1][1] then
		return p69[1][2]
	end
	for v71 = 2, #p69 do
		local v72 = p69[v71 - 1]
		local v73 = p69[v71]
		if p70 > v73[1] then
			continue
		end
		if v72[2] <= 1.5 ~= (v73[2] <= 1.5) then
			return v72[2]
		end
		local v74 = p70 - v72[1]
		local v75 = v73[1] - v72[1]
		local v76 = v74 / math.max(v75, 0.0001)
		local v77 = v76 * v76 * (3 - v76 * 2)
		return v72[2] + (v73[2] - v72[2]) * v77
	end
	return p69[#p69][2]
end
local function v_u_196(p79, p80) -- name: prepare
	-- upvalues: (copy) v_u_23, (copy) v_u_19, (ref) v_u_24, (ref) v_u_25, (copy) v_u_21, (copy) v_u_52, (copy) v_u_16, (copy) v_u_10, (copy) v_u_12, (copy) v_u_60, (copy) v_u_68
	local v81 = v_u_23[p79]
	if v81 then
		return v81
	end
	local v_u_82 = v_u_19[p80]
	local v83 = v_u_24
	local v84 = not v_u_82 or v_u_25 and v_u_25:FindFirstChild(p79)
	if v84 then
		v83 = v84
	elseif v83 then
		v83 = v83:FindFirstChild(p79)
	end
	if not (v_u_82 and (v83 and v83:IsA("Model"))) then
		return nil
	end
	local v85 = v83:Clone()
	for _, v86 in v85:GetDescendants() do
		if v86:IsA("BasePart") then
			v86.Anchored = true
			v86.CanCollide = false
			v86.CanQuery = false
			v86.CanTouch = false
			v86.CastShadow = false
			v86.Massless = true
		elseif v86:IsA("ParticleEmitter") or (v86:IsA("Trail") or (v86:IsA("Beam") or v86:IsA("Light"))) then
			v86.Enabled = false
		else
			if not (v86:IsA("Script") or (v86:IsA("LocalScript") or v86:IsA("Sound"))) then
				continue
			end
			v86:Destroy()
		end
	end
	local v87 = v85.PrimaryPart or v85:FindFirstChild("Handle")
	if not (v87 and v87:IsA("BasePart")) then
		v85:Destroy()
		return nil
	end
	v85.PrimaryPart = v87
	local v88 = v_u_21[p79]
	local v89 = v87:FindFirstChild("RightGripAttachment", true)
	local v90 = v85:FindFirstChild("Strip", true)
	local v91
	if v90 then
		v91 = v90.Parent
	else
		v91 = nil
	end
	if v90 then
		v90.Parent = nil
	end
	local v92 = nil
	for _, v93 in v85:GetChildren() do
		if not v93:IsA("BasePart") or v93:GetAttribute("OffHand") ~= true then
			continue
		end
		v92 = v93
	end
	if v92 then
		v92.Parent = nil
	end
	local v94, v95 = v85:GetBoundingBox()
	if v90 then
		v90.Parent = v91
	end
	if v92 then
		v92.Parent = v85
	end
	local v96 = v_u_52
	local v97 = v_u_82.act
	local v98
	if v89 and v89:IsA("Attachment") then
		v98 = v87.CFrame:ToObjectSpace(v89.WorldCFrame)
	else
		v98 = CFrame.new()
	end
	local v99 = v87.CFrame:ToObjectSpace(v94)
	local v100
	if v88 then
		v100 = v88.barrel
	else
		v100 = v88
	end
	local v101, v102 = v96(p80, v97, v87, v98, v95, v99, v100)
	if v102 == "stock" then
		local v103 = v_u_82.stock
		if v103 then
			v_u_82 = table.clone(v_u_82)
			for v104, v105 in v103 do
				v_u_82[v104] = v105
			end
			v_u_82.stock = nil
		end
	end
	if v88 and (v88.pos or (v88.use or v88.windup)) then
		v_u_82 = table.clone(v_u_82)
		v_u_82.pos = v_u_82.pos + (v88.pos or Vector3.new(0, 0, 0))
		v_u_82.use = v88.use or v_u_82.use
		v_u_82.windup = v88.windup or v_u_82.windup
	end
	local v106 = v95.X
	local v107 = v95.Y
	local v108 = v95.Z
	local v109 = math.max(v106, v107, v108, 0.05)
	local v110
	if v88 and v88.len then
		v110 = v88.len
	else
		v110 = v_u_82.len
	end
	local v111 = v110 / v109
	v85:ScaleTo((math.clamp(v111, 0.005, 1)))
	local v112
	if v92 then
		local v113 = v92:FindFirstChild("OffHandGrip")
		v112 = {
			["part"] = v92
		}
		local v114
		if v113 and v113:IsA("Attachment") then
			v114 = v113.CFrame:Inverse()
		else
			v114 = CFrame.identity
		end
		v112.rel = v114
		v92.Parent = nil
	else
		v112 = nil
	end
	local v115
	if v89 and v89:IsA("Attachment") then
		v115 = v87.CFrame:ToObjectSpace(v89.WorldCFrame)
	else
		v115 = CFrame.new()
	end
	local v116 = not (v88 and v88.rot) and Vector3.new(0, 0, 0) or v88.rot
	local v_u_117 = CFrame.fromEulerAnglesYXZ(v_u_82.rot.X * 0.017453292519943295, v_u_82.rot.Y * 0.017453292519943295, v_u_82.rot.Z * 0.017453292519943295) * CFrame.fromEulerAnglesYXZ(v116.X * 0.017453292519943295, v116.Y * 0.017453292519943295, v116.Z * 0.017453292519943295)
	local v118 = v_u_117 * v101
	local v119 = v87:FindFirstChild("Tip", true)
	local v120 = v87:FindFirstChild("RightGripAttachment", true)
	local v121
	if v119 and (v119:IsA("Attachment") and (v120 and v120:IsA("Attachment"))) then
		v121 = (v119.WorldPosition - v120.WorldPosition).Magnitude
	else
		v121 = v_u_82.len * 0.8
	end
	local v122, v123 = v85:GetBoundingBox()
	local v124 = v118 * v115:Inverse() * v87.CFrame:ToObjectSpace(v122)
	local v125 = 0
	for _, v126 in { -0.5, 0.5 } do
		for _, v127 in { -0.5, 0.5 } do
			for _, v128 in { -0.5, 0.5 } do
				local v129 = v126 * v123.X
				local v130 = v127 * v123.Y
				local v131 = v128 * v123.Z
				local v132 = -v124:PointToWorldSpace((Vector3.new(v129, v130, v131))).Z
				v125 = math.max(v125, v132)
			end
		end
	end
	local v133 = v101 * v115:Inverse() * v87.CFrame:ToObjectSpace(v122)
	local v134 = {}
	for _, v135 in { -0.5, 0.5 } do
		for _, v136 in { -0.5, 0.5 } do
			for _, v137 in { -0.5, 0.5 } do
				local v138 = v135 * v123.X
				local v139 = v136 * v123.Y
				local v140 = v137 * v123.Z
				local v141 = Vector3.new(v138, v139, v140)
				table.insert(v134, v133:PointToWorldSpace(v141))
			end
		end
	end
	local v142 = v87:FindFirstChild("Muzzle", true)
	local v143
	if v88 and v88.pan then
		v143 = Instance.new("Attachment")
		v143.Name = "ViewPan"
		local v144 = v88.pan
		local v145
		if v88.len then
			v145 = v88.len
		else
			v145 = v_u_82.len
		end
		v143.Position = v144 * (v145 / v109)
		v143.Parent = v87
	else
		v143 = nil
	end
	if v88 and v88.muzzle then
		v142 = Instance.new("Attachment")
		v142.Name = "ViewMuzzle"
		local v146 = v88.muzzle
		local v147
		if v88.len then
			v147 = v88.len
		else
			v147 = v_u_82.len
		end
		v142.Position = v146 * (v147 / v109)
		v142.Parent = v87
	end
	local v148 = -(v_u_16.hand.Z + v_u_82.pos.Z)
	local function v154(p149) -- name: asOffsets
		-- upvalues: (ref) v_u_10, (copy) v_u_117, (ref) v_u_16, (ref) v_u_82
		if type(p149) ~= "table" then
			return nil, nil
		end
		local v150 = v_u_10.Frame(p149.pos, p149.tip, p149.edge)
		local v151, v152, v153 = (v150.Rotation * v_u_117:Inverse()):ToEulerAnglesYXZ()
		return v150.Position - (v_u_16.hand + v_u_82.pos), Vector3.new(v151, v152, v153)
	end
	local v155, v156 = v154(v_u_82.blockFrame)
	local v157, v158 = v154(v_u_82.drawFrame)
	local v159 = 0
	for _, v160 in v134 do
		local v161 = v160.Z
		v159 = math.max(v159, v161)
	end
	local v162 = {
		["model"] = v85,
		["gripInv"] = v115:Inverse(),
		["pivotRel"] = v87.CFrame:ToObjectSpace(v85:GetPivot()),
		["kind"] = p80,
		["cfg"] = v_u_82,
		["id"] = p79,
		["style"] = v118,
		["styleRot"] = v_u_117,
		["norm"] = v101,
		["bladeLen"] = v121,
		["blockP"] = v155,
		["blockR"] = v156,
		["drawP"] = v157,
		["drawR"] = v158,
		["brace"] = v159,
		["clips"] = v_u_10.SETS[p80] or v_u_12.For(p79, p80)
	}
	local v163 = v_u_12.ITEMS[p79]
	v162.drawFrom = v163 and v163.drawFrom or (v_u_10.DRAW[p80] or v_u_12.DRAW[p80])
	v162.corners = v134
	local v164
	if v142 and v142:IsA("Attachment") then
		v164 = v142
	elseif v119 and v119:IsA("Attachment") then
		v164 = v119
	else
		v164 = nil
	end
	v162.muzzle = v164
	local v165
	if v119 and v119:IsA("Attachment") then
		v165 = v119
	else
		v165 = nil
	end
	v162.tipAtt = v165
	if not (v120 and v120:IsA("Attachment")) then
		v120 = nil
	end
	v162.gripAtt = v120
	v162.pan = v143
	v162.hammer = v_u_60(v85, v87)
	v162.frizzen = v_u_60(v85, v87, "Frizzen", "FrizzenPivot", "Open")
	local v166 = v_u_68
	if not (v142 and v142:IsA("Attachment")) then
		v142 = nil
	end
	v162.rod = v166(v85, v87, v142)
	local v167
	if p79 == "longbow" then
		v167 = v85:FindFirstChild("Neon", true)
	else
		v167 = nil
	end
	v162.inlay = v167 and v167:IsA("BasePart") and {
		["part"] = v167,
		["rest"] = v167.Color
	} or nil
	local v168 = v85:FindFirstChild("Strip", true)
	local v169
	if v168 and v168:IsA("BasePart") then
		v168.Transparency = 0
		v169 = {
			["part"] = v168,
			["size"] = v168.Size,
			["rest"] = v87.CFrame:ToObjectSpace(v168.CFrame)
		}
	else
		v169 = nil
	end
	v162.strip = v169
	local v170 = v85:FindFirstChild("Stone", true)
	if not (v170 and v170:IsA("BasePart")) then
		v170 = nil
	end
	v162.stone = v170
	local v171 = v87:FindFirstChild("NockTop")
	local v172
	if v171 and v171:IsA("Attachment") then
		v172 = (v101 * v115:Inverse()):PointToWorldSpace(v171.Position)
	else
		v172 = nil
	end
	local v173 = v87:FindFirstChild("NockBottom")
	local v174
	if v173 and v173:IsA("Attachment") then
		v174 = (v101 * v115:Inverse()):PointToWorldSpace(v173.Position)
	else
		v174 = nil
	end
	local v175 = v87:FindFirstChild("Brace")
	local v176
	if v175 and v175:IsA("Attachment") then
		v176 = (v101 * v115:Inverse()):PointToWorldSpace(v175.Position)
	else
		v176 = nil
	end
	local v177 = v87:FindFirstChild("NockPoint")
	local v178
	if v177 and v177:IsA("Attachment") then
		v178 = (v101 * v115:Inverse()):PointToWorldSpace(v177.Position)
	else
		v178 = nil
	end
	local v179 = v87:FindFirstChild("Rest")
	local v180
	if v179 and v179:IsA("Attachment") then
		v180 = (v101 * v115:Inverse()):PointToWorldSpace(v179.Position)
	else
		v180 = nil
	end
	v162.bow = v172 and (v174 and (v176 and (v178 and v180))) and {
		["top"] = v172,
		["bottom"] = v174,
		["brace"] = v176,
		["nock"] = v178,
		["rest"] = v180
	} or nil
	local v181 = v87:FindFirstChild("StringLeft")
	local v182
	if v181 and v181:IsA("Attachment") then
		v182 = (v101 * v115:Inverse()):PointToWorldSpace(v181.Position)
	else
		v182 = nil
	end
	local v183 = v87:FindFirstChild("StringRight")
	local v184
	if v183 and v183:IsA("Attachment") then
		v184 = (v101 * v115:Inverse()):PointToWorldSpace(v183.Position)
	else
		v184 = nil
	end
	local v185 = v87:FindFirstChild("Nut")
	local v186
	if v185 and v185:IsA("Attachment") then
		v186 = (v101 * v115:Inverse()):PointToWorldSpace(v185.Position)
	else
		v186 = nil
	end
	local v187 = v87:FindFirstChild("Brace")
	local v188
	if v187 and v187:IsA("Attachment") then
		v188 = (v101 * v115:Inverse()):PointToWorldSpace(v187.Position)
	else
		v188 = nil
	end
	v162.xbow = p80 == "Crossbow" and (v182 and (v184 and (v186 and v188))) and {
		["left"] = v182,
		["right"] = v184,
		["nut"] = v186,
		["brace"] = v188
	} or nil
	local v189
	if v119 and v119:IsA("Attachment") then
		v189 = (v101 * v115:Inverse()):PointToWorldSpace(v119.Position)
	else
		v189 = nil
	end
	v162.tipCanon = v189
	v162.handle = v87
	v162.leftFist = v112
	v162.wallDist = v148 + v125 + v_u_16.wallMargin
	local v190 = v_u_16.wallRotMax
	local v191 = v_u_82.len
	local v192 = v125 / math.max(v191, 0.05)
	local v193 = math.clamp(v192, 0, 1)
	local v194 = math.asin(v193)
	local v195 = math.deg(v194) + 12
	v162.wallRot = math.min(v190, v195) * 0.017453292519943295
	if v112 then
		v112.part.Parent = v85
	end
	v85.Name = "TribesViewModel_" .. p79
	v_u_23[p79] = v162
	return v162
end
local v_u_197 = v7.new(Vector3.new(0, 0, 0), v_u_16.poseHz, v_u_16.poseDamp)
local v_u_198 = v7.new(Vector3.new(0, 0, 0), v_u_16.poseHz, v_u_16.poseDamp)
local v_u_199 = v7.new(0, v_u_16.airHz, v_u_16.airDamp)
local v_u_200 = v7.new(0, v_u_16.airHz, v_u_16.airDamp)
local v_u_201 = v7.new(0, v_u_16.landHz, v_u_16.landDamp)
local v_u_202 = v7.new(Vector3.new(0, 0, 0), v_u_16.swayHz, v_u_16.swayDamp)
local v_u_203 = v7.new(Vector3.new(0, 0, 0), v_u_16.kickHz, v_u_16.kickDamp)
local v_u_204 = v7.new(Vector3.new(0, 0, 0), v_u_16.kickHz, v_u_16.kickDamp)
local v_u_205 = v7.new(0, v_u_16.equipHz, v_u_16.equipDamp)
local v_u_206 = {
	["shown"] = nil,
	["wantId"] = nil,
	["dropAt"] = nil,
	["hiddenUntil"] = 0,
	["action"] = nil,
	["actT0"] = 0,
	["actDur"] = 1,
	["actMirror"] = 1,
	["block"] = false,
	["parry"] = false,
	["charge"] = false,
	["chargeT0"] = 0,
	["chargeTime"] = 0.6,
	["draw"] = false,
	["drawT0"] = 0,
	["drawTime"] = 1,
	["wind"] = false,
	["windT0"] = 0,
	["windTime"] = 0.5,
	["windHold"] = 0,
	["windK"] = 0,
	["windHalf"] = false,
	["throwN"] = 0,
	["looseAt"] = nil,
	["nocked"] = true,
	["nockT0"] = -10,
	["shotN"] = 0,
	["arrowTip"] = nil,
	["inlayLvl"] = 0,
	["inlayFrom"] = Color3.new(),
	["inlayT0"] = -10,
	["bite"] = 0,
	["spinA"] = 0,
	["spinT0"] = -10,
	["stringV"] = 0,
	["stringT0"] = -10,
	["stripV"] = 0.25,
	["useOutUntil"] = nil,
	["use"] = false,
	["useT0"] = 0,
	["useTime"] = 1,
	["reload"] = false,
	["reloadT0"] = 0,
	["reloadTime"] = 1,
	["grounded"] = true,
	["minVy"] = 0,
	["lastYaw"] = nil,
	["lastPitch"] = nil,
	["lastRootY"] = nil,
	["vy"] = 0,
	["step"] = 0,
	["now"] = 0,
	["spent"] = false,
	["clip"] = nil,
	["clipT0"] = 0,
	["clipFrom"] = CFrame.identity,
	["clipScale"] = 1,
	["lastFrame"] = nil,
	["frame"] = nil,
	["layerPos"] = Vector3.new(0, 0, 0),
	["layerRot"] = Vector3.new(0, 0, 0),
	["spark"] = false,
	["wallPush"] = 0,
	["restFrame"] = CFrame.identity,
	["rawVel"] = nil,
	["clipFromVel"] = nil,
	["lastFrameT"] = 0,
	["clipName"] = nil,
	["clipFx"] = 1,
	["fxQueue"] = {},
	["pendingDraw"] = nil,
	["vanishAt"] = nil,
	["shakeUntil"] = 0,
	["embers"] = false,
	["fuse"] = 0,
	["arrowKind"] = "Arrow",
	["sim"] = false,
	["release"] = nil,
	["releaseT"] = 0,
	["boltIn"] = true,
	["boltT0"] = -10,
	["drawHold"] = 0,
	["drawHalf"] = false,
	["drawFull"] = false,
	["chargeFull"] = false,
	["hammerTarget"] = 0,
	["frizzenTarget"] = 0,
	["rodV"] = 0,
	["windFull"] = false,
	["leftLast"] = nil,
	["leftFrom"] = CFrame.identity,
	["leftFromVel"] = nil,
	["leftVel"] = nil,
	["leftFrame"] = nil,
	["leftOut"] = false,
	["leftVanishAt"] = nil,
	["leftCatchT"] = -10,
	["lastLungeT"] = nil,
	["lastLungeName"] = nil,
	["refreshGlintAt"] = nil,
	["refreshFF"] = nil,
	["leftOutAt"] = -10,
	["leftSeenOut"] = false
}
local v_u_207 = v7.new(Vector3.new(0, 0, 0), v_u_16.retHz, v_u_16.retDamp)
local v_u_208 = v7.new(0, 16, 0.45)
local v_u_209 = v7.new(0, 14, 0.4)
local v_u_210 = v7.new(Vector3.new(0, 0, 0), v_u_16.retHz, v_u_16.retDamp)
local function v_u_252() -- name: resetState
	-- upvalues: (copy) v_u_197, (copy) v_u_198, (copy) v_u_199, (copy) v_u_200, (copy) v_u_201, (copy) v_u_202, (copy) v_u_203, (copy) v_u_204, (copy) v_u_205, (copy) v_u_207, (copy) v_u_210, (copy) v_u_206, (copy) v_u_11, (copy) v_u_13
	v_u_197:Snap(Vector3.new(0, 0, 0))
	v_u_198:Snap(Vector3.new(0, 0, 0))
	v_u_199:Snap(0)
	v_u_200:Snap(0)
	v_u_201:Snap(0)
	v_u_202:Snap(Vector3.new(0, 0, 0))
	v_u_203:Snap(Vector3.new(0, 0, 0))
	v_u_204:Snap(Vector3.new(0, 0, 0))
	v_u_205:Snap(0)
	v_u_207:Snap(Vector3.new(0, 0, 0))
	v_u_210:Snap(Vector3.new(0, 0, 0))
	v_u_206.action = nil
	local v211 = v_u_206
	local v212 = v_u_206
	local v213 = v_u_206
	local v214 = v_u_206
	v_u_206.clip = nil
	v211.lastFrame = nil
	v212.frame = nil
	v213.spark = false
	v214.rawVel = nil
	local v215 = v_u_206
	local v216 = v_u_206
	local v217 = v_u_206
	v_u_206.leftLast = nil
	v215.leftFromVel = nil
	v216.leftVel = nil
	v217.leftFrame = nil
	local v218 = v_u_206
	local v219 = v_u_206
	local v220 = v_u_206
	local v221 = v_u_206
	v_u_206.leftOut = false
	v218.leftVanishAt = nil
	v219.leftCatchT = -10
	v220.leftOutAt = -10
	v221.leftSeenOut = false
	local v222 = v_u_206
	local v223 = v_u_206
	local v224 = v_u_206
	v_u_206.lastLungeT = nil
	v222.lastLungeName = nil
	v223.refreshGlintAt = nil
	v224.refreshFF = nil
	local v225 = v_u_206
	local v226 = v_u_206
	v_u_206.clipName = nil
	v225.pendingDraw = nil
	v226.vanishAt = nil
	local v227 = v_u_206
	local v228 = v_u_206
	v_u_206.drawHold = 0
	v227.drawHalf = false
	v228.drawFull = false
	local v229 = v_u_206
	local v230 = v_u_206
	local v231 = v_u_206
	v_u_206.nocked = true
	v229.nockT0 = -10
	v230.shotN = 0
	v231.looseAt = nil
	local v232 = v_u_206
	local v233 = v_u_206
	local v234 = v_u_206
	local v235 = v_u_206
	local v236 = v_u_206
	v_u_206.windHold = 0
	v232.windK = 0
	v233.windFull = false
	v234.windHalf = false
	v235.throwN = 0
	v236.bite = 0
	local v237 = v_u_206
	v_u_206.stringV = 0
	v237.stringT0 = -10
	local v238 = v_u_206
	local v239 = v_u_206
	local v240 = v_u_206
	v_u_206.stripV = 0.25
	v238.useOutUntil = nil
	v239.spinA = 0
	v240.spinT0 = -10
	table.clear(v_u_206.fxQueue)
	v_u_11.Hide()
	v_u_13.Hide()
	local v241 = v_u_206
	v_u_206.embers = false
	v241.fuse = 0
	local v242 = v_u_206
	local v243 = v_u_206
	local v244 = v_u_206
	local v245 = v_u_206
	local v246 = v_u_206
	local v247 = v_u_206
	v_u_206.block = false
	v242.parry = false
	v243.charge = false
	v244.draw = false
	v245.wind = false
	v246.use = false
	v247.reload = false
	v_u_206.dropAt = nil
	v_u_206.hiddenUntil = 0
	local v248 = v_u_206
	local v249 = v_u_206
	v_u_206.lastYaw = nil
	v248.lastPitch = nil
	v249.lastRootY = nil
	local v250 = v_u_206
	local v251 = v_u_206
	v_u_206.vy = 0
	v250.minVy = 0
	v251.grounded = true
end
local function v_u_267(p253, p254, p255, p256) -- name: startClip
	-- upvalues: (copy) v_u_206, (copy) v_u_207, (copy) v_u_210
	local v257
	if v_u_206.shown then
		v257 = v_u_206.shown.clips
	else
		v257 = nil
	end
	local v258
	if v257 then
		v258 = v257[p253]
	else
		v258 = nil
	end
	if not v258 then
		return false
	end
	v_u_206.clip = v258
	v_u_206.clipName = p253
	v_u_206.clipFx = 1
	v_u_206.clipFrom = p255 or (v_u_206.lastFrame or v_u_206.restFrame)
	local v259 = v_u_206
	local v260
	if p255 then
		v260 = nil
	else
		v260 = v_u_206.rawVel
	end
	v259.clipFromVel = v260
	v_u_206.leftFrom = p255 or (v_u_206.leftLast or v_u_206.restFrame)
	local v261 = v_u_206
	local v262
	if p255 then
		v262 = nil
	else
		v262 = v_u_206.leftVel
	end
	v261.leftFromVel = v262
	local v263 = v_u_206.lastFrameT
	local v264 = v_u_206
	if p255 or (not v_u_206.lastFrame or (v_u_206.now - v263 < 0 or v_u_206.now - v263 >= 0.1)) then
		v263 = v_u_206.now
	end
	v264.clipT0 = v263
	local v265 = v_u_206
	if not p256 then
		if p254 and (p254 > 0 and v258.contact > 0) then
			local v266 = p254 / v258.contact
			p256 = math.clamp(v266, 0.6, 1.8)
		else
			p256 = 1
		end
	end
	v265.clipScale = p256
	v_u_207:Snap(Vector3.new(0, 0, 0))
	v_u_210:Snap(Vector3.new(0, 0, 0))
	return true
end
local function v_u_401(p268, p269) -- name: onEvent
	-- upvalues: (copy) v_u_206, (copy) v_u_10, (copy) v_u_12, (copy) v_u_267, (copy) v_u_22, (copy) v_u_203, (copy) v_u_204, (copy) v_u_208, (copy) v_u_209, (copy) v_u_16
	local v270 = p269 or {}
	local v271 = v_u_206.shown
	local v272
	if v271 then
		v272 = v271.kind
	else
		v272 = nil
	end
	if p268 == "Swing" then
		local v273 = v270.step
		local v274 = tonumber(v273) or 1
		local v275 = v270.finisher == true
		local v276
		if v272 == "Sword" or v272 == "Dagger" then
			v276 = v_u_10.Pick(v272, v274, v275)
		elseif v272 then
			v276 = v_u_12.Pick(v272, v274, v275, v270.oneHanded == true and true or v_u_206.leftOut)
		else
			v276 = nil
		end
		if v272 == "Shield" and v276 == "bash" then
			local v277 = v_u_206
			v277.shotN = v277.shotN + 1
			if v_u_206.shotN % 2 == 0 then
				local v278 = v_u_206.shown
				local v279
				if v278 == nil or v278.clips == nil then
					v279 = false
				else
					v279 = v278.clips.bash2 ~= nil
				end
				v276 = v279 and "bash2" or v276
			end
		end
		if v276 then
			local v280 = v_u_267
			local v281 = v270.hitDelay
			if v280(v276, (tonumber(v281))) then
				return
			end
		end
		if v272 == "Shield" then
			local v282 = v_u_22.stab
			if v282 then
				v_u_206.action = "stab"
				v_u_206.actT0 = v_u_206.now
				v_u_206.actDur = v282.dur
				v_u_206.actMirror = 1
			end
		end
		if v272 == "Axe" then
			local v283 = v_u_22.chop
			if v283 then
				v_u_206.action = "chop"
				v_u_206.actT0 = v_u_206.now
				v_u_206.actDur = v283.dur
				v_u_206.actMirror = 1
			end
		end
		if v272 == "Club" then
			local v284 = v_u_22.smash
			if v284 then
				v_u_206.action = "smash"
				v_u_206.actT0 = v_u_206.now
				v_u_206.actDur = v284.dur
				v_u_206.actMirror = 1
			end
		end
		if v272 == "Spear" then
			local v285 = v_u_22.thrust
			if v285 then
				v_u_206.action = "thrust"
				v_u_206.actT0 = v_u_206.now
				v_u_206.actDur = v285.dur
				v_u_206.actMirror = 1
			end
		end
	elseif p268 == "Parry" then
		local v286 = v_u_206.parry
		v_u_206.parry = v270.on == true
		if v_u_206.parry and not v286 then
			v_u_267("parry_in")
			return
		end
		if v286 and not v_u_206.parry then
			v_u_267("parry_out")
			return
		end
	elseif p268 == "Parried" then
		v_u_206.parry = false
		if not v_u_267("parry_hit") then
			v_u_203:Impulse(Vector3.new(0.03, -0.04, 0.08))
			return
		end
	else
		if p268 == "Hurl" then
			local v287
			if v271 and v271.clips then
				v287 = v271.clips.throw
			else
				v287 = nil
			end
			if v287 and v_u_267("throw") then
				v_u_206.leftVanishAt = v_u_206.now + (v287.vanishLeft or 0.06) * v_u_206.clipScale
			else
				local v288 = v_u_206
				local v289 = v_u_206
				local v290 = v_u_206.now
				v288.leftOut = true
				v289.leftOutAt = v290
			end
		end
		if p268 == "Catch" then
			if v_u_206.leftOut or v_u_206.leftVanishAt then
				local v291 = v_u_206
				local v292 = v_u_206
				v_u_206.leftOut = false
				v291.leftVanishAt = nil
				v292.leftSeenOut = false
				v_u_206.leftCatchT = v_u_206.now
				return
			end
		elseif p268 == "Block" then
			local v293 = v_u_206.block
			v_u_206.block = v270.on == true
			if v_u_206.block and not v293 then
				v_u_267("block_in")
				return
			end
			if v293 and not v_u_206.block then
				v_u_267("block_out")
				return
			end
		else
			if p268 == "Charge" then
				v_u_206.charge = v270.on == true
				local v294 = v_u_206
				local v295 = v_u_206
				local v296 = v_u_206.now
				local v297 = v270.time
				local v298 = tonumber(v297) or 0.6
				v294.chargeT0 = v296
				v295.chargeTime = v298
				v_u_206.chargeFull = false
				return
			end
			if p268 == "Heavy" then
				v_u_206.charge = false
				local v299 = v_u_267
				local v300 = v270.hitDelay
				if not v299("heavy", (tonumber(v300))) then
					local v301 = v_u_22.heavy
					if v301 then
						v_u_206.action = "heavy"
						v_u_206.actT0 = v_u_206.now
						v_u_206.actDur = v301.dur
						v_u_206.actMirror = 1
					end
				end
			elseif p268 == "Lunge" then
				v_u_206.charge = false
				local v302 = v270.time
				local v303 = tonumber(v302) or 0.25
				local v304 = "lunge"
				local v305 = v_u_206.shown
				local v306
				if v305 == nil or v305.clips == nil then
					v306 = false
				else
					v306 = v305.clips.lunge_b ~= nil
				end
				if v306 then
					local v307 = v_u_206.now - v_u_206.clipT0
					local v308 = not v_u_206.lastLungeT and (1 / 0) or v_u_206.now - v_u_206.lastLungeT
					local v309
					if v_u_206.clipName == "sweep_r" and v307 < 0.45 then
						v309 = true
					elseif (v_u_206.clipName == "lunge" or v_u_206.clipName == "lunge_c") and v307 > 0.22 then
						v309 = v307 < 0.34
					else
						v309 = false
					end
					if v309 then
						v304 = "lunge_b"
					elseif v308 >= 0 and (v308 < 1.5 and v_u_206.lastLungeName == "lunge") then
						local v310 = v_u_206.shown
						local v311
						if v310 == nil or v310.clips == nil then
							v311 = false
						else
							v311 = v310.clips.lunge_c ~= nil
						end
						v304 = v311 and "lunge_c" or v304
					end
				end
				local v312 = v_u_206
				v_u_206.lastLungeT = v_u_206.now
				v312.lastLungeName = v304
				local v313 = v_u_206.shown and (v_u_206.shown.clips and v_u_206.shown.clips[v304]) and (v_u_206.shown.clips[v304].lungeRef or 0.24) or 0.24
				if v_u_206.refreshGlintAt or v_u_206.refreshFF then
					v_u_206.refreshGlintAt = v_u_206.now
				end
				v_u_206.refreshFF = nil
				local v314 = v_u_267
				local v315 = v303 / v313
				if not v314(v304, nil, nil, (math.clamp(v315, 0.6, 2))) then
					local v316 = v303 + 0.3
					local v317 = v_u_22.lunge
					if v317 then
						v_u_206.action = "lunge"
						v_u_206.actT0 = v_u_206.now
						v_u_206.actDur = v316 or v317.dur
						v_u_206.actMirror = 1
					end
				end
			else
				if p268 == "Refresh" then
					local v318 = v_u_206.clip
					if v318 and (v318.refreshAt and (v_u_206.clipScale and (v_u_206.now - v_u_206.clipT0) / v_u_206.clipScale < v318.refreshAt)) then
						v_u_206.refreshFF = v318.refreshAt
						v_u_206.refreshGlintAt = nil
					else
						v_u_206.refreshGlintAt = v_u_206.now
					end
				end
				if p268 == "Draw" then
					v_u_206.draw = v270.on == true
					local v319 = v_u_206
					local v320 = v_u_206
					local v321 = v_u_206.now
					local v322 = v270.time
					local v323 = tonumber(v322) or 1
					local v324 = math.max(0.1, v323)
					v319.drawT0 = v321
					v320.drawTime = v324
					if v_u_206.draw then
						local v325 = v_u_206
						local v326 = v270.arrow
						v325.arrowKind = type(v326) ~= "string" and "Arrow" or v270.arrow
						local v327 = v_u_206
						local v328 = v_u_206
						v_u_206.drawHalf = false
						v327.drawFull = false
						v328.drawHold = 0
						if not v_u_206.nocked then
							local v329 = v_u_206
							local v330 = v_u_206
							local v331 = v_u_206.now
							v329.nocked = true
							v330.nockT0 = v331
						end
						v_u_267("nock")
						return
					end
				elseif p268 == "Release" then
					v_u_206.draw = false
					v_u_206.nocked = false
					v_u_206.drawHold = v_u_206.now + 0.16
					local v332 = v270.charge
					local v333 = tonumber(v332) or 1
					local v334 = math.clamp(v333, 0.2, 1) * (not (v271 and v271.cfg.kick) and 1 or v271.cfg.kick)
					if not v_u_267("release") then
						v_u_203:Impulse(Vector3.new(0, 0.2, 1.2) * v334)
						v_u_204:Impulse(Vector3.new(120, 0, 0) * v334 * 0.017453292519943295)
						return
					end
				else
					if p268 == "Fire" then
						v_u_206.boltIn = false
						local v335 = v_u_206
						local v336 = v_u_206
						local v337 = v_u_206.now
						v335.stringV = 1
						v336.stringT0 = v337
						v_u_206.hammerTarget = 1
						v_u_208.velocity = 30
						v_u_206.frizzenTarget = 1
						v_u_209.velocity = 22
						local v338
						if (v_u_206.clipName == "draw" or v_u_206.clipName == "redraw") and v_u_206.clip ~= nil then
							v338 = v_u_206.now - v_u_206.clipT0 < v_u_206.clip.release * v_u_206.clipScale * 0.7
						else
							v338 = false
						end
						if v338 then
							local v339 = v_u_206.fxQueue
							table.insert(v339, "muzzle")
						end
						local v340 = v_u_206
						v340.shotN = v340.shotN + 1
						if v338 or not v_u_267("fire") then
							local v341 = v270.kick
							local v342 = (tonumber(v341) or 2) / 3 * (not (v271 and v271.cfg.kick) and 1 or v271.cfg.kick)
							local v343 = math.min(v342, 3.5)
							v_u_203:Impulse(Vector3.new(0, 0.5, 3) * v343)
							local v344 = v_u_204
							local v345 = (math.random() - 0.5) * 40
							local v346 = (math.random() - 0.5) * 40
							v344:Impulse(Vector3.new(420, v345, v346) * v343 * 0.017453292519943295)
						else
							local v347 = ({
								["Musket"] = Vector3.new(160, 80, 280),
								["Blunderbuss"] = Vector3.new(220, 80, 260),
								["Pistol"] = Vector3.new(340, 60, 220),
								["Crossbow"] = Vector3.new(90, 40, 60)
							})[v272 or ""] or Vector3.new(150, 60, 150)
							local v348 = Random.new(v_u_206.shotN * 7919 + 17)
							local v349 = v_u_204
							local v350 = v348:NextNumber(-1, 1) * v347.X
							local v351 = v348:NextNumber(-1, 1) * v347.Y
							local v352 = v348:NextNumber(-1, 1) * v347.Z
							v349:Impulse(Vector3.new(v350, v351, v352) * 0.017453292519943295)
						end
					end
					if p268 == "Reload" then
						local v353 = v270.time
						local v354 = tonumber(v353) or 1.2
						local v355 = math.max(0.2, v354)
						local v356
						if v271 and v271.clips then
							v356 = v271.clips.reload
						else
							v356 = nil
						end
						if v356 then
							local v357 = v_u_267
							local v358 = v355 / (v356.span or v356.release)
							v357("reload", nil, nil, (math.clamp(v358, 0.35, 2.5)))
						else
							v_u_206.reload = true
							local v359 = v_u_206
							v_u_206.reloadT0 = v_u_206.now
							v359.reloadTime = v355
						end
					end
					if p268 == "ReloadEnd" then
						v_u_206.reload = false
						return
					end
					if p268 == "Windup" then
						v_u_206.wind = v270.on == true
						local v360 = v_u_206
						local v361 = v_u_206
						v_u_206.windFull = false
						v360.windHalf = false
						v361.windHold = 0
						local v362 = v_u_206
						local v363 = v_u_206
						local v364 = v_u_206.now
						local v365 = v270.time
						local v366 = tonumber(v365) or 0.5
						local v367 = math.max(0.1, v366)
						v362.windT0 = v364
						v363.windTime = v367
						if v_u_206.wind then
							v_u_267("windup")
							return
						end
					elseif p268 == "Throw" then
						local v368 = v_u_206
						v368.throwN = v368.throwN + 1
						local v369 = v271 and (v271.clips and (v271.clips.throw2 and v_u_206.throwN % 2 == 0)) and "throw2" or "throw"
						local v370
						if v271 and v271.clips then
							v370 = v271.clips[v369]
						else
							v370 = nil
						end
						if v_u_206.wind then
							local v371 = (v_u_206.now - v_u_206.windT0) / v_u_206.windTime
							local v372 = math.clamp(v371, 0, 1)
							local v373 = v_u_206
							local v374 = (v_u_206.now - v_u_206.windT0) / 0.12
							local v375 = math.clamp(v374, 0, 1)
							local v376 = v375 * v375 * (3 - v375 * 2) * 0.75
							local v377 = math.clamp(v372, 0, 1)
							v373.windK = v376 + v377 * v377 * (3 - v377 * 2) * 0.25
							v_u_206.windHold = v_u_206.now + (not (v370 and v370.vanish) and 0.07 or v370.vanish) + 0.06
						end
						v_u_206.wind = false
						if not (v370 and v_u_267(v369)) then
							local v378 = v_u_22.throw
							if v378 then
								v_u_206.action = "throw"
								v_u_206.actT0 = v_u_206.now
								v_u_206.actDur = v378.dur
								v_u_206.actMirror = 1
							end
							v_u_206.hiddenUntil = v_u_206.now + 0.5
							return
						end
						if v370.vanish then
							v_u_206.vanishAt = v_u_206.now + v370.vanish * v_u_206.clipScale
							v_u_206.hiddenUntil = v_u_206.vanishAt + (v_u_12.HIDE[v272 or ""] or 0.45)
							return
						end
						if v370.loose then
							v_u_206.looseAt = v_u_206.now + v370.loose * v_u_206.clipScale
							return
						end
					elseif p268 == "Use" then
						local v379 = v_u_206.use
						v_u_206.use = v270.on == true
						local v380 = v_u_206
						local v381 = v_u_206
						local v382 = v_u_206.now
						local v383 = v270.time
						local v384 = tonumber(v383) or 1
						local v385 = math.max(0.2, v384)
						v380.useT0 = v382
						v381.useTime = v385
						if v_u_206.use and not v379 then
							v_u_206.bite = 0
							v_u_267("use_in")
							return
						end
						if v_u_206.use or not v379 then
							if v270.done then
								v_u_203:Impulse(Vector3.new(0, 0.5, 0))
								return
							end
						else
							v_u_206.useOutUntil = v_u_206.now + 0.45
							if not v270.done then
								v_u_267("use_out")
								return
							end
							if not v_u_267("use_done") then
								v_u_203:Impulse(Vector3.new(0, 0.5, 0))
								return
							end
						end
					else
						if p268 == "Place" then
							local v386
							if v271 and v271.clips then
								v386 = v271.clips.place
							else
								v386 = nil
							end
							if v386 and v_u_267("place") then
								v_u_206.vanishAt = v_u_206.now + (v386.vanish or 0.2)
								v_u_206.hiddenUntil = v_u_206.vanishAt + (v_u_12.HIDE[v272 or ""] or 0.5)
							else
								local v387 = v_u_22.place
								if v387 then
									v_u_206.action = "place"
									v_u_206.actT0 = v_u_206.now
									v_u_206.actDur = v387.dur
									v_u_206.actMirror = 1
								end
								v_u_206.hiddenUntil = v_u_206.now + 0.6
							end
						end
						if p268 == "Hurt" then
							if v270.blocked and (v_u_206.block and v271) then
								if v271.cfg.blockFrame then
									v_u_206.spark = true
								else
									local v388 = v_u_206.shown
									local v389
									if v388 == nil or v388.clips == nil then
										v389 = false
									else
										v389 = v388.clips.block_hit ~= nil
									end
									if v389 then
										v_u_267("block_hit")
										local v390 = v_u_206.fxQueue
										table.insert(v390, "rimspark")
									end
								end
							end
							local v391 = v270.amount
							local v392 = (tonumber(v391) or 10) / 40
							local v393 = math.clamp(v392, 0.2, 1.2) * (v270.blocked and 0.5 or 1)
							local v394 = v_u_204
							local v395 = (math.random() - 0.3) * 2
							local v396 = (math.random() - 0.5) * 2
							local v397 = (math.random() - 0.5) * 2.5
							v394:Impulse(Vector3.new(v395, v396, v397) * v_u_16.hurtRot * v393 * 0.017453292519943295)
							local v398 = v_u_203
							local v399 = -v_u_16.hurtPos
							local v400 = v_u_16.hurtPos * 0.6
							v398:Impulse(Vector3.new(0, v399, v400) * v393)
						end
					end
				end
			end
		end
	end
end
local function v_u_415(p402, p403) -- name: evalKeys
	local v404 = #p402
	if p403 <= p402[1][1] then
		return p402[1][2], p402[1][3]
	end
	for v405 = 1, v404 - 1 do
		local v406 = p402[v405]
		local v407 = p402[v405 + 1]
		local v408 = v406[1]
		local v409 = v407[1]
		if p403 > v409 then
			continue
		end
		local v410 = p403 - v408
		local v411 = v409 - v408
		local v412 = v410 / math.max(v411, 0.0001)
		local v413 = math.clamp(v412, 0, 1)
		local v414 = v413 * v413 * (3 - v413 * 2)
		return v406[2]:Lerp(v407[2], v414), v406[3]:Lerp(v407[3], v414)
	end
	return p402[v404][2], p402[v404][3]
end
local function v_u_714(p416) -- name: step
	-- upvalues: (copy) v_u_206, (copy) v_u_19, (copy) v_u_16, (copy) v_u_196, (copy) v_u_207, (copy) v_u_210, (copy) v_u_13, (copy) v_u_208, (copy) v_u_209, (copy) v_u_205, (copy) v_u_201, (copy) v_u_202, (copy) v_u_203, (copy) v_u_204, (copy) v_u_197, (copy) v_u_198, (copy) v_u_199, (copy) v_u_200, (copy) v_u_22, (copy) v_u_415, (copy) v_u_267, (copy) v_u_10, (copy) v_u_78
	local v417 = p416.dt
	local v418 = math.clamp(v417, 0.004166666666666667, 0.1)
	local v419 = p416.now
	v_u_206.now = v419
	local v420
	if p416.visible and (p416.id and (p416.kind and v_u_19[p416.kind])) then
		v420 = p416.id
	else
		v420 = nil
	end
	if v420 ~= v_u_206.wantId then
		v_u_206.wantId = v420
		if v_u_206.shown and (v_u_206.shown.id ~= v420 and not v_u_206.dropAt) then
			v_u_206.dropAt = v419
		end
	end
	if v_u_206.dropAt and (v_u_206.shown and v_u_206.shown.id == v_u_206.wantId) then
		v_u_206.dropAt = nil
	end
	local v421
	if v_u_206.shown then
		v421 = v_u_206.shown.id
	else
		v421 = nil
	end
	if v421 ~= v_u_206.wantId and (v_u_206.shown == nil or v_u_206.dropAt ~= nil and v419 - v_u_206.dropAt >= v_u_16.dropTime) then
		v_u_206.dropAt = nil
		local v422 = v_u_206
		local v423
		if v_u_206.wantId then
			v423 = v_u_196(v_u_206.wantId, p416.kind)
		else
			v423 = nil
		end
		v422.shown = v423
		v_u_206.action = nil
		local v424 = v_u_206
		local v425 = v_u_206
		local v426 = v_u_206
		v_u_206.clip = nil
		v424.lastFrame = nil
		v425.rawVel = nil
		v426.clipName = nil
		v_u_207:Snap(Vector3.new(0, 0, 0))
		v_u_210:Snap(Vector3.new(0, 0, 0))
		local v427 = v_u_206
		local v428 = v_u_206
		local v429 = v_u_206
		local v430 = v_u_206
		local v431 = v_u_206
		local v432 = v_u_206
		v_u_206.block = false
		v427.parry = false
		v428.charge = false
		v429.draw = false
		v430.wind = false
		v431.use = false
		v432.reload = false
		local v433 = v_u_206
		v_u_206.hiddenUntil = 0
		v433.vanishAt = nil
		v_u_206.drawHold = 0
		local v434 = v_u_206
		v_u_206.windHold = 0
		v434.looseAt = nil
		local v435 = v_u_206
		v_u_206.nocked = false
		v435.nockT0 = -10
		local v436 = v_u_206
		v_u_206.stringV = 0
		v436.stringT0 = -10
		table.clear(v_u_206.fxQueue)
		if v_u_206.embers then
			v_u_206.embers = false
			v_u_13.Play("embers", CFrame.identity, {
				["on"] = false
			})
		end
		if v_u_206.fuse > 0 then
			v_u_206.fuse = 0
			v_u_13.Play("fuse", CFrame.identity, {
				["on"] = false
			})
		end
		local v437 = v_u_206
		v_u_206.boltIn = true
		v437.boltT0 = -10
		v_u_206.hammerTarget = 0.5
		v_u_208:Snap(0.5)
		v_u_206.frizzenTarget = 0
		v_u_209:Snap(0)
		if v_u_206.shown then
			if v_u_206.shown.drawFrom and (v_u_206.shown.clips and v_u_206.shown.clips.draw) then
				v_u_205:Snap(0)
				v_u_206.pendingDraw = "draw"
			else
				local v438 = v_u_205
				local v439 = v_u_205
				v_u_205.value = -1
				v438.velocity = 0
				v439.target = 0
			end
		end
	end
	local v440 = v_u_206.shown
	if not v440 then
		return Vector3.new(0, 0, 0), Vector3.new(0, 0, 0), nil
	end
	local v441 = v440.cfg
	if v_u_206.lastRootY and v418 > 0 then
		local v442 = (p416.rootY - v_u_206.lastRootY) / v418
		local v443 = math.abs(v442) > 150 and 0 or v442
		local v444 = v_u_206
		local v445 = v444.vy
		local v446 = v443 - v_u_206.vy
		local v447 = v418 * -14
		v444.vy = v445 + v446 * (1 - math.exp(v447))
	end
	v_u_206.lastRootY = p416.rootY
	if p416.grounded then
		if not v_u_206.grounded then
			local v448 = -v_u_206.minVy
			if v448 > 6 then
				local v449 = v_u_201
				local v450 = v448 * v_u_16.landK
				local v451 = v_u_16.landMax
				v449:Impulse(-math.min(v450, v451))
			end
			v_u_206.minVy = 0
		end
	else
		local v452 = v_u_206
		local v453 = v_u_206.minVy
		local v454 = v_u_206.vy
		v452.minVy = math.min(v453, v454)
	end
	v_u_206.grounded = p416.grounded
	local v455 = p416.cam.LookVector
	local v456 = -v455.X
	local v457 = -v455.Z
	local v458 = math.atan2(v456, v457)
	local v459 = v455.Y
	local v460 = math.clamp(v459, -1, 1)
	local v461 = math.asin(v460)
	if v_u_206.lastYaw then
		local v462 = (v458 - v_u_206.lastYaw + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
		local v463 = v461 - v_u_206.lastPitch
		if math.abs(v462) < 1.2 and math.abs(v463) < 1.2 then
			local v464 = v_u_202
			local v465 = v_u_202.value
			local v466 = -v463
			local v467 = -v462
			local v468 = -v462 * 0.5
			v464.value = v465 + Vector3.new(v466, v467, v468) * v_u_16.swayK
		end
	end
	local v469 = v_u_206
	v_u_206.lastYaw = v458
	v469.lastPitch = v461
	local v470 = p416.aiming
	if v470 then
		v470 = v441.aimPos ~= nil
	end
	local v471 = v_u_16.hand + v441.pos + ((not p416.touch or v470) and Vector3.new(0, 0, 0) or v_u_16.touchHand)
	local v472 = Vector3.new(0, 0, 0)
	if v470 then
		v471 = v471 + v441.aimPos
		v472 = v472 + (v441.aimRot or Vector3.new(0, 0, 0)) * 0.017453292519943295
	end
	if v_u_206.block and (v440.blockP and v440.blockR) then
		v471 = v471 + v440.blockP
		v472 = v472 + v440.blockR
	elseif v_u_206.block and v441.block then
		local v473 = v441.block[1]
		local v474 = v419 * 3
		local v475 = math.sin(v474) * 0.004
		v471 = v471 + (v473 + Vector3.new(0, v475, 0))
		local v476 = v441.block[2] * 0.017453292519943295
		local v477 = v419 * 2.3
		local v478 = math.sin(v477) * 0.5 * 0.017453292519943295
		v472 = v472 + (v476 + Vector3.new(0, 0, v478))
	end
	local v479 = 0
	local v480 = 0
	if v_u_206.charge and v441.charge then
		local v481 = (v419 - v_u_206.chargeT0) / v_u_206.chargeTime
		local v482 = math.clamp(v481, 0, 1)
		local v483 = math.clamp(v482, 0, 1)
		local v484 = v483 * v483 * (3 - v483 * 2) * 0.15 + 0.85
		if v441.chargeIn then
			local v485 = (v419 - v_u_206.chargeT0) / v441.chargeIn
			local v486 = math.clamp(v485, 0, 1) - 1
			v484 = v484 * (v486 * 3.6 * v486 * v486 + 1 + v486 * 2.6 * v486)
		end
		v471 = v471 + v441.charge[1] * v484
		v472 = v472 + v441.charge[2] * 0.017453292519943295 * v484
		v479 = v479 + (v482 * 0.0028 + 0.0012)
		if v482 >= 1 and not v_u_206.chargeFull then
			v_u_206.chargeFull = true
			v_u_203:Impulse(Vector3.new(0, 1.5, 1.2))
			local v487 = v_u_206.fxQueue
			table.insert(v487, "headglint")
		end
	end
	local v488 = v419 - (v_u_206.drawHold - 0.16)
	local v489 = not v_u_206.draw
	if v489 then
		if v_u_206.drawHold > 0 then
			v489 = v488 < 0.36
		else
			v489 = false
		end
	end
	if (v_u_206.draw or v489) and (v441.draw or v440.drawP) then
		local v490
		if v_u_206.draw then
			local v491 = (v419 - v_u_206.drawT0) / v_u_206.drawTime
			v490 = math.clamp(v491, 0, 1)
		else
			v490 = 1
		end
		local v492
		if v_u_206.draw then
			local v493 = (v419 - v_u_206.drawT0) / 0.14
			local v494 = math.clamp(v493, 0, 1)
			local v495 = v494 * v494 * (3 - v494 * 2) * 0.7
			local v496 = math.clamp(v490, 0, 1)
			v492 = v495 + v496 * v496 * (3 - v496 * 2) * 0.3
		else
			local v497 = (v488 - 0.16) / 0.2
			local v498 = math.clamp(v497, 0, 1)
			v492 = 1 - v498 * v498 * (3 - v498 * 2)
		end
		if v440.drawP and v440.drawR then
			v471 = v471 + v440.drawP * v492
			v472 = v472 + v440.drawR * v492
		elseif v441.draw then
			v471 = v471 + v441.draw[1] * v492
			v472 = v472 + v441.draw[2] * 0.017453292519943295 * v492
		end
		if v_u_206.draw then
			if v490 >= 1 then
				local v499 = (v419 - v_u_206.drawT0 - v_u_206.drawTime) / 0.5
				v480 = math.clamp(v499, 0.3, 1) * 0.0007
			end
			local v500
			if v440.kind == "Bow" then
				v500 = v441.stock == nil
			else
				v500 = false
			end
			if v500 and (v490 >= 0.5 and not v_u_206.drawHalf) then
				v_u_206.drawHalf = true
				v_u_203:Impulse(Vector3.new(0, -1.1, 0.9))
				v_u_204:Impulse(Vector3.new(-3.4906585, 0, 0))
				local v501 = v_u_206.fxQueue
				table.insert(v501, "sfx:Gun_Cock")
			end
			if v490 >= 1 and not v_u_206.drawFull then
				v_u_206.drawFull = true
				v_u_203:Impulse(Vector3.new(0, -0.8, 0.6))
				v_u_204:Impulse(Vector3.new(-2.268928, 0, 0))
				local v502 = v_u_206.fxQueue
				table.insert(v502, "fullglint")
			end
		end
	end
	if v_u_206.wind and v441.windup then
		local v503 = (v419 - v_u_206.windT0) / v_u_206.windTime
		local v504 = math.clamp(v503, 0, 1)
		local v505 = (v419 - v_u_206.windT0) / 0.12
		local v506 = math.clamp(v505, 0, 1)
		local v507 = v506 * v506 * (3 - v506 * 2) * 0.75
		local v508 = math.clamp(v504, 0, 1)
		local v509 = v507 + v508 * v508 * (3 - v508 * 2) * 0.25
		v471 = v471 + v441.windup[1] * v509
		v472 = v472 + v441.windup[2] * 0.017453292519943295 * v509
		v479 = v479 + (v504 * 0.003 + 0.001)
		if v440.id == "harpoon" and (v504 >= 0.5 and not v_u_206.windHalf) then
			v_u_206.windHalf = true
			v_u_203:Impulse(Vector3.new(0, -0.5, 0.4))
			local v510 = v_u_206.fxQueue
			table.insert(v510, "glint")
			local v511 = v_u_206.fxQueue
			table.insert(v511, "sfx:Crossbow_Crank")
		end
		if v504 >= 1 and not v_u_206.windFull then
			v_u_206.windFull = true
			v_u_203:Impulse(Vector3.new(0, -1.6, 1.2))
			v_u_204:Impulse(Vector3.new(-2.7925267, 0, 0))
			local v512 = v_u_206.fxQueue
			table.insert(v512, "glint")
			local v513 = v_u_206.fxQueue
			local v514 = v440.id == "harpoon" and "sfx:Crossbow_Ready" or (v440.kind == "Bomb" and "sfx:Equip_Item" or "sfx:Knife_Ready")
			table.insert(v513, v514)
		end
	elseif v419 < v_u_206.windHold and v441.windup then
		v471 = v471 + v441.windup[1] * v_u_206.windK
		v472 = v472 + v441.windup[2] * 0.017453292519943295 * v_u_206.windK
	end
	local v515 = 0
	if v_u_206.use and v441.use then
		v471 = v471 + v441.use[1]
		v472 = v472 + v441.use[2] * 0.017453292519943295
		v515 = v419 - v_u_206.useT0 > 0.15 and not (v440.clips and v440.clips.use_loop) and 1 or v515
		if v419 - v_u_206.useT0 > v_u_206.useTime + 0.3 then
			v_u_206.use = false
		end
	end
	local v516 = 0
	if v_u_206.reload then
		local v517 = (v419 - v_u_206.reloadT0) / v_u_206.reloadTime
		if v517 >= 1.15 then
			v_u_206.reload = false
		else
			local v518 = v517 / 0.2
			local v519 = math.clamp(v518, 0, 1)
			local v520 = v519 * v519 * (3 - v519 * 2)
			local v521 = (v517 - 0.78) / 0.22
			local v522 = math.clamp(v521, 0, 1)
			local v523 = v520 * (1 - v522 * v522 * (3 - v522 * 2))
			v471 = v471 + Vector3.new(-0.04, -0.1, 0.02) * v523
			v472 = v472 + Vector3.new(0.4886922, 0.41887903, 0.5934119) * v523
			if v517 > 0.25 and v517 < 0.75 then
				v516 = 1
			end
		end
	end
	if p416.sliding then
		v471 = v471 + v_u_16.slidePos
		v472 = v472 + v_u_16.slideRot * 0.017453292519943295
	end
	local v524 = p416.wall
	if v524 and v524 < v440.wallDist then
		local v525 = v440.wallDist - v524
		local v526 = v440.wallDist - v_u_16.wallMin
		local v527 = v525 / math.max(v526, 0.1)
		local v528 = math.clamp(v527, 0, 1)
		v471 = v471 + v_u_16.wallPos * v528
		local v529 = v440.wallRot * v528
		v472 = v472 + Vector3.new(v529, 0, 0)
	end
	v_u_197.frequency = v_u_206.useOutUntil and v419 < v_u_206.useOutUntil and 3.2 or v_u_16.poseHz
	v_u_198.frequency = v_u_197.frequency
	v_u_197.target = v471
	v_u_198.target = v472
	v_u_197:Update(v418)
	v_u_198:Update(v418)
	local v530 = -v_u_206.vy * v_u_16.airK
	local v531 = -v_u_16.airMax
	local v532 = v_u_16.airMax
	local v533 = math.clamp(v530, v531, v532)
	local v534 = -v_u_206.vy * v_u_16.airTiltK
	local v535 = -v_u_16.airTiltMax
	local v536 = v_u_16.airTiltMax
	local v537 = math.clamp(v534, v535, v536) * 0.017453292519943295
	if p416.grounded then
		v533 = 0
		v537 = 0
	end
	v_u_199.target = v533
	v_u_200.target = v537
	v_u_199:Update(v418)
	v_u_200:Update(v418)
	v_u_201:Update(v418)
	v_u_202:Update(v418)
	local v538 = v_u_202.value
	local v539 = v_u_16.swayMax * 0.017453292519943295
	if v539 < v538.Magnitude then
		v_u_202.value = v538.Unit * v539
	end
	v_u_203:Update(v418)
	v_u_204:Update(v418)
	v_u_205:Update(v418)
	v_u_208.target = v_u_206.hammerTarget
	v_u_208:Update(v418)
	v_u_209.target = v_u_206.frizzenTarget
	v_u_209:Update(v418)
	local v540 = v_u_197.value
	local v541 = v_u_198.value
	local v542 = v419 * v_u_16.idleHz * 2 * 3.141592653589793
	local v543 = v542 * 0.5
	local v544 = math.sin(v543) * v_u_16.idlePos * 0.6
	local v545 = math.sin(v542) * v_u_16.idlePos
	local v546 = v540 + Vector3.new(v544, v545, 0)
	local v547 = v542 + 0.6
	local v548 = math.sin(v547) * v_u_16.idleRot
	local v549 = v542 * 0.5
	local v550 = math.sin(v549) * v_u_16.idleRot * 0.5
	local v551 = v541 + Vector3.new(v548, 0, v550) * 0.017453292519943295
	local v552 = p416.bobAmount
	if v552 > 0 then
		local v553 = p416.bobPhase
		local v554 = math.cos(v553)
		local v555 = math.abs(v554) - 0.64
		local v556 = math.sin(v553) * v_u_16.bobX * v552
		local v557 = -v555 * v_u_16.bobY * v552
		v546 = v546 + Vector3.new(v556, v557, 0)
		local v558 = v555 * v_u_16.bobPitch * v552
		local v559 = math.sin(v553) * v_u_16.bobRoll * v552
		v551 = v551 + Vector3.new(v558, 0, v559) * 0.017453292519943295
	end
	local v560 = v_u_199.value + v_u_201.value * v_u_16.landDist
	local v561 = v546 + Vector3.new(0, v560, 0)
	local v562 = v_u_200.value + v_u_201.value * 0.12
	local v563 = v551 + Vector3.new(v562, 0, 0)
	local v564 = v_u_202.value
	local v565 = v563 + v564
	local v566 = -v564.Y * v_u_16.swayShift
	local v567 = v564.X * v_u_16.swayShift
	local v568 = v561 + Vector3.new(v566, v567, 0) + v_u_203.value
	local v569 = v565 + v_u_204.value
	if v479 > 0 then
		local v570 = v419 * 84
		local v571 = math.sin(v570) * v479
		local v572 = v419 * 71 + 1
		local v573 = math.sin(v572) * v479
		v568 = v568 + Vector3.new(v571, v573, 0)
	end
	if v480 > 0 then
		local v574 = v419 * 33
		local v575 = math.sin(v574) * v480
		local v576 = v419 * 27 + 1
		local v577 = math.sin(v576) * v480
		v568 = v568 + Vector3.new(v575, v577, 0)
	end
	if p416.sliding then
		local v578 = v_u_16.slideShake
		local v579 = v419 * 53
		local v580 = math.sin(v579) * v578
		local v581 = v419 * 71 + 2
		local v582 = math.sin(v581) * v578
		v568 = v568 + Vector3.new(v580, v582, 0)
		local v583 = v419 * 39
		local v584 = math.sin(v583) * 1.6 * 0.017453292519943295
		v569 = v569 + Vector3.new(0, 0, v584)
	end
	if v516 > 0 then
		local v585 = v419 * 42
		local v586 = math.sin(v585) * 5
		local v587 = v419 * 33 + 1
		local v588 = math.sin(v587) * 7
		v569 = v569 + Vector3.new(v586, 0, v588) * 0.017453292519943295
		local v589 = v419 * 21
		local v590 = math.sin(v589)
		local v591 = math.abs(v590) * 0.012
		v568 = v568 + Vector3.new(0, v591, 0)
	end
	if v515 > 0 then
		local v592 = (v419 - v_u_206.useT0) * 9
		local v593 = math.sin(v592)
		local v594 = math.abs(v593)
		local v595 = v594 * 0.022
		local v596 = -v594 * 0.012
		v568 = v568 + Vector3.new(0, v595, v596)
		local v597 = v594 * 9
		v569 = v569 + Vector3.new(v597, 0, 0) * 0.017453292519943295
	end
	if v_u_206.action then
		local v598 = v_u_22[v_u_206.action]
		local v599 = (v419 - v_u_206.actT0) / v_u_206.actDur
		if v598 and v599 < 1 then
			local v600, v601 = v_u_415(v598.keys, v599)
			if v598.mirror and v_u_206.actMirror < 0 then
				local v602 = -v600.X
				local v603 = v600.Y
				local v604 = v600.Z
				v600 = Vector3.new(v602, v603, v604)
				local v605 = v601.X
				local v606 = -v601.Y
				local v607 = -v601.Z
				v601 = Vector3.new(v605, v606, v607)
			end
			v568 = v568 + v600
			v569 = v569 + v601 * 0.017453292519943295
		else
			v_u_206.action = nil
		end
	end
	local v608 = v_u_205.value
	local v609 = v608 * v_u_16.equipDrop
	local v610 = v568 + Vector3.new(0, v609, 0)
	local v611 = -v608 * v_u_16.equipTilt * 0.017453292519943295
	local v612 = v569 + Vector3.new(v611, 0, 0)
	if v_u_206.dropAt then
		local v613 = (v419 - v_u_206.dropAt) / v_u_16.dropTime
		local v614 = math.clamp(v613, 0, 1)
		local v615 = v614 * v614
		local v616 = -v_u_16.equipDrop * v615
		v610 = v610 + Vector3.new(0, v616, 0)
		local v617 = -v_u_16.equipTilt * 0.017453292519943295 * v615
		v612 = v612 + Vector3.new(v617, 0, 0)
	end
	if v_u_206.hiddenUntil > 0 and v_u_206.hiddenUntil <= v419 then
		v_u_206.hiddenUntil = 0
		v_u_206.vanishAt = nil
		if v_u_206.action == "throw" or v_u_206.action == "place" then
			v_u_206.action = nil
		end
		if v440.drawFrom and (v440.clips and (v440.clips.redraw or v440.clips.draw)) then
			local v618 = v_u_206
			v_u_206.clip = nil
			v618.clipName = nil
			v_u_206.pendingDraw = v440.clips.redraw and "redraw" or "draw"
		else
			local v619 = v_u_205
			local v620 = v_u_205
			v_u_205.value = -1
			v619.velocity = 0
			v620.target = 0
		end
	end
	v_u_206.frame = nil
	v_u_206.wallPush = 0
	local v621 = v_u_197.value
	local v622 = v_u_198.value
	local v623 = v610 - v621
	local v624 = v612 - v622
	local v625 = v_u_206
	v_u_206.layerPos = v623
	v625.layerRot = v624
	local v626 = CFrame.new(v621) * CFrame.fromEulerAnglesYXZ(v622.X, v622.Y, v622.Z) * v440.styleRot
	v_u_206.restFrame = v626
	if v_u_206.pendingDraw then
		local v627 = v_u_206.pendingDraw
		v_u_206.pendingDraw = nil
		if v440.drawFrom then
			v_u_267(v627, nil, v_u_10.StartFrame(v440.drawFrom, v626))
			v_u_206.clipFromVel = {
				["pos"] = Vector3.new(0, 3.5, 0),
				["tip"] = Vector3.new(0, 0, 0),
				["edge"] = Vector3.new(0, 0, 0)
			}
		end
	end
	if v_u_206.refreshFF then
		if v_u_206.clip and (v419 - v_u_206.clipT0) / v_u_206.clipScale < v_u_206.refreshFF then
			local v628 = v_u_206
			v628.clipT0 = v628.clipT0 - 4 * v418
		else
			v_u_206.refreshFF = nil
			v_u_206.refreshGlintAt = v419 + 0.05
		end
	end
	if v_u_206.refreshGlintAt and v_u_206.refreshGlintAt <= v419 then
		v_u_206.refreshGlintAt = nil
		local v629 = v_u_206.fxQueue
		table.insert(v629, "headglint")
		v_u_203:Impulse(Vector3.new(0, 0.6, 0))
	end
	local v630 = v_u_206.clip
	v_u_206.rodV = 0
	local v631
	if v630 then
		local v632 = v419 - v_u_206.clipT0
		if v630.rod then
			v_u_206.rodV = v_u_78(v630.rod, v632 / v_u_206.clipScale)
		end
		if v630.string then
			v_u_206.stringV = v_u_78(v630.string, v632 / v_u_206.clipScale)
		end
		if v630.strip then
			v_u_206.stripV = v_u_78(v630.strip, v632 / v_u_206.clipScale)
		end
		local v633 = v630.fx
		if v633 then
			v631 = v626
			while v_u_206.clipFx <= #v633 and v633[v_u_206.clipFx][1] * v_u_206.clipScale <= v632 do
				local v634 = v633[v_u_206.clipFx]
				local v635 = v634[2]
				if v635 == "bolt" then
					local v636 = v_u_206
					v_u_206.boltIn = true
					v636.boltT0 = v419
				elseif v635 == "half" then
					v_u_206.hammerTarget = 0.5
				elseif v635 == "prime" then
					v_u_206.frizzenTarget = 0
				elseif v635 == "nock" then
					local v637 = v_u_206
					v_u_206.nocked = true
					v637.nockT0 = v419
				elseif v635 == "click" then
					v_u_206.hammerTarget = 0
				end
				local v638 = v_u_206.fxQueue
				table.insert(v638, v635)
				local v639 = v634[3]
				if type(v639) == "string" then
					local v640 = v_u_206.fxQueue
					local v641 = v634[3]
					local v642 = v634[4]
					local v643 = "sfx:" .. v641 .. (type(v642) ~= "number" and "" or "@" .. v634[4])
					table.insert(v640, v643)
				end
				local v644 = v_u_206
				v644.clipFx = v644.clipFx + 1
			end
		else
			v631 = v626
		end
		local v645 = v_u_10.Eval(v630, v_u_206.clipFrom, v632, v_u_206.clipScale, v626, v_u_206.clipFromVel)
		local v646 = v630.release * v_u_206.clipScale <= v632
		if v646 and (not v_u_206.dropAt and (v_u_206.use and (v_u_206.clipName == "use_in" or v_u_206.clipName == "use_loop"))) and v_u_267("use_loop", nil, v645) or (v646 and (not v_u_206.dropAt and (v_u_206.parry and (v_u_206.clipName == "parry_in" or v_u_206.clipName == "parry_hold"))) and v_u_267("parry_hold", nil, v645) or not (v646 or v_u_206.dropAt)) then
			v631 = v645
		else
			v_u_207:Snap(v645.Position - v626.Position)
			v_u_207.target = Vector3.new(0, 0, 0)
			local v647, v648 = (v645.Rotation * v626.Rotation:Inverse()):ToAxisAngle()
			v_u_210:Snap(v647 * v648)
			v_u_210.target = Vector3.new(0, 0, 0)
			if not v_u_206.dropAt then
				local v649 = v_u_10.Eval
				local v650 = v_u_206.clipFrom
				local v651 = v632 - 0.004166666666666667
				local v652 = v649(v630, v650, math.max(0, v651), v_u_206.clipScale, v626, v_u_206.clipFromVel)
				v_u_207.velocity = (v645.Position - v652.Position) / 0.004166666666666667 + (v630.vel or Vector3.new(0, 0, 0))
				local v653, v654 = (v645.Rotation * v652.Rotation:Inverse()):ToAxisAngle()
				local v655 = v_u_210
				local v656 = v654 / 0.004166666666666667
				v655.velocity = v653 * math.min(v656, 20)
			end
			local v657 = v_u_206
			v_u_206.clip = nil
			v657.clipName = nil
		end
	else
		v631 = v626
	end
	if not v_u_206.clip then
		v_u_207:Update(v418)
		v_u_210:Update(v418)
		local v658 = v_u_207.value
		local v659 = v_u_210.value
		if v658.Magnitude > 0.00001 or v659.Magnitude > 0.00001 then
			local v660
			if v659.Magnitude > 1e-6 then
				v660 = CFrame.fromAxisAngle(v659.Unit, v659.Magnitude)
			else
				v660 = CFrame.identity
			end
			v631 = CFrame.new(v626.Position + v658) * v660 * v626.Rotation
		end
	end
	local v661 = v_u_206.lastFrame
	if v661 and v418 > 0 then
		local v662 = v_u_206
		local v663 = {}
		local v664 = (v631.Position - v661.Position) / v418
		if v664.Magnitude > 25 then
			v664 = v664.Unit * 25
		end
		v663.pos = v664
		local v665 = (v631.UpVector - v661.UpVector) / v418
		if v665.Magnitude > 40 then
			v665 = v665.Unit * 40
		end
		v663.tip = v665
		local v666 = (v631.LookVector - v661.LookVector) / v418
		if v666.Magnitude > 40 then
			v666 = v666.Unit * 40
		end
		v663.edge = v666
		v662.rawVel = v663
	end
	v_u_206.lastFrame = v631
	v_u_206.lastFrameT = v419
	if v440.id == "bolas" then
		if (v_u_206.clipName == "draw" or v_u_206.clipName == "redraw") and v_u_206.spinT0 ~= v_u_206.clipT0 then
			v_u_206.spinT0 = v_u_206.clipT0
		end
		if v_u_206.clipName == "throw" then
			v_u_206.spinA = (v_u_206.spinA + v418 * 2 * 3.141592653589793 * 4) % 6.283185307179586
		else
			local v667 = (v419 - v_u_206.spinT0) / 0.7
			v_u_206.spinA = 12.566370614359172 * (1 - (1 - math.clamp(v667, 0, 1)) ^ 3)
		end
		v631 = v631 * CFrame.Angles(0, v_u_206.spinA, 0)
	end
	local v668 = CFrame.new(v631.Position + v623) * CFrame.fromEulerAnglesYXZ(v624.X, v624.Y, v624.Z) * v631.Rotation
	local v669 = p416.wall
	if v669 then
		local v670 = 0
		for _, v671 in v440.corners do
			local v672 = -v668:PointToWorldSpace(v671).Z
			v670 = math.max(v670, v672)
		end
		local v673 = v669 - 0.12
		if v673 < v670 then
			local v674 = v_u_206
			local v675 = v670 - v673
			local v676 = -v668.Position.Z - 0.28
			local v677 = math.max(0, v676)
			v674.wallPush = math.min(v675, v677)
			local v678 = v_u_206.wallPush
			v668 = v668 + Vector3.new(0, 0, v678)
		end
	end
	v_u_206.frame = v668
	if v_u_206.leftVanishAt and v_u_206.leftVanishAt <= v419 then
		local v679 = v_u_206
		local v680 = v_u_206
		v_u_206.leftOut = true
		v679.leftVanishAt = nil
		v680.leftOutAt = v419
	end
	if p416.offHandOut == true then
		v_u_206.leftSeenOut = true
		if not (v_u_206.leftOut or v_u_206.leftVanishAt) then
			local v681 = v_u_206
			v_u_206.leftOut = true
			v681.leftOutAt = v419
		end
	elseif p416.offHandOut == false and (v_u_206.leftOut and (v_u_206.leftSeenOut or v419 - v_u_206.leftOutAt > 1)) then
		local v682 = v_u_206
		v_u_206.leftOut = false
		v682.leftSeenOut = false
		v_u_206.leftCatchT = v419
	end
	if v440.leftFist and v_u_206.leftOut then
		v_u_206.leftFrame = nil
	elseif v440.leftFist then
		local v683 = v_u_206.clip
		if v683 and v683.left then
			local v684 = v683.leftClip
			if not v684 then
				v684 = {
					["keys"] = v683.left,
					["contact"] = v683.contact,
					["release"] = v683.release,
					["eyeRoll"] = v683.eyeRoll
				}
				v683.leftClip = v684
			end
			v626 = v_u_10.Eval(v684, v_u_206.leftFrom, v419 - v_u_206.clipT0, v_u_206.clipScale, v626, v_u_206.leftFromVel)
		end
		local v685 = v_u_206.leftLast
		if v685 and v418 > 0 then
			local v686 = v_u_206
			local v687 = {}
			local v688 = (v626.Position - v685.Position) / v418
			if v688.Magnitude > 25 then
				v688 = v688.Unit * 25
			end
			v687.pos = v688
			local v689 = (v626.UpVector - v685.UpVector) / v418
			if v689.Magnitude > 40 then
				v689 = v689.Unit * 40
			end
			v687.tip = v689
			local v690 = (v626.LookVector - v685.LookVector) / v418
			if v690.Magnitude > 40 then
				v690 = v690.Unit * 40
			end
			v687.edge = v690
			v686.leftVel = v687
		end
		v_u_206.leftLast = v626
		local v691 = (v419 - v_u_206.leftCatchT) / 0.3
		if v691 >= 0 and v691 < 1 then
			local v692 = v691 - 1
			local v693 = 1 - (2.70158 * v692 * v692 * v692 + 1 + 1.70158 * v692 * v692)
			v626 = CFrame.new(v626.Position + Vector3.new(0.06, -0.42, 0.04) * v693) * CFrame.fromEulerAnglesYXZ(-0.8726646259971648 * v693, 0, 0.5235987755982988 * v693) * v626.Rotation
		end
		local v694, v695, v696, v697, v698, v699, v700, v701, v702, v703, v704, v705 = v626:GetComponents()
		local v706 = CFrame.new(-v694, v695, v696, v697, -v698, -v699, -v700, v701, v702, -v703, v704, v705)
		local v707 = v_u_206
		local v708 = CFrame.new
		local v709 = v706.Position + v623
		local v710 = v_u_206.wallPush
		v707.leftFrame = v708(v709 + Vector3.new(0, 0, v710)) * CFrame.fromEulerAnglesYXZ(v624.X, v624.Y, v624.Z) * v706.Rotation
	else
		v_u_206.leftFrame = nil
	end
	local v711
	if v_u_206.vanishAt then
		if v_u_206.vanishAt <= v419 then
			v711 = v419 < v_u_206.hiddenUntil
		else
			v711 = false
		end
	elseif v419 < v_u_206.hiddenUntil and v_u_206.action ~= "throw" then
		v711 = v_u_206.action ~= "place"
	else
		v711 = false
	end
	if v711 then
		return v610, v612, nil
	end
	if p416.charges and p416.charges <= 0 then
		v_u_206.spent = true
		if not v_u_206.vanishAt or v419 >= v_u_206.vanishAt then
			return v610, v612, nil
		end
	elseif v_u_206.spent then
		v_u_206.spent = false
		if v440.drawFrom and (v440.clips and (v440.clips.redraw or v440.clips.draw)) then
			v_u_206.pendingDraw = v440.clips.redraw and "redraw" or "draw"
		else
			local v712 = v_u_205
			local v713 = v_u_205
			v_u_205.value = -1
			v712.velocity = 0
			v713.target = 0
		end
	end
	return v610, v612, v440
end
local v_u_715 = nil
local v_u_716 = RaycastParams.new()
v_u_716.FilterType = Enum.RaycastFilterType.Exclude
v_u_716.RespectCanCollide = true
local v_u_717 = nil
local v_u_718 = {}
local v_u_719 = {}
local v_u_720 = {}
local v_u_721 = {}
local v_u_722 = {}
local v_u_723 = {}
local function v_u_778(p724, p725, p726, p727) -- name: drawBlade
	-- upvalues: (copy) v_u_11, (copy) v_u_206, (copy) v_u_16, (copy) v_u_10, (copy) v_u_721, (copy) v_u_722, (copy) v_u_723, (copy) v_u_718, (copy) v_u_719, (copy) v_u_720
	v_u_11.Follow(p725)
	local v728 = v_u_206.frame
	if v_u_206.spark then
		v_u_206.spark = false
		if v728 then
			local v729 = v_u_11.Spark
			local v730 = v728.X
			local v731 = v728.Y
			local v732 = v728.Z * p726
			v729(p724, p725, Vector3.new(v730, v731, v732) + v728.UpVector * (p727.bladeLen * 0.55))
		end
	end
	local v733 = v_u_206.clip
	local v734
	if v733 then
		v734 = v733.smear
	else
		v734 = nil
	end
	if not (v733 and v734) then
		v_u_11.Hide()
		return
	end
	local v735 = v_u_206.clipScale
	local v736 = v_u_206.now - v_u_206.clipT0
	local v737 = v734[1] * v735
	local v738 = v734[2] * v735
	local v739 = v_u_16.smearLen * v735
	local v740 = math.min(v736, v738)
	local v741 = v736 - v739
	local v742 = math.max(v737, v741)
	if v740 - v742 < 0.004 then
		v_u_11.Hide()
		return
	end
	local v743
	if v738 < v736 then
		local v744 = 1 - (v736 - v738) / v739
		v743 = math.clamp(v744, 0, 1)
	else
		v743 = 1
	end
	local v745 = v_u_11.SEGMENTS
	local v746 = v_u_206.layerPos
	local v747 = v_u_206.wallPush
	local v748 = v746 + Vector3.new(0, 0, v747)
	local v749 = v_u_206.layerRot
	local v750 = CFrame.fromEulerAnglesYXZ(v749.X, v749.Y, v749.Z)
	local v751 = v_u_16.smearAlong[p727.kind]
	for v752 = 0, v745 do
		local v753 = v_u_10.Eval(v733, v_u_206.clipFrom, v742 + (v740 - v742) * v752 / v745, v735, v_u_206.restFrame, v_u_206.clipFromVel)
		local v754 = v753.Position + v748
		local v755 = v_u_721
		local v756 = v752 + 1
		local v757 = v754.X
		local v758 = v754.Y
		local v759 = v754.Z * p726
		v755[v756] = Vector3.new(v757, v758, v759)
		if v751 then
			local v760 = v_u_721
			local v761 = v752 + 1
			v760[v761] = v760[v761] + v750 * v753.UpVector * (p727.bladeLen * v751.root)
			v_u_722[v752 + 1] = v750 * v753.LookVector
		else
			v_u_722[v752 + 1] = v750 * v753.UpVector
		end
	end
	for v762, v763 in v_u_16.smearItem[p727.id] or (v_u_16.smear[p727.kind] or v_u_16.smear.Sword) do
		if v_u_11.LAYERS < v762 then
			break
		end
		local v764 = p727.bladeLen * v763.at
		local v765 = p727.bladeLen * v763.width * (v733.smearWidth or 1)
		for v766 = 1, v745 + 1 do
			v_u_723[v766] = v_u_721[v766] + v_u_722[v766] * v764
		end
		for v767 = 1, v745 + 1 do
			local v768 = v_u_723
			local v769 = v745 + 1
			local v770 = v767 + 1
			local v771 = v768[math.min(v769, v770)]
			local v772 = v_u_723
			local v773 = v767 - 1
			local v774 = v771 - v772[math.max(1, v773)]
			local v775 = v_u_722[v767]
			local v776 = v774 - v775 * v774:Dot(v775)
			if v776.Magnitude < 0.00001 then
				v776 = v775:Cross(Vector3.new(0, 0, 1))
			end
			v_u_718[v767] = CFrame.fromMatrix(v_u_723[v767], v776.Unit, v775)
			local v777 = (v767 - 1) / v745
			v_u_719[v767] = v765 * (0.3 + 0.7 * v777)
			v_u_720[v767] = 1 - (1 - v763.alpha) * v777 ^ 1.4 * v743
		end
		v_u_11.Draw(p724, p725, v762, v_u_718, v_u_719, v_u_720, v763.color)
	end
end
local v_u_779 = {}
local v_u_780 = nil
local function v_u_798(p781, p782) -- name: arrowFor
	-- upvalues: (copy) v_u_779, (copy) v_u_2, (ref) v_u_25
	local v783 = p781 .. ":" .. tostring(p782 or 0.36)
	local v784 = v_u_779[v783]
	if v784 then
		return v784
	end
	local v785 = v_u_2:FindFirstChild("Assets")
	if v785 then
		v785 = v785:FindFirstChild("VFX")
	end
	if v785 then
		v785 = v785:FindFirstChild("Projectiles")
	end
	if p781 == "ViewArrow" and v_u_25 then
		v785 = v_u_25:FindFirstChild("Arrow")
	elseif v785 then
		v785 = v785:FindFirstChild(p781) or v785:FindFirstChild("Arrow")
	end
	if not (v785 and v785:IsA("Model")) then
		return nil
	end
	local v786 = v785:Clone()
	for _, v787 in v786:GetDescendants() do
		if v787:IsA("BasePart") then
			v787.Anchored = true
			v787.CanCollide = false
			v787.CanQuery = false
			v787.CanTouch = false
			v787.CastShadow = false
			if p781 ~= "Bolt" then
				continue
			end
			local v788 = v787.Color.R
			local v789 = v787.Color.G
			local v790 = v787.Color.B
			if math.min(v788, v789, v790) <= 0.5 then
				continue
			end
			v787.Color = Color3.fromRGB(120, 124, 130)
			if not v787:IsA("MeshPart") then
				continue
			end
			v787.TextureID = ""
		elseif v787:IsA("ParticleEmitter") then
			v787.LockedToPart = true
		elseif v787:IsA("Trail") or (v787:IsA("Beam") or v787:IsA("Light")) then
			v787.Enabled = false
		else
			if not (v787:IsA("Script") or (v787:IsA("LocalScript") or v787:IsA("Sound"))) then
				continue
			end
			v787:Destroy()
		end
	end
	local _, v791 = v786:GetBoundingBox()
	local v792 = v791.X
	local v793 = v791.Y
	local v794 = v791.Z
	local v795 = (p782 or 0.36) / math.max(v792, v793, v794, 0.05)
	v786:ScaleTo((math.clamp(v795, 0.005, 1)))
	v786.Name = "TribesViewArrow_" .. p781
	local v796 = v786:GetBoundingBox()
	local v797 = {
		["model"] = v786,
		["centre"] = v786:GetPivot():ToObjectSpace(v796)
	}
	v_u_779[v783] = v797
	return v797
end
local function v_u_809(p799, p800, p801) -- name: drawBolt
	-- upvalues: (copy) v_u_206, (copy) v_u_798
	if p801.kind ~= "Crossbow" or not (v_u_206.boltIn and (v_u_206.frame and p801.muzzle)) then
		return nil
	end
	local v802 = v_u_798("Bolt", 0.347)
	if not v802 then
		return nil
	end
	local v803 = v_u_206.frame
	local v804 = v803.LookVector
	local v805 = p800:PointToObjectSpace(p801.muzzle.WorldPosition)
	local v806 = (v_u_206.now - v_u_206.boltT0) / 0.1
	local v807 = math.clamp(v806, 0, 1)
	local v808 = v805 - v804 * (0.1735 + 0.24 * (1 - v807 * v807 * (3 - v807 * 2)))
	v802.model:PivotTo(p800 * (CFrame.lookAt(v808, v808 + v804, v803.UpVector) * v802.centre:Inverse()))
	if v802.model.Parent ~= p799 then
		v802.model.Parent = p799
	end
	return v802.model
end
local v_u_810 = {
	["thick"] = 0.0035,
	["color"] = nil,
	["ring"] = 0.02,
	["ringHz"] = 18,
	["ringTime"] = 0.15,
	["color"] = Color3.fromRGB(196, 180, 140)
}
local v_u_811 = {}
local function v_u_875(p812, p813, p814, p815) -- name: drawArrow
	-- upvalues: (copy) v_u_206, (copy) v_u_798, (ref) v_u_25, (copy) v_u_809, (ref) v_u_780, (copy) v_u_811, (copy) v_u_810
	local v816 = p815.bow
	local v817 = p815.kind == "Bow" and p815.cfg.stock ~= nil and v_u_206.nocked
	if v817 then
		v817 = v_u_206.frame ~= nil
	end
	local v818
	if v817 then
		v818 = v_u_798(v_u_25 and v_u_25:FindFirstChild("Arrow") and "ViewArrow" or v_u_206.arrowKind, 0.36)
	else
		v818 = nil
	end
	local v819
	if v818 then
		v819 = v818.model
	else
		v819 = v_u_809(p812, p813, p815)
	end
	if v819 ~= v_u_780 then
		if v_u_780 then
			v_u_780.Parent = nil
		end
		v_u_780 = v819
	end
	local v820 = v_u_206.frame
	if v820 then
		local v821 = CFrame.new(v820.X, v820.Y, v820.Z * p814) * v820.Rotation
		local v822 = (v_u_206.now - v_u_206.drawT0) / v_u_206.drawTime
		local v823 = math.clamp(v822, 0, 1)
		local v824 = v823 * v823 * (3 - v823 * 2)
		local v825 = nil
		if v816 then
			if v_u_206.draw then
				local v826 = v816.nock
				local v827 = 0.12 * v824
				v825 = v826 + Vector3.new(0, 0, v827)
			else
				local v828 = v_u_206.now - v_u_206.drawHold + 0.16
				local v829
				if v828 >= 0 and v828 < v_u_810.ringTime then
					local v830 = v_u_810.ring
					local v831 = v828 * v_u_810.ringHz * 2 * 3.141592653589793
					v829 = v830 * math.sin(v831) * (1 - v828 / v_u_810.ringTime)
				else
					v829 = 0
				end
				local v832 = v816.brace
				local v833 = v829 * 0.3
				v825 = v832 + Vector3.new(v829, 0, v833)
			end
			local v834 = v821:PointToWorldSpace(v825)
			for v835, v836 in { v816.top, v816.bottom } do
				local v837 = v821:PointToWorldSpace(v836)
				local v838 = v_u_811[v835]
				if not v838 then
					v838 = Instance.new("Part")
					v838.Name = "TribesViewString"
					v838.Anchored = true
					v838.CanCollide = false
					v838.CanQuery = false
					v838.CanTouch = false
					v838.CastShadow = false
					v838.Material = Enum.Material.SmoothPlastic
					v838.Color = v_u_810.color
					local v839 = v_u_810.thick
					local v840 = v_u_810.thick
					v838.Size = Vector3.new(v839, v840, 0.1)
					v_u_811[v835] = v838
				end
				local v841 = (v834 - v837).Magnitude
				local v842 = v_u_810.thick
				local v843 = v_u_810.thick
				local v844 = math.max(v841, 0.001)
				v838.Size = Vector3.new(v842, v843, v844)
				v838.CFrame = p813 * CFrame.lookAt((v837 + v834) * 0.5, v834)
				if v838.Parent == p812 then
					continue
				end
				v838.Parent = p812
			end
		elseif p815.xbow then
			local v845 = p815.xbow
			local v846 = v_u_206.stringV
			local v847 = math.clamp(v846, 0, 1)
			local v848 = v_u_206.now - v_u_206.stringT0
			local v849 = v845.brace - v845.nut
			local v850 = v849:Cross(v845.right - v845.left)
			local v851 = v850.Magnitude <= 1e-6 and Vector3.new(0, 1, 0) or v850.Unit
			local v852
			if v848 >= 0 and v848 < 0.15 then
				local v853 = v848 * 18 * 2 * 3.141592653589793
				v852 = math.cos(v853) * 0.012 * (1 - v848 / 0.15)
			else
				v852 = 0
			end
			local v854 = v821:PointToWorldSpace(v845.nut + v849 * v847 + v851 * v852)
			for v855, v856 in { v845.left, v845.right } do
				local v857 = v821:PointToWorldSpace(v856)
				local v858 = v_u_811[v855]
				if not v858 then
					v858 = Instance.new("Part")
					v858.Name = "TribesViewString"
					v858.Anchored = true
					v858.CanCollide = false
					v858.CanQuery = false
					v858.CanTouch = false
					v858.CastShadow = false
					v858.Material = Enum.Material.SmoothPlastic
					v858.Color = v_u_810.color
					local v859 = v_u_810.thick
					local v860 = v_u_810.thick
					v858.Size = Vector3.new(v859, v860, 0.1)
					v_u_811[v855] = v858
				end
				local v861 = (v854 - v857).Magnitude
				local v862 = v_u_810.thick * 1.5
				local v863 = math.max(v861, 0.001)
				v858.Size = Vector3.new(v862, v862, v863)
				v858.CFrame = p813 * CFrame.lookAt((v857 + v854) * 0.5, v854)
				if v858.Parent == p812 then
					continue
				end
				v858.Parent = p812
			end
		else
			for _, v864 in v_u_811 do
				v864.Parent = nil
			end
		end
		if v818 and v819 then
			local v865 = (v_u_206.now - v_u_206.nockT0) / 0.1
			local v866 = math.clamp(v865, 0, 1)
			local v867 = 1 - v866 * v866 * (3 - v866 * 2)
			local v868, v869
			if v816 and v825 then
				local v870 = -0.07 * v867
				v868 = v821:PointToWorldSpace(v825 + Vector3.new(0, v870, 0))
				v869 = (v821:PointToWorldSpace(v816.rest) - v868).Unit
			else
				local v871 = p815.brace - 0.005 + 0.12 * v824
				local v872 = -0.07 * v867
				v868 = v821 * Vector3.new(-0.012, v872, v871)
				v869 = v820.LookVector
			end
			v_u_206.arrowTip = v868 + v869 * 0.36
			if v818.centre.Position.Z < 0 and (v_u_25 and v_u_25:FindFirstChild("Arrow")) then
				v819:PivotTo(p813 * CFrame.lookAt(v868, v868 + v869, v820.UpVector))
			else
				local v873 = v868 + v869 * 0.18
				v819:PivotTo(p813 * (CFrame.lookAt(v873, v873 + v869, v820.UpVector) * v818.centre:Inverse()))
			end
			if v819.Parent ~= p812 then
				v819.Parent = p812
			end
		end
	else
		for _, v874 in v_u_811 do
			v874.Parent = nil
		end
		return
	end
end
local v_u_876 = {
	["fire_bomb"] = true
}
local function v_u_887(p877, p878, p879) -- name: itemPoint
	-- upvalues: (copy) v_u_206
	local v880 = v_u_206.frame or CFrame.identity
	local v881
	if p879 == "tip" then
		v881 = p878.tipAtt or p878.muzzle
	else
		v881 = p878.muzzle
	end
	local v882
	if p878.gripAtt then
		v882 = p878.gripAtt.WorldPosition
	else
		v882 = p878.model:GetPivot().Position
	end
	local v883
	if v881 then
		v883 = v881.WorldPosition
	else
		v883 = v882
	end
	local v884 = p877:PointToObjectSpace(v883)
	local v885
	if p878.cfg.act == "gun" or p879 == "barrel" then
		v885 = v880.LookVector
	else
		local v886 = p877:PointToObjectSpace(v882)
		if (v884 - v886).Magnitude > 0.001 then
			v885 = (v884 - v886).Unit
		else
			v885 = v880.LookVector
		end
	end
	return CFrame.lookAt(v884, v884 + v885)
end
local v_u_888 = {
	["Spear"] = true,
	["Gauntlets"] = true,
	["Hatchets"] = true
}
local function v_u_942(p_u_889, p_u_890) -- name: drawStreak
	-- upvalues: (copy) v_u_206, (copy) v_u_888, (copy) v_u_13, (copy) v_u_10
	local v_u_891 = v_u_206.clip
	local v892
	if v_u_891 then
		v892 = v_u_891.smear
	else
		v892 = nil
	end
	if v_u_888[p_u_890.kind] and (v_u_891 and (v892 and p_u_890.tipCanon)) then
		local v_u_893 = v_u_206.clipScale
		local v894 = v_u_206.now - v_u_206.clipT0
		if v894 < v892[1] * v_u_893 or v892[2] * v_u_893 + 0.035 < v894 then
			v_u_13.Streak(nil, nil)
		else
			local v895 = v_u_206.layerPos
			local v896 = v_u_206.wallPush
			local v_u_897 = v895 + Vector3.new(0, 0, v896)
			local v898 = v_u_206.layerRot
			local v_u_899 = CFrame.fromEulerAnglesYXZ(v898.X, v898.Y, v898.Z)
			local v_u_900 = v_u_891.leftClip
			local v_u_901
			if v_u_891.smearLeft == true and p_u_890.leftFist ~= nil then
				v_u_901 = v_u_900 ~= nil
			else
				v_u_901 = false
			end
			local function v931(p902) -- name: tipAt
				-- upvalues: (copy) v_u_901, (ref) v_u_10, (copy) v_u_900, (ref) v_u_206, (copy) v_u_893, (copy) v_u_897, (copy) p_u_890, (copy) p_u_889, (copy) v_u_899, (copy) v_u_891
				if not v_u_901 then
					local v903 = v_u_10.Eval(v_u_891, v_u_206.clipFrom, p902, v_u_893, v_u_206.restFrame, v_u_206.clipFromVel)
					local v904 = v903.Position + v_u_897
					local v905 = v904.X
					local v906 = v904.Y
					local v907 = v904.Z * p_u_889
					return Vector3.new(v905, v906, v907) + (v_u_899 * v903.Rotation):VectorToWorldSpace(p_u_890.tipCanon)
				end
				local v908, v909, v910, v911, v912, v913, v914, v915, v916, v917, v918, v919 = v_u_10.Eval(v_u_900, v_u_206.leftFrom, p902, v_u_893, v_u_206.restFrame, v_u_206.leftFromVel):GetComponents()
				local v920 = CFrame.new(-v908, v909, v910, v911, -v912, -v913, -v914, v915, v916, -v917, v918, v919)
				local v921 = v920.Position + v_u_897
				local v922 = p_u_890.tipCanon
				local v923 = v921.X
				local v924 = v921.Y
				local v925 = v921.Z * p_u_889
				local v926 = Vector3.new(v923, v924, v925)
				local v927 = v_u_899 * v920.Rotation
				local v928 = -v922.X
				local v929 = v922.Y
				local v930 = v922.Z
				return v926 + v927:VectorToWorldSpace((Vector3.new(v928, v929, v930)))
			end
			local v932 = v892[2] * v_u_893
			local v933 = math.min(v894, v932)
			local v934 = v892[1] * v_u_893
			local v935 = v894 - 0.035
			local v936 = math.max(v934, v935)
			local v937 = v_u_13.Streak
			local v938 = v931(v936)
			local v939 = v931(v933)
			local v940 = v892[2] * v_u_893 >= v894 and 1 or 1 - (v894 - v892[2] * v_u_893) / 0.035
			local v941
			if p_u_890.kind == "Gauntlets" then
				v941 = p_u_890.cfg.len * 0.2
			elseif p_u_890.kind == "Hatchets" then
				v941 = p_u_890.cfg.len * 0.45
			else
				v941 = nil
			end
			v937(v938, v939, v940, v941)
		end
	else
		v_u_13.Streak(nil, nil)
		return
	end
end
local function v_u_981(p943, p944, p945) -- name: viewEffects
	-- upvalues: (copy) v_u_13, (copy) v_u_206, (copy) v_u_887, (copy) v_u_16, (ref) v_u_780, (copy) v_u_9, (copy) v_u_876
	v_u_13.Follow(p943, p944)
	local v946 = v_u_206.fxQueue
	if #v946 > 0 then
		for _, v947 in v946 do
			if v947 == "muzzle" then
				v_u_13.Play("muzzle", v_u_887(p944, p945, "barrel"), {
					["style"] = p945.kind == "Blunderbuss" and "blunderbuss" or (p945.kind == "Pistol" and "pistol" or "musket")
				})
			elseif v947 == "pan" then
				local v948 = v_u_206.frame or CFrame.identity
				local v949
				if p945.gripAtt then
					v949 = p944:PointToObjectSpace(p945.gripAtt.WorldPosition)
				else
					v949 = v948.Position
				end
				local v950
				if p945.pan then
					v950 = p944:PointToObjectSpace(p945.pan.WorldPosition)
				else
					v950 = v949 + v948.UpVector * 0.035 + v948.LookVector * 0.05
				end
				v_u_13.Play("pan", CFrame.lookAt(v950, v950 + v948.UpVector))
			elseif v947 == "headglint" or v947 == "rimspark" then
				local v951 = v_u_206.frame or CFrame.identity
				local v952
				if p945.gripAtt then
					v952 = p944:PointToObjectSpace(p945.gripAtt.WorldPosition)
				else
					v952 = v951.Position
				end
				local v953 = v951.UpVector
				local v954
				if v947 == "headglint" then
					v954 = p945.bladeLen * 0.85
				else
					v954 = p945.cfg.len * 0.8
				end
				local v955 = v952 + v953 * v954
				local v956 = v_u_16.smearAlong[p945.kind]
				if v947 == "headglint" and v956 then
					v955 = v952 + v951.UpVector * (p945.bladeLen * v956.root) + v951.LookVector * (p945.bladeLen * 0.3)
				end
				local v957 = p943.FieldOfView
				local v958 = math.rad(v957) / 2
				local v959 = math.tan(v958)
				local v960 = p943.ViewportSize.X
				local v961 = p943.ViewportSize.Y
				local v962 = v960 / math.max(v961, 1)
				for _ = 1, 6 do
					local v963 = -v955.Z
					if v963 > 0.05 then
						local v964 = v955.X / (v963 * v959 * v962)
						if math.abs(v964) < 0.9 then
							local v965 = v955.Y / (v963 * v959)
							if math.abs(v965) < 0.9 then
								break
							end
						end
					end
					v955 = v952 + (v955 - v952) * 0.8
				end
				local v966 = v955.Unit
				local v967 = v955.Magnitude - 0.03
				local v968 = v966 * math.min(v967, 0.5)
				v_u_13.Play(v947 == "headglint" and (v956 and "flare" or "glint") or "block_spark", CFrame.lookAt(v968, v968 + v951.UpVector))
			elseif v947 == "fullglint" then
				local v969 = v_u_206.frame or CFrame.identity
				local v970
				if p945.gripAtt then
					v970 = p944:PointToObjectSpace(p945.gripAtt.WorldPosition)
				else
					v970 = v969.Position
				end
				local v971 = v969.LookVector
				local v972
				if p945.cfg.stock == nil then
					v972 = p945.cfg.len * 0.5
				else
					v972 = 0.288 - p945.brace
				end
				local v973 = v970 + v971 * v972
				if p945.cfg.stock ~= nil and (v_u_206.arrowTip and (v_u_780 and v_u_780.Parent)) then
					v973 = v_u_206.arrowTip
				end
				v_u_13.Play("glint", CFrame.lookAt(v973, v973 + v969.LookVector))
			elseif v947 == "bolt" then
				v_u_13.Play("glint", v_u_887(p944, p945, "muzzle"))
			elseif string.sub(v947, 1, 4) == "sfx:" then
				if v_u_206.sim then
					continue
				end
				local v974, v975 = string.match(v947, "^sfx:([^@]+)@?(.*)$")
				v_u_9.Play(v974 or string.sub(v947, 5), nil, tonumber(v975) and {
					["pitch"] = tonumber(v975)
				} or nil)
			elseif v947 == "click" and p945.pan then
				local v976 = p944:PointToObjectSpace(p945.pan.WorldPosition)
				v_u_13.Play("click", CFrame.lookAt(v976, v976 + Vector3.new(0, 1, 0)))
			elseif v947 == "twang" or (v947 == "powder" or (v947 == "puff" or (v947 == "click" or v947 == "ring"))) then
				v_u_13.Play(v947, v_u_887(p944, p945, "muzzle"))
			elseif v947 == "sparkle" then
				v_u_13.Play(p945.id == "healing_tonic" and "gold" or "sparkle", v_u_887(p944, p945, "tip"))
			elseif v947 == "crumbs" and p945.id == "healing_tonic" then
				v_u_13.Play("crumbs", v_u_887(p944, p945, "tip"))
				local v977 = v_u_206
				v977.bite = v977.bite + 1
				if v_u_206.bite % 2 ~= 1 then
					continue
				end
				v_u_13.Play("gold", v_u_887(p944, p945, "tip"))
			elseif v947 == "knock" then
				local v978 = v_u_887(p944, p945, "tip").Position
				v_u_13.Play("flare", CFrame.new(0, v978.Y, v978.Z))
			else
				if v947 == "beat" then
					continue
				end
				v_u_13.Play(v947, v_u_887(p944, p945, "tip"))
			end
		end
		table.clear(v946)
	end
	if p945.cfg.act == "gun" then
		v_u_13.Track("muzzle", v_u_887(p944, p945, "barrel"))
	end
	local v979 = v_u_876[p945.id] == true
	if v979 ~= v_u_206.embers then
		v_u_206.embers = v979
		v_u_13.Play("embers", v_u_887(p944, p945, "tip"), {
			["on"] = v979
		})
	end
	if v979 then
		v_u_13.Track("embers", v_u_887(p944, p945, "tip"))
	end
	local v980 = p945.id == "smoke_bomb" and (v_u_206.wind and 2 or 1) or 0
	if v980 ~= v_u_206.fuse then
		v_u_206.fuse = v980
		v_u_13.Play("fuse", v_u_887(p944, p945, "tip"), {
			["on"] = v980 > 0,
			["rate"] = v980 * 18
		})
	end
	if v980 > 0 then
		v_u_13.Track("fuse", v_u_887(p944, p945, "tip"))
	end
end
local function v_u_1051(p982, p983, p984, p985, p986, p987) -- name: place
	-- upvalues: (ref) v_u_715, (copy) v_u_11, (copy) v_u_811, (ref) v_u_780, (copy) v_u_206, (copy) v_u_13, (copy) v_u_16, (copy) v_u_208, (copy) v_u_209, (copy) v_u_778, (copy) v_u_875, (copy) v_u_981, (copy) v_u_942
	local v988
	if p987 then
		v988 = p987.model
	else
		v988 = nil
	end
	if v988 ~= v_u_715 then
		if v_u_715 then
			v_u_715.Parent = nil
		end
		v_u_715 = v988
	end
	if p987 and v988 then
		local v989 = v_u_16.fovRef * 0.5 * 0.017453292519943295
		local v990 = math.tan(v989)
		local v991 = math.clamp(p984, 20, 110) * 0.5 * 0.017453292519943295
		local v992 = v990 / math.tan(v991)
		local v993 = v_u_206.frame
		local v994
		if v993 then
			v994 = p983 * CFrame.new(v993.X, v993.Y, v993.Z * v992) * v993.Rotation * p987.norm
		else
			v994 = p983 * CFrame.new(p985.X, p985.Y, p985.Z * v992) * CFrame.fromEulerAnglesYXZ(p986.X, p986.Y, p986.Z) * p987.style
		end
		v988:PivotTo(v994 * p987.gripInv * p987.pivotRel)
		local v995 = p987.leftFist
		if v995 then
			local v996 = v_u_206.leftFrame
			if v996 then
				local v997 = v995.part
				local v998 = p983 * CFrame.new(v996.X, v996.Y, v996.Z * v992) * v996.Rotation
				local v999, v1000, v1001, v1002, v1003, v1004, v1005, v1006, v1007, v1008, v1009, v1010 = p987.norm:GetComponents()
				v997.CFrame = v998 * CFrame.new(-v999, v1000, v1001, v1002, -v1003, -v1004, -v1005, v1006, v1007, -v1008, v1009, v1010) * v995.rel
				v995.part.LocalTransparencyModifier = 0
			else
				v995.part.LocalTransparencyModifier = 1
			end
		end
		local v1011 = p987.inlay
		if v1011 then
			local v1012 = v_u_206.draw and (v_u_206.drawFull and 3 or (v_u_206.drawHalf and 2 or 1)) or 0
			if v1012 ~= v_u_206.inlayLvl then
				local v1013 = v_u_206
				local v1014 = v_u_206
				local v1015 = v_u_206
				local v1016 = v1011.part.Color
				local v1017 = v_u_206.now
				v1013.inlayFrom = v1016
				v1014.inlayLvl = v1012
				v1015.inlayT0 = v1017
			end
			local v1018 = {
				v1011.rest,
				Color3.fromRGB(60, 90, 92),
				Color3.fromRGB(95, 150, 152),
				Color3.fromRGB(140, 205, 206)
			}
			local v1019 = v1011.part
			local v1020 = v_u_206.inlayFrom
			local v1021 = v1018[v1012]
			local v1022 = (v_u_206.now - v_u_206.inlayT0) / 0.05
			v1019.Color = v1020:Lerp(v1021, (math.clamp(v1022, 0, 1)))
		end
		local v1023 = p987.strip
		if v1023 then
			local v1024 = v_u_206.stripV
			local v1025 = v1023.part
			local v1026 = v1023.size.X
			local v1027 = v1023.size.Y * v1024
			local v1028 = v1023.size.Z
			v1025.Size = Vector3.new(v1026, v1027, v1028)
			v1023.part.CFrame = p987.handle.CFrame * v1023.rest * CFrame.new(0, -v1023.size.Y * (v1024 - 1) / 2, 0)
		end
		if p987.stone then
			local v1029
			if v_u_206.looseAt == nil or v_u_206.now < v_u_206.looseAt then
				v1029 = false
			else
				v1029 = v_u_206.now < v_u_206.looseAt + 0.38
			end
			p987.stone.LocalTransparencyModifier = v1029 and 1 or 0
		end
		local v1030 = p987.hammer
		if v1030 then
			local v1031 = v_u_208.value
			local v1032 = math.clamp(v1031, -0.2, 1.25) * v1030.fired * 0.017453292519943295
			local v1033 = p987.handle.CFrame
			v1030.part.CFrame = v1033 * CFrame.new(v1030.pivot) * CFrame.fromAxisAngle(v1030.axis, v1032) * CFrame.new(-v1030.pivot) * v1030.rest
		end
		local v1034 = p987.frizzen
		if v1034 then
			local v1035 = v_u_209.value
			local v1036 = math.clamp(v1035, -0.1, 1.2) * v1034.fired * 0.017453292519943295
			local v1037 = p987.handle.CFrame
			v1034.part.CFrame = v1037 * CFrame.new(v1034.pivot) * CFrame.fromAxisAngle(v1034.axis, v1036) * CFrame.new(-v1034.pivot) * v1034.rest
		end
		local v1038 = p987.rod
		if v1038 then
			local v1039 = v_u_206.rodV
			local v1040 = p987.handle.CFrame
			if v1039 <= 1.5 then
				v1038.part.CFrame = v1040 * CFrame.new(v1038.fwd * (math.min(v1039, 1) * 1.3 * v1038.len)) * v1038.rest
			else
				local v1041 = (v1039 - 2) * v1038.len
				v1038.part.CFrame = v1040 * CFrame.fromMatrix(v1038.muzzle + v1038.fwd * (v1041 - v1038.len * 0.5), -v1038.fwd, v1038.up)
			end
		end
		if v988.Parent ~= p982 then
			v988.Parent = p982
		end
		if v_u_16.smearItem[p987.id] or v_u_16.smear[p987.kind] then
			v_u_778(p982, p983, v992, p987)
		else
			v_u_11.Hide()
		end
		v_u_875(p982, p983, v992, p987)
		v_u_981(p982, p983, p987)
		v_u_942(v992, p987)
		local v1042
		if v_u_206.leftVanishAt and (p987.leftFist and v_u_206.leftFrame) then
			v1042 = p987.leftFist.part.Position
		elseif v_u_780 and (v_u_780.Parent and p987.kind == "Bow") then
			local v1043, v1044 = v_u_780:GetBoundingBox()
			local v1045 = v1043.Position
			local v1046
			if v_u_206.frame then
				v1046 = p983:VectorToWorldSpace(v_u_206.frame.LookVector)
			else
				v1046 = v1043.LookVector
			end
			v1042 = v1045 + v1046 * (v1044.Z * 0.5)
		elseif (p987.kind == "Sling" or p987.id == "bolas") and p987.tipAtt then
			v1042 = p987.tipAtt.WorldPosition
		elseif p987.muzzle then
			v1042 = p987.muzzle.WorldPosition
		else
			v1042 = v988:GetBoundingBox().Position
		end
		local v1047 = v_u_206
		local v1048 = v_u_206
		local v1049 = os.clock()
		v1047.release = v1042
		v1048.releaseT = v1049
	else
		v_u_11.Hide()
		for _, v1050 in v_u_811 do
			v1050.Parent = nil
		end
		if v_u_780 then
			v_u_780.Parent = nil
			v_u_780 = nil
		end
		if v_u_206.embers then
			v_u_206.embers = false
			v_u_13.Play("embers", CFrame.identity, {
				["on"] = false
			})
		end
		if v_u_206.fuse > 0 then
			v_u_206.fuse = 0
			v_u_13.Play("fuse", CFrame.identity, {
				["on"] = false
			})
		end
	end
end
local v_u_1052 = false
local v_u_1053 = false
local v_u_1054 = game:GetService("UserInputService")
local function v_u_1083(p1055) -- name: liveInput
	-- upvalues: (copy) v_u_4, (copy) v_u_15, (copy) v_u_6, (copy) v_u_8, (ref) v_u_717, (copy) v_u_716, (copy) v_u_1054
	local v1056 = v_u_4.CurrentCamera
	local v1057 = v_u_15.Character
	local v1058
	if v1057 then
		v1058 = v1057:FindFirstChild("HumanoidRootPart")
	else
		v1058 = v1057
	end
	local v1059
	if v1057 then
		v1059 = v1057:FindFirstChildOfClass("Humanoid")
	else
		v1059 = v1057
	end
	if not (v1056 and (v1057 and (v1058 and (v1058:IsA("BasePart") and v1059)))) then
		return nil, v1056
	end
	local v1060 = v_u_6.InFirstPerson
	if v1060 then
		v1060 = v_u_6.InFirstPerson() == true
	end
	local v1061 = v1057:FindFirstChildOfClass("Tool")
	local v1062
	if v1061 then
		v1062 = v1061:GetAttribute("WeaponId")
	else
		v1062 = v1061
	end
	local v1063
	if type(v1062) == "string" then
		if v1061 then
			v1063 = v1061:GetAttribute("Kind")
		else
			v1063 = v1061
		end
		if type(v1063) ~= "string" then
			v1063 = v_u_8.Kind(v1062)
		end
	else
		v1063 = nil
	end
	local v1064
	if v1061 and (tonumber(v1061:GetAttribute("MaxCharges")) or 0) > 0 then
		v1064 = tonumber(v1061:GetAttribute("Charges"))
	else
		v1064 = nil
	end
	local v1065 = v1056.CFrame
	local v1066
	if v1060 then
		if v_u_717 ~= v1057 then
			v_u_717 = v1057
			local v1067 = { v1057 }
			for _, v1068 in { "FX", "Projectiles" } do
				local v1069 = v_u_4:FindFirstChild(v1068)
				if not v1069 then
					continue
				end
				table.insert(v1067, v1069)
			end
			v_u_716.FilterDescendantsInstances = v1067
		end
		local v1070 = v_u_4:Spherecast(v1065.Position, 0.15, v1065.LookVector * 1.8, v_u_716)
		if v1070 then
			v1066 = v1070.Distance
		else
			v1066 = nil
		end
	else
		v1066 = nil
	end
	local v1071, v1072
	if v_u_6.GetViewBob then
		v1071, v1072 = v_u_6.GetViewBob()
	else
		v1071 = 0
		v1072 = 0
	end
	local v1073 = {
		["dt"] = p1055,
		["now"] = os.clock()
	}
	if v1060 then
		if v1059.Health > 0 then
			v1060 = v_u_15:GetAttribute("ReplayPlaying") ~= true
		else
			v1060 = false
		end
	end
	v1073.visible = v1060
	if type(v1062) ~= "string" then
		v1062 = nil
	end
	v1073.id = v1062
	v1073.kind = v1063
	v1073.charges = v1064
	v1073.cam = v1065
	v1073.fov = v1056.FieldOfView
	v1073.grounded = v1059.FloorMaterial ~= Enum.Material.Air
	local function v1074()
		-- upvalues: (ref) v_u_6
		if v_u_6.GetDrawnRoot then
			return v_u_6.GetDrawnRoot()
		else
			return nil
		end
	end
	local v1075, v1076 = pcall(v1074)
	local v1077
	if v1075 and typeof(v1076) == "CFrame" then
		v1077 = v1076.Position.Y
	else
		v1077 = v1058.Position.Y
	end
	v1073.rootY = v1077
	v1073.sliding = v1057:GetAttribute("Sliding") == true
	local v1078 = v_u_6.IsAiming
	if v1078 then
		v1078 = v_u_6.IsAiming() == true
	end
	v1073.aiming = v1078
	local v1079
	if v1061 then
		v1079 = v1061:GetAttribute("Thrown") == true
	else
		v1079 = nil
	end
	v1073.offHandOut = v1079
	v1073.bobPhase = v1071
	v1073.bobAmount = v1072
	v1073.wall = v1066
	local function v1080()
		-- upvalues: (ref) v_u_1054
		return v_u_1054.PreferredInput
	end
	local v1081, v1082 = pcall(v1080)
	if v1081 then
		if typeof(v1082) == "EnumItem" then
			v1081 = v1082.Name == "Touch"
		else
			v1081 = false
		end
	end
	v1073.touch = v1081
	return v1073, v1056
end
local v_u_1084 = 0
local v_u_1085 = 0
local v_u_1086 = 0
local function v_u_1101(p1087) -- name: renderFrame
	-- upvalues: (copy) v_u_1083, (ref) v_u_715, (copy) v_u_811, (ref) v_u_780, (copy) v_u_11, (copy) v_u_13, (copy) v_u_206, (copy) v_u_714, (copy) v_u_1051
	local v1088, v1089 = v_u_1083(p1087)
	if v1088 and v1089 then
		if v1088.visible then
			local v1090, v1091, v1092 = v_u_714(v1088)
			v_u_1051(v1089, v1088.cam, v1088.fov, v1090, v1091, v1092)
		else
			if v_u_206.shown or v_u_715 then
				local v1093 = v_u_206
				local v1094 = v_u_206
				v_u_206.shown = nil
				v1093.wantId = nil
				v1094.dropAt = nil
				if v_u_715 then
					v_u_715.Parent = nil
					v_u_715 = nil
				end
				for _, v1095 in v_u_811 do
					v1095.Parent = nil
				end
				if v_u_780 then
					v_u_780.Parent = nil
					v_u_780 = nil
				end
				v_u_11.Hide()
				v_u_13.Hide()
				local v1096 = v_u_206
				v_u_206.embers = false
				v1096.fuse = 0
			end
			local v1097 = v_u_206
			local v1098 = v_u_206
			v_u_206.lastYaw = nil
			v1097.lastPitch = nil
			v1098.lastRootY = nil
		end
	else
		if v_u_715 then
			v_u_715.Parent = nil
			v_u_715 = nil
		end
		for _, v1099 in v_u_811 do
			v1099.Parent = nil
		end
		if v_u_780 then
			v_u_780.Parent = nil
			v_u_780 = nil
		end
		v_u_11.Hide()
		v_u_13.Hide()
		local v1100 = v_u_206
		v_u_206.embers = false
		v1100.fuse = 0
		return
	end
end
local function v_u_1106(p1102) -- name: render
	-- upvalues: (ref) v_u_1052, (ref) v_u_1053, (copy) v_u_1101, (ref) v_u_1084, (ref) v_u_1085, (ref) v_u_1086
	if not (v_u_1052 or v_u_1053) then
		local v1103 = os.clock()
		v_u_1101(p1102)
		local v1104 = os.clock() - v1103
		v_u_1084 = v_u_1084 + v1104
		v_u_1085 = v_u_1085 + 1
		local v1105 = v_u_1086
		v_u_1086 = math.max(v1105, v1104)
	end
end
function v_u_14.SetExternal(p1107) -- name: SetExternal
	-- upvalues: (ref) v_u_1053, (copy) v_u_252, (copy) v_u_206, (ref) v_u_715, (copy) v_u_811, (ref) v_u_780, (copy) v_u_11, (copy) v_u_13
	if v_u_1053 ~= p1107 then
		v_u_1053 = p1107
		v_u_252()
		v_u_206.shown = nil
		v_u_206.wantId = nil
		if v_u_715 then
			v_u_715.Parent = nil
			v_u_715 = nil
		end
		for _, v1108 in v_u_811 do
			v1108.Parent = nil
		end
		if v_u_780 then
			v_u_780.Parent = nil
			v_u_780 = nil
		end
		v_u_11.Hide()
		v_u_13.Hide()
		local v1109 = v_u_206
		v_u_206.embers = false
		v1109.fuse = 0
	end
end
function v_u_14.ReleasePoint() -- name: ReleasePoint
	-- upvalues: (copy) v_u_206
	if v_u_206.release and os.clock() - v_u_206.releaseT < 0.5 then
		return v_u_206.release
	else
		return nil
	end
end
function v_u_14.ReleaseDelay() -- name: ReleaseDelay
	-- upvalues: (copy) v_u_206
	local v1110 = v_u_206.vanishAt or (v_u_206.looseAt or v_u_206.leftVanishAt)
	if not v1110 then
		return 0
	end
	local v1111 = v1110 - os.clock()
	return math.max(0, v1111)
end
function v_u_14.IsExternal() -- name: IsExternal
	-- upvalues: (ref) v_u_1053
	return v_u_1053
end
function v_u_14.ExternalFrame(p1112) -- name: ExternalFrame
	-- upvalues: (ref) v_u_1053, (copy) v_u_4, (copy) v_u_206, (ref) v_u_715, (copy) v_u_811, (ref) v_u_780, (copy) v_u_11, (copy) v_u_13, (copy) v_u_714, (copy) v_u_1054, (copy) v_u_1051
	if v_u_1053 then
		local v1113 = v_u_4.CurrentCamera
		if v1113 then
			if p1112.visible then
				local v1114 = v1113.CFrame
				local v1115 = v_u_714
				local v1116 = {
					["dt"] = nil,
					["now"] = nil,
					["visible"] = true,
					["id"] = nil,
					["kind"] = nil,
					["charges"] = nil,
					["cam"] = nil,
					["fov"] = nil,
					["grounded"] = nil,
					["rootY"] = nil,
					["sliding"] = nil,
					["aiming"] = nil,
					["bobPhase"] = nil,
					["bobAmount"] = nil,
					["wall"] = nil,
					["touch"] = nil,
					["dt"] = p1112.dt,
					["now"] = os.clock(),
					["id"] = p1112.id,
					["kind"] = p1112.kind,
					["charges"] = p1112.charges,
					["cam"] = v1114,
					["fov"] = v1113.FieldOfView,
					["grounded"] = p1112.grounded,
					["rootY"] = p1112.rootY,
					["sliding"] = p1112.sliding,
					["aiming"] = p1112.aiming,
					["bobPhase"] = p1112.bobPhase,
					["bobAmount"] = p1112.bobAmount,
					["wall"] = p1112.wall
				}
				local function v1117()
					-- upvalues: (ref) v_u_1054
					return v_u_1054.PreferredInput
				end
				local v1118, v1119 = pcall(v1117)
				if v1118 then
					if typeof(v1119) == "EnumItem" then
						v1118 = v1119.Name == "Touch"
					else
						v1118 = false
					end
				end
				v1116.touch = v1118
				local v1120, v1121, v1122 = v1115(v1116)
				v_u_1051(v1113, v1114, v1113.FieldOfView, v1120, v1121, v1122)
			else
				if v_u_206.shown or v_u_715 then
					local v1123 = v_u_206
					local v1124 = v_u_206
					v_u_206.shown = nil
					v1123.wantId = nil
					v1124.dropAt = nil
					if v_u_715 then
						v_u_715.Parent = nil
						v_u_715 = nil
					end
					for _, v1125 in v_u_811 do
						v1125.Parent = nil
					end
					if v_u_780 then
						v_u_780.Parent = nil
						v_u_780 = nil
					end
					v_u_11.Hide()
					v_u_13.Hide()
					local v1126 = v_u_206
					v_u_206.embers = false
					v1126.fuse = 0
				end
				local v1127 = v_u_206
				local v1128 = v_u_206
				v_u_206.lastYaw = nil
				v1127.lastPitch = nil
				v1128.lastRootY = nil
			end
		else
			return
		end
	else
		return
	end
end
function v_u_14.ExternalEvent(p1129, p1130) -- name: ExternalEvent
	-- upvalues: (ref) v_u_1053, (copy) v_u_206, (copy) v_u_401
	if v_u_1053 then
		v_u_206.now = os.clock()
		v_u_401(p1129, p1130)
	end
end
local function v_u_1164(p1131) -- name: simulate
	-- upvalues: (copy) v_u_4, (ref) v_u_1052, (copy) v_u_206, (copy) v_u_252, (copy) v_u_13, (copy) v_u_401, (copy) v_u_714, (copy) v_u_8, (copy) v_u_1051
	local v1132 = v_u_4.CurrentCamera
	if not v1132 then
		return {
			["err"] = "no camera"
		}
	end
	v_u_1052 = true
	v_u_206.sim = true
	v_u_252()
	v_u_13.Freeze(true)
	v_u_206.shown = nil
	v_u_206.wantId = nil
	local v1133 = p1131.id
	local v1134 = v1132.CFrame
	local v1135 = p1131.t
	local v1136 = tonumber(v1135) or 0
	local v1137 = p1131.events or {}
	local v1138 = p1131.speed
	local v1139 = tonumber(v1138) or 0
	local v1140 = -0.8
	local v1141 = {}
	local v1142 = 0
	local v1143 = 0
	local v1144 = Vector3.new(0, 0, 0)
	local v1145 = Vector3.new(0, 0, 0)
	local v1146 = nil
	while v1140 <= v1136 + 0.004166666666666667 do
		local v1147 = 0
		local v1148 = true
		for _, v1149 in p1131.air or {} do
			if v1149[1] > v1140 then
				continue
			end
			v1147 = v1149[2]
			v1148 = v1149[3]
		end
		v1142 = v1142 + v1147 * 0.016666666666666666
		if v1140 >= 0 and v1148 then
			v1143 = (v1143 + v1139 * 0.016666666666666666 / 7 * 2 * 3.141592653589793) % 12.566370614359172
		end
		local v1150
		if v1140 >= 0 and v1148 then
			local v1151 = (v1139 - 1) / 20
			v1150 = math.clamp(v1151, 0, 1.25)
		else
			v1150 = 0
		end
		v_u_206.now = v1140 + 1000
		if v1140 + 0.016666666666666666 > v1136 + 0.004166666666666667 then
			table.clear(v_u_206.fxQueue)
		end
		for v1152, v1153 in v1137 do
			if v1141[v1152] or v1153[1] > v1140 then
				continue
			end
			v1141[v1152] = true
			v_u_401(v1153[2], v1153[3])
		end
		local v1154 = p1131.switch
		local v1155
		if v1154 and v1154[1] <= v1140 then
			v1155 = v1154[2]
		else
			v1155 = v1133
		end
		local v1156 = p1131.slide
		local v1157
		if v1156 == nil or v1156[1] > v1140 then
			v1157 = false
		else
			v1157 = v1140 < v1156[2]
		end
		local v1158 = v_u_714
		local v1159 = {
			["dt"] = 0.016666666666666666,
			["now"] = nil,
			["visible"] = true,
			["id"] = nil,
			["kind"] = nil,
			["charges"] = nil,
			["cam"] = nil,
			["fov"] = nil,
			["grounded"] = nil,
			["rootY"] = nil,
			["sliding"] = nil,
			["aiming"] = nil,
			["bobPhase"] = nil,
			["bobAmount"] = nil,
			["wall"] = nil,
			["now"] = v1140 + 1000,
			["id"] = v1155,
			["kind"] = v_u_8.Kind(v1155),
			["cam"] = v1134
		}
		local v1160 = p1131.fov
		v1159.fov = tonumber(v1160) or v1132.FieldOfView
		v1159.grounded = v1148
		v1159.rootY = v1142
		v1159.sliding = v1157
		local v1161
		if p1131.aiming == true then
			v1161 = v1140 >= 0
		else
			v1161 = false
		end
		v1159.aiming = v1161
		v1159.bobPhase = v1143
		v1159.bobAmount = v1150
		v1159.wall = p1131.wall
		v1144, v1145, v1146 = v1158(v1159)
		v1140 = v1140 + 0.016666666666666666
	end
	local v1162 = v_u_1051
	local v1163 = p1131.fov
	v1162(v1132, v1134, tonumber(v1163) or v1132.FieldOfView, v1144, v1145, v1146)
	return {
		["shown"] = v1146 ~= nil,
		["pos"] = { v1144.X, v1144.Y, v1144.Z },
		["rot"] = { v1145.X / 0.017453292519943295, v1145.Y / 0.017453292519943295, v1145.Z / 0.017453292519943295 }
	}
end
local v_u_1165 = false
function v_u_14.Start() -- name: Start
	-- upvalues: (ref) v_u_1165, (copy) v_u_13, (copy) v_u_2, (ref) v_u_24, (ref) v_u_25, (copy) v_u_15, (copy) v_u_252, (copy) v_u_206, (ref) v_u_715, (copy) v_u_811, (ref) v_u_780, (copy) v_u_11, (copy) v_u_14, (ref) v_u_1052, (ref) v_u_1053, (copy) v_u_401, (copy) v_u_3, (copy) v_u_1106, (copy) v_u_1164, (copy) v_u_19, (copy) v_u_21, (copy) v_u_23, (copy) v_u_10, (copy) v_u_16, (copy) v_u_207, (copy) v_u_210, (copy) v_u_12, (ref) v_u_1085, (ref) v_u_1084, (ref) v_u_1086
	if not v_u_1165 then
		v_u_1165 = true
		v_u_13.Preload()
		local v1166 = v_u_2:WaitForChild("Assets", 30)
		local v1167
		if v1166 then
			v1167 = v1166:WaitForChild("Weapons", 30)
		else
			v1167 = v1166
		end
		v_u_24 = v1167
		if v1166 then
			v1166 = v1166:FindFirstChild("ViewModels")
		end
		v_u_25 = v1166
		task.spawn(function()
			-- upvalues: (ref) v_u_25, (ref) v_u_24
			local v_u_1168 = {}
			for _, v1169 in { v_u_25, v_u_24 } do
				if not v1169 then
					continue
				end
				table.insert(v_u_1168, v1169)
			end
			pcall(function()
				-- upvalues: (copy) v_u_1168
				game:GetService("ContentProvider"):PreloadAsync(v_u_1168)
			end)
		end)
		v_u_15.CharacterAdded:Connect(function()
			-- upvalues: (ref) v_u_252, (ref) v_u_206, (ref) v_u_715, (ref) v_u_811, (ref) v_u_780, (ref) v_u_11, (ref) v_u_13
			v_u_252()
			v_u_206.shown = nil
			v_u_206.wantId = nil
			if v_u_715 then
				v_u_715.Parent = nil
				v_u_715 = nil
			end
			for _, v1170 in v_u_811 do
				v1170.Parent = nil
			end
			if v_u_780 then
				v_u_780.Parent = nil
				v_u_780 = nil
			end
			v_u_11.Hide()
			v_u_13.Hide()
			local v1171 = v_u_206
			v_u_206.embers = false
			v1171.fuse = 0
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_15, (ref) v_u_14, (ref) v_u_1052, (ref) v_u_1053, (ref) v_u_206, (ref) v_u_401
			local v1172 = v_u_15:WaitForChild("PlayerScripts"):WaitForChild("Combat", 60)
			local v1173
			if v1172 then
				v1173 = v1172:WaitForChild("Controller", 30)
			else
				v1173 = v1172
			end
			if v1172 then
				v1172 = v1172:WaitForChild("Effects", 30)
			end
			if v1172 and v1172:IsA("ModuleScript") then
				local v1174 = require
				local v1175, v1176 = pcall(v1174, v1172)
				if v1175 and type(v1176) == "table" then
					local v1177 = v1176.SetViewHandOff
					if type(v1177) == "function" then
						v1176.SetViewHandOff(v_u_14.ReleasePoint, v_u_14.ReleaseDelay)
					end
				end
			end
			if v1173 and v1173:IsA("ModuleScript") then
				local v1178 = require
				local v1179, v1180 = pcall(v1178, v1173)
				if v1179 and type(v1180) == "table" then
					local v1181 = v1180.OnViewEvent
					if type(v1181) == "function" then
						v1180.OnViewEvent(function(p1182, p1183)
							-- upvalues: (ref) v_u_1052, (ref) v_u_1053, (ref) v_u_206, (ref) v_u_401
							if not (v_u_1052 or v_u_1053) then
								v_u_206.now = os.clock()
								v_u_401(p1182, p1183)
							end
						end)
					end
				end
			end
		end)
		v_u_3:BindToRenderStep("TribesViewModel", Enum.RenderPriority.Camera.Value + 2, v_u_1106)
		if v_u_3:IsStudio() then
			local v1184 = Instance.new("BindableFunction")
			v1184.Name = "ViewModelDebug"
			function v1184.OnInvoke(p1185, p1186)
				-- upvalues: (ref) v_u_1164, (ref) v_u_1052, (ref) v_u_206, (ref) v_u_13, (ref) v_u_252, (ref) v_u_715, (ref) v_u_811, (ref) v_u_780, (ref) v_u_11, (ref) v_u_19, (ref) v_u_21, (ref) v_u_23, (ref) v_u_10, (ref) v_u_16, (ref) v_u_207, (ref) v_u_210, (ref) v_u_12, (ref) v_u_1085, (ref) v_u_1084, (ref) v_u_1086
				if p1185 == "Sim" then
					return v_u_1164(p1186)
				end
				if p1185 == "Live" then
					v_u_1052 = false
					v_u_206.sim = false
					v_u_13.Freeze(false)
					v_u_252()
					v_u_206.shown = nil
					v_u_206.wantId = nil
					if v_u_715 then
						v_u_715.Parent = nil
						v_u_715 = nil
					end
					for _, v1187 in v_u_811 do
						v1187.Parent = nil
					end
					if v_u_780 then
						v_u_780.Parent = nil
						v_u_780 = nil
					end
					v_u_11.Hide()
					v_u_13.Hide()
					local v1188 = v_u_206
					v_u_206.embers = false
					v1188.fuse = 0
					return true
				end
				if p1185 ~= "Tune" then
					if p1185 == "Clips" then
						local v1189 = p1186 or {}
						for _, v1190 in { "SWORD", "DAGGER" } do
							local v1191 = v1189[v1190]
							if type(v1191) ~= "table" then
								continue
							end
							for v1192, v1193 in v1189[v1190] do
								v_u_10[v1190][v1192] = v1193
							end
						end
						local v1194 = v1189.T
						if type(v1194) == "table" then
							for v1195, v1196 in v1189.T do
								v_u_16[v1195] = v1196
							end
							local v1197 = v_u_207
							local v1198 = v_u_207
							local v1199 = v_u_16.retHz
							local v1200 = v_u_16.retDamp
							v1197.frequency = v1199
							v1198.damping = v1200
							local v1201 = v_u_210
							local v1202 = v_u_210
							local v1203 = v_u_16.retHz
							local v1204 = v_u_16.retDamp
							v1201.frequency = v1203
							v1202.damping = v1204
						end
						return true
					end
					if p1185 == "ItemClip" then
						local v1205 = p1186 or {}
						local v1206 = v_u_12.SETS[v1205.kind]
						if v1206 then
							local v1207 = v1205.draw
							if type(v1207) == "table" then
								v_u_12.DRAW[v1205.kind] = v1205.draw
								for _, v1208 in v_u_23 do
									if v1208.kind ~= v1205.kind then
										continue
									end
									v1208.drawFrom = v1205.draw
								end
							end
						end
						if v1206 then
							local v1209 = v1205.name
							if type(v1209) == "string" then
								local v1210 = v1205.clip
								if type(v1210) == "table" then
									v1206[v1205.name] = v1205.clip
									return true
								end
							end
						end
						return v1206 ~= nil
					end
					if p1185 ~= "State" then
						return nil
					end
					local v1211 = {}
					local v1212 = v_u_206.shown
					if v1212 then
						v1212 = v_u_206.shown.id
					end
					v1211.shown = v1212
					v1211.want = v_u_206.wantId
					v1211.frozen = v_u_1052
					v1211.action = v_u_206.action
					v1211.block = v_u_206.block
					v1211.charge = v_u_206.charge
					v1211.draw = v_u_206.draw
					v1211.wind = v_u_206.wind
					v1211.use = v_u_206.use
					v1211.reload = v_u_206.reload
					local v1213 = v_u_715 and v_u_715.Parent
					if v1213 then
						v1213 = v_u_715.Parent.Name
					end
					v1211.parent = v1213
					v1211.msPerFrame = v_u_1085 <= 0 and 0 or v_u_1084 / v_u_1085 * 1000
					v1211.maxFrameMs = v_u_1086 * 1000
					v1211.frames = v_u_1085
					return v1211
				end
				local v1214 = p1186 or {}
				local v1215 = v1214.kind
				if v1215 then
					v1215 = v_u_19[v1214.kind]
				end
				local v1216, v1217, v1218, v1219, v1220, v1221, v1222, v1223, v1224, v1225, v1226, v1227, v1228, v1229, v1230
				if not v1215 then
					if v1214.id then
						v1216 = v_u_21[v1214.id]
						v1217 = v_u_21
						v1218 = v1214.id
						v1219 = {}
						if v1214.fix then
							v1220 = v1214.fix[1]
							v1221 = v1214.fix[2]
							v1222 = v1214.fix[3]
							v1223 = Vector3.new(v1220, v1221, v1222)
						else
							v1223 = nil
						end
						v1219.rot = v1223
						if v1214.fixPos then
							v1224 = v1214.fixPos[1]
							v1225 = v1214.fixPos[2]
							v1226 = v1214.fixPos[3]
							v1227 = Vector3.new(v1224, v1225, v1226)
						else
							v1227 = nil
						end
						v1219.pos = v1227
						v1219.len = v1214.fixLen
						if v1214.barrel then
							v1228 = v1214.barrel[1]
							v1229 = v1214.barrel[2]
							v1230 = v1214.barrel[3]
							v1216 = Vector3.new(v1228, v1229, v1230)
						elseif v1216 then
							v1216 = v1216.barrel
						end
						v1219.barrel = v1216
						v1217[v1218] = v1219
					end
					for v1268, v1269 in v_u_23 do
						if (not v1214.id or v1268 ~= v1214.id) and (not v1215 or v1269.kind ~= v1214.kind) then
							continue
						end
						v1269.model:Destroy()
						v_u_23[v1268] = nil
					end
					return true
				end
				if v1214.rot then
					local v1233 = v1214.rot[1]
					local v1234 = v1214.rot[2]
					local v1235 = v1214.rot[3]
					v1215.rot = Vector3.new(v1233, v1234, v1235)
				end
				if v1214.pos then
					local v1236 = v1214.pos[1]
					local v1237 = v1214.pos[2]
					local v1238 = v1214.pos[3]
					v1215.pos = Vector3.new(v1236, v1237, v1238)
				end
				if v1214.len then
					v1215.len = v1214.len
				end
				if v1214.aimPos then
					local v1239 = v1214.aimPos[1]
					local v1240 = v1214.aimPos[2]
					local v1241 = v1214.aimPos[3]
					v1215.aimPos = Vector3.new(v1239, v1240, v1241)
				end
				if v1214.aimRot then
					local v1242 = v1214.aimRot[1]
					local v1243 = v1214.aimRot[2]
					local v1244 = v1214.aimRot[3]
					v1215.aimRot = Vector3.new(v1242, v1243, v1244)
				end
				local v1245 = v1214.stock
				if type(v1245) ~= "table" then
					if v1214.id then
						v1216 = v_u_21[v1214.id]
						v1217 = v_u_21
						v1218 = v1214.id
						v1219 = {}
						if v1214.fix then
							v1220 = v1214.fix[1]
							v1221 = v1214.fix[2]
							v1222 = v1214.fix[3]
							v1223 = Vector3.new(v1220, v1221, v1222)
						else
							v1223 = nil
						end
						v1219.rot = v1223
						if v1214.fixPos then
							v1224 = v1214.fixPos[1]
							v1225 = v1214.fixPos[2]
							v1226 = v1214.fixPos[3]
							v1227 = Vector3.new(v1224, v1225, v1226)
						else
							v1227 = nil
						end
						v1219.pos = v1227
						v1219.len = v1214.fixLen
						if v1214.barrel then
							v1228 = v1214.barrel[1]
							v1229 = v1214.barrel[2]
							v1230 = v1214.barrel[3]
							v1216 = Vector3.new(v1228, v1229, v1230)
						elseif v1216 then
							v1216 = v1216.barrel
						end
						v1219.barrel = v1216
						v1217[v1218] = v1219
					end
					for v1268, v1269 in v_u_23 do
						if (not v1214.id or v1268 ~= v1214.id) and (not v1215 or v1269.kind ~= v1214.kind) then
							continue
						end
						v1269.model:Destroy()
						v_u_23[v1268] = nil
					end
					return true
				end
				local v1248 = v1215.stock or {}
				for v1249, v1251 in v1214.stock do
					local v1251, v1252, v1253, v1254, v1255
					if type(v1251) == "table" then
						local v1256 = v1251[1]
						if type(v1256) == "table" then
							local v1257 = {}
							local v1258 = v1251[1]
							if type(v1258) == "table" then
								local v1259 = v1258[1]
								if type(v1259) == "number" then
									local v1260 = v1258[1]
									local v1261 = v1258[2]
									local v1262 = v1258[3]
									v1258 = Vector3.new(v1260, v1261, v1262)
								end
							end
							local v1263 = v1251[2]
							if type(v1263) == "table" then
								local v1264 = v1263[1]
								if type(v1264) == "number" then
									local v1265 = v1263[1]
									local v1266 = v1263[2]
									local v1267 = v1263[3]
									v1263 = Vector3.new(v1265, v1266, v1267)
								end
							end
							__set_list(v1257, 1, {v1258, v1263})
							v1251 = v1257
							v1248[v1249] = v1251
						else
							if type(v1251) == "table" then
								v1252 = v1251[1]
								if type(v1252) == "number" then
									v1253 = v1251[1]
									v1254 = v1251[2]
									v1255 = v1251[3]
									v1251 = Vector3.new(v1253, v1254, v1255)
								end
							end
							v1248[v1249] = v1251
						end
					else
						if type(v1251) == "table" then
							v1252 = v1251[1]
							if type(v1252) == "number" then
								v1253 = v1251[1]
								v1254 = v1251[2]
								v1255 = v1251[3]
								v1251 = Vector3.new(v1253, v1254, v1255)
							end
						end
						v1248[v1249] = v1251
					end
				end
				v1215.stock = v1248
				if v1214.id then
					v1216 = v_u_21[v1214.id]
					v1217 = v_u_21
					v1218 = v1214.id
					v1219 = {}
					if v1214.fix then
						v1220 = v1214.fix[1]
						v1221 = v1214.fix[2]
						v1222 = v1214.fix[3]
						v1223 = Vector3.new(v1220, v1221, v1222)
					else
						v1223 = nil
					end
					v1219.rot = v1223
					if v1214.fixPos then
						v1224 = v1214.fixPos[1]
						v1225 = v1214.fixPos[2]
						v1226 = v1214.fixPos[3]
						v1227 = Vector3.new(v1224, v1225, v1226)
					else
						v1227 = nil
					end
					v1219.pos = v1227
					v1219.len = v1214.fixLen
					if v1214.barrel then
						v1228 = v1214.barrel[1]
						v1229 = v1214.barrel[2]
						v1230 = v1214.barrel[3]
						v1216 = Vector3.new(v1228, v1229, v1230)
					elseif v1216 then
						v1216 = v1216.barrel
					end
					v1219.barrel = v1216
					v1217[v1218] = v1219
				end
				for v1268, v1269 in v_u_23 do
					if (not v1214.id or v1268 ~= v1214.id) and (not v1215 or v1269.kind ~= v1214.kind) then
						continue
					end
					v1269.model:Destroy()
					v_u_23[v1268] = nil
				end
				return true
			end
			v1184.Parent = v_u_15
		end
	end
end
return v_u_14