local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("TextChatService")
local v_u_3 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Tribes"))
return {
	["Init"] = function(p4) -- name: Init
		-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_2
		local v_u_5 = {
			["count"] = 0
		}
		local function v_u_13(p6) -- name: decorate
			-- upvalues: (ref) v_u_1, (ref) v_u_3
			local v7 = p6.TextSource
			if v7 then
				v7 = v_u_1:GetPlayerByUserId(v7.UserId)
			end
			local v8
			if v7 then
				local v9 = v7.Character
				if v9 then
					v9 = v9:GetAttribute("Level")
				end
				if type(v9) ~= "number" then
					v9 = v7:GetAttribute("Level")
				end
				if type(v9) == "number" and v9 >= 1 then
					v8 = math.floor(v9)
				else
					v8 = nil
				end
			else
				v8 = v7
			end
			if not v8 then
				return nil
			end
			local v10 = Instance.new("TextChatMessageProperties")
			local v11 = v7:GetAttribute("TribeTag")
			local v12 = (type(v11) ~= "string" or v11 == "") and "" or string.format("<font color=\"#%s\">[%s]</font> ", v_u_3.TextColor(v7:GetAttribute("TribeColor1")):ToHex(), v11)
			v10.PrefixText = string.format("<font color=\"%s\">[%d]</font> ", "#AEB5C2", v8) .. v12 .. p6.PrefixText
			return v10
		end
		local function v19()
			-- upvalues: (ref) v_u_2, (copy) v_u_13, (copy) v_u_5
			function v_u_2.OnIncomingMessage(p14)
				-- upvalues: (ref) v_u_13, (ref) v_u_5
				local v15 = v_u_13(p14)
				local v16 = v_u_5
				v16.count = v16.count + 1
				v_u_5.original = p14.PrefixText
				local v17 = v_u_5
				local v18
				if v15 then
					v18 = v15.PrefixText
				else
					v18 = p14.PrefixText
				end
				v17.prefix = v18
				return v15
			end
		end
		local v_u_20, v21 = pcall(v19)
		if not v_u_20 then
			warn("[UI] chat tags: " .. tostring(v21))
		end
		function p4.Debug.chatTags(p22, p23, p24)
			-- upvalues: (ref) v_u_1, (copy) v_u_13, (copy) v_u_20, (copy) v_u_5
			if p22 ~= "test" then
				return {
					["hooked"] = v_u_20,
					["count"] = v_u_5.count,
					["prefix"] = v_u_5.prefix or false,
					["original"] = v_u_5.original or false
				}
			end
			local v25 = {}
			local v26 = {}
			if type(p23) ~= "number" then
				p23 = v_u_1.LocalPlayer.UserId
			end
			v26.UserId = p23
			v25.TextSource = v26
			if type(p24) ~= "string" then
				p24 = v_u_1.LocalPlayer.DisplayName
			end
			v25.PrefixText = p24
			local v27 = v_u_13(v25)
			local v28 = {
				["changed"] = v27 ~= nil
			}
			local v29
			if v27 then
				v29 = v27.PrefixText
			else
				v29 = v25.PrefixText
			end
			v28.prefix = v29
			return v28
		end
	end
}