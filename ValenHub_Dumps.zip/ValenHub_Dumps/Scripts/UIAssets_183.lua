return {
	["Icons"] = {
		["Shell"] = "rbxassetid://99846648765728",
		["Mask"] = "rbxassetid://89003241513845",
		["Headshot"] = "rbxassetid://72793509129602",
		["Skull"] = "rbxassetid://80007031854950",
		["Lock"] = "rbxassetid://102203462430148",
		["Fire"] = "rbxassetid://72400396952299",
		["CrossedArrows"] = "rbxassetid://99328030142471",
		["Sword"] = "rbxassetid://72261169750292",
		["Star"] = "rbxassetid://78177476692890",
		["Clock"] = "rbxassetid://137159598049108",
		["Shield"] = "rbxassetid://76192296789559",
		["Teeth"] = "rbxassetid://101212307594515",
		["Feather"] = "rbxassetid://108647323581271",
		["Glow"] = "rbxassetid://97800992243662",
		["LoadoutSword"] = "rbxassetid://134698198955611",
		["CollectionGem"] = "rbxassetid://97124384725009",
		["Trophy"] = "rbxassetid://97528395336976"
	},
	["Ranks"] = {
		["bronze"] = "rbxassetid://90236652093643",
		["silver"] = "rbxassetid://132850691635939",
		["gold"] = "rbxassetid://77828372401279",
		["platinum"] = "rbxassetid://132107548449858",
		["diamond"] = "rbxassetid://133923950881275",
		["master"] = "rbxassetid://124138478279228",
		["grandmaster"] = "rbxassetid://89659320531633",
		["immortal"] = "rbxassetid://113839586007970"
	},
	["Fx"] = {
		["Band"] = "rbxassetid://89979088288249",
		["Shard"] = "rbxassetid://86878914555447",
		["Spark"] = "rbxassetid://89943623116354",
		["Vignette"] = "rbxassetid://136482878684932",
		["Ring"] = "rbxassetid://110283870778458",
		["Rays"] = "rbxassetid://134713914861874",
		["RaysThin"] = "rbxassetid://84039287921878",
		["Sparkle"] = "rbxassetid://131807536411883",
		["Dust"] = "rbxassetid://90519718971434",
		["Beam"] = "rbxassetid://132023407255834",
		["CardBack"] = "rbxassetid://100851392218181",
		["Gem"] = "rbxassetid://102236949100017",
		["GlowRing"] = "rbxassetid://97811580890704",
		["Flare"] = "rbxassetid://76289087675153"
	},
	["Mouse"] = {
		["Left"] = "rbxassetid://130699253681146",
		["Right"] = "rbxassetid://109697423841513"
	},
	["News"] = {
		["NewWeapons"] = "rbxassetid://139552399595431"
	},
	["WeaponArt"] = {
		["short_bow"] = "rbxassetid://130889399161340",
		["longbow"] = "rbxassetid://79633738763289",
		["crossbow"] = "rbxassetid://113585186053213",
		["throwing_knives"] = "rbxassetid://98111181878246",
		["obsidian_dagger"] = "rbxassetid://98111181878246",
		["sling"] = "rbxassetid://95857044140409",
		["javelins"] = "rbxassetid://105438407988325",
		["spear"] = "rbxassetid://105438407988325",
		["bronze_sword"] = "rbxassetid://114209284269899",
		["war_club"] = "rbxassetid://138401845278401",
		["battle_axe"] = "rbxassetid://138401845278401",
		["fire_bomb"] = "rbxassetid://136101603928779"
	}
}