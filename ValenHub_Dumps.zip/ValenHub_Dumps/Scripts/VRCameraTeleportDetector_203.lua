local v_u_5 = {
	["JUMP_STUDS"] = 4,
	["SETTLED_STUDS"] = 1,
	["DEBOUNCE_SECONDS"] = 0.25,
	["shouldRecenter"] = function(p1, p2, p3, p4) -- name: shouldRecenter
		-- upvalues: (copy) v_u_5
		if p2 <= v_u_5.JUMP_STUDS then
			return false
		elseif p1 == nil or v_u_5.SETTLED_STUDS > p1 then
			return p3 == nil or p4 - p3 >= v_u_5.DEBOUNCE_SECONDS
		else
			return false
		end
	end
}
return v_u_5