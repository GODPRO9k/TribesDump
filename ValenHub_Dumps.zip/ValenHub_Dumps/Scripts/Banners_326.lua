local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Tribes"))
local v5 = {}
local v_u_6 = require(script.Parent.Parent.Tips)
function v5.Init(p_u_7) -- name: Init
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3
	local v_u_8 = p_u_7.UI
	local v_u_9 = p_u_7.Theme
	local v_u_10 = p_u_7.State
	local v_u_11 = p_u_7.Portraits
	local v_u_12 = v_u_9.Colors
	local v_u_13 = v_u_9.Fonts
	local _ = v_u_1.LocalPlayer
	local v14 = p_u_7.Canvas.Overlay
	local v_u_15 = v_u_8.new("Frame", {
		["Name"] = "Banners",
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v14
	})
	local v_u_16 = v_u_8.DisplayText({
		["Name"] = "Slam",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["TextSize"] = 100,
		["TextColor3"] = nil,
		["StrokeThickness"] = 5,
		["Visible"] = false,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.36),
		["Size"] = UDim2.fromOffset(900, 140),
		["TextColor3"] = v_u_12.Text,
		["Parent"] = v_u_15
	})
	local v_u_17 = v_u_16:FindFirstChildOfClass("UIStroke")
	local v_u_18 = v_u_8.new("UIScale", {
		["Name"] = "Scale",
		["Parent"] = nil,
		["Parent"] = v_u_16
	})
	local v_u_19 = v_u_8.new("TextLabel", {
		["Name"] = "SlamSub",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 30,
		["TextColor3"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0.36, 66),
		["Size"] = UDim2.fromOffset(900, 40),
		["FontFace"] = v_u_13.Title,
		["TextColor3"] = v_u_12.TextDim,
		["Parent"] = v_u_15
	})
	v_u_8.TextStroke(v_u_12.Void, 2.5, 0.1).Parent = v_u_19
	local v_u_20 = 0
	local v_u_21 = false
	local v_u_22 = 0
	local v_u_23 = v_u_19:FindFirstChildOfClass("UIStroke")
	local v_u_24 = {}
	local function v_u_32(p25, p26, p27, p28) -- name: fadeTo
		-- upvalues: (copy) v_u_24, (copy) v_u_8
		local v29 = v_u_24[p25]
		if not v29 then
			v29 = {}
			v_u_24[p25] = v29
		end
		local v30 = v_u_8.Tween
		local v31 = TweenInfo.new(p28)
		table.insert(v29, v30(p25, v31, {
			[p26] = p27
		}))
	end
	local function v_u_36(...) -- name: stopFades
		-- upvalues: (copy) v_u_24
		for _, v33 in { ... } do
			local v34 = v_u_24[v33]
			if not v34 then
				continue
			end
			for _, v35 in v34 do
				v35:Cancel()
			end
			table.clear(v34)
		end
	end
	local function v_u_45(p37, p38) -- name: pinSub
		-- upvalues: (ref) v_u_22, (copy) v_u_19, (copy) v_u_12, (ref) v_u_21, (copy) v_u_36, (copy) v_u_23, (copy) v_u_8, (copy) v_u_9, (copy) v_u_32
		v_u_22 = v_u_22 + 1
		local v_u_39 = v_u_22
		if p37 then
			v_u_19.TextColor3 = p38 or v_u_12.TextDim
			if not v_u_21 or (not v_u_19.Visible or v_u_19.Text ~= p37) then
				v_u_36(v_u_19, v_u_23)
				v_u_19.Text = p37
				v_u_19.TextTransparency = 0
				v_u_23.Transparency = 0.1
				v_u_19.Visible = true
				local v40 = v_u_8.SlideIn
				local v41 = v_u_19
				local v42 = Vector2.new(0, 16)
				local v43 = v_u_9.Tween.Smooth
				local v44
				if v_u_8.Compact then
					v44 = UDim2.new(0.5, 0, 0.3, 52)
				else
					v44 = UDim2.new(0.5, 0, 0.36, 66)
				end
				v40(v41, v42, v43, v44)
			end
			v_u_21 = true
		elseif v_u_21 then
			v_u_21 = false
			v_u_32(v_u_19, "TextTransparency", 1, 0.2)
			v_u_32(v_u_23, "Transparency", 1, 0.2)
			task.delay(0.21, function()
				-- upvalues: (copy) v_u_39, (ref) v_u_22, (ref) v_u_21, (ref) v_u_19
				if v_u_39 == v_u_22 and not v_u_21 then
					v_u_19.Visible = false
				end
			end)
		end
	end
	local function v_u_58(p46, p47, p48, p49, p50) -- name: showSlam
		-- upvalues: (ref) v_u_20, (copy) v_u_36, (copy) v_u_16, (copy) v_u_17, (copy) v_u_19, (copy) v_u_23, (copy) v_u_8, (copy) v_u_18, (copy) v_u_9, (ref) v_u_21, (copy) v_u_12, (copy) v_u_32
		v_u_20 = v_u_20 + 1
		local v_u_51 = v_u_20
		v_u_36(v_u_16, v_u_17, v_u_19, v_u_23)
		v_u_16.Text = p46
		v_u_16.TextColor3 = p47
		v_u_16.Position = UDim2.fromScale(0.5, v_u_8.Compact and 0.3 or 0.36)
		local v52 = p50 == false and 0.84 or 1.2
		v_u_16.TextTransparency = 0
		v_u_17.Transparency = 0
		v_u_16.Visible = true
		v_u_18.Scale = v52 * 1.8
		v_u_8.Tween(v_u_18, v_u_9.Tween.Slam, {
			["Scale"] = v52
		})
		if not v_u_21 then
			v_u_19.Visible = p48 ~= nil
			if p48 then
				v_u_19.Text = p48
				v_u_19.TextColor3 = v_u_12.TextDim
				v_u_19.TextTransparency = 0
				v_u_23.Transparency = 0.1
				local v53 = v_u_8.SlideIn
				local v54 = v_u_19
				local v55 = Vector2.new(0, 16)
				local v56 = v_u_9.Tween.Smooth
				local v57
				if v_u_8.Compact then
					v57 = UDim2.new(0.5, 0, 0.3, 52)
				else
					v57 = UDim2.new(0.5, 0, 0.36, 66)
				end
				v53(v54, v55, v56, v57)
			end
		end
		task.delay(p49 or 0.8, function()
			-- upvalues: (copy) v_u_51, (ref) v_u_20, (ref) v_u_32, (ref) v_u_16, (ref) v_u_17, (ref) v_u_21, (ref) v_u_19, (ref) v_u_23
			if v_u_51 == v_u_20 then
				v_u_32(v_u_16, "TextTransparency", 1, 0.25)
				v_u_32(v_u_17, "Transparency", 1, 0.25)
				if not v_u_21 then
					v_u_32(v_u_19, "TextTransparency", 1, 0.25)
					v_u_32(v_u_23, "Transparency", 1, 0.25)
				end
				task.delay(0.26, function()
					-- upvalues: (ref) v_u_51, (ref) v_u_20, (ref) v_u_16, (ref) v_u_21, (ref) v_u_19
					if v_u_51 == v_u_20 then
						v_u_16.Visible = false
						if not v_u_21 then
							v_u_19.Visible = false
						end
					end
				end)
			end
		end)
	end
	local v_u_59 = nil
	local v_u_60 = 0
	local v_u_61 = {}
	local function v_u_67(p62) -- name: recordLook
		-- upvalues: (copy) v_u_61
		local v63 = p62:GetDescendants()
		table.insert(v63, p62)
		local v64 = {}
		for _, v65 in v63 do
			local v66 = {}
			if v65:IsA("GuiObject") and v65.BackgroundTransparency < 1 then
				v66.BackgroundTransparency = v65.BackgroundTransparency
			end
			if (v65:IsA("TextLabel") or v65:IsA("TextButton")) and v65.TextTransparency < 1 then
				v66.TextTransparency = v65.TextTransparency
			elseif (v65:IsA("ImageLabel") or v65:IsA("ViewportFrame")) and v65.ImageTransparency < 1 then
				v66.ImageTransparency = v65.ImageTransparency
			elseif v65:IsA("UIStroke") and v65.Transparency < 1 then
				v66.Transparency = v65.Transparency
			end
			if not next(v66) then
				continue
			end
			v64[v65] = v66
		end
		v_u_61[p62] = v64
	end
	local function v_u_74(p68, p69) -- name: setFade
		-- upvalues: (copy) v_u_61
		for v70, v71 in v_u_61[p68] or {} do
			for v72, v73 in v71 do
				v70[v72] = v73 + (1 - v73) * p69
			end
		end
	end
	local v_u_75 = require(script.Parent.Parent:WaitForChild("TribeEmblem"))
	v_u_75.Init(v_u_8)
	local v_u_76 = {}
	Color3.fromRGB(255, 214, 110)
	local function v_u_99() -- name: buildIntro
		-- upvalues: (copy) v_u_8, (copy) v_u_15, (copy) v_u_12, (copy) v_u_9, (copy) v_u_13, (copy) v_u_75, (ref) v_u_76, (copy) v_u_67
		local v77 = v_u_8.new("Frame", {
			["Name"] = "Intro",
			["Size"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v_u_15
		})
		for v78 = 1, 2 do
			local v79
			if v78 == 1 then
				v79 = v_u_12.Ally
			else
				v79 = v_u_12.Enemy
			end
			local v80 = v_u_8.new("Frame", {
				["Name"] = v78 == 1 and "Left" or "Right",
				["AnchorPoint"] = Vector2.new(v78 == 1 and 0 or 1, 0),
				["Position"] = UDim2.fromScale(v78 == 1 and 0 or 1, 0),
				["Size"] = UDim2.fromScale(0.5, 1),
				["BackgroundColor3"] = Color3.new(1, 1, 1),
				["BackgroundTransparency"] = 0.08,
				["ClipsDescendants"] = true,
				v_u_8.Gradient(v_u_9.Darken(v79, 0.45), v_u_9.Darken(v79, 0.82), v78 == 1 and 0 or 180),
				["Parent"] = v77
			})
			local v81 = v_u_8.new("Frame", {
				["Name"] = "Content",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.46),
				["Size"] = UDim2.fromOffset(560, 380),
				["Parent"] = v80
			})
			v_u_8.DisplayText({
				["Name"] = "Tribe",
				["Size"] = nil,
				["Text"] = "WOLF",
				["TextSize"] = 76,
				["TextColor3"] = nil,
				["StrokeThickness"] = 4,
				["Parent"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 80),
				["TextColor3"] = v_u_9.Lighten(v79, 0.3),
				["Parent"] = v81
			})
			local v82 = v_u_8.new("TextLabel", {
				["Name"] = "Tag",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "3 V 3",
				["FontFace"] = nil,
				["TextSize"] = 22,
				["TextColor3"] = nil,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(0, 80),
				["Size"] = UDim2.new(1, 0, 0, 30),
				["FontFace"] = v_u_13.Title,
				["TextColor3"] = v_u_12.TextDim,
				["Parent"] = v81
			})
			v_u_8.TextStroke(v_u_12.Void, 2, 0.3).Parent = v82
			local v83 = v_u_8.new("Frame", {
				["Name"] = "Fighters",
				["Position"] = UDim2.fromOffset(0, 130),
				["Size"] = UDim2.new(1, 0, 0, 220),
				v_u_8.List(Enum.FillDirection.Horizontal, 18, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Top),
				["Parent"] = v81
			})
			for v84 = 1, 3 do
				local v85 = v_u_8.new("Frame", {
					["Name"] = "F" .. v84,
					["Size"] = UDim2.fromOffset(150, 210),
					["LayoutOrder"] = v84,
					["Parent"] = v83
				})
				local v86 = v_u_8.new("Frame", {
					["Name"] = "Inner",
					["Size"] = nil,
					["Parent"] = nil,
					["Size"] = UDim2.fromScale(1, 1),
					["Parent"] = v85
				})
				v_u_8.new("ImageLabel", {
					["Name"] = "Img",
					["Size"] = UDim2.fromOffset(150, 150),
					["BackgroundColor3"] = v_u_9.Darken(v79, 0.6),
					["BackgroundTransparency"] = 0.1,
					["ScaleType"] = Enum.ScaleType.Crop,
					v_u_8.Corner(v_u_9.Radius.Pill),
					v_u_8.Stroke(v79, 3, 0),
					["Parent"] = v86
				})
				local v87 = v_u_8.new("TextLabel", {
					["Name"] = "Name",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["FontFace"] = nil,
					["TextSize"] = 21,
					["TextTruncate"] = nil,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(-10, 156),
					["Size"] = UDim2.new(1, 20, 0, 26),
					["FontFace"] = v_u_13.Heavy,
					["TextTruncate"] = Enum.TextTruncate.AtEnd,
					["Parent"] = v86
				})
				v_u_8.TextStroke(v_u_12.Void, 1.5, 0.2).Parent = v87
				v_u_8.new("TextLabel", {
					["Name"] = "Sub",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["FontFace"] = nil,
					["TextSize"] = 15,
					["TextColor3"] = nil,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(0, 182),
					["Size"] = UDim2.new(1, 0, 0, 20),
					["FontFace"] = v_u_13.Bold,
					["TextColor3"] = v_u_12.TextDim,
					["Parent"] = v86
				})
			end
		end
		v_u_8.DisplayText({
			["Name"] = "VS",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "VS",
			["TextSize"] = 110,
			["TextColor3"] = nil,
			["StrokeThickness"] = 6,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.44),
			["Size"] = UDim2.fromOffset(240, 140),
			["TextColor3"] = v_u_12.Text,
			["Parent"] = v77
		})
		local v88 = v_u_8.new("Frame", {
			["Name"] = "Map",
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, -40),
			["Size"] = UDim2.fromOffset(760, 176),
			["BackgroundColor3"] = v_u_12.Void,
			["BackgroundTransparency"] = 0.2,
			["ZIndex"] = 3,
			v_u_8.Corner(14),
			v_u_8.Stroke(v_u_12.Stroke, 2, 0.6),
			["Parent"] = v77
		})
		v_u_8.new("ImageLabel", {
			["Name"] = "Thumb",
			["Position"] = UDim2.fromOffset(9, 9),
			["Size"] = UDim2.fromOffset(280, 158),
			["BackgroundColor3"] = v_u_12.Raised,
			["ScaleType"] = Enum.ScaleType.Crop,
			["ImageTransparency"] = 1,
			["ZIndex"] = 3,
			v_u_8.Corner(10),
			["Parent"] = v88
		})
		local v89 = v_u_8.new("TextLabel", {
			["Name"] = "MapName",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 38,
			["TextXAlignment"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(306, 14),
			["Size"] = UDim2.new(1, -322, 0, 40),
			["FontFace"] = v_u_13.Display,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v88
		})
		v_u_8.TextStroke(v_u_12.Void, 2, 0.2).Parent = v89
		v_u_8.new("TextLabel", {
			["Name"] = "Mode",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "3V3 \194\183 FIRST TO 5 ROUNDS",
			["FontFace"] = nil,
			["TextSize"] = 18,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(306, 56),
			["Size"] = UDim2.new(1, -322, 0, 22),
			["FontFace"] = v_u_13.Heavy,
			["TextColor3"] = v_u_12.Accent,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v88
		})
		v_u_8.new("TextLabel", {
			["Name"] = "Tip",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 19,
			["TextColor3"] = nil,
			["TextWrapped"] = true,
			["TextXAlignment"] = nil,
			["TextYAlignment"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(306, 88),
			["Size"] = UDim2.new(1, -322, 0, 70),
			["FontFace"] = v_u_13.SemiBold,
			["TextColor3"] = v_u_12.TextDim,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextYAlignment"] = Enum.TextYAlignment.Top,
			["Parent"] = v88
		})
		local v90 = v_u_8.new("Frame", {
			["Name"] = "Clash",
			["Size"] = nil,
			["Visible"] = false,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v77
		})
		local _ = v_u_8.Image(v_u_8.Assets.Fx.Rays, {
			["Name"] = "Rays",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 1,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.4),
			["Size"] = UDim2.fromOffset(620, 620),
			["ImageColor3"] = Color3.fromRGB(255, 205, 110),
			["Parent"] = v90
		})
		local v91 = {}
		for v92 = 1, 2 do
			local v93 = {
				["ZIndex"] = 5,
				["Parent"] = nil,
				["Parent"] = v_u_8.new("Frame", {
					["Name"] = "Crest" .. v92,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.4),
					["Size"] = UDim2.fromOffset(140, 151),
					["ZIndex"] = 5,
					v_u_8.new("UIScale", {
						["Name"] = "Fit"
					}),
					["Parent"] = v90
				})
			}
			v91[v92] = v_u_75.new(140, v93)
		end
		local _ = v_u_8.Image(v_u_8.Assets.Fx.Flare, {
			["Name"] = "Flare",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 1,
			["ZIndex"] = 6,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.4),
			["Size"] = UDim2.fromOffset(1100, 120),
			["ImageColor3"] = Color3.fromRGB(255, 220, 150),
			["Parent"] = v90
		})
		local _ = v_u_8.Image(v_u_8.Assets.Fx.Ring, {
			["Name"] = "Ring",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 1,
			["ZIndex"] = 6,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.4),
			["Size"] = UDim2.fromOffset(60, 60),
			["ImageColor3"] = Color3.fromRGB(255, 214, 140),
			["Parent"] = v90
		})
		for v94 = 1, 8 do
			v_u_8.Image(v_u_8.Assets.Fx.Spark, {
				["Name"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ImageColor3"] = nil,
				["ImageTransparency"] = 1,
				["ZIndex"] = 6,
				["Parent"] = nil,
				["Name"] = "Spark" .. v94,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.4),
				["Size"] = UDim2.fromOffset(96, 18),
				["ImageColor3"] = Color3.fromRGB(255, 226, 160),
				["Parent"] = v90
			})
		end
		local v95 = v_u_8.DisplayText({
			["Name"] = "Title",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "TRIBE CLASH",
			["TextSize"] = 84,
			["TextColor3"] = nil,
			["StrokeThickness"] = 5,
			["ZIndex"] = 7,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.1),
			["Size"] = UDim2.fromOffset(900, 100),
			["TextColor3"] = Color3.fromRGB(255, 214, 110),
			["Parent"] = v90
		})
		v_u_8.Gradient(Color3.fromRGB(255, 236, 170), Color3.fromRGB(240, 170, 50), 90).Parent = v95
		local v96 = v_u_8.new("TextLabel", {
			["Name"] = "Sub",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 22,
			["TextColor3"] = nil,
			["ZIndex"] = 7,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0.1, 50),
			["Size"] = UDim2.fromOffset(900, 26),
			["FontFace"] = v_u_13.Heavy,
			["TextColor3"] = v_u_12.Text,
			["Parent"] = v90
		})
		v_u_8.TextStroke(v_u_12.Void, 2, 0.25).Parent = v96
		v_u_8.new("Frame", {
			["Name"] = "Flash",
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 1,
			["ZIndex"] = 8,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.fromRGB(255, 206, 120),
			["Parent"] = v90
		})
		v_u_76 = v91
		v_u_67((v90:FindFirstChild("Crest" .. 1)))
		v_u_67((v90:FindFirstChild("Crest" .. 2)))
		v_u_67(v95)
		v_u_67((v77:FindFirstChild("VS")))
		v_u_67((v77:FindFirstChild("Map")))
		for _, v97 in { v77:FindFirstChild("Left"), v77:FindFirstChild("Right") } do
			for v98 = 1, 3 do
				v_u_67((v97:FindFirstChild("Content"):FindFirstChild("Fighters"):FindFirstChild("F" .. v98):FindFirstChild("Inner")))
			end
		end
		return v77
	end
	local function v_u_108(p100) -- name: teamTribe
		local v101 = {}
		local v102 = nil
		local v103
		if type(p100) == "table" then
			local v104 = p100.members
			v103 = type(v104) ~= "table" and {} or p100.members
		else
			v103 = {}
		end
		for _, v105 in v103 do
			local v106 = v105.tribe
			if type(v106) ~= "table" then
				continue
			end
			local v107 = v106.id
			if type(v107) ~= "number" then
				continue
			end
			v101[v106.id] = (v101[v106.id] or 0) + 1
			if v101[v106.id] < 2 then
				continue
			end
			v102 = v106
		end
		return v102
	end
	local function v_u_177(p109, p110) -- name: fillIntro
		-- upvalues: (copy) v_u_10, (copy) v_u_108, (copy) v_u_12, (ref) v_u_4, (copy) v_u_9, (copy) v_u_11, (copy) v_u_8, (copy) p_u_7, (ref) v_u_6, (ref) v_u_76
		local v111 = p110.teams
		local v112 = type(v111) == "table" and p110.teams or (v_u_10.Match and v_u_10.Match.teams or {})
		local v113 = v_u_10.MyTeam()
		local v114 = { v_u_108(v112[v113]), (v_u_108(v112[3 - v113])) }
		local v115
		if v114[1] == nil or v114[2] == nil then
			v115 = false
		else
			v115 = v114[1].id ~= v114[2].id
		end
		p109:SetAttribute("Clash", v115)
		for v116, v117 in { v113, 3 - v113 } do
			local v118 = p109:FindFirstChild(v116 == 1 and "Left" or "Right")
			local v119 = v118:FindFirstChild("Content")
			local v120 = v112[v117] or {}
			local v121 = v119:FindFirstChild("Tribe")
			local v122
			if v116 == 1 then
				v122 = v_u_12.Ally
			else
				v122 = v_u_12.Enemy
			end
			local v123
			if v115 then
				v123 = v_u_4.Color(v114[v116].color1)
			else
				v123 = v122
			end
			local v124 = v118:FindFirstChildOfClass("UIGradient")
			if v124 then
				v124.Color = ColorSequence.new(v_u_9.Darken(v123, 0.45), v_u_9.Darken(v123, 0.82))
			end
			local v125
			if v115 then
				local v126 = string.upper
				local v127 = v114[v116].name or v114[v116].tag
				v125 = v126((tostring(v127)))
			else
				v125 = v116 == 1 and "YOUR TEAM" or "ENEMY TEAM"
			end
			v121.Text = v125
			v121.TextColor3 = v_u_9.Lighten(v123, 0.3)
			local v128 = v119:FindFirstChild("Tag")
			if v128 then
				if v128:GetAttribute("Default") == nil then
					v128:SetAttribute("Default", v128.Text)
				end
				local v129 = v114[v116]
				if v115 then
					local v130 = v129.tag
					v128.Text = "[" .. tostring(v130) .. "]  \194\183  " .. (v116 == 1 and "YOUR TRIBE" or "ENEMY TRIBE")
					v128.TextColor3 = v_u_9.Lighten(v122, 0.35)
				else
					local v131
					if v129 then
						local v132 = v129.tag
						v131 = "TRIBE  [" .. tostring(v132) .. "]"
					else
						v131 = tostring(v128:GetAttribute("Default"))
					end
					v128.Text = v131
					local v133
					if v129 then
						v133 = v_u_4.TextColor(v129.color1)
					else
						v133 = v_u_12.TextDim
					end
					v128.TextColor3 = v133
				end
			end
			local v134 = v119:FindFirstChild("Fighters")
			for v135 = 1, 3 do
				local v136 = v134:FindFirstChild("F" .. v135)
				local v137 = v136:FindFirstChild("Inner")
				local v138 = v120.members
				local v139
				if type(v138) == "table" then
					v139 = v120.members[v135] or nil
				else
					v139 = nil
				end
				v136.Visible = v139 ~= nil
				if not v139 then
					continue
				end
				local v140 = v137:FindFirstChild("Img")
				v_u_11.Apply(v140, v139, 150)
				local v141 = v137:FindFirstChild("Name")
				local v142 = v139.tribe
				local v143
				if type(v142) == "table" then
					local v144 = v139.tribe.tag
					v143 = type(v144) ~= "string" and "" or "[" .. v139.tribe.tag .. "] "
				else
					v143 = ""
				end
				local v145 = v139.name or "?"
				v141.Text = v143 .. tostring(v145)
				local v146
				if v139.id == v_u_10.MyId() then
					v146 = v_u_12.Accent
				else
					v146 = v_u_12.Text
				end
				v141.TextColor3 = v146
				local v147 = v137:FindFirstChild("Sub")
				local v148 = v139.level or 1
				v147.Text = "LEVEL " .. tostring(v148)
			end
		end
		local v149 = p109:FindFirstChild("Map")
		local v150 = v149:FindFirstChild("MapName")
		local v151 = string.upper
		local v152 = p110.mapName or (v_u_10.Match and v_u_10.Match.mapName or "ARENA")
		v150.Text = v151((tostring(v152)))
		local v_u_153 = v149:FindFirstChild("Thumb")
		local v154 = not p110.mapThumb and v_u_10.Match
		if v154 then
			v154 = v_u_10.Match.mapThumb
		end
		local v155 = v_u_8.Compact
		local v156 = v155 and 200 or 280
		local v157 = v155 and 112 or 158
		v149.Size = UDim2.fromOffset(v155 and 640 or 760, v157 + 18)
		v149.Position = UDim2.new(0.5, 0, 1, v155 and -14 or -40)
		v_u_153.Size = UDim2.fromOffset(v156, v157)
		v_u_153.Image = type(v154) ~= "string" and "" or v154
		v_u_153.Visible = v_u_153.Image ~= ""
		if v_u_153.Visible then
			if v_u_153.IsLoaded then
				v_u_153.ImageTransparency = 0
			else
				v_u_153.ImageTransparency = 1
				task.spawn(function()
					-- upvalues: (ref) p_u_7, (copy) v_u_153, (ref) v_u_8, (ref) v_u_9
					p_u_7.PreloadThumb(v_u_153.Image, true)
					if v_u_153.Image ~= "" then
						v_u_8.Tween(v_u_153, v_u_9.Tween.Smooth, {
							["ImageTransparency"] = 0
						})
					end
				end)
			end
		end
		local v158 = v_u_153.Visible
		local v159 = not v158 and 16 or v156 + 26
		for _, v160 in { "MapName", "Mode", "Tip" } do
			local v161 = v149:FindFirstChild(v160)
			v161.Position = UDim2.fromOffset(v159, v161.Position.Y.Offset)
			v161.Size = UDim2.new(1, -(v159 + 16), 0, v161.Size.Y.Offset)
			local v162
			if v158 then
				v162 = Enum.TextXAlignment.Left
			else
				v162 = Enum.TextXAlignment.Center
			end
			v161.TextXAlignment = v162
		end
		local v163 = v149:FindFirstChild("Tip")
		v163.Text = "TIP  \194\183  " .. v_u_6.Next()
		v163.Size = UDim2.new(1, -(v159 + 16), 0, v157 - 80)
		v163.TextSize = v155 and 17 or 19
		local v164
		if p110 then
			v164 = p110.roundsToWin
		else
			v164 = p110
		end
		local v165 = tonumber(v164) or v_u_10.RoundsToWin()
		local v166
		if p110 then
			v166 = p110.holder
		else
			v166 = p110
		end
		local v167
		if type(v166) == "table" then
			local v168 = v166.tag
			v167 = type(v168) ~= "string" and "" or "  \194\183  HELD BY [" .. v166.tag .. "]"
		else
			v167 = ""
		end
		v149:FindFirstChild("Mode").Text = string.format("3V3  \194\183  BEST OF %d%s", v165 * 2 - 1, v167)
		local v169 = p109:FindFirstChild("Clash")
		v169.Visible = v115
		if v115 then
			local v170 = v114[1]
			v_u_76[1]:Set(v170.icon, v170.color1, v170.color2, v170.tag)
			local v171 = v114[2]
			v_u_76[2]:Set(v171.icon, v171.color1, v171.color2, v171.tag)
			local v172 = string.upper
			local v173 = p110.mapName or (v_u_10.Match and v_u_10.Match.mapName or "this map")
			local v174 = v172((tostring(v173)))
			local v175 = v169:FindFirstChild("Sub")
			local v176 = p_u_7.Custom and p_u_7.Custom.IsServer
			if v176 then
				v176 = p_u_7.Custom.IsServer()
			end
			if v176 then
				v175.Text = "CUSTOM MATCH  \194\183  NO GLORY AT STAKE"
				return
			end
			if type(v166) == "table" and (v166.id == v114[1].id or v166.id == v114[2].id) then
				v175.Text = ("[%*] DEFENDS %*"):format(v166.tag, v174)
				return
			end
			if type(v166) == "table" then
				v175.Text = ("%*  \194\183  HELD BY [%*]"):format(v174, v166.tag)
				return
			end
			v175.Text = ("GLORY DECIDES WHO HOLDS %*"):format(v174)
		end
	end
	local v_u_178 = nil
	local function v_u_183(p179) -- name: lookLock
		-- upvalues: (ref) v_u_178, (ref) v_u_2
		if v_u_178 == nil then
			local v_u_180 = v_u_2:WaitForChild("Shared"):FindFirstChild("Camera")
			local v181, v182 = pcall(function()
				-- upvalues: (copy) v_u_180
				if v_u_180 then
					return require(v_u_180)
				else
					return nil
				end
			end)
			if not v181 or type(v182) ~= "table" then
				v182 = false
			end
			v_u_178 = v182
		end
		if v_u_178 and v_u_178.PushLookLock then
			if p179 then
				v_u_178.PushLookLock("Intro")
				return
			end
			v_u_178.PopLookLock("Intro")
		end
	end
	local function v_u_188(p184) -- name: newClashState
		local v185 = Random.new(p184 or os.clock() * 1000)
		local v186 = {}
		for v187 = 1, 8 do
			v186[v187] = {
				["a"] = (v187 - 1) / 8 * 3.141592653589793 * 2 + v185:NextNumber(-0.25, 0.25),
				["d"] = v185:NextNumber(170, 260),
				["dur"] = v185:NextNumber(0.35, 0.5)
			}
		end
		return {
			["sparks"] = v186
		}
	end
	local function v_u_253(p189, p190, p191, p192) -- name: clashLook
		-- upvalues: (copy) v_u_8, (ref) v_u_76, (copy) v_u_74
		local v193 = p189:FindFirstChild("Clash")
		local v194 = v_u_8.Compact
		local v195 = p190 - 0.45
		local v196 = v194 and 0.085 or 0.4
		local v197 = v194 and 28 or 56
		local v198 = v194 and 232 or 80
		for v199 = 1, 2 do
			local v200 = v193:FindFirstChild("Crest" .. v199)
			local v201 = v199 == 1 and -1 or 1
			local v202 = UDim2.new(v201 * 0.62 + 0.5, 0, v196, 0)
			local v203 = UDim2.new(0.5, v201 * v197, v196, 0)
			local v204 = UDim2.new(0.5, v201 * v198, v196, 0)
			if v195 < 0 then
				local v205 = (p190 - 0.09) / 0.36
				local v206 = math.clamp(v205, 0, 1)
				local v207 = v206 * v206
				v200.Position = v202:Lerp(v203, v207)
				v200.Rotation = v201 * 18 * (1 - v207)
			else
				local v208 = v195 / 0.45
				v200.Position = v203:Lerp(v204, 1 - (1 - math.clamp(v208, 0, 1)) ^ 5)
				v200.Rotation = 0
			end
			v200:FindFirstChild("Fit").Scale = v194 and 0.5 or 1
			local v209 = v_u_8.GetScaleObj(v_u_76[v199].Instance)
			local v210
			if v195 < 0 then
				v210 = 1
			else
				local v211 = v195 / 0.35
				local v212 = math.clamp(v211, 0, 1) - 1
				v210 = (v212 * 2.70158 * v212 * v212 + 1 + v212 * 1.70158 * v212) * -0.17999999999999994 + 1.18
			end
			v209.Scale = v210
			v_u_74(v200, p191)
		end
		local v213 = v193:FindFirstChild("Flash")
		local v214
		if v195 < 0 then
			v214 = 1
		else
			local v215 = v195 / 0.32
			local v216 = math.clamp(v215, 0, 1)
			v214 = 1 - (1 - ((1 - (1 - v216) * (1 - v216)) * 0.5 + 0.5)) * (1 - p191)
		end
		v213.BackgroundTransparency = v214
		local v217 = v193:FindFirstChild("Ring")
		local v218 = v195 / 0.55
		local v219 = 1 - (1 - math.clamp(v218, 0, 1)) ^ 4
		local v220 = v194 and 380 or 640
		v217.Position = UDim2.fromScale(0.5, v196)
		v217.Size = UDim2.fromOffset((v220 - 60) * v219 + 60, (v220 - 60) * v219 + 60)
		v217.ImageTransparency = v195 < 0 and 1 or 1 - (1 - (v219 * 0.95 + 0.05)) * (1 - p191)
		local v221 = v193:FindFirstChild("Flare")
		local v222 = v195 / 0.5
		local v223 = 1 - (1 - math.clamp(v222, 0, 1)) ^ 4
		v221.Position = UDim2.fromScale(0.5, v196)
		v221.Size = UDim2.fromOffset(v223 * 1060 + 240, v223 * 40 + 90)
		v221.ImageTransparency = v195 < 0 and 1 or 1 - (1 - v223) * (1 - p191)
		for v224, v225 in p192.sparks do
			local v226 = v193:FindFirstChild("Spark" .. v224)
			local v227 = v195 / v225.dur
			local v228 = 1 - (1 - math.clamp(v227, 0, 1)) ^ 4
			local v229 = v225.d * (v194 and 0.6 or 1) * v228
			local v230 = v225.a
			v226.Rotation = math.deg(v230)
			local v231 = UDim2.new
			local v232 = v225.a
			local v233 = math.cos(v232) * v229
			local v234 = v225.a
			v226.Position = v231(0.5, v233, v196, math.sin(v234) * v229)
			v226.Size = UDim2.fromOffset(v228 * -70 + 110, v228 * -10 + 18)
			v226.ImageTransparency = v195 < 0 and 1 or 1 - (1 - v228) * (1 - p191)
		end
		local v235 = Vector2.zero
		if v195 >= 0 and v195 < 0.14 then
			local v236 = {
				Vector2.new(10, -6),
				Vector2.new(-8, 5),
				Vector2.new(5, 3),
				Vector2.new(-3, -2)
			}
			local v237 = v195 / 0.035
			v235 = v236[math.floor(v237) + 1]
		end
		p189.Position = UDim2.fromOffset(v235.X, v235.Y)
		local v238 = v193:FindFirstChild("Rays")
		v238.Position = UDim2.fromScale(0.5, v196)
		local v239
		if v194 then
			v239 = UDim2.fromOffset(380, 380)
		else
			v239 = UDim2.fromOffset(620, 620)
		end
		v238.Size = v239
		local v240
		if v195 < 0 then
			v240 = 1
		else
			local v241 = v195 / 0.6
			local v242 = math.clamp(v241, 0, 1)
			v240 = 1 - (1 - ((1 - (1 - v242) * (1 - v242)) * 0.20000000000000007 + 0.35)) * (1 - p191)
		end
		v238.ImageTransparency = v240
		local v243 = v195 / 6
		v238.Rotation = math.clamp(v243, 0, 1) * 40
		local v244 = v193:FindFirstChild("Title")
		v244.Visible = v195 >= 0
		v244.Position = UDim2.fromScale(0.5, v194 and 0.085 or 0.1)
		v244.TextSize = v194 and 54 or 84
		local v245 = v_u_8.GetScaleObj(v244)
		local v246 = v195 / 0.28
		local v247 = math.clamp(v246, 0, 1) - 1
		v245.Scale = (v247 * 2.70158 * v247 * v247 + 1 + v247 * 1.70158 * v247) * -1.2000000000000002 + 2.2
		v_u_74(v244, p191)
		local v248 = v193:FindFirstChild("Sub")
		v248.Visible = not v194
		local v249 = (v195 - 0.15) / 0.3
		local v250 = math.clamp(v249, 0, 1)
		local v251 = 1 - (1 - v250) * (1 - v250)
		v248.TextTransparency = 1 - (1 - (1 - v251)) * (1 - p191)
		local v252 = v248:FindFirstChildOfClass("UIStroke")
		if v252 then
			v252.Transparency = 1 - (1 - (v251 * -0.75 + 1)) * (1 - p191)
		end
	end
	local v_u_254 = nil
	local function v_u_264(p_u_255) -- name: playClash
		-- upvalues: (ref) v_u_254, (copy) v_u_188, (copy) p_u_7, (ref) v_u_3, (copy) v_u_253
		if v_u_254 then
			v_u_254.conn:Disconnect()
			v_u_254 = nil
		end
		local v_u_256 = v_u_188()
		local v_u_257 = os.clock()
		local v_u_258 = false
		p_u_7.Sounds.Play("UI/Whoosh")
		local v_u_259 = {}
		v_u_259.conn = v_u_3.RenderStepped:Connect(function()
			-- upvalues: (copy) v_u_257, (ref) v_u_258, (ref) p_u_7, (copy) v_u_259, (ref) v_u_253, (copy) p_u_255, (copy) v_u_256, (ref) v_u_254
			local v260 = os.clock()
			local v261 = v260 - v_u_257
			if not v_u_258 and v261 >= 0.45 then
				v_u_258 = true
				p_u_7.Sounds.Play("Match/Tribe_Clash")
			end
			local v262
			if v_u_259.outAt then
				local v263 = (v260 - v_u_259.outAt) / 0.2
				v262 = math.clamp(v263, 0, 1)
			else
				v262 = 0
			end
			v_u_253(p_u_255, v261, v262, v_u_256)
			if v262 >= 1 and v_u_254 then
				v_u_254.conn:Disconnect()
				v_u_254 = nil
			end
		end)
		v_u_254 = v_u_259
		v_u_253(p_u_255, 0, 0, v_u_256)
	end
	local function v_u_270(p265) -- name: hideIntro
		-- upvalues: (ref) v_u_60, (copy) v_u_183, (ref) v_u_59, (copy) p_u_7, (ref) v_u_254, (copy) v_u_8
		v_u_60 = v_u_60 + 1
		v_u_183(false)
		local v_u_266 = v_u_59
		if v_u_266 and v_u_266.Visible then
			p_u_7.SetHudHidden("Intro", false)
			if p265 then
				if v_u_254 then
					v_u_254.conn:Disconnect()
					v_u_254 = nil
				end
				v_u_266.Visible = false
			else
				local v_u_267 = v_u_60
				local v268 = v_u_266:FindFirstChild("Left")
				local v269 = v_u_266:FindFirstChild("Right")
				v_u_8.Tween(v268, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					["Position"] = UDim2.fromScale(-0.55, 0)
				})
				v_u_8.Tween(v269, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
					["Position"] = UDim2.fromScale(1.55, 0)
				})
				v_u_8.FadeOut(v_u_266:FindFirstChild("VS"), TweenInfo.new(0.2))
				v_u_8.FadeOut(v_u_266:FindFirstChild("Map"), TweenInfo.new(0.2))
				if v_u_254 then
					v_u_254.outAt = os.clock()
				end
				task.delay(0.36, function()
					-- upvalues: (copy) v_u_267, (ref) v_u_60, (copy) v_u_266
					if v_u_267 == v_u_60 then
						v_u_266.Visible = false
					end
				end)
			end
		else
			return
		end
	end
	local function v_u_286(p271) -- name: showIntro
		-- upvalues: (ref) v_u_59, (copy) v_u_99, (copy) v_u_177, (ref) v_u_60, (copy) p_u_7, (copy) v_u_183, (copy) v_u_8, (copy) v_u_264, (copy) v_u_9, (copy) v_u_10, (copy) v_u_270
		v_u_59 = v_u_59 or v_u_99()
		local v272 = v_u_59
		v_u_177(v272, p271)
		v_u_60 = v_u_60 + 1
		local v_u_273 = v_u_60
		v272.Visible = true
		p_u_7.SetHudHidden("Intro", true)
		v_u_183(true)
		local v274 = v272:FindFirstChild("Left")
		local v275 = v272:FindFirstChild("Right")
		v274.Position = UDim2.fromScale(-0.55, 0)
		v275.Position = UDim2.fromScale(1.55, 0)
		v_u_8.Tween(v274, TweenInfo.new(0.45, Enum.EasingStyle.Quint), {
			["Position"] = UDim2.fromScale(0, 0)
		})
		v_u_8.Tween(v275, TweenInfo.new(0.45, Enum.EasingStyle.Quint), {
			["Position"] = UDim2.fromScale(1, 0)
		})
		local v_u_276 = v272:FindFirstChild("VS")
		v_u_8.Unfade(v_u_276)
		v_u_276.Visible = false
		if v272:GetAttribute("Clash") == true then
			v_u_264(v272)
		else
			task.delay(0.35, function()
				-- upvalues: (copy) v_u_273, (ref) v_u_60, (copy) v_u_276, (ref) v_u_8, (ref) v_u_9
				if v_u_273 == v_u_60 then
					v_u_276.Visible = true
					v_u_8.Pop(v_u_276, 2.4, v_u_9.Tween.Slam)
				end
			end)
		end
		local v277 = v272:FindFirstChild("Map")
		v_u_8.Unfade(v277)
		v_u_8.Enter(v277, Vector2.new(0, 40), 0.5)
		for v278 = 1, 2 do
			local v279
			if v278 == 1 then
				v279 = v274
			else
				v279 = v275
			end
			local v280 = v279:FindFirstChild("Content"):FindFirstChild("Fighters")
			for v281 = 1, 3 do
				local v282 = v280:FindFirstChild("F" .. v281):FindFirstChild("Inner")
				v_u_8.Unfade(v282)
				v_u_8.Enter(v282, Vector2.new(0, 30), v281 * 0.08 + 0.2, UDim2.new())
			end
		end
		local v283 = v_u_10.Match and v_u_10.Match.phase == "Intro" and (v_u_10.Match.phaseEndsAt or 0) or 0
		local v284
		if v283 > 0 then
			local v285 = v283 - v_u_10.Now()
			v284 = math.clamp(v285, 1.5, 6)
		else
			v284 = 4
		end
		task.delay(v284 - 0.3, function()
			-- upvalues: (copy) v_u_273, (ref) v_u_60, (ref) v_u_270
			if v_u_273 == v_u_60 then
				v_u_270()
			end
		end)
	end
	local v_u_287 = nil
	function p_u_7.Debug.introScrub(p288, p289, p290)
		-- upvalues: (ref) v_u_254, (ref) v_u_60, (ref) v_u_59, (copy) v_u_99, (copy) v_u_177, (ref) v_u_287, (copy) v_u_188, (copy) v_u_8, (copy) v_u_74, (copy) v_u_253, (copy) p_u_7
		if type(p288) == "table" then
			if v_u_254 then
				v_u_254.conn:Disconnect()
				v_u_254 = nil
			end
			v_u_60 = v_u_60 + 1
			v_u_59 = v_u_59 or v_u_99()
			v_u_177(v_u_59, p288)
			v_u_59.Visible = true
			v_u_287 = v_u_188(7)
		end
		local v291 = v_u_59
		if not v291 or type(p289) ~= "number" then
			return false
		end
		local v292 = type(p290) ~= "number" and 3 or p290
		local v293 = v292 - 0.3
		local v294 = v291:GetAttribute("Clash") == true
		local v295 = p289 / 0.45
		local v296 = 1 - (1 - math.clamp(v295, 0, 1)) ^ 5
		local v297 = (p289 - v293) / 0.35
		local v298 = math.clamp(v297, 0, 1)
		local v299 = v298 * v298
		v291:FindFirstChild("Left").Position = UDim2.fromScale(v296 * 0.55 + -0.55 - v299 * 0.55, 0)
		v291:FindFirstChild("Right").Position = UDim2.fromScale(v296 * -0.55 + 1.55 + v299 * 0.55, 0)
		local v300 = (p289 - v293) / 0.2
		local v301 = math.clamp(v300, 0, 1)
		local v302 = v291:FindFirstChild("VS")
		local v303 = not v294
		if v303 then
			v303 = p289 >= 0.35
		end
		v302.Visible = v303
		local v304 = v_u_8.GetScaleObj(v302)
		local v305 = (p289 - 0.35) / 0.28
		local v306 = math.clamp(v305, 0, 1) - 1
		v304.Scale = (v306 * 2.70158 * v306 * v306 + 1 + v306 * 1.70158 * v306) * -1.4 + 2.4
		v_u_74(v302, v301)
		local v307 = v291:FindFirstChild("Map")
		local v308 = UDim2.new
		local v309 = v_u_8.Compact and -14 or -40
		local v310 = (p289 - 0.5) / 0.36
		local v311 = math.clamp(v310, 0, 1) - 1
		v307.Position = v308(0.5, 0, 1, v309 + (1 - (v311 * 2.70158 * v311 * v311 + 1 + v311 * 1.70158 * v311)) * 40)
		local v312 = (p289 - 0.5) / 0.2
		local v313 = math.clamp(v312, 0, 1)
		local v314 = 1 - (1 - (1 - v313) * (1 - v313))
		local v315 = math.max(v314, v301)
		v_u_74(v307, v315)
		local v316 = v307:FindFirstChild("Thumb")
		if v316.Image ~= "" then
			v316.ImageTransparency = v315
		end
		for v317 = 1, 2 do
			local v318 = v291:FindFirstChild(v317 == 1 and "Left" or "Right"):FindFirstChild("Content"):FindFirstChild("Fighters")
			for v319 = 1, 3 do
				local v320 = v318:FindFirstChild("F" .. v319):FindFirstChild("Inner")
				local v321 = v319 * 0.08 + 0.2
				local v322 = UDim2.fromOffset
				local v323 = (p289 - v321) / 0.36
				local v324 = math.clamp(v323, 0, 1) - 1
				v320.Position = v322(0, (1 - (v324 * 2.70158 * v324 * v324 + 1 + v324 * 1.70158 * v324)) * 30)
				local v325 = v_u_74
				local v326 = (p289 - v321) / 0.2
				local v327 = math.clamp(v326, 0, 1)
				v325(v320, 1 - (1 - (1 - v327) * (1 - v327)))
			end
		end
		if v294 and v_u_287 then
			local v328 = v_u_253
			local v329 = (p289 - v293) / 0.2
			v328(v291, p289, math.clamp(v329, 0, 1), v_u_287)
		else
			v291.Position = UDim2.new()
		end
		v291.Visible = p289 < v292 + 0.06
		p_u_7.SetHudHidden("Intro", p289 < v293)
		return true
	end
	local v_u_330 = 8
	local v_u_331 = v_u_2:FindFirstChild("Shared")
	if v_u_331 then
		v_u_331 = v_u_2.Shared:FindFirstChild("Config")
	end
	local v332, v333 = pcall(function()
		-- upvalues: (copy) v_u_331
		if v_u_331 then
			return require(v_u_331)
		else
			return nil
		end
	end)
	if v332 and type(v333) == "table" then
		local v334 = v333.PRE_ROUND_TIME
		if type(v334) == "number" then
			local v335 = v333.PRE_ROUND_TIME
			local v336 = math.floor(v335)
			v_u_330 = math.clamp(v336, 3, 9)
		end
	end
	local v_u_337 = v_u_8.new("Frame", {
		["Name"] = "Countdown",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, v_u_8.Compact and 0.3 or 0.36),
		["Size"] = UDim2.fromOffset(700, 200),
		["Parent"] = v_u_15
	})
	local function v342(p338, p339) -- name: cdLabel
		-- upvalues: (copy) v_u_8, (copy) v_u_13, (copy) v_u_337, (copy) v_u_12
		local v340 = v_u_8.new("TextLabel", {
			["Name"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 100,
			["TextColor3"] = nil,
			["TextTransparency"] = 1,
			["Visible"] = false,
			["Parent"] = nil,
			["Name"] = p338,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(700, 130),
			["FontFace"] = v_u_13.Display,
			["TextColor3"] = p339,
			["Parent"] = v_u_337
		})
		local v341 = v_u_8.TextStroke(v_u_12.Void, 2, 1)
		v341.Parent = v340
		return {
			["label"] = nil,
			["stroke"] = nil,
			["scale"] = nil,
			["text"] = "",
			["a"] = 0,
			["s"] = 1,
			["y"] = 0,
			["on"] = false,
			["label"] = v340,
			["stroke"] = v341,
			["scale"] = v_u_8.new("UIScale", {
				["Name"] = "Scale",
				["Parent"] = nil,
				["Parent"] = v340
			})
		}
	end
	local v_u_343 = v342("DigitOdd", v_u_12.Bone)
	local v_u_344 = v342("DigitEven", v_u_12.Bone)
	local v_u_345 = {
		tostring(1),
		tostring(2),
		tostring(3),
		tostring(4),
		tostring(5),
		tostring(6),
		tostring(7),
		tostring(8),
		tostring(9)
	}
	v_u_8.LayoutChanged:Connect(function()
		-- upvalues: (copy) v_u_337, (copy) v_u_8
		v_u_337.Position = UDim2.fromScale(0.5, v_u_8.Compact and 0.3 or 0.36)
	end)
	local v_u_346 = v342("Fight", v_u_12.Accent)
	v_u_346.label.Text = "FIGHT!"
	v_u_346.text = "FIGHT!"
	local function v_u_356(p347, p348, p349, p350, p351) -- name: put
		if p349 <= 0.004 then
			if p347.on then
				p347.on = false
				p347.label.Visible = false
			end
		else
			if p347.text ~= p348 then
				p347.text = p348
				p347.label.Text = p348
			end
			local v352 = p347.a - p349
			if math.abs(v352) > 0.003 or not p347.on then
				p347.a = p349
				p347.label.TextTransparency = 1 - p349
				p347.stroke.Transparency = 1 - p349 * 0.85
			end
			local v353 = p347.s - p350
			if math.abs(v353) > 0.0008 or not p347.on then
				p347.s = p350
				p347.scale.Scale = p350
			end
			local v354 = p351 + 0.5
			local v355 = math.floor(v354)
			if p347.y ~= v355 or not p347.on then
				p347.y = v355
				p347.label.Position = UDim2.new(0.5, 0, 0.5, v355)
			end
			if not p347.on then
				p347.on = true
				p347.label.Visible = true
			end
		end
	end
	local function v_u_367(p357) -- name: digitLook
		if p357 < 0 then
			return 0, 1, 0
		end
		if p357 < 0.2 then
			local v358 = p357 / 0.06
			local v359 = math.min(1, v358)
			local v360 = p357 / 0.2 - 1
			return v359, 1.4 - (v360 * 2.5 * v360 * v360 + 1 + v360 * 1.5 * v360) * 0.4, 0
		end
		if p357 < 0.84 then
			return 1, 1 - (p357 - 0.2) * 0.03 / 0.6399999999999999, 0
		end
		local v361 = (p357 - 0.84) / 0.22
		local v362 = math.min(1, v361)
		local v363 = 1 - v362 * v362
		local v364 = 1 - v362
		local v365 = 0.97 - (1 - v364 * v364 * v364) * 0.2
		local v366 = 1 - v362
		return v363, v365, (1 - v366 * v366 * v366) * -14
	end
	local v_u_368 = nil
	local v_u_369 = 0
	local v_u_370 = 1
	local v_u_371 = false
	local v_u_372 = 0
	local v_u_373 = 0
	local v_u_374 = false
	local function v_u_380(p375) -- name: cdStop
		-- upvalues: (ref) v_u_368, (ref) v_u_371, (ref) v_u_374, (copy) p_u_7, (copy) v_u_343, (copy) v_u_344, (copy) v_u_346, (copy) v_u_337, (ref) v_u_21, (ref) v_u_22, (copy) v_u_36, (copy) v_u_19, (copy) v_u_23, (copy) v_u_32
		if v_u_368 and (v_u_371 and (not v_u_374 and p_u_7.Decider)) then
			p_u_7.Decider.Stop(false)
		end
		v_u_368 = nil
		local v376 = v_u_343
		if v376.on then
			v376.on = false
			v376.label.Visible = false
		end
		local v377 = v_u_344
		if v377.on then
			v377.on = false
			v377.label.Visible = false
		end
		local v378 = v_u_346
		if v378.on then
			v378.on = false
			v378.label.Visible = false
		end
		v_u_337.Visible = false
		if p375 then
			v_u_21 = false
			v_u_22 = v_u_22 + 1
			v_u_36(v_u_19, v_u_23)
			v_u_19.Visible = false
		else
			v_u_22 = v_u_22 + 1
			local v_u_379 = v_u_22
			if v_u_21 then
				v_u_21 = false
				v_u_32(v_u_19, "TextTransparency", 1, 0.2)
				v_u_32(v_u_23, "Transparency", 1, 0.2)
				task.delay(0.21, function()
					-- upvalues: (copy) v_u_379, (ref) v_u_22, (ref) v_u_21, (ref) v_u_19
					if v_u_379 == v_u_22 and not v_u_21 then
						v_u_19.Visible = false
					end
				end)
			end
		end
	end
	local function v_u_388() -- name: cdOnShow
		-- upvalues: (ref) v_u_371, (copy) p_u_7, (ref) v_u_370, (copy) v_u_10, (copy) v_u_45, (copy) v_u_12
		if v_u_371 then
			p_u_7.Decider.Intro(v_u_370)
		else
			local v381 = v_u_10.Match
			local v382 = v_u_10.RoundsToWin()
			local v383 = false
			if v381 then
				local v384 = (v381.teams[1].score or 0) >= v382 - 1 and true or v383
				v383 = (v381.teams[2].score or 0) >= v382 - 1 and true or v384
			end
			local v385 = v_u_45
			local v386 = v383 and "MATCH POINT" or "ROUND " .. v_u_370
			local v387
			if v383 then
				v387 = v_u_12.Warning
			else
				v387 = v_u_12.TextDim
			end
			v385(v386, v387)
		end
	end
	local function v_u_425() -- name: cdFrame
		-- upvalues: (copy) v_u_10, (ref) v_u_368, (ref) v_u_370, (ref) v_u_369, (ref) v_u_372, (ref) v_u_373, (ref) v_u_374, (ref) v_u_371, (copy) p_u_7, (ref) v_u_20, (copy) v_u_36, (copy) v_u_16, (copy) v_u_17, (ref) v_u_21, (copy) v_u_19, (copy) v_u_343, (copy) v_u_344, (copy) v_u_346, (copy) v_u_337, (copy) v_u_380, (ref) v_u_59, (copy) v_u_388, (ref) v_u_330, (ref) v_u_22, (copy) v_u_32, (copy) v_u_23, (copy) v_u_8, (copy) v_u_367, (copy) v_u_356, (copy) v_u_345
		local v389, v390, v391 = v_u_10.PhaseClock()
		if v389 == "PreRound" and v390 > 0 then
			local v392 = v_u_10.Get("MatchId") or "?"
			local v393, v394, v395, v396
			if v392 == v_u_368 and v391 == v_u_370 then
				local v397 = v390 - v_u_369
				if math.abs(v397) > 0.05 then
					v_u_368 = v392
					v_u_369 = v390
					v_u_370 = v391
					v_u_372 = 0
					v_u_373 = 0
					v_u_374 = false
					if p_u_7.Decider == nil then
						v393 = false
					else
						v393 = p_u_7.Decider.IsDecider(v_u_10.Match)
					end
					v_u_371 = v393
					v_u_20 = v_u_20 + 1
					v_u_36(v_u_16, v_u_17)
					v_u_16.Visible = false
					if not v_u_21 then
						v_u_19.Visible = false
					end
					v394 = v_u_343
					if v394.on then
						v394.on = false
						v394.label.Visible = false
					end
					v395 = v_u_344
					if v395.on then
						v395.on = false
						v395.label.Visible = false
					end
					v396 = v_u_346
					if v396.on then
						v396.on = false
						v396.label.Visible = false
					end
					v_u_337.Visible = false
				end
			else
				v_u_368 = v392
				v_u_369 = v390
				v_u_370 = v391
				v_u_372 = 0
				v_u_373 = 0
				v_u_374 = false
				if p_u_7.Decider == nil then
					v393 = false
				else
					v393 = p_u_7.Decider.IsDecider(v_u_10.Match)
				end
				v_u_371 = v393
				v_u_20 = v_u_20 + 1
				v_u_36(v_u_16, v_u_17)
				v_u_16.Visible = false
				if not v_u_21 then
					v_u_19.Visible = false
				end
				v394 = v_u_343
				if v394.on then
					v394.on = false
					v394.label.Visible = false
				end
				v395 = v_u_344
				if v395.on then
					v395.on = false
					v395.label.Visible = false
				end
				v396 = v_u_346
				if v396.on then
					v396.on = false
					v396.label.Visible = false
				end
				v_u_337.Visible = false
			end
		end
		if v_u_368 then
			local v398 = v_u_369 - v_u_10.Now()
			if (v389 == "PreRound" or v389 == "Live") and v398 >= -1.05 then
				if v_u_59 and v_u_59.Visible then
					v_u_372 = 0
					local v399 = v_u_343
					if v399.on then
						v399.on = false
						v399.label.Visible = false
					end
					local v400 = v_u_344
					if v400.on then
						v400.on = false
						v400.label.Visible = false
					end
					local v401 = v_u_346
					if v401.on then
						v401.on = false
						v401.label.Visible = false
					end
					v_u_337.Visible = false
					return
				else
					if v_u_372 == 0 then
						v_u_372 = os.clock()
						v_u_388()
					end
					local v402 = (os.clock() - v_u_372) / 0.15
					local v403 = math.min(1, v402)
					local v404 = v398 <= 0 and 0 or math.ceil(v398)
					if v404 ~= v_u_373 and (v404 >= 1 and v404 <= v_u_330) then
						v_u_373 = v404
						if v_u_371 then
							p_u_7.Decider.Digit(v404)
						end
					end
					if v398 <= 0 and not v_u_374 then
						v_u_374 = true
						v_u_22 = v_u_22 + 1
						local v_u_405 = v_u_22
						if v_u_21 then
							v_u_21 = false
							v_u_32(v_u_19, "TextTransparency", 1, 0.2)
							v_u_32(v_u_23, "Transparency", 1, 0.2)
							task.delay(0.21, function()
								-- upvalues: (copy) v_u_405, (ref) v_u_22, (ref) v_u_21, (ref) v_u_19
								if v_u_405 == v_u_22 and not v_u_21 then
									v_u_19.Visible = false
								end
							end)
						end
						if v_u_371 then
							p_u_7.Decider.Fight()
						end
					end
					if v_u_371 then
						local v406 = v_u_343
						if v406.on then
							v406.on = false
							v406.label.Visible = false
						end
						local v407 = v_u_344
						if v407.on then
							v407.on = false
							v407.label.Visible = false
						end
						local v408 = v_u_346
						if v408.on then
							v408.on = false
							v408.label.Visible = false
						end
						v_u_337.Visible = false
					else
						if not v_u_337.Visible then
							v_u_337.Visible = true
						end
						local v409 = v_u_8.Compact and 1.5 or 1.8
						for v410 = v404, v404 + 1 do
							local v411
							if v410 % 2 == 1 then
								v411 = v_u_343
							else
								v411 = v_u_344
							end
							if v410 >= 1 and v410 <= v_u_330 then
								local v412, v413, v414 = v_u_367(v410 - v398)
								local v415, v416
								if v410 > 3 then
									v415 = 0.8
									v416 = 0.82
								else
									v415 = 1
									v416 = 1
								end
								v_u_356(v411, v_u_345[v410], v412 * v416 * v403, v409 * v415 * v413, v414 * v409)
							else
								if not v411.on then
									continue
								end
								v411.on = false
								v411.label.Visible = false
							end
						end
						local v417 = -v398
						local v418, v419, v420
						if v417 < 0 or v417 >= 1 then
							v418 = 0
							v419 = 1
							v420 = 0
						elseif v417 < 0.2 then
							local v421 = v417 / 0.05
							v418 = math.min(1, v421)
							local v422 = v417 / 0.2 - 1
							v419 = 1.6 - (v422 * 2.5 * v422 * v422 + 1 + v422 * 1.5 * v422) * 0.6
							v420 = 0
						elseif v417 < 0.72 then
							v418 = 1
							v419 = 1
							v420 = 0
						else
							local v423 = (v417 - 0.72) / 0.28
							v418 = 1 - v423 * v423
							local v424 = 1 - v423
							v419 = (1 - v424 * v424 * v424) * 0.12 + 1
							v420 = 0
						end
						v_u_356(v_u_346, "FIGHT!", v418 * v403, (v_u_8.Compact and 0.9 or 1) * 1.2 * v419, v420)
					end
				end
			else
				v_u_380()
				return
			end
		else
			return
		end
	end
	local v_u_426 = nil
	local v427 = v_u_10.SeesMatch()
	if v427 and not v_u_426 then
		v_u_426 = v_u_3.RenderStepped:Connect(v_u_425)
	elseif not v427 and v_u_426 then
		v_u_426:Disconnect()
		v_u_426 = nil
		if v_u_368 and (v_u_371 and (not v_u_374 and p_u_7.Decider)) then
			p_u_7.Decider.Stop(false)
		end
		v_u_368 = nil
		if v_u_343.on then
			v_u_343.on = false
			v_u_343.label.Visible = false
		end
		if v_u_344.on then
			v_u_344.on = false
			v_u_344.label.Visible = false
		end
		if v_u_346.on then
			v_u_346.on = false
			v_u_346.label.Visible = false
		end
		v_u_337.Visible = false
		v_u_21 = false
		v_u_22 = v_u_22 + 1
		v_u_36(v_u_19, v_u_23)
		v_u_19.Visible = false
	end
	local v_u_428 = v_u_8.new("Frame", {
		["Name"] = "Elimination",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromScale(0.5, 0.6),
		["Size"] = UDim2.fromOffset(600, 90),
		["Parent"] = v_u_15
	})
	local v_u_429 = v_u_8.new("Frame", {
		["Name"] = "Inner",
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_428
	})
	local v_u_430 = v_u_8.Image(v_u_8.Assets.Icons.Skull, {
		["Name"] = "Skull",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ImageColor3"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromScale(0.5, 0),
		["Size"] = UDim2.fromOffset(34, 34),
		["ImageColor3"] = v_u_12.Enemy,
		["Parent"] = v_u_429
	})
	local v_u_431 = v_u_8.DisplayText({
		["Name"] = "Title",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "ELIMINATED",
		["TextSize"] = 32,
		["TextColor3"] = nil,
		["StrokeThickness"] = 2.5,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 34),
		["Size"] = UDim2.new(1, 0, 0, 34),
		["TextColor3"] = v_u_12.Enemy,
		["Parent"] = v_u_429
	})
	local v_u_432 = v_u_8.new("TextLabel", {
		["Name"] = "Victim",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 22,
		["TextColor3"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 66),
		["Size"] = UDim2.new(1, 0, 0, 24),
		["FontFace"] = v_u_13.Heavy,
		["TextColor3"] = v_u_12.Text,
		["Parent"] = v_u_429
	})
	v_u_8.TextStroke(v_u_12.Void, 2, 0.2).Parent = v_u_432
	local v_u_433 = 0
	local v_u_434 = 0
	local v_u_435 = 0
	local v_u_436 = {
		[2] = "DOUBLE ELIMINATION",
		[3] = "TRIPLE ELIMINATION"
	}
	local function v_u_441(p437, p438) -- name: showElim
		-- upvalues: (ref) v_u_433, (ref) v_u_435, (ref) v_u_434, (copy) v_u_431, (copy) v_u_436, (copy) v_u_432, (copy) v_u_428, (copy) v_u_8, (copy) v_u_429, (copy) v_u_9, (copy) v_u_430
		v_u_433 = v_u_433 + 1
		local v_u_439 = v_u_433
		local v440 = os.clock()
		v_u_435 = v440 - v_u_434 > 4 and 1 or v_u_435 + 1
		v_u_434 = v440
		v_u_431.Text = v_u_436[v_u_435] or (v_u_435 >= 3 and "TRIPLE ELIMINATION" or "ELIMINATED")
		v_u_432.Text = string.upper(p437) .. (p438 and "  \194\183  HEADSHOT" or "")
		v_u_428.Position = UDim2.fromScale(0.5, v_u_8.Compact and 0.54 or 0.6)
		v_u_428.Visible = true
		v_u_8.Unfade(v_u_429)
		v_u_8.SlideIn(v_u_429, Vector2.new(0, 14), v_u_9.Tween.PopSmall, UDim2.new())
		v_u_8.Pop(v_u_430, 1.6)
		task.delay(1.8, function()
			-- upvalues: (copy) v_u_439, (ref) v_u_433, (ref) v_u_8, (ref) v_u_429, (ref) v_u_428
			if v_u_439 == v_u_433 then
				v_u_8.FadeOut(v_u_429, TweenInfo.new(0.3))
				task.delay(0.32, function()
					-- upvalues: (ref) v_u_439, (ref) v_u_433, (ref) v_u_428
					if v_u_439 == v_u_433 then
						v_u_428.Visible = false
					end
				end)
			end
		end)
	end
	p_u_7.OnMatchEvent(function(p442, p443)
		-- upvalues: (ref) v_u_368, (ref) v_u_371, (ref) v_u_374, (copy) p_u_7, (copy) v_u_343, (copy) v_u_344, (copy) v_u_346, (copy) v_u_337, (ref) v_u_21, (ref) v_u_22, (copy) v_u_36, (copy) v_u_19, (copy) v_u_23, (copy) v_u_286, (copy) v_u_270, (ref) v_u_20, (copy) v_u_16, (copy) v_u_17, (copy) v_u_58, (copy) v_u_12, (copy) v_u_10, (copy) v_u_441, (ref) v_u_60, (copy) v_u_183, (ref) v_u_59, (ref) v_u_254
		local v444 = type(p443) ~= "table" and {} or p443
		if p442 == "MatchStart" then
			if v_u_368 and (v_u_371 and (not v_u_374 and p_u_7.Decider)) then
				p_u_7.Decider.Stop(false)
			end
			v_u_368 = nil
			local v445 = v_u_343
			if v445.on then
				v445.on = false
				v445.label.Visible = false
			end
			local v446 = v_u_344
			if v446.on then
				v446.on = false
				v446.label.Visible = false
			end
			local v447 = v_u_346
			if v447.on then
				v447.on = false
				v447.label.Visible = false
			end
			v_u_337.Visible = false
			v_u_21 = false
			v_u_22 = v_u_22 + 1
			v_u_36(v_u_19, v_u_23)
			v_u_19.Visible = false
			v_u_286(v444)
			return
		elseif p442 == "RoundStart" then
			v_u_270()
		elseif p442 == "RoundEnd" then
			if v_u_368 and (v_u_371 and (not v_u_374 and p_u_7.Decider)) then
				p_u_7.Decider.Stop(false)
			end
			v_u_368 = nil
			local v448 = v_u_343
			if v448.on then
				v448.on = false
				v448.label.Visible = false
			end
			local v449 = v_u_344
			if v449.on then
				v449.on = false
				v449.label.Visible = false
			end
			local v450 = v_u_346
			if v450.on then
				v450.on = false
				v450.label.Visible = false
			end
			v_u_337.Visible = false
			v_u_21 = false
			v_u_22 = v_u_22 + 1
			v_u_36(v_u_19, v_u_23)
			v_u_19.Visible = false
			v_u_20 = v_u_20 + 1
			v_u_36(v_u_16, v_u_17)
			v_u_16.Visible = false
			if not v_u_21 then
				v_u_19.Visible = false
				return
			end
		else
			if p442 == "Overtime" then
				v_u_58("OVERTIME", v_u_12.Danger, "THE RING OF FIRE IS CLOSING", 2.2, false)
				return
			end
			if p442 == "Elimination" then
				local v451 = p_u_7.PlayerGui:FindFirstChild("CombatHUD") ~= nil
				if v444.killerId == v_u_10.MyId() and (v444.victimId ~= v_u_10.MyId() and not v451) then
					local v452 = v_u_441
					local v453 = v444.victimName or "?"
					v452(tostring(v453), v444.headshot == true)
					return
				end
			else
				if p442 == "Replaced" then
					local v454 = p_u_7.Toast
					local v455 = string.format
					local v456 = v444.name or "A fighter"
					local v457 = tostring(v456)
					local v458 = v444.botName or "a new fighter"
					v454(v455("%s left \194\183 %s joined", v457, (tostring(v458))), "info")
					return
				end
				if p442 == "MatchEnd" then
					if v_u_368 and (v_u_371 and (not v_u_374 and p_u_7.Decider)) then
						p_u_7.Decider.Stop(false)
					end
					v_u_368 = nil
					local v459 = v_u_343
					if v459.on then
						v459.on = false
						v459.label.Visible = false
					end
					local v460 = v_u_344
					if v460.on then
						v460.on = false
						v460.label.Visible = false
					end
					local v461 = v_u_346
					if v461.on then
						v461.on = false
						v461.label.Visible = false
					end
					v_u_337.Visible = false
					v_u_21 = false
					v_u_22 = v_u_22 + 1
					v_u_36(v_u_19, v_u_23)
					v_u_19.Visible = false
					v_u_60 = v_u_60 + 1
					v_u_183(false)
					local v462 = v_u_59
					if v462 then
						if not v462.Visible then
							return
						end
						p_u_7.SetHudHidden("Intro", false)
						if v_u_254 then
							v_u_254.conn:Disconnect()
							v_u_254 = nil
						end
						v462.Visible = false
					end
				end
			end
		end
	end)
	v_u_10.PlayerStateChanged:Connect(function(p463)
		-- upvalues: (copy) v_u_10, (ref) v_u_60, (copy) v_u_183, (ref) v_u_59, (copy) p_u_7, (ref) v_u_254, (ref) v_u_20, (copy) v_u_36, (copy) v_u_16, (copy) v_u_17, (ref) v_u_21, (copy) v_u_19, (ref) v_u_426, (ref) v_u_3, (copy) v_u_425, (ref) v_u_368, (ref) v_u_371, (ref) v_u_374, (copy) v_u_343, (copy) v_u_344, (copy) v_u_346, (copy) v_u_337, (ref) v_u_22, (copy) v_u_23
		if p463 ~= "Match" and not v_u_10.Watching() then
			v_u_60 = v_u_60 + 1
			v_u_183(false)
			local v464 = v_u_59
			if v464 and v464.Visible then
				p_u_7.SetHudHidden("Intro", false)
				if v_u_254 then
					v_u_254.conn:Disconnect()
					v_u_254 = nil
				end
				v464.Visible = false
			end
			v_u_20 = v_u_20 + 1
			v_u_36(v_u_16, v_u_17)
			v_u_16.Visible = false
			if not v_u_21 then
				v_u_19.Visible = false
			end
		end
		local v465 = v_u_10.SeesMatch()
		if v465 and not v_u_426 then
			v_u_426 = v_u_3.RenderStepped:Connect(v_u_425)
		elseif not v465 and v_u_426 then
			v_u_426:Disconnect()
			v_u_426 = nil
			if v_u_368 and (v_u_371 and (not v_u_374 and p_u_7.Decider)) then
				p_u_7.Decider.Stop(false)
			end
			v_u_368 = nil
			local v466 = v_u_343
			if v466.on then
				v466.on = false
				v466.label.Visible = false
			end
			local v467 = v_u_344
			if v467.on then
				v467.on = false
				v467.label.Visible = false
			end
			local v468 = v_u_346
			if v468.on then
				v468.on = false
				v468.label.Visible = false
			end
			v_u_337.Visible = false
			v_u_21 = false
			v_u_22 = v_u_22 + 1
			v_u_36(v_u_19, v_u_23)
			v_u_19.Visible = false
		end
	end)
	v_u_10.WatchChanged:Connect(function(p469)
		-- upvalues: (copy) v_u_10, (ref) v_u_60, (copy) v_u_183, (ref) v_u_59, (copy) p_u_7, (ref) v_u_254, (ref) v_u_20, (copy) v_u_36, (copy) v_u_16, (copy) v_u_17, (ref) v_u_21, (copy) v_u_19, (ref) v_u_426, (ref) v_u_3, (copy) v_u_425, (ref) v_u_368, (ref) v_u_371, (ref) v_u_374, (copy) v_u_343, (copy) v_u_344, (copy) v_u_346, (copy) v_u_337, (ref) v_u_22, (copy) v_u_23
		if not (p469 or v_u_10.InMatch()) then
			v_u_60 = v_u_60 + 1
			v_u_183(false)
			local v470 = v_u_59
			if v470 and v470.Visible then
				p_u_7.SetHudHidden("Intro", false)
				if v_u_254 then
					v_u_254.conn:Disconnect()
					v_u_254 = nil
				end
				v470.Visible = false
			end
			v_u_20 = v_u_20 + 1
			v_u_36(v_u_16, v_u_17)
			v_u_16.Visible = false
			if not v_u_21 then
				v_u_19.Visible = false
			end
		end
		local v471 = v_u_10.SeesMatch()
		if v471 and not v_u_426 then
			v_u_426 = v_u_3.RenderStepped:Connect(v_u_425)
		elseif not v471 and v_u_426 then
			v_u_426:Disconnect()
			v_u_426 = nil
			if v_u_368 and (v_u_371 and (not v_u_374 and p_u_7.Decider)) then
				p_u_7.Decider.Stop(false)
			end
			v_u_368 = nil
			local v472 = v_u_343
			if v472.on then
				v472.on = false
				v472.label.Visible = false
			end
			local v473 = v_u_344
			if v473.on then
				v473.on = false
				v473.label.Visible = false
			end
			local v474 = v_u_346
			if v474.on then
				v474.on = false
				v474.label.Visible = false
			end
			v_u_337.Visible = false
			v_u_21 = false
			v_u_22 = v_u_22 + 1
			v_u_36(v_u_19, v_u_23)
			v_u_19.Visible = false
		end
	end)
	function p_u_7.Debug.banner(p475, p476)
		-- upvalues: (copy) v_u_10
		v_u_10.MatchEvent:Fire(p475, p476 or {})
		return true
	end
	function p_u_7.Debug.countdown(p477)
		-- upvalues: (ref) v_u_368, (ref) v_u_371, (ref) v_u_374, (copy) p_u_7, (copy) v_u_343, (copy) v_u_344, (copy) v_u_346, (copy) v_u_337, (ref) v_u_21, (ref) v_u_22, (copy) v_u_36, (copy) v_u_19, (copy) v_u_23, (copy) v_u_10, (ref) v_u_373
		if p477 == "restart" then
			if v_u_368 and (v_u_371 and (not v_u_374 and p_u_7.Decider)) then
				p_u_7.Decider.Stop(false)
			end
			v_u_368 = nil
			local v478 = v_u_343
			if v478.on then
				v478.on = false
				v478.label.Visible = false
			end
			local v479 = v_u_344
			if v479.on then
				v479.on = false
				v479.label.Visible = false
			end
			local v480 = v_u_346
			if v480.on then
				v480.on = false
				v480.label.Visible = false
			end
			v_u_337.Visible = false
			v_u_21 = false
			v_u_22 = v_u_22 + 1
			v_u_36(v_u_19, v_u_23)
			v_u_19.Visible = false
		end
		local v481, v482 = v_u_10.PhaseClock()
		local v483 = {
			["phase"] = v481,
			["left"] = v482 <= 0 and 0 or v482 - v_u_10.Now(),
			["running"] = v_u_368 ~= nil,
			["digit"] = v_u_373,
			["decider"] = v_u_371,
			["fought"] = v_u_374
		}
		local v484
		if v_u_343.on then
			v484 = v_u_343.text
		else
			v484 = false
		end
		v483.odd = v484
		local v485
		if v_u_344.on then
			v485 = v_u_344.text
		else
			v485 = false
		end
		v483.even = v485
		v483.fight = v_u_346.on
		local v486
		if v_u_19.Visible then
			v486 = v_u_19.Text
		else
			v486 = false
		end
		v483.sub = v486
		return v483
	end
end
return v5