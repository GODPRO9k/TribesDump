local v1 = {}
local v2 = {
	["size"] = { 5, 4.6666, 5 },
	["hinge"] = { 0, 1.6667, 2.5 },
	["parts"] = {
		{
			["name"] = "chest.T_mesh",
			["lid"] = true,
			["mesh"] = "rbxassetid://8562367045",
			["tex"] = "rbxassetid://8562367073",
			["size"] = nil,
			["scale"] = nil,
			["cf"] = nil,
			["color"] = nil,
			["material"] = "Plastic",
			["size"] = { 5, 3, 5 },
			["scale"] = { 1.7012, 1.7012, 1.7012 },
			["cf"] = {
				0,
				3.1666,
				0,
				1,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				1
			},
			["color"] = { 163, 162, 165 }
		},
		{
			["name"] = "chest.B_mesh",
			["lid"] = false,
			["mesh"] = "rbxassetid://8562367050",
			["tex"] = "rbxassetid://8562367073",
			["size"] = nil,
			["scale"] = nil,
			["cf"] = nil,
			["color"] = nil,
			["material"] = "Plastic",
			["size"] = { 4.6666, 2.3333, 4.6666 },
			["scale"] = { 1.7012, 1.7012, 1.7012 },
			["cf"] = {
				0,
				1.1667,
				0,
				1,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				1
			},
			["color"] = { 163, 162, 165 }
		}
	}
}
v1.Drop = v2
local v3 = {
	["size"] = { 5, 3.3517, 3.6115 },
	["hinge"] = { 0, 1.7414, 1.6044 },
	["parts"] = {
		{
			["name"] = "bottom",
			["lid"] = false,
			["mesh"] = "rbxassetid://10716480530",
			["tex"] = "rbxassetid://8231683509",
			["size"] = nil,
			["scale"] = nil,
			["cf"] = nil,
			["color"] = nil,
			["material"] = "SmoothPlastic",
			["size"] = { 5, 1.7414, 3.4102 },
			["scale"] = { 182.6998, 182.6998, 182.6998 },
			["cf"] = {
				0,
				0.8707,
				-0.1007,
				1,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				1
			},
			["color"] = { 163, 162, 165 }
		},
		{
			["name"] = "gold",
			["lid"] = false,
			["mesh"] = "rbxassetid://10716480194",
			["tex"] = "rbxassetid://8231683509",
			["size"] = nil,
			["scale"] = nil,
			["cf"] = nil,
			["color"] = nil,
			["material"] = "Metal",
			["size"] = { 4.454, 0.9657, 2.5241 },
			["scale"] = { 182.6998, 182.6998, 182.6998 },
			["cf"] = {
				-0.0215,
				1.8837,
				-0.0396,
				1,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				1
			},
			["color"] = { 163, 162, 165 }
		},
		{
			["name"] = "lid",
			["lid"] = true,
			["mesh"] = "rbxassetid://10716480747",
			["tex"] = "rbxassetid://8231683509",
			["size"] = nil,
			["scale"] = nil,
			["cf"] = nil,
			["color"] = nil,
			["material"] = "SmoothPlastic",
			["size"] = { 4.7618, 3.2162, 1.9592 },
			["scale"] = { 156.4378, 156.4377, 156.4378 },
			["cf"] = {
				0.0495,
				2.3721,
				0.1976,
				1,
				0,
				0,
				0,
				0,
				1,
				0,
				-1,
				0
			},
			["color"] = { 163, 162, 165 }
		}
	}
}
v1.Victory = v3
local v4 = {
	["size"] = { 5, 4.1778, 3.0454 },
	["hinge"] = { 0.0287, 2.1055, 1.0743 },
	["parts"] = {
		{
			["name"] = "Gold",
			["lid"] = false,
			["mesh"] = "rbxassetid://77232919448456",
			["tex"] = "",
			["size"] = nil,
			["scale"] = nil,
			["cf"] = nil,
			["color"] = nil,
			["material"] = "SmoothPlastic",
			["size"] = { 4.2545, 0.7565, 1.677 },
			["scale"] = { 2.5505, 2.5505, 2.5505 },
			["cf"] = {
				0.0662,
				1.9782,
				0.1152,
				1,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				1
			},
			["color"] = { 150, 120, 10 }
		},
		{
			["name"] = "Top",
			["lid"] = true,
			["mesh"] = "rbxassetid://81058868435468",
			["tex"] = "rbxassetid://122990138689628",
			["size"] = nil,
			["scale"] = nil,
			["cf"] = nil,
			["color"] = nil,
			["material"] = "Plastic",
			["size"] = { 4.6913, 2.3915, 3.0454 },
			["scale"] = { 2.5505, 2.5505, 2.5505 },
			["cf"] = {
				0.0662,
				2.9821,
				0,
				1,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				1
			},
			["color"] = { 163, 162, 165 }
		},
		{
			["name"] = "Bottom",
			["lid"] = false,
			["mesh"] = "rbxassetid://140054016486876",
			["tex"] = "rbxassetid://122990138689628",
			["size"] = nil,
			["scale"] = nil,
			["cf"] = nil,
			["color"] = nil,
			["material"] = "Plastic",
			["size"] = { 5, 2.1063, 2.6762 },
			["scale"] = { 2.5505, 2.5505, 2.5505 },
			["cf"] = {
				0,
				1.0531,
				0.071,
				1,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				1
			},
			["color"] = { 163, 162, 165 }
		}
	}
}
v1.Golden = v4
return v1