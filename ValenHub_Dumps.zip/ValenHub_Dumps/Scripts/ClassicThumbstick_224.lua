local v_u_1 = game:GetService("GuiService")
local v2 = game:GetService("Players")
local v3 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
local v_u_4 = v3.getUserFlag("UserPlayerScriptsCCLIntegrationD")
local v_u_5 = v3.getUserFlag("UserPlayerScriptsClassicThumbstickRenameUI")
local v_u_6 = v3.getUserFlag("UserAbilitiesUserInterfaceC")
local v_u_7 = v3.getUserFlag("UserPlayerScriptsResetDTTouchOnCreate")
local v_u_8 = script.Parent.Parent:WaitForChild("InputContexts"):WaitForChild("TransformerContext"):WaitForChild("ThumbstickAction")
local v_u_9 = Vector2.new(-1, -1)
local v_u_10 = require(script.Parent:WaitForChild("AvatarAbilitiesInterface"))
local v_u_11
if v_u_4 then
	v_u_11 = v_u_10.get(v2.LocalPlayer)
else
	v_u_11 = nil
end
local v_u_12 = require(script.Parent:WaitForChild("ActionController"))
local v_u_13 = setmetatable({}, v_u_12)
v_u_13.__index = v_u_13
function v_u_13.new(p14) -- name: new
	-- upvalues: (copy) v_u_12, (copy) v_u_13
	local v15 = v_u_12.new()
	local v16 = v_u_13
	local v17 = setmetatable(v15, v16)
	v17.playerData = p14
	v17.enabled = false
	v17.isTouchActive = false
	v17.isFollowStick = false
	v17.thumbstickFrame = nil
	v17.screenPos = nil
	v17.stickImage = nil
	v17.thumbstickSize = nil
	return v17
end
local function v_u_21(p18) -- name: setupThumbstickInput
	-- upvalues: (copy) v_u_8
	for _, v19 in v_u_8:GetChildren() do
		if v19.Name ~= "DynamicTouchBinding" and v19.Name ~= "ClassicTouchBinding" then
			continue
		end
		v19:Destroy()
	end
	local v20 = Instance.new("InputBinding")
	v20.Name = "ClassicTouchBinding"
	v20.KeyCode = Enum.KeyCode.TouchPosition
	v20.UIModifier = p18.thumbstickButton
	v20.Parent = v_u_8
end
function v_u_13.Enable(p22, p23, p24) -- name: Enable
	-- upvalues: (copy) v_u_12, (copy) v_u_7, (copy) v_u_21, (copy) v_u_8
	if p23 == nil then
		return false
	end
	local v25 = p23 and true or false
	if p22.enabled == v25 then
		return true
	end
	v_u_12.Enable(p22, v25)
	p22.isJumping = false
	if v25 then
		if not p22.thumbstickFrame then
			p22:Create(p24)
		end
		if v_u_7 then
			v_u_21(p22)
			p22.thumbstickStateChangedConn = v_u_8.StateChanged:Connect(p22.onStateChanged)
			v_u_8.Enabled = true
		else
			p22.thumbstickStateChangedConn = v_u_8.StateChanged:Connect(p22.onStateChanged)
			v_u_8.Enabled = true
		end
		p22.thumbstickFrame.Visible = true
	else
		if v_u_7 then
			v_u_8.Enabled = false
			if p22.thumbstickStateChangedConn then
				p22.thumbstickStateChangedConn:Disconnect()
				p22.thumbstickStateChangedConn = nil
			end
		else
			v_u_8.Enabled = false
			if p22.thumbstickStateChangedConn then
				p22.thumbstickStateChangedConn:Disconnect()
				p22.thumbstickStateChangedConn = nil
			end
		end
		p22.thumbstickFrame.Visible = false
		p22:OnInputEnded()
	end
	p22.enabled = v25
end
function v_u_13.OnInputEnded(p26) -- name: OnInputEnded
	p26.isTouchActive = false
	p26.thumbstickFrame.Position = p26.screenPos
	p26.stickImage.Position = UDim2.new(0, p26.thumbstickFrame.Size.X.Offset / 2 - p26.thumbstickSize / 4, 0, p26.thumbstickFrame.Size.Y.Offset / 2 - p26.thumbstickSize / 4)
	local v27 = p26.playerData.actions.MoveAction:FindFirstChild("ClassicThumbstickScriptableBinding")
	if v27 then
		v27:Fire(Vector2.zero)
	end
	p26.isJumping = false
	p26.thumbstickFrame.Position = p26.screenPos
end
function v_u_13.Create(p_u_28, p_u_29) -- name: Create
	-- upvalues: (copy) v_u_8, (copy) v_u_5, (copy) v_u_4, (copy) v_u_11, (copy) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_9, (copy) v_u_1
	if p_u_28.thumbstickFrame then
		v_u_8.Enabled = false
		if p_u_28.thumbstickStateChangedConn then
			p_u_28.thumbstickStateChangedConn:Disconnect()
			p_u_28.thumbstickStateChangedConn = nil
		end
		p_u_28.thumbstickFrame:Destroy()
		p_u_28.thumbstickFrame = nil
		if p_u_28.absoluteSizeChangedConn then
			p_u_28.absoluteSizeChangedConn:Disconnect()
			p_u_28.absoluteSizeChangedConn = nil
		end
		if p_u_28.avatarAbilitiesEnabledChangedConn then
			p_u_28.avatarAbilitiesEnabledChangedConn:Disconnect()
			p_u_28.avatarAbilitiesEnabledChangedConn = nil
		end
	end
	p_u_28.thumbstickFrame = Instance.new("Frame")
	p_u_28.thumbstickFrame.Name = v_u_5 and "ClassicThumbstickFrame" or "ThumbstickFrame"
	p_u_28.thumbstickFrame.Active = true
	p_u_28.thumbstickFrame.Visible = false
	p_u_28.thumbstickFrame.BackgroundTransparency = 1
	local v_u_30 = Instance.new("ImageLabel")
	v_u_30.Name = "OuterImage"
	v_u_30.Image = "rbxasset://textures/ui/TouchControlsSheet.png"
	v_u_30.ImageRectOffset = Vector2.new()
	v_u_30.ImageRectSize = Vector2.new(220, 220)
	v_u_30.BackgroundTransparency = 1
	v_u_30.Position = UDim2.new(0, 0, 0, 0)
	p_u_28.stickImage = Instance.new("ImageLabel")
	p_u_28.stickImage.Name = "StickImage"
	p_u_28.stickImage.Image = "rbxasset://textures/ui/TouchControlsSheet.png"
	p_u_28.stickImage.ImageRectOffset = Vector2.new(220, 0)
	p_u_28.stickImage.ImageRectSize = Vector2.new(111, 111)
	p_u_28.stickImage.BackgroundTransparency = 1
	p_u_28.stickImage.ZIndex = 2
	local function v35() -- name: ResizeThumbstick
		-- upvalues: (copy) p_u_29, (ref) v_u_4, (ref) v_u_11, (ref) v_u_10, (copy) p_u_28, (copy) v_u_30
		local v31 = p_u_29.AbsoluteSize.X
		local v32 = p_u_29.AbsoluteSize.Y
		local v33 = math.min(v31, v32) <= 500
		local v34
		if v_u_4 then
			v34 = v_u_11:isEnabled()
		else
			v34 = v_u_10.isEnabled()
		end
		if v34 then
			p_u_28.thumbstickSize = v33 and 72 or 120
			p_u_28.screenPos = UDim2.new(0, v33 and 64 or 100, 1, -p_u_28.thumbstickSize - (v33 and 64 or 112))
		else
			p_u_28.thumbstickSize = v33 and 70 or 120
			p_u_28.screenPos = v33 and UDim2.new(0, p_u_28.thumbstickSize / 2 - 10, 1, -p_u_28.thumbstickSize - 20) or UDim2.new(0, p_u_28.thumbstickSize / 2, 1, -p_u_28.thumbstickSize * 1.75)
		end
		p_u_28.thumbstickFrame.Size = UDim2.new(0, p_u_28.thumbstickSize, 0, p_u_28.thumbstickSize)
		p_u_28.thumbstickFrame.Position = p_u_28.screenPos
		v_u_30.Size = UDim2.new(0, p_u_28.thumbstickSize, 0, p_u_28.thumbstickSize)
		p_u_28.stickImage.Size = UDim2.new(0, p_u_28.thumbstickSize / 2, 0, p_u_28.thumbstickSize / 2)
		p_u_28.stickImage.Position = UDim2.new(0, p_u_28.thumbstickSize / 2 - p_u_28.thumbstickSize / 4, 0, p_u_28.thumbstickSize / 2 - p_u_28.thumbstickSize / 4)
	end
	v35()
	p_u_28.absoluteSizeChangedConn = p_u_29:GetPropertyChangedSignal("AbsoluteSize"):Connect(v35)
	if v_u_4 then
		p_u_28.avatarAbilitiesEnabledChangedConn = v_u_11:GetEnabledChangedSignal():Connect(v35)
	else
		p_u_28.avatarAbilitiesEnabledChangedConn = v_u_10.GetEnabledChangedSignal():Connect(v35)
	end
	v_u_30.Parent = p_u_28.thumbstickFrame
	p_u_28.stickImage.Parent = p_u_28.thumbstickFrame
	p_u_28.thumbstickButton = Instance.new("ImageButton")
	p_u_28.thumbstickButton.Name = "ClassicThumbstickUIModifier"
	p_u_28.thumbstickButton.BackgroundTransparency = 1
	p_u_28.thumbstickButton.ImageTransparency = 1
	p_u_28.thumbstickButton.AutoButtonColor = false
	p_u_28.thumbstickButton.Size = UDim2.new(1, 0, 1, 0)
	p_u_28.thumbstickButton.ZIndex = p_u_28.thumbstickFrame.ZIndex
	p_u_28.thumbstickButton.Visible = true
	p_u_28.thumbstickButton.Active = false
	p_u_28.thumbstickButton.Parent = p_u_28.thumbstickFrame
	if not v_u_7 then
		local v36 = Instance.new("InputBinding")
		v36.Name = "ClassicTouchBinding"
		v36.KeyCode = Enum.KeyCode.TouchPosition
		v36.UIModifier = p_u_28.thumbstickButton
		v36.Parent = v_u_8
	end
	local v_u_37 = nil
	local function v_u_46(p38) -- name: DoMove
		-- upvalues: (copy) p_u_28
		local v39 = p38 / (p_u_28.thumbstickSize / 2)
		local v40 = v39.magnitude
		local v41
		if v40 < 0.05 then
			v41 = Vector2.new()
		else
			local v42 = v39.unit
			local v43 = (v40 - 0.05) / 0.95
			v41 = v42 * math.min(1, v43)
		end
		local v44 = Vector2.new(v41.X, -v41.Y)
		local v45 = p_u_28.playerData.actions.MoveAction:FindFirstChild("ClassicThumbstickScriptableBinding")
		if v45 then
			v45:Fire(v44)
		end
	end
	local function v_u_54(p47) -- name: MoveStick
		-- upvalues: (ref) v_u_37, (copy) p_u_28, (ref) v_u_6, (copy) p_u_29
		local v48 = Vector2.new(p47.X - v_u_37.X, p47.Y - v_u_37.Y)
		local v49 = v48.magnitude
		local v50 = p_u_28.thumbstickFrame.AbsoluteSize.X / 2
		if p_u_28.isFollowStick and v50 < v49 then
			local v51 = v48.unit * v50
			if v_u_6 then
				local v52 = p_u_29.AbsolutePosition
				p_u_28.thumbstickFrame.Position = UDim2.new(0, p47.X - v52.X - p_u_28.thumbstickFrame.AbsoluteSize.X / 2 - v51.X, 0, p47.Y - v52.Y - p_u_28.thumbstickFrame.AbsoluteSize.Y / 2 - v51.Y)
			else
				p_u_28.thumbstickFrame.Position = UDim2.new(0, p47.X - p_u_28.thumbstickFrame.AbsoluteSize.X / 2 - v51.X, 0, p47.Y - p_u_28.thumbstickFrame.AbsoluteSize.Y / 2 - v51.Y)
			end
		else
			local v53 = math.min(v49, v50)
			v48 = v48.unit * v53
		end
		p_u_28.stickImage.Position = UDim2.new(0, v48.X + p_u_28.stickImage.AbsoluteSize.X / 2, 0, v48.Y + p_u_28.stickImage.AbsoluteSize.Y / 2)
	end
	function p_u_28.onStateChanged(p55)
		-- upvalues: (ref) v_u_9, (ref) v_u_1, (copy) p_u_28, (ref) v_u_6, (copy) p_u_29, (ref) v_u_37, (copy) v_u_46, (copy) v_u_54
		if p55 == v_u_9 then
			if p_u_28.isTouchActive then
				p_u_28:OnInputEnded()
			end
			return
		else
			local v56 = v_u_1:GetInsetArea(Enum.ScreenInsets.None).Min
			local v57 = p55.X + v56.X
			local v58 = p55.Y + v56.Y
			local v59 = Vector3.new(v57, v58, 0)
			if p_u_28.isTouchActive then
				v_u_37 = Vector2.new(p_u_28.thumbstickFrame.AbsolutePosition.X + p_u_28.thumbstickFrame.AbsoluteSize.X / 2, p_u_28.thumbstickFrame.AbsolutePosition.Y + p_u_28.thumbstickFrame.AbsoluteSize.Y / 2)
				v_u_46((Vector2.new(v59.X - v_u_37.X, v59.Y - v_u_37.Y)))
				v_u_54(v59)
			else
				p_u_28.isTouchActive = true
				if v_u_6 then
					local v60 = p_u_29.AbsolutePosition
					p_u_28.thumbstickFrame.Position = UDim2.new(0, v59.X - v60.X - p_u_28.thumbstickFrame.Size.X.Offset / 2, 0, v59.Y - v60.Y - p_u_28.thumbstickFrame.Size.Y.Offset / 2)
				else
					p_u_28.thumbstickFrame.Position = UDim2.new(0, v59.X - p_u_28.thumbstickFrame.Size.X.Offset / 2, 0, v59.Y - p_u_28.thumbstickFrame.Size.Y.Offset / 2)
				end
				v_u_37 = Vector2.new(p_u_28.thumbstickFrame.AbsolutePosition.X + p_u_28.thumbstickFrame.AbsoluteSize.X / 2, p_u_28.thumbstickFrame.AbsolutePosition.Y + p_u_28.thumbstickFrame.AbsoluteSize.Y / 2)
			end
		end
	end
	v_u_1.MenuOpened:Connect(function()
		-- upvalues: (copy) p_u_28
		if p_u_28.isTouchActive then
			p_u_28:OnInputEnded()
		end
	end)
	p_u_28.thumbstickFrame.Parent = p_u_29
end
return v_u_13