local v_u_1 = {}
v_u_1.__index = v_u_1
function v_u_1.new() -- name: new
	-- upvalues: (copy) v_u_1
	local v2 = v_u_1
	return setmetatable({
		["_handlers"] = {}
	}, v2)
end
function v_u_1.Connect(p3, p_u_4) -- name: Connect
	local v5 = {
		["Connected"] = true
	}
	local v_u_6 = p3._handlers
	function v5.Disconnect(p7) -- name: Disconnect
		-- upvalues: (copy) v_u_6, (copy) p_u_4
		p7.Connected = false
		local v8 = table.find(v_u_6, p_u_4)
		if v8 then
			table.remove(v_u_6, v8)
		end
	end
	table.insert(v_u_6, p_u_4)
	return v5
end
function v_u_1.Once(p9, p_u_10) -- name: Once
	local v_u_11 = nil
	v_u_11 = p9:Connect(function(...)
		-- upvalues: (ref) v_u_11, (copy) p_u_10
		v_u_11:Disconnect()
		p_u_10(...)
	end)
	return v_u_11
end
function v_u_1.Fire(p12, ...) -- name: Fire
	for _, v13 in table.clone(p12._handlers) do
		task.spawn(v13, ...)
	end
end
function v_u_1.Wait(p14) -- name: Wait
	local v_u_15 = coroutine.running()
	p14:Once(function(...)
		-- upvalues: (copy) v_u_15
		task.spawn(v_u_15, ...)
	end)
	return coroutine.yield()
end
return v_u_1