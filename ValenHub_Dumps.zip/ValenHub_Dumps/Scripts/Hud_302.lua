game:GetService("Players")
local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v3 = v1:WaitForChild("Shared")
local v_u_4 = require(v3:WaitForChild("ReplayCodec"))
local v_u_5 = require(v3:WaitForChild("Combat"))
local v_u_6 = require(v3:WaitForChild("Weapons"))
local v_u_7 = require(script.Parent.HudBridge)
local v_u_8 = {}
local v_u_9 = script.Parent.Parent
local v_u_10 = Color3.fromRGB(228, 232, 240)
local v_u_11 = Color3.fromRGB(150, 200, 255)
local v_u_12 = {}
local function v_u_19(p13) -- name: mod
	-- upvalues: (copy) v_u_12, (copy) v_u_9
	local v14 = v_u_12[p13]
	if v14 == nil then
		local v15 = v_u_9:FindFirstChild("Combat")
		if v15 then
			v15 = v15:FindFirstChild(p13)
		end
		local v16 = false
		if v15 and v15:IsA("ModuleScript") then
			local v17 = require
			local v18
			v18, v14 = pcall(v17, v15)
			if v18 then
				if type(v14) ~= "table" then
					v14 = v16
				end
			else
				v14 = v16
			end
		else
			v14 = v16
		end
		v_u_12[p13] = v14
	end
	return v14 or nil
end
local v_u_20 = {
	["active"] = false,
	["items"] = nil,
	["src"] = nil,
	["hum"] = nil,
	["slots"] = nil,
	["heldId"] = nil,
	["style"] = "Dot",
	["charge"] = nil,
	["aiming"] = false,
	["blocking"] = false,
	["hp"] = -1,
	["armor"] = -1,
	["ui"] = false,
	["alive"] = true,
	["items"] = {},
	["slots"] = {}
}
local function v_u_27(p21) -- name: presetOf
	-- upvalues: (copy) v_u_19, (copy) v_u_5
	local v22 = v_u_19("Presentation")
	if not v22 then
		return {}
	end
	local v23 = v22.For
	local v24 = v_u_5.Kind
	local v25, v26 = pcall(v23, p21, v24(p21))
	return (not v25 or type(v26) ~= "table") and {} or v26
end
local function v_u_42() -- name: refreshPips
	-- upvalues: (copy) v_u_19, (copy) v_u_20, (copy) v_u_5, (copy) v_u_27, (copy) v_u_6
	local v28 = v_u_19("Hud")
	if v28 and v_u_20.src then
		local v29 = v_u_20.heldId
		for _, v31 in v_u_20.slots do
			if v31.id ~= v_u_20.heldId then
				continue
			end
		end
		local v31 = nil
		local v32 = v_u_5.Kind(v29) or "Fists"
		if v31 then
			v31 = v31.tool
		end
		local v33
		if v31 then
			v33 = v31:GetAttribute("Ammo")
		else
			v33 = v31
		end
		if type(v33) ~= "number" then
			v33 = nil
		end
		local v34
		if v31 then
			v34 = v31:GetAttribute("MaxAmmo")
		else
			v34 = v31
		end
		if type(v34) ~= "number" then
			v34 = nil
		end
		local v35
		if v31 then
			v35 = v31:GetAttribute("Charges")
		else
			v35 = v31
		end
		if type(v35) ~= "number" then
			v35 = nil
		end
		if v31 then
			v31 = v31:GetAttribute("MaxCharges")
		end
		if type(v31) ~= "number" then
			v31 = nil
		end
		if v_u_5.UsesAmmo(v32) and (v33 and v34) then
			v28.SetPips(v33, v34)
		elseif v35 and (v31 and v32 ~= "Bow") then
			local v36 = v28.SetPips
			local v37
			if v32 == "Herbs" or v32 == "Trap" then
				v37 = v_u_27(v29).color
			else
				v37 = nil
			end
			v36(v35, v31, v37)
		else
			v28.SetPips(0, 0)
		end
		local v38 = v29 and v_u_6.AmmoOf
		if v38 then
			v38 = v_u_6.AmmoOf(v29)
		end
		local v39 = v_u_20.src.model
		local v40
		if type(v38) == "string" then
			v40 = v39:GetAttribute("Ammo_" .. v38)
		else
			v40 = nil
		end
		local v41 = v_u_19("Util")
		if type(v38) == "string" and (v41 and (v41.AmmoShown and v41.AmmoLeft(v39, v38) > 0)) then
			v28.SetAmmoCount(v41.AmmoShown(v39, v38))
			return
		elseif type(v40) == "number" then
			v28.SetAmmoCount(v40, v41 and v41.AMMO_NOUN and v41.AMMO_NOUN[v38] or string.upper(v38))
		else
			v28.SetAmmoCount(nil)
		end
	else
		return
	end
end
local function v_u_66() -- name: refreshArc
	-- upvalues: (copy) v_u_19, (copy) v_u_20, (copy) v_u_2, (copy) v_u_5, (copy) v_u_10, (copy) v_u_11
	local v43 = v_u_19("Hud")
	for _, v45 in v_u_20.slots do
		if v45.id ~= v_u_20.heldId then
			continue
		end
	end
	local v45 = nil
	if v43 and v45 then
		local v46 = v45.tool
		local v47 = v_u_2:GetServerTimeNow()
		local v48 = v46:GetAttribute("ReloadEndsAt")
		if v46:GetAttribute("Reloading") == true and (type(v48) == "number" and v47 < v48) then
			local v49 = v45.id
			local v50 = v_u_5.Tuning
			local v51, v52 = pcall(v50, v49)
			local v53 = ((not v51 or type(v52) ~= "table") and {} or v52).reloadTime or v48 - v47
			local v54 = v43.SetArc
			local v55 = v_u_10
			local v56 = v53 - (v48 - v47)
			v54(v53, v55, (math.max(0, v56)))
		else
			local v57 = v46:GetAttribute("NextCharge")
			local v58 = v45.id
			local v59 = v_u_5.Tuning
			local v60, v61 = pcall(v59, v58)
			local v62 = ((not v60 or type(v61) ~= "table") and {} or v61).regen
			if type(v57) == "number" and (v47 < v57 and type(v62) == "number") then
				local v63 = v43.SetArc
				local v64 = v_u_11
				local v65 = v62 - (v57 - v47)
				v63(v62, v64, (math.max(0, v65)))
			end
		end
	else
		return
	end
end
local function v_u_73(p67) -- name: setHeld
	-- upvalues: (copy) v_u_20, (copy) v_u_19, (copy) v_u_27, (copy) v_u_5, (copy) v_u_42, (copy) v_u_66
	v_u_20.heldId = p67
	v_u_20.charge = nil
	local v68 = v_u_19("Hud")
	local v69 = v_u_20.src
	if v69 then
		for _, v70 in v_u_20.slots do
			local v71
			if v70.id == p67 then
				v71 = v69.character
			else
				v71 = v69.backpack
			end
			if v70.tool.Parent == v71 then
				continue
			end
			v70.tool.Parent = v71
		end
	end
	if v68 then
		local v72 = v_u_27(p67 or v_u_5.FISTS_ID).crosshair or "Dot"
		v_u_20.style = v72
		v68.SetStyle(v72)
		v68.SetArc(nil)
		v68.SetBlocking(v_u_20.blocking)
	end
	v_u_42()
	v_u_66()
end
local function v_u_109(p74) -- name: applyInv
	-- upvalues: (copy) v_u_20, (copy) v_u_2, (copy) v_u_4, (copy) v_u_6, (copy) v_u_5, (copy) v_u_42, (copy) v_u_66
	local v75 = v_u_20.src
	if not v75 then
		return
	end
	local v76 = p74.items
	local v77 = v_u_2:GetServerTimeNow()
	local v78 = {}
	if type(v76) == "string" then
		for v79 = 0, #v76 // v_u_4.INV_BYTES - 1 do
			local v80 = string.unpack
			local v81 = v_u_4.INV_FORMAT
			local v82 = v79 * v_u_4.INV_BYTES + 1
			local v83, v84, v85, v86, v87, v88, v89, v90, v91, v92 = pcall(v80, v81, v76, v82)
			if not v83 then
				break
			end
			local v93 = v_u_20.items[v84]
			if not v93 or (v85 < 1 or v85 > 6) then
				continue
			end
			v78[v85] = true
			local v94 = v_u_20.slots[v85]
			if not v94 or v94.id ~= v93 then
				if v94 then
					v94.tool:Destroy()
				end
				local v95 = Instance.new("Tool")
				local v96 = v_u_6.Get(v93)
				local v97
				if v96 then
					v97 = v96.name
				else
					v97 = v93
				end
				v95.Name = v97
				v95.RequiresHandle = false
				v95.CanBeDropped = false
				v95:SetAttribute("WeaponId", v93)
				v95:SetAttribute("SlotIndex", v85)
				v95:SetAttribute("Kind", v_u_5.Kind(v93))
				local v98
				if v93 == v_u_20.heldId then
					v98 = v75.character
				else
					v98 = v75.backpack
				end
				v95.Parent = v98
				v94 = {
					["tool"] = v95,
					["id"] = v93
				}
				v_u_20.slots[v85] = v94
			end
			local v99 = v94.tool
			local v100
			if v86 > 0 then
				v100 = v86 - 1
			else
				v100 = nil
			end
			if v99:GetAttribute("Ammo") ~= v100 then
				v99:SetAttribute("Ammo", v100)
			end
			local v101
			if v87 > 0 then
				v101 = v87 - 1
			else
				v101 = nil
			end
			if v99:GetAttribute("MaxAmmo") ~= v101 then
				v99:SetAttribute("MaxAmmo", v101)
			end
			local v102
			if v88 > 0 then
				v102 = v88 - 1
			else
				v102 = nil
			end
			if v99:GetAttribute("Charges") ~= v102 then
				v99:SetAttribute("Charges", v102)
			end
			local v103
			if v89 > 0 then
				v103 = v89 - 1
			else
				v103 = nil
			end
			if v99:GetAttribute("MaxCharges") ~= v103 then
				v99:SetAttribute("MaxCharges", v103)
			end
			v99:SetAttribute("Reloading", v90 > 0)
			v99:SetAttribute("ReloadEndsAt", v90 <= 0 and 0 or v77 + v90 / 100)
			v99:SetAttribute("Cooldown", v91 <= 0 and 0 or v77 + v91 / 100)
			v99:SetAttribute("NextCharge", v92 <= 0 and 0 or v77 + v92 / 100)
		end
	end
	for v104, v105 in v_u_20.slots do
		if v78[v104] then
			continue
		end
		v105.tool:Destroy()
		v_u_20.slots[v104] = nil
	end
	for v106, v107 in p74 do
		if type(v106) ~= "string" or (string.sub(v106, 1, 4) ~= "Ammo" or type(v107) ~= "number") then
			continue
		end
		v75.model:SetAttribute(v106, v107)
	end
	local v108 = p74.maxArmor
	if type(v108) == "number" then
		v75.model:SetAttribute("MaxArmor", p74.maxArmor)
	end
	v_u_42()
	v_u_66()
end
function v_u_8.Begin(p110) -- name: Begin
	-- upvalues: (copy) v_u_8, (copy) v_u_20, (copy) v_u_19, (copy) v_u_7
	v_u_8.End()
	v_u_20.active = true
	v_u_20.items = p110
	v_u_20.slots = {}
	v_u_20.heldId = nil
	v_u_20.charge = nil
	v_u_20.aiming = false
	v_u_20.blocking = false
	v_u_20.hp = -1
	v_u_20.armor = -1
	v_u_20.alive = true
	local v111 = Instance.new("Model")
	v111.Name = "ReplayHudSource"
	local v112 = Instance.new("Humanoid")
	v112.MaxHealth = 100
	v112.Health = 100
	v112.Parent = v111
	v111:SetAttribute("Armor", 0)
	v111:SetAttribute("MaxArmor", 0)
	local v113 = Instance.new("Folder")
	v113.Name = "Backpack"
	v113.Parent = v111
	local v114 = Instance.new("Folder")
	v114.Name = "Character"
	v114.Parent = v111
	v_u_20.src = {
		["backpack"] = v113,
		["character"] = v114,
		["model"] = v111
	}
	v_u_20.hum = v112
	local v115 = v_u_19("Controller")
	if v115 then
		local v116 = v115.SetReplayHud
		if type(v116) == "function" then
			local v117 = v115.SetReplayHud
			pcall(v117, true)
		end
	end
	local v118 = v_u_19("Hud")
	if v118 then
		v118.SetVisible(true)
		v118.SetStyle("Dot")
		v118.SetPips(0, 0)
		v118.SetArc(nil)
		v118.SetAmmoCount(nil)
		v118.SetFrozen(false)
	end
	v_u_20.ui = false
	local v119 = v_u_7.ui
	if v119 then
		local v120 = v_u_20
		local v121 = v119.Enter
		local v122 = v_u_20.src
		v120.ui = pcall(v121, v122)
	end
end
function v_u_8.Active() -- name: Active
	-- upvalues: (copy) v_u_20
	return v_u_20.active
end
function v_u_8.UiShown() -- name: UiShown
	-- upvalues: (copy) v_u_20
	return v_u_20.ui
end
function v_u_8.End() -- name: End
	-- upvalues: (copy) v_u_20, (copy) v_u_19, (copy) v_u_7
	if v_u_20.active then
		v_u_20.active = false
		local v123 = v_u_19("Hud")
		if v123 then
			local v124 = v123.StopChannel
			pcall(v124)
			local v125 = v123.SetCharge
			pcall(v125, 0)
			local v126 = v123.SetArc
			pcall(v126, nil)
			local v127 = v123.SetAmmoCount
			pcall(v127, nil)
			local v128 = v123.SetVisible
			pcall(v128, false)
		end
		local v129 = v_u_7.ui
		if v_u_20.ui and v129 then
			local v130 = v129.Leave
			pcall(v130)
		end
		v_u_20.ui = false
		local v131 = v_u_19("Controller")
		if v131 then
			local v132 = v131.SetReplayHud
			if type(v132) == "function" then
				local v133 = v131.SetReplayHud
				pcall(v133, false)
			end
		end
		if v_u_20.src then
			v_u_20.src.model:Destroy()
		end
		v_u_20.src = nil
		v_u_20.hum = nil
		v_u_20.slots = {}
	end
end
function v_u_8.Update(p134, p135, p136, p137, p138) -- name: Update
	-- upvalues: (copy) v_u_20, (copy) v_u_19, (copy) v_u_73, (copy) v_u_4, (copy) v_u_5
	if v_u_20.active then
		local v139 = v_u_19("Hud")
		local v140 = v_u_20.hum
		if v140 then
			local v141 = p136 - v_u_20.hp
			if math.abs(v141) >= 0.5 then
				v_u_20.hp = p136
				v140.Health = math.clamp(p136, 0, 100)
			end
		end
		if v_u_20.src then
			local v142 = p137 - v_u_20.armor
			if math.abs(v142) >= 0.5 then
				v_u_20.armor = p137
				v_u_20.src.model:SetAttribute("Armor", p137)
			end
		end
		if p135 ~= v_u_20.heldId then
			v_u_73(p135)
		end
		if v139 then
			local v143 = v_u_4.F_ALIVE
			local v144 = bit32.btest(p138, v143)
			if v144 ~= v_u_20.alive then
				v_u_20.alive = v144
				v139.SetVisible(v144)
				if not v144 then
					v139.StopChannel()
					v139.SetCharge(0)
					v_u_20.charge = nil
				end
			end
			local v145 = v_u_4.F_BLOCKING
			local v146 = bit32.btest(p138, v145)
			if v146 ~= v_u_20.blocking then
				v_u_20.blocking = v146
				v139.SetBlocking(v146)
			end
			local v147 = v_u_20
			local v148 = v_u_4.F_AIMING
			v147.aiming = bit32.btest(p138, v148)
			local v149 = v_u_20.charge
			if v149 then
				local v150 = v139.SetCharge
				local v151 = p134 - v149.start
				local v152 = v149.time
				local v153 = v151 / math.max(0.05, v152)
				v150((math.clamp(v153, 0, 1)))
			end
			if v_u_20.style == "Gun" or v_u_20.style == "Spread" then
				local v154 = v_u_20.heldId
				local v155 = v_u_5.Tuning
				local v156, v157 = pcall(v155, v154)
				local v158 = (not v156 or type(v157) ~= "table") and {} or v157
				local v159 = v_u_5.Kind(v_u_20.heldId)
				local v160
				if v159 == "Blunderbuss" then
					if v_u_20.aiming then
						v160 = v158.spreadAim or (v158.spread or 6)
					else
						v160 = v158.spread or 6
					end
				elseif v159 == "Crossbow" then
					v160 = 0.4
				elseif v_u_20.aiming then
					v160 = v158.spreadAim or 0
				else
					v160 = v158.spreadHip or 0
				end
				v139.SetSpread(v160)
			end
		end
	else
		return
	end
end
function v_u_8.ChargeAt(p161) -- name: ChargeAt
	-- upvalues: (copy) v_u_20
	local v162 = v_u_20.charge
	if not v162 then
		return 1
	end
	local v163 = p161 - v162.start
	local v164 = v162.time
	local v165 = v163 / math.max(0.05, v164)
	return math.clamp(v165, 0, 1)
end
function v_u_8.HeldCharges() -- name: HeldCharges
	-- upvalues: (copy) v_u_20
	for _, v167 in v_u_20.slots do
		if v167.id ~= v_u_20.heldId then
			continue
		end
	end
	local v167 = nil
	if v167 then
		local v168 = v167.tool:GetAttribute("MaxCharges")
		local v169 = v167.tool:GetAttribute("Charges")
		if type(v168) == "number" and (v168 > 0 and type(v169) == "number") then
			return v169
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_8.OnFighterEvent(p170, p171, p172) -- name: OnFighterEvent
	-- upvalues: (copy) v_u_20, (copy) v_u_19, (copy) v_u_109, (copy) v_u_5, (copy) v_u_27, (copy) v_u_10
	if v_u_20.active then
		local v173 = v_u_19("Hud")
		if p170 == "Inv" then
			v_u_109(p171)
			return
		elseif v173 then
			if p170 == "Charge" then
				if p171.on == true then
					local v174 = p171.weaponId
					local v175
					if type(v174) == "string" then
						v175 = p171.weaponId
					else
						v175 = v_u_20.heldId
					end
					local v176 = v_u_5.Tuning
					local v177, v178 = pcall(v176, v175)
					local v179 = (not v177 or type(v178) ~= "table") and {} or v178
					local v180 = p171.kind
					local v181 = tostring(v180)
					local v182
					if v181 == "Heavy" then
						v182 = v179.heavy and v179.heavy.charge or 0.6
					elseif v181 == "Lunge" then
						v182 = v179.lunge and v179.lunge.charge or 0.6
					elseif v181 == "Throw" then
						v182 = v179.drawTime or 0.5
					else
						v182 = v179.drawTime or 1
					end
					v_u_20.charge = {
						["kind"] = v181,
						["start"] = p172,
						["time"] = v182
					}
				else
					v_u_20.charge = nil
					v173.SetCharge(0)
				end
			elseif p170 == "Projectile" then
				local v183 = v_u_5.Kind(p171.weaponId)
				local v184 = v_u_20.charge
				local v185
				if v184 then
					local v186 = p172 - v184.start
					local v187 = v184.time
					local v188 = v186 / math.max(0.05, v187)
					v185 = math.clamp(v188, 0, 1)
				else
					v185 = 1
				end
				if v183 == "Bow" then
					v173.Kick(v185 * 6)
				elseif v_u_5.UsesAmmo(v183) then
					local v189 = v_u_27(p171.weaponId)
					local v190 = v173.Kick
					local v191 = p171.weaponId
					local v192 = v_u_5.Tuning
					local v193, v194 = pcall(v192, v191)
					v190((((not v193 or type(v194) ~= "table") and {} or v194).kick or (v189.kick or 2)) * 3)
				else
					v173.Kick(4)
					local v195 = p171.weaponId
					local v196 = v_u_5.Tuning
					local v197, v198 = pcall(v196, v195)
					local v199 = ((not v197 or type(v198) ~= "table") and {} or v198).cooldown
					if type(v199) == "number" and v199 >= 0.3 then
						v173.SetArc(v199, v_u_10)
					end
				end
				v_u_20.charge = nil
				v173.SetCharge(0)
				return
			elseif p170 == "Swing" then
				if p171.heavy == true or p171.lunge == true then
					local v200 = p171.weaponId
					local v201 = v_u_5.Tuning
					local v202, v203 = pcall(v201, v200)
					local v204 = (not v202 or type(v203) ~= "table") and {} or v203
					local v205
					if p171.heavy == true then
						v205 = v204.heavy
					else
						v205 = v204.lunge
					end
					v173.SetArc(type(v205) == "table" and (v205.cooldown or 1) or 1, v_u_10)
				end
				v_u_20.charge = nil
				v173.SetCharge(0)
				return
			elseif p170 == "Reload" then
				local v206 = p171.duration
				local v207 = tonumber(v206)
				if not v207 then
					local v208 = p171.weaponId
					local v209 = v_u_5.Tuning
					local v210, v211 = pcall(v209, v208)
					v207 = ((not v210 or type(v211) ~= "table") and {} or v211).reloadTime or 1
				end
				v173.SetArc(v207, v_u_10)
			elseif p170 == "Use" and p171.position == nil then
				local v212 = v_u_27(p171.weaponId)
				local v213 = p171.duration
				local v214 = tonumber(v213)
				if v214 and v214 > 0 then
					v173.StartChannel(v212.label or "USING", v214, v212.color)
					return
				end
			elseif p170 == "Heal" then
				v173.StopChannel()
				v173.Flash(Color3.fromRGB(110, 220, 110), 0.35, 0.4)
			end
		else
			return
		end
	else
		return
	end
end
function v_u_8.HitConfirm(p215, p216) -- name: HitConfirm
	-- upvalues: (copy) v_u_19, (copy) v_u_20
	local v217 = v_u_19("Controller")
	if v_u_20.active and v217 then
		local v218 = v217.ReplayHitConfirm
		if type(v218) == "function" then
			local v219 = v217.ReplayHitConfirm
			local v220 = {
				["victimId"] = p216 or "",
				["victim"] = p215.victim
			}
			local v221 = p215.amount
			v220.amount = tonumber(v221) or 0
			v220.headshot = p215.headshot == true
			v220.crit = p215.crit == true
			v220.killed = p215.killed == true
			v220.blocked = p215.blocked == true
			v220.position = p215.position
			v220.weaponId = p215.weaponId
			v220.dot = p215.dot == true
			local v222 = p215.armor
			v220.armor = tonumber(v222) or 0
			v220.armorBroken = p215.armorBroken == true
			v219(v220)
			return
		end
	end
end
function v_u_8.DamageTaken(p223, p224) -- name: DamageTaken
	-- upvalues: (copy) v_u_19, (copy) v_u_20
	local v225 = v_u_19("Controller")
	if v_u_20.active and v225 then
		local v226 = v225.ReplayDamageTaken
		if type(v226) == "function" then
			local v227 = p223.attacker
			local v228 = p223.fromPosition
			if typeof(v228) ~= "Vector3" and typeof(v227) == "Instance" then
				local v229 = v227:FindFirstChild("HumanoidRootPart")
				if v229 and v229:IsA("BasePart") then
					v228 = v229.Position
				else
					v228 = nil
				end
			end
			local v230 = v225.ReplayDamageTaken
			local v231 = {
				["amount"] = nil,
				["fromPosition"] = nil,
				["attackerId"] = nil,
				["attacker"] = nil,
				["headshot"] = nil,
				["killed"] = nil,
				["blocked"] = nil,
				["knockback"] = false,
				["weaponId"] = nil,
				["damageType"] = nil,
				["stagger"] = nil,
				["armor"] = nil,
				["armorBroken"] = nil,
				["interrupted"] = nil
			}
			local v232 = p223.amount
			v231.amount = tonumber(v232) or 0
			if typeof(v228) ~= "Vector3" then
				v228 = false
			end
			v231.fromPosition = v228
			v231.attackerId = p224 or ""
			v231.attacker = v227
			v231.headshot = p223.headshot == true
			v231.killed = p223.killed == true
			v231.blocked = p223.blocked == true
			local v233 = p223.weaponId
			local v234
			if type(v233) == "string" then
				v234 = p223.weaponId
			else
				v234 = false
			end
			v231.weaponId = v234
			local v235 = p223.damageType
			local v236
			if type(v235) == "string" then
				v236 = p223.damageType
			else
				v236 = false
			end
			v231.damageType = v236
			local v237 = p223.stagger
			local v238
			if type(v237) == "number" then
				v238 = p223.stagger
			else
				v238 = false
			end
			v231.stagger = v238
			local v239 = p223.armor
			v231.armor = tonumber(v239) or 0
			v231.armorBroken = p223.armorBroken == true
			v231.interrupted = p223.interrupted == true
			v230(v231)
			local v240 = p223.interrupted == true and v_u_19("Hud")
			if v240 then
				v240.StopChannel()
			end
			return
		end
	end
end
return v_u_8