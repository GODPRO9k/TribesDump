local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = {}
local v_u_5 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Keybinds"))
local v_u_6 = {
	["Item1"] = 1,
	["Item2"] = 2,
	["Item3"] = 3,
	["Item4"] = 4,
	["Item5"] = 5,
	["Item6"] = 6
}
local v_u_7 = {
	["primary"] = 1,
	["secondary"] = 2,
	["melee"] = 3,
	["utility"] = 4
}
function v_u_4.Init(p_u_8) -- name: Init
	-- upvalues: (copy) v_u_1, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_2, (copy) v_u_5, (copy) v_u_6
	local v_u_9 = p_u_8.UI
	local v_u_10 = p_u_8.Theme
	local v_u_11 = p_u_8.State
	local v_u_12 = p_u_8.WeaponIcon
	local v_u_13 = p_u_8.WeaponInfo
	local v_u_14 = v_u_10.Colors
	local _ = v_u_10.Fonts
	local v_u_15 = v_u_1.LocalPlayer
	local v_u_16 = v_u_9.new("Frame", {
		["Name"] = "Hotbar",
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Size"] = UDim2.fromOffset(566, 98),
		["Parent"] = p_u_8.Canvas.HUD
	})
	local v_u_17 = v_u_9.DisplayText({
		["Name"] = "Equipped",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["TextSize"] = 24,
		["TextColor3"] = nil,
		["TextTransparency"] = 1,
		["StrokeThickness"] = 2,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 0, -4),
		["Size"] = UDim2.fromOffset(420, 28),
		["TextColor3"] = v_u_14.Text,
		["Parent"] = v_u_16
	})
	local v_u_18 = v_u_17:FindFirstChildOfClass("UIStroke")
	v_u_18.Transparency = 1
	local v_u_19 = {}
	local v_u_20 = 0
	local v_u_21 = 4
	p_u_8.HotbarChanged = p_u_8.HotbarChanged or Instance.new("BindableEvent")
	local v_u_22 = v_u_9.PadActionCap("PrevItem", {
		["Height"] = 24,
		["Position"] = nil,
		["ZIndex"] = 3,
		["Position"] = UDim2.fromOffset(4, 4)
	})
	local v_u_23 = v_u_9.PadActionCap("NextItem", {
		["Height"] = 24,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["ZIndex"] = 3,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -4, 0, 4)
	})
	v_u_22.Name = "PadPrev"
	v_u_23.Name = "PadNext"
	function p_u_8.HotbarTop() -- name: HotbarTop
		-- upvalues: (copy) v_u_9
		return (v_u_9.Compact and 76 or 86) + 12 + (v_u_9.Compact and 8 or 18)
	end
	function p_u_8.HotbarWidth() -- name: HotbarWidth
		-- upvalues: (copy) v_u_9, (ref) v_u_21
		local v24 = v_u_9.Compact and 76 or 86
		local v25 = v_u_9.Compact and 6 or 10
		local v26 = v_u_21 * v24 + (v_u_21 - 1) * v25
		local v27 = v24 * 4 + v25 * 3
		return math.max(v26, v27)
	end
	local v_u_28 = nil
	local function v_u_40() -- name: layout
		-- upvalues: (copy) v_u_9, (copy) v_u_16, (ref) v_u_21, (copy) v_u_19, (ref) v_u_20, (copy) v_u_22, (copy) v_u_23
		local v29 = v_u_9.Compact and 76 or 86
		local v30 = v_u_9.Compact and 6 or 10
		v_u_16.Size = UDim2.fromOffset(v_u_21 * v29 + (v_u_21 - 1) * v30, v29 + 12)
		v_u_16.Position = UDim2.new(0.5, 0, 1, v_u_9.Compact and -8 or -18)
		for v31, v32 in v_u_19 do
			v32.holder.Visible = v31 <= v_u_21
			v32.holder.Size = UDim2.fromOffset(v29, v29)
			v32.holder.Position = UDim2.fromOffset((v31 - 1) * (v29 + v30), v31 == v_u_20 and 0 or 12)
		end
		local v33 = v_u_19[1]
		local v34 = v_u_21
		local v35 = v_u_19[math.clamp(v34, 1, 6)]
		if v33 and v35 then
			local v36 = v_u_22
			local v37 = v_u_23
			local v38 = v33.face
			local v39 = v35.face
			v36.Parent = v38
			v37.Parent = v39
		end
	end
	local v_u_41 = 0
	local v_u_42 = nil
	for v_u_43 = 1, 6 do
		local v44 = v_u_9.new("TextButton", {
			["Name"] = nil,
			["Size"] = nil,
			["Position"] = nil,
			["Selectable"] = false,
			["Parent"] = nil,
			["Name"] = "Slot" .. v_u_43,
			["Size"] = UDim2.fromOffset(86, 86),
			["Position"] = UDim2.fromOffset((v_u_43 - 1) * 96, 12),
			["Parent"] = v_u_16
		})
		local v45 = v_u_9.new("Frame", {
			["Name"] = "Face",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["BackgroundTransparency"] = 0.2,
			v_u_9.Corner(12),
			v_u_9.Gradient(v_u_14.PanelHi, v_u_14.PanelLo, 90),
			["Parent"] = v44
		})
		local v_u_46 = v_u_9.Stroke(v_u_14.Stroke, 2, 0.7)
		v_u_46.Parent = v45
		local v47 = v_u_9.new("Frame", {
			["Name"] = "Icon",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.new(1, -14, 1, -14),
			["Parent"] = v45
		})
		local v48 = v_u_9.ActionCap("Item" .. v_u_43, {
			["Height"] = 22,
			["Position"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(5, 5),
			["Parent"] = v45
		})
		local v49 = v_u_9.DisplayText({
			["Name"] = "Ammo",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["TextSize"] = 22,
			["TextXAlignment"] = nil,
			["ZIndex"] = 4,
			["StrokeThickness"] = 2,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(1, -6, 1, -3),
			["Size"] = UDim2.fromOffset(60, 24),
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["Parent"] = v45
		})
		local v50 = v_u_9.new("Frame", {
			["Name"] = "Pips",
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, -5),
			["Size"] = UDim2.new(1, -12, 0, 8),
			["Visible"] = false,
			["ZIndex"] = 4,
			v_u_9.List(Enum.FillDirection.Horizontal, 4, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
			["Parent"] = v45
		})
		local v51 = v_u_9.new("Frame", {
			["Name"] = "Reload",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = v_u_14.Void,
			["BackgroundTransparency"] = 0.4,
			["Visible"] = false,
			["ZIndex"] = 5,
			["ClipsDescendants"] = true,
			v_u_9.Corner(12),
			["Parent"] = v45
		})
		local v52 = v_u_9.new("Frame", {
			["Name"] = "Fill",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.55,
			["ZIndex"] = 5,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.fromScale(0, 1),
			["Size"] = UDim2.fromScale(1, 0),
			["BackgroundColor3"] = v_u_14.Accent,
			["Parent"] = v51
		})
		v_u_9.DisplayText({
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "RELOAD",
			["TextSize"] = 16,
			["TextColor3"] = nil,
			["ZIndex"] = 6,
			["StrokeThickness"] = 1.5,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.new(1, 0, 0, 20),
			["TextColor3"] = v_u_14.Accent,
			["Parent"] = v51
		}).Name = "Label"
		local v53 = v_u_9.new("Frame", {
			["Name"] = "Cooldown",
			["Size"] = nil,
			["ClipsDescendants"] = true,
			["Visible"] = false,
			["ZIndex"] = 5,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v45
		})
		local v54 = v_u_9.new("Frame", {
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.fromScale(0, 1),
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = v_u_14.Void,
			["BackgroundTransparency"] = 0.45,
			["ZIndex"] = 5,
			v_u_9.Corner(12),
			["Parent"] = v53
		})
		local v55 = v_u_9.new("Frame", {
			["Name"] = "Regen",
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, -2),
			["Size"] = UDim2.new(1, -20, 0, 3),
			["BackgroundColor3"] = v_u_14.Void,
			["BackgroundTransparency"] = 0.3,
			["Visible"] = false,
			["ZIndex"] = 4,
			v_u_9.Corner(2),
			["Parent"] = v45
		})
		local v_u_56 = {
			["holder"] = nil,
			["face"] = nil,
			["stroke"] = nil,
			["icon"] = nil,
			["key"] = nil,
			["ammo"] = nil,
			["pips"] = nil,
			["reload"] = nil,
			["reloadFill"] = nil,
			["cool"] = nil,
			["coolFill"] = nil,
			["regen"] = nil,
			["regenFill"] = nil,
			["timers"] = nil,
			["tool"] = nil,
			["weaponId"] = nil,
			["holder"] = v44,
			["face"] = v45,
			["stroke"] = v_u_46,
			["icon"] = v47,
			["key"] = v48,
			["ammo"] = v49,
			["pips"] = v50,
			["reload"] = v51,
			["reloadFill"] = v52,
			["cool"] = v53,
			["coolFill"] = v54,
			["regen"] = v55,
			["regenFill"] = v_u_9.new("Frame", {
				["Size"] = UDim2.fromScale(0, 1),
				["BackgroundColor3"] = v_u_14.Bone,
				["ZIndex"] = 4,
				v_u_9.Corner(2),
				["Parent"] = v55
			}),
			["timers"] = {}
		}
		v_u_19[v_u_43] = v_u_56
		v44.Activated:Connect(function()
			-- upvalues: (ref) v_u_28, (copy) v_u_43
			v_u_28(v_u_43)
		end)
		v44.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_56, (ref) v_u_20, (copy) v_u_43, (copy) v_u_9, (copy) v_u_46, (copy) v_u_10
			if v_u_56.tool and v_u_20 ~= v_u_43 then
				v_u_9.Tween(v_u_46, v_u_10.Tween.Fast, {
					["Transparency"] = 0.35
				})
			end
		end)
		v44.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_20, (copy) v_u_43, (copy) v_u_9, (copy) v_u_46, (copy) v_u_10
			if v_u_20 ~= v_u_43 then
				v_u_9.Tween(v_u_46, v_u_10.Tween.Fast, {
					["Transparency"] = 0.7
				})
			end
		end)
	end
	v_u_40()
	v_u_9.LayoutChanged:Connect(v_u_40)
	local v_u_57 = nil
	local function v_u_66() -- name: toolsBySlot
		-- upvalues: (ref) v_u_7, (ref) v_u_57, (copy) v_u_15
		local v_u_58 = {}
		local function v63(p59) -- name: scan
			-- upvalues: (ref) v_u_7, (copy) v_u_58
			if p59 then
				for _, v60 in p59:GetChildren() do
					if not v60:IsA("Tool") then
						continue
					end
					local v61 = v60:GetAttribute("SlotIndex")
					if type(v61) ~= "number" or (v61 < 1 or v61 > 6) then
						local v62 = v60:GetAttribute("Slot")
						if type(v62) == "string" then
							v61 = v_u_7[v62]
						else
							v61 = nil
						end
					end
					if not v61 then
						continue
					end
					v_u_58[v61] = v60
				end
			end
		end
		local v64
		if v_u_57 then
			v64 = v_u_57.backpack
		else
			v64 = v_u_15:FindFirstChildOfClass("Backpack")
		end
		v63(v64)
		local v65
		if v_u_57 then
			v65 = v_u_57.character
		else
			v65 = v_u_15.Character
		end
		v63(v65)
		return v_u_58
	end
	local function v_u_78(p67, p68, p69) -- name: setPips
		-- upvalues: (copy) v_u_9, (copy) v_u_14
		local v70 = {}
		for _, v71 in p67.pips:GetChildren() do
			if not v71:IsA("Frame") then
				continue
			end
			table.insert(v70, v71)
		end
		for v72 = #v70 + 1, p69 do
			local v73 = v_u_9.new
			local v74 = {
				["Size"] = UDim2.fromOffset(12, 6),
				["BackgroundColor3"] = v_u_14.Accent,
				["LayoutOrder"] = v72,
				["ZIndex"] = 4,
				v_u_9.Corner(3),
				v_u_9.Stroke(v_u_14.Void, 1, 0.4),
				["Parent"] = p67.pips
			}
			table.insert(v70, v73("Frame", v74))
		end
		for v75, v76 in v70 do
			v76.Visible = v75 <= p69
			local v77
			if v75 <= p68 then
				v77 = v_u_14.Accent
			else
				v77 = Color3.fromRGB(60, 64, 78)
			end
			v76.BackgroundColor3 = v77
		end
	end
	local v_u_79 = nil
	local function v_u_88() -- name: stepTimers
		-- upvalues: (copy) v_u_11, (copy) v_u_19, (ref) v_u_79
		local v80 = v_u_11.Now()
		local v81 = false
		for _, v82 in v_u_19 do
			for v83, v84 in v82.timers do
				local v85 = v84.endsAt - v80
				local v86
				if v84.total > 0 then
					local v87 = v85 / v84.total
					v86 = 1 - math.clamp(v87, 0, 1)
				else
					v86 = 1
				end
				if v83 == "reload" then
					v82.reloadFill.Size = UDim2.fromScale(1, v86)
				elseif v83 == "cooldown" then
					v82.coolFill.Size = UDim2.fromScale(1, 1 - v86)
				elseif v83 == "regen" then
					v82.regenFill.Size = UDim2.fromScale(v86, 1)
				end
				if v85 <= 0 then
					v82.timers[v83] = nil
					if v83 == "cooldown" then
						v82.cool.Visible = false
					else
						if v83 ~= "regen" then
							continue
						end
						v82.regen.Visible = false
					end
				else
					v81 = true
				end
			end
		end
		if not v81 and v_u_79 then
			v_u_79:Disconnect()
			v_u_79 = nil
		end
	end
	local function v_u_99(p89, p90, p91)
		-- upvalues: (copy) v_u_11, (ref) v_u_79, (ref) v_u_3, (copy) v_u_88
		local v92 = v_u_11.Now()
		local v93
		if type(p91) == "number" then
			v93 = v92 < p91
		else
			v93 = false
		end
		local v94 = p89.timers[p90]
		if v93 then
			local v95, v96, v97
			if v94 then
				local v98 = v94.endsAt - p91
				if math.abs(v98) > 0.01 then
					v95 = p89.timers
					v96 = {
						["endsAt"] = p91
					}
					v97 = p91 - v92
					v96.total = math.max(0.1, v97)
					v95[p90] = v96
					if p90 == "cooldown" then
						p89.cool.Visible = v93
					elseif p90 == "regen" then
						p89.regen.Visible = v93
					elseif p90 == "reload" and not v93 then
						p89.reloadFill.Size = UDim2.fromScale(1, p89.reload.Visible and 1 or 0)
					end
					if v93 and not v_u_79 then
						v_u_79 = v_u_3.RenderStepped:Connect(v_u_88)
					end
				else
					if p90 == "cooldown" then
						p89.cool.Visible = v93
					elseif p90 == "regen" then
						p89.regen.Visible = v93
					elseif p90 == "reload" and not v93 then
						p89.reloadFill.Size = UDim2.fromScale(1, p89.reload.Visible and 1 or 0)
					end
					if v93 and not v_u_79 then
						v_u_79 = v_u_3.RenderStepped:Connect(v_u_88)
					end
				end
			else
				v95 = p89.timers
				v96 = {
					["endsAt"] = p91
				}
				v97 = p91 - v92
				v96.total = math.max(0.1, v97)
				v95[p90] = v96
				if p90 == "cooldown" then
					p89.cool.Visible = v93
				elseif p90 == "regen" then
					p89.regen.Visible = v93
				elseif p90 == "reload" and not v93 then
					p89.reloadFill.Size = UDim2.fromScale(1, p89.reload.Visible and 1 or 0)
				end
				if v93 and not v_u_79 then
					v_u_79 = v_u_3.RenderStepped:Connect(v_u_88)
				end
				return
			end
		else
			p89.timers[p90] = nil
			if p90 == "cooldown" then
				p89.cool.Visible = v93
			elseif p90 == "regen" then
				p89.regen.Visible = v93
			elseif p90 == "reload" and not v93 then
				p89.reloadFill.Size = UDim2.fromScale(1, p89.reload.Visible and 1 or 0)
			end
			if v93 and not v_u_79 then
				v_u_79 = v_u_3.RenderStepped:Connect(v_u_88)
			end
			return
		end
	end
	local function v_u_100()
		return {}
	end
	local v101, v102 = pcall(function()
		return require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Weapons"))
	end)
	if v101 and type(v102) == "table" then
		local v103 = v102.AltAmmo
		if type(v103) == "function" then
			v_u_100 = v102.AltAmmo
		end
	end
	local function v_u_109(p104) -- name: reserveOf
		-- upvalues: (ref) v_u_57, (copy) v_u_15, (ref) v_u_100
		if not p104 then
			return nil
		end
		local v105
		if v_u_57 then
			v105 = v_u_57.model
		else
			v105 = v_u_15.Character
		end
		local v106
		if v105 then
			v106 = v105:GetAttribute("Ammo_" .. p104)
		else
			v106 = v105
		end
		if type(v106) ~= "number" then
			v106 = v_u_15:GetAttribute("Ammo_" .. p104)
		end
		if type(v106) ~= "number" then
			v106 = nil
		end
		for _, v107 in v_u_100(p104) do
			local v108
			if v105 then
				v108 = v105:GetAttribute("Ammo_" .. v107)
			else
				v108 = v105
			end
			if type(v108) ~= "number" then
				v108 = v_u_15:GetAttribute("Ammo_" .. v107)
			end
			if type(v108) ~= "number" then
				v108 = nil
			end
			if not v108 then
				continue
			end
			v106 = (v106 or 0) + v108
		end
		return v106
	end
	v_u_4.ReserveOf = v_u_109
	local function v_u_130(p110) -- name: refreshState
		-- upvalues: (copy) v_u_19, (ref) v_u_99, (copy) v_u_13, (copy) v_u_109, (copy) v_u_78, (copy) v_u_14, (copy) v_u_9
		local v111 = v_u_19[p110]
		local v112 = v111.tool
		if v112 then
			local v113 = v112:GetAttribute("Ammo")
			local v114 = v112:GetAttribute("MaxAmmo")
			local v115 = v112:GetAttribute("Charges")
			local v116 = v112:GetAttribute("MaxCharges")
			local v117
			if type(v113) == "number" then
				v117 = v113
			elseif type(v115) == "number" then
				v117 = v115
			else
				v117 = nil
			end
			if type(v113) == "number" then
				if type(v114) ~= "number" then
					v114 = nil
				end
			elseif type(v116) == "number" then
				v114 = v116
			else
				v114 = nil
			end
			local v118 = v_u_109((v_u_13.AmmoOf(v111.weaponId)))
			if v118 then
				v114 = nil
			else
				v118 = v117
			end
			if v118 then
				if v114 and (v114 <= 6 and v114 > 1) then
					v111.pips.Visible = true
					v111.ammo.Text = ""
					v_u_78(v111, v118, v114)
				else
					v111.pips.Visible = false
					v111.ammo.Text = tostring(v118)
				end
				local v119 = v111.ammo
				local v120
				if v118 <= 0 then
					v120 = v_u_14.Danger
				else
					v120 = v_u_14.Text
				end
				v119.TextColor3 = v120
				if v111.lastAmmo and v118 < v111.lastAmmo then
					v_u_9.Bump(v111.ammo, 0.2)
				end
				v111.lastAmmo = v118
			else
				v111.ammo.Text = ""
				v111.pips.Visible = false
				v111.lastAmmo = nil
			end
			local v121 = v112:GetAttribute("Reloading") == true
			if v121 ~= v111.reload.Visible then
				v111.reload.Visible = v121
				if not v121 and (v118 and v118 > 0) then
					v_u_9.Pop(v111.ammo, 1.4)
				end
			end
			local v122 = v_u_99
			local v123 = "reload"
			local v124
			if v121 then
				v124 = v112:GetAttribute("ReloadEndsAt")
			else
				v124 = nil
			end
			v122(v111, v123, v124)
			v_u_99(v111, "cooldown", v112:GetAttribute("Cooldown"))
			local v125
			if type(v115) == "number" and type(v116) == "number" then
				v125 = v116 <= v115
			else
				v125 = false
			end
			local v126 = v_u_99
			local v127 = "regen"
			local v128
			if v125 then
				v128 = nil
			else
				v128 = v112:GetAttribute("NextCharge")
			end
			v126(v111, v127, v128)
		else
			v111.ammo.Text = ""
			v111.pips.Visible = false
			v111.reload.Visible = false
			for v129 in v111.timers do
				v_u_99(v111, v129, nil)
			end
		end
	end
	local function v_u_139(p131) -- name: paintSelection
		-- upvalues: (copy) v_u_19, (ref) v_u_20, (copy) v_u_9, (copy) v_u_10, (copy) v_u_14, (copy) v_u_12
		for v132, v133 in v_u_19 do
			local v134 = v132 == v_u_20
			local v135 = v133.tool ~= nil
			local v136 = UDim2.fromOffset(v133.holder.Position.X.Offset, v134 and 0 or 12)
			if p131 then
				v_u_9.Tween(v133.holder, v_u_10.Tween.PopSmall, {
					["Position"] = v136
				})
			else
				v133.holder.Position = v136
			end
			local v137 = v133.stroke
			local v138
			if v134 then
				v138 = v_u_14.Accent
			else
				v138 = v_u_14.Stroke
			end
			v137.Color = v138
			v133.stroke.Thickness = v134 and 3 or 2
			v133.stroke.Transparency = v134 and 0 or 0.7
			v133.face.BackgroundTransparency = v134 and 0.05 or (v135 and 0.2 or 0.5)
			v_u_12.SetDim(v133.icon, not v135)
		end
	end
	local function v_u_156() -- name: rebuild
		-- upvalues: (copy) v_u_66, (copy) v_u_19, (copy) v_u_130, (ref) v_u_20, (ref) v_u_4, (copy) v_u_12, (ref) v_u_57, (copy) v_u_15, (ref) v_u_7, (ref) v_u_42, (ref) v_u_41, (copy) v_u_139, (copy) p_u_8, (copy) v_u_9, (copy) v_u_17, (copy) v_u_11, (copy) v_u_13, (copy) v_u_18, (copy) v_u_10, (ref) v_u_21, (copy) v_u_40
		local v140 = v_u_66()
		local v141 = false
		for v_u_142, v143 in v_u_19 do
			local v144 = v140[v_u_142]
			if v144 ~= v143.tool then
				if v143.conn then
					v143.conn:Disconnect()
					v143.conn = nil
				end
				v143.reload.Visible = false
				v143.lastAmmo = nil
				v143.tool = v144
				if v144 then
					v143.conn = v144.AttributeChanged:Connect(function()
						-- upvalues: (ref) v_u_130, (copy) v_u_142, (ref) v_u_20, (ref) v_u_4
						v_u_130(v_u_142)
						if v_u_142 == v_u_20 and v_u_4.RefreshCrosshairAmmo then
							v_u_4.RefreshCrosshairAmmo()
						end
					end)
				end
			end
			local v145
			if v144 then
				v145 = v144:GetAttribute("WeaponId")
			else
				v145 = v144
			end
			if type(v145) ~= "string" then
				if v144 then
					v145 = v144.Name
				else
					v145 = nil
				end
			end
			if v145 ~= v143.weaponId then
				v143.weaponId = v145
				v_u_12.Set(v143.icon, v145)
			end
			v_u_130(v_u_142)
			if not v144 then
				continue
			end
			v141 = true
		end
		local v146
		if v_u_57 then
			v146 = v_u_57.character
		else
			v146 = v_u_15.Character
		end
		if v146 then
			v146 = v146:FindFirstChildOfClass("Tool")
		end
		local v_u_147
		if v146 then
			local v148 = v146:GetAttribute("SlotIndex")
			if type(v148) ~= "number" or (v148 < 1 or v148 > 6) then
				local v149 = v146:GetAttribute("Slot")
				if type(v149) == "string" then
					v148 = v_u_7[v149]
				else
					v148 = nil
				end
			end
			v_u_147 = v148 or 0
		else
			v_u_147 = 0
		end
		local v150
		if v_u_147 == 0 then
			v150 = nil
		else
			v150 = v_u_19[v_u_147].weaponId
		end
		if v_u_147 == v_u_20 and v150 == v_u_42 then
			v_u_139(false)
		else
			if v_u_20 ~= 0 and v_u_147 ~= v_u_20 then
				v_u_41 = v_u_20
			end
			v_u_20 = v_u_147
			v_u_42 = v150
			v_u_139(true)
			p_u_8.HeldWeaponChanged:Fire(v150)
			if v_u_147 ~= 0 and v_u_19[v_u_147].tool then
				local v151 = v_u_19[v_u_147]
				v_u_9.Pop(v151.icon, 0.8)
				v_u_17.Position = UDim2.new(0.5, 0, 0, v_u_11.InMatch() and -70 or -4)
				v_u_17.Text = string.upper(v_u_13.Name(v151.weaponId))
				v_u_17.TextTransparency = 0
				v_u_18.Transparency = 0.1
				task.delay(1.1, function()
					-- upvalues: (ref) v_u_20, (copy) v_u_147, (ref) v_u_9, (ref) v_u_17, (ref) v_u_10, (ref) v_u_18
					if v_u_20 == v_u_147 then
						v_u_9.Tween(v_u_17, v_u_10.Tween.Slow, {
							["TextTransparency"] = 1
						})
						v_u_9.Tween(v_u_18, v_u_10.Tween.Slow, {
							["Transparency"] = 1
						})
					end
				end)
			end
		end
		v_u_4.HasTools = v141
		local v152 = 0
		for v153, v154 in v_u_19 do
			if not v154.tool then
				continue
			end
			v152 = v153
		end
		local v155 = math.max(v152, 1)
		if v155 ~= v_u_21 then
			v_u_21 = v155
			v_u_40()
			p_u_8.HotbarChanged:Fire()
		end
		v_u_4.RefreshVisible()
	end
	local v_u_157 = false
	local function v_u_158() -- name: queueRebuild
		-- upvalues: (ref) v_u_157, (copy) v_u_156
		if not v_u_157 then
			v_u_157 = true
			task.defer(function()
				-- upvalues: (ref) v_u_157, (ref) v_u_156
				v_u_157 = false
				v_u_156()
			end)
		end
	end
	local v_u_159 = {}
	local function v_u_175() -- name: rewatch
		-- upvalues: (copy) v_u_159, (ref) v_u_57, (copy) v_u_15, (copy) v_u_158, (ref) v_u_157, (copy) v_u_156
		for _, v160 in v_u_159 do
			v160:Disconnect()
		end
		table.clear(v_u_159)
		local v161
		if v_u_57 then
			v161 = v_u_57.backpack
		else
			v161 = v_u_15:FindFirstChildOfClass("Backpack")
		end
		if v161 then
			local v162 = v_u_159
			local v163 = v161.ChildAdded
			local v164 = v_u_158
			table.insert(v162, v163:Connect(v164))
			local v165 = v_u_159
			local v166 = v161.ChildRemoved
			local v167 = v_u_158
			table.insert(v165, v166:Connect(v167))
		end
		local v168
		if v_u_57 then
			v168 = v_u_57.character
		else
			v168 = v_u_15.Character
		end
		if v168 then
			local v169 = v_u_159
			local v170 = v168.ChildAdded
			local v171 = v_u_158
			table.insert(v169, v170:Connect(v171))
			local v172 = v_u_159
			local v173 = v168.ChildRemoved
			local v174 = v_u_158
			table.insert(v172, v173:Connect(v174))
		end
		if not v_u_157 then
			v_u_157 = true
			task.defer(function()
				-- upvalues: (ref) v_u_157, (ref) v_u_156
				v_u_157 = false
				v_u_156()
			end)
		end
	end
	v_u_15.ChildAdded:Connect(function(p176)
		-- upvalues: (copy) v_u_175
		if p176:IsA("Backpack") then
			v_u_175()
		end
	end)
	local v_u_177 = v_u_9.new("Frame", {
		["Name"] = "CrosshairAmmo",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 0),
		["Position"] = UDim2.new(0.5, 34, 0.5, 26),
		["Size"] = UDim2.fromOffset(240, 26),
		["Parent"] = p_u_8.Canvas.HUD
	})
	local v_u_178 = v_u_9.DisplayText({
		["Name"] = "Count",
		["Size"] = nil,
		["Text"] = "12",
		["TextSize"] = 22,
		["TextXAlignment"] = nil,
		["StrokeThickness"] = 1.5,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(60, 26),
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_177
	})
	local v_u_179 = v_u_9.DisplayText({
		["Name"] = "Out",
		["Size"] = nil,
		["Text"] = "OUT OF ARROWS",
		["TextSize"] = 18,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["StrokeThickness"] = 1.5,
		["Visible"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(240, 26),
		["TextColor3"] = v_u_14.Danger,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v_u_177
	})
	local v_u_180 = -1
	local function v_u_191() -- name: refreshCrosshairAmmo
		-- upvalues: (ref) v_u_20, (copy) v_u_19, (copy) v_u_13, (copy) v_u_109, (copy) p_u_8, (copy) v_u_16, (copy) v_u_177, (ref) v_u_180, (copy) v_u_179, (copy) v_u_178, (copy) v_u_14, (copy) v_u_9
		local v181
		if v_u_20 == 0 then
			v181 = nil
		else
			v181 = v_u_19[v_u_20]
		end
		local v182
		if v181 then
			v182 = v_u_13.AmmoOf(v181.weaponId)
		else
			v182 = v181
		end
		local v183 = v_u_109(v182)
		local v184 = p_u_8.PlayerGui:FindFirstChild("CombatHUD") ~= nil
		local v185 = v_u_16.Visible
		if v185 then
			if v183 == nil then
				v185 = false
			else
				v185 = not v184
			end
		end
		v_u_177.Visible = v185
		if v185 and v181 then
			local v186 = v181.tool
			if v186 then
				v186 = v186:GetAttribute("Ammo")
			end
			local v187 = v183 + (type(v186) ~= "number" and 0 or v186)
			local v188 = v_u_13.AmmoDef(v182)
			v_u_179.Text = "OUT OF " .. string.upper(v188 and v188.name or "AMMO")
			v_u_179.Visible = v187 <= 0
			v_u_178.Visible = v187 > 0
			v_u_178.Text = tostring(v187)
			local v189 = v_u_178
			local v190
			if v187 <= 3 then
				v190 = v_u_14.Warning
			else
				v190 = v_u_14.Text
			end
			v189.TextColor3 = v190
			if v187 ~= v_u_180 then
				if v187 < v_u_180 and v187 > 0 then
					v_u_9.Bump(v_u_178, 0.15)
				elseif v187 <= 0 and v_u_180 > 0 then
					v_u_9.Pop(v_u_179, 1.3)
				end
				v_u_180 = v187
			end
		else
			v_u_180 = -1
		end
	end
	v_u_4.RefreshCrosshairAmmo = v_u_191
	p_u_8.HeldWeaponChanged:Connect(v_u_191)
	local v_u_192 = {}
	local function v_u_202(p193) -- name: hookAmmoAttrs
		-- upvalues: (copy) v_u_192, (copy) v_u_19, (copy) v_u_130, (copy) v_u_191, (copy) v_u_15
		for _, v194 in v_u_192 do
			v194:Disconnect()
		end
		table.clear(v_u_192)
		local function v197(p195) -- name: onAttr
			-- upvalues: (ref) v_u_19, (ref) v_u_130, (ref) v_u_191
			if string.sub(p195, 1, 5) == "Ammo_" then
				for v196 in v_u_19 do
					v_u_130(v196)
				end
				v_u_191()
			end
		end
		if p193 then
			local v198 = v_u_192
			local v199 = p193.AttributeChanged
			table.insert(v198, v199:Connect(v197))
		end
		local v200 = v_u_192
		local v201 = v_u_15.AttributeChanged
		table.insert(v200, v201:Connect(v197))
	end
	v_u_202(v_u_15.Character)
	v_u_15.CharacterAdded:Connect(function(p203)
		-- upvalues: (copy) v_u_175, (copy) v_u_202, (ref) v_u_4
		task.defer(v_u_175)
		v_u_202(p203)
		local v204 = p203:WaitForChild("Humanoid", 10)
		if v204 and v204:IsA("Humanoid") then
			v204.Died:Connect(function()
				-- upvalues: (ref) v_u_4
				v_u_4.RefreshVisible()
			end)
		end
	end)
	v_u_175()
	local v_u_205 = nil
	local function v_u_211() -- name: combat
		-- upvalues: (ref) v_u_205, (copy) v_u_15
		if v_u_205 == nil then
			local v206 = v_u_15:FindFirstChildOfClass("PlayerScripts")
			if v206 then
				v206 = v206:FindFirstChild("Combat")
			end
			if v206 then
				v206 = v206:FindFirstChild("Controller")
			end
			if v206 and v206:IsA("ModuleScript") then
				local v207 = require
				local v208, v209 = pcall(v207, v206)
				if v208 and type(v209) == "table" then
					local v210 = v209.Equip
					if type(v210) ~= "function" then
						v209 = false
					end
				else
					v209 = false
				end
				v_u_205 = v209
			end
		end
		return v_u_205 or nil
	end
	local function v_u_218(p212)
		-- upvalues: (copy) v_u_19, (copy) v_u_9, (copy) v_u_15, (ref) v_u_57, (copy) v_u_211, (ref) v_u_157, (copy) v_u_156
		local v213 = v_u_19[p212]
		if v213 and v213.tool then
			local v214 = v_u_15.Character
			if v214 then
				v214 = v214:FindFirstChildOfClass("Humanoid")
			end
			if v214 and (v214.Health > 0 and not v_u_57) then
				local v215 = v_u_211()
				local v216 = v213.tool.Parent == v_u_15.Character
				if v215 then
					local v217 = v215.Wanted
					if type(v217) == "function" then
						if v216 then
							v216 = v215.Wanted() == v213.tool
						end
					end
				end
				if v216 then
					v_u_9.Bump(v213.icon, 0.1)
					return
				else
					if v215 then
						v215.Equip(v213.tool)
					else
						v214:EquipTool(v213.tool)
					end
					if not v_u_157 then
						v_u_157 = true
						task.defer(function()
							-- upvalues: (ref) v_u_157, (ref) v_u_156
							v_u_157 = false
							v_u_156()
						end)
					end
				end
			else
				return
			end
		else
			if v213 then
				v_u_9.Shake(v213.holder, 4)
			end
			return
		end
	end
	v_u_4.Equip = v_u_218
	function p_u_8.Debug.equip(p219)
		-- upvalues: (ref) v_u_218, (ref) v_u_57, (copy) v_u_15, (ref) v_u_7
		v_u_218(p219)
		local v220
		if v_u_57 then
			v220 = v_u_57.character
		else
			v220 = v_u_15.Character
		end
		if v220 then
			v220 = v220:FindFirstChildOfClass("Tool")
		end
		if not v220 then
			return 0
		end
		local v221 = v220:GetAttribute("SlotIndex")
		if type(v221) ~= "number" or (v221 < 1 or v221 > 6) then
			local v222 = v220:GetAttribute("Slot")
			if type(v222) == "string" then
				v221 = v_u_7[v222]
			else
				v221 = nil
			end
		end
		return v221 or 0
	end
	local function v_u_227(p223) -- name: cycle
		-- upvalues: (ref) v_u_20, (copy) v_u_19, (ref) v_u_218
		local v224
		if v_u_20 == 0 then
			v224 = p223 > 0 and 0 or 7
		else
			v224 = v_u_20
		end
		for v225 = 1, 6 do
			local v226 = (v224 - 1 + p223 * v225) % 6 + 1
			if not v_u_19[v226].tool then
				continue
			end
			v_u_218(v226)
			return
		end
	end
	v_u_5.OnInput("Began", function(p228, p229)
		-- upvalues: (ref) v_u_5, (ref) v_u_2, (copy) p_u_8, (copy) v_u_16, (ref) v_u_41, (ref) v_u_20, (copy) v_u_19, (ref) v_u_218, (copy) v_u_227, (ref) v_u_6
		local v230 = v_u_5.IsPad(p228, "PrevItem")
		local v231 = v_u_5.IsPad(p228, "NextItem")
		local v232 = v_u_5.IsPad(p228, "LastItem")
		if v230 or (v231 or v232) then
			if not v_u_2:GetFocusedTextBox() and (not (p_u_8.MenuManager.RecentlyOpen(0.2) or p_u_8.HudHidden) and v_u_16.Visible) and not p_u_8.MenuManager.PadBlocked() then
				if v232 then
					if v_u_41 ~= 0 and (v_u_41 ~= v_u_20 and v_u_19[v_u_41].tool) then
						v_u_218(v_u_41)
						return
					end
				else
					v_u_227(v230 and -1 or 1)
				end
			end
		else
			local v233 = v_u_5.ActionOf(p228)
			if v233 and (not (p229 or v_u_2:GetFocusedTextBox()) and (not (p_u_8.MenuManager.RecentlyOpen(0.2) or p_u_8.HudHidden) and v_u_16.Visible)) then
				local v234 = v_u_6[v233]
				if v234 then
					v_u_218(v234)
				elseif v233 == "LastItem" and (v_u_41 ~= 0 and (v_u_41 ~= v_u_20 and v_u_19[v_u_41].tool)) then
					v_u_218(v_u_41)
				end
			else
				return
			end
		end
	end)
	v_u_2.InputChanged:Connect(function(p235, p236)
		-- upvalues: (ref) v_u_2, (copy) p_u_8, (copy) v_u_16, (copy) v_u_227
		if p235.UserInputType == Enum.UserInputType.MouseWheel and (not (p236 or v_u_2:GetFocusedTextBox()) and (not (p_u_8.MenuManager.RecentlyOpen(0.2) or p_u_8.HudHidden) and v_u_16.Visible)) then
			v_u_227(p235.Position.Z > 0 and -1 or 1)
		end
	end)
	function v_u_4.RefreshVisible() -- name: RefreshVisible
		-- upvalues: (ref) v_u_4, (copy) p_u_8, (copy) v_u_11, (ref) v_u_57, (copy) v_u_16, (copy) v_u_9, (copy) v_u_10
		local v237 = v_u_4.HasTools == true and (not p_u_8.HudHidden and v_u_11.IsAlive())
		if v237 then
			if v_u_11.Get("CombatMode") == false then
				v237 = false
			else
				v237 = not v_u_11.Watching()
			end
		end
		if v_u_57 then
			v237 = v_u_4.HasTools == true
		end
		if v_u_4.RefreshCrosshairAmmo then
			task.defer(v_u_4.RefreshCrosshairAmmo)
		end
		if v237 ~= v_u_16.Visible then
			v_u_16.Visible = v237
			if v237 then
				v_u_9.SlideIn(v_u_16, Vector2.new(0, 30), v_u_10.Tween.PopSmall)
			end
		end
	end
	p_u_8.HudHiddenChanged:Connect(v_u_4.RefreshVisible)
	v_u_11.AttrChanged:Connect(function(p238)
		-- upvalues: (ref) v_u_4
		if p238 == "Alive" or (p238 == "State" or (p238 == "CombatMode" or p238 == "Spectating")) then
			v_u_4.RefreshVisible()
		end
	end)
	function v_u_4.SetReplaySource(p239) -- name: SetReplaySource
		-- upvalues: (ref) v_u_57, (copy) v_u_175, (copy) v_u_202, (copy) v_u_15, (ref) v_u_4
		v_u_57 = p239
		v_u_175()
		local v240 = v_u_202
		local v241
		if p239 then
			v241 = p239.model
		else
			v241 = v_u_15.Character
		end
		v240(v241)
		v_u_4.RefreshVisible()
	end
	p_u_8.Hotbar = v_u_4
	p_u_8.HotbarRoot = v_u_16
end
return v_u_4