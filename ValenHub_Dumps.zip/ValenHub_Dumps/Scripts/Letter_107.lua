local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("StarterGui")
local v_u_6 = game:GetService("TextChatService")
local v7 = require(v_u_4:WaitForChild("Shared"):WaitForChild("Letters"))
local v8 = {}
local v_u_9 = Color3.fromRGB(240, 228, 200)
local v_u_10 = Color3.fromRGB(222, 202, 162)
local v_u_11 = Color3.fromRGB(46, 34, 26)
local v_u_12 = Font.fromEnum(Enum.Font.PatrickHand)
local v_u_13 = v7.Current()
local v_u_14 = {
	["heading"] = v_u_13.heading,
	["body"] = v_u_13.body,
	["signature"] = v_u_13.signature
}
local v_u_15 = v_u_13.author
local v_u_16 = Color3.fromRGB(226, 208, 170)
local v_u_17 = Color3.fromRGB(216, 196, 154)
local v_u_18 = v_u_16:Lerp(v_u_11, 0.3)
local v_u_19 = Color3.fromRGB(66, 50, 38)
local v_u_20 = Color3.fromRGB(80, 62, 47)
local v_u_21 = Color3.fromRGB(212, 158, 70)
local v_u_22 = Color3.fromRGB(246, 234, 208)
local v_u_23 = nil
function v8.Init(p_u_24) -- name: Init
	-- upvalues: (copy) v_u_10, (copy) v_u_9, (copy) v_u_12, (copy) v_u_11, (copy) v_u_14, (copy) v_u_3, (copy) v_u_15, (copy) v_u_13, (copy) v_u_16, (copy) v_u_18, (copy) v_u_4, (ref) v_u_20, (ref) v_u_19, (copy) v_u_17, (ref) v_u_21, (ref) v_u_22, (copy) v_u_2, (copy) v_u_1, (ref) v_u_23, (copy) v_u_6, (copy) v_u_5
	local v_u_25 = p_u_24.UI
	local v26 = p_u_24.Theme.Colors
	local v_u_27 = v_u_25.new("Frame", {
		["Name"] = "Letter",
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = p_u_24.Canvas.Menus
	})
	v_u_25.new("TextButton", {
		["Name"] = "Outside",
		["Size"] = nil,
		["BackgroundTransparency"] = 1,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["Selectable"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_27
	}).Activated:Connect(function()
		-- upvalues: (copy) p_u_24
		p_u_24.MenuManager.Close("Letter")
	end)
	local v_u_28 = v_u_25.new("Frame", {
		["Name"] = "Sheet",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = -0.8,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.52),
		["Size"] = UDim2.fromOffset(640, 420),
		["Parent"] = v_u_27
	})
	v_u_25.new("Frame", {
		["Name"] = "Shadow",
		["Position"] = UDim2.fromOffset(10, 14),
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundColor3"] = v26.Void,
		["BackgroundTransparency"] = 0.55,
		v_u_25.Corner(UDim.new(0, 10)),
		["Parent"] = v_u_28
	})
	local v29 = v_u_25.new("TextButton", {
		["Name"] = "Paper",
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Text"] = "",
		["AutoButtonColor"] = false,
		["Selectable"] = false,
		v_u_25.Corner(UDim.new(0, 10)),
		v_u_25.Stroke(v_u_10, 2, 0.1),
		["Parent"] = v_u_28
	})
	v_u_25.new("UIGradient", {
		["Color"] = nil,
		["Rotation"] = 70,
		["Parent"] = nil,
		["Color"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_9), ColorSequenceKeypoint.new(0.7, v_u_9:Lerp(v_u_10, 0.25)), ColorSequenceKeypoint.new(1, v_u_10) }),
		["Parent"] = v29
	})
	v29.Activated:Connect(function() end)
	local v_u_30 = v_u_25.new("Frame", {
		["Name"] = "Body",
		["Size"] = UDim2.fromScale(1, 1),
		v_u_25.Padding(40, 46, 30, 46),
		["Parent"] = v29
	})
	v_u_25.new("UIListLayout", {
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Padding"] = UDim.new(0, 18),
		["Parent"] = v_u_30
	})
	local function v35(p31, p32, p33, p34) -- name: line
		-- upvalues: (copy) v_u_25, (ref) v_u_12, (ref) v_u_11, (copy) v_u_30
		return v_u_25.new("TextLabel", {
			["Name"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["TextWrapped"] = true,
			["TextXAlignment"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Name"] = p31,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["Text"] = p32,
			["FontFace"] = v_u_12,
			["TextSize"] = p33,
			["TextColor3"] = v_u_11,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["LayoutOrder"] = p34,
			["Parent"] = v_u_30
		})
	end
	v35("Heading", v_u_14.heading, 52, 1)
	for v36, v37 in v_u_14.body do
		v35("Para" .. v36, v37, 34, 1 + v36)
	end
	local v38 = v_u_25.new("Frame", {
		["Name"] = "Signature",
		["Size"] = nil,
		["LayoutOrder"] = 10,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 72),
		["Parent"] = v_u_30
	})
	local v39 = v_u_25.new("Frame", {
		["Name"] = "Sign",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.fromScale(1, 0.5),
		["Size"] = UDim2.fromOffset(0, 72),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v38
	})
	v_u_25.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["HorizontalAlignment"] = Enum.HorizontalAlignment.Right,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["Padding"] = UDim.new(0, 14),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v39
	})
	v_u_25.new("TextLabel", {
		["Name"] = "Name",
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 46,
		["TextColor3"] = nil,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(0, 60),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Text"] = v_u_14.signature,
		["FontFace"] = v_u_12,
		["TextColor3"] = v_u_11,
		["Parent"] = v39
	})
	local v_u_40 = v_u_25.new("ImageLabel", {
		["Name"] = "Headshot",
		["Size"] = UDim2.fromOffset(68, 68),
		["BackgroundColor3"] = v_u_10,
		["Image"] = "",
		["LayoutOrder"] = 2,
		v_u_25.Corner(UDim.new(1, 0)),
		v_u_25.Stroke(v_u_11, 2, 0.35),
		["Parent"] = v39
	})
	task.spawn(function()
		-- upvalues: (ref) v_u_3, (ref) v_u_15, (copy) v_u_40
		local function v41()
			-- upvalues: (ref) v_u_3, (ref) v_u_15
			return v_u_3:GetUserThumbnailAsync(v_u_15, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size150x150)
		end
		local v42, v43 = pcall(v41)
		if v42 and type(v43) == "string" then
			v_u_40.Image = v43
		end
	end)
	local v_u_44 = p_u_24.Remotes
	local v_u_45 = p_u_24.State
	local v_u_46 = v_u_13.id
	local v_u_47 = v_u_13.reactions ~= false
	local v_u_48 = v_u_25.new("TextButton", {
		["Name"] = "Reaction",
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, -8, 0.5, 0),
		["Size"] = UDim2.fromOffset(0, 72),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["BackgroundTransparency"] = 1,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["Visible"] = v_u_47,
		v_u_25.Padding(0, 8, 0, 8),
		["Parent"] = v38
	})
	v_u_25.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["Parent"] = v_u_48
	})
	local v_u_49 = v_u_25.new("Frame", {
		["Name"] = "Pill",
		["Size"] = UDim2.fromOffset(0, 54),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["BackgroundColor3"] = v_u_16,
		v_u_25.Corner(UDim.new(1, 0)),
		["Parent"] = v_u_48
	})
	local v_u_50 = v_u_25.Stroke(v_u_18, 1.5, 0)
	v_u_50.Parent = v_u_49
	local v_u_51 = v_u_25.Padding(0, 18, 0, 14)
	v_u_51.Parent = v_u_49
	v_u_25.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_49
	})
	local v_u_52 = v_u_25.GetScaleObj(v_u_49, "HoverScale")
	local v_u_53 = v_u_25.new("TextLabel", {
		["Name"] = "Icon",
		["Size"] = nil,
		["Text"] = "\240\159\145\141",
		["TextSize"] = 34,
		["TextColor3"] = nil,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(38, 38),
		["TextColor3"] = v_u_11,
		["Parent"] = v_u_49
	})
	local v_u_54 = v_u_25.GetScaleObj(v_u_53, "PopScale")
	local v_u_55 = v_u_25.new("TextLabel", {
		["Name"] = "Count",
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 27,
		["TextColor3"] = nil,
		["LayoutOrder"] = 2,
		["Visible"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(0, 34),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["FontFace"] = p_u_24.Theme.Fonts.Bold,
		["TextColor3"] = v_u_11,
		["Parent"] = v_u_49
	})
	local v_u_56 = nil
	local v_u_57 = false
	local v_u_58 = false
	local v_u_59 = (-1 / 0)
	local v_u_60 = false
	local v_u_61 = false
	local v_u_62 = nil
	local v_u_63 = {}
	local v_u_64 = nil
	local function v_u_67() -- name: valueObj
		-- upvalues: (ref) v_u_62, (ref) v_u_4, (copy) v_u_46, (ref) v_u_63, (ref) v_u_64
		if v_u_62 and v_u_62.Parent then
			return v_u_62
		else
			local v65 = v_u_4:FindFirstChild("LetterReactions")
			if v65 then
				v65 = v65:FindFirstChild(v_u_46)
			end
			if v65 and (v65:IsA("IntValue") and v65 ~= v_u_62) then
				v_u_62 = v65
				for _, v66 in v_u_63 do
					v66:Disconnect()
				end
				v_u_63 = { v65.Changed:Connect(function()
						-- upvalues: (ref) v_u_64
						v_u_64()
					end), v65:GetAttributeChangedSignal("Ready"):Connect(function()
						-- upvalues: (ref) v_u_64
						v_u_64()
					end) }
			end
			if v_u_62 and v_u_62.Parent then
				return v_u_62
			else
				return nil
			end
		end
	end
	v_u_64 = function()
		-- upvalues: (copy) v_u_67, (ref) v_u_56, (ref) v_u_57, (copy) v_u_55, (copy) v_u_25, (copy) v_u_51, (copy) v_u_49, (ref) v_u_61, (ref) v_u_20, (ref) v_u_19, (ref) v_u_17, (ref) v_u_16, (copy) v_u_50, (ref) v_u_21, (ref) v_u_18, (ref) v_u_22, (ref) v_u_11
		local v68 = v_u_67()
		local v69 = not v68 and 0 or v68.Value
		local v70
		if v68 == nil then
			v70 = false
		else
			v70 = v68:GetAttribute("Ready") == true
		end
		if v_u_56 ~= nil and v_u_57 ~= v_u_56 then
			v69 = v69 + (v_u_57 and 1 or -1)
		end
		local v71 = math.max(0, v69)
		if v70 then
			v70 = v71 > 0
		end
		local v72 = v_u_55
		local v73
		if v71 >= 100000 then
			v73 = v_u_25.FormatCompact(v71)
		else
			v73 = v_u_25.FormatNumber(v71)
		end
		v72.Text = v73
		v_u_55.Visible = v70
		v_u_51.PaddingRight = UDim.new(0, v70 and 18 or 14)
		local v74 = v_u_57
		local v75 = v_u_49
		local v76
		if v74 then
			if v_u_61 then
				v76 = v_u_20
			else
				v76 = v_u_19
			end
		elseif v_u_61 then
			v76 = v_u_17
		else
			v76 = v_u_16
		end
		v75.BackgroundColor3 = v76
		local v77 = v_u_50
		local v78
		if v74 then
			v78 = v_u_21
		else
			v78 = v_u_18
		end
		v77.Color = v78
		v_u_50.Thickness = v74 and 2 or 1.5
		local v79 = v_u_55
		local v80
		if v74 then
			v80 = v_u_22
		else
			v80 = v_u_11
		end
		v79.TextColor3 = v80
	end
	local function v_u_86()
		-- upvalues: (ref) v_u_58, (copy) v_u_47, (ref) v_u_56, (ref) v_u_57, (ref) v_u_59, (ref) v_u_60, (ref) v_u_86, (copy) v_u_44, (copy) v_u_46, (ref) v_u_64
		if v_u_58 or (not v_u_47 or (v_u_56 == nil or v_u_57 == v_u_56)) then
			return
		else
			local v81 = v_u_59 + 0.25 - os.clock()
			if v81 > 0 then
				if not v_u_60 then
					v_u_60 = true
					task.delay(v81, function()
						-- upvalues: (ref) v_u_60, (ref) v_u_86
						v_u_60 = false
						v_u_86()
					end)
				end
			else
				v_u_58 = true
				v_u_59 = os.clock()
				local v_u_82 = v_u_57
				task.spawn(function()
					-- upvalues: (ref) v_u_44, (ref) v_u_46, (copy) v_u_82, (ref) v_u_58, (ref) v_u_56, (ref) v_u_57, (ref) v_u_64, (ref) v_u_86
					local v83, v84, v85 = v_u_44.Invoke("LetterAction", "React", v_u_46, v_u_82)
					v_u_58 = false
					if v83 and type(v85) == "boolean" then
						v_u_56 = v85
						if v84 ~= true and v_u_57 == v_u_82 then
							v_u_57 = v85
						end
					elseif v_u_57 == v_u_82 then
						v_u_57 = v_u_56
					end
					v_u_64()
					v_u_86()
				end)
			end
		end
	end
	local function v_u_88(p87) -- name: pop
		-- upvalues: (copy) v_u_54, (copy) v_u_25, (copy) p_u_24, (copy) v_u_55
		if p87 then
			v_u_54.Scale = 1
			v_u_25.Tween(v_u_54, TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Scale"] = 1.45
			})
			task.delay(0.08, function()
				-- upvalues: (ref) v_u_25, (ref) v_u_54
				v_u_25.Tween(v_u_54, TweenInfo.new(0.34, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
					["Scale"] = 1
				})
			end)
		else
			v_u_54.Scale = 0.8
			v_u_25.Tween(v_u_54, p_u_24.Theme.Tween.PopSmall, {
				["Scale"] = 1
			})
		end
		if v_u_55.Visible then
			v_u_25.Bump(v_u_55, 0.16)
		end
	end
	local function v91() -- name: tap
		-- upvalues: (copy) v_u_47, (ref) v_u_56, (copy) v_u_45, (copy) v_u_46, (ref) v_u_57, (copy) p_u_24, (ref) v_u_64, (copy) v_u_88, (ref) v_u_86
		if v_u_47 then
			if v_u_56 == nil then
				local v89 = v_u_45.Profile
				if v89 then
					v89 = v_u_45.Profile.reactions
				end
				local v90
				if type(v89) == "table" then
					v90 = v89[v_u_46] == true
				else
					v90 = false
				end
				v_u_56 = v90
				v_u_57 = v_u_56
			end
			v_u_57 = not v_u_57
			p_u_24.Sounds.Play("Click")
			v_u_64()
			v_u_88(v_u_57)
			v_u_86()
		end
	end
	v_u_48.Activated:Connect(v91)
	v_u_48.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_25, (ref) v_u_61, (copy) v_u_52, (copy) p_u_24, (ref) v_u_64
		if not v_u_25.Touch then
			v_u_61 = true
			v_u_25.Tween(v_u_52, p_u_24.Theme.Tween.PopSmall, {
				["Scale"] = 1.05
			})
			v_u_64()
		end
	end)
	v_u_48.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_61, (copy) v_u_25, (copy) v_u_52, (copy) p_u_24, (ref) v_u_64
		v_u_61 = false
		v_u_25.Tween(v_u_52, p_u_24.Theme.Tween.PopSmall, {
			["Scale"] = 1
		})
		v_u_64()
	end)
	v_u_48.MouseButton1Down:Connect(function()
		-- upvalues: (copy) v_u_25, (copy) v_u_52, (copy) p_u_24
		v_u_25.Tween(v_u_52, p_u_24.Theme.Tween.Instant, {
			["Scale"] = 0.93
		})
	end)
	v_u_48.MouseButton1Up:Connect(function()
		-- upvalues: (copy) v_u_25, (copy) v_u_52, (copy) p_u_24, (ref) v_u_61
		local v92 = {
			["Scale"] = v_u_61 and 1.05 or 1
		}
		v_u_25.Tween(v_u_52, p_u_24.Theme.Tween.PopSmall, v92)
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_4, (copy) v_u_46, (ref) v_u_64
		local v93 = v_u_4:WaitForChild("LetterReactions", 30)
		if v93 then
			v93:WaitForChild(v_u_46, 30)
		end
		v_u_64()
	end)
	v_u_45.ProfileChanged:Connect(function()
		-- upvalues: (ref) v_u_58, (ref) v_u_57, (ref) v_u_56, (copy) v_u_45, (copy) v_u_46, (ref) v_u_64
		if not v_u_58 and v_u_57 == v_u_56 then
			local v94 = v_u_45.Profile
			if v94 then
				v94 = v_u_45.Profile.reactions
			end
			local v95
			if type(v94) == "table" then
				v95 = v94[v_u_46] == true
			else
				v95 = false
			end
			v_u_56 = v95
			v_u_57 = v_u_56
			v_u_64()
		end
	end)
	if v_u_45.HasProfile then
		local v96 = v_u_45.Profile
		if v96 then
			v96 = v_u_45.Profile.reactions
		end
		v_u_56 = false
		if type(v96) == "table" then
			if v96[v_u_46] == true then
				v_u_56 = true
			else
				v_u_56 = false
			end
		end
	else
		v_u_56 = nil
	end
	if v_u_56 == true then
		v_u_57 = true
	else
		v_u_57 = false
	end
	v_u_64()
	function p_u_24.Debug.letter(p97, p98)
		-- upvalues: (copy) v_u_47, (ref) v_u_56, (copy) v_u_45, (copy) v_u_46, (ref) v_u_57, (copy) p_u_24, (ref) v_u_64, (copy) v_u_88, (ref) v_u_86, (ref) v_u_2, (ref) v_u_19, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22, (copy) v_u_67, (copy) v_u_48, (copy) v_u_27, (ref) v_u_58, (copy) v_u_55, (ref) v_u_53, (copy) v_u_49, (copy) v_u_25
		if p97 == "tap" then
			if v_u_47 then
				if v_u_56 == nil then
					local v99 = v_u_45.Profile
					if v99 then
						v99 = v_u_45.Profile.reactions
					end
					local v100
					if type(v99) == "table" then
						v100 = v99[v_u_46] == true
					else
						v100 = false
					end
					v_u_56 = v100
					v_u_57 = v_u_56
				end
				v_u_57 = not v_u_57
				p_u_24.Sounds.Play("Click")
				v_u_64()
				v_u_88(v_u_57)
				v_u_86()
			end
		elseif p97 == "palette" and (v_u_2:IsStudio() and type(p98) == "table") then
			local v101 = p98.on
			local v102 = v_u_19
			if type(v101) == "table" then
				v102 = Color3.fromRGB(v101[1], v101[2], v101[3])
			end
			local v103 = p98.hover
			local v104 = v_u_20
			if type(v103) == "table" then
				v104 = Color3.fromRGB(v103[1], v103[2], v103[3])
			end
			v_u_19 = v102
			v_u_20 = v104
			local v105 = p98.edge
			local v106 = v_u_21
			if type(v105) == "table" then
				v106 = Color3.fromRGB(v105[1], v105[2], v105[3])
			end
			local v107 = p98.text
			local v108 = v_u_22
			if type(v107) == "table" then
				v108 = Color3.fromRGB(v107[1], v107[2], v107[3])
			end
			v_u_21 = v106
			v_u_22 = v108
			v_u_64()
		end
		local v109 = v_u_67()
		local v110 = {
			["id"] = v_u_46
		}
		local v111
		if v_u_48.Parent == nil then
			v111 = false
		else
			v111 = v_u_48.Visible
		end
		v110.chip = v111
		v110.visible = v_u_27.Visible
		v110.reacted = v_u_57
		v110.confirmed = v_u_56 == nil and "unknown" or v_u_56
		v110.inflight = v_u_58
		v110.text = v_u_55.Text
		v110.countVisible = v_u_55.Visible
		local v112
		if v109 then
			v112 = v109.Value
		else
			v112 = false
		end
		v110.value = v112
		local v113
		if v109 == nil then
			v113 = false
		else
			v113 = v109:GetAttribute("Ready") == true
		end
		v110.ready = v113
		local v114
		if v_u_53:IsA("TextLabel") then
			v114 = v_u_53.Text
		else
			v114 = v_u_53.Image
		end
		v110.icon = v114
		v110.hit = { v_u_48.AbsoluteSize.X, v_u_48.AbsoluteSize.Y }
		v110.pill = { v_u_49.AbsoluteSize.X, v_u_49.AbsoluteSize.Y }
		v110.scale = v_u_25.Scale
		v110.centre = { v_u_48.AbsolutePosition.X + v_u_48.AbsoluteSize.X / 2, v_u_48.AbsolutePosition.Y + v_u_48.AbsoluteSize.Y / 2 }
		return v110
	end
	v_u_25.IconButton({
		["Name"] = "Close",
		["IconName"] = "cross",
		["IconScale"] = 0.4,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Color"] = nil,
		["Transparency"] = 0.15,
		["Sound"] = "Close",
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -14, 0, 14),
		["Size"] = UDim2.fromOffset(52, 52),
		["Color"] = Color3.fromRGB(58, 44, 34),
		["Parent"] = v29
	}).Activated:Connect(function()
		-- upvalues: (copy) p_u_24
		p_u_24.MenuManager.Close("Letter")
	end)
	local v_u_115 = 420
	local v_u_116 = v_u_25.new("UIScale", {
		["Parent"] = v_u_28
	})
	local v_u_117 = v_u_30:FindFirstChildOfClass("UIListLayout")
	local function v_u_125() -- name: barButtonsRight
		-- upvalues: (copy) v_u_25, (ref) v_u_1, (copy) p_u_24, (copy) v_u_27
		local v118 = v_u_25.Scale
		local v119 = math.max(v118, 0.01)
		if v_u_25.DebugDevice then
			return (v_u_25.TopInset() - 4) * 4.5
		end
		local function v120()
			-- upvalues: (ref) v_u_1
			return v_u_1.TopbarInset
		end
		local v121, v122 = pcall(v120)
		local v123 = p_u_24.TopbarSettings
		if v123 then
			v123 = p_u_24.TopbarSettings.Button
		end
		if v123 then
			v123 = v123:FindFirstAncestorOfClass("ScreenGui")
		end
		local v124 = not v123 and 0 or v123.AbsolutePosition.X - v_u_27.AbsolutePosition.X
		return (not v121 or (not v122 or v122.Width <= 0)) and 0 or (v124 + v122.Min.X) / v119 + 8
	end
	local function v_u_149() -- name: layout
		-- upvalues: (copy) v_u_25, (copy) v_u_116, (copy) v_u_117, (ref) v_u_115, (copy) v_u_28, (copy) v_u_125, (copy) v_u_48
		local v126 = v_u_25.CanvasSize()
		local v127 = v_u_25.Scale * v_u_116.Scale
		local v128 = math.max(v127, 0.01)
		local v129 = not v_u_117 and 0 or v_u_117.AbsoluteContentSize.Y / v128
		if v129 > 50 then
			local v130 = v129 + 78
			v_u_115 = math.ceil(v130)
		end
		v_u_28.Size = UDim2.fromOffset(640, v_u_115)
		local v131 = (v126.Y - 24) / v_u_115
		local v132 = (v126.X - 32) / 640
		local v133 = math.min(1, v131, v132)
		local v134 = (v126.X - v133 * 640) / 2 > v_u_125() and 12 or v_u_25.TopInset()
		local v135 = (v126.Y - v134 - 12) / v_u_115
		local v136 = math.min(v133, v135)
		v_u_116.Scale = v136
		local v137 = v_u_115 * v136
		local v138 = v126.Y / 2
		local v139 = v134 + v137 / 2
		local v140 = math.max(v138, v139)
		v_u_28.Position = UDim2.fromOffset(v126.X / 2, v140)
		local v141 = v_u_25.Scale * v136
		local v142 = math.max(v141, 0.01)
		local v143 = v_u_48
		local v144 = UDim2.fromOffset
		local v145 = 0
		local v146
		if v_u_25.Touch then
			local v147 = 46 / v142
			local v148 = math.ceil(v147)
			v146 = math.max(72, v148)
		else
			v146 = 72
		end
		v143.Size = v144(v145, v146)
	end
	v_u_149()
	v_u_25.LayoutChanged:Connect(v_u_149)
	v_u_25.ScaleChanged:Connect(v_u_149)
	v_u_25.TouchChanged:Connect(v_u_149)
	if v_u_117 then
		local v_u_150 = false
		local v_u_151 = v_u_117.AbsoluteContentSize
		local v_u_152 = 0
		local v_u_153 = 0
		v_u_117:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
			-- upvalues: (ref) v_u_150, (copy) v_u_117, (ref) v_u_151, (ref) v_u_153, (ref) v_u_152, (copy) v_u_149
			if v_u_150 or (v_u_117.AbsoluteContentSize - v_u_151).Magnitude < 0.5 then
				return
			else
				local v154 = os.clock()
				if v154 - v_u_153 > 0.5 then
					v_u_152 = 0
				end
				if v_u_152 < 6 then
					v_u_152 = v_u_152 + 1
					v_u_153 = v154
					v_u_150 = true
					task.delay(0, function()
						-- upvalues: (ref) v_u_150, (ref) v_u_151, (ref) v_u_117, (ref) v_u_149
						v_u_150 = false
						v_u_151 = v_u_117.AbsoluteContentSize
						v_u_149()
					end)
				end
			end
		end)
	end
	local v_u_155 = 0
	local v175 = {
		["open"] = function() -- name: open
			-- upvalues: (ref) v_u_155, (copy) p_u_24, (ref) v_u_23, (ref) v_u_6, (ref) v_u_5, (copy) v_u_149, (copy) v_u_27, (copy) v_u_28, (copy) v_u_25, (copy) v_u_47, (copy) v_u_44, (copy) v_u_46, (ref) v_u_58, (ref) v_u_56, (ref) v_u_57, (ref) v_u_64
			v_u_155 = v_u_155 + 1
			p_u_24.SetHudHidden("Letter", true)
			if p_u_24.TopbarSettings and p_u_24.TopbarSettings.SetHidden then
				p_u_24.TopbarSettings.SetHidden("Letter", true)
			end
			if not v_u_23 then
				local v_u_156 = {}
				local function v159()
					-- upvalues: (ref) v_u_6, (copy) v_u_156, (ref) v_u_5
					local v157 = v_u_6:FindFirstChildOfClass("ChatWindowConfiguration")
					local v158 = v_u_6:FindFirstChildOfClass("ChatInputBarConfiguration")
					if v157 then
						v_u_156.window = v157.Enabled
						v157.Enabled = false
					end
					if v158 then
						v_u_156.bar = v158.Enabled
						v158.Enabled = false
					end
					v_u_156.core = v_u_5:GetCoreGuiEnabled(Enum.CoreGuiType.Chat)
					v_u_5:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, false)
				end
				pcall(v159)
				v_u_23 = v_u_156
			end
			v_u_149()
			v_u_27.Visible = true
			v_u_28.Rotation = -4
			local v160 = v_u_28.Position
			v_u_28.Position = v160 + UDim2.fromOffset(0, 40)
			v_u_25.Tween(v_u_28, TweenInfo.new(0.42, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				["Position"] = nil,
				["Rotation"] = -0.8,
				["Position"] = v160
			})
			v_u_25.FadeIn(v_u_28, TweenInfo.new(0.2))
			p_u_24.Sounds.Play("Open")
			if v_u_47 then
				local v_u_161 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_44, (ref) v_u_46, (copy) v_u_161, (ref) v_u_58, (ref) v_u_56, (ref) v_u_57, (ref) v_u_64
					local v162, v163, _, v164 = v_u_44.Invoke("LetterAction", "Watch", v_u_46, v_u_161)
					if v_u_161 and (v162 and (v163 == true and (type(v164) == "boolean" and (not v_u_58 and (v_u_56 == nil or v_u_57 == v_u_56))))) then
						v_u_56 = v164
						v_u_57 = v164
					end
					v_u_64()
				end)
			end
		end,
		["close"] = function(p165) -- name: close
			-- upvalues: (ref) v_u_155, (copy) p_u_24, (ref) v_u_23, (ref) v_u_6, (ref) v_u_5, (copy) v_u_47, (copy) v_u_44, (copy) v_u_46, (ref) v_u_58, (ref) v_u_56, (ref) v_u_57, (ref) v_u_64, (copy) v_u_27, (copy) v_u_25, (copy) v_u_28
			v_u_155 = v_u_155 + 1
			local v_u_166 = v_u_155
			p_u_24.SetHudHidden("Letter", false)
			if p_u_24.TopbarSettings and p_u_24.TopbarSettings.SetHidden then
				p_u_24.TopbarSettings.SetHidden("Letter", false)
			end
			local v_u_167 = v_u_23
			if v_u_167 then
				v_u_23 = nil
				local function v170()
					-- upvalues: (ref) v_u_6, (copy) v_u_167, (ref) v_u_5
					local v168 = v_u_6:FindFirstChildOfClass("ChatWindowConfiguration")
					local v169 = v_u_6:FindFirstChildOfClass("ChatInputBarConfiguration")
					if v168 and v_u_167.window ~= nil then
						v168.Enabled = v_u_167.window
					end
					if v169 and v_u_167.bar ~= nil then
						v169.Enabled = v_u_167.bar
					end
					if v_u_167.core ~= nil then
						v_u_5:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, v_u_167.core)
					end
				end
				pcall(v170)
			end
			if v_u_47 then
				local v_u_171 = false
				task.spawn(function()
					-- upvalues: (ref) v_u_44, (ref) v_u_46, (copy) v_u_171, (ref) v_u_58, (ref) v_u_56, (ref) v_u_57, (ref) v_u_64
					local v172, v173, _, v174 = v_u_44.Invoke("LetterAction", "Watch", v_u_46, v_u_171)
					if v_u_171 and (v172 and (v173 == true and (type(v174) == "boolean" and (not v_u_58 and (v_u_56 == nil or v_u_57 == v_u_56))))) then
						v_u_56 = v174
						v_u_57 = v174
					end
					v_u_64()
				end)
			end
			if p165 then
				v_u_27.Visible = false
			else
				v_u_25.FadeOut(v_u_28, TweenInfo.new(0.16))
				task.delay(0.17, function()
					-- upvalues: (copy) v_u_166, (ref) v_u_155, (ref) v_u_27
					if v_u_166 == v_u_155 then
						v_u_27.Visible = false
					end
				end)
			end
		end
	}
	p_u_24.MenuManager.Register("Letter", v175)
end
return v8