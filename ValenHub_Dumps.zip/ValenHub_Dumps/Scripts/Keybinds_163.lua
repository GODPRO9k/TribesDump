local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v3 = require(script.Parent:WaitForChild("Signal"))
local v_u_4 = {
	["PREFIX"] = "kb_",
	["PAD_PREFIX"] = "gp_",
	["MAX"] = 2
}
v_u_4.ACTIONS = {
	{
		["id"] = "Jump",
		["label"] = "JUMP",
		["keys"] = nil,
		["max"] = nil,
		["group"] = "move",
		["keys"] = { "Space" },
		["max"] = v_u_4.MAX
	},
	{
		["id"] = "Slide",
		["label"] = "SLIDE",
		["keys"] = nil,
		["max"] = nil,
		["group"] = "move",
		["keys"] = { "C", "LeftControl" },
		["max"] = v_u_4.MAX
	},
	{
		["id"] = "Attack",
		["label"] = "ATTACK",
		["keys"] = nil,
		["max"] = nil,
		["group"] = "combat",
		["keys"] = { "MouseButton1" },
		["max"] = v_u_4.MAX
	},
	{
		["id"] = "Aim",
		["label"] = "AIM / BLOCK",
		["keys"] = nil,
		["max"] = nil,
		["group"] = "combat",
		["keys"] = { "MouseButton2" },
		["max"] = v_u_4.MAX
	},
	{
		["id"] = "Reload",
		["label"] = "RELOAD",
		["keys"] = nil,
		["max"] = nil,
		["group"] = "combat",
		["keys"] = { "R" },
		["max"] = v_u_4.MAX
	},
	{
		["id"] = "Ping",
		["label"] = "PING",
		["keys"] = nil,
		["max"] = nil,
		["group"] = "combat",
		["keys"] = { "MouseButton3", "G" },
		["max"] = v_u_4.MAX
	},
	{
		["id"] = "Item1",
		["label"] = "ITEM 1",
		["keys"] = nil,
		["max"] = 1,
		["group"] = "items",
		["keys"] = { "One" }
	},
	{
		["id"] = "Item2",
		["label"] = "ITEM 2",
		["keys"] = nil,
		["max"] = 1,
		["group"] = "items",
		["keys"] = { "Two" }
	},
	{
		["id"] = "Item3",
		["label"] = "ITEM 3",
		["keys"] = nil,
		["max"] = 1,
		["group"] = "items",
		["keys"] = { "Three" }
	},
	{
		["id"] = "Item4",
		["label"] = "ITEM 4",
		["keys"] = nil,
		["max"] = 1,
		["group"] = "items",
		["keys"] = { "Four" }
	},
	{
		["id"] = "Item5",
		["label"] = "ITEM 5",
		["keys"] = nil,
		["max"] = 1,
		["group"] = "items",
		["keys"] = { "Five" }
	},
	{
		["id"] = "Item6",
		["label"] = "ITEM 6",
		["keys"] = nil,
		["max"] = 1,
		["group"] = "items",
		["keys"] = { "Six" }
	},
	{
		["id"] = "LastItem",
		["label"] = "LAST ITEM",
		["keys"] = nil,
		["max"] = nil,
		["group"] = "items",
		["keys"] = { "Q" },
		["max"] = v_u_4.MAX
	},
	{
		["id"] = "NextLoadout",
		["label"] = "NEXT LOADOUT",
		["keys"] = nil,
		["max"] = nil,
		["group"] = "items",
		["keys"] = { "B" },
		["max"] = v_u_4.MAX
	},
	{
		["id"] = "View",
		["label"] = "FIRST / THIRD PERSON",
		["keys"] = nil,
		["max"] = nil,
		["group"] = "camera",
		["keys"] = { "V" },
		["max"] = v_u_4.MAX
	},
	{
		["id"] = "Shoulder",
		["label"] = "SWITCH SHOULDER",
		["keys"] = nil,
		["max"] = nil,
		["group"] = "camera",
		["keys"] = { "X" },
		["max"] = v_u_4.MAX
	},
	{
		["id"] = "FreeCursor",
		["label"] = "FREE CURSOR",
		["keys"] = nil,
		["max"] = nil,
		["group"] = "camera",
		["keys"] = { "LeftAlt", "RightAlt" },
		["max"] = v_u_4.MAX
	},
	{
		["id"] = "CustomMenu",
		["label"] = "CUSTOM MATCH MENU",
		["keys"] = nil,
		["max"] = nil,
		["group"] = "menus",
		["keys"] = { "H" },
		["max"] = v_u_4.MAX
	},
	{
		["id"] = "Scoreboard",
		["label"] = "SCOREBOARD (HOLD)",
		["keys"] = nil,
		["max"] = nil,
		["group"] = "menus",
		["keys"] = { "Tab" },
		["max"] = v_u_4.MAX
	}
}
local v_u_5 = {}
for _, v6 in v_u_4.ACTIONS do
	v_u_5[v6.id] = v6
end
function v_u_4.Action(p7) -- name: Action
	-- upvalues: (copy) v_u_5
	return v_u_5[p7]
end
local v_u_8 = {
	["Escape"] = "Esc opens the Roblox menu",
	["Slash"] = "/ opens chat",
	["W"] = "W A S D move you",
	["A"] = "W A S D move you",
	["S"] = "W A S D move you",
	["D"] = "W A S D move you",
	["Up"] = "The arrow keys move you",
	["Down"] = "The arrow keys move you",
	["Left"] = "The arrow keys turn the camera",
	["Right"] = "The arrow keys turn the camera",
	["M"] = "M opens Settings",
	["E"] = "E interacts with things",
	["F9"] = "F9 opens Roblox\'s console",
	["F10"] = "Reserved by Roblox",
	["F11"] = "Reserved by Roblox",
	["F12"] = "Reserved by Roblox",
	["LeftSuper"] = "Reserved by your system",
	["RightSuper"] = "Reserved by your system",
	["Print"] = "Reserved by your system",
	["Menu"] = "Reserved by your system"
}
v_u_4.RESERVED = v_u_8
local v_u_9 = {}
local v_u_10 = {
	["MouseButton1"] = true,
	["MouseButton2"] = true,
	["MouseButton3"] = true
}
for _, v11 in string.split("B C F G H I J K L N O P Q R T U V X Y Z", " ") do
	v_u_9[v11] = v11
end
for v12, v13 in {
	"Zero",
	"One",
	"Two",
	"Three",
	"Four",
	"Five",
	"Six",
	"Seven",
	"Eight",
	"Nine"
} do
	local v14 = v12 - 1
	v_u_9[v13] = tostring(v14)
	local v15 = "Keypad" .. v13
	local v16 = v12 - 1
	v_u_9[v15] = "NUM " .. tostring(v16)
end
v_u_9["F" .. 1] = "F" .. 1
v_u_9["F" .. 2] = "F" .. 2
v_u_9["F" .. 3] = "F" .. 3
v_u_9["F" .. 4] = "F" .. 4
v_u_9["F" .. 5] = "F" .. 5
v_u_9["F" .. 6] = "F" .. 6
v_u_9["F" .. 7] = "F" .. 7
v_u_9["F" .. 8] = "F" .. 8
for v17, v18 in {
	["Space"] = "SPACE",
	["Tab"] = "TAB",
	["CapsLock"] = "CAPS",
	["Return"] = "ENTER",
	["Backspace"] = "BKSP",
	["LeftShift"] = "SHIFT",
	["RightShift"] = "R SHIFT",
	["LeftControl"] = "CTRL",
	["RightControl"] = "R CTRL",
	["LeftAlt"] = "ALT",
	["RightAlt"] = "R ALT",
	["Insert"] = "INS",
	["Delete"] = "DEL",
	["Home"] = "HOME",
	["End"] = "END",
	["PageUp"] = "PG UP",
	["PageDown"] = "PG DN",
	["Backquote"] = "`",
	["Minus"] = "-",
	["Equals"] = "=",
	["LeftBracket"] = "[",
	["RightBracket"] = "]",
	["BackSlash"] = "\\",
	["Semicolon"] = ";",
	["Quote"] = "\'",
	["Comma"] = ",",
	["Period"] = ".",
	["KeypadPeriod"] = "NUM .",
	["KeypadDivide"] = "NUM /",
	["KeypadMultiply"] = "NUM *",
	["KeypadMinus"] = "NUM -",
	["KeypadPlus"] = "NUM +",
	["KeypadEnter"] = "NUM ENTER",
	["MouseButton1"] = "LEFT CLICK",
	["MouseButton2"] = "RIGHT CLICK",
	["MouseButton3"] = "MIDDLE CLICK"
} do
	v_u_9[v17] = v18
end
function v_u_4.Bindable(p19) -- name: Bindable
	-- upvalues: (copy) v_u_9, (copy) v_u_8
	if v_u_9[p19] then
		return true, nil
	else
		return false, v_u_8[p19] or "That key can\'t be used"
	end
end
function v_u_4.Display(p20) -- name: Display
	-- upvalues: (copy) v_u_9
	return not p20 and "\226\128\148" or (v_u_9[p20] or p20)
end
function v_u_4.CapFor(p21) -- name: CapFor
	-- upvalues: (copy) v_u_9
	if p21 then
		return p21 == "MouseButton1" and "M1" or (p21 == "MouseButton2" and "M2" or (p21 == "MouseButton3" and "M3" or (v_u_9[p21] or p21)))
	else
		return nil
	end
end
function v_u_4.Parse(p22, p23) -- name: Parse
	-- upvalues: (copy) v_u_5, (copy) v_u_9
	local v24 = v_u_5[p22]
	if not v24 or (type(p23) ~= "string" or #p23 > 64) then
		return nil
	end
	if p23 == "-" then
		return {}
	end
	if p23 == "" then
		return nil
	end
	local v25 = string.split(p23, ",")
	if #v25 > v24.max then
		return nil
	end
	local v26 = {}
	for _, v27 in v25 do
		if #v27 == 0 or (#v27 > 16 or (not v_u_9[v27] or v26[v27])) then
			return nil
		end
		v26[v27] = true
	end
	return v25
end
function v_u_4.Encode(p28) -- name: Encode
	return #p28 == 0 and "-" or table.concat(p28, ",")
end
function v_u_4.ValidSetting(p29, p30) -- name: ValidSetting
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	if type(p29) == "string" then
		local v31 = #v_u_4.PAD_PREFIX
		if string.sub(p29, 1, v31) == v_u_4.PAD_PREFIX then
			local v32 = #v_u_4.PAD_PREFIX + 1
			local v33 = string.sub(p29, v32)
			if v_u_4.PadAction(v33) then
				return p30 == "" and true or v_u_4.PadParse(v33, p30) ~= nil
			else
				return false
			end
		else
			local v34 = #v_u_4.PREFIX
			if string.sub(p29, 1, v34) == v_u_4.PREFIX then
				local v35 = #v_u_4.PREFIX + 1
				local v36 = string.sub(p29, v35)
				if v_u_5[v36] then
					return p30 == "" and true or v_u_4.Parse(v36, p30) ~= nil
				else
					return false
				end
			else
				return false
			end
		end
	else
		return false
	end
end
function v_u_4.IsKey(p37) -- name: IsKey
	-- upvalues: (copy) v_u_4
	local v38
	if type(p37) == "string" then
		local v39 = #v_u_4.PREFIX
		if string.sub(p37, 1, v39) == v_u_4.PREFIX then
			v38 = true
		else
			local v40 = #v_u_4.PAD_PREFIX
			v38 = string.sub(p37, 1, v40) == v_u_4.PAD_PREFIX
		end
	else
		v38 = false
	end
	return v38
end
local v_u_41 = {}
local v_u_42 = {}
v_u_4.Changed = v3.new()
local function v_u_45() -- name: reindex
	-- upvalues: (copy) v_u_42, (copy) v_u_4, (copy) v_u_41
	table.clear(v_u_42)
	for _, v43 in v_u_4.ACTIONS do
		for _, v44 in v_u_41[v43.id] do
			v_u_42[v44] = v43.id
		end
	end
end
local function v_u_47() -- name: resetAll
	-- upvalues: (copy) v_u_4, (copy) v_u_41, (copy) v_u_45
	for _, v46 in v_u_4.ACTIONS do
		v_u_41[v46.id] = table.clone(v46.keys)
	end
	v_u_45()
end
v_u_47()
function v_u_4.Get(p48) -- name: Get
	-- upvalues: (copy) v_u_41
	return table.clone(v_u_41[p48] or {})
end
function v_u_4.IsDefault(p49) -- name: IsDefault
	-- upvalues: (copy) v_u_5, (copy) v_u_41
	local v50 = v_u_5[p49]
	local v51
	if v50 == nil then
		v51 = false
	else
		local v52 = v_u_41[p49]
		local v53 = v50.keys
		if #v52 ~= #v53 then
			return false
		end
		for v54, v55 in v52 do
			if v53[v54] == v55 then
				continue
			end
			return false
		end
		v51 = true
	end
	return v51
end
function v_u_4.AllDefault() -- name: AllDefault
	-- upvalues: (copy) v_u_4, (copy) v_u_41
	for _, v56 in v_u_4.ACTIONS do
		local v57 = v_u_41[v56.id]
		local v58 = v56.keys
		local v59
		if #v57 == #v58 then
			for v60, v61 in v57 do
				if v58[v60] == v61 then
					continue
				end
				v59 = false
			end
			v59 = true
		else
			v59 = false
		end
		if v59 then
			continue
		end
		return false
	end
	return true
end
function v_u_4.OwnerOf(p62) -- name: OwnerOf
	-- upvalues: (copy) v_u_42
	return v_u_42[p62]
end
function v_u_4.SettingValue(p63) -- name: SettingValue
	-- upvalues: (copy) v_u_5, (copy) v_u_41, (copy) v_u_4
	local v64 = v_u_5[p63]
	if v64 then
		local v65 = v_u_41[p63]
		local v66 = v64.keys
		local v67
		if #v65 == #v66 then
			for v68, v69 in v65 do
				if v66[v68] == v69 then
					continue
				end
				v67 = false
			end
			v67 = true
		else
			v67 = false
		end
		if not v67 then
			return v_u_4.Encode(v_u_41[p63])
		end
	end
	return ""
end
function v_u_4.Load(p70) -- name: Load
	-- upvalues: (copy) v_u_41, (copy) v_u_4, (copy) v_u_45
	local v71 = type(p70) ~= "table" and {} or p70
	local v72 = {}
	for v73, v74 in v_u_41 do
		v72[v73] = v74
	end
	local v75 = {}
	local v76 = {}
	for _, v77 in v_u_4.ACTIONS do
		local v78 = v_u_4.Parse(v77.id, v71[v_u_4.PREFIX .. v77.id])
		if not v78 then
			continue
		end
		local v79 = {}
		for _, v80 in v78 do
			if v75[v80] then
				continue
			end
			v75[v80] = true
			table.insert(v79, v80)
		end
		v_u_41[v77.id] = v79
		v76[v77.id] = true
	end
	for _, v81 in v_u_4.ACTIONS do
		if v76[v81.id] then
			continue
		end
		local v82 = {}
		for _, v83 in v81.keys do
			if v75[v83] then
				continue
			end
			v75[v83] = true
			table.insert(v82, v83)
		end
		v_u_41[v81.id] = v82
	end
	v_u_45()
	local v84 = {}
	for _, v85 in v_u_4.ACTIONS do
		local v86 = v72[v85.id] or {}
		local v87 = v_u_41[v85.id]
		local v88
		if #v86 == #v87 then
			for v89, v90 in v86 do
				if v87[v89] == v90 then
					continue
				end
				v88 = false
			end
			v88 = true
		else
			v88 = false
		end
		if v88 then
			continue
		end
		local v91 = v85.id
		table.insert(v84, v91)
	end
	if #v84 > 0 then
		v_u_4.Changed:Fire(v84)
	end
	v_u_4.PadLoad(v71)
end
function v_u_4.Assign(p92, p93, p94) -- name: Assign
	-- upvalues: (copy) v_u_5, (copy) v_u_9, (copy) v_u_41, (copy) v_u_42, (copy) v_u_45, (copy) v_u_4
	local v95 = v_u_5[p92]
	if not (v95 and v_u_9[p94]) then
		return {}, nil, nil
	end
	local v96 = v95.max
	local v97 = #v_u_41[p92] + 1
	local v98 = math.min(v96, v97)
	local v99 = math.clamp(p93, 1, v98)
	local v100 = v_u_41[p92]
	local v101 = v100[v99]
	if v101 == p94 then
		return {}, nil, nil
	end
	local v102 = { p92 }
	local v103 = v_u_42[p94]
	local v104 = nil
	if v103 == p92 then
		if v101 == nil then
			return {}, nil, nil
		end
		v100[table.find(v100, p94)] = v101
		v100[v99] = p94
	else
		if v103 then
			local v105 = v_u_41[v103]
			local v106 = table.find(v105, p94)
			if v101 and not table.find(v105, v101) then
				v105[v106] = v101
			else
				table.remove(v105, v106)
			end
			table.insert(v102, v103)
			v104 = table.clone(v105)
		end
		v100[v99] = p94
	end
	v_u_45()
	v_u_4.Changed:Fire(v102)
	if v103 == p92 or not v103 then
		v103 = nil
	end
	return v102, v103, v104
end
function v_u_4.Clear(p107, p108) -- name: Clear
	-- upvalues: (copy) v_u_41, (copy) v_u_45, (copy) v_u_4
	local v109 = v_u_41[p107]
	if v109 and v109[p108] then
		table.remove(v109, p108)
		v_u_45()
		v_u_4.Changed:Fire({ p107 })
	end
end
function v_u_4.ResetAll() -- name: ResetAll
	-- upvalues: (copy) v_u_4, (copy) v_u_41, (copy) v_u_47
	local v110 = {}
	for _, v111 in v_u_4.ACTIONS do
		local v112 = v_u_41[v111.id]
		local v113 = v111.keys
		local v114
		if #v112 == #v113 then
			for v115, v116 in v112 do
				if v113[v115] == v116 then
					continue
				end
				v114 = false
			end
			v114 = true
		else
			v114 = false
		end
		if v114 then
			continue
		end
		local v117 = v111.id
		table.insert(v110, v117)
	end
	v_u_47()
	if #v110 > 0 then
		v_u_4.Changed:Fire(v110)
	end
	return v110
end
function v_u_4.ActionOf(p118) -- name: ActionOf
	-- upvalues: (copy) v_u_42
	local v119 = p118.UserInputType
	if v119 == Enum.UserInputType.Keyboard then
		return v_u_42[p118.KeyCode.Name]
	elseif v119 == Enum.UserInputType.MouseButton1 or (v119 == Enum.UserInputType.MouseButton2 or v119 == Enum.UserInputType.MouseButton3) then
		return v_u_42[v119.Name]
	else
		return nil
	end
end
function v_u_4.Inputs(p120) -- name: Inputs
	-- upvalues: (copy) v_u_41, (copy) v_u_10
	local v121 = {}
	for _, v_u_122 in v_u_41[p120] or {} do
		if v_u_10[v_u_122] then
			local v123 = Enum.UserInputType[v_u_122]
			table.insert(v121, v123)
		else
			local v124, v125 = pcall(function()
				-- upvalues: (copy) v_u_122
				return Enum.KeyCode[v_u_122]
			end)
			if not (v124 and v125) then
				continue
			end
			table.insert(v121, v125)
		end
	end
	return v121
end
function v_u_4.CapText(p126) -- name: CapText
	-- upvalues: (copy) v_u_41, (copy) v_u_4
	local v127 = v_u_41[p126]
	local v128 = v_u_4.CapFor
	if v127 then
		v127 = v127[1]
	end
	return v128(v127)
end
function v_u_4.NameOf(p129) -- name: NameOf
	local v130 = p129.UserInputType
	if v130 == Enum.UserInputType.Keyboard then
		return p129.KeyCode.Name
	elseif v130 == Enum.UserInputType.MouseButton1 or (v130 == Enum.UserInputType.MouseButton2 or v130 == Enum.UserInputType.MouseButton3) then
		return v130.Name
	else
		return nil
	end
end
local function v140(p131, p132, p133, p134, p135, p136, p137) -- name: P
	local v138 = {}
	for _, v139 in string.split(p135, " ") do
		v138[v139] = true
	end
	return {
		["id"] = p131,
		["label"] = p132,
		["desc"] = p133,
		["buttons"] = p134,
		["max"] = p137 or 1,
		["contexts"] = v138,
		["group"] = p136
	}
end
v_u_4.PAD_ACTIONS = {
	v140("Jump", "JUMP", "In the lobby and in matches", { "ButtonA" }, "lobby training match", "move"),
	v140("Slide", "SLIDE", "While running", { "ButtonB" }, "lobby training match", "move"),
	v140("Attack", "ATTACK", "Swing, fire, throw, use", { "ButtonR2" }, "training match", "combat"),
	v140("Aim", "AIM / BLOCK", "Aim, zoom, block, heavy attack, lunge", { "ButtonL2" }, "training match", "combat"),
	v140("Reload", "RELOAD", "Reload your weapon", { "ButtonX" }, "training match", "combat"),
	v140("Ping", "PING", "Mark a spot for your team", { "ButtonL3" }, "match", "combat"),
	v140("NextItem", "NEXT ITEM", "The next hotbar slot", { "ButtonR1" }, "training match", "items"),
	v140("PrevItem", "PREVIOUS ITEM", "The previous hotbar slot", { "ButtonL1" }, "training match", "items"),
	v140("LastItem", "LAST ITEM", "Swap back to your last item", { "ButtonY" }, "training match", "items"),
	v140("NextLoadout", "NEXT LOADOUT", "During the round countdown", { "DPadRight" }, "match", "items"),
	v140("PrevLoadout", "PREVIOUS LOADOUT", "During the round countdown", { "DPadLeft" }, "match", "items"),
	v140("View", "FIRST / THIRD PERSON", "Switch the camera view", { "DPadUp" }, "training match", "camera"),
	v140("Shoulder", "SWITCH SHOULDER", "Look over the other shoulder", { "ButtonR3" }, "training match", "camera"),
	v140("Scoreboard", "SCOREBOARD (HOLD)", "In a match", { "DPadDown" }, "match spectate", "menus"),
	v140("SpectateNext", "SPECTATE NEXT", "While you\'re out of the round", { "ButtonR1", "ButtonA" }, "spectate", "spectate", 2),
	v140("SpectatePrev", "SPECTATE PREVIOUS", "While you\'re out of the round", { "ButtonL1", "ButtonB" }, "spectate", "spectate", 2),
	v140("Play", "PLAY / CANCEL", "Join or leave the queue in the lobby", { "ButtonY" }, "lobby", "menus"),
	(v140("CustomMenu", "CUSTOM MATCH MENU", "In a custom match server\'s lobby", { "DPadDown" }, "lobby", "menus"))
}
local v_u_141 = {}
for _, v142 in v_u_4.PAD_ACTIONS do
	v_u_141[v142.id] = v142
end
function v_u_4.PadAction(p143) -- name: PadAction
	-- upvalues: (copy) v_u_141
	return v_u_141[p143]
end
local v_u_144 = {
	["ButtonA"] = "A",
	["ButtonB"] = "B",
	["ButtonX"] = "X",
	["ButtonY"] = "Y",
	["ButtonL1"] = "LB",
	["ButtonR1"] = "RB",
	["ButtonL2"] = "LT",
	["ButtonR2"] = "RT",
	["ButtonL3"] = "LS",
	["ButtonR3"] = "RS",
	["DPadUp"] = "D-PAD UP",
	["DPadDown"] = "D-PAD DOWN",
	["DPadLeft"] = "D-PAD LEFT",
	["DPadRight"] = "D-PAD RIGHT"
}
v_u_4.PAD_ALLOWED = v_u_144
local v_u_145 = {
	["ButtonSelect"] = "That button opens Settings",
	["ButtonStart"] = "That button opens Roblox\'s menu"
}
v_u_4.PAD_RESERVED = v_u_145
function v_u_4.PadBindable(p146) -- name: PadBindable
	-- upvalues: (copy) v_u_144, (copy) v_u_145
	if v_u_144[p146] then
		return true, nil
	else
		return false, v_u_145[p146] or "That button can\'t be used"
	end
end
function v_u_4.PadDisplay(p147) -- name: PadDisplay
	-- upvalues: (copy) v_u_144
	return not p147 and "\226\128\148" or (v_u_144[p147] or p147)
end
function v_u_4.PadParse(p148, p149) -- name: PadParse
	-- upvalues: (copy) v_u_141, (copy) v_u_144
	local v150 = v_u_141[p148]
	if not v150 or (type(p149) ~= "string" or #p149 > 64) then
		return nil
	end
	if p149 == "-" then
		return {}
	end
	if p149 == "" then
		return nil
	end
	local v151 = string.split(p149, ",")
	if #v151 > v150.max then
		return nil
	end
	local v152 = {}
	for _, v153 in v151 do
		if #v153 == 0 or (#v153 > 16 or (not v_u_144[v153] or v152[v153])) then
			return nil
		end
		v152[v153] = true
	end
	return v151
end
function v_u_4.PadOverlap(p154, p155)
	-- upvalues: (copy) v_u_141
	local v156 = v_u_141[p154]
	local v157 = v_u_141[p155]
	local v158
	if v156 == nil or v157 == nil then
		v158 = false
	else
		for v159 in v156.contexts do
			if not v157.contexts[v159] then
				continue
			end
			return true
		end
		v158 = false
	end
	return v158
end
local v_u_160 = {}
local v_u_161 = {}
local v_u_162 = false
v_u_4.PadChanged = v3.new()
local function v_u_167() -- name: padReindex
	-- upvalues: (copy) v_u_161, (copy) v_u_4, (copy) v_u_160
	table.clear(v_u_161)
	for _, v163 in v_u_4.PAD_ACTIONS do
		for _, v164 in v_u_160[v163.id] do
			v_u_161[v164] = v_u_161[v164] or {}
			local v165 = v_u_161[v164]
			local v166 = v163.id
			table.insert(v165, v166)
		end
	end
end
local function v_u_169() -- name: padResetAll
	-- upvalues: (copy) v_u_4, (copy) v_u_160, (copy) v_u_167
	for _, v168 in v_u_4.PAD_ACTIONS do
		v_u_160[v168.id] = table.clone(v168.buttons)
	end
	v_u_167()
end
v_u_169()
local function v_u_177(p170, p171, p172) -- name: padTaken
	-- upvalues: (copy) v_u_161, (copy) v_u_141
	for _, v173 in v_u_161[p171] or {} do
		if v173 == p170.id or v173 == p172 then
			continue
		end
		local v174 = v_u_141[v173]
		for v175 in p170.contexts do
			if not v174.contexts[v175] then
				continue
			end
			v176 = true
		end
		local v176 = false
		if not v176 then
			break
		end
		return v173
	end
	return nil
end
function v_u_4.PadGet(p178) -- name: PadGet
	-- upvalues: (copy) v_u_160
	return table.clone(v_u_160[p178] or {})
end
function v_u_4.PadCode(p179) -- name: PadCode
	-- upvalues: (copy) v_u_160
	local v_u_180 = v_u_160[p179]
	if v_u_180 then
		v_u_180 = v_u_180[1]
	end
	if v_u_180 then
		local v181, v182 = pcall(function()
			-- upvalues: (copy) v_u_180
			return Enum.KeyCode[v_u_180]
		end)
		if v181 then
			return v182
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_4.PadInputs(p183) -- name: PadInputs
	-- upvalues: (copy) v_u_160
	local v184 = {}
	for _, v_u_185 in v_u_160[p183] or {} do
		local v186, v187 = pcall(function()
			-- upvalues: (copy) v_u_185
			return Enum.KeyCode[v_u_185]
		end)
		if not (v186 and v187) then
			continue
		end
		table.insert(v184, v187)
	end
	return v184
end
function v_u_4.PadIsDefault(p188) -- name: PadIsDefault
	-- upvalues: (copy) v_u_141, (copy) v_u_160
	local v189 = v_u_141[p188]
	local v190
	if v189 == nil then
		v190 = false
	else
		local v191 = v_u_160[p188]
		local v192 = v189.buttons
		if #v191 ~= #v192 then
			return false
		end
		for v193, v194 in v191 do
			if v192[v193] == v194 then
				continue
			end
			return false
		end
		v190 = true
	end
	return v190
end
function v_u_4.PadAllDefault() -- name: PadAllDefault
	-- upvalues: (copy) v_u_4, (copy) v_u_160
	for _, v195 in v_u_4.PAD_ACTIONS do
		local v196 = v_u_160[v195.id]
		local v197 = v195.buttons
		local v198
		if #v196 == #v197 then
			for v199, v200 in v196 do
				if v197[v199] == v200 then
					continue
				end
				v198 = false
			end
			v198 = true
		else
			v198 = false
		end
		if v198 then
			continue
		end
		return false
	end
	return true
end
function v_u_4.PadSettingValue(p201) -- name: PadSettingValue
	-- upvalues: (copy) v_u_141, (copy) v_u_160, (copy) v_u_4
	local v202 = v_u_141[p201]
	if v202 then
		local v203 = v_u_160[p201]
		local v204 = v202.buttons
		local v205
		if #v203 == #v204 then
			for v206, v207 in v203 do
				if v204[v206] == v207 then
					continue
				end
				v205 = false
			end
			v205 = true
		else
			v205 = false
		end
		if not v205 then
			return v_u_4.Encode(v_u_160[p201])
		end
	end
	return ""
end
function v_u_4.SettingValueFor(p208) -- name: SettingValueFor
	-- upvalues: (copy) v_u_4
	local v209 = #v_u_4.PAD_PREFIX
	if string.sub(p208, 1, v209) == v_u_4.PAD_PREFIX then
		local v210 = v_u_4.PadSettingValue
		local v211 = #v_u_4.PAD_PREFIX + 1
		return v210((string.sub(p208, v211)))
	else
		local v212 = v_u_4.SettingValue
		local v213 = #v_u_4.PREFIX + 1
		return v212((string.sub(p208, v213)))
	end
end
local v_u_214 = {}
function v_u_4.PadActionsOf(p215) -- name: PadActionsOf
	-- upvalues: (copy) v_u_214, (copy) v_u_161
	local v216 = p215.UserInputType.Name
	if string.sub(v216, 1, 7) == "Gamepad" then
		return v_u_161[p215.KeyCode.Name] or v_u_214
	else
		return v_u_214
	end
end
function v_u_4.IsPad(p217, p218) -- name: IsPad
	-- upvalues: (copy) v_u_4
	return table.find(v_u_4.PadActionsOf(p217), p218) ~= nil
end
function v_u_4.PadUsedIn(p219, p220) -- name: PadUsedIn
	-- upvalues: (copy) v_u_4, (copy) v_u_141
	for _, v221 in v_u_4.PadActionsOf(p219) do
		if not v_u_141[v221].contexts[p220] then
			continue
		end
		return true
	end
	return false
end
function v_u_4.PadBlocked() -- name: PadBlocked
	-- upvalues: (ref) v_u_162
	return v_u_162
end
function v_u_4.PadLoad(p222) -- name: PadLoad
	-- upvalues: (copy) v_u_160, (copy) v_u_141, (copy) v_u_4, (copy) v_u_167
	local v223 = type(p222) ~= "table" and {} or p222
	local v224 = {}
	for v225, v226 in v_u_160 do
		v224[v225] = v226
	end
	local v_u_227 = {}
	local function v239(p228, p229) -- name: keep
		-- upvalues: (copy) v_u_227, (ref) v_u_141
		local v230 = {}
		for _, v231 in p229 do
			local v232 = true
			for _, v233 in v_u_227[v231] or {} do
				local v234 = v_u_141[v233]
				for v235 in p228.contexts do
					if not v234.contexts[v235] then
						continue
					end
					v236 = true
				end
				local v236 = false
				if not v236 then
					break
				end
				v232 = false
			end
			if not v232 then
				break
			end
			v_u_227[v231] = v_u_227[v231] or {}
			local v237 = v_u_227[v231]
			local v238 = p228.id
			table.insert(v237, v238)
			table.insert(v230, v231)
		end
		return v230
	end
	local v240 = {}
	for _, v241 in v_u_4.PAD_ACTIONS do
		local v242 = v_u_4.PadParse(v241.id, v223[v_u_4.PAD_PREFIX .. v241.id])
		if not v242 then
			continue
		end
		v_u_160[v241.id] = v239(v241, v242)
		v240[v241.id] = true
	end
	for _, v243 in v_u_4.PAD_ACTIONS do
		if v240[v243.id] then
			continue
		end
		v_u_160[v243.id] = v239(v243, v243.buttons)
	end
	v_u_167()
	local v244 = {}
	for _, v245 in v_u_4.PAD_ACTIONS do
		local v246 = v224[v245.id] or {}
		local v247 = v_u_160[v245.id]
		local v248
		if #v246 == #v247 then
			for v249, v250 in v246 do
				if v247[v249] == v250 then
					continue
				end
				v248 = false
			end
			v248 = true
		else
			v248 = false
		end
		if v248 then
			continue
		end
		local v251 = v245.id
		table.insert(v244, v251)
	end
	if #v244 > 0 then
		v_u_4.PadChanged:Fire(v244)
	end
end
function v_u_4.PadAssign(p252, p253, p254) -- name: PadAssign
	-- upvalues: (copy) v_u_141, (copy) v_u_144, (copy) v_u_160, (copy) v_u_167, (copy) v_u_4, (copy) v_u_177
	local v255 = v_u_141[p252]
	if not (v255 and v_u_144[p254]) then
		return {}, {}
	end
	local v256 = v_u_160[p252]
	local v257 = v255.max
	local v258 = #v256 + 1
	local v259 = math.min(v257, v258)
	local v260 = math.clamp(p253, 1, v259)
	local v261 = v256[v260]
	if v261 == p254 then
		return {}, {}
	end
	local v262 = table.find(v256, p254)
	if v262 then
		if v261 == nil then
			return {}, {}
		end
		v256[v262] = v261
		v256[v260] = p254
		v_u_167()
		v_u_4.PadChanged:Fire({ p252 })
		return { p252 }, {}
	end
	v256[v260] = p254
	v_u_167()
	local v263 = { p252 }
	local v264 = {}
	for _, v265 in v_u_4.PAD_ACTIONS do
		if v265.id == p252 then
			continue
		end
		for v266 in v255.contexts do
			if not v265.contexts[v266] then
				continue
			end
			v267 = true
		end
		local v267 = false
		if not v267 then
			break
		end
		local v268 = v_u_160[v265.id]
		local v269 = table.find(v268, p254)
		if not v269 then
			break
		end
		if v261 and (not table.find(v268, v261) and v_u_177(v265, v261, nil) == nil) then
			v268[v269] = v261
		else
			table.remove(v268, v269)
		end
		v_u_167()
		local v270 = v265.id
		table.insert(v263, v270)
		local v271 = {
			["id"] = v265.id,
			["now"] = table.clone(v268)
		}
		table.insert(v264, v271)
	end
	v_u_4.PadChanged:Fire(v263)
	return v263, v264
end
function v_u_4.PadClear(p272, p273) -- name: PadClear
	-- upvalues: (copy) v_u_160, (copy) v_u_167, (copy) v_u_4
	local v274 = v_u_160[p272]
	if v274 and v274[p273] then
		table.remove(v274, p273)
		v_u_167()
		v_u_4.PadChanged:Fire({ p272 })
	end
end
function v_u_4.PadResetAll() -- name: PadResetAll
	-- upvalues: (copy) v_u_4, (copy) v_u_160, (copy) v_u_169
	local v275 = {}
	for _, v276 in v_u_4.PAD_ACTIONS do
		local v277 = v_u_160[v276.id]
		local v278 = v276.buttons
		local v279
		if #v277 == #v278 then
			for v280, v281 in v277 do
				if v278[v280] == v281 then
					continue
				end
				v279 = false
			end
			v279 = true
		else
			v279 = false
		end
		if v279 then
			continue
		end
		local v282 = v276.id
		table.insert(v275, v282)
	end
	v_u_169()
	if #v275 > 0 then
		v_u_4.PadChanged:Fire(v275)
	end
	return v275
end
v_u_4.FakeInput = v3.new()
function v_u_4.OnInput(p_u_283, p_u_284) -- name: OnInput
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v285 = game:GetService("UserInputService")
	local v286
	if p_u_283 == "Began" then
		v286 = v285.InputBegan
	elseif p_u_283 == "Ended" then
		v286 = v285.InputEnded
	else
		v286 = v285.InputChanged
	end
	v286:Connect(p_u_284)
	if v_u_2:IsStudio() then
		v_u_4.FakeInput:Connect(function(p287, p288, p289)
			-- upvalues: (copy) p_u_283, (copy) p_u_284
			if p287 == p_u_283 then
				p_u_284(p288, p289 == true)
			end
		end)
	end
end
local v_u_290 = { "Slide", "Jump" }
local v_u_291 = {
	["MouseButton1"] = Enum.KeyCode.MouseLeftButton,
	["MouseButton2"] = Enum.KeyCode.MouseRightButton,
	["MouseButton3"] = Enum.KeyCode.MouseMiddleButton
}
local v_u_292 = {}
local function v_u_298(p293) -- name: collectPadBindings
	-- upvalues: (copy) v_u_290, (copy) v_u_292
	for _, v294 in v_u_290 do
		local v295 = p293:FindFirstChild(v294)
		if not (v295 and v295:IsA("InputAction")) then
			continue
		end
		for _, v296 in v295:GetChildren() do
			if not v296:IsA("InputBinding") or v_u_292[v296] ~= nil then
				continue
			end
			local v297 = v296.KeyCode.Name
			if string.find(v297, "^Button") == nil and string.find(v297, "^DPad") == nil and string.find(v297, "^Thumbstick") == nil and string.find(v296.Name, "^PadLocal") == nil then
				continue
			end
			v_u_292[v296] = true
		end
	end
end
local function v_u_314(p299) -- name: applyPadBindings
	-- upvalues: (copy) v_u_292, (copy) v_u_290, (copy) v_u_160, (ref) v_u_162
	for v300 in v_u_292 do
		if v300.Parent then
			continue
		end
		v_u_292[v300] = nil
	end
	for _, v301 in v_u_290 do
		local v302 = p299:FindFirstChild(v301)
		if not (v302 and v302:IsA("InputAction")) then
			continue
		end
		local v303 = {}
		for _, v304 in v302:GetChildren() do
			if not (v304:IsA("InputBinding") and v_u_292[v304]) then
				continue
			end
			table.insert(v303, v304)
		end
		table.sort(v303, function(p305, p306)
			return p305.Name < p306.Name
		end)
		local v307 = v_u_160[v301] or {}
		local v308 = #v303
		local v309 = #v307
		for v310 = 1, math.max(v308, v309) do
			local v_u_311 = v303[v310]
			local v312 = v307[v310]
			if v312 and not v_u_311 then
				v_u_311 = Instance.new("InputBinding")
				v_u_311.Name = "PadLocal" .. v310
				v_u_311.KeyCode = Enum.KeyCode.None
				v_u_292[v_u_311] = true
				v_u_311.Parent = v302
			end
			if not v_u_311 then
				continue
			end
			local v_u_313
			if v312 and not v_u_162 then
				v_u_313 = Enum.KeyCode[v312]
			else
				v_u_313 = Enum.KeyCode.None
			end
			pcall(function()
				-- upvalues: (ref) v_u_311, (copy) v_u_313
				v_u_311.KeyCode = v_u_313
			end)
		end
	end
end
function v_u_4.SetPadBlocked(p315) -- name: SetPadBlocked
	-- upvalues: (ref) v_u_162, (copy) v_u_1, (copy) v_u_298, (copy) v_u_314
	v_u_162 = p315
	local v316 = v_u_1.LocalPlayer
	if v316 then
		v316 = v316:FindFirstChild("TribesInputs")
	end
	if v316 then
		v_u_298(v316)
		v_u_314(v316)
	end
end
local function v_u_332() -- name: applyInputActions
	-- upvalues: (copy) v_u_1, (copy) v_u_298, (copy) v_u_314, (copy) v_u_290, (copy) v_u_292, (copy) v_u_41, (copy) v_u_291
	local v317 = v_u_1.LocalPlayer
	if v317 then
		v317 = v317:FindFirstChild("TribesInputs")
	end
	if v317 then
		v_u_298(v317)
		v_u_314(v317)
		for _, v318 in v_u_290 do
			local v319 = v317:FindFirstChild(v318)
			if not (v319 and v319:IsA("InputAction")) then
				continue
			end
			local v320 = {}
			for _, v321 in v319:GetChildren() do
				if not v321:IsA("InputBinding") or (v321.Name == "Script" or v321.Type == Enum.InputBindingType.Scriptable) then
					continue
				end
				local v322 = v321.KeyCode.Name
				if (string.find(v322, "^Button") ~= nil or string.find(v322, "^DPad") ~= nil) and true or string.find(v322, "^Thumbstick") ~= nil or v_u_292[v321] ~= nil then
					continue
				end
				table.insert(v320, v321)
			end
			table.sort(v320, function(p323, p324)
				return p323.Name < p324.Name
			end)
			local v325 = v_u_41[v318] or {}
			local v326 = #v320
			local v327 = #v325
			for v328 = 1, math.max(v326, v327) do
				local v_u_329 = v320[v328]
				local v330 = v325[v328]
				if v330 and not v_u_329 then
					v_u_329 = Instance.new("InputBinding")
					v_u_329.Name = "KeyLocal" .. v328
					v_u_329.Parent = v319
				end
				if not v_u_329 then
					continue
				end
				local v_u_331
				if v330 then
					v_u_331 = v_u_291[v330] or Enum.KeyCode[v330]
				else
					v_u_331 = Enum.KeyCode.None
				end
				pcall(function()
					-- upvalues: (ref) v_u_329, (copy) v_u_331
					v_u_329.KeyCode = v_u_331
				end)
			end
		end
	end
end
v_u_4.ApplyInputActions = v_u_332
if v_u_2:IsClient() then
	local function v335(p333) -- name: onIds
		-- upvalues: (copy) v_u_332
		for _, v334 in p333 do
			if v334 ~= "Slide" and v334 ~= "Jump" then
				continue
			end
			v_u_332()
			return
		end
	end
	v_u_4.Changed:Connect(v335)
	v_u_4.PadChanged:Connect(v335)
	task.spawn(function()
		-- upvalues: (copy) v_u_1, (copy) v_u_290, (copy) v_u_332
		local v336 = v_u_1.LocalPlayer
		if v336 then
			v336 = v336:WaitForChild("TribesInputs", 120)
		end
		if v336 then
			for _, v337 in v_u_290 do
				v336:WaitForChild(v337, 10)
			end
			v_u_332()
			v336.DescendantAdded:Connect(function(p338)
				-- upvalues: (ref) v_u_332
				if p338:IsA("InputBinding") and not (string.find(p338.Name, "^KeyLocal") or string.find(p338.Name, "^PadLocal")) then
					task.defer(v_u_332)
				end
			end)
		end
	end)
end
return v_u_4