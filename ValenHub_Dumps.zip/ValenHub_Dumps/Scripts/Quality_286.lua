local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v3 = game:GetService("UserInputService")
local v_u_4 = {
	["level"] = "High",
	["particleScale"] = 1,
	["nearRadius"] = 150,
	["maxBursts"] = 40,
	["maxFlying"] = 160,
	["maxSounds"] = 20,
	["highlights"] = true,
	["decals"] = true,
	["layers"] = true
}
local v_u_5 = {
	["High"] = {
		["particleScale"] = 1,
		["nearRadius"] = 150,
		["maxBursts"] = 40,
		["maxFlying"] = 160,
		["maxSounds"] = 20,
		["highlights"] = true,
		["decals"] = true,
		["layers"] = true
	},
	["Medium"] = {
		["particleScale"] = 0.7,
		["nearRadius"] = 120,
		["maxBursts"] = 25,
		["maxFlying"] = 100,
		["maxSounds"] = 14,
		["highlights"] = true,
		["decals"] = true,
		["layers"] = true
	},
	["Low"] = {
		["particleScale"] = 0.4,
		["nearRadius"] = 80,
		["maxBursts"] = 12,
		["maxFlying"] = 50,
		["maxSounds"] = 8,
		["highlights"] = false,
		["decals"] = false,
		["layers"] = false
	}
}
local v_u_6 = {}
function v_u_4.OnChanged(p7) -- name: OnChanged
	-- upvalues: (copy) v_u_6
	local v8 = v_u_6
	table.insert(v8, p7)
end
local function v_u_14(p9) -- name: apply
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_1, (copy) v_u_6
	if p9 ~= v_u_4.level then
		v_u_4.level = p9
		for v10, v11 in v_u_5[p9] do
			v_u_4[v10] = v11
		end
		local v12 = v_u_1.LocalPlayer
		if v12 then
			v12 = v_u_1.LocalPlayer:FindFirstChildOfClass("PlayerScripts")
		end
		if v12 then
			v12:SetAttribute("CombatQualityLevel", p9)
		end
		for _, v13 in v_u_6 do
			task.spawn(v13, p9)
		end
	end
end
v_u_4.Set = v_u_14
local v_u_15 = 0
local v_u_16 = 0
local v_u_17 = v3.TouchEnabled and not v3.MouseEnabled and "Medium" or "High"
local function v_u_23() -- name: reevaluate
	-- upvalues: (copy) v_u_1, (copy) v_u_14, (ref) v_u_15, (copy) v_u_2, (ref) v_u_16, (ref) v_u_17
	local v18 = v_u_1.LocalPlayer
	if v18 then
		v18 = v_u_1.LocalPlayer:FindFirstChildOfClass("PlayerScripts")
	end
	if v18 then
		v18 = v18:GetAttribute("CombatQuality")
	end
	if v18 == "Low" or (v18 == "Medium" or v18 == "High") then
		v_u_14(v18)
		return
	else
		local v19, v20 = pcall(function()
			return UserSettings().GameSettings.SavedQualityLevel
		end)
		local v21
		if v19 and (typeof(v20) == "EnumItem" and v20 ~= Enum.SavedQualitySetting.Automatic) then
			v21 = v20.Value
		else
			v21 = nil
		end
		if v21 then
			v_u_14(v21 <= 3 and "Low" or (v21 <= 6 and "Medium" or "High"))
		else
			if v_u_15 > 0 and not v_u_2:IsStudio() then
				local v22 = v_u_16 / v_u_15 * 1000
				if v22 > 28 then
					v_u_17 = v_u_17 == "High" and "Medium" or "Low"
				elseif v22 < 18 and v_u_17 ~= "High" then
					v_u_17 = v_u_17 == "Low" and "Medium" or "High"
				end
			end
			v_u_14(v_u_17)
		end
	end
end
local v_u_24 = false
function v_u_4.Start() -- name: Start
	-- upvalues: (ref) v_u_24, (copy) v_u_4, (copy) v_u_14, (ref) v_u_17, (copy) v_u_23, (copy) v_u_2, (ref) v_u_15, (ref) v_u_16
	if not v_u_24 then
		v_u_24 = true
		v_u_4.level = "High"
		v_u_14(v_u_17)
		v_u_23()
		local v_u_25 = os.clock()
		v_u_2.RenderStepped:Connect(function(p26)
			-- upvalues: (ref) v_u_15, (ref) v_u_16, (ref) v_u_25, (ref) v_u_23
			v_u_15 = v_u_15 + 1
			v_u_16 = v_u_16 + p26
			local v27 = os.clock()
			if v27 - v_u_25 >= 2 then
				v_u_25 = v27
				v_u_23()
				v_u_15 = 0
				v_u_16 = 0
			end
		end)
	end
end
return v_u_4