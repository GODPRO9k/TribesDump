local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = script.Parent
local v_u_5 = v_u_4:WaitForChild("Humanoid")
local v_u_6 = v_u_5:FindFirstChildOfClass("Animator") or v_u_5:WaitForChild("Animator")
local v_u_7 = v_u_4:WaitForChild("HumanoidRootPart")
local v_u_8, v_u_9 = pcall(function()
	-- upvalues: (copy) v_u_2
	return require(v_u_2:WaitForChild("Shared"):WaitForChild("Camera"))
end)
pcall(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_6
	require(v_u_2:WaitForChild("Shared"):WaitForChild("AnimGuard")).Watch(v_u_6)
end)
local v10 = v_u_1.LocalPlayer:WaitForChild("PlayerScripts")
local v11 = require(v10:WaitForChild("Character"):WaitForChild("AnimationIds"))
local v12 = v11.R15
local v13 = v11.R6
local v_u_14 = v11.Emotes
if v_u_5.RigType ~= Enum.HumanoidRigType.R6 then
	v13 = v12
end
local v_u_15 = {}
local v_u_16 = {}
local v_u_17 = {}
local v_u_18 = {}
for v19, v20 in v13 do
	local v21 = Instance.new("Animation")
	v21.Name = v19
	v21.AnimationId = v20
	local v22 = v_u_6:LoadAnimation(v21)
	v22.Priority = Enum.AnimationPriority.Core
	v22.Looped = true
	v_u_15[v19] = v22
	v_u_16[v19] = 0
end
for v23, v24 in v_u_15 do
	v24:Play(0, 0.0001, 1)
	v_u_16[v23] = 0
	v_u_17[v23] = 0.0001
	v_u_18[v23] = 1
end
v_u_16.idle = 1
v_u_15.idle:AdjustWeight(1, 0)
v_u_17.idle = 1
local v_u_25 = 0
local v_u_26 = false
local v_u_27 = "ground"
local v_u_28 = -1
local v_u_29 = 0
local v_u_30 = 0
local v_u_31 = nil
local v_u_32 = {
	[Enum.HumanoidStateType.Jumping] = "air",
	[Enum.HumanoidStateType.Freefall] = "air",
	[Enum.HumanoidStateType.Climbing] = "climb",
	[Enum.HumanoidStateType.Swimming] = "swim",
	[Enum.HumanoidStateType.Seated] = "sit",
	[Enum.HumanoidStateType.Dead] = "none",
	[Enum.HumanoidStateType.Physics] = "none",
	[Enum.HumanoidStateType.Ragdoll] = "none",
	[Enum.HumanoidStateType.FallingDown] = "none",
	[Enum.HumanoidStateType.PlatformStanding] = "none",
	[Enum.HumanoidStateType.Running] = "ground",
	[Enum.HumanoidStateType.RunningNoPhysics] = "ground",
	[Enum.HumanoidStateType.Landed] = "ground",
	[Enum.HumanoidStateType.GettingUp] = "ground"
}
v_u_5.StateChanged:Connect(function(_, p33)
	-- upvalues: (copy) v_u_3, (ref) v_u_27, (ref) v_u_28, (copy) v_u_15, (ref) v_u_31, (copy) v_u_8, (copy) v_u_9, (copy) v_u_32
	if v_u_3:IsResimulating() then
		return
	elseif p33 == Enum.HumanoidStateType.Jumping then
		if v_u_27 ~= "air" or (v_u_28 <= 0 or os.clock() - v_u_28 >= 0.4) then
			v_u_27 = "air"
			v_u_28 = os.clock() - 0
			v_u_15.jump.TimePosition = 0
		end
		if v_u_31 then
			v_u_31:Stop(0.2)
			v_u_31 = nil
			if v_u_8 then
				v_u_9.ResumeCharacterRotation("Emote")
			end
		end
	else
		local v34 = v_u_32[p33]
		if v34 then
			if v34 == v_u_27 then
				return
			end
			if v34 == "air" then
				v_u_28 = -1
			end
			if v34 ~= "ground" and (v34 ~= "sit" and v_u_31) then
				v_u_31:Stop(0.2)
				v_u_31 = nil
				if v_u_8 then
					v_u_9.ResumeCharacterRotation("Emote")
				end
			end
			v_u_27 = v34
		end
	end
end)
v_u_5.Climbing:Connect(function(p35)
	-- upvalues: (ref) v_u_29
	v_u_29 = p35
end)
v_u_5.Swimming:Connect(function(p36)
	-- upvalues: (ref) v_u_30
	v_u_30 = p36
end)
local v37 = script:FindFirstChild("PlayEmote")
if not v37 then
	v37 = Instance.new("BindableFunction")
	v37.Name = "PlayEmote"
	v37.Parent = script
end
v_u_1.LocalPlayer:GetAttributeChangedSignal("State"):Connect(function()
	-- upvalues: (copy) v_u_1, (ref) v_u_31, (copy) v_u_8, (copy) v_u_9
	if v_u_1.LocalPlayer:GetAttribute("State") == "Match" and v_u_31 then
		v_u_31:Stop(0.2)
		v_u_31 = nil
		if v_u_8 then
			v_u_9.ResumeCharacterRotation("Emote")
		end
	end
end)
function v37.OnInvoke(p38)
	-- upvalues: (ref) v_u_27, (copy) v_u_5, (copy) v_u_1, (copy) v_u_14, (ref) v_u_31, (copy) v_u_8, (copy) v_u_9, (copy) v_u_6
	if v_u_27 ~= "ground" or v_u_5.MoveDirection.Magnitude > 0.05 or v_u_1.LocalPlayer:GetAttribute("State") == "Match" then
		return false
	end
	local v39 = nil
	if typeof(p38) == "Instance" and p38:IsA("Animation") then
		v39 = p38
	elseif typeof(p38) == "string" and v_u_14[p38] then
		v39 = Instance.new("Animation")
		v39.AnimationId = v_u_14[p38]
	end
	if not v39 then
		return false
	end
	if v_u_31 then
		v_u_31:Stop(0.2)
		v_u_31 = nil
		if v_u_8 then
			v_u_9.ResumeCharacterRotation("Emote")
		end
	end
	local v_u_40 = v_u_6:LoadAnimation(v39)
	v_u_40.Priority = Enum.AnimationPriority.Idle
	v_u_40:Play(0.2)
	v_u_31 = v_u_40
	if v_u_8 then
		v_u_9.SuspendCharacterRotation("Emote")
	end
	v_u_40.Stopped:Once(function()
		-- upvalues: (ref) v_u_31, (copy) v_u_40, (ref) v_u_8, (ref) v_u_9
		if v_u_31 == v_u_40 then
			v_u_31 = nil
			if v_u_8 then
				v_u_9.ResumeCharacterRotation("Emote")
			end
		end
	end)
	return true
end
local v_u_41 = {}
local v_u_42 = false
local v_u_43 = {}
local v_u_44 = 0
local v_u_45 = v_u_27
local function v_u_54() -- name: push
	-- upvalues: (copy) v_u_15, (copy) v_u_16, (copy) v_u_17, (copy) v_u_41, (copy) v_u_43, (copy) v_u_18
	for v46, v47 in v_u_15 do
		local v48 = v_u_16[v46]
		local v49 = v_u_17[v46]
		local v50, v51
		if v48 == v49 then
			v50 = v_u_43[v46]
			if v50 then
				v51 = v50 - v_u_18[v46]
				if math.abs(v51) >= 0.02 then
					v_u_18[v46] = v50
					v47:AdjustSpeed(v50)
				end
			end
			if v47.IsPlaying then
				continue
			end
			v47:Play(0, v_u_17[v46], v_u_18[v46])
		else
			local v52 = v48 - v49
			if math.abs(v52) >= 0.01 then
				v_u_17[v46] = v48
				v47:AdjustWeight(v48, 0.05)
				::l7::
				v50 = v_u_43[v46]
				if v50 then
					v51 = v50 - v_u_18[v46]
					if math.abs(v51) >= 0.02 then
						v_u_18[v46] = v50
						v47:AdjustSpeed(v50)
					end
				end
				if v47.IsPlaying then
					continue
				end
				v47:Play(0, v_u_17[v46], v_u_18[v46])
			else
				local v53 = v_u_41[v46] or 0
				if v48 == math.max(v53, 0.0001) then
					v_u_17[v46] = v48
					v47:AdjustWeight(v48, 0.05)
					goto l7
				end
				v50 = v_u_43[v46]
				if v50 then
					v51 = v50 - v_u_18[v46]
					if math.abs(v51) >= 0.02 then
						v_u_18[v46] = v50
						v47:AdjustSpeed(v50)
					end
				end
				if v47.IsPlaying then
					continue
				end
				v47:Play(0, v_u_17[v46], v_u_18[v46])
			end
		end
	end
end
v_u_3.Heartbeat:Connect(function(p55)
	-- upvalues: (ref) v_u_42, (copy) v_u_4, (copy) v_u_15, (copy) v_u_41, (copy) v_u_43, (copy) v_u_7, (copy) v_u_5, (copy) v_u_32, (ref) v_u_27, (ref) v_u_28, (ref) v_u_31, (copy) v_u_8, (copy) v_u_9, (ref) v_u_25, (ref) v_u_26, (ref) v_u_29, (ref) v_u_30, (copy) v_u_16, (ref) v_u_44, (ref) v_u_45, (copy) v_u_54
	if not v_u_42 and v_u_4.Parent then
		for v56 in v_u_15 do
			v_u_41[v56] = 0
		end
		table.clear(v_u_43)
		local v57 = v_u_7.AssemblyLinearVelocity
		local v58 = v57.X
		local v59 = v57.Z
		local v60 = Vector3.new(v58, 0, v59).Magnitude
		local v61 = v_u_4:FindFirstChild("HumanoidRootPart")
		if v61 then
			v61 = v61:GetAttribute("SHipBase")
		end
		local v62 = 0.5
		if type(v61) ~= "number" then
			v61 = v_u_5.HipHeight
		end
		local v63 = v61 / 2
		local v64 = math.max(v62, v63)
		local v65 = v_u_32[v_u_5:GetState()]
		if v65 and v65 ~= v_u_27 then
			if v65 == "air" and v57.Y > 8 then
				local v66 = workspace.Gravity
				local v67 = 2 * v66
				local v68 = v_u_5.JumpHeight
				local v69 = v67 * math.max(v68, 0.1)
				local v70 = (math.sqrt(v69) - v57.Y) / v66
				local v71 = math.clamp(v70, 0, 0.4)
				if v_u_27 ~= "air" or (v_u_28 <= 0 or os.clock() - v_u_28 >= 0.4) then
					v_u_27 = "air"
					v_u_28 = os.clock() - v71
					v_u_15.jump.TimePosition = v71
				end
			elseif v65 ~= v_u_27 then
				if v65 == "air" then
					v_u_28 = -1
				end
				if v65 ~= "ground" and (v65 ~= "sit" and v_u_31) then
					v_u_31:Stop(0.2)
					v_u_31 = nil
					if v_u_8 then
						v_u_9.ResumeCharacterRotation("Emote")
					end
				end
				v_u_27 = v65
			end
		end
		if v_u_27 == "ground" then
			local v72 = (v60 - 0.6) / 2.5
			local v73 = math.clamp(v72, 0, 1)
			local v74 = v_u_5.MoveDirection.Magnitude < 0.05 and v60 < 3 and 0 or v73
			local v75 = (v60 / v64 - 9) / 5
			local v76 = math.clamp(v75, 0, 1)
			v_u_25 = v_u_25 + p55
			if v_u_25 > 12 then
				v_u_25 = 0
				v_u_26 = math.random() < 0.35
			end
			v_u_41[v_u_26 and "idle2" or "idle"] = 1 - v74
			v_u_41.walk = v74 * (1 - v76)
			v_u_41.run = v74 * v76
			local v77 = 1
			if v60 > 1 then
				local v78 = v_u_7.CFrame.LookVector
				v77 = (v57.X * v78.X + v57.Z * v78.Z) / v60 < -0.35 and -1 or v77
			end
			local v79 = v_u_43
			local v80 = v60 / (v64 * 7.5)
			v79.walk = v77 * math.clamp(v80, 0.4, 1.8)
			local v81 = v_u_43
			local v82 = v60 / (v64 * 16.5)
			v81.run = v77 * math.clamp(v82, 0.55, 1.7)
			if v_u_31 and (v74 > 0.1 and v_u_31) then
				v_u_31:Stop(0.2)
				v_u_31 = nil
				if v_u_8 then
					v_u_9.ResumeCharacterRotation("Emote")
				end
			end
		elseif v_u_27 == "air" then
			local v83 = os.clock() - v_u_28
			if v_u_28 > 0 and (v83 < 0.45 and v57.Y > -12) then
				v_u_41.jump = 1
			else
				v_u_41.fall = 1
			end
		elseif v_u_27 == "climb" then
			v_u_41.climb = 1
			local v84 = v_u_29
			v_u_43.climb = math.abs(v84) <= 0.1 and 0 or v_u_29 / (v64 * 5)
		elseif v_u_27 == "swim" then
			local v85 = (v_u_30 - 1) / 3
			local v86 = math.clamp(v85, 0, 1)
			v_u_41.swim = v86
			v_u_41.swimidle = 1 - v86
			local v87 = v_u_43
			local v88 = v_u_30 / 10
			v87.swim = math.clamp(v88, 0.6, 1.5)
		elseif v_u_27 == "sit" then
			v_u_41.sit = 1
		end
		local v89 = -14 * p55
		local v90 = 1 - math.exp(v89)
		for v91 in v_u_15 do
			local v92 = v_u_41[v91] or 0
			local v93 = v_u_16[v91] + (v92 - v_u_16[v91]) * v90
			local v94 = v92 - v93
			if math.abs(v94) >= 0.002 then
				v92 = v93
			end
			v_u_16[v91] = v92 < 0.001 and 0.0001 or v92
		end
		v_u_44 = v_u_44 + p55
		if v_u_44 >= 0.05 or v_u_27 ~= v_u_45 then
			v_u_44 = 0
			v_u_45 = v_u_27
			v_u_54()
		end
	end
end)
v_u_5.Died:Connect(function()
	-- upvalues: (ref) v_u_42, (ref) v_u_31, (copy) v_u_8, (copy) v_u_9, (copy) v_u_15
	v_u_42 = true
	if v_u_31 then
		v_u_31:Stop(0.2)
		v_u_31 = nil
		if v_u_8 then
			v_u_9.ResumeCharacterRotation("Emote")
		end
	end
	for _, v95 in v_u_15 do
		v95:Stop(0.3)
	end
end)