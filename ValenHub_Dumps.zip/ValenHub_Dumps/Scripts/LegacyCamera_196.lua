require(script.Parent:WaitForChild("CameraUtils"))
local v_u_1 = require(script.Parent:WaitForChild("CameraInput"))
local v_u_2 = game:GetService("Players")
local v_u_3 = require(script.Parent:WaitForChild("BaseCamera"))
local v_u_4 = setmetatable({}, v_u_3)
v_u_4.__index = v_u_4
function v_u_4.new() -- name: new
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v5 = v_u_3.new()
	local v6 = v_u_4
	local v7 = setmetatable(v5, v6)
	v7.cameraType = Enum.CameraType.Fixed
	v7.lastUpdate = tick()
	v7.lastDistanceToSubject = nil
	return v7
end
function v_u_4.GetModuleName(_) -- name: GetModuleName
	return "LegacyCamera"
end
function v_u_4.Update(p8, p9) -- name: Update
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	if not p8.cameraType then
		return nil, nil
	end
	local v10 = tick()
	local v11 = v10 - p8.lastUpdate
	local v12 = workspace.CurrentCamera
	local v13 = v12.CFrame
	local v14 = v12.Focus
	local v15 = v_u_2.LocalPlayer
	local v16 = v_u_1.getRotation(p9)
	if p8.lastUpdate == nil or v11 > 1 then
		p8.lastDistanceToSubject = nil
	end
	local v17 = p8:GetSubjectPosition()
	if p8.cameraType == Enum.CameraType.Fixed then
		if v17 and (v15 and v12) then
			local v18 = p8:GetCameraToSubjectDistance()
			local v19 = p8:CalculateNewLookVectorFromArg(nil, v16)
			v14 = v12.Focus
			v13 = CFrame.new(v12.CFrame.Position, v12.CFrame.Position + v18 * v19)
		end
	elseif p8.cameraType == Enum.CameraType.Attach then
		local v20 = p8:GetSubjectCFrame()
		local v21 = v12.CFrame:ToEulerAnglesYXZ()
		local _, v22 = v20:ToEulerAnglesYXZ()
		local v23 = v21 - v16.Y
		local v24 = math.clamp(v23, -1.3962634015954636, 1.3962634015954636)
		v14 = CFrame.new(v20.Position) * CFrame.fromEulerAnglesYXZ(v24, v22, 0)
		v13 = v14 * CFrame.new(0, 0, p8:StepZoom(p9))
	else
		if p8.cameraType ~= Enum.CameraType.Watch then
			return v12.CFrame, v12.Focus
		end
		if v17 and (v15 and v12) then
			local v25 = nil
			if v17 == v12.CFrame.Position then
				warn("Camera cannot watch subject in same position as itself")
				return v12.CFrame, v12.Focus
			end
			local v26 = p8:GetHumanoid()
			if v26 and v26.RootPart then
				local v27 = v17 - v12.CFrame.Position
				v25 = v27.unit
				if p8.lastDistanceToSubject and p8.lastDistanceToSubject == p8:GetCameraToSubjectDistance() then
					p8:SetCameraToSubjectDistance(v27.magnitude)
				end
			end
			local v28 = p8:GetCameraToSubjectDistance()
			local v29 = p8:CalculateNewLookVectorFromArg(v25, v16)
			v14 = CFrame.new(v17)
			v13 = CFrame.new(v17 - v28 * v29, v17)
			p8.lastDistanceToSubject = v28
		end
	end
	p8.lastUpdate = v10
	return v13, v14
end
return v_u_4