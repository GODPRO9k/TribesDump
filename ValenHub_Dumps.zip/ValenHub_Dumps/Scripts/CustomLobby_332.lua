local v_u_1 = game:GetService("ProximityPromptService")
game:GetService("UserInputService")
game:GetService("GuiService")
local v_u_2 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("CustomMatch"))
return {
	["Init"] = function(p_u_3) -- name: Init
		-- upvalues: (copy) v_u_2, (copy) v_u_1
		local v_u_4 = p_u_3.UI
		local v_u_5 = p_u_3.Theme
		local v_u_6 = p_u_3.State
		local v_u_7 = v_u_5.Colors
		local v_u_8 = v_u_5.Fonts
		local v_u_9 = p_u_3.Custom
		local v_u_10 = UDim2.fromOffset
		local v_u_11 = false
		local v_u_12 = nil
		local v_u_13 = nil
		local v_u_14 = nil
		local v_u_15 = nil
		local v_u_16 = nil
		local v_u_17 = nil
		local v_u_18 = nil
		local v_u_19 = nil
		local v_u_20 = nil
		local v_u_21 = nil
		local function v_u_24() -- name: placeLock
			-- upvalues: (ref) v_u_18, (ref) v_u_14, (ref) v_u_19
			if v_u_18 and (v_u_14 and v_u_19) then
				local v22 = v_u_14.Position.Y.Offset + v_u_14.Size.Y.Offset / 2
				v_u_19.Position = UDim2.new(1, v_u_14.Position.X.Offset, 0, v22)
				local v23
				if v_u_19.Visible then
					v23 = v_u_19.Size.X.Offset
				else
					v23 = v_u_14.TextBounds.X
				end
				v_u_18.Position = UDim2.new(1, v_u_14.Position.X.Offset - v23 - 7, 0, v22)
			end
		end
		local v_u_25 = nil
		local v_u_26 = nil
		local v_u_27 = nil
		local v_u_28 = false
		local v_u_29 = nil
		local function v_u_30() -- name: closeConfirm
			-- upvalues: (ref) v_u_29, (copy) p_u_3
			if v_u_29 then
				v_u_29.Visible = false
			end
			p_u_3.MenuManager.PopMouse("CustomLeave")
			p_u_3.MenuManager.PopFocus("CustomLeave")
		end
		local function v_u_33() -- name: leave
			-- upvalues: (ref) v_u_29, (copy) p_u_3, (copy) v_u_9
			if v_u_29 then
				v_u_29.Visible = false
			end
			p_u_3.MenuManager.PopMouse("CustomLeave")
			p_u_3.MenuManager.PopFocus("CustomLeave")
			task.spawn(function()
				-- upvalues: (ref) v_u_9, (ref) p_u_3
				local v31, v32 = v_u_9.Action("Leave")
				if not v31 then
					p_u_3.Toast(tostring(v32), "error")
				end
			end)
		end
		local function v_u_40() -- name: openConfirm
			-- upvalues: (ref) v_u_29, (copy) v_u_4, (copy) v_u_7, (copy) p_u_3, (copy) v_u_30, (copy) v_u_10, (copy) v_u_8, (copy) v_u_33
			if not v_u_29 then
				local v34 = v_u_4.new("TextButton", {
					["Name"] = "CustomLeaveConfirm",
					["Size"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.45,
					["Text"] = "",
					["AutoButtonColor"] = false,
					["Selectable"] = false,
					["ZIndex"] = 50,
					["Visible"] = false,
					["Parent"] = nil,
					["Size"] = UDim2.fromScale(1, 1),
					["BackgroundColor3"] = v_u_7.Void,
					["Parent"] = p_u_3.Canvas.Overlay
				})
				v34.Activated:Connect(v_u_30)
				local v35 = v_u_4.Panel({
					["Name"] = "Card",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundTransparency"] = 0.02,
					["Radius"] = nil,
					["ZIndex"] = 51,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Size"] = v_u_10(480, 256),
					["Radius"] = UDim.new(0, 16),
					["Parent"] = v34
				})
				v_u_4.DropShadow(v35, 16, 8, 0.5)
				v_u_4.new("TextButton", {
					["Name"] = "Sink",
					["Size"] = nil,
					["BackgroundTransparency"] = 1,
					["Text"] = "",
					["Selectable"] = false,
					["ZIndex"] = 52,
					["Parent"] = nil,
					["Size"] = UDim2.fromScale(1, 1),
					["Parent"] = v35
				})
				v_u_4.DisplayText({
					["Name"] = "Title",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "LEAVE CUSTOM MATCH?",
					["TextSize"] = 32,
					["TextColor3"] = nil,
					["ZIndex"] = 53,
					["Parent"] = nil,
					["Position"] = v_u_10(0, 24),
					["Size"] = UDim2.new(1, 0, 0, 40),
					["TextColor3"] = v_u_7.Text,
					["Parent"] = v35
				})
				v_u_4.new("TextLabel", {
					["Name"] = "Body",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "You\'ll go back to a public lobby. You can come back with the code while there\'s room.",
					["FontFace"] = nil,
					["TextSize"] = 19,
					["TextColor3"] = nil,
					["TextWrapped"] = true,
					["ZIndex"] = 53,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0),
					["Position"] = UDim2.new(0.5, 0, 0, 74),
					["Size"] = UDim2.new(1, -56, 0, 74),
					["FontFace"] = v_u_8.Bold,
					["TextColor3"] = v_u_7.TextDim,
					["Parent"] = v35
				})
				local v36 = v_u_4.Button({
					["Name"] = "Stay",
					["Text"] = "STAY",
					["TextSize"] = 21,
					["Style"] = "Dark",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 54,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0, 1),
					["Position"] = UDim2.new(0, 28, 1, -24),
					["Size"] = v_u_10(200, 58),
					["Parent"] = v35
				})
				local v37 = v_u_4.Button({
					["Name"] = "Leave",
					["Text"] = "LEAVE",
					["TextSize"] = 21,
					["Style"] = "Danger",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 54,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(1, 1),
					["Position"] = UDim2.new(1, -28, 1, -24),
					["Size"] = v_u_10(200, 58),
					["Parent"] = v35
				})
				v36.Activated:Connect(v_u_30)
				v37.Activated:Connect(v_u_33)
				v_u_29 = v34
			end
			local v_u_38 = v_u_29
			v_u_38.Visible = true
			v_u_4.Enter(v_u_38:FindFirstChild("Card"), Vector2.new(0, 16), 0, UDim2.fromScale(0.5, 0.5))
			p_u_3.Sounds.Play("Open")
			p_u_3.MenuManager.PushMouse("CustomLeave")
			p_u_3.MenuManager.PushFocus("CustomLeave", function()
				-- upvalues: (copy) v_u_38
				local v39 = v_u_38:FindFirstChild("Card")
				if v39 then
					v39 = v39:FindFirstChild("Stay")
				end
				return v39 or nil
			end, function()
				-- upvalues: (ref) v_u_29, (ref) p_u_3
				if v_u_29 then
					v_u_29.Visible = false
				end
				p_u_3.MenuManager.PopMouse("CustomLeave")
				p_u_3.MenuManager.PopFocus("CustomLeave")
				return true
			end)
		end
		local function v_u_64() -- name: build
			-- upvalues: (ref) v_u_11, (copy) p_u_3, (ref) v_u_12, (copy) v_u_4, (ref) v_u_13, (copy) v_u_8, (copy) v_u_7, (ref) v_u_14, (ref) v_u_19, (copy) v_u_9, (ref) v_u_18, (copy) v_u_24, (ref) v_u_20, (ref) v_u_15, (ref) v_u_16, (copy) v_u_5, (ref) v_u_17, (ref) v_u_21, (ref) v_u_25, (ref) v_u_26, (ref) v_u_27, (ref) v_u_28, (copy) v_u_40
			if not v_u_11 then
				v_u_11 = true
				local v41
				if p_u_3.LobbyHud then
					v41 = p_u_3.LobbyHud.Root
				else
					v41 = p_u_3.Canvas.HUD
				end
				v_u_12 = v_u_4.Panel({
					["Name"] = "CustomMatchCard",
					["Radius"] = nil,
					["BackgroundTransparency"] = 0.12,
					["StrokeTransparency"] = 0.82,
					["Visible"] = false,
					["Parent"] = nil,
					["Radius"] = UDim.new(0, 16),
					["Parent"] = v41
				})
				v_u_13 = v_u_4.new("TextLabel", {
					["Name"] = "Cap",
					["Text"] = "CUSTOM MATCH",
					["FontFace"] = nil,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["Parent"] = nil,
					["FontFace"] = v_u_8.Heavy,
					["TextColor3"] = v_u_7.TextDim,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Parent"] = v_u_12
				})
				v_u_14 = v_u_4.new("TextLabel", {
					["Name"] = "Code",
					["AnchorPoint"] = nil,
					["Text"] = "",
					["FontFace"] = nil,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(1, 0),
					["FontFace"] = v_u_8.Display,
					["TextColor3"] = v_u_7.Accent,
					["TextXAlignment"] = Enum.TextXAlignment.Right,
					["Parent"] = v_u_12
				})
				v_u_19 = v_u_9.MaskDots({
					["Name"] = "Mask",
					["Dot"] = 7,
					["Gap"] = 4,
					["GroupGap"] = 9,
					["Color"] = nil,
					["AnchorPoint"] = nil,
					["Parent"] = nil,
					["Color"] = v_u_7.TextDim,
					["AnchorPoint"] = Vector2.new(1, 0.5),
					["Parent"] = v_u_12
				})
				v_u_19.Visible = false
				v_u_18 = v_u_4.Glyph("lock-closed", 15, v_u_7.TextDim, {
					["Name"] = "Lock",
					["AnchorPoint"] = nil,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(1, 0.5),
					["Parent"] = v_u_12
				})
				v_u_18.Visible = false
				v_u_14:GetPropertyChangedSignal("TextBounds"):Connect(function()
					-- upvalues: (ref) v_u_24
					v_u_24()
				end)
				v_u_20 = v_u_4.Icon("chevRight", 18, v_u_7.TextDim, {
					["Name"] = "Open",
					["AnchorPoint"] = nil,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(1, 0.5),
					["Parent"] = v_u_12
				})
				v_u_15 = v_u_4.new("TextLabel", {
					["Name"] = "ServerName",
					["Text"] = "",
					["FontFace"] = nil,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["TextTruncate"] = nil,
					["Parent"] = nil,
					["FontFace"] = v_u_8.Heavy,
					["TextColor3"] = v_u_7.Text,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["TextTruncate"] = Enum.TextTruncate.AtEnd,
					["Parent"] = v_u_12
				})
				v_u_4.TextStroke(v_u_7.Void, 1.5, 0.4).Parent = v_u_15
				v_u_16 = v_u_4.new("Frame", {
					["Name"] = "Dot",
					["AnchorPoint"] = Vector2.new(0, 0.5),
					["BackgroundColor3"] = v_u_7.Success,
					v_u_4.Corner(v_u_5.Radius.Pill),
					["Parent"] = v_u_12
				})
				v_u_17 = v_u_4.new("TextLabel", {
					["Name"] = "Status",
					["Text"] = "",
					["FontFace"] = nil,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["TextTruncate"] = nil,
					["Parent"] = nil,
					["FontFace"] = v_u_8.SemiBold,
					["TextColor3"] = v_u_7.TextDim,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["TextTruncate"] = Enum.TextTruncate.AtEnd,
					["Parent"] = v_u_12
				})
				v_u_21 = v_u_4.new("TextButton", {
					["Name"] = "Open",
					["Size"] = nil,
					["BackgroundTransparency"] = 1,
					["Text"] = "",
					["AutoButtonColor"] = false,
					["ZIndex"] = 6,
					["Parent"] = nil,
					["Size"] = UDim2.fromScale(1, 1),
					["Parent"] = v_u_12
				})
				local v_u_42 = v_u_12:FindFirstChildOfClass("UIStroke")
				local v_u_43 = v_u_42.Transparency
				local v_u_44 = v_u_42.Color
				local v_u_45 = false
				local function v_u_53(p46) -- name: paintHover
					-- upvalues: (ref) v_u_4, (copy) v_u_42, (ref) v_u_5, (ref) v_u_45, (ref) v_u_7, (copy) v_u_44, (copy) v_u_43, (ref) v_u_12
					local v47 = v_u_4.Tween
					local v48 = v_u_42
					local v49 = v_u_5.Tween.Fast
					local v50 = {}
					local v51
					if v_u_45 or p46 then
						v51 = v_u_7.Accent
					else
						v51 = v_u_44
					end
					v50.Color = v51
					v50.Transparency = p46 and 0.1 or (v_u_45 and 0.35 or v_u_43)
					v47(v48, v49, v50)
					local v52 = {
						["BackgroundTransparency"] = p46 and 0.2 or (v_u_45 and 0.04 or 0.12)
					}
					v_u_4.Tween(v_u_12, v_u_5.Tween.Fast, v52)
				end
				v_u_21.MouseEnter:Connect(function()
					-- upvalues: (ref) v_u_45, (ref) v_u_4, (ref) p_u_3, (copy) v_u_53
					v_u_45 = true
					if not v_u_4.Touch then
						p_u_3.Sounds.Play("Hover")
					end
					v_u_53()
				end)
				v_u_21.MouseLeave:Connect(function()
					-- upvalues: (ref) v_u_45, (copy) v_u_53
					v_u_45 = false
					v_u_53()
				end)
				v_u_21.MouseButton1Down:Connect(function()
					-- upvalues: (copy) v_u_53
					v_u_53(true)
				end)
				v_u_21.MouseButton1Up:Connect(function()
					-- upvalues: (copy) v_u_53
					v_u_53()
				end)
				v_u_21.Activated:Connect(function()
					-- upvalues: (ref) v_u_45, (copy) v_u_53, (ref) p_u_3
					v_u_45 = false
					v_u_53()
					p_u_3.Sounds.Play("Click")
					p_u_3.MenuManager.Toggle("CustomHost")
				end)
				v_u_25 = v_u_4.Button({
					["Name"] = "CustomStart",
					["Text"] = "START MATCH",
					["Style"] = "Primary",
					["Icon"] = nil,
					["Visible"] = false,
					["Parent"] = nil,
					["OnDisabledClick"] = nil,
					["Icon"] = v_u_4.Glyph("play-large", 22, v_u_7.Text),
					["Parent"] = v41,
					["OnDisabledClick"] = function() -- name: OnDisabledClick
						-- upvalues: (ref) v_u_9, (ref) p_u_3
						local v54 = v_u_9.State()
						local v55 = p_u_3.Toast
						local v56 = v54 and v54.startHint ~= "" and (v54.startHint or "Can\'t start yet") or "Can\'t start yet"
						v55(tostring(v56), "info")
					end
				})
				v_u_26 = v_u_4.Button({
					["Name"] = "CustomLeave",
					["Text"] = "LEAVE",
					["Style"] = "Dark",
					["Icon"] = nil,
					["Visible"] = false,
					["Sound"] = false,
					["Parent"] = nil,
					["Icon"] = v_u_4.Glyph("door-open-arrow-to-bottom-right", 20, v_u_7.TextDim),
					["Parent"] = v41
				})
				v_u_27 = v_u_4.Button({
					["Name"] = "CustomWatch",
					["Text"] = "WATCH MATCH",
					["Style"] = "Primary",
					["Icon"] = nil,
					["Visible"] = false,
					["Parent"] = nil,
					["Icon"] = v_u_4.Glyph("eye", 22, v_u_7.Text),
					["Parent"] = v41
				})
				v_u_27.Activated:Connect(function()
					-- upvalues: (ref) v_u_28, (ref) v_u_27, (ref) v_u_9, (ref) p_u_3
					if v_u_28 then
						return
					else
						v_u_28 = true
						v_u_27:SetText("LOADING...")
						local v57, v58 = v_u_9.Action("Watch", true)
						v_u_28 = false
						v_u_27:SetText("WATCH MATCH")
						if v57 then
							p_u_3.Sounds.Play("Click")
						else
							p_u_3.Toast(tostring(v58), "error")
						end
					end
				end)
				v_u_25.Activated:Connect(function()
					-- upvalues: (ref) v_u_28, (ref) v_u_9, (ref) p_u_3, (ref) v_u_4, (ref) v_u_25
					if v_u_28 then
						return
					else
						local v59 = v_u_9.State()
						if v59 and v59.canStart then
							v_u_28 = true
							v_u_25:SetText("STARTING...")
							local v60, v61 = v_u_9.Host("Start")
							v_u_28 = false
							v_u_25:SetText("START MATCH")
							if v60 then
								p_u_3.Sounds.Play("Match_Found")
							else
								p_u_3.Toast(tostring(v61), "error")
							end
						else
							local v62 = p_u_3.Toast
							local v63 = v59 and v59.startHint or "Can\'t start yet"
							v62(tostring(v63), "info")
							v_u_4.Shake(v_u_25.Instance, 5)
							return
						end
					end
				end)
				v_u_26.Activated:Connect(function()
					-- upvalues: (ref) p_u_3, (ref) v_u_40
					p_u_3.Sounds.Play("Click")
					v_u_40()
				end)
			end
		end
		local function v_u_117() -- name: layout
			-- upvalues: (ref) v_u_11, (copy) p_u_3, (copy) v_u_4, (ref) v_u_12, (copy) v_u_10, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_20, (ref) v_u_16, (ref) v_u_17, (ref) v_u_25, (ref) v_u_26, (ref) v_u_27, (copy) v_u_24
			if v_u_11 then
				local v65 = p_u_3.LobbyHud
				if v65 then
					v65 = p_u_3.LobbyHud.PlayButton
				end
				if v_u_4.Compact then
					local v66
					if v65 then
						v66 = v65.Instance.Position.Y.Offset
					else
						v66 = v_u_4.TopInset()
					end
					v_u_12.AnchorPoint = Vector2.new(1, 0)
					v_u_12.Position = UDim2.new(1, -16, 0, v66)
					v_u_12.Size = v_u_10(272, 88)
					local v67 = v_u_13
					local v68 = v_u_13
					local v69 = v_u_13
					local v70 = v_u_10(16, 10)
					local v71 = v_u_10(150, 16)
					v67.Position = v70
					v68.Size = v71
					v69.TextSize = 13
					local v72 = v_u_14
					local v73 = v_u_14
					local v74 = v_u_14
					local v75 = UDim2.new(1, -16, 0, 7)
					local v76 = v_u_10(110, 22)
					v72.Position = v75
					v73.Size = v76
					v74.TextSize = 20
					local v77 = v_u_15
					local v78 = v_u_15
					local v79 = v_u_15
					local v80 = v_u_10(16, 29)
					local v81 = v_u_10(214, 26)
					v77.Position = v80
					v78.Size = v81
					v79.TextSize = 21
					v_u_20.Position = UDim2.new(1, -12, 0, 43)
					local v82 = v_u_16
					local v83 = v_u_16
					local v84 = v_u_10(17, 69)
					local v85 = v_u_10(8, 8)
					v82.Position = v84
					v83.Size = v85
					local v86 = v_u_17
					local v87 = v_u_17
					local v88 = v_u_17
					local v89 = v_u_10(31, 60)
					local v90 = v_u_10(228, 18)
					v86.Position = v89
					v87.Size = v90
					v88.TextSize = 14
					for _, v91 in { v_u_25, v_u_26, v_u_27 } do
						v91.Instance.AnchorPoint = Vector2.new(1, 0)
						v91.Instance.Position = UDim2.new(1, -16, 0, v66 + 96)
						v91.Instance.Size = v_u_10(272, 52)
						v91.Label.TextSize = 20
					end
				else
					v_u_12.AnchorPoint = Vector2.new(1, 1)
					v_u_12.Position = UDim2.new(1, -28, 1, -104)
					v_u_12.Size = v_u_10(300, 98)
					local v92 = v_u_13
					local v93 = v_u_13
					local v94 = v_u_13
					local v95 = v_u_10(18, 12)
					local v96 = v_u_10(160, 16)
					v92.Position = v95
					v93.Size = v96
					v94.TextSize = 13
					local v97 = v_u_14
					local v98 = v_u_14
					local v99 = v_u_14
					local v100 = UDim2.new(1, -18, 0, 9)
					local v101 = v_u_10(120, 22)
					v97.Position = v100
					v98.Size = v101
					v99.TextSize = 21
					local v102 = v_u_15
					local v103 = v_u_15
					local v104 = v_u_15
					local v105 = v_u_10(18, 32)
					local v106 = v_u_10(236, 28)
					v102.Position = v105
					v103.Size = v106
					v104.TextSize = 23
					v_u_20.Position = UDim2.new(1, -14, 0, 47)
					local v107 = v_u_16
					local v108 = v_u_16
					local v109 = v_u_10(19, 76)
					local v110 = v_u_10(8, 8)
					v107.Position = v109
					v108.Size = v110
					local v111 = v_u_17
					local v112 = v_u_17
					local v113 = v_u_17
					local v114 = v_u_10(33, 67)
					local v115 = v_u_10(252, 18)
					v111.Position = v114
					v112.Size = v115
					v113.TextSize = 15
					for _, v116 in { v_u_25, v_u_26, v_u_27 } do
						v116.Instance.AnchorPoint = Vector2.new(1, 1)
						v116.Instance.Position = UDim2.new(1, -28, 1, -40)
						v116.Instance.Size = v_u_10(300, 54)
						v116.Label.TextSize = 22
					end
				end
				v_u_24()
			end
		end
		local v_u_118 = false
		local v_u_119 = ""
		local v_u_120 = false
		local v_u_121 = false
		local function v149() -- name: paint
			-- upvalues: (copy) v_u_9, (copy) p_u_3, (ref) v_u_11, (ref) v_u_12, (ref) v_u_25, (ref) v_u_26, (ref) v_u_27, (ref) v_u_118, (copy) v_u_64, (copy) v_u_117, (ref) v_u_120, (copy) v_u_4, (ref) v_u_121, (ref) v_u_14, (ref) v_u_2, (ref) v_u_19, (ref) v_u_18, (copy) v_u_24, (ref) v_u_15, (copy) v_u_7, (ref) v_u_17, (ref) v_u_16, (ref) v_u_28, (ref) v_u_119
			local v122 = v_u_9.IsServer()
			if p_u_3.LobbyHud and p_u_3.LobbyHud.SetPlayHidden then
				p_u_3.LobbyHud.SetPlayHidden("Custom", v122)
			end
			local v123
			if v122 then
				v123 = v_u_9.IsHost()
			else
				v123 = v122
			end
			if p_u_3.TopbarSettings and p_u_3.TopbarSettings.SetHostVisible then
				p_u_3.TopbarSettings.SetHostVisible(v123)
			end
			if not v122 then
				if v_u_11 then
					v_u_12.Visible = false
					v_u_25.Instance.Visible = false
					v_u_26.Instance.Visible = false
					v_u_27.Instance.Visible = false
				end
				v_u_118 = false
				return
			end
			v_u_64()
			v_u_117()
			local v124 = v_u_9.State() or {}
			v_u_12.Visible = true
			local v125 = v124.players
			local v126 = false
			for _, v127 in type(v125) ~= "table" and {} or v124.players do
				if type(v127) ~= "table" or (v127.userId ~= p_u_3.Player.UserId or not v127.playing) then
					continue
				end
				v126 = true
			end
			local v128
			if v124.status == "Match" then
				v128 = not v126
			else
				v128 = false
			end
			local v129 = v_u_25.Instance
			local v130
			if v123 then
				v130 = not v128
			else
				v130 = v123
			end
			v129.Visible = v130
			local v131 = v_u_26.Instance
			local v132 = not v123
			if v132 then
				v132 = not v128
			end
			v131.Visible = v132
			v_u_27.Instance.Visible = v128
			if v128 and not v_u_120 then
				v_u_4.Enter(v_u_27.Instance, Vector2.new(0, 12), 0.05, v_u_27.Instance.Position)
			end
			if not v_u_121 then
				local v133 = v124.status
				if type(v133) == "string" then
					v_u_121 = true
					if v128 then
						p_u_3.Toast("A match is in progress. Watch it while you wait for the next one.", "info")
					end
				end
			end
			v_u_120 = v128
			local v134 = v_u_9.IsPrivate()
			if v134 then
				v134 = not v_u_9.IsRevealed()
			end
			v_u_14.Text = v_u_2.FormatCode(v_u_9.Code())
			v_u_14.Visible = not v134
			v_u_19.Visible = v134
			v_u_18.Visible = v_u_9.IsPrivate()
			v_u_24()
			local v135 = v_u_15
			local v136 = v124.name or "Custom match"
			v135.Text = tostring(v136)
			local v137 = v124.players
			local v138 = type(v137) == "table" and #v124.players or 0
			local v139 = v124.max
			local v140 = tonumber(v139) or v_u_2.MAX_PLAYERS
			local v141 = v124.status or "Lobby"
			local v142, v143, v144, v145
			if v141 == "Match" then
				v142 = string.format("Match in progress  \194\183  %d/%d", v138, v140)
				v143 = v_u_7.Warning
				v_u_17.Text = v142
				v_u_16.BackgroundColor3 = v143
				v144 = v_u_25
				if v124.canStart == true then
					v145 = not v_u_28
				else
					v145 = false
				end
				v144:SetEnabled(v145)
				if v123 and not v_u_118 then
					v_u_4.Enter(v_u_25.Instance, Vector2.new(0, 12), 0.05, v_u_25.Instance.Position)
				end
				if v141 ~= v_u_119 then
					v_u_119 = v141
					v_u_4.Pop(v_u_16, 1.8)
				end
				v_u_118 = v123
				return
			elseif v141 == "Results" then
				v143 = v_u_7.Accent
				v142 = "Showing the results"
				v_u_17.Text = v142
				v_u_16.BackgroundColor3 = v143
				v144 = v_u_25
				if v124.canStart == true then
					v145 = not v_u_28
				else
					v145 = false
				end
				v144:SetEnabled(v145)
				if v123 and not v_u_118 then
					v_u_4.Enter(v_u_25.Instance, Vector2.new(0, 12), 0.05, v_u_25.Instance.Position)
				end
				if v141 ~= v_u_119 then
					v_u_119 = v141
					v_u_4.Pop(v_u_16, 1.8)
				end
				v_u_118 = v123
			else
				local v146, v147
				if v123 and v124.canStart ~= true then
					local v148 = v124.startHint
					if type(v148) == "string" and v124.startHint ~= "" then
						v142 = v124.startHint
						v143 = v_u_7.Warning
						v_u_17.Text = v142
						v_u_16.BackgroundColor3 = v143
						v144 = v_u_25
						if v124.canStart == true then
							v145 = not v_u_28
						else
							v145 = false
						end
						v144:SetEnabled(v145)
						if v123 and not v_u_118 then
							v_u_4.Enter(v_u_25.Instance, Vector2.new(0, 12), 0.05, v_u_25.Instance.Position)
						end
						if v141 ~= v_u_119 then
							v_u_119 = v141
							v_u_4.Pop(v_u_16, 1.8)
						end
						v_u_118 = v123
						return
					end
					if v123 then
						v146 = string.format
						v147 = v124.mapName or "Random"
						v142 = v146("You\'re the host  \194\183  %s", (tostring(v147)))
						v143 = v_u_7.Success
					else
						v142 = string.format("Waiting for the host  \194\183  %d/%d", v138, v140)
						v143 = v_u_7.Success
					end
				elseif v123 then
					v146 = string.format
					v147 = v124.mapName or "Random"
					v142 = v146("You\'re the host  \194\183  %s", (tostring(v147)))
					v143 = v_u_7.Success
				else
					v142 = string.format("Waiting for the host  \194\183  %d/%d", v138, v140)
					v143 = v_u_7.Success
				end
				v_u_17.Text = v142
				v_u_16.BackgroundColor3 = v143
				v144 = v_u_25
				if v124.canStart == true then
					v145 = not v_u_28
				else
					v145 = false
				end
				v144:SetEnabled(v145)
				if v123 and not v_u_118 then
					v_u_4.Enter(v_u_25.Instance, Vector2.new(0, 12), 0.05, v_u_25.Instance.Position)
				end
				if v141 ~= v_u_119 then
					v_u_119 = v141
					v_u_4.Pop(v_u_16, 1.8)
				end
				v_u_118 = v123
			end
		end
		v_u_9.Changed:Connect(v149)
		v_u_9.RevealChanged:Connect(v149)
		v_u_4.LayoutChanged:Connect(function()
			-- upvalues: (copy) v_u_117
			v_u_117()
		end)
		if p_u_3.LobbyHud and p_u_3.LobbyHud.PlayButton then
			p_u_3.LobbyHud.PlayButton.Instance:GetPropertyChangedSignal("Position"):Connect(v_u_117)
		end
		if p_u_3.TopbarSettings and p_u_3.TopbarSettings.HostActivated then
			p_u_3.TopbarSettings.HostActivated:Connect(function()
				-- upvalues: (copy) p_u_3
				p_u_3.MenuManager.Toggle("CustomHost")
			end)
		end
		local v_u_150 = game:GetService("UserInputService")
		local v_u_151 = require(game:GetService("ReplicatedStorage").Shared:WaitForChild("Keybinds"))
		v_u_151.OnInput("Began", function(p152, p153)
			-- upvalues: (copy) v_u_150, (copy) v_u_9, (copy) v_u_151, (copy) v_u_6, (copy) p_u_3
			if not p153 and (not v_u_150:GetFocusedTextBox() and v_u_9.IsServer()) then
				local v154 = v_u_151.IsPad(p152, "CustomMenu")
				if v154 then
					if v_u_6.Get("State") == "Match" or v_u_6.Get("CombatMode") == true then
						v154 = false
					else
						v154 = not v_u_151.PadBlocked() or p_u_3.MenuManager.IsOpen("CustomHost")
					end
				end
				if v154 or v_u_151.ActionOf(p152) == "CustomMenu" then
					p_u_3.MenuManager.Toggle("CustomHost")
				end
			end
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_11, (ref) v_u_12, (copy) v_u_4, (ref) v_u_16
			while true do
				repeat
					task.wait(1.2)
				until v_u_11 and v_u_12.Visible
				v_u_4.Tween(v_u_16, TweenInfo.new(0.6, Enum.EasingStyle.Sine), {
					["BackgroundTransparency"] = v_u_16.BackgroundTransparency < 0.3 and 0.55 or 0
				})
			end
		end)
		v149()
		v_u_1.PromptShown:Connect(function(p_u_155)
			-- upvalues: (copy) v_u_9
			if p_u_155.Name == "CustomMatchesPrompt" and v_u_9.IsServer() then
				p_u_155.Enabled = false
				task.spawn(function()
					-- upvalues: (copy) p_u_155, (ref) v_u_9
					while p_u_155.Parent and v_u_9.IsServer() do
						task.wait(2)
					end
					if p_u_155.Parent then
						p_u_155.Enabled = true
					end
				end)
			end
		end)
		function p_u_3.Debug.customLobby(p156)
			-- upvalues: (copy) v_u_40, (ref) v_u_29, (copy) p_u_3, (ref) v_u_25, (ref) v_u_27, (copy) v_u_9, (ref) v_u_11, (ref) v_u_12, (ref) v_u_17, (ref) v_u_19, (ref) v_u_14, (ref) v_u_18, (ref) v_u_26
			if p156 == "leave" then
				v_u_40()
			elseif p156 == "closeConfirm" then
				if v_u_29 then
					v_u_29.Visible = false
				end
				p_u_3.MenuManager.PopMouse("CustomLeave")
				p_u_3.MenuManager.PopFocus("CustomLeave")
			elseif p156 == "start" then
				v_u_25.Activated:Fire()
			elseif p156 == "watch" then
				v_u_27.Activated:Fire()
			elseif p156 == "leaveYes" then
				if v_u_29 then
					v_u_29.Visible = false
				end
				p_u_3.MenuManager.PopMouse("CustomLeave")
				p_u_3.MenuManager.PopFocus("CustomLeave")
				task.spawn(function()
					-- upvalues: (ref) v_u_9, (ref) p_u_3
					local v157, v158 = v_u_9.Action("Leave")
					if not v157 then
						p_u_3.Toast(tostring(v158), "error")
					end
				end)
			end
			local v159 = {
				["custom"] = v_u_9.IsServer(),
				["host"] = v_u_9.IsHost()
			}
			local v160 = v_u_11
			if v160 then
				v160 = v_u_12.Visible
			end
			v159.card = v160
			v159.status = not v_u_11 and "" or v_u_17.Text
			local v161
			if v_u_11 then
				if v_u_19.Visible then
					v161 = v_u_9.MASK
				else
					v161 = v_u_14.Text
				end
			else
				v161 = ""
			end
			v159.code = v161
			local v162 = v_u_11
			if v162 then
				v162 = v_u_18.Visible
			end
			v159.lock = v162
			local v163 = v_u_11
			if v163 then
				v163 = v_u_25.Instance.Visible
			end
			v159.start = v163
			local v164 = v_u_11
			if v164 then
				v164 = v_u_26.Instance.Visible
			end
			v159.leave = v164
			local v165 = v_u_11
			if v165 then
				v165 = v_u_27.Instance.Visible
			end
			v159.watch = v165
			v159.crown = p_u_3.TopbarSettings and p_u_3.TopbarSettings.HostButton.Visible or false
			return v159
		end
		function p_u_3.Debug.custom(p166, p167)
			-- upvalues: (copy) v_u_9
			if p166 == "mock" then
				v_u_9.SetMock(p167)
			end
			local v168 = v_u_9.State()
			return {
				["server"] = v_u_9.IsServer(),
				["host"] = v_u_9.IsHost(),
				["code"] = v_u_9.Code(),
				["status"] = v168 and v168.status or false
			}
		end
	end
}