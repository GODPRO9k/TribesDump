local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("SoundService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent:WaitForChild("Quality"))
local v_u_6 = {}
local v_u_7 = {
	["Jump"] = {
		["id"] = "rbxasset://sounds/action_jump.mp3",
		["volume"] = 0.15
	},
	["Land"] = {
		["id"] = "rbxasset://sounds/action_jump_land.mp3",
		["volume"] = 0.5
	},
	["LandHeavy"] = {
		["id"] = "rbxasset://sounds/action_jump_land.mp3",
		["volume"] = 0.9,
		["speed"] = 0.8
	},
	["Footstep"] = {
		["id"] = "rbxasset://sounds/action_footsteps_plastic.mp3",
		["volume"] = 0.25
	},
	["Slide"] = {
		["id"] = "rbxasset://sounds/action_falling.mp3",
		["volume"] = 0.3,
		["speed"] = 1.6
	}
}
local v_u_8 = nil
local v_u_9 = (-1 / 0)
local v_u_10 = false
local function v_u_17() -- name: getSfx
	-- upvalues: (ref) v_u_8, (ref) v_u_10, (ref) v_u_9, (copy) v_u_2
	if v_u_8 or v_u_10 then
		return v_u_8
	end
	local v11 = os.clock()
	if v11 - v_u_9 < 5 then
		return nil
	end
	v_u_9 = v11
	local v12 = v_u_2:FindFirstChild("Shared")
	if v12 then
		v12 = v12:FindFirstChild("Sfx")
	end
	if not (v12 and v12:IsA("ModuleScript")) then
		return v_u_8
	end
	local v13 = require
	local v14, v15 = pcall(v13, v12)
	if v14 and type(v15) == "table" then
		local v16 = v15.Play
		if type(v16) == "function" then
			v_u_8 = v15
			return v_u_8
		end
		v_u_10 = true
		warn("[Character] Shared.Sfx failed to load; playing character sounds locally")
	else
		v_u_10 = true
		warn("[Character] Shared.Sfx failed to load; playing character sounds locally")
	end
	return v_u_8
end
function v_u_6.Group(p18) -- name: Group
	-- upvalues: (copy) v_u_3
	local v19 = v_u_3:FindFirstChild(p18)
	if v19 and v19:IsA("SoundGroup") then
		return v19
	else
		return nil
	end
end
local function v_u_27(p20) -- name: pickTemplate
	-- upvalues: (copy) v_u_2
	local v21 = v_u_2:FindFirstChild("Assets")
	if v21 then
		v21 = v21:FindFirstChild("Sounds")
	end
	if v21 then
		v21 = v21:FindFirstChild("Character")
	end
	if v21 then
		v21 = v21:FindFirstChild(p20)
	end
	if not v21 then
		return nil, nil
	end
	if v21:IsA("Sound") then
		return v21, "Character/" .. p20
	end
	local v22 = v21:GetChildren()
	local v23 = #v22
	if v23 == 0 then
		return nil, nil
	end
	local v24 = math.random(1, v23)
	for v25 = 0, v23 - 1 do
		local v26 = v22[(v24 + v25 - 1) % v23 + 1]
		if not v26:IsA("Sound") then
			continue
		end
		return v26, "Character/" .. p20 .. "/" .. v26.Name
	end
	return nil, nil
end
function v_u_6.MakeSound(p28) -- name: MakeSound
	-- upvalues: (copy) v_u_27, (copy) v_u_7, (copy) v_u_6
	local v29 = v_u_27(p28)
	local v30
	if v29 then
		v30 = v29:Clone()
	else
		local v31 = v_u_7[p28]
		if not v31 then
			return nil
		end
		v30 = Instance.new("Sound")
		v30.Name = p28
		v30.SoundId = v31.id
		v30.Volume = v31.volume
		v30.PlaybackSpeed = v31.speed or 1
	end
	v30.SoundGroup = v30.SoundGroup or v_u_6.Group("SFX")
	return v30
end
local function v_u_37(p32, p33, p34, p35) -- name: playLocal
	-- upvalues: (copy) v_u_6, (copy) v_u_3, (copy) v_u_1
	local v_u_36 = v_u_6.MakeSound(p32)
	if not v_u_36 then
		return nil
	end
	v_u_36.Volume = v_u_36.Volume * (p34.volume or 1)
	v_u_36.PlaybackSpeed = v_u_36.PlaybackSpeed * p35
	if p34.maxDistance then
		v_u_36.RollOffMaxDistance = p34.maxDistance
	end
	v_u_36.Looped = p34.looped == true
	v_u_36.Parent = p33 or v_u_3
	v_u_36:Play()
	if not v_u_36.Looped then
		v_u_36.Ended:Once(function()
			-- upvalues: (copy) v_u_36
			v_u_36:Destroy()
		end)
		v_u_1:AddItem(v_u_36, 10)
	end
	return v_u_36
end
local function v_u_49(p38, p39, p40, p41) -- name: viaSfx
	-- upvalues: (copy) v_u_17, (copy) v_u_2
	local v42 = v_u_17()
	local v43
	if v42 then
		local v44 = v_u_2:FindFirstChild("Assets")
		if v44 then
			v44 = v44:FindFirstChild("Sounds")
		end
		if v44 then
			v44 = v44:FindFirstChild("Character")
		end
		if v44 and v44:FindFirstChild(p38) then
			v43 = "Character/" .. p38
		else
			v43 = nil
		end
	else
		v43 = v42
	end
	if not (v42 and v43) then
		return false, nil
	end
	local v45 = v42.Play
	local v46 = {
		["volume"] = p40.volume or 1,
		["pitch"] = p41
	}
	local v47, v48 = pcall(v45, v43, p39, v46)
	return v47, v48
end
local function v_u_61(p50, p51, p52, p53) -- name: loopViaSfx
	-- upvalues: (copy) v_u_17, (copy) v_u_2
	local v54 = v_u_17()
	local v55
	if v54 then
		local v56 = v_u_2:FindFirstChild("Assets")
		if v56 then
			v56 = v56:FindFirstChild("Sounds")
		end
		if v56 then
			v56 = v56:FindFirstChild("Character")
		end
		if v56 and v56:FindFirstChild(p50) then
			v55 = "Character/" .. p50
		else
			v55 = nil
		end
	else
		v55 = v54
	end
	if v54 and v55 then
		local v57 = v54.Loop
		if type(v57) == "function" then
			local v58 = v54.Loop
			local v59, _, v60 = pcall(v58, v55, p51)
			if not v59 or (typeof(v60) ~= "Instance" or not v60:IsA("Sound")) then
				return nil
			end
			v60.Volume = v60.Volume * (p52.volume or 1)
			v60.PlaybackSpeed = v60.PlaybackSpeed * p53
			return v60
		end
	end
	return nil
end
function v_u_6.PlaySound(p62, p63, p64) -- name: PlaySound
	-- upvalues: (copy) v_u_61, (copy) v_u_49, (copy) v_u_37
	local v65 = p64 or {}
	local v66 = v65.speed or 1
	if v65.pitchVar then
		v66 = v66 * (1 + (math.random() * 2 - 1) * v65.pitchVar)
	end
	if v65.looped then
		local v67 = v_u_61(p62, p63, v65, v66)
		if v67 then
			return v67
		end
	else
		local v68, v69 = v_u_49(p62, p63, v65, v66)
		if v68 then
			if typeof(v69) == "Instance" and v69:IsA("Sound") then
				return v69
			else
				return nil
			end
		end
	end
	return v_u_37(p62, p63, v65, v66)
end
function v_u_6.PlaySoundAt(p70, p71, p72) -- name: PlaySoundAt
	-- upvalues: (copy) v_u_49, (copy) v_u_4, (copy) v_u_1, (copy) v_u_37
	local v73 = p72 or {}
	local v74 = v73.speed or 1
	if v73.pitchVar then
		v74 = v74 * (1 + (math.random() * 2 - 1) * v73.pitchVar)
	end
	local v75, v76 = v_u_49(p70, p71, v73, v74)
	if v75 then
		if typeof(v76) == "Instance" and v76:IsA("Sound") then
			return v76
		else
			return nil
		end
	else
		local v77 = Instance.new("Attachment")
		v77.WorldPosition = p71
		v77.Parent = v_u_4.Terrain
		v_u_1:AddItem(v77, 4)
		return v_u_37(p70, v77, v73, v74)
	end
end
local v_u_78 = nil
local function v_u_82(p79, p80) -- name: makeDustEmitter
	local v81 = Instance.new("ParticleEmitter")
	v81.Texture = "rbxasset://textures/particles/smoke_main.dds"
	v81.LightEmission = 0
	v81.LightInfluence = 1
	v81.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.35), NumberSequenceKeypoint.new(0.6, 0.7), NumberSequenceKeypoint.new(1, 1) })
	v81.Lifetime = NumberRange.new(0.45, 0.8)
	v81.Rotation = NumberRange.new(0, 360)
	v81.RotSpeed = NumberRange.new(-60, 60)
	v81.Drag = 6
	v81.SpreadAngle = Vector2.new(180, 8)
	v81.Acceleration = Vector3.new(0, 3, 0)
	v81.Shape = Enum.ParticleEmitterShape.Disc
	v81.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
	v81.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
	v81.Enabled = false
	v81.Color = ColorSequence.new(p79 or Color3.fromRGB(214, 200, 176))
	v81.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p80 * 0.6), NumberSequenceKeypoint.new(1, p80 * 2.2) })
	v81.Speed = NumberRange.new(p80 * 6, p80 * 11)
	v81.Orientation = Enum.ParticleOrientation.FacingCamera
	return v81
end
function v_u_6.Dust(p83, p84, p85) -- name: Dust
	-- upvalues: (ref) v_u_78, (copy) v_u_4, (copy) v_u_82, (copy) v_u_5, (copy) v_u_1
	local v86 = Instance.new("Part")
	v86.Anchored = true
	v86.CanCollide = false
	v86.CanQuery = false
	v86.CanTouch = false
	v86.Transparency = 1
	v86.Size = Vector3.new(0.2, 0.2, 0.2)
	v86.CFrame = CFrame.new(p83)
	local v87
	if v_u_78 and v_u_78.Parent then
		v87 = v_u_78
	else
		v87 = Instance.new("Folder")
		v87.Name = "CharacterFX"
		v87.Parent = v_u_4.CurrentCamera
		v_u_78 = v87
	end
	v86.Parent = v87
	local v88 = v_u_82(p85, p84)
	v88.Parent = v86
	local v89 = p84 * 8 * v_u_5.budget.dustScale
	local v90 = math.floor(v89)
	v88:Emit((math.clamp(v90, 2, 30)))
	v_u_1:AddItem(v86, 2)
end
function v_u_6.Trail(p91, p92) -- name: Trail
	-- upvalues: (copy) v_u_82, (copy) v_u_5
	local v93 = v_u_82(p92, 0.55)
	v93.SpreadAngle = Vector2.new(35, 35)
	v93.EmissionDirection = Enum.NormalId.Top
	v93.Shape = Enum.ParticleEmitterShape.Box
	v93.Speed = NumberRange.new(2, 5)
	v93.Lifetime = NumberRange.new(0.35, 0.6)
	v93.Rate = 34 * v_u_5.budget.dustScale
	v93.Enabled = true
	v93.Parent = p91
	return v93
end
local v_u_94 = {
	[Enum.Material.Grass] = Color3.fromRGB(150, 175, 110),
	[Enum.Material.LeafyGrass] = Color3.fromRGB(150, 175, 110),
	[Enum.Material.Salt] = Color3.fromRGB(150, 175, 110),
	[Enum.Material.Basalt] = Color3.fromRGB(170, 140, 105),
	[Enum.Material.Sand] = Color3.fromRGB(226, 206, 158),
	[Enum.Material.Snow] = Color3.fromRGB(218, 224, 232),
	[Enum.Material.Mud] = Color3.fromRGB(120, 95, 70),
	[Enum.Material.Ground] = Color3.fromRGB(170, 140, 105),
	[Enum.Material.Water] = Color3.fromRGB(186, 208, 230),
	[Enum.Material.Wood] = Color3.fromRGB(176, 150, 118),
	[Enum.Material.WoodPlanks] = Color3.fromRGB(176, 150, 118)
}
function v_u_6.DustColor(p95) -- name: DustColor
	-- upvalues: (copy) v_u_94
	return p95 and v_u_94[p95] or Color3.fromRGB(196, 186, 170)
end
return v_u_6