local v_u_1 = game:GetService("Lighting")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("RunService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game:GetService("Workspace")
local v7 = require(v_u_3.Shared.Config)
local v_u_8 = require(v_u_3.Shared.UIAssets)
local v9 = require(script.Parent.Parent.UI.Theme)
local v_u_10 = v7.UPDATE_COUNTDOWN
if v_u_10 then
	local v_u_11 = nil
	local function v12()
		-- upvalues: (ref) v_u_11, (copy) v_u_3
		v_u_11 = require(v_u_3.Shared.Sfx)
	end
	pcall(v12)
	local v_u_13 = v9.Colors
	local v_u_14 = Color3.fromRGB
	local v_u_15 = v_u_10.skyHours * 3600
	local v_u_16 = v_u_10.goldenHours * 3600
	local v_u_17 = v_u_13.Gold
	local v_u_18 = v_u_14(12, 16, 30)
	local v19 = Font.new("rbxasset://fonts/families/Montserrat.json", Enum.FontWeight.Heavy)
	local v20 = Font.new("rbxasset://fonts/families/Montserrat.json", Enum.FontWeight.ExtraBold)
	local v_u_21 = v2.LocalPlayer
	local v22 = v_u_6.CurrentCamera
	local v23 = os.clock()
	local v_u_24 = v_u_11
	while v_u_21:GetAttribute("LoadingShownMs") == nil and os.clock() - v23 < 30 do
		task.wait(0.2)
	end
	if not v_u_10.shipped or (not v_u_3.Shared:FindFirstChild(v_u_10.shipped) or (v_u_6:GetAttribute("CountdownPreview") ~= nil or v_u_6:GetAttribute("CountdownPreviewAt") ~= nil)) then
		local v_u_25 = Instance.new("Part")
		v_u_25.Name = "UpdateCountdownSky"
		v_u_25.Anchored = true
		v_u_25.CanCollide = false
		v_u_25.CanQuery = false
		v_u_25.CanTouch = false
		v_u_25.CastShadow = false
		v_u_25.Transparency = 1
		v_u_25.Size = Vector3.new(357, 64, 0.2)
		v_u_25.CFrame = CFrame.lookAt(Vector3.new(0, 66, -135), Vector3.new(0, 9, 120))
		v_u_25.Parent = v_u_6
		local v_u_26 = Instance.new("SurfaceGui")
		v_u_26.Name = "UpdateCountdown"
		v_u_26.Adornee = v_u_25
		v_u_26.Face = Enum.NormalId.Front
		v_u_26.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
		v_u_26.PixelsPerStud = 3.361344537815126
		v_u_26.LightInfluence = 0
		v_u_26.Brightness = 1.25
		v_u_26.MaxDistance = 2000
		v_u_26.ResetOnSpawn = false
		v_u_26.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		local v_u_27 = Instance.new("Frame")
		v_u_27.Name = "Root"
		v_u_27.BackgroundTransparency = 1
		v_u_27.Size = UDim2.fromScale(1, 1)
		v_u_27.Parent = v_u_26
		local function v46(p28, p29, p30, p31, p32, p_u_33, p34, p35) -- name: text
			-- upvalues: (copy) v_u_27, (copy) v_u_18, (copy) v_u_13
			local v_u_36 = Instance.new("Frame")
			v_u_36.Name = p28
			v_u_36.BackgroundTransparency = 1
			v_u_36.AnchorPoint = Vector2.new(0.5, 0.5)
			v_u_36.Position = UDim2.fromOffset(p29, p30)
			v_u_36.Size = UDim2.fromOffset(p31, p32)
			v_u_36.Parent = p35 or v_u_27
			local v37 = Instance.new("UIScale")
			v37.Parent = v_u_36
			local function v44(p38, p39, p40, p41, p42) -- name: mk
				-- upvalues: (copy) p_u_33, (copy) v_u_36
				local v43 = Instance.new("TextLabel")
				v43.Name = p38
				v43.BackgroundTransparency = 1
				v43.TextScaled = true
				v43.FontFace = p_u_33
				v43.TextColor3 = p40
				v43.TextTransparency = p41
				v43.Position = UDim2.fromOffset(0, p39)
				v43.Size = UDim2.fromScale(1, 1)
				v43.Text = ""
				v43.ZIndex = p42
				v43.Parent = v_u_36
				return v43
			end
			local v45 = v44("Shadow", p34, v_u_18, 0.45, 1)
			return {
				["label"] = v44("Text", 0, v_u_13.White, 0, 2),
				["shadow"] = v45,
				["holder"] = v_u_36,
				["scale"] = v37
			}
		end
		local v47 = Instance.new("ImageLabel")
		v47.Name = "Plate"
		v47.BackgroundTransparency = 1
		v47.Image = "rbxassetid://90962482350826"
		v47.ImageColor3 = v_u_18
		v47.ImageTransparency = 0.3
		v47.ScaleType = Enum.ScaleType.Stretch
		v47.AnchorPoint = Vector2.new(0.5, 0.5)
		v47.Position = UDim2.fromOffset(600, 112)
		v47.Size = UDim2.fromOffset(1240, 300)
		v47.Parent = v_u_27
		local v_u_48 = v46("Title", 600, 82, 1000, 84, v19, 4)
		v_u_48.label.Text = v_u_10.title
		v_u_48.shadow.Text = v_u_10.title
		local v_u_49 = v46("Timer", 600, 168, 480, 74, v19, 4)
		local v_u_50 = v46("When", 600, 22, 600, 24, v20, 2)
		local v_u_51 = v_u_25:Clone()
		v_u_51.Name = "UpdateCountdownSkyBig"
		v_u_51.CFrame = v_u_25.CFrame * CFrame.new(0, 0, -0.3)
		v_u_51.Parent = v_u_6
		local v_u_52 = v_u_26:Clone()
		v_u_52.Name = "UpdateCountdownBig"
		v_u_52.Adornee = v_u_51
		v_u_52.PixelsPerStud = 1.680672268907563
		v_u_52:ClearAllChildren()
		local v53 = Instance.new("Frame")
		v53.Name = "Root"
		v53.BackgroundTransparency = 1
		v53.Size = UDim2.fromScale(1, 1)
		v53.Parent = v_u_52
		local v_u_54 = v46("Big", 300, 62, 560, 84, v19, 4, v53)
		v_u_54.holder.Visible = false
		local v55 = #v_u_10.ranks / 2
		local v56 = math.ceil(v55)
		local v_u_57 = {}
		local v_u_58 = { v_u_48, v_u_49, v_u_50 }
		for v59, v60 in v_u_10.ranks do
			local v61
			if v59 <= v56 then
				v61 = 310 - (v56 - v59) * 74
			else
				v61 = 890 + (v59 - v56 - 1) * 74
			end
			local v62 = Instance.new("Frame")
			v62.Name = v60.name
			v62.BackgroundTransparency = 1
			v62.AnchorPoint = Vector2.new(0.5, 0.5)
			v62.Position = UDim2.fromOffset(v61, 168)
			v62.Size = UDim2.fromOffset(62, 62)
			v62.Parent = v_u_27
			local v63 = Instance.new("ImageLabel")
			v63.Name = "Emblem"
			v63.BackgroundTransparency = 1
			local v64 = v_u_8.Ranks
			v63.Image = v64 and v64[string.lower(v60.name)] or (v60.img or "")
			v63.ScaleType = Enum.ScaleType.Fit
			v63.Size = UDim2.fromScale(1, 1)
			v63.Parent = v62
			local v65 = Instance.new("UIScale")
			v65.Parent = v62
			table.insert(v_u_57, {
				["cell"] = v62,
				["img"] = v63,
				["scale"] = v65
			})
		end
		local v_u_66 = Instance.new("Frame")
		v_u_66.Name = "Hero"
		v_u_66.BackgroundTransparency = 1
		v_u_66.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_66.Position = UDim2.fromOffset(640, 120)
		v_u_66.Size = UDim2.fromOffset(620, 210)
		v_u_66.Visible = false
		v_u_66.ZIndex = 3
		v_u_66.Parent = v_u_27
		local v_u_67 = Instance.new("UIScale")
		v_u_67.Parent = v_u_66
		local v_u_68 = Instance.new("ImageLabel")
		v_u_68.Name = "Glow"
		v_u_68.BackgroundTransparency = 1
		v_u_68.Image = "rbxassetid://90962482350826"
		v_u_68.ImageTransparency = 1
		v_u_68.ScaleType = Enum.ScaleType.Stretch
		v_u_68.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_68.Position = UDim2.fromOffset(100, 105)
		v_u_68.Size = UDim2.fromOffset(300, 300)
		v_u_68.Parent = v_u_66
		local v_u_69 = Instance.new("UIScale")
		v_u_69.Parent = v_u_68
		local v_u_70 = Instance.new("ImageLabel")
		v_u_70.Name = "Emblem"
		v_u_70.BackgroundTransparency = 1
		v_u_70.ScaleType = Enum.ScaleType.Fit
		v_u_70.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_70.Position = UDim2.fromOffset(100, 105)
		v_u_70.Size = UDim2.fromOffset(180, 180)
		v_u_70.ZIndex = 4
		v_u_70.Parent = v_u_66
		local v_u_71 = v46("Kicker", 370, 66, 320, 30, v20, 2, v_u_66)
		local v_u_72 = v46("HeroName", 370, 124, 320, 80, v19, 4, v_u_66)
		for _, v73 in { v_u_71, v_u_72 } do
			v73.label.TextXAlignment = Enum.TextXAlignment.Left
			v73.shadow.TextXAlignment = Enum.TextXAlignment.Left
			v73.label.ZIndex = 5
			v73.shadow.ZIndex = 4
		end
		v_u_71.label.Text = "NEW RANK REVEALED"
		v_u_71.shadow.Text = "NEW RANK REVEALED"
		v_u_71.label.TextColor3 = v_u_17
		local v_u_74 = Instance.new("ImageLabel")
		v_u_74.Name = "Flyer"
		v_u_74.BackgroundTransparency = 1
		v_u_74.ScaleType = Enum.ScaleType.Fit
		v_u_74.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_74.Visible = false
		v_u_74.ZIndex = 6
		v_u_74.Parent = v_u_27
		v_u_26.Parent = v_u_21:WaitForChild("PlayerGui")
		v_u_52.Parent = v_u_21:WaitForChild("PlayerGui")
		local v_u_75 = Instance.new("ScreenGui")
		v_u_75.Name = "UpdateCountdownBanner"
		v_u_75.ResetOnSpawn = false
		v_u_75.DisplayOrder = 30
		v_u_75.IgnoreGuiInset = false
		v_u_75.Parent = v_u_21:WaitForChild("PlayerGui")
		local v_u_76 = Instance.new("Frame")
		v_u_76.Name = "Banner"
		v_u_76.AnchorPoint = Vector2.new(0.5, 1)
		v_u_76.Position = UDim2.new(0.5, 0, 0, -10)
		v_u_76.Size = UDim2.fromOffset(420, 92)
		v_u_76.BackgroundColor3 = v_u_14(14, 17, 24)
		v_u_76.BackgroundTransparency = 0.08
		v_u_76.Visible = false
		v_u_76.Parent = v_u_75
		local v77 = Instance.new("UICorner")
		v77.CornerRadius = UDim.new(0, 14)
		v77.Parent = v_u_76
		local v78 = Instance.new("UIStroke")
		v78.Thickness = 2
		v78.Color = v_u_17
		v78.Transparency = 0.25
		v78.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v78.Parent = v_u_76
		local v_u_79 = Instance.new("ImageLabel")
		v_u_79.BackgroundTransparency = 1
		v_u_79.ScaleType = Enum.ScaleType.Fit
		v_u_79.Position = UDim2.fromOffset(12, 10)
		v_u_79.Size = UDim2.fromOffset(72, 72)
		v_u_79.Parent = v_u_76
		local v80 = Instance.new("TextLabel")
		v80.BackgroundTransparency = 1
		v80.Position = UDim2.fromOffset(98, 14)
		v80.Size = UDim2.new(1, -110, 0, 22)
		v80.FontFace = v20
		v80.TextSize = 17
		v80.TextColor3 = v_u_17
		v80.TextXAlignment = Enum.TextXAlignment.Left
		v80.Text = "NEW RANK REVEALED"
		v80.Parent = v_u_76
		local v_u_81 = Instance.new("TextLabel")
		v_u_81.BackgroundTransparency = 1
		v_u_81.Position = UDim2.fromOffset(98, 38)
		v_u_81.Size = UDim2.new(1, -110, 0, 40)
		v_u_81.FontFace = v19
		v_u_81.TextScaled = true
		v_u_81.TextColor3 = v_u_13.White
		v_u_81.TextXAlignment = Enum.TextXAlignment.Left
		v_u_81.Parent = v_u_76
		local v_u_82 = 0
		local function v_u_88(p83) -- name: showBanner
			-- upvalues: (ref) v_u_82, (copy) v_u_79, (copy) v_u_8, (copy) v_u_81, (copy) v_u_76, (copy) v_u_5
			v_u_82 = v_u_82 + 1
			local v_u_84 = v_u_82
			local v85 = v_u_79
			local v86 = v_u_8.Ranks
			v85.Image = v86 and v86[string.lower(p83.name)] or (p83.img or "")
			v_u_81.Text = p83.name
			v_u_76.Position = UDim2.new(0.5, 0, 0, -10)
			v_u_76.Visible = true
			v_u_5:Create(v_u_76, TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				["Position"] = UDim2.new(0.5, 0, 0, 110)
			}):Play()
			task.delay(4.2, function()
				-- upvalues: (ref) v_u_82, (copy) v_u_84, (ref) v_u_5, (ref) v_u_76
				if v_u_82 == v_u_84 then
					local v87 = v_u_5:Create(v_u_76, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["Position"] = UDim2.new(0.5, 0, 0, -10)
					})
					v87.Completed:Once(function()
						-- upvalues: (ref) v_u_82, (ref) v_u_84, (ref) v_u_76
						if v_u_82 == v_u_84 then
							v_u_76.Visible = false
						end
					end)
					v87:Play()
				end
			end)
		end
		local v_u_89 = Instance.new("Folder")
		v_u_89.Name = "UpdateCountdownFx"
		v_u_89.Parent = v_u_6
		local v_u_90 = Random.new()
		local v_u_91 = v_u_25.CFrame.RightVector
		local v_u_92 = v_u_25.CFrame.UpVector
		local v_u_93 = -v_u_25.CFrame.LookVector
		local v_u_94 = {}
		local function v_u_102(p_u_95, p96, p97, p_u_98) -- name: fwSound
			-- upvalues: (ref) v_u_24, (copy) v_u_94, (copy) v_u_90
			if v_u_24 and os.clock() - (v_u_94[p_u_95] or 0) >= p96 then
				v_u_94[p_u_95] = os.clock()
				task.delay(p97, function()
					-- upvalues: (ref) v_u_24, (copy) p_u_95, (copy) p_u_98, (ref) v_u_90
					local v99 = v_u_24.Play
					local v100 = p_u_95
					local v101 = {
						["volume"] = p_u_98,
						["pitch"] = v_u_90:NextNumber(0.94, 1.06)
					}
					pcall(v99, v100, nil, v101)
				end)
			end
		end
		local function v_u_117(p103, p_u_104, p105) -- name: burst
			-- upvalues: (copy) v_u_89, (copy) v_u_13
			local v_u_106 = Instance.new("Part")
			v_u_106.Anchored = true
			v_u_106.CanCollide = false
			v_u_106.CanQuery = false
			v_u_106.CanTouch = false
			v_u_106.Transparency = 1
			v_u_106.Size = Vector3.new(1, 1, 1)
			v_u_106.CFrame = CFrame.new(p103)
			v_u_106.Parent = v_u_89
			local function v114(p107, p108, p109, p110, p111, p112) -- name: emitter
				-- upvalues: (copy) p_u_104, (copy) v_u_106
				local v113 = Instance.new("ParticleEmitter")
				v113.Texture = "rbxasset://textures/particles/sparkles_main.dds"
				v113.LightEmission = 1
				v113.LightInfluence = 0
				v113.Brightness = p112
				v113.Color = ColorSequence.new(p111, p_u_104)
				v113.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p108), NumberSequenceKeypoint.new(0.7, p108 * 0.6), NumberSequenceKeypoint.new(1, 0) })
				v113.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.75, 0.15), NumberSequenceKeypoint.new(1, 1) })
				v113.Lifetime = NumberRange.new(p110 * 0.75, p110)
				v113.Speed = NumberRange.new(p109 * 0.8, p109)
				v113.SpreadAngle = Vector2.new(180, 180)
				v113.Acceleration = Vector3.new(0, -22, 0)
				v113.Drag = 1.6
				v113.Rate = 0
				v113.RotSpeed = NumberRange.new(-180, 180)
				v113.Parent = v_u_106
				v113:Emit(p107)
			end
			local v115 = p105 * 120
			v114(math.floor(v115), p105 * 8, p105 * 72, 2, p_u_104:Lerp(v_u_13.White, 0.1), 3)
			local v116 = p105 * 26
			v114(math.floor(v116), p105 * 4, p105 * 36, 2.6, p_u_104:Lerp(v_u_13.White, 0.6), 2)
			task.delay(4, function()
				-- upvalues: (copy) v_u_106
				v_u_106:Destroy()
			end)
		end
		local function v_u_129(p_u_118, p_u_119, p_u_120) -- name: rocket
			-- upvalues: (copy) v_u_90, (copy) v_u_13, (copy) v_u_89, (copy) v_u_5, (copy) v_u_117, (copy) v_u_102
			local v121 = p_u_118.X + v_u_90:NextNumber(-20, 20)
			local v122 = p_u_118.Z + v_u_90:NextNumber(-10, 10)
			local v123 = Vector3.new(v121, 30, v122)
			local v_u_124 = Instance.new("Part")
			v_u_124.Anchored = true
			v_u_124.CanCollide = false
			v_u_124.CanQuery = false
			v_u_124.CanTouch = false
			v_u_124.CastShadow = false
			v_u_124.Material = Enum.Material.Neon
			v_u_124.Color = p_u_119:Lerp(v_u_13.White, 0.5)
			v_u_124.Size = Vector3.new(1.6, 1.6, 1.6)
			v_u_124.Shape = Enum.PartType.Ball
			v_u_124.CFrame = CFrame.new(v123)
			local v125 = Instance.new("Attachment")
			v125.Position = Vector3.new(0, 0.8, 0)
			v125.Parent = v_u_124
			local v126 = Instance.new("Attachment")
			v126.Position = Vector3.new(0, -0.8, 0)
			v126.Parent = v_u_124
			local v127 = Instance.new("Trail")
			v127.Attachment0 = v125
			v127.Attachment1 = v126
			v127.Lifetime = 0.45
			v127.LightEmission = 1
			v127.FaceCamera = true
			v127.Color = ColorSequence.new(p_u_119:Lerp(v_u_13.White, 0.6), p_u_119)
			v127.Transparency = NumberSequence.new(0, 1)
			v127.WidthScale = NumberSequence.new(1, 0)
			v127.Parent = v_u_124
			v_u_124.Parent = v_u_89
			local v128 = v_u_5:Create(v_u_124, TweenInfo.new(0.85, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["CFrame"] = CFrame.new(p_u_118)
			})
			v128.Completed:Once(function()
				-- upvalues: (copy) v_u_124, (ref) v_u_117, (copy) p_u_118, (copy) p_u_119, (copy) p_u_120, (ref) v_u_102
				v_u_124.Transparency = 1
				v_u_117(p_u_118, p_u_119, p_u_120)
				v_u_102("Firework/Explode", 0.25, 0.15, 1)
				v_u_102("Firework/Crackle", 0.6, 0.45, 1)
				task.delay(0.6, function()
					-- upvalues: (ref) v_u_124
					v_u_124:Destroy()
				end)
			end)
			v128:Play()
		end
		local v_u_130 = {
			v_u_14(255, 204, 64),
			v_u_14(255, 92, 92),
			v_u_14(86, 202, 255),
			v_u_14(186, 116, 255),
			v_u_14(120, 236, 150),
			v_u_14(255, 150, 80)
		}
		local function v_u_141(p131, p132, p_u_133, p_u_134) -- name: volley
			-- upvalues: (copy) v_u_90, (copy) v_u_21, (copy) v_u_129, (copy) v_u_91, (copy) v_u_92, (copy) v_u_93, (copy) v_u_130
			for v_u_135 = 1, p131 do
				local v136 = task.delay
				local v137 = v_u_135 - 1
				local v138 = p131 - 1
				v136(v137 / math.max(1, v138) * p132 + v_u_90:NextNumber(0, 0.15), function()
					-- upvalues: (ref) v_u_21, (copy) v_u_135, (ref) v_u_90, (ref) v_u_129, (ref) v_u_91, (ref) v_u_92, (ref) v_u_93, (copy) p_u_133, (ref) v_u_130, (copy) p_u_134
					if v_u_21:GetAttribute("State") ~= "Match" then
						local v139 = (v_u_135 % 2 == 0 and 1 or -1) * v_u_90:NextNumber(150, 260)
						local v140 = v_u_90:NextNumber(10, 80)
						if v_u_135 % 3 == 0 then
							v139 = v_u_90:NextNumber(-140, 140)
							v140 = v_u_90:NextNumber(70, 110)
						end
						v_u_129(Vector3.new(0, 66, -135) + v_u_91 * v139 + v_u_92 * v140 + v_u_93 * 30, p_u_133 or v_u_130[v_u_90:NextInteger(1, #v_u_130)], p_u_134)
					end
				end)
			end
		end
		local v142 = v_u_3:FindFirstChild("Lighting")
		if v142 then
			v142 = v142:FindFirstChild("Lobby")
		end
		local v143
		if v142 then
			v143 = v142:FindFirstChildOfClass("Atmosphere")
		else
			v143 = v142
		end
		local v_u_144 = {}
		if v142 then
			local v145 = v142:GetAttribute("ClockTime")
		end
		v_u_144.clock = v145 == nil and 16.3 or v145
		local v146 = v_u_14(214, 184, 140)
		local v147
		if v142 then
			v147 = v142:GetAttribute("ColorShift_Top")
		else
			v147 = v142
		end
		if v147 ~= nil then
			v146 = v147
		end
		v_u_144.shiftTop = v146
		if v142 then
			local v148 = v142:GetAttribute("Brightness")
		end
		v_u_144.brightness = v148 == nil and 2.5 or v148
		local v149 = v_u_14(136, 128, 126)
		local v150
		if v142 then
			v150 = v142:GetAttribute("OutdoorAmbient")
		else
			v150 = v142
		end
		if v150 ~= nil then
			v149 = v150
		end
		v_u_144.outdoor = v149
		local v151
		if v143 then
			v151 = v143.Color
		else
			v151 = v_u_14(224, 210, 190)
		end
		v_u_144.atmColor = v151
		local v152
		if v143 then
			v152 = v143.Decay
		else
			v152 = v_u_14(170, 160, 178)
		end
		v_u_144.atmDecay = v152
		v_u_144.atmHaze = not v143 and 1.2 or v143.Haze
		v_u_144.atmDensity = not v143 and 0.24 or v143.Density
		v_u_144.atmGlare = not v143 and 0.08 or v143.Glare
		if v142 then
			v142 = v142:FindFirstChildOfClass("SunRaysEffect")
		end
		v_u_144.rays = not v142 and 0.035 or v142.Intensity
		local v_u_153 = {
			["clock"] = 17.35,
			["shiftTop"] = nil,
			["atmColor"] = nil,
			["atmDecay"] = nil,
			["haze"] = 1.6,
			["density"] = 0.27,
			["glare"] = 2.2,
			["bright"] = 2.9,
			["outdoor"] = nil,
			["rays"] = 0.14,
			["shiftTop"] = v_u_14(255, 176, 110),
			["atmColor"] = v_u_14(255, 178, 130),
			["atmDecay"] = v_u_14(232, 128, 140),
			["outdoor"] = v_u_14(170, 132, 118)
		}
		local v_u_154 = {
			["clock"] = 17.62,
			["shiftTop"] = nil,
			["atmColor"] = nil,
			["atmDecay"] = nil,
			["haze"] = 1.9,
			["density"] = 0.29,
			["glare"] = 3,
			["bright"] = 2.6,
			["outdoor"] = nil,
			["rays"] = 0.2,
			["shiftTop"] = v_u_14(255, 140, 100),
			["atmColor"] = v_u_14(255, 150, 120),
			["atmDecay"] = v_u_14(196, 98, 150),
			["outdoor"] = v_u_14(156, 112, 128)
		}
		local v_u_155 = Instance.new("ColorCorrectionEffect")
		v_u_155.Name = "UpdateCountdownGrade"
		v_u_155.Enabled = false
		v_u_155.Parent = v22
		local v_u_156 = nil
		local function v157()
			-- upvalues: (ref) v_u_156
			v_u_156 = require(script.Parent.Parent.Core.LightingController)
		end
		pcall(v157)
		local v_u_158 = {
			["w"] = 0,
			["d"] = 0
		}
		local v_u_159 = false
		local function v_u_234(p160, p161) -- name: paintSky
			-- upvalues: (copy) v_u_21, (ref) v_u_156, (copy) v_u_155, (ref) v_u_159, (copy) v_u_1, (copy) v_u_144, (copy) v_u_153, (copy) v_u_154, (copy) v_u_13, (copy) v_u_14
			if v_u_21:GetAttribute("State") ~= "Match" then
				local v162
				if v_u_156 then
					local v163 = v_u_156.Current
					local v164
					v162, v164 = pcall(v163)
					if v162 then
						v162 = v164 == "Lobby"
					end
				else
					v162 = true
				end
				if v162 then
					if p160 <= 0.001 and p161 <= 0.001 then
						if v_u_159 then
							v_u_1.ClockTime = v_u_144.clock
							v_u_1.ColorShift_Top = v_u_144.shiftTop
							v_u_1.Brightness = v_u_144.brightness
							v_u_1.OutdoorAmbient = v_u_144.outdoor
							local v165 = v_u_1:FindFirstChildOfClass("Atmosphere")
							if v165 then
								local v166 = v_u_144.atmColor
								local v167 = v_u_144.atmDecay
								local v168 = v_u_144.atmHaze
								local v169 = v_u_144.atmDensity
								local v170 = v_u_144.atmGlare
								v165.Color = v166
								v165.Decay = v167
								v165.Haze = v168
								v165.Density = v169
								v165.Glare = v170
							end
							local v171 = v_u_1:FindFirstChildOfClass("SunRaysEffect")
							if v171 then
								v171.Intensity = v_u_144.rays
							end
							v_u_159 = false
						end
						v_u_155.Enabled = false
					else
						v_u_159 = true
						local v172 = v_u_1
						local v173 = v_u_144.clock
						local v174 = v_u_153.clock
						local v175 = v_u_154.clock
						local v176
						if typeof(v173) == "Color3" then
							v176 = v173:Lerp(v174, p160):Lerp(v175, p161)
						else
							local v177 = v173 + (v174 - v173) * p160
							v176 = v177 + (v175 - v177) * p161
						end
						v172.ClockTime = v176
						local v178 = v_u_1
						local v179 = v_u_144.shiftTop
						local v180 = v_u_153.shiftTop
						local v181 = v_u_154.shiftTop
						local v182
						if typeof(v179) == "Color3" then
							v182 = v179:Lerp(v180, p160):Lerp(v181, p161)
						else
							local v183 = v179 + (v180 - v179) * p160
							v182 = v183 + (v181 - v183) * p161
						end
						v178.ColorShift_Top = v182
						local v184 = v_u_1
						local v185 = v_u_144.brightness
						local v186 = v_u_153.bright
						local v187 = v_u_154.bright
						local v188
						if typeof(v185) == "Color3" then
							v188 = v185:Lerp(v186, p160):Lerp(v187, p161)
						else
							local v189 = v185 + (v186 - v185) * p160
							v188 = v189 + (v187 - v189) * p161
						end
						v184.Brightness = v188
						local v190 = v_u_1
						local v191 = v_u_144.outdoor
						local v192 = v_u_153.outdoor
						local v193 = v_u_154.outdoor
						local v194
						if typeof(v191) == "Color3" then
							v194 = v191:Lerp(v192, p160):Lerp(v193, p161)
						else
							local v195 = v191 + (v192 - v191) * p160
							v194 = v195 + (v193 - v195) * p161
						end
						v190.OutdoorAmbient = v194
						local v196 = v_u_1:FindFirstChildOfClass("SunRaysEffect")
						if v196 then
							local v197 = v_u_144.rays
							local v198 = v_u_153.rays
							local v199 = v_u_154.rays
							local v200
							if typeof(v197) == "Color3" then
								v200 = v197:Lerp(v198, p160):Lerp(v199, p161)
							else
								local v201 = v197 + (v198 - v197) * p160
								v200 = v201 + (v199 - v201) * p161
							end
							v196.Intensity = v200
						end
						local v202 = v_u_1:FindFirstChildOfClass("Atmosphere")
						if v202 then
							local v203 = v_u_144.atmColor
							local v204 = v_u_153.atmColor
							local v205 = v_u_154.atmColor
							local v206
							if typeof(v203) == "Color3" then
								v206 = v203:Lerp(v204, p160):Lerp(v205, p161)
							else
								local v207 = v203 + (v204 - v203) * p160
								v206 = v207 + (v205 - v207) * p161
							end
							v202.Color = v206
							local v208 = v_u_144.atmDecay
							local v209 = v_u_153.atmDecay
							local v210 = v_u_154.atmDecay
							local v211
							if typeof(v208) == "Color3" then
								v211 = v208:Lerp(v209, p160):Lerp(v210, p161)
							else
								local v212 = v208 + (v209 - v208) * p160
								v211 = v212 + (v210 - v212) * p161
							end
							v202.Decay = v211
							local v213 = v_u_144.atmHaze
							local v214 = v_u_153.haze
							local v215 = v_u_154.haze
							local v216
							if typeof(v213) == "Color3" then
								v216 = v213:Lerp(v214, p160):Lerp(v215, p161)
							else
								local v217 = v213 + (v214 - v213) * p160
								v216 = v217 + (v215 - v217) * p161
							end
							v202.Haze = v216
							local v218 = v_u_144.atmDensity
							local v219 = v_u_153.density
							local v220 = v_u_154.density
							local v221
							if typeof(v218) == "Color3" then
								v221 = v218:Lerp(v219, p160):Lerp(v220, p161)
							else
								local v222 = v218 + (v219 - v218) * p160
								v221 = v222 + (v220 - v222) * p161
							end
							v202.Density = v221
							local v223 = v_u_144.atmGlare
							local v224 = v_u_153.glare
							local v225 = v_u_154.glare
							local v226
							if typeof(v223) == "Color3" then
								v226 = v223:Lerp(v224, p160):Lerp(v225, p161)
							else
								local v227 = v223 + (v224 - v223) * p160
								v226 = v227 + (v225 - v227) * p161
							end
							v202.Glare = v226
						end
						v_u_155.Enabled = true
						local v228 = v_u_155
						local v229 = v_u_13.White
						local v230 = v_u_14(255, 238, 222)
						local v231 = v_u_14(255, 228, 226)
						local v232
						if typeof(v229) == "Color3" then
							v232 = v229:Lerp(v230, p160):Lerp(v231, p161)
						else
							local v233 = v229 + (v230 - v229) * p160
							v232 = v233 + (v231 - v233) * p161
						end
						v228.TintColor = v232
						v_u_155.Saturation = p160 * 0.12
						v_u_155.Contrast = p160 * 0.05
						v_u_155.Brightness = p160 * 0.03
					end
				end
			end
			v_u_155.Enabled = false
			v_u_159 = false
		end
		local function v_u_240(p235) -- name: clock
			local v236 = p235 // 86400
			local v237 = p235 // 3600 % 24
			local v238 = p235 // 60 % 60
			local v239 = p235 % 60
			if v236 > 0 then
				return string.format("%dD %02d:%02d:%02d", v236, v237, v238, v239)
			elseif v237 > 0 then
				return string.format("%d:%02d:%02d", v237, v238, v239)
			else
				return string.format("%d:%02d", v238, v239)
			end
		end
		local v_u_241 = v_u_10.at
		local v242, v243 = pcall(function()
			-- upvalues: (copy) v_u_241
			return DateTime.fromUnixTimestamp(v_u_241):FormatLocalTime("dddd h:mm A", "en-us")
		end)
		local v_u_244 = not v242 and "" or string.upper(v243) .. " YOUR TIME"
		local v_u_245 = {}
		local function v_u_249(p246, p247) -- name: fadeText
			-- upvalues: (copy) v_u_58, (copy) v_u_5
			for _, v248 in v_u_58 do
				v_u_5:Create(v248.label, TweenInfo.new(p247), {
					["TextTransparency"] = p246
				}):Play()
				v_u_5:Create(v248.shadow, TweenInfo.new(p247), {
					["TextTransparency"] = math.max(p246, 0.45)
				}):Play()
			end
		end
		local v_u_250 = false
		local v_u_251 = 0
		local function v_u_273(p_u_252) -- name: reveal
			-- upvalues: (copy) v_u_10, (copy) v_u_17, (ref) v_u_250, (ref) v_u_251, (copy) v_u_57, (copy) v_u_18, (copy) v_u_70, (copy) v_u_8, (copy) v_u_72, (copy) v_u_245, (copy) v_u_13, (copy) v_u_71, (copy) v_u_66, (copy) v_u_67, (copy) v_u_249, (copy) v_u_5, (copy) v_u_68, (copy) v_u_69, (ref) v_u_24, (copy) v_u_141, (copy) v_u_88, (copy) v_u_74
			local v_u_253 = v_u_10.ranks[p_u_252]
			local v254 = v_u_253.color or v_u_17
			local v255 = p_u_252 == #v_u_10.ranks
			v_u_250 = true
			v_u_251 = p_u_252
			local v256 = v_u_57[p_u_252]
			local _ = v_u_10.ranks[p_u_252]
			v256.out = false
			v256.img.ImageColor3 = v_u_18
			v256.img.ImageTransparency = 0.15
			local v257 = v_u_70
			local v258 = v_u_8.Ranks
			v257.Image = v258 and v258[string.lower(v_u_253.name)] or (v_u_253.img or "")
			v_u_70.ImageTransparency = 0
			local v259 = v_u_72
			local v260 = v_u_253.name
			if v_u_245[v259] ~= v260 then
				v_u_245[v259] = v260
				v259.label.Text = v260
				v259.shadow.Text = v260
			end
			v_u_72.label.TextColor3 = v254:Lerp(v_u_13.White, 0.35)
			for _, v261 in { v_u_72, v_u_71 } do
				v261.label.TextTransparency = 0
				v261.shadow.TextTransparency = 0.45
			end
			v_u_66.Position = UDim2.fromOffset(640, 120)
			v_u_66.Visible = true
			v_u_67.Scale = 0.3
			v_u_249(1, 0.2)
			v_u_5:Create(v_u_67, TweenInfo.new(0.55, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				["Scale"] = 1
			}):Play()
			v_u_68.ImageColor3 = v254
			v_u_68.ImageTransparency = 0
			v_u_69.Scale = 0.4
			v_u_5:Create(v_u_68, TweenInfo.new(1.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["ImageTransparency"] = 0.55
			}):Play()
			v_u_5:Create(v_u_69, TweenInfo.new(0.7, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				["Scale"] = 1.3
			}):Play()
			if v_u_24 then
				local v262 = v_u_24.PlayUI
				pcall(v262, "UI/Unlock")
			end
			if v255 then
				task.delay(0.15, function()
					-- upvalues: (ref) v_u_24
					if v_u_24 then
						local v263 = v_u_24.PlayUI
						pcall(v263, "UI/NewItem_Fanfare")
					end
				end)
			end
			v_u_141(v255 and 14 or 8, 2.4, v254, v255 and 1.35 or 1.1)
			v_u_88(v_u_253)
			task.delay(3.4, function()
				-- upvalues: (ref) v_u_57, (copy) p_u_252, (ref) v_u_74, (copy) v_u_253, (ref) v_u_8, (ref) v_u_66, (ref) v_u_68, (ref) v_u_5, (ref) v_u_10, (ref) v_u_13, (ref) v_u_24, (ref) v_u_249, (ref) v_u_250, (ref) v_u_251
				local v264 = v_u_57[p_u_252]
				local v265 = Vector2.new(430, 120)
				local v266 = v_u_74
				local v267 = v_u_253
				local v268 = v_u_8.Ranks
				v266.Image = v268 and v268[string.lower(v267.name)] or (v267.img or "")
				v_u_74.Position = UDim2.fromOffset(v265.X, v265.Y)
				v_u_74.Size = UDim2.fromOffset(180, 180)
				v_u_74.Visible = true
				v_u_66.Visible = false
				v_u_68.ImageTransparency = 1
				local v269 = v264.cell.Position
				v_u_5:Create(v_u_74, TweenInfo.new(0.55, Enum.EasingStyle.Quint, Enum.EasingDirection.In), {
					["Position"] = v269,
					["Size"] = UDim2.fromOffset(62, 62)
				}):Play()
				task.wait(0.55)
				v_u_74.Visible = false
				local v270 = p_u_252
				local v271 = v_u_57[v270]
				local _ = v_u_10.ranks[v270]
				v271.out = true
				v271.img.ImageColor3 = v_u_13.White
				v271.img.ImageTransparency = 0
				v264.scale.Scale = 1.6
				v_u_5:Create(v264.scale, TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
					["Scale"] = 1
				}):Play()
				if v_u_24 then
					local v272 = v_u_24.PlayUI
					pcall(v272, "UI/Card_Reveal")
				end
				v_u_249(0, 0.35)
				v_u_250 = false
				v_u_251 = 0
			end)
		end
		local v_u_274 = -1
		local v_u_275 = ""
		local v_u_276 = false
		local v_u_277 = os.clock()
		local v_u_278 = nil
		local v_u_279 = 0
		local v_u_280 = {}
		v_u_6:GetAttributeChangedSignal("CountdownPreviewAt"):Connect(function()
			-- upvalues: (ref) v_u_276, (ref) v_u_275, (ref) v_u_278, (copy) v_u_280
			v_u_276 = false
			v_u_275 = ""
			v_u_278 = nil
			table.clear(v_u_280)
		end)
		local function v_u_334(p281) -- name: step
			-- upvalues: (copy) v_u_6, (copy) v_u_10, (copy) v_u_21, (copy) v_u_26, (copy) v_u_52, (copy) v_u_75, (copy) v_u_57, (ref) v_u_276, (copy) v_u_13, (copy) v_u_18, (copy) v_u_280, (ref) v_u_251, (copy) v_u_277, (ref) v_u_250, (copy) v_u_273, (copy) v_u_15, (copy) v_u_16, (copy) v_u_3, (copy) v_u_158, (copy) v_u_234, (copy) v_u_48, (copy) v_u_17, (copy) v_u_49, (copy) v_u_50, (copy) v_u_245, (copy) v_u_54, (ref) v_u_274, (copy) v_u_5, (ref) v_u_24, (copy) v_u_244, (copy) v_u_240, (ref) v_u_275, (ref) v_u_278, (copy) v_u_141, (ref) v_u_279, (copy) v_u_90
			local v282 = v_u_6:GetServerTimeNow()
			local v283 = v_u_6:GetAttribute("CountdownPreview")
			local v284 = v_u_6:GetAttribute("CountdownPreviewAt")
			if type(v283) == "number" and type(v284) == "number" then
				v282 = v_u_10.at - v283 + (v282 - v284)
			end
			local v285 = v_u_10.at - v282
			local v286 = v_u_21:GetAttribute("State") ~= "Match"
			v_u_26.Enabled = v286
			v_u_52.Enabled = v286
			v_u_75.Enabled = v286
			for v287, v288 in v_u_10.ranks do
				local v289 = v_u_10.at - v288.hours * 3600
				local v290 = v289 <= v282
				local v291 = v_u_57[v287]
				if v291.out == nil or not v_u_276 then
					local v292 = v_u_57[v287]
					local _ = v_u_10.ranks[v287]
					v292.out = v290
					if v290 then
						v292.img.ImageColor3 = v_u_13.White
						v292.img.ImageTransparency = 0
					else
						v292.img.ImageColor3 = v_u_18
						v292.img.ImageTransparency = 0.15
					end
				elseif v290 and (not v291.out and (not table.find(v_u_280, v287) and v_u_251 ~= v287)) then
					if v282 - v289 < 4 and os.clock() - v_u_277 > 6 then
						local v293 = v_u_280
						table.insert(v293, v287)
					else
						local v294 = v_u_57[v287]
						local _ = v_u_10.ranks[v287]
						v294.out = true
						v294.img.ImageColor3 = v_u_13.White
						v294.img.ImageTransparency = 0
					end
				else
					if v290 or not v291.out then
						continue
					end
					local v295 = v_u_57[v287]
					local _ = v_u_10.ranks[v287]
					v295.out = false
					v295.img.ImageColor3 = v_u_18
					v295.img.ImageTransparency = 0.15
				end
			end
			v_u_276 = true
			if not v_u_250 and #v_u_280 > 0 then
				local v296 = table.remove(v_u_280, 1)
				if v286 then
					v_u_273(v296)
				else
					local v297 = v_u_57[v296]
					local _ = v_u_10.ranks[v296]
					v297.out = true
					v297.img.ImageColor3 = v_u_13.White
					v297.img.ImageTransparency = 0
				end
			end
			local v298 = 0
			local v299 = 0
			if v285 > 0 and v285 <= v_u_15 then
				if v_u_16 < v285 then
					local v300 = (v_u_15 - v285) / (v_u_15 - v_u_16)
					v298 = 0.6 * v300 * v300 * (3 - 2 * v300)
				else
					local v301 = v285 - 60
					v298 = 0.6 + 0.4 * (1 - math.max(0, v301) / (v_u_16 - 60))
				end
				if v285 <= 60 then
					v299 = 1 - v285 / 60
				else
					v299 = 0
				end
			elseif v285 <= 0 then
				local v302
				if v_u_6:GetAttribute("CountdownPreviewShipped") == true then
					v302 = true
				elseif v_u_10.shipped == nil then
					v302 = false
				else
					v302 = v_u_3.Shared:FindFirstChild(v_u_10.shipped) ~= nil
				end
				if not v302 then
					v298 = 1
					v299 = 1
				end
			end
			local v303
			if os.clock() - v_u_277 < 0.4 then
				v303 = 1
			else
				local v304 = p281 * 0.6
				v303 = math.min(1, v304)
			end
			local v305 = v_u_158
			v305.w = v305.w + (v298 - v_u_158.w) * v303
			local v306 = v_u_158
			v306.d = v306.d + (v299 - v_u_158.d) * v303
			v_u_234(v_u_158.w, v_u_158.d)
			if v285 > 0 then
				local v307 = math.ceil(v285)
				local v308 = v285 <= 60 and "final" or (v285 <= v_u_16 and "close" or "far")
				for _, v309 in v_u_57 do
					v309.cell.Visible = true
				end
				local v310 = v308 ~= "far"
				local v311 = v_u_48.label
				local v312
				if v310 then
					v312 = v_u_17
				else
					v312 = v_u_13.White
				end
				v311.TextColor3 = v312
				local v313 = v_u_49.label
				local v314
				if v310 then
					v314 = v_u_17
				else
					v314 = v_u_13.White
				end
				v313.TextColor3 = v314
				if v308 == "final" then
					local v315 = v_u_50
					local v316 = string.upper(v_u_10.title) .. " IN"
					if v_u_245[v315] ~= v316 then
						v_u_245[v315] = v316
						v315.label.Text = v316
						v315.shadow.Text = v316
					end
					v_u_50.label.TextColor3 = v_u_17
					v_u_48.holder.Visible = false
					v_u_49.holder.Visible = false
					v_u_54.holder.Visible = not v_u_250
					local v317 = v_u_54.label
					local v318
					if v307 <= 10 then
						v318 = v_u_13.White
					else
						v318 = v_u_17
					end
					v317.TextColor3 = v318
					if v307 ~= v_u_274 then
						local v319 = v_u_54
						local v320 = tostring(v307)
						if v_u_245[v319] ~= v320 then
							v_u_245[v319] = v320
							v319.label.Text = v320
							v319.shadow.Text = v320
						end
						v_u_54.scale.Scale = v307 <= 10 and 1.2 or 1.12
						v_u_5:Create(v_u_54.scale, TweenInfo.new(0.35, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
							["Scale"] = 1
						}):Play()
						if v286 then
							local v321 = v307 <= 3 and "Match/Countdown_1" or "Match/Countdown_Tick"
							if v_u_24 then
								local v322 = v_u_24.PlayUI
								pcall(v322, v321)
							end
						end
					end
				else
					local v323 = v_u_50
					local v324 = v_u_244
					if v_u_245[v323] ~= v324 then
						v_u_245[v323] = v324
						v323.label.Text = v324
						v323.shadow.Text = v324
					end
					v_u_50.label.TextColor3 = v_u_13.White
					v_u_48.holder.Visible = true
					v_u_49.holder.Visible = true
					v_u_54.holder.Visible = false
					local v325 = v_u_49
					local v326 = v_u_240(v307)
					if v_u_245[v325] ~= v326 then
						v_u_245[v325] = v326
						v325.label.Text = v326
						v325.shadow.Text = v326
					end
				end
				v_u_274 = v307
				v_u_275 = v308
				return true
			end
			if v_u_275 == "final" or v_u_275 == "close" then
				v_u_278 = os.clock()
				if v286 then
					if v_u_24 then
						local v327 = v_u_24.PlayUI
						pcall(v327, "Match/Victory")
					end
					v_u_141(16, 7, nil, 1.5)
					task.delay(7.5, function()
						-- upvalues: (ref) v_u_141
						v_u_141(10, 3, nil, 1.8)
					end)
				end
			end
			if v_u_275 ~= "done" then
				v_u_54.scale.Scale = 0.4
				v_u_5:Create(v_u_54.scale, TweenInfo.new(0.6, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
					["Scale"] = 1
				}):Play()
			end
			v_u_275 = "done"
			for _, v328 in v_u_57 do
				v328.cell.Visible = false
			end
			v_u_48.holder.Visible = false
			v_u_49.holder.Visible = false
			v_u_50.holder.Visible = true
			v_u_54.holder.Visible = true
			v_u_50.label.TextColor3 = v_u_17
			local v329 = v_u_50
			local v330 = string.upper(v_u_10.title)
			if v_u_245[v329] ~= v330 then
				v_u_245[v329] = v330
				v329.label.Text = v330
				v329.shadow.Text = v330
			end
			local v331
			if v_u_6:GetAttribute("CountdownPreviewShipped") == true then
				v331 = true
			elseif v_u_10.shipped == nil then
				v331 = false
			else
				v331 = v_u_3.Shared:FindFirstChild(v_u_10.shipped) ~= nil
			end
			if v331 then
				if -v285 > v_u_10.OUT_FOR then
					return false
				end
				local v332 = v_u_54
				if v_u_245[v332] ~= "OUT NOW!" then
					v_u_245[v332] = "OUT NOW!"
					v332.label.Text = "OUT NOW!"
					v332.shadow.Text = "OUT NOW!"
				end
				v_u_54.label.TextColor3 = v_u_17
				if v286 and (v_u_279 <= os.clock() and -v285 < 7200) then
					v_u_279 = os.clock() + v_u_90:NextNumber(25, 40)
					if v_u_278 == nil or os.clock() - v_u_278 > 15 then
						v_u_141(5, 2.5, nil, 1.1)
					end
				end
			else
				local v333 = v_u_54
				if v_u_245[v333] ~= "SERVERS RESTARTING..." then
					v_u_245[v333] = "SERVERS RESTARTING..."
					v333.label.Text = "SERVERS RESTARTING..."
					v333.shadow.Text = "SERVERS RESTARTING..."
				end
				v_u_54.label.TextColor3 = v_u_13.White
			end
			return true
		end
		local v_u_335 = nil
		local v_u_336 = 0
		v_u_335 = v4.Heartbeat:Connect(function(p337)
			-- upvalues: (ref) v_u_336, (copy) v_u_334, (ref) v_u_335, (copy) v_u_21, (ref) v_u_156, (copy) v_u_155, (ref) v_u_159, (copy) v_u_1, (copy) v_u_144, (copy) v_u_26, (copy) v_u_52, (copy) v_u_75, (copy) v_u_25, (copy) v_u_51, (copy) v_u_89
			v_u_336 = v_u_336 + p337
			if v_u_336 < 0.05 then
				return
			end
			local v338 = v_u_334
			local v339 = v_u_336
			local v340, v341 = pcall(v338, v339)
			v_u_336 = 0
			if not v340 or v341 ~= false then
				if not v340 then
					warn("[UpdateCountdown] " .. tostring(v341))
				end
				return
			end
			if v_u_335 then
				v_u_335:Disconnect()
			end
			if v_u_21:GetAttribute("State") ~= "Match" then
				local v342
				if v_u_156 then
					local v343 = v_u_156.Current
					local v344
					v342, v344 = pcall(v343)
					if v342 then
						v342 = v344 == "Lobby"
					end
				else
					v342 = true
				end
				if v342 then
					if v_u_159 then
						v_u_1.ClockTime = v_u_144.clock
						v_u_1.ColorShift_Top = v_u_144.shiftTop
						v_u_1.Brightness = v_u_144.brightness
						v_u_1.OutdoorAmbient = v_u_144.outdoor
						local v345 = v_u_1:FindFirstChildOfClass("Atmosphere")
						if v345 then
							local v346 = v_u_144.atmColor
							local v347 = v_u_144.atmDecay
							local v348 = v_u_144.atmHaze
							local v349 = v_u_144.atmDensity
							local v350 = v_u_144.atmGlare
							v345.Color = v346
							v345.Decay = v347
							v345.Haze = v348
							v345.Density = v349
							v345.Glare = v350
						end
						local v351 = v_u_1:FindFirstChildOfClass("SunRaysEffect")
						if v351 then
							v351.Intensity = v_u_144.rays
						end
						v_u_159 = false
					end
					v_u_155.Enabled = false
					v_u_26:Destroy()
					v_u_52:Destroy()
					v_u_75:Destroy()
					v_u_25:Destroy()
					v_u_51:Destroy()
					v_u_89:Destroy()
					v_u_155:Destroy()
				else
					v_u_155.Enabled = false
					v_u_159 = false
					v_u_26:Destroy()
					v_u_52:Destroy()
					v_u_75:Destroy()
					v_u_25:Destroy()
					v_u_51:Destroy()
					v_u_89:Destroy()
					v_u_155:Destroy()
				end
			else
				v_u_155.Enabled = false
				v_u_159 = false
				v_u_26:Destroy()
				v_u_52:Destroy()
				v_u_75:Destroy()
				v_u_25:Destroy()
				v_u_51:Destroy()
				v_u_89:Destroy()
				v_u_155:Destroy()
				return
			end
		end)
	end
else
	return
end