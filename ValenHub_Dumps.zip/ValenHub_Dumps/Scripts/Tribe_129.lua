local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("HttpService")
local v4 = game:GetService("ReplicatedStorage"):WaitForChild("Shared")
local v_u_5 = require(v4:WaitForChild("Tribes"))
local v_u_6 = require(v4:WaitForChild("TribeArt"))
local v_u_7 = require(v4:WaitForChild("TribeMapGrid"))
local v8 = {}
local v_u_9 = {
	["left"] = 360,
	["gap"] = 20,
	["row"] = 64,
	["text"] = 18,
	["sub"] = 14,
	["tab"] = 40,
	["cell"] = 58,
	["swatch"] = 34,
	["hero"] = 214
}
local v_u_10 = {
	["left"] = 320,
	["gap"] = 14,
	["row"] = 60,
	["text"] = 17,
	["sub"] = 13,
	["tab"] = 40,
	["cell"] = 50,
	["swatch"] = 30,
	["hero"] = 132
}
local v_u_11 = Color3.fromRGB(142, 149, 166)
local v_u_12 = Color3.fromRGB(10, 11, 15)
local v_u_13 = Color3.fromRGB(255, 186, 46)
Color3.fromRGB(150, 98, 10)
local v_u_14 = {
	["chief"] = {
		["text"] = "CHIEF",
		["color"] = nil,
		["color"] = Color3.fromRGB(196, 136, 20)
	},
	["elder"] = {
		["text"] = "ELDER",
		["color"] = nil,
		["color"] = Color3.fromRGB(28, 110, 220)
	}
}
local v_u_15 = {
	["open"] = "OPEN",
	["request"] = "REQUEST",
	["invite"] = "INVITE ONLY"
}
local v_u_16 = {
	["open"] = "Anyone can join",
	["request"] = "Players ask, Elders accept",
	["invite"] = "Only players you invite"
}
local v_u_17 = {
	0,
	5,
	10,
	20,
	30,
	50
}
local function v_u_21(p18) -- name: ago
	if type(p18) == "number" and p18 > 0 then
		local v19 = os.time() - p18
		local v20 = math.max(0, v19)
		if v20 < 60 then
			return "just now"
		elseif v20 < 3600 then
			return ("%*m ago"):format(v20 // 60)
		elseif v20 < 86400 then
			return ("%*h ago"):format(v20 // 3600)
		else
			return ("%*d ago"):format(v20 // 86400)
		end
	else
		return ""
	end
end
local function v_u_26(p22) -- name: untilText
	if type(p22) ~= "number" then
		return ""
	end
	local v23 = p22 - os.time()
	local v24 = math.max(0, v23)
	if v24 >= 86400 then
		return ("%*d %*h"):format(v24 // 86400, v24 % 86400 // 3600)
	end
	if v24 >= 3600 then
		return ("%*h %*m"):format(v24 // 3600, v24 % 3600 // 60)
	end
	local v25 = v24 // 60
	return ("%*m"):format((math.max(1, v25)))
end
function v8.Init(p_u_27) -- name: Init
	-- upvalues: (copy) v_u_1, (copy) v_u_10, (copy) v_u_9, (copy) v_u_11, (copy) v_u_3, (copy) v_u_2, (copy) v_u_12, (copy) v_u_5, (copy) v_u_13, (copy) v_u_26, (copy) v_u_14, (copy) v_u_15, (copy) v_u_21, (copy) v_u_7, (copy) v_u_6, (copy) v_u_16, (copy) v_u_17
	local v_u_28 = p_u_27.UI
	local v_u_29 = p_u_27.Theme
	local v30 = p_u_27.State
	local v_u_31 = v_u_29.Colors
	local v_u_32 = v_u_29.Fonts
	local v_u_33 = p_u_27.Tribes
	local v_u_34 = p_u_27.MenuManager
	local v_u_35 = v_u_1.LocalPlayer
	local v_u_36 = UDim2.fromOffset
	local v_u_37
	if v_u_28.Compact then
		v_u_37 = v_u_10
	else
		v_u_37 = v_u_9
	end
	local v_u_38 = require(script.Parent.Parent:WaitForChild("TribeEmblem"))
	v_u_38.Init(v_u_28)
	local v_u_39 = v_u_28.Assets.Icons.Glow
	local v_u_40 = v_u_28.Window({
		["Name"] = "Tribe",
		["Title"] = "TRIBES",
		["Subtitle"] = "Play together, earn Glory, hold the maps",
		["Size"] = nil,
		["HeaderHeight"] = 80,
		["Parent"] = nil,
		["OnCloseRequested"] = nil,
		["Size"] = v_u_36(1180, 700),
		["Parent"] = p_u_27.Canvas.Menus,
		["OnCloseRequested"] = function() -- name: OnCloseRequested
			-- upvalues: (copy) v_u_34
			v_u_34.Close("Tribe")
		end
	})
	local v41 = v_u_40.Content
	v_u_28.SelectionRing(v_u_40.Root)
	local v_u_42 = v_u_28.new("TextLabel", {
		["Name"] = "HeadInfo",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["RichText"] = true,
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -96, 0, 34),
		["Size"] = v_u_36(320, 22),
		["FontFace"] = v_u_32.Heavy,
		["TextColor3"] = v_u_31.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_40.Header
	})
	local v43 = nil
	local v_u_44 = false
	local v_u_45 = nil
	local v_u_46 = nil
	local function v_u_53(p47) -- name: roleIn
		-- upvalues: (copy) v_u_35, (copy) v_u_33
		local v48
		if type(p47) == "table" then
			local v49 = p47.membersList
			v48 = type(v49) ~= "table" and {} or p47.membersList
		else
			v48 = {}
		end
		for _, v50 in v48 do
			if v50.userId ~= v_u_35.UserId then
				continue
			end
			local v51 = v50.role
			return tostring(v51)
		end
		local v52 = v_u_33.Mine()
		return not v52 and "member" or v52.role
	end
	local v_u_54 = (-1 / 0)
	local function v_u_57(p55) -- name: label
		-- upvalues: (copy) v_u_32, (copy) v_u_31, (copy) v_u_28
		local v56 = table.clone(p55)
		v56.FontFace = v56.FontFace or v_u_32.Bold
		v56.TextColor3 = v56.TextColor3 or v_u_31.Text
		v56.TextXAlignment = v56.TextXAlignment or Enum.TextXAlignment.Left
		v56.TextTruncate = v56.TextTruncate or Enum.TextTruncate.AtEnd
		return v_u_28.new("TextLabel", v56)
	end
	local function v_u_61(p58, p59) -- name: caps
		-- upvalues: (copy) v_u_57, (copy) v_u_32, (copy) v_u_31
		local v60 = p59 or {}
		return v_u_57({
			["Name"] = v60.Name or "Caption",
			["Text"] = p58,
			["FontFace"] = v_u_32.Heavy,
			["TextSize"] = v60.TextSize or 12,
			["TextColor3"] = v60.TextColor3 or v_u_31.TextMuted,
			["TextXAlignment"] = v60.TextXAlignment or Enum.TextXAlignment.Left,
			["Size"] = v60.Size or UDim2.new(1, 0, 0, 14),
			["Position"] = v60.Position,
			["AnchorPoint"] = v60.AnchorPoint,
			["LayoutOrder"] = v60.LayoutOrder or 0,
			["ZIndex"] = v60.ZIndex,
			["Parent"] = v60.Parent
		})
	end
	local function v_u_70(p62, p63, p64, p65, p66, p67) -- name: section
		-- upvalues: (copy) v_u_28, (copy) v_u_36, (copy) v_u_31, (ref) v_u_11, (copy) v_u_57, (copy) v_u_32
		local v68 = v_u_28.new("Frame", {
			["Name"] = "Section_" .. p62,
			["Size"] = UDim2.new(1, -6, 0, 22),
			["LayoutOrder"] = p65,
			["Parent"] = p66
		})
		v_u_28.new("Frame", {
			["Name"] = "Bar",
			["Size"] = v_u_36(4, 16),
			["Position"] = v_u_36(0, 3),
			["BackgroundColor3"] = p67 or v_u_31.Accent,
			v_u_28.Corner(2),
			["Parent"] = v68
		})
		local v69 = string.format("<font color=\"#%s\">%s</font>", v_u_31.TextDim:ToHex(), string.upper(p62))
		if p63 ~= nil then
			v69 = v69 .. string.format("  <font color=\"#%s\">\194\183  %s</font>", v_u_31.TextMuted:ToHex(), (tostring(p63)))
		end
		if p64 and p64 ~= "" then
			v69 = v69 .. string.format("    <font color=\"#%s\" weight=\"600\">%s</font>", v_u_11:ToHex(), p64)
		end
		v_u_57({
			["Name"] = "Text",
			["Text"] = nil,
			["RichText"] = true,
			["FontFace"] = nil,
			["TextSize"] = 15,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v69,
			["FontFace"] = v_u_32.Heavy,
			["Position"] = v_u_36(12, 0),
			["Size"] = UDim2.new(1, -12, 1, 0),
			["Parent"] = v68
		})
		return v68
	end
	local function v_u_75(p71, p72, p73) -- name: card
		-- upvalues: (copy) v_u_28, (copy) v_u_31
		local v74 = p73 or {}
		return v_u_28.new("Frame", {
			["Name"] = p71,
			["BackgroundColor3"] = v74.Color or v_u_31.PanelHi,
			["BackgroundTransparency"] = v74.Transparency or 0.35,
			["Size"] = v74.Size or UDim2.new(1, -6, 0, 0),
			["AutomaticSize"] = v74.AutomaticSize or Enum.AutomaticSize.Y,
			["LayoutOrder"] = v74.LayoutOrder or 0,
			v_u_28.Corner(12),
			v_u_28.Stroke(v_u_31.Stroke, 1, 0.92),
			["Parent"] = p72
		})
	end
	local function v78(p76, p77) -- name: pad
		-- upvalues: (copy) v_u_28
		v_u_28.Padding(p77, p77, p77, p77).Parent = p76
	end
	local function v82(p79, p80, p81) -- name: column
		-- upvalues: (copy) v_u_28
		return v_u_28.new("ScrollingFrame", {
			["Name"] = p79,
			["ScrollBarThickness"] = 3,
			["Selectable"] = false,
			v_u_28.List(Enum.FillDirection.Vertical, p81 or 10),
			v_u_28.Padding(4, 8, 10, 4),
			["Parent"] = p80
		})
	end
	local function v_u_85(p83) -- name: clear
		for _, v84 in p83:GetChildren() do
			if not v84:IsA("GuiObject") then
				continue
			end
			v84:Destroy()
		end
	end
	local function v_u_93(p86, p87, p88, p_u_89, p90) -- name: smallButton
		-- upvalues: (copy) v_u_28, (copy) v_u_36, (ref) v_u_54
		local v91 = p90 or {}
		local v92 = v_u_28.Button({
			["Name"] = nil,
			["Text"] = nil,
			["Style"] = nil,
			["TextSize"] = nil,
			["Icon"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Radius"] = 10,
			["Parent"] = nil,
			["Name"] = v91.Name or p86,
			["Text"] = p86,
			["Style"] = p87,
			["TextSize"] = v91.TextSize or 16,
			["Icon"] = v91.Icon,
			["Size"] = v91.Size or v_u_36(v91.Width or 104, v91.Height or 40),
			["LayoutOrder"] = v91.LayoutOrder or 0,
			["AnchorPoint"] = v91.AnchorPoint,
			["Position"] = v91.Position,
			["Parent"] = p88
		})
		v92.Activated:Connect(function()
			-- upvalues: (ref) v_u_54, (copy) p_u_89
			if os.clock() - v_u_54 >= 0.5 then
				p_u_89()
			end
		end)
		if v91.Enabled == false then
			v92:SetEnabled(false)
		end
		return v92
	end
	local function v_u_103(p94, p95, p96) -- name: heroTile
		-- upvalues: (copy) v_u_28, (copy) v_u_31, (copy) v_u_39
		local v97 = v_u_28.new("Frame", {
			["Name"] = "Hero",
			["Size"] = UDim2.new(1, 0, 0, p95),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["ClipsDescendants"] = true,
			["LayoutOrder"] = p96,
			v_u_28.Corner(12),
			["Parent"] = p94
		})
		local v_u_98 = v_u_28.Gradient(v_u_31.Accent, v_u_31.Panel, 115)
		v_u_98.Parent = v97
		local v_u_99 = v_u_28.Image(v_u_39, {
			["Name"] = "Glow",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ImageTransparency"] = 0.55,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.46),
			["Size"] = UDim2.fromScale(1.15, 1.35),
			["Parent"] = v97
		})
		local function v101(p100) -- name: tint
			-- upvalues: (copy) v_u_98, (ref) v_u_31, (copy) v_u_99
			v_u_98.Color = ColorSequence.new(p100:Lerp(v_u_31.Panel, 0.45), v_u_31.Panel:Lerp(v_u_31.PanelLo, 0.5))
			v_u_99.ImageColor3 = p100
		end
		local v102 = v_u_31.Accent
		v_u_98.Color = ColorSequence.new(v102:Lerp(v_u_31.Panel, 0.45), v_u_31.Panel:Lerp(v_u_31.PanelLo, 0.5))
		v_u_99.ImageColor3 = v102
		return v97, v101
	end
	local function v_u_109(p104, p105, p106) -- name: statTile
		-- upvalues: (copy) v_u_28, (copy) v_u_31, (copy) v_u_57, (copy) v_u_32, (copy) v_u_36, (copy) v_u_61
		local v107 = v_u_28.new("Frame", {
			["Name"] = "Stat_" .. p105,
			["Size"] = UDim2.new(0.3333333333333333, -6, 1, 0),
			["LayoutOrder"] = p106,
			["BackgroundColor3"] = v_u_31.Inset,
			["BackgroundTransparency"] = 0.35,
			v_u_28.Corner(10),
			["Parent"] = p104
		})
		local v108 = v_u_57({
			["Name"] = "Value",
			["Text"] = "-",
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_32.Display,
			["TextSize"] = v_u_28.Compact and 20 or 24,
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["Position"] = v_u_36(0, v_u_28.Compact and 5 or 8),
			["Size"] = UDim2.new(1, 0, 0, 26),
			["Parent"] = v107
		})
		v_u_61(p105, {
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["Position"] = UDim2.new(0, 0, 1, -22),
			["Size"] = UDim2.new(1, 0, 0, 14),
			["Parent"] = v107
		})
		return v108
	end
	local v_u_110 = v_u_28.new("Frame", {
		["Name"] = "Tabs",
		["Size"] = UDim2.new(1, 0, 0, v_u_37.tab),
		v_u_28.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
		["Parent"] = v41
	})
	local v_u_111 = v_u_28.new("Frame", {
		["Name"] = "Pages",
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = v_u_36(0, v_u_37.tab + 14),
		["Size"] = UDim2.new(1, 0, 1, -(v_u_37.tab + 14)),
		["Parent"] = v41
	})
	local v_u_112 = {}
	local v_u_113 = {}
	local v_u_114 = nil
	local v_u_115 = {}
	local function v122(p116, p117, p118) -- name: makeTab
		-- upvalues: (copy) v_u_28, (copy) v_u_36, (ref) v_u_37, (copy) v_u_31, (copy) v_u_29, (copy) v_u_110, (copy) v_u_32, (copy) v_u_111, (copy) v_u_112
		local v119 = v_u_28.new("TextButton", {
			["Name"] = p116,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = v_u_36(0, v_u_37.tab),
			["BackgroundColor3"] = v_u_31.Raised,
			["BackgroundTransparency"] = 0.4,
			v_u_28.Corner(v_u_29.Radius.Pill),
			v_u_28.Padding(0, 18, 0, 14),
			v_u_28.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
			["Parent"] = v_u_110
		})
		local v120 = v_u_28.Glyph(p118, 20, v_u_31.TextDim, {
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Parent"] = v119
		})
		local v121 = {
			["button"] = v119,
			["text"] = v_u_28.new("TextLabel", {
				["Name"] = "Text",
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 16,
				["TextColor3"] = nil,
				["AutomaticSize"] = nil,
				["Size"] = nil,
				["LayoutOrder"] = 2,
				["Parent"] = nil,
				["Text"] = p117,
				["FontFace"] = v_u_32.Heavy,
				["TextColor3"] = v_u_31.TextDim,
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["Size"] = UDim2.fromScale(0, 1),
				["Parent"] = v119
			}),
			["icon"] = v120,
			["page"] = v_u_28.new("Frame", {
				["Name"] = nil,
				["Size"] = nil,
				["Visible"] = false,
				["Parent"] = nil,
				["Name"] = p116,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v_u_111
			})
		}
		v_u_112[p116] = v121
		return v121
	end
	local function v_u_132() -- name: paintTabs
		-- upvalues: (copy) v_u_112, (ref) v_u_114, (copy) v_u_31
		for v123, v124 in v_u_112 do
			local v125 = v123 == v_u_114
			local v126 = v124.button
			local v127
			if v125 then
				v127 = v_u_31.Accent
			else
				v127 = v_u_31.Raised
			end
			v126.BackgroundColor3 = v127
			v124.button.BackgroundTransparency = v125 and 0 or 0.4
			local v128 = v124.text
			local v129
			if v125 then
				v129 = v_u_31.Text
			else
				v129 = v_u_31.TextDim
			end
			v128.TextColor3 = v129
			local v130 = v124.icon
			local v131
			if v125 then
				v131 = v_u_31.Text
			else
				v131 = v_u_31.TextDim
			end
			v130.TextColor3 = v131
		end
	end
	local function v_u_137(p133) -- name: showTab
		-- upvalues: (copy) v_u_112, (ref) v_u_114, (copy) v_u_132, (copy) v_u_28, (copy) v_u_115
		if v_u_112[p133] then
			local v134 = v_u_114
			v_u_114 = p133
			for v135, v136 in v_u_112 do
				v136.page.Visible = v135 == p133
			end
			v_u_132()
			if v134 ~= p133 then
				v_u_28.SlideIn(v_u_112[p133].page, Vector2.new(0, 12), TweenInfo.new(0.28, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), UDim2.new())
			end
			if v_u_115[p133] then
				task.spawn(v_u_115[p133])
			end
		end
	end
	local function v_u_142(p138) -- name: setTabs
		-- upvalues: (ref) v_u_113, (copy) v_u_112, (ref) v_u_114, (copy) v_u_137
		v_u_113 = p138
		for v139, v140 in v_u_112 do
			local v141 = table.find(p138, v139)
			v140.button.Visible = v141 ~= nil
			v140.button.LayoutOrder = v141 or 99
		end
		if not (v_u_114 and table.find(p138, v_u_114)) and (v_u_114 ~= "Form" and v_u_114 ~= "View") then
			v_u_137(p138[1])
		end
	end
	local v_u_143 = v122("Find", "FIND A TRIBE", "magnifying-glass")
	local v144 = v122("Overview", "MY TRIBE", "shield-check")
	local v145 = v122("Members", "MEMBERS", "three-people")
	local v146 = v122("Leaderboard", "LEADERBOARD", "trophy")
	local v147 = v122("Territories", "TERRITORIES", "location-pin-map")
	local v148 = v122("Form", "", "pencil")
	v148.button.Visible = false
	local v149 = v122("View", "", "eye")
	v149.button.Visible = false
	local v_u_150 = v_u_113
	local v_u_151 = v43
	local v_u_152 = v_u_54
	local v_u_153 = v_u_114
	for v_u_154, v_u_155 in v_u_112 do
		v_u_155.button.Activated:Connect(function()
			-- upvalues: (ref) v_u_153, (copy) v_u_154, (ref) v_u_152, (copy) p_u_27, (copy) v_u_137
			if v_u_153 ~= v_u_154 and os.clock() - v_u_152 >= 0.5 then
				p_u_27.Sounds.Play("Click")
				v_u_137(v_u_154)
			end
		end)
		v_u_155.button.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_153, (copy) v_u_154, (copy) v_u_28, (copy) v_u_155, (copy) v_u_29
			if v_u_153 ~= v_u_154 and not v_u_28.Touch then
				v_u_28.Tween(v_u_155.button, v_u_29.Tween.Fast, {
					["BackgroundTransparency"] = 0.15
				})
			end
		end)
		v_u_155.button.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_28, (copy) v_u_155, (copy) v_u_29, (ref) v_u_153, (copy) v_u_154
			v_u_28.Tween(v_u_155.button, v_u_29.Tween.Fast, {
				["BackgroundTransparency"] = v_u_153 == v_u_154 and 0 or 0.4
			})
		end)
	end
	local v_u_156 = v_u_28.new("TextButton", {
		["Name"] = "DialogDim",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundColor3"] = v_u_31.Void,
		["BackgroundTransparency"] = 0.3,
		["Visible"] = false,
		["ZIndex"] = 20,
		["Selectable"] = false,
		v_u_28.Corner(16),
		["Parent"] = v_u_40.Body
	})
	local v_u_157 = v_u_28.new("Frame", {
		["Name"] = "Dialog",
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = v_u_36(460, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["BackgroundColor3"] = v_u_31.Panel,
		["ZIndex"] = 21,
		v_u_28.Corner(16),
		v_u_28.Stroke(v_u_31.Stroke, 1, 0.85),
		v_u_28.Padding(22, 22, 22, 22),
		v_u_28.List(Enum.FillDirection.Vertical, 12),
		["Parent"] = v_u_156
	})
	local v_u_158 = false
	local v_u_159 = 0
	v_u_156.Activated:Connect(function()
		-- upvalues: (ref) v_u_159, (ref) v_u_158, (copy) v_u_156, (copy) v_u_85, (copy) v_u_157, (copy) v_u_28, (copy) v_u_34
		if os.clock() - v_u_159 > 0.3 then
			v_u_158 = false
			v_u_156.Visible = false
			v_u_85(v_u_157)
			if v_u_28.Gamepad then
				v_u_34.Reselect()
			end
		end
	end)
	local function v_u_169(p160, p161, p162, p163) -- name: openDialog
		-- upvalues: (copy) v_u_85, (copy) v_u_157, (ref) v_u_158, (ref) v_u_159, (copy) v_u_156, (copy) v_u_57, (copy) v_u_32, (copy) v_u_31, (copy) v_u_28, (copy) v_u_34, (ref) v_u_2
		v_u_85(v_u_157)
		v_u_158 = true
		v_u_159 = os.clock()
		v_u_156.Visible = true
		v_u_57({
			["Name"] = "Title",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 26,
			["Size"] = nil,
			["ZIndex"] = 22,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Text"] = p160,
			["FontFace"] = v_u_32.Display,
			["Size"] = UDim2.new(1, 0, 0, 30),
			["Parent"] = v_u_157
		})
		if p161 and p161 ~= "" then
			v_u_57({
				["Name"] = "Text",
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 17,
				["TextColor3"] = nil,
				["TextWrapped"] = true,
				["TextTruncate"] = nil,
				["AutomaticSize"] = nil,
				["Size"] = nil,
				["ZIndex"] = 22,
				["LayoutOrder"] = 2,
				["Parent"] = nil,
				["Text"] = p161,
				["FontFace"] = v_u_32.SemiBold,
				["TextColor3"] = v_u_31.TextDim,
				["TextTruncate"] = Enum.TextTruncate.None,
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["Parent"] = v_u_157
			})
		end
		if p163 then
			p163((v_u_28.new("Frame", {
				["Name"] = "Extra",
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 3,
				["ZIndex"] = 22,
				["Parent"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["Parent"] = v_u_157
			})))
		end
		local v164 = v_u_28.new("Frame", {
			["Name"] = "Buttons",
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = 4,
			v_u_28.List(Enum.FillDirection.Vertical, 8),
			["Parent"] = v_u_157
		})
		local v165 = nil
		for v166, v_u_167 in p162 do
			local v168 = v_u_28.Button({
				["Name"] = nil,
				["Text"] = nil,
				["Style"] = nil,
				["TextSize"] = 18,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["ZIndex"] = 23,
				["Parent"] = nil,
				["Name"] = "B" .. v166,
				["Text"] = v_u_167.text,
				["Style"] = v_u_167.style or "Dark",
				["Size"] = UDim2.new(1, 0, 0, 48),
				["LayoutOrder"] = v166,
				["Parent"] = v164
			})
			v168.Activated:Connect(function()
				-- upvalues: (ref) v_u_159, (ref) v_u_158, (ref) v_u_156, (ref) v_u_85, (ref) v_u_157, (ref) v_u_28, (ref) v_u_34, (copy) v_u_167
				if os.clock() - v_u_159 >= 0.25 then
					v_u_158 = false
					v_u_156.Visible = false
					v_u_85(v_u_157)
					if v_u_28.Gamepad then
						v_u_34.Reselect()
					end
					if v_u_167.fn then
						task.spawn(v_u_167.fn)
					end
				end
			end)
			if v_u_167.enabled == false then
				v168:SetEnabled(false)
			end
			v165 = v165 or v168.Instance
		end
		v_u_28.Pop(v_u_157, 0.92)
		if v_u_28.Gamepad and v165 then
			v_u_2.SelectedObject = v165
		end
	end
	local v_u_170 = v82("Left", v_u_143.page, 12)
	local v_u_171 = v_u_28.new("Frame", {
		["Name"] = "Right",
		["Parent"] = nil,
		["Parent"] = v_u_143.page
	})
	local v172 = v_u_28.new("Frame", {
		["Name"] = "SearchRow",
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 46),
		["Parent"] = v_u_171
	})
	local v173 = v_u_28.new("Frame", {
		["Name"] = "SearchField",
		["Size"] = UDim2.new(1, -262, 1, 0),
		["BackgroundColor3"] = v_u_12,
		["BackgroundTransparency"] = 0.25,
		v_u_28.Corner(v_u_29.Radius.Pill),
		v_u_28.Stroke(v_u_31.Stroke, 1, 0.88),
		["Parent"] = v172
	})
	v_u_28.Glyph("magnifying-glass", 20, v_u_31.TextMuted, {
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 16, 0.5, 0),
		["Parent"] = v173
	})
	local v_u_174 = v_u_28.new("TextBox", {
		["Name"] = "Search",
		["Text"] = "",
		["PlaceholderText"] = "Search a tag or name",
		["PlaceholderColor3"] = nil,
		["ClearTextOnFocus"] = false,
		["FontFace"] = nil,
		["TextSize"] = 17,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["PlaceholderColor3"] = v_u_31.TextMuted,
		["FontFace"] = v_u_32.Bold,
		["TextColor3"] = v_u_31.Text,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = v_u_36(46, 0),
		["Size"] = UDim2.new(1, -60, 1, 0),
		["Parent"] = v173
	})
	local v175 = v_u_28.new("Frame", {
		["Name"] = "Sort",
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -4, 0, 0),
		["Size"] = v_u_36(250, 46),
		["BackgroundColor3"] = v_u_12,
		["BackgroundTransparency"] = 0.25,
		v_u_28.Corner(v_u_29.Radius.Pill),
		v_u_28.Padding(4, 4, 4, 4),
		v_u_28.List(Enum.FillDirection.Horizontal, 4),
		["Parent"] = v172
	})
	local v_u_176 = v_u_158
	local v_u_177 = {}
	local function v_u_181(p178, ...) -- name: act
		-- upvalues: (ref) v_u_44, (copy) v_u_33, (copy) p_u_27
		if v_u_44 then
			return false, nil
		end
		v_u_44 = true
		local v179, v180 = v_u_33.Action(p178, ...)
		v_u_44 = false
		if not v179 then
			p_u_27.Toast(tostring(v180), "error")
		end
		task.spawn(v_u_33.Home, true)
		return v179, v180
	end
	local v_u_182 = "top"
	for v183, v184 in {
		{ "top", "TOP" },
		{ "recruiting", "RECRUITING" }
	} do
		v_u_177[v184[1]] = v_u_28.new("TextButton", {
			["Name"] = v184[1],
			["Text"] = v184[2],
			["AutoButtonColor"] = false,
			["FontFace"] = v_u_32.Heavy,
			["TextSize"] = 14,
			["TextColor3"] = v_u_31.TextDim,
			["Size"] = UDim2.new(0.5, -2, 1, 0),
			["LayoutOrder"] = v183,
			["BackgroundColor3"] = v_u_31.Accent,
			["BackgroundTransparency"] = 1,
			v_u_28.Corner(v_u_29.Radius.Pill),
			["Parent"] = v175
		})
	end
	local v_u_185 = v_u_28.new("ScrollingFrame", {
		["Name"] = "List",
		["Position"] = v_u_36(0, 58),
		["Size"] = UDim2.new(1, 0, 1, -58),
		["ScrollBarThickness"] = 3,
		["Selectable"] = false,
		v_u_28.List(Enum.FillDirection.Vertical, 8),
		v_u_28.Padding(4, 10, 10, 4),
		["Parent"] = v_u_171
	})
	local v_u_186 = v_u_28.new("Frame", {
		["Name"] = "Empty",
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Position"] = v_u_36(0, 120),
		["Size"] = UDim2.new(1, 0, 0, 120),
		["Parent"] = v_u_171
	})
	v_u_28.Glyph("three-people", 48, v_u_31.TextMuted, {
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 0),
		["Parent"] = v_u_186
	})
	local v_u_187 = v_u_57({
		["Name"] = "Text",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 17,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_32.SemiBold,
		["TextColor3"] = v_u_11,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Position"] = v_u_36(0, 60),
		["Size"] = UDim2.new(1, 0, 0, 24),
		["Parent"] = v_u_186
	})
	local function v_u_194(p188, p189, p190, p191, p192) -- name: rowStat
		-- upvalues: (copy) v_u_28, (copy) v_u_36, (copy) v_u_57, (copy) v_u_32, (copy) v_u_31, (copy) v_u_61
		local v193 = v_u_28.new("Frame", {
			["Name"] = "S_" .. p190,
			["Size"] = v_u_36(78, 40),
			["LayoutOrder"] = p191,
			["Parent"] = p188
		})
		v_u_57({
			["Name"] = "Value",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 18,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = p189,
			["FontFace"] = v_u_32.Display,
			["TextColor3"] = p192 or v_u_31.Text,
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["Size"] = UDim2.new(1, 0, 0, 22),
			["Parent"] = v193
		})
		v_u_61(p190, {
			["TextSize"] = 11,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["Position"] = v_u_36(0, 23),
			["Size"] = UDim2.new(1, 0, 0, 13),
			["Parent"] = v193
		})
	end
	local function v_u_205(p195, p_u_196, p_u_197) -- name: openable
		-- upvalues: (ref) v_u_152, (copy) p_u_27, (ref) v_u_46, (copy) v_u_28, (copy) v_u_29
		p195.Activated:Connect(function()
			-- upvalues: (ref) v_u_152, (ref) p_u_27, (ref) v_u_46, (copy) p_u_197
			if os.clock() - v_u_152 >= 0.5 then
				p_u_27.Sounds.Play("Click")
				v_u_46(p_u_197.id, p_u_197)
			end
		end)
		local v_u_198 = p_u_196.Transparency
		p195.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_28, (copy) p_u_196, (ref) v_u_29, (copy) v_u_198
			if not v_u_28.Touch then
				local v199 = v_u_28.Tween
				local v200 = p_u_196
				local v201 = v_u_29.Tween.Fast
				local v202 = {}
				local v203 = v_u_198
				v202.Transparency = math.min(v203, 0.55)
				v199(v200, v201, v202)
			end
		end)
		p195.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_28, (copy) p_u_196, (ref) v_u_29, (copy) v_u_198
			local v204 = {
				["Transparency"] = v_u_198
			}
			v_u_28.Tween(p_u_196, v_u_29.Tween.Fast, v204)
		end)
	end
	local function v_u_247(p206, p207, p208, p209) -- name: tribeRow
		-- upvalues: (copy) v_u_28, (ref) v_u_37, (copy) v_u_31, (copy) v_u_205, (ref) v_u_5, (copy) v_u_38, (copy) v_u_57, (copy) v_u_32, (copy) v_u_36, (ref) v_u_11, (copy) v_u_194, (ref) v_u_13
		local v210 = v_u_28.new
		local v211 = {}
		local v212 = p206.id
		v211.Name = "T" .. tostring(v212)
		v211.Text = ""
		v211.AutoButtonColor = false
		v211.Size = UDim2.new(1, -4, 0, v_u_37.row + 8)
		v211.LayoutOrder = p208
		v211.BackgroundColor3 = Color3.new(1, 1, 1)
		v211.BackgroundTransparency = 0.1
		v211.ClipsDescendants = true
		__set_list(v211, 1, {(v_u_28.Corner(12))})
		v211.Parent = p207
		local v213 = v210("TextButton", v211)
		local v214 = v_u_28.Stroke(v_u_31.Stroke, 1, 0.92)
		v214.Parent = v213
		v_u_205(v213, v214, p206)
		v_u_28.Gradient(v_u_5.Color(p206.color1):Lerp(v_u_31.Panel, 0.8), v_u_31.PanelHi:Lerp(v_u_31.Panel, 0.55), 0).Parent = v213
		v_u_38.new(v_u_37.row - 2, {
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 10, 0.5, 0),
			["Parent"] = v213
		}):Set(p206.icon, p206.color1, p206.color2, p206.tag)
		local v215 = v_u_37.row + 20
		local v216 = v_u_57
		local v217 = {
			["Name"] = "Name",
			["Text"] = nil,
			["RichText"] = true,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil
		}
		local v218 = string.format
		local v219 = "<font color=\"#%s\">%s</font>  %s"
		local v220 = v_u_38.TagColor(p206.color1):ToHex()
		local v221 = v_u_38.Tag
		local v222
		if type(p206) == "table" then
			v222 = p206.tag
		else
			v222 = p206
		end
		local v223 = v221(v222)
		local v224 = p206.name or ""
		v217.Text = v218(v219, v220, v223, (tostring(v224)))
		v217.FontFace = v_u_32.Heavy
		v217.TextSize = v_u_37.text
		local v225 = v_u_36
		local v226 = (v_u_37.row + 8) / 2
		v217.Position = v225(v215, math.floor(v226) - v_u_37.text - 2)
		v217.Size = UDim2.new(1, -(v215 + 400), 0, v_u_37.text + 2)
		v217.Parent = v213
		v216(v217).Name = "Name"
		local v227 = p206.joinMode == "invite" and "Invite only" or (p206.joinMode == "request" and "Ask to join" or "Open to everyone")
		local v228 = p206.minLevel
		if (tonumber(v228) or 0) > 0 then
			v227 = v227 .. ("  \194\183  level %*+"):format(p206.minLevel)
		end
		local v229 = v_u_57
		local v230 = {
			["Name"] = "Sub",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v227,
			["FontFace"] = v_u_32.SemiBold,
			["TextSize"] = v_u_37.sub,
			["TextColor3"] = v_u_11
		}
		local v231 = v_u_36
		local v232 = (v_u_37.row + 8) / 2
		v230.Position = v231(v215, math.floor(v232) + 3)
		v230.Size = UDim2.new(1, -(v215 + 400), 0, v_u_37.sub + 2)
		v230.Parent = v213
		v229(v230)
		local v233 = v_u_28.new("Frame", {
			["Name"] = "Stats",
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -160, 0.5, 0),
			["Size"] = v_u_36(250, 40),
			v_u_28.List(Enum.FillDirection.Horizontal, 4, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
			["Parent"] = v213
		})
		local v234 = v_u_194
		local v235 = p206.members
		v234(v233, ("%*/%*"):format(tonumber(v235) or 0, v_u_5.MAX_MEMBERS), "MEMBERS", 1)
		local v236 = v_u_194
		local v237 = v_u_28.FormatCompact
		local v238 = p206.weekRenown
		v236(v233, v237(tonumber(v238) or 0), "GLORY", 2, v_u_13)
		local v239 = v_u_194
		local v240 = p206.online
		local v241 = tonumber(v240) or 0
		local v242 = tostring(v241)
		local v243 = "ONLINE"
		local v244 = 3
		local v245 = p206.online
		local v246
		if (tonumber(v245) or 0) > 0 then
			v246 = v_u_31.Success
		else
			v246 = v_u_31.TextDim
		end
		v239(v233, v242, v243, v244, v246)
		p209((v_u_28.new("Frame", {
			["Name"] = "Action",
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -12, 0.5, 0),
			["Size"] = v_u_36(136, 42),
			v_u_28.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
			["Parent"] = v213
		})))
		return v213
	end
	local function v_u_304(p_u_248, p249, p250) -- name: joinButton
		-- upvalues: (ref) v_u_151, (copy) v_u_35, (copy) v_u_93, (copy) v_u_169, (copy) v_u_38, (copy) v_u_181, (ref) v_u_5, (copy) p_u_27
		local v251 = v_u_151 or {}
		local v252 = v251.requested
		local v253
		if type(v252) == "table" then
			v253 = table.find(v251.requested, p_u_248.id) ~= nil
		else
			v253 = false
		end
		local v254 = v_u_35:GetAttribute("Level") or 1
		local v255 = v251.cooldownUntil
		local v_u_256
		if type(v255) == "number" then
			v_u_256 = v251.cooldownUntil > os.time()
		else
			v_u_256 = false
		end
		if v253 then
			local v257 = v_u_93
			local v258 = "REQUESTED"
			local v259 = "Dark"
			local function v268()
				-- upvalues: (ref) v_u_169, (copy) p_u_248, (ref) v_u_38, (ref) v_u_181
				local v260 = v_u_169
				local v261 = "Cancel your request?"
				local v262 = "You asked to join %* %*."
				local v263 = p_u_248
				local v264 = v_u_38.Tag
				if type(v263) == "table" then
					v263 = v263.tag
				end
				local v265 = v264(v263)
				local v266 = p_u_248.name
				local v267 = {
					{
						["text"] = "CANCEL REQUEST",
						["style"] = "Danger",
						["fn"] = nil,
						["fn"] = function() -- name: fn
							-- upvalues: (ref) v_u_181, (ref) p_u_248
							v_u_181("Cancel", p_u_248.id)
						end
					},
					{
						["text"] = "KEEP IT"
					}
				}
				v260(v261, v262:format(v265, (tostring(v266))), v267)
			end
			local v269 = {
				["Width"] = 130,
				["TextSize"] = 15
			}
			if p250 then
				v269.Size = p250
			end
			v257(v258, v259, p249, v268, v269)
			return
		else
			local v270 = p_u_248.members
			if (tonumber(v270) or 0) >= v_u_5.MAX_MEMBERS then
				local v271 = v_u_93
				local v272 = "FULL"
				local v273 = "Dark"
				local function v274() end
				local v275 = {
					["Width"] = 130,
					["Enabled"] = false
				}
				if p250 then
					v275.Size = p250
				end
				v271(v272, v273, p249, v274, v275)
				return
			elseif p_u_248.joinMode == "invite" then
				local v276 = v_u_93
				local v277 = "INVITE ONLY"
				local v278 = "Dark"
				local function v279() end
				local v280 = {
					["Width"] = 130,
					["Enabled"] = false,
					["TextSize"] = 14
				}
				if p250 then
					v280.Size = p250
				end
				v276(v277, v278, p249, v279, v280)
				return
			else
				local v281 = p_u_248.minLevel
				if v254 < (tonumber(v281) or 0) then
					local v282 = v_u_93
					local v283 = ("LV %*+"):format(p_u_248.minLevel)
					local v284 = "Dark"
					local function v285() end
					local v286 = {
						["Width"] = 130,
						["Enabled"] = false
					}
					if p250 then
						v286.Size = p250
					end
					v282(v283, v284, p249, v285, v286)
				else
					local v287 = p_u_248.joinMode == "request" and "ASK TO JOIN" or "JOIN"
					local v288 = v_u_93
					local v289 = "Dark"
					local function v302()
						-- upvalues: (copy) v_u_256, (ref) p_u_27, (ref) v_u_5, (ref) v_u_181, (copy) p_u_248, (ref) v_u_38
						if v_u_256 then
							p_u_27.Toast(v_u_5.Message("cooldown"), "error")
						else
							local v290, v291 = v_u_181("Join", p_u_248.id)
							if v290 and type(v291) == "table" then
								if v291.joined then
									p_u_27.Sounds.Play("Queue_Join")
									local v292 = p_u_27.Toast
									local v293 = "Welcome to %* %*!"
									local v294 = p_u_248
									local v295 = v_u_38.Tag
									if type(v294) == "table" then
										v294 = v294.tag
									end
									local v296 = v295(v294)
									local v297 = p_u_248.name
									v292(v293:format(v296, (tostring(v297))), "success")
									return
								end
								if v291.requested then
									local v298 = p_u_27.Toast
									local v299 = "Request sent to %*"
									local v300 = p_u_248
									local v301 = v_u_38.Tag
									if type(v300) == "table" then
										v300 = v300.tag
									end
									v298(v299:format((v301(v300))), "info")
								end
							end
						end
					end
					local v303 = {
						["Width"] = 130,
						["TextSize"] = nil,
						["Enabled"] = nil,
						["TextSize"] = p_u_248.joinMode == "request" and 15 or 16,
						["Enabled"] = not v_u_256
					}
					if p250 then
						v303.Size = p250
					end
					v288(v287, v289, p249, v302, v303)
				end
			end
		end
	end
	local v_u_305 = 0
	local v_u_306 = nil
	local v_u_307 = nil
	local v_u_308 = nil
	local v_u_309 = ""
	local function v_u_319() -- name: rowsSig
		-- upvalues: (ref) v_u_151, (copy) v_u_53, (copy) v_u_33, (copy) v_u_35
		local v310 = v_u_151 or {}
		local v311 = v_u_151
		if v311 then
			v311 = v_u_151.tribe
		end
		local v312
		if type(v311) == "table" then
			v312 = {
				["id"] = v311.id,
				["role"] = v_u_53(v311)
			}
		else
			v312 = v_u_33.Mine()
		end
		local v313 = v310.requested
		local v314 = {}
		for _, v315 in type(v313) ~= "table" and {} or v310.requested do
			local v316 = tostring(v315)
			table.insert(v314, v316)
		end
		local v317 = v310.cooldownUntil
		local v318
		if type(v317) == "number" then
			v318 = v310.cooldownUntil > os.time()
		else
			v318 = false
		end
		return ("%*|%*|%*|%*"):format(not v312 and 0 or v312.id, table.concat(v314, ","), v318, v_u_35:GetAttribute("Level") or 1)
	end
	local function v_u_331(p320, p321) -- name: drawRows
		-- upvalues: (ref) v_u_309, (copy) v_u_319, (copy) v_u_85, (copy) v_u_185, (copy) v_u_186, (copy) v_u_187, (copy) v_u_174, (copy) v_u_247, (ref) v_u_151, (copy) v_u_53, (copy) v_u_33, (copy) v_u_28, (copy) v_u_31, (copy) v_u_93, (ref) v_u_46, (copy) v_u_304
		v_u_309 = v_u_319()
		v_u_85(v_u_185)
		v_u_186.Visible = #p320 == 0
		v_u_187.Text = v_u_174.Text == "" and "No tribes yet. Found the first one!" or "No tribe matches that."
		for v322, v_u_323 in p320 do
			if type(v_u_323) ~= "table" then
				continue
			end
			local v327 = v_u_247(v_u_323, v_u_185, v322, function(p324)
				-- upvalues: (ref) v_u_151, (ref) v_u_53, (ref) v_u_33, (copy) v_u_323, (ref) v_u_28, (ref) v_u_31, (ref) v_u_93, (ref) v_u_46, (ref) v_u_304
				local v325 = v_u_151
				if v325 then
					v325 = v_u_151.tribe
				end
				local v326
				if type(v325) == "table" then
					v326 = {
						["id"] = v325.id,
						["role"] = v_u_53(v325)
					}
				else
					v326 = v_u_33.Mine()
				end
				if v326 and v326.id == v_u_323.id then
					v_u_28.Pill("YOUR TRIBE", v_u_31.Accent, {
						["Height"] = 26,
						["TextSize"] = 12,
						["Parent"] = nil,
						["Parent"] = p324
					})
					return
				elseif v326 then
					v_u_93("VIEW", "Dark", p324, function()
						-- upvalues: (ref) v_u_46, (ref) v_u_323
						v_u_46(v_u_323.id, v_u_323)
					end, {
						["Width"] = 130
					})
				else
					v_u_304(v_u_323, p324)
				end
			end)
			if not p321 then
				continue
			end
			local v328 = v_u_28.Enter
			local v329 = Vector2.new(0, 10)
			local v330 = v322 * 0.03
			v328(v327, v329, math.min(v330, 0.25), UDim2.new())
		end
	end
	local function v_u_354() -- name: runSearch
		-- upvalues: (copy) v_u_174, (ref) v_u_182, (ref) v_u_308, (ref) v_u_305, (ref) v_u_306, (copy) v_u_33, (ref) v_u_307, (copy) v_u_331, (copy) v_u_85, (copy) v_u_185, (copy) v_u_28, (ref) v_u_37, (copy) v_u_31, (copy) v_u_186, (copy) v_u_187, (ref) v_u_5, (ref) v_u_3, (copy) v_u_319, (ref) v_u_309
		local v332 = v_u_174.Text .. "\n" .. v_u_182
		if v_u_308 == v332 then
			return
		else
			v_u_305 = v_u_305 + 1
			local v333 = v_u_305
			v_u_308 = v332
			local v334 = v_u_306 ~= v332
			local v335 = v_u_174.Text
			local v336
			if v335 == "" then
				v336 = v_u_33.CachedBoard(v_u_182)
			else
				v336 = nil
			end
			if v334 and type(v336) == "table" then
				v_u_306 = v332
				v_u_307 = v336
				v_u_331(v336, true)
				v334 = false
			end
			if v334 then
				v_u_85(v_u_185)
				for v337 = 1, 4 do
					local v338 = v_u_28.new("Frame", {
						["Name"] = "Skeleton",
						["Size"] = UDim2.new(1, -4, 0, v_u_37.row + 8),
						["LayoutOrder"] = v337,
						["BackgroundColor3"] = v_u_31.PanelHi,
						["BackgroundTransparency"] = 0.5,
						v_u_28.Corner(12),
						["Parent"] = v_u_185
					})
					v_u_28.Tween(v338, TweenInfo.new(0.8, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true, v337 * 0.12), {
						["BackgroundTransparency"] = 0.78
					})
				end
				v_u_186.Visible = false
			end
			local v339, v340
			if v335 == "" then
				v339, v340 = v_u_33.Board(v_u_182)
			else
				v339, v340 = v_u_33.Action("Search", v335, v_u_182)
			end
			if v333 == v_u_305 then
				v_u_308 = nil
				if v339 and type(v340) == "table" then
					if not v334 and v_u_307 then
						local v341 = v_u_3.JSONEncode
						local v342 = v_u_3
						local v343, v344 = pcall(v341, v342, v340)
						if not v343 then
							local v345 = os.clock
							v344 = tostring(v345())
						end
						local v346 = v_u_307
						local v347 = v_u_3.JSONEncode
						local v348 = v_u_3
						local v349, v350 = pcall(v347, v348, v346)
						if not v349 then
							local v351 = os.clock
							v350 = tostring(v351())
						end
						if v344 == v350 and v_u_319() == v_u_309 then
							return
						end
					end
					v_u_306 = v332
					v_u_307 = v340
					v_u_331(v340, v334)
				elseif v334 or not v_u_307 then
					v_u_306 = nil
					v_u_307 = nil
					v_u_85(v_u_185)
					v_u_186.Visible = true
					local v352 = v_u_187
					local v353 = v340 or v_u_5.Message("unavailable")
					v352.Text = tostring(v353)
				end
			else
				return
			end
		end
	end
	local v_u_355 = v_u_309
	local v_u_356 = v_u_307
	local v_u_357 = v_u_308
	local function v_u_361() -- name: paintSort
		-- upvalues: (copy) v_u_177, (ref) v_u_182, (copy) v_u_31
		for v358, v359 in v_u_177 do
			v359.BackgroundTransparency = v358 == v_u_182 and 0 or 1
			local v360
			if v358 == v_u_182 then
				v360 = v_u_31.Text
			else
				v360 = v_u_31.TextDim
			end
			v359.TextColor3 = v360
		end
	end
	for v_u_362, v363 in v_u_177 do
		v363.Activated:Connect(function()
			-- upvalues: (ref) v_u_182, (copy) v_u_362, (ref) v_u_152, (copy) p_u_27, (copy) v_u_361, (copy) v_u_354
			if v_u_182 ~= v_u_362 and os.clock() - v_u_152 >= 0.5 then
				v_u_182 = v_u_362
				p_u_27.Sounds.Play("Click")
				v_u_361()
				v_u_354()
			end
		end)
	end
	v_u_174.FocusLost:Connect(function()
		-- upvalues: (copy) v_u_354
		v_u_354()
	end)
	local v_u_364 = {
		{ "three-people", "Play together", "Up to 2x Glory with tribemates" },
		{ "location-pin-map", "Hold the maps", "Most Glory on a map holds it" },
		{ "trophy", "Weekly Tribe Chest", "Item shards every Monday" }
	}
	local v_u_365 = 0
	local v_u_366 = (-1 / 0)
	local function v_u_426(p367) -- name: renderFindLeft
		-- upvalues: (copy) v_u_85, (copy) v_u_170, (ref) v_u_365, (copy) v_u_35, (ref) v_u_5, (copy) v_u_28, (copy) v_u_103, (ref) v_u_37, (copy) v_u_38, (copy) v_u_57, (copy) v_u_32, (copy) v_u_364, (copy) v_u_36, (copy) v_u_31, (copy) v_u_29, (ref) v_u_11, (ref) v_u_152, (copy) p_u_27, (copy) v_u_61, (ref) v_u_12, (ref) v_u_366, (ref) v_u_26, (copy) v_u_70, (copy) v_u_75, (copy) v_u_93, (copy) v_u_181
		v_u_85(v_u_170)
		v_u_365 = v_u_365 + 1
		local v368 = v_u_35:GetAttribute("Level") or 1
		local v369 = p367.cooldownUntil
		local v_u_370
		if type(v369) == "number" then
			v_u_370 = p367.cooldownUntil > os.time()
		else
			v_u_370 = false
		end
		local v371 = p367.foundLevel
		local v372
		if type(v371) == "number" then
			v372 = p367.foundLevel
		else
			v372 = v_u_5.FOUND_LEVEL
		end
		local v373 = v_u_28.Panel({
			["Name"] = "FoundPanel",
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["BackgroundTransparency"] = 0.06,
			["Radius"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, -6, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["Radius"] = UDim.new(0, 14),
			["Parent"] = v_u_170
		})
		v_u_28.Padding(12, 12, 12, 12).Parent = v373
		v_u_28.List(Enum.FillDirection.Vertical, 10).Parent = v373
		local v_u_374, v_u_375 = v_u_103(v373, v_u_37.hero - 30, 1)
		local v_u_376 = v_u_38.new(96, {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["ZIndex"] = 2,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Parent"] = v_u_374
		})
		local v_u_377 = v_u_365
		task.spawn(function()
			-- upvalues: (copy) v_u_377, (ref) v_u_365, (copy) v_u_374, (copy) v_u_376, (ref) v_u_5, (copy) v_u_375, (ref) v_u_28
			local v378 = Random.new()
			while v_u_377 == v_u_365 and v_u_374.Parent do
				local v379 = v378:NextInteger(1, 14)
				v_u_376:Set(v378:NextInteger(1, #v_u_5.ICONS), v379, ({
					v_u_5.WHITE,
					v_u_5.WHITE,
					6,
					20
				})[v378:NextInteger(1, 4)], nil)
				v_u_375(v_u_5.Color(v379))
				v_u_28.Pop(v_u_376.Instance, 0.9)
				task.wait(2.2)
			end
		end)
		v_u_57({
			["Name"] = "Title",
			["Text"] = "FOUND A TRIBE",
			["FontFace"] = nil,
			["TextSize"] = 26,
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["FontFace"] = v_u_32.Display,
			["Size"] = UDim2.new(1, 0, 0, 30),
			["Parent"] = v373
		})
		for v380, v381 in v_u_364 do
			local v382 = v_u_28.new("Frame", {
				["Name"] = "Perk" .. v380,
				["Size"] = UDim2.new(1, 0, 0, 38),
				["LayoutOrder"] = 2 + v380,
				["Parent"] = v373
			})
			local v383 = v_u_28.new("Frame", {
				["Name"] = "Icon",
				["Size"] = v_u_36(32, 32),
				["Position"] = v_u_36(0, 3),
				["BackgroundColor3"] = v_u_31.Accent,
				["BackgroundTransparency"] = 0.8,
				v_u_28.Corner(v_u_29.Radius.Pill),
				["Parent"] = v382
			})
			v_u_28.Glyph(v381[1], 18, v_u_29.Lighten(v_u_31.Accent, 0.3), {
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Parent"] = v383
			})
			v_u_57({
				["Name"] = "Title",
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 15,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = v381[2],
				["FontFace"] = v_u_32.Heavy,
				["Position"] = v_u_36(42, 0),
				["Size"] = UDim2.new(1, -42, 0, 18),
				["Parent"] = v382
			})
			v_u_57({
				["Name"] = "Text",
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 13,
				["TextColor3"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = v381[3],
				["FontFace"] = v_u_32.SemiBold,
				["TextColor3"] = v_u_11,
				["Position"] = v_u_36(42, 19),
				["Size"] = UDim2.new(1, -42, 0, 16),
				["Parent"] = v382
			})
		end
		if v372 <= v368 then
			local v384 = v_u_28.Button({
				["Name"] = "Found",
				["Text"] = "FOUND A TRIBE",
				["Style"] = "Primary",
				["Size"] = nil,
				["LayoutOrder"] = 8,
				["Parent"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 52),
				["Parent"] = v373
			})
			v384.Activated:Connect(function()
				-- upvalues: (ref) v_u_152, (copy) v_u_370, (ref) p_u_27, (ref) v_u_5
				if os.clock() - v_u_152 >= 0.5 then
					if v_u_370 then
						p_u_27.Toast(v_u_5.Message("cooldown"), "error")
					else
						p_u_27.OpenTribeForm("create")
					end
				else
					return
				end
			end)
			if v_u_370 then
				v384:SetEnabled(false)
			end
		else
			local v385 = v_u_28.new("Frame", {
				["Name"] = "Lock",
				["Size"] = UDim2.new(1, 0, 0, 54),
				["LayoutOrder"] = 8,
				["BackgroundColor3"] = v_u_31.Inset,
				["BackgroundTransparency"] = 0.3,
				v_u_28.Corner(10),
				["Parent"] = v373
			})
			v_u_28.Glyph("lock-closed", 18, v_u_31.TextDim, {
				["Position"] = v_u_36(12, 9),
				["Parent"] = v385
			})
			v_u_57({
				["Name"] = "Text",
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 15,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = ("Reach level %* to found a tribe"):format(v372),
				["FontFace"] = v_u_32.Heavy,
				["Position"] = v_u_36(38, 8),
				["Size"] = UDim2.new(1, -110, 0, 20),
				["Parent"] = v385
			})
			v_u_61(("LV %* / %*"):format(v368, v372), {
				["TextXAlignment"] = Enum.TextXAlignment.Right,
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.new(1, -12, 0, 12),
				["Size"] = v_u_36(80, 14),
				["Parent"] = v385
			})
			local v386 = v_u_28.new("Frame", {
				["Name"] = "Bar",
				["Position"] = v_u_36(12, 36),
				["Size"] = UDim2.new(1, -24, 0, 8),
				["BackgroundColor3"] = v_u_12,
				v_u_28.Corner(v_u_29.Radius.Pill),
				["Parent"] = v385
			})
			local v387 = v_u_28.new
			local v388 = {
				["Name"] = "Fill"
			}
			local v389 = UDim2.fromScale
			local v390 = v368 / v372
			v388.Size = v389(math.clamp(v390, 0.03, 1), 1)
			v388.BackgroundColor3 = v_u_31.Accent
			__set_list(v388, 1, {(v_u_28.Corner(v_u_29.Radius.Pill))})
			v388.Parent = v386
			v387("Frame", v388)
			local v_u_391 = p_u_27.Economy
			if v_u_391 and v_u_391.CanBuy("tribe_found") then
				local v_u_392 = v_u_28.Button({
					["Name"] = "FoundNow",
					["Text"] = "",
					["Style"] = "Primary",
					["Size"] = nil,
					["LayoutOrder"] = 9,
					["Parent"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 52),
					["Parent"] = v373
				})
				v_u_392.Label.RichText = true
				local function v_u_396() -- name: paintBuy
					-- upvalues: (copy) v_u_391, (copy) v_u_392, (copy) v_u_370
					local v393 = v_u_391.Pending("tribe_found")
					local v394 = v_u_392
					local v395 = not v393
					if v395 then
						v395 = not v_u_370
					end
					v394:SetEnabled(v395)
					v_u_392:SetText(v393 and "FOUNDING\226\128\166" or string.format("FOUND NOW   <font color=\"#FFFFFF\">%s</font> %s", v_u_391.ROBUX, v_u_391.PriceAmount("tribe_found")))
				end
				v_u_396()
				local v_u_397 = nil
				v_u_397 = v_u_391.Changed:Connect(function()
					-- upvalues: (copy) v_u_392, (copy) v_u_396, (ref) v_u_397
					if v_u_392.Instance.Parent then
						v_u_396()
					else
						v_u_397:Disconnect()
					end
				end)
				v_u_392.Activated:Connect(function()
					-- upvalues: (ref) v_u_152, (copy) v_u_391, (copy) v_u_370, (ref) p_u_27, (ref) v_u_5, (ref) v_u_366
					if os.clock() - v_u_152 >= 0.5 and not v_u_391.Pending("tribe_found") then
						if v_u_370 then
							p_u_27.Toast(v_u_5.Message("cooldown"), "error")
						else
							v_u_366 = os.clock()
							v_u_391.Buy("tribe_found")
						end
					else
						return
					end
				end)
				v_u_61("OR JOIN A TRIBE AT ANY LEVEL", {
					["TextXAlignment"] = nil,
					["LayoutOrder"] = 10,
					["Parent"] = nil,
					["TextXAlignment"] = Enum.TextXAlignment.Center,
					["Parent"] = v373
				})
			else
				v_u_61("YOU CAN JOIN A TRIBE AT ANY LEVEL", {
					["TextXAlignment"] = nil,
					["LayoutOrder"] = 9,
					["Parent"] = nil,
					["TextXAlignment"] = Enum.TextXAlignment.Center,
					["Parent"] = v373
				})
			end
		end
		if v_u_370 then
			v_u_57({
				["Name"] = "Cooldown",
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 13,
				["TextColor3"] = nil,
				["TextWrapped"] = true,
				["TextTruncate"] = nil,
				["AutomaticSize"] = nil,
				["Size"] = nil,
				["LayoutOrder"] = 11,
				["Parent"] = nil,
				["Text"] = ("You left a tribe recently. You can join or found one again in %*."):format((v_u_26(p367.cooldownUntil))),
				["FontFace"] = v_u_32.SemiBold,
				["TextColor3"] = v_u_31.Warning,
				["TextTruncate"] = Enum.TextTruncate.None,
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["Parent"] = v373
			})
		end
		local v398 = p367.invites
		local v399 = type(v398) ~= "table" and {} or p367.invites
		if #v399 > 0 then
			v_u_70("INVITES", #v399, nil, 2, v_u_170, v_u_31.Warning)
			for v400, v401 in v399 do
				local v_u_402 = v401.tribe
				if type(v_u_402) ~= "table" then
					continue
				end
				local v403 = v_u_75("Invite" .. v400, v_u_170, {
					["LayoutOrder"] = 2 + v400
				})
				v_u_28.Padding(12, 12, 12, 12).Parent = v403
				v_u_28.List(Enum.FillDirection.Vertical, 10).Parent = v403
				local v404 = v_u_28.new("Frame", {
					["Name"] = "Top",
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Parent"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 54),
					["Parent"] = v403
				})
				v_u_38.new(50, {
					["Parent"] = v404
				}):Set(v_u_402.icon, v_u_402.color1, v_u_402.color2, v_u_402.tag)
				local v405 = v_u_57
				local v406 = {
					["Name"] = "Name",
					["Text"] = nil,
					["RichText"] = true,
					["FontFace"] = nil,
					["TextSize"] = 16,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil
				}
				local v407 = string.format
				local v408 = "<font color=\"#%s\">%s</font>  %s"
				local v409 = v_u_38.TagColor(v_u_402.color1):ToHex()
				local v410 = v_u_38.Tag
				local v411
				if type(v_u_402) == "table" then
					v411 = v_u_402.tag
				else
					v411 = v_u_402
				end
				local v412 = v410(v411)
				local v413 = v_u_402.name or ""
				v406.Text = v407(v408, v409, v412, (tostring(v413)))
				v406.FontFace = v_u_32.Heavy
				v406.Position = v_u_36(62, 7)
				v406.Size = UDim2.new(1, -62, 0, 20)
				v406.Parent = v404
				v405(v406)
				local v414 = v_u_57
				local v415 = {
					["Name"] = "From",
					["Text"] = nil,
					["FontFace"] = nil,
					["TextSize"] = 13,
					["TextColor3"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil
				}
				local v416 = v401.from or "?"
				local v417 = tostring(v416)
				local v418 = v_u_402.members
				v415.Text = ("%* invited you  \194\183  %*/%* members"):format(v417, tonumber(v418) or 0, v_u_5.MAX_MEMBERS)
				v415.FontFace = v_u_32.SemiBold
				v415.TextColor3 = v_u_11
				v415.Position = v_u_36(62, 29)
				v415.Size = UDim2.new(1, -62, 0, 16)
				v415.Parent = v404
				v414(v415)
				local v419 = v_u_28.new("Frame", {
					["Name"] = "Row",
					["Size"] = UDim2.new(1, 0, 0, 40),
					["LayoutOrder"] = 2,
					v_u_28.List(Enum.FillDirection.Horizontal, 8),
					["Parent"] = v403
				})
				v_u_93("JOIN", "Primary", v419, function()
					-- upvalues: (ref) v_u_181, (copy) v_u_402, (ref) p_u_27, (ref) v_u_38
					if v_u_181("Join", v_u_402.id) then
						p_u_27.Sounds.Play("Queue_Join")
						local v420 = p_u_27.Toast
						local v421 = "Welcome to %* %*!"
						local v422 = v_u_402
						local v423 = v_u_38.Tag
						if type(v422) == "table" then
							v422 = v422.tag
						end
						local v424 = v423(v422)
						local v425 = v_u_402.name
						v420(v421:format(v424, (tostring(v425))), "success")
					end
				end, {
					["Size"] = UDim2.new(0.5, -4, 1, 0)
				})
				v_u_93("DECLINE", "Dark", v419, function()
					-- upvalues: (ref) v_u_181, (copy) v_u_402
					v_u_181("Decline", v_u_402.id)
				end, {
					["Size"] = UDim2.new(0.5, -4, 1, 0)
				})
			end
		end
	end
	function v_u_115.Find()
		-- upvalues: (copy) v_u_361, (copy) v_u_354
		v_u_361()
		v_u_354()
	end
	local v_u_427 = v82("Left", v144.page, 12)
	local v_u_428 = v82("Right", v144.page, 12)
	local v_u_439 = {
		["founded"] = function(p429) -- name: founded
			return ("%* founded the tribe"):format(p429.name)
		end,
		["joined"] = function(p430) -- name: joined
			return ("%* joined"):format(p430.name)
		end,
		["left"] = function(p431) -- name: left
			return ("%* left"):format(p431.name)
		end,
		["kicked"] = function(p432) -- name: kicked
			return ("%* removed %*"):format(p432.by, p432.name)
		end,
		["promoted"] = function(p433) -- name: promoted
			return ("%* is now an Elder"):format(p433.name)
		end,
		["demoted"] = function(p434) -- name: demoted
			return ("%* is now a Member"):format(p434.name)
		end,
		["chief"] = function(p435) -- name: chief
			return ("%* is now the Chief"):format(p435.name)
		end,
		["renamed"] = function(p436) -- name: renamed
			return ("The tribe is now called %*"):format(p436.name)
		end,
		["took"] = function(p437) -- name: took
			-- upvalues: (copy) v_u_33
			if p437.from then
				return ("Took %* from [%*]"):format(v_u_33.MapName(p437.mapId), p437.from)
			else
				return ("Took %*"):format((v_u_33.MapName(p437.mapId)))
			end
		end,
		["lost"] = function(p438) -- name: lost
			-- upvalues: (copy) v_u_33
			return ("[%*] took %*"):format(p438.to, (v_u_33.MapName(p438.mapId)))
		end
	}
	local v_u_440 = {
		["founded"] = { "flag", v_u_31.Accent },
		["joined"] = { "person-plus", v_u_31.Success },
		["left"] = { "door-open-arrow-to-bottom-right", v_u_31.TextMuted },
		["kicked"] = { "door-open-arrow-to-bottom-right", v_u_31.Danger },
		["promoted"] = { "crown", v_u_13 },
		["demoted"] = { "person", v_u_31.TextMuted },
		["chief"] = { "crown", v_u_13 },
		["renamed"] = { "pencil", v_u_31.Accent },
		["took"] = { "location-pin-map", v_u_31.Success },
		["lost"] = { "location-pin-map", v_u_31.Danger }
	}
	local v_u_441 = 0
	local function v_u_469(p442, p443, p444, p445, p_u_446, p447) -- name: heldChips
		-- upvalues: (copy) v_u_28, (copy) v_u_75, (copy) v_u_31, (copy) v_u_57, (copy) v_u_32, (ref) v_u_11, (copy) v_u_36, (copy) v_u_93, (copy) v_u_137, (copy) v_u_33, (ref) v_u_152, (copy) p_u_27
		local v448 = v_u_28.new
		local v449 = "Frame"
		local v450 = {
			["Name"] = "Held",
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, -6, 0, #p442 == 0 and 64 or 0)
		}
		local v451
		if #p442 == 0 then
			v451 = Enum.AutomaticSize.None
		else
			v451 = Enum.AutomaticSize.Y
		end
		v450.AutomaticSize = v451
		v450.LayoutOrder = p444
		v450.Parent = p443
		local v452 = v448(v449, v450)
		if #p442 == 0 then
			local v453 = v_u_75("Empty", v452, {
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["Transparency"] = 0.5,
				["Size"] = UDim2.fromScale(1, 1),
				["AutomaticSize"] = Enum.AutomaticSize.None
			})
			v_u_28.Glyph("location-pin-map", 22, v_u_31.TextMuted, {
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 16, 0.5, 0),
				["Parent"] = v453
			})
			v_u_57({
				["Name"] = "Text",
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 14,
				["TextColor3"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["TextWrapped"] = true,
				["TextTruncate"] = nil,
				["Parent"] = nil,
				["Text"] = p447,
				["FontFace"] = v_u_32.SemiBold,
				["TextColor3"] = v_u_11,
				["Position"] = v_u_36(48, 0),
				["Size"] = UDim2.new(1, -170, 1, 0),
				["TextTruncate"] = Enum.TextTruncate.None,
				["Parent"] = v453
			})
			v_u_93("SEE THE MAP", "Dark", v453, function()
				-- upvalues: (ref) v_u_137
				v_u_137("Territories")
			end, {
				["Width"] = 120,
				["TextSize"] = 14,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Height"] = 38,
				["AnchorPoint"] = Vector2.new(1, 0.5),
				["Position"] = UDim2.new(1, -10, 0.5, 0)
			})
			return v452
		end
		v_u_28.new("UIGridLayout", {
			["CellSize"] = v_u_36(180, 104),
			["CellPadding"] = v_u_36(10, 10),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v452
		})
		local v454 = v_u_33.CachedTerritories()
		local v_u_455 = {}
		for v456, v_u_457 in p442 do
			local v458 = v454 and v454.maps
			if v458 then
				v458 = v454.maps[v_u_457]
			end
			local v459 = v_u_28.new("TextButton", {
				["Name"] = v_u_457,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["LayoutOrder"] = v456,
				["BackgroundColor3"] = v_u_31.Raised,
				["ClipsDescendants"] = true,
				v_u_28.Corner(12),
				["Parent"] = v452
			})
			local v460 = v_u_28.new
			local v461 = {
				["Name"] = "Thumb",
				["Image"] = nil,
				["Size"] = nil,
				["ScaleType"] = nil,
				["Parent"] = nil
			}
			local v462 = v458 and v458.thumb or ""
			v461.Image = tostring(v462)
			v461.Size = UDim2.fromScale(1, 1)
			v461.ScaleType = Enum.ScaleType.Crop
			v461.Parent = v459
			v_u_455[v_u_457] = v460("ImageLabel", v461)
			v_u_28.new("Frame", {
				["Name"] = "Shade",
				["Size"] = UDim2.fromScale(1, 1),
				["BackgroundColor3"] = Color3.new(1, 1, 1),
				v_u_28.Gradient(Color3.new(0, 0, 0), Color3.new(0, 0, 0), 90, NumberSequence.new(1, 0.15)),
				["Parent"] = v459
			})
			v_u_28.new("Frame", {
				["Name"] = "Tint",
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["Parent"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 4),
				["BackgroundColor3"] = p445,
				["Parent"] = v459
			})
			v_u_57({
				["Name"] = "Name",
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 16,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = v_u_33.MapName(v_u_457),
				["FontFace"] = v_u_32.Heavy,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.new(0, 10, 1, -8),
				["Size"] = UDim2.new(1, -20, 0, 20),
				["Parent"] = v459
			})
			v459.Activated:Connect(function()
				-- upvalues: (ref) v_u_152, (ref) p_u_27, (copy) v_u_457, (ref) v_u_137
				if os.clock() - v_u_152 >= 0.5 then
					p_u_27.Sounds.Play("Click")
					p_u_27.TribeMapSelect = v_u_457
					v_u_137("Territories")
				end
			end)
		end
		if not v454 then
			task.spawn(function()
				-- upvalues: (ref) v_u_33, (copy) p_u_446, (copy) v_u_455
				local v463 = v_u_33.Territories(false)
				if p_u_446() and v463 then
					local v464 = v463.maps
					if type(v464) == "table" then
						for v465, v466 in v_u_455 do
							local v467 = v463.maps[v465]
							if not (v466.Parent and v467) then
								continue
							end
							local v468 = v467.thumb or ""
							v466.Image = tostring(v468)
						end
						return
					end
				end
			end)
		end
		return v452
	end
	local function v_u_574(p_u_470) -- name: renderOverview
		-- upvalues: (ref) v_u_441, (copy) v_u_85, (copy) v_u_427, (copy) v_u_428, (copy) v_u_53, (ref) v_u_5, (copy) v_u_28, (copy) v_u_103, (ref) v_u_37, (copy) v_u_38, (copy) v_u_31, (ref) v_u_14, (copy) v_u_36, (copy) v_u_57, (copy) v_u_32, (copy) v_u_61, (ref) v_u_15, (copy) v_u_109, (ref) v_u_13, (copy) v_u_93, (copy) p_u_27, (copy) v_u_169, (copy) v_u_181, (copy) v_u_70, (ref) v_u_26, (copy) v_u_75, (ref) v_u_12, (copy) v_u_29, (copy) v_u_35, (ref) v_u_11, (copy) v_u_469, (copy) v_u_439, (copy) v_u_440, (ref) v_u_21
		v_u_441 = v_u_441 + 1
		local v_u_471 = v_u_441
		v_u_85(v_u_427)
		v_u_85(v_u_428)
		local v472 = v_u_53(p_u_470)
		local v473 = v_u_5.Color(p_u_470.color1)
		local v474 = v_u_28.Panel({
			["Name"] = "Hero",
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["BackgroundTransparency"] = 0.06,
			["Radius"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, -6, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["Radius"] = UDim.new(0, 14),
			["Parent"] = v_u_427
		})
		v_u_28.Padding(12, 12, 12, 12).Parent = v474
		v_u_28.List(Enum.FillDirection.Vertical, 10).Parent = v474
		local v475, v476 = v_u_103(v474, v_u_37.hero, 1)
		v476(v473)
		v_u_38.new(v_u_28.Compact and 78 or 124, {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["ZIndex"] = 2,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.44),
			["Parent"] = v475
		}):Set(p_u_470.icon, p_u_470.color1, p_u_470.color2, p_u_470.tag)
		local v477 = v_u_28.Pill
		local v478 = v_u_38.Tag
		local v479
		if type(p_u_470) == "table" then
			v479 = p_u_470.tag
		else
			v479 = p_u_470
		end
		v477(v478(v479), v_u_31.Void, {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Height"] = 26,
			["TextSize"] = 15,
			["TextColor"] = nil,
			["Transparency"] = 0.3,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, -10),
			["TextColor"] = v_u_38.TagColor(p_u_470.color1),
			["Parent"] = v475
		})
		local v480 = v_u_14[v472]
		if v480 then
			v_u_28.Pill("YOU: " .. v480.text, v480.color, {
				["Position"] = nil,
				["Height"] = 22,
				["TextSize"] = 12,
				["ZIndex"] = 3,
				["Parent"] = nil,
				["Position"] = v_u_36(10, 10),
				["Parent"] = v475
			})
		end
		local v481 = v_u_57
		local v482 = {
			["Name"] = "Name",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextScaled"] = true,
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil
		}
		local v483 = string.upper
		local v484 = p_u_470.name or ""
		v482.Text = v483((tostring(v484)))
		v482.FontFace = v_u_32.Display
		v482.Size = UDim2.new(1, 0, 0, 32)
		v482.Parent = v474
		local v485 = {
			["MaxTextSize"] = 28,
			["MinTextSize"] = 16,
			["Parent"] = nil,
			["Parent"] = v481(v482)
		}
		v_u_28.new("UITextSizeConstraint", v485)
		local v486 = p_u_470.members
		local v487 = tonumber(v486) or 0
		local v488 = p_u_470.membersList
		local v489 = 0
		for _, v490 in type(v488) ~= "table" and {} or p_u_470.membersList do
			if not v490.where then
				continue
			end
			v489 = v489 + 1
		end
		v_u_61(("%*/%* MEMBERS  \194\183  %* ONLINE  \194\183  %*"):format(v487, v_u_5.MAX_MEMBERS, v489, (string.upper(v_u_15[p_u_470.joinMode] or ""))), {
			["LayoutOrder"] = 3,
			["Parent"] = nil,
			["Parent"] = v474
		})
		local v491 = v_u_28.new("Frame", {
			["Name"] = "Stats",
			["Size"] = UDim2.new(1, 0, 0, v_u_28.Compact and 52 or 62),
			["LayoutOrder"] = 4,
			v_u_28.List(Enum.FillDirection.Horizontal, 8),
			["Parent"] = v474
		})
		local v492 = v_u_109(v491, "WEEK RANK", 1)
		local v493 = v_u_109(v491, "GLORY", 2)
		local v494 = v_u_109(v491, "TERRITORIES", 3)
		local v495
		if p_u_470.rank then
			local v496 = p_u_470.rank
			v495 = "#" .. tostring(v496)
		else
			v495 = "-"
		end
		v492.Text = v495
		v493.TextColor3 = v_u_13
		local v497 = p_u_470.territories
		local v498 = type(v497) ~= "table" and {} or p_u_470.territories
		local v499 = #v498
		v494.Text = tostring(v499)
		local v501 = v_u_28.CountUp(v493, function(p500)
			-- upvalues: (ref) v_u_28
			return v_u_28.FormatCompact((math.floor(p500)))
		end, 0.6)
		local v502 = p_u_470.weekRenown
		local v503 = tonumber(v502) or 0
		local v504 = p_u_470.weekRenown
		v501(v503, (tonumber(v504) or 0) == 0)
		local v505 = v_u_28.new("Frame", {
			["Name"] = "Buttons",
			["Size"] = UDim2.new(1, 0, 0, 42),
			["LayoutOrder"] = 5,
			v_u_28.List(Enum.FillDirection.Horizontal, 8),
			["Parent"] = v474
		})
		if v472 == "chief" then
			v_u_93("EDIT TRIBE", "Dark", v505, function()
				-- upvalues: (ref) p_u_27
				p_u_27.OpenTribeForm("settings")
			end, {
				["Size"] = nil,
				["TextSize"] = 15,
				["Icon"] = nil,
				["Size"] = UDim2.new(0.5, -4, 1, 0),
				["Icon"] = v_u_28.Glyph("pencil", 18, v_u_31.Text)
			})
		end
		local v506 = v_u_93
		local v507 = "LEAVE"
		local v508 = "Dark"
		local function v514()
			-- upvalues: (copy) p_u_470, (ref) v_u_169, (ref) v_u_5, (ref) v_u_181, (ref) p_u_27, (ref) v_u_38
			local v509 = p_u_470.members
			v_u_169("Leave the tribe?", (tonumber(v509) or 0) <= 1 and "You\'re the last member: the tribe will be disbanded and its tag freed." or ("You can join another tribe in %* minutes. If you leave before Monday you lose this week\'s chest."):format(v_u_5.LEAVE_COOLDOWN // 60), {
				{
					["text"] = "LEAVE TRIBE",
					["style"] = "Danger",
					["fn"] = nil,
					["fn"] = function() -- name: fn
						-- upvalues: (ref) v_u_181, (ref) p_u_27, (ref) p_u_470, (ref) v_u_38
						if v_u_181("Leave") then
							local v510 = p_u_27.Toast
							local v511 = "You left %*"
							local v512 = p_u_470
							local v513 = v_u_38.Tag
							if type(v512) == "table" then
								v512 = v512.tag
							end
							v510(v511:format((v513(v512))), "info")
						end
					end
				},
				{
					["text"] = "STAY"
				}
			})
		end
		local v515 = {
			["Size"] = nil,
			["TextSize"] = 15,
			["Icon"] = nil
		}
		local v516
		if v472 == "chief" then
			v516 = UDim2.new(0.5, -4, 1, 0)
		else
			v516 = UDim2.new(1, 0, 1, 0)
		end
		v515.Size = v516
		v515.Icon = v_u_28.Glyph("door-open-arrow-to-bottom-right", 18, v_u_31.Text)
		v506(v507, v508, v505, v514, v515)
		local v517 = p_u_470.weekRenown
		local v518 = tonumber(v517) or 0
		local v519 = v_u_5.ChestTier(v518)
		local v520 = v_u_5.CHEST_TIERS[v519 + 1]
		v_u_70("TRIBE CHEST", nil, ("opens Monday 00:00 UTC, in %*"):format((v_u_26(p_u_470.weekEndsAt))), 1, v_u_428, v_u_13)
		local v521 = v_u_75("Chest", v_u_428, {
			["LayoutOrder"] = 2,
			["Transparency"] = 0.25
		})
		v_u_28.Padding(16, 16, 16, 16).Parent = v521
		v_u_28.List(Enum.FillDirection.Vertical, 12).Parent = v521
		local v522 = v_u_28.new("Frame", {
			["Name"] = "Track",
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 58),
			["Parent"] = v521
		})
		local v523 = v_u_28.new("Frame", {
			["Name"] = "Line",
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 18, 0, 18),
			["Size"] = UDim2.new(1, -36, 0, 8),
			["BackgroundColor3"] = v_u_12,
			v_u_28.Corner(v_u_29.Radius.Pill),
			["Parent"] = v522
		})
		local v524 = v_u_5.CHEST_TIERS
		local v525 = 0
		for v526 = 1, #v524 do
			local v527 = v526 == 1 and 0 or v524[v526 - 1]
			if v524[v526] > v518 then
				local v528 = (v518 - v527) / (v524[v526] - v527)
				v525 = v525 + math.clamp(v528, 0, 1) / #v524
				break
			end
			v525 = v526 / #v524
		end
		local v529 = v_u_28.new("Frame", {
			["Name"] = "Fill",
			["Size"] = UDim2.fromScale(0, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			v_u_28.Corner(v_u_29.Radius.Pill),
			["Parent"] = v523
		})
		v_u_28.Gradient(Color3.fromRGB(255, 214, 110), v_u_13, 0).Parent = v529
		v_u_28.Tween(v529, TweenInfo.new(0.7, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
			["Size"] = UDim2.fromScale(math.clamp(v525, 0, 1), 1)
		})
		for v530, v531 in v524 do
			local v532 = v531 <= v518
			local v533 = v530 / #v524
			local v534 = v_u_28.new
			local v535 = "Frame"
			local v536 = {
				["Name"] = "Node" .. v530,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.new(v533, v530 == #v524 and -4 or 0, 0.5, 0),
				["Size"] = v_u_36(34, 34)
			}
			local v537
			if v532 then
				v537 = v_u_13
			else
				v537 = v_u_31.Raised
			end
			v536.BackgroundColor3 = v537
			v536.ZIndex = 2
			local v538 = v_u_28.Corner(v_u_29.Radius.Pill)
			local v539 = v_u_28.Stroke
			local v540
			if v532 then
				v540 = Color3.fromRGB(255, 226, 150)
			elseif v530 == v519 + 1 then
				v540 = v_u_13
			else
				v540 = v_u_31.StrokeSoft
			end
			__set_list(v536, 1, {v538, (v539(v540, 2, 0))})
			v536.Parent = v523
			local v541 = v534(v535, v536)
			local v542 = v_u_57
			local v543 = {
				["Name"] = "N",
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 17,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["Size"] = nil,
				["ZIndex"] = 3,
				["Parent"] = nil,
				["Text"] = tostring(v530),
				["FontFace"] = v_u_32.Display
			}
			local v544
			if v532 then
				v544 = v_u_31.TextDark
			else
				v544 = v_u_31.TextDim
			end
			v543.TextColor3 = v544
			v543.TextXAlignment = Enum.TextXAlignment.Center
			v543.Size = UDim2.fromScale(1, 1)
			v543.Parent = v541
			v542(v543)
			v_u_61(v_u_28.FormatCompact(v531), {
				["TextXAlignment"] = Enum.TextXAlignment.Center,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(v533, v530 == #v524 and -4 or 0, 0, 40),
				["Size"] = v_u_36(60, 14),
				["Parent"] = v522
			})
			if v530 ~= v519 then
				continue
			end
			v_u_28.Pop(v541, 1.25)
		end
		local v545 = p_u_470.membersList
		local v546 = 0
		for _, v547 in type(v545) ~= "table" and {} or p_u_470.membersList do
			if v547.userId ~= v_u_35.UserId then
				continue
			end
			local v548 = v547.weekRenown
			v546 = tonumber(v548) or 0
		end
		local v549 = v_u_28.new("Frame", {
			["Name"] = "Info",
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 40),
			["Parent"] = v521
		})
		local v550 = v_u_57
		local v551 = {
			["Name"] = "Tribe",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 20,
			["TextColor3"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v519 <= 0 and "NO CHEST YET" or ("TIER %*"):format(v519),
			["FontFace"] = v_u_32.Display
		}
		local v552
		if v519 > 0 then
			v552 = v_u_13
		else
			v552 = v_u_31.TextDim
		end
		v551.TextColor3 = v552
		v551.Size = UDim2.new(0.5, 0, 0, 22)
		v551.Parent = v549
		v550(v551)
		v_u_57({
			["Name"] = "TribeSub",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 13,
			["TextColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = not v520 and "Top tier this week" or ("%* more Glory for tier %*"):format(v_u_28.FormatNumber(v520 - v518), v519 + 1),
			["FontFace"] = v_u_32.SemiBold,
			["TextColor3"] = v_u_11,
			["Position"] = v_u_36(0, 23),
			["Size"] = UDim2.new(0.5, 0, 0, 16),
			["Parent"] = v549
		})
		local v553 = v_u_5.CHEST_MIN <= v546
		local v554 = v_u_57
		local v555 = {
			["Name"] = "You",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 20,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil
		}
		local v556
		if v553 then
			v556 = ("YOU: %* GLORY"):format(v546)
		else
			v556 = ("YOU: %* / %*"):format(v546, v_u_5.CHEST_MIN)
		end
		v555.Text = v556
		v555.FontFace = v_u_32.Display
		local v557
		if v553 then
			v557 = v_u_31.Success
		else
			v557 = v_u_31.Warning
		end
		v555.TextColor3 = v557
		v555.TextXAlignment = Enum.TextXAlignment.Right
		v555.AnchorPoint = Vector2.new(1, 0)
		v555.Position = UDim2.new(1, 0, 0, 0)
		v555.Size = UDim2.new(0.5, 0, 0, 22)
		v555.Parent = v549
		v554(v555)
		v_u_57({
			["Name"] = "YouSub",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 13,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v553 and "You\'ll get this chest" or ("Earn %* more to get this chest"):format(v_u_5.CHEST_MIN - v546),
			["FontFace"] = v_u_32.SemiBold,
			["TextColor3"] = v_u_11,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, 0, 0, 23),
			["Size"] = UDim2.new(0.5, 0, 0, 16),
			["Parent"] = v549
		})
		v_u_70("TERRITORIES", #v498, #v498 == 0 and "win matches on a map to take it" or "held this week", 3, v_u_428)
		v_u_469(v498, v_u_428, 4, v473, function()
			-- upvalues: (copy) v_u_471, (ref) v_u_441
			return v_u_471 == v_u_441
		end, "No territories yet. The tribe with the most Glory on a map this week holds it.")
		local v558 = p_u_470.feed
		local v559 = type(v558) ~= "table" and {} or p_u_470.feed
		v_u_70("ACTIVITY", nil, nil, 5, v_u_428)
		local v560 = v_u_75("Feed", v_u_428, {
			["LayoutOrder"] = 6,
			["Transparency"] = 0.5
		})
		v_u_28.List(Enum.FillDirection.Vertical, 0).Parent = v560
		local v561 = 0
		for v562, v563 in v559 do
			local v564 = v_u_439
			local v565 = v563.kind
			local v566 = v564[tostring(v565)]
			if not v566 then
				continue
			end
			local v567 = v563.data
			if type(v567) ~= "table" or v561 >= 20 then
				continue
			end
			v561 = v561 + 1
			local v568 = v_u_440[v563.kind] or { "flag", v_u_31.Accent }
			local v569 = v_u_28.new("Frame", {
				["Name"] = "F" .. v562,
				["Size"] = UDim2.new(1, 0, 0, 44),
				["LayoutOrder"] = v562,
				["BackgroundColor3"] = v_u_31.Void,
				["BackgroundTransparency"] = v561 % 2 == 0 and 0.85 or 1,
				["Parent"] = v560
			})
			local v570 = v_u_28.new("Frame", {
				["Name"] = "Icon",
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 12, 0.5, 0),
				["Size"] = v_u_36(28, 28),
				["BackgroundColor3"] = v568[2],
				["BackgroundTransparency"] = 0.8,
				v_u_28.Corner(v_u_29.Radius.Pill),
				["Parent"] = v569
			})
			v_u_28.Glyph(v568[1], 16, v568[2], {
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Parent"] = v570
			})
			local v571 = v563.data
			local v572, v573 = pcall(v566, v571)
			v_u_57({
				["Name"] = "Text",
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 15,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = not v572 and "" or v573,
				["FontFace"] = v_u_32.Bold,
				["Position"] = v_u_36(50, 0),
				["Size"] = UDim2.new(1, -150, 1, 0),
				["Parent"] = v569
			})
			v_u_61(string.upper((v_u_21(v563.at))), {
				["TextXAlignment"] = Enum.TextXAlignment.Right,
				["AnchorPoint"] = Vector2.new(1, 0.5),
				["Position"] = UDim2.new(1, -14, 0.5, 0),
				["Size"] = v_u_36(90, 14),
				["Parent"] = v569
			})
		end
		if v561 == 0 then
			v_u_57({
				["Name"] = "NoFeed",
				["Text"] = "Nothing yet.",
				["FontFace"] = nil,
				["TextSize"] = 14,
				["TextColor3"] = nil,
				["Size"] = nil,
				["Position"] = nil,
				["Parent"] = nil,
				["FontFace"] = v_u_32.SemiBold,
				["TextColor3"] = v_u_11,
				["Size"] = UDim2.new(1, -24, 0, 40),
				["Position"] = v_u_36(12, 0),
				["Parent"] = v560
			})
		end
	end
	local v575 = v_u_28.new("Frame", {
		["Name"] = "Head",
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 40),
		["Parent"] = v145.page
	})
	local v_u_576 = v_u_28.new("Frame", {
		["Name"] = "TitleHolder",
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, -220, 1, 0),
		["Parent"] = v575
	})
	local v_u_577 = v_u_28.new("Frame", {
		["Name"] = "InviteSlot",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -10, 0, 0),
		["Size"] = v_u_36(200, 40),
		["Parent"] = v575
	})
	local v578 = v_u_28.new("Frame", {
		["Name"] = "Cols",
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = v_u_36(0, 48),
		["Size"] = UDim2.new(1, -14, 0, 16),
		["Parent"] = v145.page
	})
	local v_u_579 = v_u_365
	local v_u_580 = v_u_366
	for _, v581 in {
		{ "PLAYER", 0 },
		{ "GLORY", -300 },
		{ "STATUS", -190 }
	} do
		local v582 = v581[1]
		local v583 = {}
		local v584
		if v581[2] == 0 then
			v584 = v_u_36(16, 0)
		else
			v584 = UDim2.new(1, v581[2], 0, 0)
		end
		v583.Position = v584
		v583.Size = v_u_36(110, 14)
		local v585
		if v581[2] == 0 then
			v585 = Enum.TextXAlignment.Left
		else
			v585 = Enum.TextXAlignment.Center
		end
		v583.TextXAlignment = v585
		v583.Parent = v578
		v_u_61(v582, v583)
	end
	local v_u_586 = v_u_28.new("ScrollingFrame", {
		["Name"] = "List",
		["Position"] = v_u_36(0, 70),
		["Size"] = UDim2.new(1, 0, 1, -70),
		["ScrollBarThickness"] = 3,
		["Selectable"] = false,
		v_u_28.List(Enum.FillDirection.Vertical, 6),
		v_u_28.Padding(4, 10, 10, 4),
		["Parent"] = v145.page
	})
	local function v_u_603(p_u_587, p_u_588) -- name: manage
		-- upvalues: (copy) v_u_53, (copy) v_u_181, (copy) v_u_169, (copy) v_u_38
		local v589 = {}
		if v_u_53(p_u_588) == "chief" then
			if p_u_587.role == "member" then
				local v590 = {
					["text"] = "PROMOTE TO ELDER",
					["style"] = "Primary",
					["fn"] = nil,
					["fn"] = function() -- name: fn
						-- upvalues: (ref) v_u_181, (copy) p_u_587
						v_u_181("Role", p_u_587.userId, "elder")
					end
				}
				table.insert(v589, v590)
			elseif p_u_587.role == "elder" then
				local v591 = {
					["text"] = "DEMOTE TO MEMBER",
					["fn"] = nil,
					["fn"] = function() -- name: fn
						-- upvalues: (ref) v_u_181, (copy) p_u_587
						v_u_181("Role", p_u_587.userId, "member")
					end
				}
				table.insert(v589, v591)
			end
			local v593 = {
				["text"] = "MAKE CHIEF",
				["fn"] = nil,
				["fn"] = function() -- name: fn
					-- upvalues: (ref) v_u_169, (copy) p_u_587, (ref) v_u_181
					local v592 = {
						{
							["text"] = "MAKE CHIEF",
							["style"] = "Primary",
							["fn"] = nil,
							["fn"] = function() -- name: fn
								-- upvalues: (ref) v_u_181, (ref) p_u_587
								v_u_181("Role", p_u_587.userId, "chief")
							end
						},
						{
							["text"] = "CANCEL"
						}
					}
					v_u_169(("Make %* the Chief?"):format(p_u_587.display), "You\'ll become an Elder. Only the Chief can change ranks and edit the tribe.", v592)
				end
			}
			table.insert(v589, v593)
		end
		local v600 = {
			["text"] = "REMOVE FROM TRIBE",
			["style"] = "Danger",
			["fn"] = nil,
			["fn"] = function() -- name: fn
				-- upvalues: (ref) v_u_169, (copy) p_u_587, (copy) p_u_588, (ref) v_u_38, (ref) v_u_181
				local v594 = v_u_169
				local v595 = ("Remove %*?"):format(p_u_587.display)
				local v596 = "They\'ll leave %*. They can be invited again."
				local v597 = p_u_588
				local v598 = v_u_38.Tag
				if type(v597) == "table" then
					v597 = v597.tag
				end
				local v599 = {
					{
						["text"] = "REMOVE",
						["style"] = "Danger",
						["fn"] = nil,
						["fn"] = function() -- name: fn
							-- upvalues: (ref) v_u_181, (ref) p_u_587
							v_u_181("Kick", p_u_587.userId)
						end
					},
					{
						["text"] = "CANCEL"
					}
				}
				v594(v595, v596:format((v598(v597))), v599)
			end
		}
		table.insert(v589, v600)
		table.insert(v589, {
			["text"] = "CANCEL"
		})
		local v601 = v_u_169
		local v602 = p_u_587.display
		v601(tostring(v602), ("@%*  \194\183  Level %*"):format(p_u_587.name, p_u_587.level), v589)
	end
	local v_u_604 = {
		["hub"] = { "IN LOBBY", v_u_31.Success },
		["match"] = { "IN MATCH", v_u_31.Warning },
		["custom"] = { "CUSTOM MATCH", v_u_31.Warning }
	}
	local function v_u_655(p_u_605, p_u_606, p607) -- name: memberRow
		-- upvalues: (copy) v_u_53, (copy) v_u_35, (copy) v_u_28, (ref) v_u_37, (copy) v_u_31, (copy) v_u_586, (copy) v_u_36, (copy) v_u_29, (copy) v_u_604, (copy) v_u_57, (copy) v_u_32, (ref) v_u_14, (ref) v_u_11, (ref) v_u_5, (ref) v_u_13, (ref) v_u_21, (ref) v_u_1, (ref) v_u_152, (copy) p_u_27, (copy) v_u_169, (copy) v_u_181, (copy) v_u_34, (copy) v_u_603
		local v608 = v_u_53(p_u_606)
		local v609 = p_u_605.userId == v_u_35.UserId
		local v610 = v_u_28.new
		local v611 = "Frame"
		local v612 = {}
		local v613 = p_u_605.userId
		v612.Name = "M" .. tostring(v613)
		v612.Size = UDim2.new(1, -4, 0, v_u_37.row)
		v612.LayoutOrder = p607
		local v614
		if v609 then
			v614 = v_u_31.AccentDeep
		else
			v614 = v_u_31.PanelHi
		end
		v612.BackgroundColor3 = v614
		v612.BackgroundTransparency = v609 and 0.45 or (p607 % 2 == 0 and 0.55 or 0.35)
		__set_list(v612, 1, {(v_u_28.Corner(12))})
		v612.Parent = v_u_586
		local v615 = v610(v611, v612)
		if v609 then
			v_u_28.Stroke(v_u_31.Accent, 1, 0.45).Parent = v615
		end
		local v616 = v_u_37.row - 18
		local v617 = v_u_28.new("ImageLabel", {
			["Name"] = "Head",
			["Image"] = ("rbxthumb://type=AvatarHeadShot&id=%*&w=150&h=150"):format(p_u_605.userId),
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 12, 0.5, 0),
			["Size"] = v_u_36(v616, v616),
			["BackgroundColor3"] = v_u_31.Raised,
			v_u_28.Corner(v_u_29.Radius.Pill),
			["Parent"] = v615
		})
		local v618
		if p_u_605.where == false then
			v618 = false
		else
			v618 = p_u_605.where ~= nil
		end
		if v618 then
			v_u_28.new("Frame", {
				["Name"] = "Dot",
				["AnchorPoint"] = Vector2.new(1, 1),
				["Position"] = UDim2.fromScale(1.02, 1.02),
				["Size"] = v_u_36(13, 13),
				["BackgroundColor3"] = (v_u_604[p_u_605.where] or v_u_604.hub)[2],
				v_u_28.Corner(v_u_29.Radius.Pill),
				v_u_28.Stroke(v_u_31.Panel, 2, 0),
				["Parent"] = v617
			})
		else
			v617.ImageTransparency = 0.35
		end
		local v619 = v616 + 26
		local v620 = v_u_28.new
		local v621 = {
			["Name"] = "NameRow"
		}
		local v622 = v_u_36
		local v623 = v_u_37.row / 2
		v621.Position = v622(v619, math.floor(v623) - v_u_37.text - 2)
		v621.Size = UDim2.new(1, -(v619 + 420), 0, v_u_37.text + 4)
		__set_list(v621, 1, {(v_u_28.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center))})
		v621.Parent = v615
		local v624 = v620("Frame", v621)
		local v625 = v_u_57
		local v626 = {
			["Name"] = "Name",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil
		}
		local v627 = p_u_605.display
		v626.Text = tostring(v627) .. (v609 and "  (you)" or "")
		v626.FontFace = v_u_32.Heavy
		v626.TextSize = v_u_37.text
		v626.AutomaticSize = Enum.AutomaticSize.X
		v626.Size = v_u_36(0, v_u_37.text + 4)
		v626.Parent = v624
		v625(v626)
		local v628 = v_u_14[p_u_605.role]
		if v628 then
			v_u_28.Pill(v628.text, v628.color, {
				["LayoutOrder"] = 2,
				["Height"] = 20,
				["TextSize"] = 11,
				["Parent"] = nil,
				["Parent"] = v624
			})
		end
		local v629 = v_u_57
		local v630 = {
			["Name"] = "Sub",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = ("@%*  \194\183  Lv %*"):format(p_u_605.name, p_u_605.level),
			["FontFace"] = v_u_32.SemiBold,
			["TextSize"] = v_u_37.sub,
			["TextColor3"] = v_u_11
		}
		local v631 = v_u_36
		local v632 = v_u_37.row / 2
		v630.Position = v631(v619, math.floor(v632) + 3)
		v630.Size = UDim2.new(1, -(v619 + 420), 0, v_u_37.sub + 2)
		v630.Parent = v615
		v629(v630)
		local v633 = p_u_605.weekRenown
		local v634 = tonumber(v633) or 0
		local v635 = v_u_57
		local v636 = {
			["Name"] = "Renown",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 20,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = tostring(v634),
			["FontFace"] = v_u_32.Display
		}
		local v637
		if v_u_5.CHEST_MIN <= v634 then
			v637 = v_u_13
		else
			v637 = v_u_31.TextDim
		end
		v636.TextColor3 = v637
		v636.TextXAlignment = Enum.TextXAlignment.Center
		v636.AnchorPoint = Vector2.new(0, 0.5)
		v636.Position = UDim2.new(1, -300, 0.5, 0)
		v636.Size = v_u_36(110, 24)
		v636.Parent = v615
		v635(v636)
		local v638
		if v618 then
			v638 = v_u_604[p_u_605.where] or v_u_604.hub
		else
			v638 = {}
			local v639 = p_u_605.lastSeen
			__set_list(v638, 1, {(tonumber(v639) or 0) <= 0 and "OFFLINE" or string.upper((v_u_21(p_u_605.lastSeen))), v_u_31.TextMuted})
		end
		local v640 = v_u_28.Pill
		local v641 = v638[1]
		local v642 = v638[2]
		local v643 = {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Height"] = 22,
			["TextSize"] = 11,
			["Transparency"] = nil,
			["TextColor"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(1, -135, 0.5, 0),
			["Transparency"] = v618 and 0.15 or 0.75
		}
		local v644
		if v618 then
			v644 = v_u_31.TextDark
		else
			v644 = v_u_31.TextDim
		end
		v643.TextColor = v644
		v643.Parent = v615
		v640(v641, v642, v643).Name = "Status"
		local v645 = v_u_28.new("Frame", {
			["Name"] = "Actions",
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -10, 0.5, 0),
			["Size"] = v_u_36(78, 40),
			v_u_28.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
			["Parent"] = v615
		})
		if not v609 then
			if v_u_1:GetPlayerByUserId(p_u_605.userId) then
				local v646 = v_u_28.IconButton({
					["Name"] = "Invite",
					["Size"] = nil,
					["Color"] = nil,
					["LayoutOrder"] = 1,
					["Parent"] = nil,
					["Size"] = v_u_36(38, 38),
					["Color"] = v_u_31.Accent,
					["Parent"] = v645
				})
				v_u_28.Glyph("person-plus", 18, v_u_31.Text, {
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Parent"] = v646
				})
				v646.Activated:Connect(function()
					-- upvalues: (ref) v_u_152, (ref) p_u_27, (copy) p_u_605
					if os.clock() - v_u_152 >= 0.5 then
						local v647, v648, v649 = p_u_27.Remotes.Invoke("PartyAction", "Invite", p_u_605.userId)
						if v647 and v648 == true then
							p_u_27.Toast(("Party invite sent to %*"):format(p_u_605.display), "success")
						else
							p_u_27.Toast(tostring(v647 and (v649 or "Couldn\'t invite them") or v648), "error")
						end
					else
						return
					end
				end)
			elseif p_u_605.where == "hub" and (p_u_605.jobId and p_u_605.jobId ~= game.JobId) then
				local v650 = v_u_28.IconButton({
					["Name"] = "Join",
					["Size"] = nil,
					["Color"] = nil,
					["LayoutOrder"] = 1,
					["Parent"] = nil,
					["Size"] = v_u_36(38, 38),
					["Color"] = v_u_31.Accent,
					["Parent"] = v645
				})
				v_u_28.Glyph("person-teleport", 18, v_u_31.Text, {
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Parent"] = v650
				})
				v650.Activated:Connect(function()
					-- upvalues: (ref) v_u_152, (ref) v_u_169, (copy) p_u_605, (ref) v_u_181, (ref) p_u_27, (ref) v_u_34
					if os.clock() - v_u_152 >= 0.5 then
						local v651 = {
							{
								["text"] = "JOIN THEIR LOBBY",
								["style"] = "Primary",
								["fn"] = nil,
								["fn"] = function() -- name: fn
									-- upvalues: (ref) v_u_181, (ref) p_u_605, (ref) p_u_27, (ref) v_u_34
									if v_u_181("Visit", p_u_605.userId) then
										p_u_27.Toast(("Joining %*\'s lobby..."):format(p_u_605.display), "info")
										v_u_34.Close("Tribe")
									end
								end
							},
							{
								["text"] = "CANCEL"
							}
						}
						v_u_169(("Join %*?"):format(p_u_605.display), "You\'ll move to their lobby.", v651)
					end
				end)
			end
			local v652 = p_u_605.role
			local v653
			if v608 == "chief" and v652 ~= "chief" then
				v653 = true
			elseif v608 == "elder" then
				v653 = v652 == "member"
			else
				v653 = false
			end
			if v653 then
				local v654 = v_u_28.IconButton({
					["Name"] = "Manage",
					["Size"] = nil,
					["Color"] = nil,
					["LayoutOrder"] = 2,
					["Parent"] = nil,
					["Size"] = v_u_36(38, 38),
					["Color"] = v_u_31.Raised,
					["Parent"] = v645
				})
				v_u_28.Glyph("three-dots-horizontal", 18, v_u_31.Text, {
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Parent"] = v654
				})
				v654.Activated:Connect(function()
					-- upvalues: (ref) v_u_152, (ref) v_u_603, (copy) p_u_605, (copy) p_u_606
					if os.clock() - v_u_152 >= 0.5 then
						v_u_603(p_u_605, p_u_606)
					end
				end)
			end
		end
		return v615
	end
	local function v_u_669() -- name: invitePicker
		-- upvalues: (copy) v_u_169, (copy) v_u_28, (ref) v_u_151, (copy) v_u_53, (copy) v_u_33, (ref) v_u_1, (copy) v_u_35, (copy) v_u_31, (copy) v_u_36, (copy) v_u_29, (copy) v_u_57, (copy) v_u_32, (copy) v_u_93, (copy) v_u_181, (ref) v_u_11
		v_u_169("Invite players", "Players in this lobby who aren\'t in a tribe. Invites last 24 hours.", {
			{
				["text"] = "DONE"
			}
		}, function(p656)
			-- upvalues: (ref) v_u_28, (ref) v_u_151, (ref) v_u_53, (ref) v_u_33, (ref) v_u_1, (ref) v_u_35, (ref) v_u_31, (ref) v_u_36, (ref) v_u_29, (ref) v_u_57, (ref) v_u_32, (ref) v_u_93, (ref) v_u_181, (ref) v_u_11
			v_u_28.List(Enum.FillDirection.Vertical, 6).Parent = p656
			local v657 = 0
			local v658 = v_u_151
			if v658 then
				v658 = v_u_151.tribe
			end
			local v659
			if type(v658) == "table" then
				v659 = {
					["id"] = v658.id,
					["role"] = v_u_53(v658)
				}
			else
				v659 = v_u_33.Mine()
			end
			local v660 = {}
			local v661
			if v659 then
				local v662 = v659.invites
				v661 = type(v662) ~= "table" and {} or v659.invites
			else
				v661 = {}
			end
			for _, v663 in v661 do
				if type(v663) ~= "table" then
					continue
				end
				local v664 = v663.userId
				if type(v664) ~= "number" then
					continue
				end
				v660[v663.userId] = true
			end
			for _, v_u_665 in v_u_1:GetPlayers() do
				local v666 = v_u_665:GetAttribute("TribeId")
				if v_u_665 == v_u_35 or type(v666) == "number" and v666 ~= 0 then
					continue
				end
				v657 = v657 + 1
				local v667 = v_u_28.new("Frame", {
					["Name"] = v_u_665.Name,
					["Size"] = UDim2.new(1, 0, 0, 46),
					["LayoutOrder"] = v657,
					["ZIndex"] = 22,
					["BackgroundColor3"] = v_u_31.PanelHi,
					["BackgroundTransparency"] = 0.5,
					v_u_28.Corner(10),
					["Parent"] = p656
				})
				v_u_28.new("ImageLabel", {
					["Name"] = "Head",
					["Image"] = ("rbxthumb://type=AvatarHeadShot&id=%*&w=150&h=150"):format(v_u_665.UserId),
					["Position"] = v_u_36(6, 5),
					["Size"] = v_u_36(36, 36),
					["BackgroundColor3"] = v_u_31.Raised,
					["ZIndex"] = 22,
					v_u_28.Corner(v_u_29.Radius.Pill),
					["Parent"] = v667
				})
				v_u_57({
					["Name"] = "Name",
					["Text"] = nil,
					["FontFace"] = nil,
					["TextSize"] = 16,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 22,
					["Parent"] = nil,
					["Text"] = v_u_665.DisplayName,
					["FontFace"] = v_u_32.Heavy,
					["Position"] = v_u_36(52, 0),
					["Size"] = UDim2.new(1, -160, 1, 0),
					["Parent"] = v667
				})
				local v_u_668 = nil
				v_u_668 = v_u_93("INVITE", "Primary", v667, function()
					-- upvalues: (ref) v_u_181, (copy) v_u_665, (ref) v_u_668
					if v_u_181("Invite", v_u_665.UserId) then
						v_u_668:SetText("SENT")
						v_u_668:SetEnabled(false)
					end
				end, {
					["Width"] = 96,
					["Height"] = 36,
					["TextSize"] = 15,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["AnchorPoint"] = Vector2.new(1, 0.5),
					["Position"] = UDim2.new(1, -6, 0.5, 0)
				})
				v_u_668.Instance.ZIndex = 23
				if not v660[v_u_665.UserId] then
					continue
				end
				v_u_668:SetText("SENT")
				v_u_668:SetEnabled(false)
			end
			if v657 == 0 then
				v_u_57({
					["Name"] = "None",
					["Text"] = "Nobody to invite here right now.",
					["FontFace"] = nil,
					["TextSize"] = 15,
					["TextColor3"] = nil,
					["Size"] = nil,
					["ZIndex"] = 22,
					["Parent"] = nil,
					["FontFace"] = v_u_32.SemiBold,
					["TextColor3"] = v_u_11,
					["Size"] = UDim2.new(1, 0, 0, 30),
					["Parent"] = p656
				})
			end
		end)
	end
	local v_u_670 = {}
	local function v_u_704(p671, p672) -- name: pendingRow
		-- upvalues: (copy) v_u_28, (ref) v_u_37, (copy) v_u_31, (copy) v_u_586, (copy) v_u_36, (copy) v_u_29, (copy) v_u_57, (copy) v_u_32, (ref) v_u_21, (ref) v_u_11, (copy) v_u_670, (ref) v_u_1, (copy) v_u_93, (copy) v_u_181, (copy) p_u_27
		local v673 = p671.userId
		local v_u_674 = tonumber(v673) or 0
		local v675 = v_u_28.new("Frame", {
			["Name"] = "I" .. tostring(v_u_674),
			["Size"] = UDim2.new(1, -4, 0, v_u_37.row),
			["LayoutOrder"] = p672,
			["BackgroundColor3"] = v_u_31.PanelHi,
			["BackgroundTransparency"] = 0.55,
			v_u_28.Corner(12),
			["Parent"] = v_u_586
		})
		v_u_28.new("ImageLabel", {
			["Name"] = "Head",
			["Image"] = ("rbxthumb://type=AvatarHeadShot&id=%*&w=150&h=150"):format(v_u_674),
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 12, 0.5, 0),
			["Size"] = v_u_36(v_u_37.row - 18, v_u_37.row - 18),
			["BackgroundColor3"] = v_u_31.Raised,
			v_u_28.Corner(v_u_29.Radius.Pill),
			["Parent"] = v675
		})
		local v676 = v_u_37.row + 8
		local v677 = p671.display
		local v678
		if type(v677) == "string" and p671.display ~= "" then
			v678 = p671.display
		else
			v678 = nil
		end
		local v679 = p671.name
		local v680
		if type(v679) == "string" and p671.name ~= "" then
			v680 = p671.name
		else
			v680 = nil
		end
		local v681 = v_u_57
		local v682 = {
			["Name"] = "Name",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v678 or (v680 or "Player"),
			["FontFace"] = v_u_32.Heavy,
			["TextSize"] = v_u_37.text
		}
		local v683 = v_u_36
		local v684 = v_u_37.row / 2
		v682.Position = v683(v676, math.floor(v684) - v_u_37.text - 2)
		v682.Size = UDim2.new(1, -(v676 + 150), 0, v_u_37.text + 4)
		v682.Parent = v675
		local v_u_685 = v681(v682)
		local v686 = p671.expiresAt
		local v687 = (tonumber(v686) or 0) - os.time()
		local v688 = math.max(0, v687)
		local v689
		if v688 >= 3600 then
			v689 = ("%*h"):format(v688 // 3600)
		else
			local v690 = v688 // 60
			v689 = ("%*m"):format((math.max(1, v690)))
		end
		local v691
		if v680 and (v678 == nil or string.lower(v680) ~= string.lower(v678)) then
			v691 = v680
		else
			v691 = nil
		end
		local v692 = v_u_57
		local v693 = {
			["Name"] = "Sub",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil
		}
		local v694 = not v691 and "" or ("@%*  \194\183  "):format(v691)
		local v695 = p671.from or "?"
		v693.Text = ("%*invited by %* %*  \194\183  expires in %*"):format(v694, tostring(v695), v_u_21(p671.at), v689)
		v693.FontFace = v_u_32.SemiBold
		v693.TextSize = v_u_37.sub
		v693.TextColor3 = v_u_11
		local v696 = v_u_36
		local v697 = v_u_37.row / 2
		v693.Position = v696(v676, math.floor(v697) + 3)
		v693.Size = UDim2.new(1, -(v676 + 150), 0, v_u_37.sub + 2)
		v693.Parent = v675
		v692(v693)
		if not v678 and (not v680 and v_u_674 > 0) then
			local function v_u_699(p698)
				-- upvalues: (copy) v_u_685
				if v_u_685.Parent then
					v_u_685.Text = p698
				end
			end
			if v_u_670[v_u_674] then
				local v700 = v_u_670[v_u_674]
				if v_u_685.Parent then
					v_u_685.Text = v700
				end
			else
				task.spawn(function()
					-- upvalues: (ref) v_u_1, (copy) v_u_674, (ref) v_u_670, (copy) v_u_699
					local function v701()
						-- upvalues: (ref) v_u_1, (ref) v_u_674
						return v_u_1:GetNameFromUserIdAsync(v_u_674)
					end
					local v702, v703 = pcall(v701)
					if v702 and type(v703) == "string" then
						v_u_670[v_u_674] = v703
						v_u_699(v703)
					end
				end)
			end
		end
		v_u_93("CANCEL", "Dark", v_u_28.new("Frame", {
			["Name"] = "Actions",
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -10, 0.5, 0),
			["Size"] = v_u_36(130, 40),
			v_u_28.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
			["Parent"] = v675
		}), function()
			-- upvalues: (ref) v_u_181, (copy) v_u_674, (ref) p_u_27, (copy) v_u_685
			if v_u_181("Uninvite", v_u_674) then
				p_u_27.Toast(("Invite to %* withdrawn"):format(v_u_685.Text), "info")
			end
		end, {
			["Width"] = 110,
			["TextSize"] = 15
		})
	end
	local function v_u_754(p705) -- name: renderMembers
		-- upvalues: (copy) v_u_85, (copy) v_u_586, (copy) v_u_577, (copy) v_u_576, (copy) v_u_70, (ref) v_u_5, (copy) v_u_36, (copy) v_u_53, (copy) v_u_93, (copy) v_u_669, (copy) v_u_28, (copy) v_u_31, (ref) v_u_37, (copy) v_u_29, (copy) v_u_57, (copy) v_u_32, (ref) v_u_21, (ref) v_u_11, (copy) v_u_181, (copy) v_u_655, (copy) v_u_704
		v_u_85(v_u_586)
		v_u_85(v_u_577)
		v_u_85(v_u_576)
		local v706 = p705.membersList
		local v707 = type(v706) ~= "table" and {} or p705.membersList
		local v708 = 0
		for _, v709 in v707 do
			if not v709.where then
				continue
			end
			v708 = v708 + 1
		end
		v_u_70("MEMBERS", ("%*/%*"):format(#v707, v_u_5.MAX_MEMBERS), ("%* online"):format(v708), 1, v_u_576).Position = v_u_36(0, 9)
		local v710 = v_u_53(p705)
		local v711 = v710 == "chief" and true or v710 == "elder"
		if v711 then
			v_u_93("INVITE PLAYERS", "Primary", v_u_577, function()
				-- upvalues: (ref) v_u_669
				v_u_669()
			end, {
				["Size"] = nil,
				["TextSize"] = 15,
				["Icon"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Icon"] = v_u_28.Glyph("person-plus", 18, v_u_31.Text)
			})
		end
		local v712 = 0
		local v713 = p705.requests
		local v714 = type(v713) ~= "table" and {} or p705.requests
		if v711 and #v714 > 0 then
			local v715 = v712 + 1
			v_u_70("JOIN REQUESTS", #v714, nil, v715, v_u_586, v_u_31.Warning)
			for _, v_u_716 in v714 do
				v715 = v715 + 1
				local v717 = v_u_28.new
				local v718 = {}
				local v719 = v_u_716.userId
				v718.Name = "R" .. tostring(v719)
				v718.Size = UDim2.new(1, -4, 0, v_u_37.row)
				v718.LayoutOrder = v715
				v718.BackgroundColor3 = Color3.fromRGB(60, 46, 20)
				v718.BackgroundTransparency = 0.35
				__set_list(v718, 1, {v_u_28.Corner(12), (v_u_28.Stroke(v_u_31.Warning, 1, 0.6))})
				v718.Parent = v_u_586
				local v720 = v717("Frame", v718)
				v_u_28.new("ImageLabel", {
					["Name"] = "Head",
					["Image"] = ("rbxthumb://type=AvatarHeadShot&id=%*&w=150&h=150"):format(v_u_716.userId),
					["AnchorPoint"] = Vector2.new(0, 0.5),
					["Position"] = UDim2.new(0, 12, 0.5, 0),
					["Size"] = v_u_36(v_u_37.row - 18, v_u_37.row - 18),
					["BackgroundColor3"] = v_u_31.Raised,
					v_u_28.Corner(v_u_29.Radius.Pill),
					["Parent"] = v720
				})
				local v721 = v_u_37.row + 8
				local v722 = v_u_57
				local v723 = {
					["Name"] = "Name",
					["Text"] = nil,
					["FontFace"] = nil,
					["TextSize"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil
				}
				local v724 = v_u_716.display
				v723.Text = tostring(v724)
				v723.FontFace = v_u_32.Heavy
				v723.TextSize = v_u_37.text
				local v725 = v_u_36
				local v726 = v_u_37.row / 2
				v723.Position = v725(v721, math.floor(v726) - v_u_37.text - 2)
				v723.Size = UDim2.new(1, -(v721 + 260), 0, v_u_37.text + 4)
				v723.Parent = v720
				v722(v723)
				local v727 = v_u_57
				local v728 = {
					["Name"] = "Sub",
					["Text"] = nil,
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["Text"] = ("@%*  \194\183  Lv %*  \194\183  asked %*"):format(v_u_716.name, v_u_716.level, (v_u_21(v_u_716.at))),
					["FontFace"] = v_u_32.SemiBold,
					["TextSize"] = v_u_37.sub,
					["TextColor3"] = v_u_11
				}
				local v729 = v_u_36
				local v730 = v_u_37.row / 2
				v728.Position = v729(v721, math.floor(v730) + 3)
				v728.Size = UDim2.new(1, -(v721 + 260), 0, v_u_37.sub + 2)
				v728.Parent = v720
				v727(v728)
				local v731 = v_u_28.new("Frame", {
					["Name"] = "Actions",
					["AnchorPoint"] = Vector2.new(1, 0.5),
					["Position"] = UDim2.new(1, -10, 0.5, 0),
					["Size"] = v_u_36(240, 40),
					v_u_28.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
					["Parent"] = v720
				})
				v_u_93("ACCEPT", "Success", v731, function()
					-- upvalues: (ref) v_u_181, (copy) v_u_716
					v_u_181("Respond", v_u_716.userId, true)
				end, {
					["Width"] = 110,
					["LayoutOrder"] = 1,
					["TextSize"] = 15
				})
				v_u_93("DECLINE", "Dark", v731, function()
					-- upvalues: (ref) v_u_181, (copy) v_u_716
					v_u_181("Respond", v_u_716.userId, false)
				end, {
					["Width"] = 110,
					["LayoutOrder"] = 2,
					["TextSize"] = 15
				})
			end
			v712 = v715 + 1
			v_u_70("MEMBERS", nil, nil, v712, v_u_586)
		end
		local v732 = table.clone(v707)
		local v_u_733 = {
			["chief"] = 0,
			["elder"] = 1,
			["member"] = 2
		}
		table.sort(v732, function(p734, p735)
			-- upvalues: (copy) v_u_733
			local v736 = p734.where and 0 or 1
			local v737 = p735.where and 0 or 1
			if v736 ~= v737 then
				return v736 < v737
			end
			if (v_u_733[p734.role] or 3) ~= (v_u_733[p735.role] or 3) then
				return (v_u_733[p734.role] or 3) < (v_u_733[p735.role] or 3)
			end
			local v738 = p734.weekRenown
			local v739 = tonumber(v738) or 0
			local v740 = p735.weekRenown
			return (tonumber(v740) or 0) < v739
		end)
		for v741, v742 in v732 do
			v712 = v712 + 1
			local v743 = v_u_655(v742, p705, v712)
			local v744 = v_u_28.Enter
			local v745 = Vector2.new(0, 8)
			local v746 = v741 * 0.025
			v744(v743, v745, math.min(v746, 0.25), UDim2.new())
		end
		local v747 = p705.invites
		local v748 = type(v747) ~= "table" and {} or p705.invites
		if v711 and #v748 > 0 then
			local v749 = v712 + 1
			local v750 = v_u_70
			local v751 = #v748
			local v752 = p705.inviteMax
			v750("PENDING INVITES", ("%*/%*"):format(v751, tonumber(v752) or 50), "expire after 24 h", v749, v_u_586, v_u_31.Accent)
			for _, v753 in v748 do
				v749 = v749 + 1
				v_u_704(v753, v749)
			end
		end
	end
	local v755 = v_u_28.new("Frame", {
		["Name"] = "Top",
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 46),
		["Parent"] = v146.page
	})
	local v756 = v_u_28.new("Frame", {
		["Name"] = "Period",
		["Size"] = v_u_36(280, 46),
		["BackgroundColor3"] = v_u_12,
		["BackgroundTransparency"] = 0.25,
		v_u_28.Corner(v_u_29.Radius.Pill),
		v_u_28.Padding(4, 4, 4, 4),
		v_u_28.List(Enum.FillDirection.Horizontal, 4),
		["Parent"] = v755
	})
	local v_u_757 = {}
	local v_u_758 = "top"
	for v759, v760 in {
		{ "top", "THIS WEEK" },
		{ "alltime", "ALL TIME" }
	} do
		v_u_757[v760[1]] = v_u_28.new("TextButton", {
			["Name"] = v760[1],
			["Text"] = v760[2],
			["AutoButtonColor"] = false,
			["FontFace"] = v_u_32.Heavy,
			["TextSize"] = 14,
			["TextColor3"] = v_u_31.TextDim,
			["Size"] = UDim2.new(0.5, -2, 1, 0),
			["LayoutOrder"] = v759,
			["BackgroundColor3"] = v_u_31.Accent,
			["BackgroundTransparency"] = 1,
			v_u_28.Corner(v_u_29.Radius.Pill),
			["Parent"] = v756
		})
	end
	local v_u_761 = v_u_57({
		["Name"] = "Note",
		["Text"] = "",
		["RichText"] = true,
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_32.SemiBold,
		["TextColor3"] = v_u_11,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -10, 0.5, 0),
		["Size"] = UDim2.new(1, -300, 0, 20),
		["Parent"] = v755
	})
	local v_u_762 = v_u_28.new("ScrollingFrame", {
		["Name"] = "List",
		["Position"] = v_u_36(0, 58),
		["Size"] = UDim2.new(1, 0, 1, -58),
		["ScrollBarThickness"] = 3,
		["Selectable"] = false,
		v_u_28.List(Enum.FillDirection.Vertical, 8),
		v_u_28.Padding(4, 10, 10, 4),
		["Parent"] = v146.page
	})
	local v_u_763 = v_u_28.new("Frame", {
		["Name"] = "Pinned",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, v_u_37.row + 22),
		["Parent"] = v146.page
	})
	local v_u_764 = v_u_28.new("Frame", {
		["Name"] = "Empty",
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Position"] = v_u_36(0, 120),
		["Size"] = UDim2.new(1, 0, 0, 120),
		["Parent"] = v146.page
	})
	v_u_28.Glyph("trophy", 48, v_u_31.TextMuted, {
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 0),
		["Parent"] = v_u_764
	})
	local v_u_765 = v_u_57({
		["Name"] = "Text",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 17,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_32.SemiBold,
		["TextColor3"] = v_u_11,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Position"] = v_u_36(0, 60),
		["Size"] = UDim2.new(1, 0, 0, 24),
		["Parent"] = v_u_764
	})
	local v_u_766 = { v_u_13, Color3.fromRGB(196, 206, 222), Color3.fromRGB(222, 140, 74) }
	local function v_u_813(p767, p768, p769, p770, p771) -- name: boardRow
		-- upvalues: (ref) v_u_37, (copy) v_u_28, (ref) v_u_5, (copy) v_u_31, (copy) v_u_205, (copy) v_u_766, (copy) v_u_36, (copy) v_u_29, (copy) v_u_57, (copy) v_u_32, (copy) v_u_38, (ref) v_u_11, (copy) v_u_194, (ref) v_u_758, (ref) v_u_13
		local v772 = v_u_37.row + 8
		local v773 = v_u_28.new("TextButton", {
			["Name"] = "R" .. tostring(p768 or 0),
			["Text"] = "",
			["AutoButtonColor"] = false,
			["Size"] = UDim2.new(1, -4, 0, v772),
			["LayoutOrder"] = p770,
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["BackgroundTransparency"] = 0.1,
			["ClipsDescendants"] = true,
			v_u_28.Corner(12),
			["Parent"] = p769
		})
		v_u_28.Gradient(v_u_5.Color(p767.color1):Lerp(v_u_31.Panel, 0.8), v_u_31.PanelHi:Lerp(v_u_31.Panel, 0.55), 0).Parent = v773
		local v774
		if p771 then
			v774 = v_u_28.Stroke(v_u_31.Accent, 2, 0)
		else
			v774 = v_u_28.Stroke(v_u_31.Stroke, 1, 0.92)
		end
		v774.Parent = v773
		v_u_205(v773, v774, p767)
		local v775
		if p768 then
			v775 = v_u_766[p768]
		else
			v775 = p768
		end
		local v776 = v_u_28.Compact and 46 or 56
		local v777 = v_u_28.new("Frame", {
			["Name"] = "Rank",
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(0, v776 / 2 + 10, 0.5, 0),
			["Size"] = v_u_36(v776 - 6, v776 - 6),
			["BackgroundColor3"] = v775 or v_u_31.Inset,
			["BackgroundTransparency"] = v775 and 0.78 or 1,
			v_u_28.Corner(v_u_29.Radius.Pill),
			["Parent"] = v773
		})
		local v778 = v_u_57
		local v779 = {
			["Name"] = "Text",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = not p768 and "-" or tostring(p768),
			["FontFace"] = v_u_32.Display
		}
		local v780
		if p768 and p768 >= 100 then
			v780 = v_u_37.text
		else
			v780 = v_u_37.text + 6
		end
		v779.TextSize = v780
		v779.TextColor3 = v775 or v_u_31.TextDim
		v779.TextXAlignment = Enum.TextXAlignment.Center
		v779.TextTruncate = Enum.TextTruncate.None
		v779.Size = UDim2.fromScale(1, 1)
		v779.Parent = v777
		v778(v779)
		local v781 = v776 + 14
		v_u_38.new(v_u_37.row - 6, {
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, v781, 0.5, 0),
			["Parent"] = v773
		}):Set(p767.icon, p767.color1, p767.color2, p767.tag)
		local v782 = v781 + v_u_37.row + 8
		local v783 = v_u_28.Compact and 96 or 260
		local v784 = v_u_57
		local v785 = {
			["Name"] = "Name",
			["Text"] = nil,
			["RichText"] = true,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil
		}
		local v786 = string.format
		local v787 = "<font color=\"#%s\">%s</font>  %s"
		local v788 = v_u_38.TagColor(p767.color1):ToHex()
		local v789 = v_u_38.Tag
		local v790
		if type(p767) == "table" then
			v790 = p767.tag
		else
			v790 = p767
		end
		local v791 = v789(v790)
		local v792 = p767.name or ""
		v785.Text = v786(v787, v788, v791, (tostring(v792)))
		v785.FontFace = v_u_32.Heavy
		v785.TextSize = v_u_37.text
		local v793 = v_u_36
		local v794 = v772 / 2
		v785.Position = v793(v782, math.floor(v794) - v_u_37.text - 2)
		v785.Size = UDim2.new(1, -(v782 + v783 + 12), 0, v_u_37.text + 2)
		v785.Parent = v773
		v784(v785)
		local v795 = p767.members
		local v796 = tonumber(v795) or 0
		local v797 = p767.held
		local v798 = tonumber(v797) or 0
		local v799 = ("%* %*"):format(v796, v796 == 1 and "member" or "members")
		if v798 > 0 and v_u_28.Compact then
			v799 = v799 .. ("  \194\183  holds %* %*"):format(v798, v798 == 1 and "map" or "maps")
		end
		if p771 then
			v799 = ("<font color=\"#%*\">Your tribe</font>  \194\183  "):format((v_u_31.Accent:ToHex())) .. v799
		end
		local v800 = v_u_57
		local v801 = {
			["Name"] = "Sub",
			["Text"] = nil,
			["RichText"] = true,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v799,
			["FontFace"] = v_u_32.SemiBold,
			["TextSize"] = v_u_37.sub,
			["TextColor3"] = v_u_11
		}
		local v802 = v_u_36
		local v803 = v772 / 2
		v801.Position = v802(v782, math.floor(v803) + 3)
		v801.Size = UDim2.new(1, -(v782 + v783 + 12), 0, v_u_37.sub + 2)
		v801.Parent = v773
		v800(v801)
		local v804 = v_u_28.new("Frame", {
			["Name"] = "Stats",
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -14, 0.5, 0),
			["Size"] = v_u_36(v783, 40),
			v_u_28.List(Enum.FillDirection.Horizontal, 4, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
			["Parent"] = v773
		})
		if not v_u_28.Compact then
			v_u_194(v804, ("%*/%*"):format(v796, v_u_5.MAX_MEMBERS), "MEMBERS", 1)
			local v805 = v_u_194
			local v806 = tostring(v798)
			local v807 = "MAPS HELD"
			local v808 = 2
			local v809
			if v798 > 0 then
				v809 = v_u_31.Text
			else
				v809 = v_u_31.TextDim
			end
			v805(v804, v806, v807, v808, v809)
		end
		local v810 = v_u_194
		local v811 = v_u_28.FormatNumber
		local v812
		if v_u_758 == "alltime" then
			v812 = p767.renown
		else
			v812 = p767.weekRenown
		end
		v810(v804, v811(tonumber(v812) or 0), "GLORY", 3, v_u_13)
		return v773
	end
	local function v_u_817() -- name: paintPeriod
		-- upvalues: (copy) v_u_757, (ref) v_u_758, (copy) v_u_31, (copy) v_u_761, (ref) v_u_26, (ref) v_u_5
		for v814, v815 in v_u_757 do
			v815.BackgroundTransparency = v814 == v_u_758 and 0 or 1
			local v816
			if v814 == v_u_758 then
				v816 = v_u_31.Text
			else
				v816 = v_u_31.TextDim
			end
			v815.TextColor3 = v816
		end
		if v_u_758 == "top" then
			v_u_761.Text = ("Resets in <font color=\"#%*\">%*</font>"):format(v_u_31.Text:ToHex(), (v_u_26(v_u_5.WeekEndsAt(v_u_5.WeekOf(os.time())))))
		else
			v_u_761.Text = "Every match since tribes began"
		end
	end
	local v_u_818 = 0
	local v_u_819 = 0
	local v_u_820 = nil
	local v_u_821 = nil
	local v_u_822 = nil
	local function v_u_837(p823) -- name: drawPin
		-- upvalues: (ref) v_u_758, (ref) v_u_3, (ref) v_u_822, (copy) v_u_85, (copy) v_u_763, (copy) v_u_762, (ref) v_u_37, (copy) v_u_28, (copy) v_u_36, (copy) v_u_31, (copy) v_u_813
		local v824 = v_u_758
		local v825 = v_u_3.JSONEncode
		local v826 = v_u_3
		local v827, v828 = pcall(v825, v826, p823 or false)
		if not v827 then
			local v829 = os.clock
			v828 = tostring(v829())
		end
		local v830 = v824 .. v828
		if v830 ~= v_u_822 then
			v_u_822 = v830
			v_u_85(v_u_763)
			if type(p823) == "table" then
				local v831 = p823.tribe
				if type(v831) == "table" then
					local v832 = p823.tribe
					local v833
					if v_u_758 == "alltime" then
						v833 = v832.renown
					else
						v833 = v832.weekRenown
					end
					local v834
					if (tonumber(v833) or 0) > 0 then
						local v835 = p823.rank
						if type(v835) == "number" then
							v834 = p823.rank
						else
							v834 = nil
						end
					else
						v834 = nil
					end
					v_u_763.Visible = true
					v_u_763.Size = UDim2.new(1, 0, 0, v_u_37.row + 22)
					v_u_762.Size = UDim2.new(1, 0, 1, -(58 + v_u_37.row + 26))
					v_u_28.new("Frame", {
						["Name"] = "Rule",
						["Position"] = nil,
						["Size"] = nil,
						["BackgroundColor3"] = nil,
						["BackgroundTransparency"] = 0.85,
						["Parent"] = nil,
						["Position"] = v_u_36(4, 2),
						["Size"] = UDim2.new(1, -18, 0, 1),
						["BackgroundColor3"] = v_u_31.Stroke,
						["Parent"] = v_u_763
					})
					local v836 = v_u_813(v832, v834, v_u_763, 1, true)
					v836.AnchorPoint = Vector2.new(0, 1)
					v836.Position = UDim2.new(0, 4, 1, -4)
					v836.Size = UDim2.new(1, -18, 0, v_u_37.row + 8)
					v_u_28.Enter(v836, Vector2.new(0, 10), 0.1, UDim2.new(0, 4, 1, -4))
					return
				end
			end
			v_u_763.Visible = false
			v_u_762.Size = UDim2.new(1, 0, 1, -58)
		end
	end
	local function v_u_884(p838, p_u_839) -- name: showBoard
		-- upvalues: (ref) v_u_151, (copy) v_u_53, (copy) v_u_33, (ref) v_u_758, (copy) v_u_837, (ref) v_u_819, (ref) v_u_818, (ref) v_u_3, (ref) v_u_822, (copy) v_u_85, (copy) v_u_763, (copy) v_u_762, (ref) v_u_820, (ref) v_u_821, (copy) v_u_764, (copy) v_u_765, (copy) v_u_813, (copy) v_u_28
		local v840 = v_u_151
		if v840 then
			v840 = v_u_151.tribe
		end
		local v841
		if type(v840) == "table" then
			v841 = {
				["id"] = v840.id,
				["role"] = v_u_53(v840)
			}
		else
			v841 = v_u_33.Mine()
		end
		local v_u_842
		if v841 then
			v_u_842 = v841.id
		else
			v_u_842 = nil
		end
		local v_u_843 = {}
		local v_u_844 = false
		for _, v845 in p838 do
			if type(v845) ~= "table" then
				continue
			end
			local v846
			if v_u_758 == "alltime" then
				v846 = v845.renown
			else
				v846 = v845.weekRenown
			end
			if (tonumber(v846) or 0) <= 0 then
				continue
			end
			table.insert(v_u_843, v845)
			if v_u_844 then
				continue
			end
			if v_u_842 == nil then
				v_u_844 = false
			else
				v_u_844 = v845.id == v_u_842
			end
		end
		local function v858() -- name: pin
			-- upvalues: (copy) v_u_842, (ref) v_u_844, (ref) v_u_837, (ref) v_u_33, (ref) v_u_758, (ref) v_u_819, (copy) p_u_839, (ref) v_u_818, (ref) v_u_3, (ref) v_u_822, (ref) v_u_85, (ref) v_u_763, (ref) v_u_762
			if v_u_842 and not v_u_844 then
				v_u_837(v_u_33.CachedRank(v_u_758))
				local v_u_847 = v_u_758
				local v_u_848 = v_u_819
				task.spawn(function()
					-- upvalues: (ref) v_u_33, (copy) v_u_847, (ref) p_u_839, (ref) v_u_818, (copy) v_u_848, (ref) v_u_819, (ref) v_u_837
					local v849, v850 = v_u_33.Rank(v_u_847)
					if v849 and (p_u_839 == v_u_818 and v_u_848 == v_u_819) then
						v_u_837(v850)
					end
				end)
				return
			else
				local v851 = v_u_758
				local v852 = v_u_3.JSONEncode
				local v853 = v_u_3
				local v854, v855 = pcall(v852, v853, false)
				if not v854 then
					local v856 = os.clock
					v855 = tostring(v856())
				end
				local v857 = v851 .. v855
				if v857 ~= v_u_822 then
					v_u_822 = v857
					v_u_85(v_u_763)
					v_u_763.Visible = false
					v_u_762.Size = UDim2.new(1, 0, 1, -58)
				end
			end
		end
		local v859 = "%*|%*|%*"
		local v860 = v_u_758
		local v861 = v_u_842 or 0
		local v862 = v_u_3.JSONEncode
		local v863 = v_u_3
		local v864, v865 = pcall(v862, v863, p838)
		if not v864 then
			local v866 = os.clock
			v865 = tostring(v866())
		end
		local v867 = v859:format(v860, v861, v865)
		if v867 == v_u_820 then
			v858()
		else
			local v_u_868 = v_u_821 ~= v_u_758
			local v869 = v_u_758
			v_u_820 = v867
			v_u_821 = v869
			v_u_819 = v_u_819 + 1
			local v_u_870 = v_u_819
			v_u_85(v_u_762)
			v_u_764.Visible = #v_u_843 == 0
			v_u_765.Text = v_u_758 == "top" and "No Glory yet this week. Win matches with tribemates to climb." or "No tribe has earned Glory yet."
			local function v_u_880(p871) -- name: build
				-- upvalues: (copy) v_u_843, (ref) v_u_813, (ref) v_u_762, (copy) v_u_842, (copy) v_u_868, (ref) v_u_28
				local v872 = v_u_843[p871]
				local v873 = v_u_813
				local v874 = v_u_762
				local v875
				if v_u_842 == nil then
					v875 = false
				else
					v875 = v872.id == v_u_842
				end
				local v876 = v873(v872, p871, v874, p871, v875)
				if v_u_868 and p871 <= 10 then
					local v877 = v_u_28.Enter
					local v878 = Vector2.new(0, 10)
					local v879 = p871 * 0.03
					v877(v876, v878, math.min(v879, 0.3), UDim2.new())
				end
			end
			local v881 = #v_u_843
			for v882 = 1, math.min(v881, 10) do
				v_u_880(v882)
			end
			if #v_u_843 > 10 then
				task.spawn(function()
					-- upvalues: (copy) v_u_843, (copy) v_u_870, (ref) v_u_819, (copy) v_u_880
					for v883 = 11, #v_u_843 do
						if (v883 - 10) % 8 == 1 then
							task.wait()
							if v_u_870 ~= v_u_819 then
								return
							end
						end
						v_u_880(v883)
					end
				end)
			end
			v858()
		end
	end
	local function v_u_908() -- name: loadBoard
		-- upvalues: (ref) v_u_818, (ref) v_u_758, (copy) v_u_817, (copy) v_u_33, (copy) v_u_884, (ref) v_u_821, (ref) v_u_820, (ref) v_u_819, (copy) v_u_85, (copy) v_u_762, (ref) v_u_3, (ref) v_u_822, (copy) v_u_763, (copy) v_u_764, (copy) v_u_28, (ref) v_u_37, (copy) v_u_31, (copy) v_u_765, (ref) v_u_5
		v_u_818 = v_u_818 + 1
		local v885 = v_u_818
		local v886 = v_u_758
		v_u_817()
		local v887 = v_u_33.CachedBoard(v886)
		if type(v887) == "table" then
			v_u_884(v887, v885)
		elseif v_u_821 ~= v886 then
			v_u_820 = nil
			v_u_821 = nil
			v_u_819 = v_u_819 + 1
			v_u_85(v_u_762)
			local v888 = v_u_758
			local v889 = v_u_3.JSONEncode
			local v890 = v_u_3
			local v891, v892 = pcall(v889, v890, false)
			if not v891 then
				local v893 = os.clock
				v892 = tostring(v893())
			end
			local v894 = v888 .. v892
			if v894 ~= v_u_822 then
				v_u_822 = v894
				v_u_85(v_u_763)
				v_u_763.Visible = false
				v_u_762.Size = UDim2.new(1, 0, 1, -58)
			end
			v_u_764.Visible = false
			for v895 = 1, 5 do
				local v896 = v_u_28.new("Frame", {
					["Name"] = "Skeleton",
					["Size"] = UDim2.new(1, -4, 0, v_u_37.row + 8),
					["LayoutOrder"] = v895,
					["BackgroundColor3"] = v_u_31.PanelHi,
					["BackgroundTransparency"] = 0.5,
					v_u_28.Corner(12),
					["Parent"] = v_u_762
				})
				v_u_28.Tween(v896, TweenInfo.new(0.8, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true, v895 * 0.12), {
					["BackgroundTransparency"] = 0.78
				})
			end
		end
		local v897, v898 = v_u_33.Board(v886)
		if v885 == v_u_818 then
			if v897 and type(v898) == "table" then
				v_u_884(v898, v885)
			elseif type(v887) ~= "table" then
				v_u_820 = nil
				v_u_821 = nil
				v_u_819 = v_u_819 + 1
				v_u_85(v_u_762)
				local v899 = v_u_758
				local v900 = v_u_3.JSONEncode
				local v901 = v_u_3
				local v902, v903 = pcall(v900, v901, false)
				if not v902 then
					local v904 = os.clock
					v903 = tostring(v904())
				end
				local v905 = v899 .. v903
				if v905 ~= v_u_822 then
					v_u_822 = v905
					v_u_85(v_u_763)
					v_u_763.Visible = false
					v_u_762.Size = UDim2.new(1, 0, 1, -58)
				end
				v_u_764.Visible = true
				local v906 = v_u_765
				local v907 = v898 or v_u_5.Message("unavailable")
				v906.Text = tostring(v907)
			end
		else
			return
		end
	end
	for v_u_909, v910 in v_u_757 do
		v910.Activated:Connect(function()
			-- upvalues: (ref) v_u_758, (copy) v_u_909, (ref) v_u_152, (copy) p_u_27, (copy) v_u_908
			if v_u_758 ~= v_u_909 and os.clock() - v_u_152 >= 0.5 then
				v_u_758 = v_u_909
				p_u_27.Sounds.Play("Click")
				v_u_908()
			end
		end)
	end
	v_u_115.Leaderboard = v_u_908
	local v_u_911 = v_u_28.new("Frame", {
		["Name"] = "MapArea",
		["BackgroundColor3"] = Color3.fromRGB(14, 52, 92),
		["BackgroundTransparency"] = 0,
		["ClipsDescendants"] = true,
		v_u_28.Corner(14),
		v_u_28.Stroke(v_u_31.Stroke, 1, 0.9),
		["Parent"] = v147.page
	})
	local v_u_912 = v82("Side", v147.page, 10)
	local v_u_913 = v_u_28.new("Frame", {
		["Name"] = "Layer",
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_911
	})
	local v_u_914 = v_u_28.new("ScrollingFrame", {
		["Name"] = "Tiles",
		["Size"] = UDim2.fromScale(1, 1),
		["ScrollBarThickness"] = 3,
		["Selectable"] = false,
		["Visible"] = false,
		v_u_28.Padding(12, 12, 12, 12),
		["Parent"] = v_u_911
	})
	local v_u_915 = v_u_28.new("UIGridLayout", {
		["CellSize"] = v_u_36(200, 150),
		["CellPadding"] = v_u_36(10, 10),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_914
	})
	local v_u_916 = v_u_57({
		["Name"] = "Loading",
		["Text"] = "Loading the map...",
		["FontFace"] = nil,
		["TextSize"] = 17,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_32.SemiBold,
		["TextColor3"] = v_u_11,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_911
	})
	local v_u_917 = v_u_28.new("Frame", {
		["Name"] = "Legend",
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 10, 1, -10),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = v_u_36(0, 30),
		["BackgroundColor3"] = v_u_31.Void,
		["BackgroundTransparency"] = 0.35,
		["ZIndex"] = 6,
		v_u_28.Corner(v_u_29.Radius.Pill),
		v_u_28.Padding(0, 12, 0, 10),
		v_u_28.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
		["Parent"] = v_u_911
	})
	v_u_28.new("Frame", {
		["Name"] = "Ring",
		["Size"] = v_u_36(14, 14),
		["BackgroundTransparency"] = 1,
		["LayoutOrder"] = 1,
		["ZIndex"] = 6,
		v_u_28.Corner(v_u_29.Radius.Pill),
		v_u_28.Stroke(v_u_31.Accent, 2, 0),
		["Parent"] = v_u_917
	})
	v_u_61("YOUR TRIBE", {
		["Size"] = nil,
		["LayoutOrder"] = 2,
		["ZIndex"] = 6,
		["TextColor3"] = nil,
		["Parent"] = nil,
		["Size"] = v_u_36(76, 14),
		["TextColor3"] = v_u_31.TextDim,
		["Parent"] = v_u_917
	})
	v_u_28.new("Frame", {
		["Name"] = "Fog",
		["Size"] = v_u_36(14, 14),
		["BackgroundColor3"] = Color3.fromRGB(58, 64, 78),
		["LayoutOrder"] = 3,
		["ZIndex"] = 6,
		v_u_28.Corner(v_u_29.Radius.Pill),
		["Parent"] = v_u_917
	})
	v_u_61("NOT IN ROTATION", {
		["Size"] = nil,
		["LayoutOrder"] = 4,
		["ZIndex"] = 6,
		["TextColor3"] = nil,
		["Parent"] = nil,
		["Size"] = v_u_36(108, 14),
		["TextColor3"] = v_u_31.TextDim,
		["Parent"] = v_u_917
	})
	local v_u_918 = nil
	local v_u_919 = nil
	local v_u_920 = nil
	local v_u_921 = {}
	local function v_u_934(p922, p923) -- name: regionAt
		-- upvalues: (ref) v_u_7, (copy) v_u_921
		local v924 = p922 / v_u_7.cell
		local v925 = math.floor(v924) + 1
		local v926 = p923 / v_u_7.cell
		local v927 = math.floor(v926) + 1
		local v928 = v_u_7.rows[v927]
		if not v928 or (v925 < 1 or v_u_7.cols < v925) then
			return nil
		end
		local v929 = v_u_921[v927]
		if not v929 then
			v929 = {}
			for v930, v931 in string.gmatch(v928, "(%D)(%d+)") do
				local v932 = string.find("abcdefghijklmnopqrstuvwxyABCDEFGHIJKLMNOPQRSTUVWXY", v930, 1, true)
				local v933
				if v932 then
					v933 = v_u_7.keys[v932] or false
				else
					v933 = false
				end
				for _ = 1, tonumber(v931) or 0 do
					table.insert(v929, v933)
				end
			end
			v_u_921[v927] = v929
		end
		return v929[v925] or nil
	end
	local v_u_935 = nil
	v_u_935 = function()
		-- upvalues: (copy) v_u_916, (ref) v_u_919, (copy) v_u_85, (copy) v_u_913, (copy) v_u_914, (copy) v_u_915, (ref) v_u_151, (copy) v_u_53, (copy) v_u_33, (ref) v_u_6, (copy) v_u_917, (copy) v_u_911, (copy) v_u_28, (copy) v_u_36, (copy) v_u_934, (ref) v_u_152, (ref) v_u_918, (copy) p_u_27, (ref) v_u_935, (ref) v_u_920, (ref) v_u_5, (copy) v_u_38, (copy) v_u_31, (copy) v_u_29, (copy) v_u_57, (copy) v_u_32, (ref) v_u_11
		v_u_916.Visible = v_u_919 == nil
		v_u_85(v_u_913)
		v_u_85(v_u_914)
		v_u_915.Parent = v_u_914
		if v_u_919 then
			local v936 = v_u_151
			if v936 then
				v936 = v_u_151.tribe
			end
			local v937
			if type(v936) == "table" then
				v937 = {
					["id"] = v936.id,
					["role"] = v_u_53(v936)
				}
			else
				v937 = v_u_33.Mine()
			end
			local v938 = v_u_919.order
			local v_u_939 = type(v938) ~= "table" and {} or v_u_919.order
			local v940 = v_u_6.Map.image ~= ""
			v_u_914.Visible = not v940
			v_u_913.Visible = v940
			v_u_917.Visible = v940
			if v940 then
				local v941 = v_u_911.AbsoluteSize
				local v942 = v_u_28.Scale
				local v943 = v941 / math.max(v942, 0.01)
				local v_u_944 = v_u_6.Map.size
				local v945 = v943.X / v_u_944.X
				local v946 = v943.Y / v_u_944.Y
				local v947 = math.min(v945, v946)
				local v948 = v_u_944.X * v947
				local v949 = math.floor(v948)
				local v950 = v_u_944.Y * v947
				local v951 = math.floor(v950)
				local v952 = (v943.X - v949) / 2
				local v953 = math.floor(v952)
				local v954 = (v943.Y - v951) / 2
				local v955 = math.floor(v954)
				v_u_28.new("ImageLabel", {
					["Name"] = "Base",
					["Image"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 1,
					["Parent"] = nil,
					["Image"] = v_u_6.Map.image,
					["Position"] = v_u_36(v953, v955),
					["Size"] = v_u_36(v949, v951),
					["Parent"] = v_u_913
				})
				local v_u_956 = v_u_28.new("TextButton", {
					["Name"] = "Hit",
					["Text"] = "",
					["AutoButtonColor"] = false,
					["Selectable"] = false,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 3,
					["Parent"] = nil,
					["Position"] = v_u_36(v953, v955),
					["Size"] = v_u_36(v949, v951),
					["Parent"] = v_u_913
				})
				v_u_956.Activated:Connect(function()
					-- upvalues: (copy) v_u_956, (ref) v_u_28, (ref) v_u_934, (copy) v_u_944, (copy) v_u_939, (ref) v_u_152, (ref) v_u_918, (ref) p_u_27, (ref) v_u_935, (ref) v_u_920
					local v957 = v_u_956.AbsoluteSize
					if v957.X > 0 and v957.Y > 0 then
						local v958 = (v_u_28.PointerAbs() - v_u_956.AbsolutePosition) / v957
						local v959 = v_u_934(v958.X * v_u_944.X, v958.Y * v_u_944.Y)
						if v959 and table.find(v_u_939, v959) then
							if os.clock() - v_u_152 < 0.5 then
								return
							end
							if v_u_918 ~= v959 then
								p_u_27.Sounds.Play("Click")
							end
							v_u_918 = v959
							v_u_935()
							v_u_920(v959)
						end
					end
				end)
				for v_u_960, v961 in v_u_6.Map.regions do
					local v962 = table.find(v_u_939, v_u_960) ~= nil
					local v963
					if v962 then
						local v964 = v_u_919 and v_u_919.maps
						if v964 then
							v964 = v_u_919.maps[v_u_960]
						end
						v963 = v964 and v964.holder and v_u_919.tribes
						if v963 then
							local v965 = v_u_919.tribes
							local v966 = v964.holder
							v963 = v965[tostring(v966)]
						end
					else
						v963 = nil
					end
					local v967 = v961.bbox[1]
					local v968 = v961.bbox[2]
					local v969 = v961.bbox[3]
					local v970 = v961.bbox[4]
					if v961.mask ~= "" then
						local v971 = v_u_918 == v_u_960
						local v972 = v_u_28.new
						local v973 = "ImageLabel"
						local v974 = {
							["Name"] = nil,
							["Image"] = nil,
							["ImageColor3"] = nil,
							["ImageTransparency"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["ZIndex"] = 2,
							["Parent"] = nil,
							["Name"] = "Mask_" .. v_u_960,
							["Image"] = v961.mask
						}
						local v975
						if v963 then
							v975 = v_u_5.Color(v963.color1)
						elseif v962 then
							v975 = Color3.new(1, 1, 1)
						else
							v975 = Color3.fromRGB(58, 64, 78)
						end
						v974.ImageColor3 = v975
						local v976
						if v963 then
							v976 = v971 and 0.3 or 0.42
						else
							v976 = v962 and (v971 and 0.8 or 1) or 0.28
						end
						v974.ImageTransparency = v976
						local v977 = v_u_36
						local v978 = v967 * v947
						local v979 = v953 + math.floor(v978)
						local v980 = v968 * v947
						v974.Position = v977(v979, v955 + math.floor(v980))
						local v981 = v_u_36
						local v982 = (v969 - v967) * v947
						local v983 = math.ceil(v982)
						local v984 = (v970 - v968) * v947
						v974.Size = v981(v983, (math.ceil(v984)))
						v974.Parent = v_u_913
						v972(v973, v974)
					end
					if not v962 then
						continue
					end
					local v985 = v953 + v961.anchor[1] * v947
					local v986 = v955 + v961.anchor[2] * v947
					local v987 = v_u_28.new("TextButton", {
						["Name"] = nil,
						["Text"] = "",
						["AutoButtonColor"] = false,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["ZIndex"] = 4,
						["Parent"] = nil,
						["Name"] = "Pin_" .. v_u_960,
						["AnchorPoint"] = Vector2.new(0.5, 0.92),
						["Position"] = v_u_36(math.floor(v985), (math.floor(v986))),
						["Size"] = v_u_36(64, 70),
						["Parent"] = v_u_913
					})
					if v963 then
						v_u_38.new(v_u_28.Compact and 58 or 54, {
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["ZIndex"] = 4,
							["Parent"] = nil,
							["AnchorPoint"] = Vector2.new(0.5, 0.5),
							["Position"] = UDim2.fromScale(0.5, 0.5),
							["Parent"] = v987
						}):Set(v963.icon, v963.color1, v963.color2, v963.tag)
					else
						v_u_28.new("Frame", {
							["Name"] = "Dot",
							["AnchorPoint"] = Vector2.new(0.5, 0.5),
							["Position"] = UDim2.fromScale(0.5, 0.62),
							["Size"] = v_u_36(14, 14),
							["BackgroundColor3"] = v_u_31.Text,
							["ZIndex"] = 4,
							v_u_28.Corner(v_u_29.Radius.Pill),
							v_u_28.Stroke(v_u_31.Void, 2, 0.3),
							["Parent"] = v987
						})
					end
					if v963 and (v937 and v963.id == v937.id) then
						v_u_28.new("Frame", {
							["Name"] = "Mine",
							["AnchorPoint"] = Vector2.new(0.5, 0.5),
							["Position"] = UDim2.fromScale(0.5, 0.5),
							["Size"] = v_u_36(v_u_28.Compact and 70 or 66, v_u_28.Compact and 76 or 72),
							["ZIndex"] = 3,
							v_u_28.Corner(v_u_29.Radius.Pill),
							v_u_28.Stroke(v_u_31.Accent, 3, 0),
							["Parent"] = v987
						})
					end
					if v_u_918 == v_u_960 then
						local v988 = v_u_28.Pill(v_u_33.MapName(v_u_960), v_u_31.Void, {
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Height"] = 24,
							["TextSize"] = 13,
							["Transparency"] = 0.15,
							["ZIndex"] = 5,
							["Parent"] = nil,
							["AnchorPoint"] = Vector2.new(0.5, 1),
							["Position"] = UDim2.new(0.5, 0, 0, -2),
							["Parent"] = v987
						})
						v_u_28.Pop(v988, 0.85)
					end
					v987.Activated:Connect(function()
						-- upvalues: (copy) v_u_960, (ref) v_u_152, (ref) v_u_918, (ref) p_u_27, (ref) v_u_935, (ref) v_u_920
						local v989 = v_u_960
						if os.clock() - v_u_152 >= 0.5 then
							if v_u_918 ~= v989 then
								p_u_27.Sounds.Play("Click")
							end
							v_u_918 = v989
							v_u_935()
							v_u_920(v989)
						end
					end)
				end
			else
				for v990, v_u_991 in v_u_939 do
					local v992 = v_u_919.maps[v_u_991]
					local v993 = v_u_919 and v_u_919.maps
					if v993 then
						v993 = v_u_919.maps[v_u_991]
					end
					local v994 = v993 and v993.holder and v_u_919.tribes
					if v994 then
						local v995 = v_u_919.tribes
						local v996 = v993.holder
						v994 = v995[tostring(v996)]
					end
					local v997 = v_u_28.new("TextButton", {
						["Name"] = v_u_991,
						["Text"] = "",
						["AutoButtonColor"] = false,
						["LayoutOrder"] = v990,
						["BackgroundColor3"] = v_u_31.PanelHi,
						["BackgroundTransparency"] = 0.2,
						["ClipsDescendants"] = true,
						v_u_28.Corner(12),
						["Parent"] = v_u_914
					})
					local v998
					if v994 then
						if v937 then
							v998 = v994.id == v937.id
						else
							v998 = v937
						end
					else
						v998 = v994
					end
					local v999 = v_u_28.Stroke
					local v1000
					if v_u_918 == v_u_991 then
						v1000 = v_u_31.Text
					elseif v998 then
						v1000 = v_u_31.Accent
					else
						v1000 = v_u_31.Stroke
					end
					v999(v1000, (v_u_918 == v_u_991 or v998) and 2 or 1, v_u_918 == v_u_991 and 0.1 or (v998 and 0 or 0.9)).Parent = v997
					local v1001 = v_u_28.new
					local v1002 = {
						["Name"] = "Thumb",
						["Image"] = nil,
						["Size"] = nil,
						["ScaleType"] = nil,
						["BackgroundColor3"] = nil,
						["Parent"] = nil
					}
					local v1003 = v992 and (v992.thumb or "") or ""
					v1002.Image = tostring(v1003)
					v1002.Size = UDim2.new(1, 0, 0, 100)
					v1002.ScaleType = Enum.ScaleType.Crop
					v1002.BackgroundColor3 = v_u_31.Raised
					v1002.Parent = v997
					v1001("ImageLabel", v1002)
					if v994 then
						v_u_28.new("Frame", {
							["Name"] = "Tint",
							["Size"] = nil,
							["BackgroundColor3"] = nil,
							["BackgroundTransparency"] = 0.7,
							["Parent"] = nil,
							["Size"] = UDim2.new(1, 0, 0, 100),
							["BackgroundColor3"] = v_u_5.Color(v994.color1),
							["Parent"] = v997
						})
						v_u_38.new(44, {
							["Position"] = v_u_36(8, 50),
							["Parent"] = v997
						}):Set(v994.icon, v994.color1, v994.color2, v994.tag)
					end
					local v1004 = v_u_57
					local v1005 = {
						["Name"] = "Name",
						["Text"] = nil,
						["FontFace"] = nil,
						["TextSize"] = 16,
						["Position"] = nil,
						["Size"] = nil,
						["Parent"] = nil
					}
					local v1006
					if v992 then
						v1006 = v992.name or v_u_991
					else
						v1006 = v_u_991
					end
					v1005.Text = tostring(v1006)
					v1005.FontFace = v_u_32.Heavy
					v1005.Position = v_u_36(10, 104)
					v1005.Size = UDim2.new(1, -20, 0, 20)
					v1005.Parent = v997
					v1004(v1005)
					local v1007 = v_u_57
					local v1008 = {
						["Name"] = "By",
						["Text"] = nil,
						["FontFace"] = nil,
						["TextSize"] = 14,
						["TextColor3"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Parent"] = nil
					}
					local v1009
					if v994 then
						local v1010 = "Held by %*"
						local v1011 = v_u_38.Tag
						local v1012
						if type(v994) == "table" then
							v1012 = v994.tag
						else
							v1012 = v994
						end
						v1009 = v1010:format((v1011(v1012)))
					else
						v1009 = "Unclaimed"
					end
					v1008.Text = v1009
					v1008.FontFace = v_u_32.SemiBold
					local v1013
					if v994 then
						v1013 = v_u_38.TagColor(v994.color1)
					else
						v1013 = v_u_11
					end
					v1008.TextColor3 = v1013
					v1008.Position = v_u_36(10, 124)
					v1008.Size = UDim2.new(1, -20, 0, 18)
					v1008.Parent = v997
					v1007(v1008)
					v997.Activated:Connect(function()
						-- upvalues: (ref) v_u_152, (ref) p_u_27, (ref) v_u_918, (copy) v_u_991, (ref) v_u_935, (ref) v_u_920
						if os.clock() - v_u_152 >= 0.5 then
							p_u_27.Sounds.Play("Click")
							v_u_918 = v_u_991
							v_u_935()
							v_u_920(v_u_991)
						end
					end)
				end
			end
		else
			return
		end
	end
	v_u_920 = function(p1014)
		-- upvalues: (copy) v_u_85, (copy) v_u_912, (ref) v_u_919, (ref) v_u_151, (copy) v_u_53, (copy) v_u_33, (copy) v_u_28, (copy) v_u_31, (copy) v_u_57, (copy) v_u_32, (ref) v_u_152, (copy) p_u_27, (ref) v_u_46, (copy) v_u_38, (copy) v_u_36, (copy) v_u_61, (ref) v_u_12, (copy) v_u_29, (ref) v_u_5, (ref) v_u_13, (ref) v_u_26, (copy) v_u_70, (copy) v_u_205, (ref) v_u_11
		v_u_85(v_u_912)
		if v_u_919 then
			local v1015 = v_u_151
			if v1015 then
				v1015 = v_u_151.tribe
			end
			local v1016
			if type(v1015) == "table" then
				v1016 = {
					["id"] = v1015.id,
					["role"] = v_u_53(v1015)
				}
			else
				v1016 = v_u_33.Mine()
			end
			if p1014 and (v_u_919.maps and v_u_919.maps[p1014]) then
				local v1017 = v_u_919.maps[p1014]
				local v1018 = v_u_919 and v_u_919.maps
				if v1018 then
					v1018 = v_u_919.maps[p1014]
				end
				local v_u_1019 = v1018 and v1018.holder and v_u_919.tribes
				if v_u_1019 then
					local v1020 = v_u_919.tribes
					local v1021 = v1018.holder
					v_u_1019 = v1020[tostring(v1021)]
				end
				local v1022 = v_u_28.Panel({
					["Name"] = "Selected",
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["BackgroundTransparency"] = 0.06,
					["Radius"] = nil,
					["LayoutOrder"] = 1,
					["Parent"] = nil,
					["Size"] = UDim2.new(1, -6, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y,
					["Radius"] = UDim.new(0, 14),
					["Parent"] = v_u_912
				})
				v_u_28.Padding(10, 10, 10, 10).Parent = v1022
				v_u_28.List(Enum.FillDirection.Vertical, 8).Parent = v1022
				local v1023 = v_u_28.new
				local v1024 = {
					["Name"] = "Thumb"
				}
				local v1025 = v1017.thumb or ""
				v1024.Image = tostring(v1025)
				v1024.Size = UDim2.new(1, 0, 0, 150)
				v1024.ScaleType = Enum.ScaleType.Crop
				v1024.BackgroundColor3 = v_u_31.Raised
				v1024.ClipsDescendants = true
				v1024.LayoutOrder = 1
				__set_list(v1024, 1, {(v_u_28.Corner(10))})
				v1024.Parent = v1022
				local v1026 = v1023("ImageLabel", v1024)
				v_u_28.new("Frame", {
					["Name"] = "Shade",
					["Size"] = UDim2.fromScale(1, 1),
					["BackgroundColor3"] = Color3.new(1, 1, 1),
					v_u_28.Gradient(Color3.new(0, 0, 0), Color3.new(0, 0, 0), 90, NumberSequence.new(1, 0.1)),
					v_u_28.Corner(10),
					["Parent"] = v1026
				})
				local v1027 = v_u_57
				local v1028 = {
					["Name"] = "Name",
					["Text"] = nil,
					["FontFace"] = nil,
					["TextSize"] = 22,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil
				}
				local v1029 = string.upper
				local v1030 = v1017.name or p1014
				v1028.Text = v1029((tostring(v1030)))
				v1028.FontFace = v_u_32.Display
				v1028.AnchorPoint = Vector2.new(0, 1)
				v1028.Position = UDim2.new(0, 12, 1, -8)
				v1028.Size = UDim2.new(1, -24, 0, 26)
				v1028.Parent = v1026
				v1027(v1028)
				local v1031 = v_u_28.new("TextButton", {
					["Name"] = "Holder",
					["Text"] = "",
					["AutoButtonColor"] = false,
					["Size"] = nil,
					["LayoutOrder"] = 2,
					["Parent"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 54),
					["Parent"] = v1022
				})
				if v_u_1019 then
					v1031.Activated:Connect(function()
						-- upvalues: (ref) v_u_152, (ref) p_u_27, (ref) v_u_46, (copy) v_u_1019
						if os.clock() - v_u_152 >= 0.5 then
							p_u_27.Sounds.Play("Click")
							v_u_46(v_u_1019.id, v_u_1019)
						end
					end)
					v_u_38.new(48, {
						["Position"] = v_u_36(2, 1),
						["Parent"] = v1031
					}):Set(v_u_1019.icon, v_u_1019.color1, v_u_1019.color2, v_u_1019.tag)
					local v1032 = v_u_61
					local v1033 = v1016 and v_u_1019.id == v1016.id and "HELD BY YOUR TRIBE" or "HELD BY"
					local v1034 = {
						["Position"] = v_u_36(60, 8),
						["Size"] = UDim2.new(1, -60, 0, 14)
					}
					local v1035
					if v1016 and v_u_1019.id == v1016.id then
						v1035 = v_u_31.Accent
					else
						v1035 = v_u_31.TextMuted
					end
					v1034.TextColor3 = v1035
					v1034.Parent = v1031
					v1032(v1033, v1034)
					local v1036 = v_u_57
					local v1037 = {
						["Name"] = "By",
						["Text"] = nil,
						["RichText"] = true,
						["FontFace"] = nil,
						["TextSize"] = 16,
						["Position"] = nil,
						["Size"] = nil,
						["Parent"] = nil
					}
					local v1038 = string.format
					local v1039 = "<font color=\"#%s\">%s</font>  %s"
					local v1040 = v_u_38.TagColor(v_u_1019.color1):ToHex()
					local v1041 = v_u_38.Tag
					local v1042
					if type(v_u_1019) == "table" then
						v1042 = v_u_1019.tag
					else
						v1042 = v_u_1019
					end
					local v1043 = v1041(v1042)
					local v1044 = v_u_1019.name or ""
					v1037.Text = v1038(v1039, v1040, v1043, (tostring(v1044)))
					v1037.FontFace = v_u_32.Heavy
					v1037.Position = v_u_36(60, 24)
					v1037.Size = UDim2.new(1, -60, 0, 20)
					v1037.Parent = v1031
					v1036(v1037)
				else
					v_u_28.Glyph("flag", 26, v_u_31.TextMuted, {
						["Position"] = v_u_36(8, 8),
						["Parent"] = v1031
					})
					v_u_61("UNCLAIMED", {
						["Position"] = v_u_36(50, 3),
						["Size"] = UDim2.new(1, -50, 0, 14),
						["Parent"] = v1031
					})
					v_u_57({
						["Name"] = "By",
						["Text"] = "Win a match here to claim it",
						["FontFace"] = nil,
						["TextSize"] = 15,
						["TextColor3"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Parent"] = nil,
						["FontFace"] = v_u_32.Heavy,
						["TextColor3"] = v_u_31.TextDim,
						["Position"] = v_u_36(50, 19),
						["Size"] = UDim2.new(1, -50, 0, 20),
						["Parent"] = v1031
					})
				end
				local v1045 = v1017.top
				local v1046 = type(v1045) ~= "table" and {} or v1017.top
				if #v1046 > 0 then
					v_u_61("THIS WEEK", {
						["LayoutOrder"] = 3,
						["Parent"] = nil,
						["Parent"] = v1022
					})
				end
				local v1047
				if v1046[1] then
					local v1048 = v1046[1].points
					v1047 = tonumber(v1048) or 1
				else
					v1047 = 1
				end
				for v1049, v1050 in v1046 do
					local v1051 = v1050.tribe
					if type(v1051) ~= "table" then
						continue
					end
					local v1052 = v_u_28.new("Frame", {
						["Name"] = "Top" .. v1049,
						["Size"] = UDim2.new(1, 0, 0, 38),
						["LayoutOrder"] = 3 + v1049,
						["Parent"] = v1022
					})
					v_u_61(tostring(v1049), {
						["Position"] = v_u_36(0, 12),
						["Size"] = v_u_36(12, 14),
						["TextXAlignment"] = Enum.TextXAlignment.Center,
						["Parent"] = v1052
					})
					v_u_38.new(32, {
						["Position"] = v_u_36(16, 1),
						["Parent"] = v1052
					}):Set(v1051.icon, v1051.color1, v1051.color2, v1051.tag)
					local v1053 = v_u_57
					local v1054 = {
						["Name"] = "Tag",
						["Text"] = nil,
						["FontFace"] = nil,
						["TextSize"] = 14,
						["TextColor3"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Parent"] = nil
					}
					local v1055 = v_u_38.Tag
					local v1056
					if type(v1051) == "table" then
						v1056 = v1051.tag
					else
						v1056 = v1051
					end
					v1054.Text = v1055(v1056)
					v1054.FontFace = v_u_32.Heavy
					v1054.TextColor3 = v_u_38.TagColor(v1051.color1)
					v1054.Position = v_u_36(56, 3)
					v1054.Size = v_u_36(80, 16)
					v1054.Parent = v1052
					v1053(v1054)
					local v1057 = v_u_28.new("Frame", {
						["Name"] = "Bar",
						["Position"] = v_u_36(56, 23),
						["Size"] = UDim2.new(1, -112, 0, 6),
						["BackgroundColor3"] = v_u_12,
						v_u_28.Corner(v_u_29.Radius.Pill),
						["Parent"] = v1052
					})
					local v1058 = v_u_28.new("Frame", {
						["Name"] = "Fill",
						["Size"] = UDim2.fromScale(0, 1),
						["BackgroundColor3"] = v_u_5.Color(v1051.color1),
						v_u_28.Corner(v_u_29.Radius.Pill),
						["Parent"] = v1057
					})
					local v1059 = v_u_28.Tween
					local v1060 = TweenInfo.new(0.5, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, v1049 * 0.05)
					local v1061 = {}
					local v1062 = UDim2.fromScale
					local v1063 = v1050.points
					local v1064 = (tonumber(v1063) or 0) / v1047
					v1061.Size = v1062(math.clamp(v1064, 0.04, 1), 1)
					v1059(v1058, v1060, v1061)
					local v1065 = v_u_57
					local v1066 = {
						["Name"] = "Pts",
						["Text"] = nil,
						["FontFace"] = nil,
						["TextSize"] = 16,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Parent"] = nil
					}
					local v1067 = v1050.points
					v1066.Text = tostring(v1067)
					v1066.FontFace = v_u_32.Display
					v1066.TextColor3 = v_u_13
					v1066.TextXAlignment = Enum.TextXAlignment.Right
					v1066.AnchorPoint = Vector2.new(1, 0)
					v1066.Position = UDim2.new(1, 0, 0, 9)
					v1066.Size = v_u_36(50, 20)
					v1066.Parent = v1052
					v1065(v1066)
				end
				if v1016 and (#v1046 > 0 and (not v_u_1019 or v_u_1019.id ~= v1016.id)) then
					local v1068 = 0
					for _, v1069 in v1046 do
						local v1070 = v1069.tribe
						if type(v1070) ~= "table" or v1069.tribe.id ~= v1016.id then
							continue
						end
						local v1071 = v1069.points
						v1068 = tonumber(v1071) or 0
					end
					local v1072
					if v1046[1] then
						local v1073 = v1046[1].points
						v1072 = tonumber(v1073) or 0
					else
						v1072 = 0
					end
					v_u_57({
						["Name"] = "Mine",
						["Text"] = nil,
						["FontFace"] = nil,
						["TextSize"] = 14,
						["TextColor3"] = nil,
						["TextWrapped"] = true,
						["TextTruncate"] = nil,
						["AutomaticSize"] = nil,
						["Size"] = nil,
						["LayoutOrder"] = 9,
						["Parent"] = nil,
						["Text"] = ("Your tribe needs %* more Glory here to take it"):format(v1072 - v1068 + 1),
						["FontFace"] = v_u_32.Bold,
						["TextColor3"] = v_u_31.Accent,
						["TextTruncate"] = Enum.TextTruncate.None,
						["AutomaticSize"] = Enum.AutomaticSize.Y,
						["Size"] = UDim2.new(1, 0, 0, 0),
						["Parent"] = v1022
					})
				elseif v1016 and (v_u_1019 and v_u_1019.id == v1016.id) then
					v_u_57({
						["Name"] = "Mine",
						["Text"] = "Keep playing here to defend it",
						["FontFace"] = nil,
						["TextSize"] = 14,
						["TextColor3"] = nil,
						["Size"] = nil,
						["LayoutOrder"] = 9,
						["Parent"] = nil,
						["FontFace"] = v_u_32.Bold,
						["TextColor3"] = v_u_31.Accent,
						["Size"] = UDim2.new(1, 0, 0, 18),
						["Parent"] = v1022
					})
				end
			end
			local v1074 = {
				["LayoutOrder"] = 2,
				["Parent"] = nil,
				["Parent"] = v_u_912
			}
			v_u_61(("TERRITORIES RESET IN %*"):format((string.upper((v_u_26(v_u_919.weekEndsAt))))), v1074)
			local v1075 = v_u_919.order
			local v1076 = {}
			for _, v1077 in type(v1075) ~= "table" and {} or v_u_919.order do
				local v1078 = v_u_919.maps[v1077]
				if not (v1078 and v1078.holder) then
					continue
				end
				local v1079 = v1078.holder
				local v1080 = tostring(v1079)
				local v1081 = v1078.holder
				v1076[v1080] = (v1076[tostring(v1081)] or 0) + 1
			end
			local v1082 = {}
			for v1083, v1084 in v1076 do
				local v1085 = v_u_919.tribes
				if v1085 then
					v1085 = v_u_919.tribes[v1083]
				end
				if not v1085 then
					continue
				end
				table.insert(v1082, {
					["c"] = v1085,
					["n"] = v1084
				})
			end
			table.sort(v1082, function(p1086, p1087)
				return p1086.n > p1087.n
			end)
			v_u_70("WHO HOLDS WHAT", nil, nil, 3, v_u_912)
			for v1088, v1089 in v1082 do
				local v1090 = v_u_28.new("TextButton", {
					["Name"] = "H" .. v1088,
					["Text"] = "",
					["AutoButtonColor"] = false,
					["Size"] = UDim2.new(1, -6, 0, 50),
					["LayoutOrder"] = 3 + v1088,
					["BackgroundColor3"] = v_u_31.PanelHi,
					["BackgroundTransparency"] = 0.5,
					v_u_28.Corner(10),
					["Parent"] = v_u_912
				})
				local v1091 = v_u_28.Stroke(v_u_31.Stroke, 1, 0.92)
				v1091.Parent = v1090
				v_u_205(v1090, v1091, v1089.c)
				v_u_38.new(38, {
					["AnchorPoint"] = Vector2.new(0, 0.5),
					["Position"] = UDim2.new(0, 8, 0.5, 0),
					["Parent"] = v1090
				}):Set(v1089.c.icon, v1089.c.color1, v1089.c.color2, v1089.c.tag)
				local v1092 = v_u_57
				local v1093 = {
					["Name"] = "Name",
					["Text"] = nil,
					["RichText"] = true,
					["FontFace"] = nil,
					["TextSize"] = 14,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil
				}
				local v1094 = v1089.c
				local v1095 = string.format
				local v1096 = "<font color=\"#%s\">%s</font>  %s"
				local v1097 = v_u_38.TagColor(v1094.color1):ToHex()
				local v1098 = v_u_38.Tag
				local v1099
				if type(v1094) == "table" then
					v1099 = v1094.tag
				else
					v1099 = v1094
				end
				local v1100 = v1098(v1099)
				local v1101 = v1094.name or ""
				v1093.Text = v1095(v1096, v1097, v1100, (tostring(v1101)))
				v1093.FontFace = v_u_32.Heavy
				v1093.Position = v_u_36(54, 0)
				v1093.Size = UDim2.new(1, -106, 1, 0)
				v1093.Parent = v1090
				v1092(v1093)
				local v1102 = v_u_57
				local v1103 = {
					["Name"] = "N",
					["Text"] = nil,
					["FontFace"] = nil,
					["TextSize"] = 19,
					["TextXAlignment"] = nil,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil
				}
				local v1104 = v1089.n
				v1103.Text = tostring(v1104)
				v1103.FontFace = v_u_32.Display
				v1103.TextXAlignment = Enum.TextXAlignment.Right
				v1103.AnchorPoint = Vector2.new(1, 0)
				v1103.Position = UDim2.new(1, -12, 0, 0)
				v1103.Size = v_u_36(40, 50)
				v1103.Parent = v1090
				v1102(v1103)
			end
			if #v1082 == 0 then
				v_u_57({
					["Name"] = "NoneHeld",
					["Text"] = "Every territory is open this week.",
					["FontFace"] = nil,
					["TextSize"] = 14,
					["TextColor3"] = nil,
					["Size"] = nil,
					["LayoutOrder"] = 4,
					["Parent"] = nil,
					["FontFace"] = v_u_32.SemiBold,
					["TextColor3"] = v_u_11,
					["Size"] = UDim2.new(1, 0, 0, 24),
					["Parent"] = v_u_912
				})
			end
		end
	end
	function v_u_115.Territories()
		-- upvalues: (ref) v_u_919, (copy) v_u_33, (copy) v_u_916, (ref) v_u_5, (ref) v_u_151, (copy) v_u_53, (copy) p_u_27, (ref) v_u_918, (ref) v_u_935, (ref) v_u_920
		v_u_919 = v_u_33.Territories(false)
		v_u_916.Text = v_u_919 and "Loading the map..." or v_u_5.Message("unavailable")
		local v1105 = v_u_151
		if v1105 then
			v1105 = v_u_151.tribe
		end
		local v1106
		if type(v1105) == "table" then
			v1106 = {
				["id"] = v1105.id,
				["role"] = v_u_53(v1105)
			}
		else
			v1106 = v_u_33.Mine()
		end
		if p_u_27.TribeMapSelect then
			v_u_918 = p_u_27.TribeMapSelect
			p_u_27.TribeMapSelect = nil
		end
		if not v_u_918 and v_u_919 then
			local v1107 = v_u_919.order
			if type(v1107) == "table" then
				for _, v1108 in v_u_919.order do
					local v1109 = v_u_919 and v_u_919.maps
					if v1109 then
						v1109 = v_u_919.maps[v1108]
					end
					local v1110 = v1109 and v1109.holder and v_u_919.tribes
					if v1110 then
						local v1111 = v_u_919.tribes
						local v1112 = v1109.holder
						v1110 = v1111[tostring(v1112)]
					end
					if not v1110 or (not v1106 or v1110.id ~= v1106.id) then
						continue
					end
					v_u_918 = v1108
				end
				v_u_918 = v_u_918 or v_u_919.order[1]
			end
		end
		task.defer(function()
			-- upvalues: (ref) v_u_935, (ref) v_u_920, (ref) v_u_918
			v_u_935()
			v_u_920(v_u_918)
		end)
	end
	local v_u_1113 = v82("Left", v149.page, 12)
	local v_u_1114 = v82("Right", v149.page, 12)
	local v_u_1115 = "Find"
	local v_u_1116 = 0
	local v_u_1117 = nil
	local function v_u_1156(p1118, p1119) -- name: viewMemberRow
		-- upvalues: (ref) v_u_37, (copy) v_u_28, (copy) v_u_31, (copy) v_u_1114, (copy) v_u_36, (copy) v_u_29, (copy) v_u_57, (copy) v_u_32, (ref) v_u_14, (ref) v_u_11, (copy) v_u_194, (ref) v_u_13
		local v1120 = v_u_37.row - 6
		local v1121 = v_u_28.new
		local v1122 = {}
		local v1123 = p1118.userId
		v1122.Name = "M" .. tostring(v1123)
		v1122.Size = UDim2.new(1, -4, 0, v1120)
		v1122.LayoutOrder = p1119
		v1122.BackgroundColor3 = v_u_31.PanelHi
		v1122.BackgroundTransparency = p1119 % 2 == 0 and 0.55 or 0.35
		__set_list(v1122, 1, {(v_u_28.Corner(12))})
		v1122.Parent = v_u_1114
		local v1124 = v1121("Frame", v1122)
		local v1125 = v1120 - 16
		local v1126 = v_u_28.new("ImageLabel", {
			["Name"] = "Head",
			["Image"] = ("rbxthumb://type=AvatarHeadShot&id=%*&w=150&h=150"):format(p1118.userId),
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 10, 0.5, 0),
			["Size"] = v_u_36(v1125, v1125),
			["BackgroundColor3"] = v_u_31.Raised,
			v_u_28.Corner(v_u_29.Radius.Pill),
			["Parent"] = v1124
		})
		local v1127
		if p1118.where == false then
			v1127 = false
		else
			v1127 = p1118.where ~= nil
		end
		if v1127 then
			v_u_28.new("Frame", {
				["Name"] = "Dot",
				["AnchorPoint"] = Vector2.new(1, 1),
				["Position"] = UDim2.fromScale(1.02, 1.02),
				["Size"] = v_u_36(12, 12),
				["BackgroundColor3"] = v_u_31.Success,
				v_u_28.Corner(v_u_29.Radius.Pill),
				v_u_28.Stroke(v_u_31.Panel, 2, 0),
				["Parent"] = v1126
			})
		else
			v1126.ImageTransparency = 0.35
		end
		local v1128 = v1125 + 22
		local v1129 = v_u_28.Compact and 92 or 200
		local v1130 = v_u_28.new
		local v1131 = {
			["Name"] = "NameRow"
		}
		local v1132 = v_u_36
		local v1133 = v1120 / 2
		v1131.Position = v1132(v1128, math.floor(v1133) - v_u_37.text - 1)
		v1131.Size = UDim2.new(1, -(v1128 + v1129), 0, v_u_37.text + 4)
		__set_list(v1131, 1, {(v_u_28.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center))})
		v1131.Parent = v1124
		local v1134 = v1130("Frame", v1131)
		local v1135 = v_u_57
		local v1136 = {
			["Name"] = "Name",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil
		}
		local v1137 = p1118.display or p1118.name
		v1136.Text = tostring(v1137)
		v1136.FontFace = v_u_32.Heavy
		v1136.TextSize = v_u_37.text
		v1136.AutomaticSize = Enum.AutomaticSize.X
		v1136.Size = v_u_36(0, v_u_37.text + 4)
		v1136.Parent = v1134
		v1135(v1136)
		local v1138 = v_u_14[p1118.role]
		if v1138 then
			v_u_28.Pill(v1138.text, v1138.color, {
				["LayoutOrder"] = 2,
				["Height"] = 20,
				["TextSize"] = 11,
				["Parent"] = nil,
				["Parent"] = v1134
			})
		end
		local v1139 = v_u_57
		local v1140 = {
			["Name"] = "Sub",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = ("@%*  \194\183  Lv %*"):format(p1118.name, p1118.level),
			["FontFace"] = v_u_32.SemiBold,
			["TextSize"] = v_u_37.sub,
			["TextColor3"] = v_u_11
		}
		local v1141 = v_u_36
		local v1142 = v1120 / 2
		v1140.Position = v1141(v1128, math.floor(v1142) + 3)
		v1140.Size = UDim2.new(1, -(v1128 + v1129), 0, v_u_37.sub + 2)
		v1140.Parent = v1124
		v1139(v1140)
		local v1143 = v_u_28.new("Frame", {
			["Name"] = "Stats",
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -10, 0.5, 0),
			["Size"] = v_u_36(v1129 - 10, 40),
			v_u_28.List(Enum.FillDirection.Horizontal, 4, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
			["Parent"] = v1124
		})
		local v1144 = p1118.weekRenown
		local v1145 = tonumber(v1144) or 0
		local v1146 = v_u_194
		local v1147 = tostring(v1145)
		local v1148 = "GLORY"
		local v1149 = 1
		local v1150
		if v1145 > 0 then
			v1150 = v_u_13
		else
			v1150 = v_u_31.TextDim
		end
		v1146(v1143, v1147, v1148, v1149, v1150)
		if not v_u_28.Compact then
			local v1151 = v_u_28.Pill
			local v1152 = v1127 and "ONLINE" or "OFFLINE"
			local v1153
			if v1127 then
				v1153 = v_u_31.Success
			else
				v1153 = v_u_31.TextMuted
			end
			local v1154 = {
				["LayoutOrder"] = 2,
				["Height"] = 22,
				["TextSize"] = 11,
				["Transparency"] = nil,
				["TextColor"] = nil,
				["Parent"] = nil,
				["Transparency"] = v1127 and 0.15 or 0.75
			}
			local v1155
			if v1127 then
				v1155 = v_u_31.TextDark
			else
				v1155 = v_u_31.TextDim
			end
			v1154.TextColor = v1155
			v1154.Parent = v1143
			v1151(v1152, v1153, v1154)
		end
		return v1124
	end
	local function v_u_1223(p1157, p1158) -- name: renderView
		-- upvalues: (copy) v_u_85, (copy) v_u_1113, (copy) v_u_1114, (ref) v_u_5, (copy) v_u_28, (copy) v_u_93, (copy) v_u_137, (ref) v_u_1115, (copy) v_u_103, (ref) v_u_37, (copy) v_u_38, (copy) v_u_31, (copy) v_u_57, (copy) v_u_32, (copy) v_u_61, (ref) v_u_15, (copy) v_u_109, (ref) v_u_13, (ref) v_u_151, (copy) v_u_53, (copy) v_u_33, (copy) v_u_304, (copy) v_u_70, (ref) v_u_1116, (copy) v_u_469, (ref) v_u_153, (copy) v_u_1156
		v_u_85(v_u_1113)
		v_u_85(v_u_1114)
		local v1159 = v_u_5.Color(p1157.color1)
		v_u_93("\226\128\185  BACK", "Dark", v_u_28.new("Frame", {
			["Name"] = "BackRow",
			["Size"] = nil,
			["LayoutOrder"] = 0,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, -6, 0, 40),
			["Parent"] = v_u_1113
		}), function()
			-- upvalues: (ref) v_u_137, (ref) v_u_1115
			v_u_137(v_u_1115)
		end, {
			["Width"] = 110,
			["TextSize"] = 15
		})
		local v1160 = v_u_28.Panel({
			["Name"] = "Hero",
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["BackgroundTransparency"] = 0.06,
			["Radius"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, -6, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["Radius"] = UDim.new(0, 14),
			["Parent"] = v_u_1113
		})
		v_u_28.Padding(12, 12, 12, 12).Parent = v1160
		v_u_28.List(Enum.FillDirection.Vertical, 10).Parent = v1160
		local v1161, v1162 = v_u_103(v1160, v_u_37.hero, 1)
		v1162(v1159)
		v_u_38.new(v_u_28.Compact and 78 or 124, {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["ZIndex"] = 2,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.44),
			["Parent"] = v1161
		}):Set(p1157.icon, p1157.color1, p1157.color2, p1157.tag)
		local v1163 = v_u_28.Pill
		local v1164 = v_u_38.Tag
		local v1165
		if type(p1157) == "table" then
			v1165 = p1157.tag
		else
			v1165 = p1157
		end
		v1163(v1164(v1165), v_u_31.Void, {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Height"] = 26,
			["TextSize"] = 15,
			["TextColor"] = nil,
			["Transparency"] = 0.3,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, -10),
			["TextColor"] = v_u_38.TagColor(p1157.color1),
			["Parent"] = v1161
		})
		local v1166 = v_u_57
		local v1167 = {
			["Name"] = "Name",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextScaled"] = true,
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil
		}
		local v1168 = string.upper
		local v1169 = p1157.name or ""
		v1167.Text = v1168((tostring(v1169)))
		v1167.FontFace = v_u_32.Display
		v1167.Size = UDim2.new(1, 0, 0, 32)
		v1167.Parent = v1160
		local v1170 = {
			["MaxTextSize"] = 28,
			["MinTextSize"] = 16,
			["Parent"] = nil,
			["Parent"] = v1166(v1167)
		}
		v_u_28.new("UITextSizeConstraint", v1170)
		local v1171 = p1157.members
		local v1172 = tonumber(v1171) or 0
		local v1173 = p1157.online
		local v1174 = tonumber(v1173) or 0
		local v1175 = p1157.membersList
		if type(v1175) == "table" then
			v1174 = 0
			for _, v1176 in p1157.membersList do
				if not v1176.where then
					continue
				end
				v1174 = v1174 + 1
			end
		end
		v_u_61(("%*/%* MEMBERS  \194\183  %* ONLINE  \194\183  %*"):format(v1172, v_u_5.MAX_MEMBERS, v1174, (string.upper(v_u_15[p1157.joinMode] or ""))), {
			["LayoutOrder"] = 3,
			["Parent"] = nil,
			["Parent"] = v1160
		})
		local v1177 = v_u_28.new("Frame", {
			["Name"] = "Stats",
			["Size"] = UDim2.new(1, 0, 0, v_u_28.Compact and 52 or 62),
			["LayoutOrder"] = 4,
			v_u_28.List(Enum.FillDirection.Horizontal, 8),
			["Parent"] = v1160
		})
		local v1178 = v_u_109(v1177, "WEEK RANK", 1)
		local v1179 = v_u_109(v1177, "GLORY", 2)
		local v1180 = v_u_109(v1177, "TERRITORIES", 3)
		local v1181
		if p1157.rank then
			local v1182 = p1157.rank
			v1181 = "#" .. tostring(v1182)
		else
			v1181 = "-"
		end
		v1178.Text = v1181
		local v1183 = v_u_28.FormatCompact
		local v1184 = p1157.weekRenown
		v1179.Text = v1183(tonumber(v1184) or 0)
		v1179.TextColor3 = v_u_13
		local v1185 = p1157.territories
		local v1186 = type(v1185) ~= "table" and {} or p1157.territories
		local v1187
		if p1158 then
			local v1188 = #v1186
			v1187 = tostring(v1188)
		else
			local v1189 = p1157.held
			local v1190 = tonumber(v1189) or 0
			v1187 = tostring(v1190)
		end
		v1180.Text = v1187
		local v1191 = p1157.renownTotal or p1157.renown
		local v1192 = tonumber(v1191) or 0
		v_u_61(("%* GLORY ALL TIME"):format((v_u_28.FormatNumber(v1192))), {
			["TextXAlignment"] = nil,
			["LayoutOrder"] = 5,
			["Parent"] = nil,
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["Parent"] = v1160
		})
		local v1193 = v_u_151
		if v1193 then
			v1193 = v_u_151.tribe
		end
		local v1194
		if type(v1193) == "table" then
			v1194 = {
				["id"] = v1193.id,
				["role"] = v_u_53(v1193)
			}
		else
			v1194 = v_u_33.Mine()
		end
		if not v1194 then
			v_u_304(p1157, v_u_28.new("Frame", {
				["Name"] = "Join",
				["Size"] = UDim2.new(1, 0, 0, 46),
				["LayoutOrder"] = 6,
				v_u_28.List(Enum.FillDirection.Horizontal, 0, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
				["Parent"] = v1160
			}), UDim2.new(1, 0, 0, 46))
		end
		local v1195 = v_u_70
		local v1196 = "TERRITORIES"
		local v1197 = p1158 and #v1186 or nil
		local v1198
		if p1158 and #v1186 == 0 then
			v1198 = nil
		else
			v1198 = p1158 and "held this week" or nil
		end
		v1195(v1196, v1197, v1198, 1, v_u_1114)
		if p1158 then
			local v_u_1199 = v_u_1116
			v_u_469(v1186, v_u_1114, 2, v1159, function()
				-- upvalues: (copy) v_u_1199, (ref) v_u_1116, (ref) v_u_153
				local v1200
				if v_u_1199 == v_u_1116 then
					v1200 = v_u_153 == "View"
				else
					v1200 = false
				end
				return v1200
			end, "No territories this week.")
		end
		local v1201 = p1157.membersList
		local v1202
		if type(v1201) == "table" then
			v1202 = p1157.membersList
		else
			v1202 = nil
		end
		v_u_70("MEMBERS", v1172, nil, 3, v_u_1114)
		if v1202 then
			local v1203 = table.clone(v1202)
			local v_u_1204 = {
				["chief"] = 0,
				["elder"] = 1
			}
			table.sort(v1203, function(p1205, p1206)
				-- upvalues: (copy) v_u_1204
				local v1207 = v_u_1204[p1205.role] or 2
				local v1208 = v_u_1204[p1206.role] or 2
				if v1207 ~= v1208 then
					return v1207 < v1208
				end
				local v1209 = p1205.where and 1 or 0
				local v1210 = p1206.where and 1 or 0
				if v1209 ~= v1210 then
					return v1210 < v1209
				end
				local v1211 = p1205.weekRenown
				local v1212 = tonumber(v1211) or 0
				local v1213 = p1206.weekRenown
				return (tonumber(v1213) or 0) < v1212
			end)
			for v1214, v1215 in v1203 do
				local v1216 = v_u_1156(v1215, 3 + v1214)
				local v1217 = v_u_28.Enter
				local v1218 = Vector2.new(0, 8)
				local v1219 = v1214 * 0.025
				v1217(v1216, v1218, math.min(v1219, 0.25), UDim2.new())
			end
		else
			local v1220 = math.max(v1172, 1)
			for v1221 = 1, math.min(v1220, 4) do
				local v1222 = v_u_28.new("Frame", {
					["Name"] = "Skeleton",
					["Size"] = UDim2.new(1, -4, 0, v_u_37.row - 6),
					["LayoutOrder"] = v1221 + 3,
					["BackgroundColor3"] = v_u_31.PanelHi,
					["BackgroundTransparency"] = 0.5,
					v_u_28.Corner(12),
					["Parent"] = v_u_1114
				})
				v_u_28.Tween(v1222, TweenInfo.new(0.8, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true, v1221 * 0.12), {
					["BackgroundTransparency"] = 0.78
				})
			end
		end
	end
	local function v1234(p_u_1224, p1225)
		-- upvalues: (ref) v_u_151, (copy) v_u_53, (copy) v_u_33, (copy) v_u_137, (ref) v_u_153, (ref) v_u_1115, (ref) v_u_1117, (ref) v_u_1116, (copy) v_u_1113, (copy) v_u_1114, (copy) v_u_1223, (copy) v_u_85, (copy) v_u_28, (copy) v_u_93, (copy) v_u_57, (ref) v_u_5, (copy) v_u_32, (ref) v_u_11
		if type(p_u_1224) == "number" then
			local v1226 = v_u_151
			if v1226 then
				v1226 = v_u_151.tribe
			end
			local v1227
			if type(v1226) == "table" then
				v1227 = {
					["id"] = v1226.id,
					["role"] = v_u_53(v1226)
				}
			else
				v1227 = v_u_33.Mine()
			end
			if v1227 and v1227.id == p_u_1224 then
				v_u_137("Overview")
			else
				if v_u_153 ~= "View" then
					v_u_1115 = v_u_153 or "Find"
				end
				v_u_1117 = p_u_1224
				v_u_1116 = v_u_1116 + 1
				local v_u_1228 = v_u_1116
				v_u_1113.CanvasPosition = Vector2.zero
				v_u_1114.CanvasPosition = Vector2.zero
				if type(p1225) == "table" and p1225.tag then
					v_u_1223(p1225, false)
				else
					v_u_85(v_u_1113)
					v_u_85(v_u_1114)
				end
				v_u_137("View")
				task.spawn(function()
					-- upvalues: (ref) v_u_33, (copy) p_u_1224, (copy) v_u_1228, (ref) v_u_1116, (ref) v_u_85, (ref) v_u_1113, (ref) v_u_1114, (ref) v_u_28, (ref) v_u_93, (ref) v_u_137, (ref) v_u_1115, (ref) v_u_57, (ref) v_u_5, (ref) v_u_32, (ref) v_u_11, (ref) v_u_1223
					local v1229, v1230 = v_u_33.Action("Get", p_u_1224)
					if v_u_1228 == v_u_1116 then
						if v1229 and type(v1230) == "table" then
							v_u_1223(v1230, true)
						else
							v_u_85(v_u_1113)
							v_u_85(v_u_1114)
							v_u_93("\226\128\185  BACK", "Dark", v_u_28.new("Frame", {
								["Name"] = "BackRow",
								["Size"] = nil,
								["LayoutOrder"] = 0,
								["Parent"] = nil,
								["Size"] = UDim2.new(1, -6, 0, 40),
								["Parent"] = v_u_1113
							}), function()
								-- upvalues: (ref) v_u_137, (ref) v_u_1115
								v_u_137(v_u_1115)
							end, {
								["Width"] = 110,
								["TextSize"] = 15
							})
							local v1231 = v_u_57
							local v1232 = {
								["Name"] = "Gone",
								["Text"] = nil,
								["FontFace"] = nil,
								["TextSize"] = 16,
								["TextColor3"] = nil,
								["TextWrapped"] = true,
								["TextTruncate"] = nil,
								["Size"] = nil,
								["LayoutOrder"] = 1,
								["Parent"] = nil
							}
							local v1233 = v1230 or v_u_5.Message("unavailable")
							v1232.Text = tostring(v1233)
							v1232.FontFace = v_u_32.SemiBold
							v1232.TextColor3 = v_u_11
							v1232.TextTruncate = Enum.TextTruncate.None
							v1232.Size = UDim2.new(1, 0, 0, 60)
							v1232.Parent = v_u_1114
							v1231(v1232)
						end
					else
						return
					end
				end)
			end
		else
			return
		end
	end
	local v_u_1235 = {
		["tag"] = "",
		["name"] = "",
		["icon"] = 1,
		["color1"] = 1,
		["color2"] = nil,
		["joinMode"] = "open",
		["minLevel"] = 0,
		["color2"] = v_u_5.WHITE
	}
	local v_u_1236 = v82("Left", v148.page, 10)
	local v_u_1237 = v82("Right", v148.page, 10)
	local v1238 = v_u_28.Panel({
		["Name"] = "PreviewPanel",
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["BackgroundTransparency"] = 0.06,
		["Radius"] = nil,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, -6, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Radius"] = UDim.new(0, 14),
		["Parent"] = v_u_1236
	})
	v78(v1238, 12)
	v_u_28.List(Enum.FillDirection.Vertical, 10).Parent = v1238
	local v1239, v_u_1240 = v_u_103(v1238, v_u_37.hero - 40, 1)
	local v_u_1241 = v_u_38.new(v_u_28.Compact and 96 or 112, {
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["ZIndex"] = 2,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Parent"] = v1239
	})
	local v1242 = v_u_28.new("Frame", {
		["Name"] = "Plate",
		["Size"] = UDim2.new(1, 0, 0, 36),
		["LayoutOrder"] = 2,
		["BackgroundColor3"] = v_u_31.Inset,
		["BackgroundTransparency"] = 0.3,
		v_u_28.Corner(10),
		["Parent"] = v1238
	})
	local v_u_1243 = v_u_57({
		["Name"] = "Text",
		["Text"] = "",
		["RichText"] = true,
		["FontFace"] = nil,
		["TextSize"] = 16,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_32.Heavy,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v1242
	})
	local function v1258(p1244, p1245, p1246, p_u_1247, p1248, p1249) -- name: field
		-- upvalues: (copy) v_u_28, (copy) v_u_61, (copy) v_u_36, (ref) v_u_12, (copy) v_u_31, (copy) v_u_32, (copy) v_u_29
		local v1250 = v_u_28.new("Frame", {
			["Name"] = p1244 .. "Wrap",
			["Size"] = UDim2.new(1, -6, 0, 68),
			["LayoutOrder"] = p1248,
			["Parent"] = p1249
		})
		v_u_61(p1245, {
			["Parent"] = v1250
		})
		local v_u_1251 = v_u_61(("0/%*"):format(p_u_1247), {
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, 0, 0, 0),
			["Size"] = v_u_36(60, 14),
			["Parent"] = v1250
		})
		local v1252 = v_u_28.new("Frame", {
			["Name"] = p1244 .. "Field",
			["Position"] = v_u_36(0, 20),
			["Size"] = UDim2.new(1, 0, 0, 46),
			["BackgroundColor3"] = v_u_12,
			["BackgroundTransparency"] = 0.25,
			v_u_28.Corner(10),
			["Parent"] = v1250
		})
		local v_u_1253 = v_u_28.Stroke(v_u_31.Stroke, 1, 0.88)
		v_u_1253.Parent = v1252
		local v_u_1254 = v_u_28.new("TextBox", {
			["Name"] = nil,
			["Text"] = "",
			["PlaceholderText"] = nil,
			["PlaceholderColor3"] = nil,
			["ClearTextOnFocus"] = false,
			["FontFace"] = nil,
			["TextSize"] = 18,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Name"] = p1244,
			["PlaceholderText"] = p1246,
			["PlaceholderColor3"] = v_u_31.TextMuted,
			["FontFace"] = v_u_32.Bold,
			["TextColor3"] = v_u_31.Text,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Position"] = v_u_36(14, 0),
			["Size"] = UDim2.new(1, -28, 1, 0),
			["Parent"] = v1252
		})
		v_u_1254:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (copy) v_u_1254, (copy) p_u_1247, (copy) v_u_1251
			if p_u_1247 < #v_u_1254.Text then
				local v1255 = v_u_1254
				local v1256 = v_u_1254.Text
				local v1257 = p_u_1247
				v1255.Text = string.sub(v1256, 1, v1257)
			else
				v_u_1251.Text = ("%*/%*"):format(#v_u_1254.Text, p_u_1247)
			end
		end)
		v_u_1254.Focused:Connect(function()
			-- upvalues: (ref) v_u_28, (copy) v_u_1253, (ref) v_u_29, (ref) v_u_31
			v_u_28.Tween(v_u_1253, v_u_29.Tween.Fast, {
				["Color"] = nil,
				["Transparency"] = 0.2,
				["Color"] = v_u_31.Accent
			})
		end)
		v_u_1254.FocusLost:Connect(function()
			-- upvalues: (ref) v_u_28, (copy) v_u_1253, (ref) v_u_29, (ref) v_u_31
			v_u_28.Tween(v_u_1253, v_u_29.Tween.Fast, {
				["Color"] = nil,
				["Transparency"] = 0.88,
				["Color"] = v_u_31.Stroke
			})
		end)
		return v_u_1254, v_u_1251
	end
	local v_u_1259 = v1258("Tag", "TAG  \194\183  2 TO 4 LETTERS OR NUMBERS", "NITE", v_u_5.TAG_MAX, 3, v_u_1236)
	local v_u_1260 = v1258("TribeName", "NAME", "Night Owls", v_u_5.NAME_MAX, 4, v_u_1236)
	local v1261 = v_u_28.new("Frame", {
		["Name"] = "JoinWrap",
		["Size"] = nil,
		["LayoutOrder"] = 5,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, -6, 0, 86),
		["Parent"] = v_u_1236
	})
	v_u_61("WHO CAN JOIN", {
		["Parent"] = v1261
	})
	local v1262 = v_u_28.new("Frame", {
		["Name"] = "JoinMode",
		["Position"] = v_u_36(0, 20),
		["Size"] = UDim2.new(1, 0, 0, 42),
		["BackgroundColor3"] = v_u_12,
		["BackgroundTransparency"] = 0.25,
		v_u_28.Corner(v_u_29.Radius.Pill),
		v_u_28.Padding(4, 4, 4, 4),
		v_u_28.List(Enum.FillDirection.Horizontal, 4),
		["Parent"] = v1261
	})
	local v_u_1263 = v_u_57({
		["Name"] = "JoinDesc",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_32.SemiBold,
		["TextColor3"] = v_u_11,
		["Position"] = v_u_36(4, 66),
		["Size"] = UDim2.new(1, -8, 0, 16),
		["Parent"] = v1261
	})
	local v_u_1264 = v_u_1115
	local v_u_1265 = v_u_1116
	local v_u_1266 = v1234
	local v_u_1267 = v_u_1117
	local v_u_1268 = {}
	local v_u_1269 = "create"
	for v1270, v1271 in v_u_5.JOIN_MODES do
		v_u_1268[v1271] = v_u_28.new("TextButton", {
			["Name"] = v1271,
			["Text"] = v_u_15[v1271],
			["AutoButtonColor"] = false,
			["FontFace"] = v_u_32.Heavy,
			["TextSize"] = 13,
			["TextColor3"] = v_u_31.TextDim,
			["Size"] = UDim2.new(0.3333333333333333, -3, 1, 0),
			["LayoutOrder"] = v1270,
			["BackgroundColor3"] = v_u_31.Accent,
			["BackgroundTransparency"] = 1,
			v_u_28.Corner(v_u_29.Radius.Pill),
			["Parent"] = v1262
		})
	end
	local v1272 = v_u_28.new("Frame", {
		["Name"] = "LevelWrap",
		["Size"] = nil,
		["LayoutOrder"] = 6,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, -6, 0, 66),
		["Parent"] = v_u_1236
	})
	v_u_61("MINIMUM LEVEL TO JOIN", {
		["Parent"] = v1272
	})
	local v1273 = v_u_28.new("Frame", {
		["Name"] = "Stepper",
		["Position"] = v_u_36(0, 20),
		["Size"] = UDim2.new(1, 0, 0, 42),
		["BackgroundColor3"] = v_u_12,
		["BackgroundTransparency"] = 0.25,
		v_u_28.Corner(v_u_29.Radius.Pill),
		["Parent"] = v1272
	})
	local v_u_1274 = v_u_57({
		["Name"] = "Value",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 18,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_32.Display,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v1273
	})
	local v1275 = v_u_28.IconButton({
		["Name"] = "Minus",
		["Text"] = "-",
		["TextSize"] = 24,
		["Size"] = nil,
		["Position"] = nil,
		["Color"] = nil,
		["Radius"] = 17,
		["Parent"] = nil,
		["Size"] = v_u_36(34, 34),
		["Position"] = v_u_36(4, 4),
		["Color"] = v_u_31.Raised,
		["Parent"] = v1273
	})
	local v1276 = v_u_28.IconButton({
		["Name"] = "Plus",
		["Text"] = "+",
		["TextSize"] = 22,
		["Size"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Color"] = nil,
		["Radius"] = 17,
		["Parent"] = nil,
		["Size"] = v_u_36(34, 34),
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -4, 0, 4),
		["Color"] = v_u_31.Raised,
		["Parent"] = v1273
	})
	v_u_70("EMBLEM", #v_u_5.ICONS, "pick one", 1, v_u_1237)
	local v1277 = v_u_28.new("Frame", {
		["Name"] = "Icons",
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, -6, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v_u_1237
	})
	v_u_28.new("UIGridLayout", {
		["CellSize"] = nil,
		["CellPadding"] = nil,
		["FillDirectionMaxCells"] = 12,
		["SortOrder"] = nil,
		["Parent"] = nil,
		["CellSize"] = v_u_36(v_u_37.cell, v_u_37.cell),
		["CellPadding"] = v_u_36(6, 6),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v1277
	})
	v_u_70("COLOUR", nil, "the crest", 3, v_u_1237)
	local v1278 = v_u_28.new("Frame", {
		["Name"] = "Color1",
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 4,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, -6, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v_u_1237
	})
	v_u_28.new("UIGridLayout", {
		["CellSize"] = nil,
		["CellPadding"] = nil,
		["FillDirectionMaxCells"] = 12,
		["SortOrder"] = nil,
		["Parent"] = nil,
		["CellSize"] = v_u_36(v_u_37.swatch, v_u_37.swatch),
		["CellPadding"] = v_u_36(10, 10),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v1278
	})
	v_u_70("SECOND COLOUR", nil, "the icon and rim", 5, v_u_1237)
	local v1279 = v_u_28.new("Frame", {
		["Name"] = "Color2",
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 6,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, -6, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v_u_1237
	})
	v_u_28.new("UIGridLayout", {
		["CellSize"] = nil,
		["CellPadding"] = nil,
		["FillDirectionMaxCells"] = 12,
		["SortOrder"] = nil,
		["Parent"] = nil,
		["CellSize"] = v_u_36(v_u_37.swatch, v_u_37.swatch),
		["CellPadding"] = v_u_36(10, 10),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v1279
	})
	local v1280 = v_u_28.new("Frame", {
		["Name"] = "Buttons",
		["Size"] = UDim2.new(1, -6, 0, 54),
		["LayoutOrder"] = 20,
		v_u_28.List(Enum.FillDirection.Horizontal, 10, Enum.HorizontalAlignment.Right),
		["Parent"] = v_u_1237
	})
	v_u_57({
		["Name"] = "Credit",
		["Text"] = "Emblem icons by Lorc, Delapouite, Caro Asercion, Carl Olsen and sbed from game-icons.net, CC BY 3.0 (creativecommons.org/licenses/by/3.0), recoloured",
		["FontFace"] = nil,
		["TextSize"] = 12,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextTruncate"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["LayoutOrder"] = 21,
		["Parent"] = nil,
		["FontFace"] = v_u_32.Medium,
		["TextColor3"] = v_u_31.TextMuted,
		["TextTruncate"] = Enum.TextTruncate.None,
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Size"] = UDim2.new(1, -6, 0, 0),
		["Parent"] = v_u_1237
	})
	local v1281 = v_u_28.Button({
		["Name"] = "Cancel",
		["Text"] = "BACK",
		["Style"] = "Dark",
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["Size"] = v_u_36(150, 52),
		["Parent"] = v1280
	})
	local v_u_1282 = v_u_28.Button({
		["Name"] = "Submit",
		["Text"] = "FOUND TRIBE",
		["Style"] = "Primary",
		["Size"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["Size"] = v_u_36(240, 52),
		["Parent"] = v1280
	})
	local v_u_1283 = {}
	local v_u_1284 = {}
	local v_u_1285 = {}
	local function v_u_1298() -- name: paintForm
		-- upvalues: (copy) v_u_1241, (ref) v_u_1235, (copy) v_u_1240, (ref) v_u_5, (copy) v_u_1259, (copy) v_u_38, (copy) v_u_1243, (copy) v_u_35, (copy) v_u_1283, (copy) v_u_1284, (copy) v_u_1285, (copy) v_u_1268, (copy) v_u_31, (copy) v_u_1263, (ref) v_u_16, (copy) v_u_1274
		v_u_1241:Set(v_u_1235.icon, v_u_1235.color1, v_u_1235.color2, v_u_1235.tag)
		v_u_1240(v_u_5.Color(v_u_1235.color1))
		local v1286 = v_u_5.CleanTag(v_u_1259.Text)
		local v1287 = v_u_38.TagColor(v_u_1235.color1)
		local v1288 = v_u_35
		v_u_1243.Text = string.format("<font color=\"#AEB5C2\">[%d]</font> <font color=\"#%s\">[%s]</font> %s", tonumber(v1288:GetAttribute("Level")) or 1, v1287:ToHex(), v1286 == "" and "TAG" or v1286, v_u_35.DisplayName)
		for v1289, v1290 in v_u_1283 do
			v1290.emblem:Set(v1289, v_u_1235.color1, v_u_1235.color2, nil)
			v1290.stroke.Transparency = v1289 == v_u_1235.icon and 0 or 1
			v1290.button.BackgroundTransparency = v1289 == v_u_1235.icon and 0.1 or 0.45
		end
		for v1291, v1292 in v_u_1284 do
			v1292.Transparency = v1291 == v_u_1235.color1 and 0 or 1
		end
		for v1293, v1294 in v_u_1285 do
			v1294.Transparency = v1293 == v_u_1235.color2 and 0 or 1
		end
		for v1295, v1296 in v_u_1268 do
			v1296.BackgroundTransparency = v1295 == v_u_1235.joinMode and 0 or 1
			local v1297
			if v1295 == v_u_1235.joinMode then
				v1297 = v_u_31.Text
			else
				v1297 = v_u_31.TextDim
			end
			v1296.TextColor3 = v1297
		end
		v_u_1263.Text = v_u_16[v_u_1235.joinMode] or ""
		v_u_1274.Text = v_u_1235.minLevel <= 0 and "ANY LEVEL" or ("LEVEL %*+"):format(v_u_1235.minLevel)
	end
	for v_u_1299 = 1, #v_u_5.ICONS do
		local v1300 = v_u_28.new("TextButton", {
			["Name"] = "Icon" .. v_u_1299,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["LayoutOrder"] = v_u_1299,
			["BackgroundColor3"] = v_u_31.PanelHi,
			["BackgroundTransparency"] = 0.45,
			v_u_28.Corner(10),
			["Parent"] = v1277
		})
		local v1301 = v_u_28.Stroke(v_u_31.Accent, 2, 1)
		v1301.Parent = v1300
		v_u_1283[v_u_1299] = {
			["button"] = v1300,
			["stroke"] = v1301,
			["emblem"] = v_u_38.new(v_u_37.cell - 6, {
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Parent"] = v1300
			})
		}
		v1300.Activated:Connect(function()
			-- upvalues: (ref) v_u_1235, (copy) v_u_1299, (copy) p_u_27, (copy) v_u_1298, (copy) v_u_28, (copy) v_u_1241
			v_u_1235.icon = v_u_1299
			p_u_27.Sounds.Play("Click")
			v_u_1298()
			v_u_28.Pop(v_u_1241.Instance, 0.9)
		end)
	end
	for v_u_1302, v1303 in v_u_5.COLORS do
		for v_u_1304, v1305 in { v1278, v1279 } do
			local v1306 = v_u_28.new("TextButton", {
				["Name"] = "C" .. v_u_1302,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["LayoutOrder"] = v_u_1302,
				["BackgroundColor3"] = v1303,
				v_u_28.Corner(v_u_29.Radius.Pill),
				["Parent"] = v1305
			})
			local v1307 = v_u_28.Stroke(v_u_31.Text, 3, 1)
			v1307.Parent = v1306
			if v_u_1304 == 1 then
				v_u_1284[v_u_1302] = v1307
			else
				v_u_1285[v_u_1302] = v1307
			end
			v1306.Activated:Connect(function()
				-- upvalues: (copy) v_u_1304, (ref) v_u_1235, (copy) v_u_1302, (copy) p_u_27, (copy) v_u_1298
				if v_u_1304 == 1 then
					v_u_1235.color1 = v_u_1302
				else
					v_u_1235.color2 = v_u_1302
				end
				p_u_27.Sounds.Play("Click")
				v_u_1298()
			end)
		end
	end
	for v_u_1308, v1309 in v_u_1268 do
		v1309.Activated:Connect(function()
			-- upvalues: (ref) v_u_1235, (copy) v_u_1308, (copy) p_u_27, (copy) v_u_1298
			v_u_1235.joinMode = v_u_1308
			p_u_27.Sounds.Play("Click")
			v_u_1298()
		end)
	end
	v1275.Activated:Connect(function()
		-- upvalues: (ref) v_u_17, (ref) v_u_1235, (copy) v_u_1298, (copy) v_u_28, (copy) v_u_1274
		local v1310 = v_u_1235
		local v1311 = v_u_17
		local v1312 = (table.find(v_u_17, v_u_1235.minLevel) or 1) + -1
		local v1313 = #v_u_17
		v1310.minLevel = v1311[math.clamp(v1312, 1, v1313)]
		v_u_1298()
		v_u_28.Bump(v_u_1274, 0.12)
	end)
	v1276.Activated:Connect(function()
		-- upvalues: (ref) v_u_17, (ref) v_u_1235, (copy) v_u_1298, (copy) v_u_28, (copy) v_u_1274
		local v1314 = v_u_1235
		local v1315 = v_u_17
		local v1316 = (table.find(v_u_17, v_u_1235.minLevel) or 1) + 1
		local v1317 = #v_u_17
		v1314.minLevel = v1315[math.clamp(v1316, 1, v1317)]
		v_u_1298()
		v_u_28.Bump(v_u_1274, 0.12)
	end)
	v_u_1259:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_1259, (copy) v_u_1298
		local v1318 = string.gsub(string.upper(v_u_1259.Text), "[^A-Z0-9]", "")
		if v1318 == v_u_1259.Text then
			v_u_1298()
		else
			v_u_1259.Text = v1318
		end
	end)
	v_u_1260:GetPropertyChangedSignal("Text"):Connect(v_u_1298)
	function p_u_27.OpenTribeForm(p1319)
		-- upvalues: (ref) v_u_1269, (ref) v_u_151, (ref) v_u_1235, (copy) v_u_1259, (copy) v_u_31, (copy) v_u_1260, (copy) v_u_1282, (ref) v_u_5, (copy) v_u_1298, (copy) v_u_137, (copy) v_u_1236, (copy) v_u_1237, (copy) v_u_28, (ref) v_u_2
		v_u_1269 = p1319
		local v1320 = v_u_151
		if v1320 then
			v1320 = v_u_151.tribe
		end
		if p1319 == "settings" and type(v1320) == "table" then
			local v1321 = {
				["tag"] = v1320.tag,
				["name"] = v1320.name,
				["icon"] = v1320.icon,
				["color1"] = v1320.color1,
				["color2"] = v1320.color2,
				["joinMode"] = v1320.joinMode
			}
			local v1322 = v1320.minLevel
			v1321.minLevel = tonumber(v1322) or 0
			v_u_1235 = v1321
			v_u_1259.Text = v1320.tag
			v_u_1259.TextEditable = false
			v_u_1259.TextColor3 = v_u_31.TextDim
			v_u_1260.Text = v1320.name
			v_u_1282:SetText("SAVE")
		else
			v_u_1235 = {
				["tag"] = "",
				["name"] = "",
				["icon"] = nil,
				["color1"] = nil,
				["color2"] = nil,
				["joinMode"] = "open",
				["minLevel"] = 0,
				["icon"] = math.random(1, #v_u_5.ICONS),
				["color1"] = math.random(1, 14),
				["color2"] = v_u_5.WHITE
			}
			v_u_1259.Text = ""
			v_u_1259.TextEditable = true
			v_u_1259.TextColor3 = v_u_31.Text
			v_u_1260.Text = ""
			v_u_1282:SetText("FOUND TRIBE")
		end
		v_u_1298()
		v_u_137("Form")
		v_u_1236.CanvasPosition = Vector2.zero
		v_u_1237.CanvasPosition = Vector2.zero
		if v_u_28.Gamepad then
			v_u_2.SelectedObject = v_u_1282.Instance
		end
	end
	v1281.Activated:Connect(function()
		-- upvalues: (ref) v_u_152, (copy) v_u_137, (ref) v_u_151
		if os.clock() - v_u_152 >= 0.5 then
			v_u_137(v_u_151 and v_u_151.tribe and "Overview" or "Find")
		end
	end)
	v_u_1282.Activated:Connect(function()
		-- upvalues: (ref) v_u_152, (ref) v_u_5, (copy) v_u_1259, (copy) v_u_1260, (ref) v_u_1269, (copy) p_u_27, (copy) v_u_28, (copy) v_u_181, (ref) v_u_1235, (copy) v_u_33, (ref) v_u_153, (ref) v_u_45, (ref) v_u_151, (copy) v_u_137
		if os.clock() - v_u_152 >= 0.5 then
			local v1323 = v_u_5.CleanTag(v_u_1259.Text)
			local v1324 = v_u_5.CleanName(v_u_1260.Text)
			if v_u_1269 == "create" and not v_u_5.ValidTag(v1323) then
				p_u_27.Toast(v_u_5.Message("bad_tag"), "error")
				v_u_28.Shake(v_u_1259.Parent, 6)
				return
			elseif v_u_5.ValidName(v1324) then
				if v_u_1269 == "create" then
					if v_u_181("Create", {
						["tag"] = v1323,
						["name"] = v1324,
						["icon"] = v_u_1235.icon,
						["color1"] = v_u_1235.color1,
						["color2"] = v_u_1235.color2,
						["joinMode"] = v_u_1235.joinMode,
						["minLevel"] = v_u_1235.minLevel
					}) then
						p_u_27.Sounds.Play("Queue_Join")
						p_u_27.Toast(("[%*] %* is founded!"):format(v1323, v1324), "success")
						local v1325 = v_u_33.Home(true)
						v_u_153 = nil
						v_u_45(v1325 or v_u_151)
						if v_u_151 then
							local v1326 = v_u_151.tribe
							if type(v1326) == "table" then
								v_u_137("Overview")
								return
							end
						end
					end
				elseif v_u_181("Settings", {
					["name"] = v1324,
					["icon"] = v_u_1235.icon,
					["color1"] = v_u_1235.color1,
					["color2"] = v_u_1235.color2,
					["joinMode"] = v_u_1235.joinMode,
					["minLevel"] = v_u_1235.minLevel
				}) then
					p_u_27.Toast("Tribe saved", "success")
					local v1327 = v_u_33.Home(true)
					v_u_153 = nil
					v_u_45(v1327 or v_u_151)
					if v_u_151 then
						local v1328 = v_u_151.tribe
						if type(v1328) == "table" then
							v_u_137("Overview")
						end
					end
				end
			else
				p_u_27.Toast(v_u_5.Message("bad_name"), "error")
				v_u_28.Shake(v_u_1260.Parent, 6)
			end
		else
			return
		end
	end)
	if p_u_27.Economy then
		p_u_27.Economy.Event:Connect(function(p1329)
			-- upvalues: (copy) v_u_33, (copy) p_u_27, (ref) v_u_580, (copy) v_u_40, (ref) v_u_153
			if p1329 == "TribePass" then
				task.spawn(function()
					-- upvalues: (ref) v_u_33, (ref) p_u_27, (ref) v_u_580, (ref) v_u_40, (ref) v_u_153
					local v1330 = v_u_33.Home(true)
					p_u_27.Sounds.Play("Queue_Join")
					p_u_27.Toast("Founding unlocked! Make your tribe", "success")
					if os.clock() - v_u_580 < 120 and (v_u_40.IsOpen and (type(v1330) == "table" and (not v1330.tribe and v_u_153 ~= "Form"))) then
						p_u_27.OpenTribeForm("create")
					end
				end)
			end
		end)
	end
	local function v_u_1355() -- name: layout
		-- upvalues: (ref) v_u_37, (copy) v_u_28, (ref) v_u_10, (ref) v_u_9, (copy) v_u_40, (copy) v_u_36, (copy) v_u_170, (copy) v_u_171, (copy) v_u_427, (copy) v_u_428, (copy) v_u_1236, (copy) v_u_1237, (copy) v_u_1113, (copy) v_u_1114, (ref) v_u_151, (copy) v_u_911, (copy) v_u_912, (copy) v_u_915, (copy) v_u_42
		local v1331
		if v_u_28.Compact then
			v1331 = v_u_10
		else
			v1331 = v_u_9
		end
		v_u_37 = v1331
		local v1332 = v_u_28.CanvasSize()
		local v1333 = v_u_28.TopInset()
		if v_u_28.Compact then
			local v1334 = v_u_40.Holder
			local v1335 = v_u_36
			local v1336 = v1332.X - 24
			local v1337 = math.min(1180, v1336)
			local v1338 = math.floor(v1337)
			local v1339 = v1332.Y - v1333 - 12
			local v1340 = math.min(680, v1339)
			v1334.Size = v1335(v1338, (math.floor(v1340)))
		else
			local v1341 = v_u_40.Holder
			local v1342 = v_u_36
			local v1343 = v1332.X - 200
			local v1344 = math.clamp(v1343, 1040, 1280)
			local v1345 = math.floor(v1344)
			local v1346 = v1332.Y - v1333 - 90
			local v1347 = math.clamp(v1346, 620, 760)
			v1341.Size = v1342(v1345, (math.floor(v1347)))
		end
		local v1348 = v_u_40.Holder.Size.X.Offset - 44
		local v1349 = v_u_40.Holder.Size.Y.Offset - 80 - 32 - (v_u_37.tab + 14)
		local v1350 = v_u_37.left
		for _, v1351 in {
			{ v_u_170, v_u_171 },
			{ v_u_427, v_u_428 },
			{ v_u_1236, v_u_1237 },
			{ v_u_1113, v_u_1114 }
		} do
			v1351[1].Size = v_u_36(v1350, v1349)
			v1351[2].Position = v_u_36(v1350 + v_u_37.gap, 0)
			v1351[2].Size = v_u_36(v1348 - v1350 - v_u_37.gap, v1349)
		end
		local v1352
		if v_u_151 == nil then
			v1352 = false
		else
			local v1353 = v_u_151.tribe
			v1352 = type(v1353) == "table"
		end
		v_u_170.Visible = not v1352
		if v1352 then
			v_u_171.Position = v_u_36(0, 0)
			v_u_171.Size = v_u_36(v1348, v1349)
		end
		local v1354 = v_u_28.Compact and 290 or 330
		v_u_911.Size = v_u_36(v1348 - v1354 - v_u_37.gap, v1349)
		v_u_912.Position = v_u_36(v1348 - v1354, 0)
		v_u_912.Size = v_u_36(v1354, v1349)
		v_u_915.CellSize = v_u_36(v_u_28.Compact and 180 or 200, 150)
		v_u_42.Visible = not v_u_28.Compact
		v_u_40.Refit()
	end
	v_u_28.LayoutChanged:Connect(function()
		-- upvalues: (copy) v_u_40, (copy) v_u_1355
		if v_u_40.IsOpen then
			v_u_1355()
		end
	end)
	v_u_28.ScaleChanged:Connect(function()
		-- upvalues: (copy) v_u_40, (copy) v_u_1355
		if v_u_40.IsOpen then
			v_u_1355()
		end
	end)
	local v_u_1356 = nil
	local function v_u_1372(p1357)
		-- upvalues: (ref) v_u_151, (copy) v_u_40, (copy) v_u_42, (copy) v_u_142, (copy) v_u_85, (copy) v_u_170, (copy) v_u_57, (ref) v_u_5, (copy) v_u_32, (ref) v_u_11, (copy) v_u_38, (copy) v_u_28, (ref) v_u_13, (ref) v_u_1356, (ref) v_u_153, (ref) v_u_1267, (copy) v_u_143, (copy) v_u_574, (copy) v_u_754, (copy) v_u_426, (copy) v_u_1355, (copy) v_u_132
		v_u_151 = p1357
		if p1357 then
			local v1358 = p1357.tribe
			if type(v1358) == "table" then
				local v1359 = v_u_40.Title
				local v1360 = string.upper
				local v1361 = v1358.name
				v1359.Text = v1360((tostring(v1361)))
				local v1362 = v1358.members
				local v1363 = tonumber(v1362) or 0
				local v1364 = v_u_40.Subtitle
				local v1365 = "%*  \194\183  %* %*  \194\183  %* Glory this week"
				local v1366 = v_u_38.Tag
				local v1367
				if type(v1358) == "table" then
					v1367 = v1358.tag
				else
					v1367 = v1358
				end
				local v1368 = v1366(v1367)
				local v1369 = v1363 == 1 and "member" or "members"
				local v1370 = v_u_28.FormatNumber
				local v1371 = v1358.weekRenown
				v1364.Text = v1365:format(v1368, v1363, v1369, (v1370(tonumber(v1371) or 0)))
				v_u_42.Text = not v1358.rank and "" or string.format("<font color=\"#%s\">#%d</font> THIS WEEK", v_u_13:ToHex(), v1358.rank)
				if v_u_1356 == false and (v_u_153 == "Find" or v_u_153 == "View") then
					v_u_153 = nil
				end
				if v_u_153 == "View" and v_u_1267 == v1358.id then
					v_u_153 = nil
				end
				v_u_1356 = true
				v_u_143.text.Text = "BROWSE"
				v_u_142({
					"Overview",
					"Members",
					"Find",
					"Leaderboard",
					"Territories"
				})
				v_u_574(v1358)
				v_u_754(v1358)
			else
				v_u_40.Title.Text = "TRIBES"
				v_u_40.Subtitle.Text = "Play together, earn Glory, hold the maps"
				v_u_42.Text = ""
				if v_u_153 == "Overview" or v_u_153 == "Members" then
					v_u_153 = nil
				end
				v_u_1356 = false
				v_u_143.text.Text = "FIND A TRIBE"
				v_u_142({ "Find", "Leaderboard", "Territories" })
				v_u_426(p1357)
			end
			v_u_1355()
			v_u_132()
		else
			v_u_40.Title.Text = "TRIBES"
			v_u_42.Text = ""
			v_u_142({ "Find", "Territories" })
			v_u_85(v_u_170)
			v_u_57({
				["Name"] = "Down",
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 16,
				["TextColor3"] = nil,
				["TextWrapped"] = true,
				["TextTruncate"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = v_u_5.Message("unavailable"),
				["FontFace"] = v_u_32.SemiBold,
				["TextColor3"] = v_u_11,
				["TextTruncate"] = Enum.TextTruncate.None,
				["Size"] = UDim2.new(1, 0, 0, 60),
				["Parent"] = v_u_170
			})
		end
	end
	v_u_33.HomeChanged:Connect(function(p1373)
		-- upvalues: (copy) v_u_40, (ref) v_u_153, (ref) v_u_1372, (ref) v_u_356, (ref) v_u_357, (copy) v_u_319, (ref) v_u_355, (copy) v_u_331
		if v_u_40.IsOpen and v_u_153 ~= "Form" then
			v_u_1372(p1373)
			if v_u_356 and (not v_u_357 and (v_u_153 == "Find" and v_u_319() ~= v_u_355)) then
				v_u_331(v_u_356, false)
			end
		end
	end)
	local v_u_1374 = 0
	local v1380 = {
		["open"] = function(p1375) -- name: open
			-- upvalues: (ref) v_u_1374, (ref) v_u_152, (copy) p_u_27, (copy) v_u_1355, (ref) v_u_153, (ref) v_u_1356, (ref) v_u_1372, (copy) v_u_33, (copy) v_u_112, (copy) v_u_137, (copy) v_u_40, (ref) v_u_356, (ref) v_u_357, (copy) v_u_319, (ref) v_u_355, (copy) v_u_331
			v_u_1374 = v_u_1374 + 1
			local v_u_1376 = v_u_1374
			v_u_152 = os.clock()
			p_u_27.SetHudHidden("Tribe", true)
			v_u_1355()
			v_u_153 = nil
			v_u_1356 = nil
			v_u_1372(v_u_33.Cached())
			if type(p1375) == "string" and v_u_112[p1375] then
				v_u_137(p1375)
			end
			v_u_40:Open()
			task.spawn(function()
				-- upvalues: (ref) v_u_33, (copy) v_u_1376, (ref) v_u_1374, (ref) v_u_40, (ref) v_u_153, (ref) v_u_1372, (ref) v_u_356, (ref) v_u_357, (ref) v_u_319, (ref) v_u_355, (ref) v_u_331
				local v1377 = v_u_33.Home(true)
				if v_u_1376 == v_u_1374 and v_u_40.IsOpen then
					if v_u_153 ~= "Form" then
						v_u_1372(v1377)
					end
					if v_u_356 and (not v_u_357 and (v_u_153 == "Find" and v_u_319() ~= v_u_355)) then
						v_u_331(v_u_356, false)
					end
				end
			end)
		end,
		["close"] = function(p1378) -- name: close
			-- upvalues: (ref) v_u_579, (ref) v_u_1265, (copy) p_u_27, (ref) v_u_176, (copy) v_u_156, (copy) v_u_85, (copy) v_u_157, (copy) v_u_28, (copy) v_u_34, (copy) v_u_1259, (copy) v_u_1260, (copy) v_u_174, (copy) v_u_40
			v_u_579 = v_u_579 + 1
			v_u_1265 = v_u_1265 + 1
			p_u_27.SetHudHidden("Tribe", false)
			v_u_176 = false
			v_u_156.Visible = false
			v_u_85(v_u_157)
			if v_u_28.Gamepad then
				v_u_34.Reselect()
			end
			v_u_1259:ReleaseFocus()
			v_u_1260:ReleaseFocus()
			v_u_174:ReleaseFocus()
			v_u_40:Close(p1378)
		end,
		["select"] = function() -- name: select
			-- upvalues: (ref) v_u_150, (copy) v_u_112
			local v1379 = v_u_150[1]
			if v1379 and v_u_112[v1379] then
				return v_u_112[v1379].button
			else
				return nil
			end
		end,
		["back"] = function() -- name: back
			-- upvalues: (ref) v_u_176, (copy) v_u_156, (copy) v_u_85, (copy) v_u_157, (copy) v_u_28, (copy) v_u_34, (ref) v_u_153, (copy) v_u_137, (ref) v_u_151, (ref) v_u_1264
			if not v_u_176 then
				if v_u_153 == "Form" then
					v_u_137(v_u_151 and v_u_151.tribe and "Overview" or "Find")
					return true
				end
				if v_u_153 ~= "View" then
					return false
				end
				v_u_137(v_u_1264)
				return true
			end
			v_u_176 = false
			v_u_156.Visible = false
			v_u_85(v_u_157)
			if v_u_28.Gamepad then
				v_u_34.Reselect()
			end
			return true
		end
	}
	v_u_34.Register("Tribe", v1380)
	v30.PlayerStateChanged:Connect(function(p1381)
		-- upvalues: (copy) v_u_34
		if p1381 == "Match" and v_u_34.IsOpen("Tribe") then
			v_u_34.Close("Tribe", true)
		end
	end)
	function p_u_27.Debug.tribe(p1382, p1383)
		-- upvalues: (copy) v_u_34, (copy) v_u_137, (ref) v_u_1266, (copy) p_u_27, (copy) v_u_1259, (copy) v_u_1260, (ref) v_u_1372, (ref) v_u_152, (copy) v_u_1282, (copy) v_u_40, (ref) v_u_153, (ref) v_u_151, (ref) v_u_176
		if p1382 == "open" then
			v_u_34.Open("Tribe", p1383)
		elseif p1382 == "tab" then
			v_u_137((tostring(p1383)))
		elseif p1382 == "view" then
			v_u_1266(tonumber(p1383) or 0, nil)
		elseif p1382 == "form" then
			p_u_27.OpenTribeForm((tostring(p1383 or "create")))
		elseif p1382 == "fill" and type(p1383) == "table" then
			local v1384 = v_u_1259
			local v1385 = p1383.tag or ""
			v1384.Text = tostring(v1385)
			local v1386 = v_u_1260
			local v1387 = p1383.name or ""
			v1386.Text = tostring(v1387)
		elseif p1382 == "home" and type(p1383) == "table" then
			v_u_1372(p1383)
		elseif p1382 == "submit" then
			v_u_152 = (-1 / 0)
			task.spawn(function()
				-- upvalues: (ref) v_u_1282
				v_u_1282.Activated:Fire()
			end)
		end
		local v1388 = {
			["open"] = v_u_40.IsOpen,
			["tab"] = v_u_153 or false
		}
		local v1389
		if v_u_151 == nil then
			v1389 = false
		else
			v1389 = v_u_151.tribe ~= false
		end
		v1388.inTribe = v1389
		v1388.dialog = v_u_176
		return v1388
	end
end
return v8