game:GetService("Players")
local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = script.Parent.Parent
local v_u_4 = require(v_u_3:WaitForChild("Character"):WaitForChild("AnimationIds"))
local v_u_5 = {}
local v_u_6 = nil
local v_u_7 = nil
task.spawn(function()
	-- upvalues: (copy) v_u_3, (ref) v_u_6, (copy) v_u_1, (ref) v_u_7
	local function v8()
		-- upvalues: (ref) v_u_3
		return require((v_u_3:WaitForChild("Character"):WaitForChild("Footsteps", 10)))
	end
	local v9, v10 = pcall(v8)
	if v9 and type(v10) == "table" then
		v_u_6 = v10
	end
	local function v11()
		-- upvalues: (ref) v_u_1
		return require((v_u_1:WaitForChild("Shared"):WaitForChild("Sfx", 10)))
	end
	local v12, v13 = pcall(v11)
	if v12 and type(v13) == "table" then
		v_u_7 = v13
	end
end)
local function v_u_21(p_u_14, p15, p16, p17) -- name: load
	if not p15 or p15 == "" then
		return nil
	end
	local v_u_18 = Instance.new("Animation")
	v_u_18.Name = p17
	v_u_18.AnimationId = p15
	local v19, v20 = pcall(function()
		-- upvalues: (copy) p_u_14, (copy) v_u_18
		return p_u_14:LoadAnimation(v_u_18)
	end)
	if not (v19 and v20) then
		return nil
	end
	v20.Priority = p16
	v20.Looped = true
	return v20
end
function v_u_5.new(p22, p23, p24) -- name: new
	-- upvalues: (copy) v_u_4, (copy) v_u_21
	local v25
	if p22.RigType == Enum.HumanoidRigType.R6 then
		v25 = v_u_4.R6
	else
		v25 = v_u_4.R15
	end
	local v26 = {
		["hum"] = nil,
		["root"] = nil,
		["tracks"] = nil,
		["weights"] = nil,
		["targets"] = nil,
		["legs"] = nil,
		["upper"] = nil,
		["sliding"] = false,
		["groundedAt"] = 0,
		["jumpAt"] = -1,
		["active"] = false,
		["stepDist"] = 0,
		["lastPos"] = nil,
		["leftFoot"] = false,
		["airTime"] = 0,
		["lastVy"] = 0,
		["hum"] = p22,
		["root"] = p23,
		["tracks"] = {},
		["weights"] = {},
		["targets"] = {}
	}
	for _, v27 in {
		"idle",
		"walk",
		"run",
		"jump",
		"fall"
	} do
		local v28 = v_u_21(p24, v25[v27], Enum.AnimationPriority.Core, v27)
		if not v28 then
			continue
		end
		v26.tracks[v27] = v28
		v26.weights[v27] = 0
	end
	v26.legs = v_u_21(p24, v_u_4.SlideLegs, Enum.AnimationPriority.Action2, "SlideLegs") or v_u_21(p24, v_u_4.SlideFallback, Enum.AnimationPriority.Movement, "SlideFallback")
	v26.upper = v_u_21(p24, v_u_4.SlideUpper, Enum.AnimationPriority.Movement, "SlideUpper")
	return v26
end
function v_u_5.Stop(p29) -- name: Stop
	for v30, v31 in p29.tracks do
		v31:Stop(0.2)
		p29.weights[v30] = 0
	end
	if p29.legs then
		p29.legs:Stop(0.15)
	end
	if p29.upper then
		p29.upper:Stop(0.15)
	end
	p29.sliding = false
	p29.active = false
end
local v_u_32 = RaycastParams.new()
v_u_32.FilterType = Enum.RaycastFilterType.Include
v_u_32.IgnoreWater = true
function v_u_5.SetGround(p33) -- name: SetGround
	-- upvalues: (copy) v_u_32
	v_u_32.FilterDescendantsInstances = p33
end
local function v_u_52(p34, p35) -- name: footstep
	-- upvalues: (ref) v_u_6, (ref) v_u_7, (copy) v_u_2, (copy) v_u_32
	if v_u_6 and v_u_7 then
		local v36 = p34.root
		local v37 = p34.hum
		local v38 = v_u_2.CurrentCamera
		if v38 and (v38.CFrame.Position - v36.Position).Magnitude > 90 then
			return
		else
			local v39 = v37.HipHeight + v36.Size.Y / 2 + 1.5
			local v40 = v_u_2
			local v41 = v36.Position
			local v42 = -v39
			local v_u_43 = v40:Raycast(v41, Vector3.new(0, v42, 0), v_u_32)
			if v_u_43 then
				local function v44()
					-- upvalues: (ref) v_u_6, (copy) v_u_43
					return v_u_6.StepSoundName(v_u_6.SurfaceFor(v_u_43.Material))
				end
				local v45, v46 = pcall(v44)
				if v45 and type(v46) == "string" then
					p34.leftFoot = not p34.leftFoot
					local v47 = v36.CFrame.RightVector * (p34.leftFoot and -0.5 or 0.5)
					local v48 = v_u_7.Play
					local v49 = "Character/" .. v46
					local v50 = v_u_43.Position + v47
					local v51 = {
						["volume"] = p35 > 23 and 1 or 0.8
					}
					pcall(v48, v49, v50, v51)
				end
			else
				return
			end
		end
	else
		return
	end
end
function v_u_5.Step(p53, p54, p55, p56, p57, p58, p59) -- name: Step
	-- upvalues: (copy) v_u_5, (ref) v_u_7, (copy) v_u_2, (copy) v_u_52
	if p59 then
		p53.active = true
		local v60 = p53.hum
		local v61 = p53.root
		local v62 = p53.targets
		for v63 in p53.tracks do
			v62[v63] = 0
		end
		local v64 = p56.X
		local v65 = p56.Z
		local v66 = Vector3.new(v64, 0, v65).Magnitude
		local v67 = v60.HipHeight / 2
		local v68 = math.max(0.5, v67)
		if p57 then
			p53.groundedAt = p55
		elseif p56.Y > 8 and p55 - p53.groundedAt < 0.25 then
			p53.jumpAt = p55
		end
		if p57 or p55 - p53.groundedAt < 0.1 then
			local v69 = (v66 - 0.6) / 2.5
			local v70 = math.clamp(v69, 0, 1)
			local v71 = (v66 / v68 - 9) / 5
			local v72 = math.clamp(v71, 0, 1)
			v62.idle = 1 - v70
			v62.walk = v70 * (1 - v72)
			v62.run = v70 * v72
			local v73 = 1
			if v66 > 1 then
				local v74 = v61.CFrame.LookVector
				v73 = (p56.X * v74.X + p56.Z * v74.Z) / v66 < -0.35 and -1 or v73
			end
			local v75 = p53.tracks.walk
			local v76 = p53.tracks.run
			if v75 then
				local v77 = v66 / (v68 * 7.5)
				v75:AdjustSpeed(v73 * math.clamp(v77, 0.4, 1.8))
			end
			if v76 then
				local v78 = v66 / (v68 * 16.5)
				v76:AdjustSpeed(v73 * math.clamp(v78, 0.55, 1.7))
			end
		elseif p53.jumpAt > 0 and (p55 - p53.jumpAt < 0.45 and p56.Y > -12) then
			v62.jump = 1
		else
			v62.fall = 1
		end
		local v79 = p54 * -14
		local v80 = 1 - math.exp(v79)
		for v81, v82 in p53.tracks do
			local v83 = p53.weights[v81] + ((v62[v81] or 0) - p53.weights[v81]) * v80
			local v84 = v83 < 0.001 and 0.0001 or v83
			p53.weights[v81] = v84
			if v82.IsPlaying then
				v82:AdjustWeight(v84, 0)
			else
				v82:Play(0, v84, v82.Speed)
			end
		end
		if p58 ~= p53.sliding then
			p53.sliding = p58
			if p58 then
				if p53.legs then
					p53.legs:Play(0.08, 1, 1)
				end
				if p53.upper then
					p53.upper:Play(0.12, 1, 1)
				end
			else
				if p53.legs then
					p53.legs:Stop(0.15)
				end
				if p53.upper then
					p53.upper:Stop(0.15)
				end
			end
		end
		if p57 then
			if p53.airTime > 0.35 and p53.lastVy < -30 then
				local v85 = -p53.lastVy
				if v85 > 72 and v_u_7 then
					local v86 = v_u_2.CurrentCamera
					local v87 = v61.Position
					local v88 = v60.HipHeight + v61.Size.Y / 2
					local v89 = v87 - Vector3.new(0, v88, 0)
					if not v86 or (v86.CFrame.Position - v89).Magnitude <= 90 then
						local v90 = (v85 - 64) / 60
						local v91 = math.clamp(v90, 0, 1)
						local v92 = v_u_7.Play
						local v93 = v91 > 0.5 and "Character/LandHeavy" or "Character/Land"
						local v94 = {
							["volume"] = v91 * 0.6 + 0.35
						}
						pcall(v92, v93, v89, v94)
					end
				else
					v_u_52(p53, 16)
				end
				p53.airTime = 0
			else
				p53.airTime = 0
			end
		else
			p53.airTime = p53.airTime + p54
			p53.lastVy = p56.Y
		end
		local v95 = v61.Position
		if p57 and (v66 > 2 and not p58) then
			local v96 = p53.lastPos
			if v96 then
				local v97 = v95.X - v96.X
				local v98 = v95.Z - v96.Z
				local v99 = Vector3.new(v97, 0, v98).Magnitude
				if v99 < 10 then
					p53.stepDist = p53.stepDist + v99
				end
			end
			if p53.stepDist >= (v66 > 15 and 5.2 or 3.9) then
				p53.stepDist = 0
				v_u_52(p53, v66)
			end
		else
			local v100 = p53.stepDist
			p53.stepDist = math.min(v100, 2.34)
		end
		p53.lastPos = v95
	elseif p53.active then
		v_u_5.Stop(p53)
	end
end
return v_u_5