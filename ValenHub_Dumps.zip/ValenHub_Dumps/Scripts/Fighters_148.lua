local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("Players")
local v_u_3 = {
	["TAGS"] = { "Combatant", "Bot" }
}
local v_u_4 = {}
local v_u_5 = {}
local v_u_6 = true
local v_u_7 = 0
local v_u_8 = false
local function v_u_9() -- name: markDirty
	-- upvalues: (ref) v_u_6
	v_u_6 = true
end
local function v_u_13() -- name: start
	-- upvalues: (ref) v_u_8, (copy) v_u_3, (copy) v_u_1, (copy) v_u_9, (copy) v_u_2, (ref) v_u_6
	if not v_u_8 then
		v_u_8 = true
		for _, v10 in v_u_3.TAGS do
			v_u_1:GetInstanceAddedSignal(v10):Connect(v_u_9)
			v_u_1:GetInstanceRemovedSignal(v10):Connect(v_u_9)
		end
		for _, v11 in v_u_2:GetPlayers() do
			v11.CharacterAdded:Connect(v_u_9)
			v11.CharacterRemoving:Connect(v_u_9)
		end
		v_u_2.PlayerAdded:Connect(function(p12)
			-- upvalues: (ref) v_u_9, (ref) v_u_6
			p12.CharacterAdded:Connect(v_u_9)
			p12.CharacterRemoving:Connect(v_u_9)
			v_u_6 = true
		end)
		v_u_2.PlayerRemoving:Connect(v_u_9)
	end
end
function v_u_3.List() -- name: List
	-- upvalues: (copy) v_u_13, (ref) v_u_6, (ref) v_u_7, (copy) v_u_4, (copy) v_u_5, (copy) v_u_2, (copy) v_u_3, (copy) v_u_1
	v_u_13()
	local v14 = os.clock()
	if v_u_6 or v14 - v_u_7 > 0.5 then
		table.clear(v_u_4)
		table.clear(v_u_5)
		for _, v15 in v_u_2:GetPlayers() do
			local v16 = v15.Character
			if not v16 or (not v16:IsA("Model") or (v_u_5[v16] or not v16:IsDescendantOf(workspace))) then
				continue
			end
			v_u_5[v16] = true
			local v17 = v_u_4
			table.insert(v17, v16)
		end
		for _, v18 in v_u_3.TAGS do
			for _, v19 in v_u_1:GetTagged(v18) do
				if not v19:IsA("Model") or (v_u_5[v19] or not v19:IsDescendantOf(workspace)) then
					continue
				end
				v_u_5[v19] = true
				local v20 = v_u_4
				table.insert(v20, v19)
			end
		end
		v_u_6 = false
		v_u_7 = v14
	end
	return v_u_4
end
function v_u_3.EachTagged(p21) -- name: EachTagged
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v22 = {}
	for _, v23 in v_u_3.TAGS do
		for _, v24 in v_u_1:GetTagged(v23) do
			if not v24:IsA("Model") or v22[v24] then
				continue
			end
			v22[v24] = true
			p21(v24)
		end
	end
end
function v_u_3.OnTaggedChanged(p25) -- name: OnTaggedChanged
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	for _, v26 in v_u_3.TAGS do
		v_u_1:GetInstanceAddedSignal(v26):Connect(p25)
		v_u_1:GetInstanceRemovedSignal(v26):Connect(p25)
	end
end
return v_u_3