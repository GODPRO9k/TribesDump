local v_u_1 = game:GetService("Workspace")
local v_u_2 = {}
local v_u_3 = { 0.5, 0 }
v_u_2.RADIUS = 0.35
v_u_2.THIN = 1.6
local v_u_4 = RaycastParams.new()
v_u_4.FilterType = Enum.RaycastFilterType.Exclude
v_u_4.IgnoreWater = true
local v_u_5 = nil
local v_u_6 = true
function v_u_2.Classify(p7) -- name: Classify
	-- upvalues: (copy) v_u_1
	if p7 == v_u_1.Terrain then
		return 1
	end
	if p7.Transparency > 0.6 or not p7.CanCollide then
		return 0
	end
	local v8 = p7.Size
	local v9 = v8.X
	local v10 = v8.Y
	local v11 = v8.Z
	local v12 = math.min(v9, v10)
	local v13 = math.max(v9, v10)
	local v14 = math.min(v13, v11)
	return math.max(v12, v14) < 1.6 and 2 or 1
end
function v_u_2.IgnoreChanged() -- name: IgnoreChanged
	-- upvalues: (ref) v_u_6
	v_u_6 = true
end
function v_u_2.Cast(p15, p16, p17, p18) -- name: Cast
	-- upvalues: (ref) v_u_5, (ref) v_u_6, (copy) v_u_4, (copy) v_u_1, (copy) v_u_2
	local v19 = p16 - p15
	local v20 = v19.Magnitude
	if v20 < 0.001 then
		return 0
	end
	if v20 ~= v20 or v20 == (1 / 0) then
		return 0
	end
	local v21 = math.min(v20, 1000)
	if p17 ~= v_u_5 then
		v_u_5 = p17
		v_u_6 = true
	end
	if v_u_6 then
		v_u_4.FilterDescendantsInstances = p17
		v_u_6 = false
	end
	local v22 = v19 / v20
	local v23 = p18 or 0.35
	for _ = 1, 6 do
		local v24 = v_u_1:Spherecast(p15, v23, v22 * v21, v_u_4)
		if not v24 then
			return v20
		end
		local v25 = v24.Instance
		if not v25:IsA("BasePart") or v_u_2.Classify(v25) == 1 then
			local v26 = v24.Distance
			return math.max(0, v26)
		end
		v_u_4:AddToFilter(v25)
		v_u_6 = true
	end
	return v20
end
local v_u_27 = {
	["pullIns"] = 0,
	["holds"] = 0,
	["swaps"] = 0
}
local function v_u_43(p28, p29, p30, p31, p32, p33) -- name: follow
	-- upvalues: (copy) v_u_27
	local v34 = p28.cur or p30
	if p30 < v34 - 0.08 then
		p28.clearSince = nil
		if p33 then
			local v35 = v_u_27
			v35.pullIns = v35.pullIns + 1
			v34 = p30
		else
			v34 = p30
		end
	elseif p32 or not p28.free then
		if v34 + 0.08 < p30 then
			local v36 = os.clock()
			if p28.clearSince == nil then
				p28.clearSince = v36
				if p33 then
					local v37 = v_u_27
					v37.holds = v37.holds + 1
				end
			end
			if v36 - p28.clearSince >= 0.15 then
				local v38 = p30 - v34
				local v39 = p29 * -6
				v34 = v34 + v38 * (1 - math.exp(v39))
			end
		else
			p28.clearSince = nil
			if not p32 then
				v34 = p30
			end
		end
	else
		v34 = p30
	end
	local v40 = math.clamp(v34, 0, p31)
	p28.cur = v40
	local v41 = not p32
	if v41 then
		local v42 = v40 - p31
		v41 = math.abs(v42) < 0.001
	end
	p28.free = v41
	return v40
end
local v_u_44 = {
	["cur"] = nil,
	["free"] = false,
	["clearSince"] = nil
}
local v_u_45 = {
	["cur"] = nil,
	["free"] = false,
	["clearSince"] = nil
}
local v_u_46 = 0
local v_u_47 = 0
local v_u_48 = false
local v_u_49 = 0
local v_u_50 = nil
function v_u_2.Reset() -- name: Reset
	-- upvalues: (ref) v_u_44, (ref) v_u_45, (ref) v_u_46, (ref) v_u_47, (ref) v_u_48, (ref) v_u_49
	v_u_44 = {
		["cur"] = nil,
		["free"] = false,
		["clearSince"] = nil
	}
	v_u_45 = {
		["cur"] = nil,
		["free"] = false,
		["clearSince"] = nil
	}
	v_u_46 = 0
	v_u_47 = 0
	v_u_48 = false
	v_u_49 = 0
end
function v_u_2.Side(p51, p52, p53, p54, p55) -- name: Side
	-- upvalues: (ref) v_u_49, (copy) v_u_2, (ref) v_u_48, (copy) v_u_27
	local v56 = os.clock()
	if v56 - v_u_49 >= 0.5 then
		local v57 = v_u_2.Cast(p51, p51 + p52 * (p53 * p54), p55)
		if v_u_48 then
			if p53 * 0.75 < v57 then
				v_u_48 = false
				v_u_49 = v56
				local v58 = v_u_27
				v58.swaps = v58.swaps + 1
			elseif v_u_2.Cast(p51, p51 - p52 * (p53 * p54), p55) < v57 + 0.2 then
				v_u_48 = false
				v_u_49 = v56
				local v59 = v_u_27
				v59.swaps = v59.swaps + 1
			end
		elseif v57 < p53 * 0.45 and v_u_2.Cast(p51, p51 - p52 * (p53 * p54), p55) > v57 + 0.8 then
			v_u_48 = true
			v_u_49 = v56
			local v60 = v_u_27
			v60.swaps = v60.swaps + 1
		end
	end
	if v_u_48 then
		return -p54
	else
		return p54
	end
end
local function v_u_78(p61, p62, p63, p64, p65, p66) -- name: reachFor
	-- upvalues: (copy) v_u_2
	local v67 = p61 + p62 * p65
	local v68 = v67 - p63 * p64
	local v69 = (v68 - p61).Magnitude
	if v69 < 0.001 or p64 < 0.001 then
		return 1, false
	end
	local v70 = v_u_2.Cast(p61, v68, p66)
	local v71 = v_u_2.Cast(v67, v68, p66)
	local v72
	if v69 <= v70 then
		v72 = v69
	else
		local v73 = v70 - 0.12
		v72 = math.max(0, v73)
	end
	local v74 = v72 / v69
	local v75
	if p64 <= v71 then
		v75 = p64
	else
		local v76 = v71 - 0.12
		v75 = math.max(0, v76)
	end
	local v77 = v75 / p64
	return math.min(v74, v77), v70 < v69 and true or v71 < p64
end
function v_u_2.Frame(p79, p80, p81, p82, p83, p84, p85, p86) -- name: Frame
	-- upvalues: (copy) v_u_2, (ref) v_u_46, (ref) v_u_47, (copy) v_u_78, (copy) v_u_3, (copy) v_u_43, (ref) v_u_44, (ref) v_u_45, (ref) v_u_50, (ref) v_u_48
	local v87 = p81 - p80
	local v88 = v87.Magnitude
	if v88 > 0.001 then
		local v89 = v87 / v88
		local v90 = v_u_2.Cast(p80, p81 + v89 * 1, p86)
		local v91 = 0
		local v92 = v88 + 1
		if v92 > v90 then
			local v93 = v90 - 0.12
			v92 = math.max(0, v93)
		end
		local v94 = v88 - v92
		v_u_46 = math.max(v91, v94)
		local v95 = v88 - (v90 - 1)
		local v96 = v88 - 0.8
		local v97 = math.max(0, v96)
		local v98 = math.clamp(v95, 0, v97)
		local v99 = v_u_47
		local v100 = (v88 + 1 <= v90 and 0 or v98) - v_u_47
		local v101 = p79 * -8
		v_u_47 = v99 + v100 * (1 - math.exp(v101))
		if v_u_47 < 0.005 then
			v_u_47 = 0
		end
		local v102 = v_u_46
		local v103 = v_u_47
		p81 = p81 - v89 * math.max(v102, v103)
	end
	local v104 = math.abs(p84)
	if v104 > 0.001 then
		p82 = p82 * math.sign(p84)
	end
	local v105
	if v104 > 0.001 then
		local v106 = v_u_2.Cast(p81, p81 + p82 * v104, p86)
		if v104 <= v106 then
			v105 = v104
		else
			local v107 = v106 - 0.12
			v105 = math.max(0, v107)
		end
	else
		v105 = 0
	end
	local v108, v109 = v_u_78(p81, p82, p83, p85, v105, p86)
	local v110, v111
	if v105 > 0.3 and v108 < 0.9 then
		v110 = v108
		v111 = v105
		for _, v112 in v_u_3 do
			local v113 = v_u_78(p81, p82, p83, p85, v105 * v112, p86)
			if v108 >= v113 - 0.2 * (1 - v112) then
				continue
			end
			v108 = v113 - 0.2 * (1 - v112)
			v111 = v105 * v112
		end
	else
		v110 = v108
		v111 = v105
	end
	local v114 = v104 <= 0.001 and 0 or v_u_43(v_u_44, p79, v111, v104, v111 < v104 - 0.001, false)
	local v115 = p81 + p82 * v114
	local v116 = v115 - p83 * p85
	local v117 = v116 - p81
	local v118 = v117.Magnitude
	if v118 < 0.001 or p85 < 0.001 then
		return v116, v115, p81
	end
	local v119 = v114 - v105
	if math.abs(v119) > 0.0001 then
		v110, v109 = v_u_78(p81, p82, p83, p85, v114, p86)
	end
	local v120 = v_u_43(v_u_45, p79, v110 * v118, v118, v109, true)
	local v121 = v120 / v118
	local v122 = p81 + v117 * v121
	if v_u_50 then
		local v123 = v_u_50
		local v124 = {}
		local v125 = v_u_46
		local v126 = v_u_47
		__set_list(v124, 1, {os.clock(), v118, v110 * v118, v120, v109 and 1 or 0, math.max(v125, v126), v_u_44.cur or v104, v_u_48 and 1 or 0})
		table.insert(v123, v124)
	end
	return v122, v122 + p83 * (p85 * v121), p81
end
function v_u_2.Debug(p127) -- name: Debug
	-- upvalues: (ref) v_u_50, (copy) v_u_27
	if p127 == "start" then
		v_u_50 = {}
		return true
	end
	if p127 ~= "stop" then
		return table.clone(v_u_27)
	end
	local v128 = v_u_50
	v_u_50 = nil
	return v128
end
local v_u_129 = RaycastParams.new()
v_u_129.FilterType = Enum.RaycastFilterType.Include
v_u_129.FilterDescendantsInstances = { v_u_1.Terrain }
v_u_129.IgnoreWater = false
local v_u_130 = 0
local v_u_131 = game:GetService("RunService"):IsStudio()
if v_u_131 then
	v_u_131 = v_u_1:GetAttribute("WaterSimOff") == true
end
function v_u_2.AboveWater(p132) -- name: AboveWater
	-- upvalues: (copy) v_u_131, (copy) v_u_1, (copy) v_u_129, (ref) v_u_130
	if v_u_131 then
		return p132
	end
	local v133 = p132.Position
	local v134 = v_u_1:Raycast(v133 + Vector3.new(0, 12, 0), Vector3.new(0, -12.4, 0), v_u_129)
	if v134 and v134.Material == Enum.Material.Water then
		local v135 = v134.Position.Y + 0.4 - v133.Y
		if v135 > 0 then
			v_u_130 = v_u_130 + 1
			return p132 + Vector3.new(0, v135, 0)
		end
	end
	return p132
end
function v_u_2.WaterLifts() -- name: WaterLifts
	-- upvalues: (ref) v_u_130
	return v_u_130
end
return v_u_2