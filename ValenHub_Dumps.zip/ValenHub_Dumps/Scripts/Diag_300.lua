local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = {
	["FAR"] = 10
}
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = v_u_2:IsStudio()
local v_u_7 = {}
local function v_u_25(p8, p9, p10, p11, p12) -- name: detail
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	if v_u_6 and #v_u_7 < 40 then
		local v13 = v_u_7
		local v14 = string.format
		local v15 = "%s %s why=%s src=%s %s"
		local v16
		if p12 then
			local v17 = string.format
			local v18 = p12.parts
			local v19 = p12.vis
			local v20 = p12.tr
			local v21 = p12.ltm
			local v22 = p12.far
			local v23 = p12.loose
			local v24 = p12.parented
			v16 = v17("parts=%d vis=%d tr=%d ltm=%d far=%d loose=%d par=%s", v18, v19, v20, v21, v22, v23, (tostring(v24)))
		else
			v16 = "-"
		end
		table.insert(v13, v14(v15, p8, p9, p10, p11, v16))
	end
end
function v_u_3.Evaluate(p26) -- name: Evaluate
	return not p26.parented and "unparented" or (p26.parts == 0 and "noparts" or (p26.far * 2 >= p26.parts and "far" or (p26.loose * 2 >= p26.parts and "loose" or (p26.vis * 3 < p26.parts and (p26.tr > 0 and p26.tr >= p26.ltm and "tr" or (p26.ltm > 0 and "ltm" or "vis")) or nil))))
end
function v_u_3.Begin(p27) -- name: Begin
	-- upvalues: (copy) v_u_7, (ref) v_u_4, (copy) v_u_1
	local v28 = {}
	for v29, v30 in p27.fighters do
		v28[v29] = v30.id
	end
	local v31 = false
	local v32 = p27.fighters[p27.focus]
	if v32 and v32.flags then
		for v33 = 1, v32.n do
			local v34 = v32.flags[v33]
			if bit32.band(v34, 96) ~= 96 then
				continue
			end
			v31 = true
		end
	end
	table.clear(v_u_7)
	local v35 = {
		["ids"] = nil,
		["focus"] = nil,
		["me"] = nil,
		["fp"] = nil,
		["failure"] = nil,
		["counts"] = nil,
		["build"] = nil,
		["srcs"] = nil,
		["early"] = false,
		["emitted"] = false,
		["shots"] = nil,
		["frames"] = 0,
		["onFrames"] = 0,
		["aimBest"] = (1 / 0),
		["ids"] = v28,
		["focus"] = p27.focus
	}
	local v36 = v_u_1.LocalPlayer.UserId
	v35.me = "p" .. tostring(v36)
	v35.fp = v31
	v35.build = {
		["hA"] = 0,
		["hB"] = 0,
		["okA"] = 0,
		["okB"] = 0
	}
	v35.srcs = {}
	v35.shots = {}
	v_u_4 = v35
end
local function v_u_46(p37, p38, p39, p40, p41, p42, p43, p44) -- name: note
	if not p37.failure then
		local v45 = p37.ids[p39] or "?"
		p37.failure = {
			["index"] = p39,
			["why"] = p40,
			["k"] = string.sub(v45, 1, 1) == "p" and "A" or "B",
			["src"] = p41,
			["at"] = p38,
			["self"] = v45 == p37.me,
			["focus"] = p39 == p37.focus,
			["st"] = p42,
			["live"] = p43,
			["fix"] = p44
		}
	end
end
function v_u_3.Built(p47, p48, p49, p50, p51, p52, p53, p54) -- name: Built
	-- upvalues: (ref) v_u_4, (copy) v_u_25, (copy) v_u_46
	local v55 = v_u_4
	if v55 then
		local v56 = v55.ids[p47] or "?"
		if p48 then
			v55.srcs[p48.src] = (v55.srcs[p48.src] or 0) + 1
		end
		if p54 then
			local v57 = v55.failure
			if v57 and (v57.index == p47 and (v57.at == "build" and (p48 and p53))) then
				v57.fix = p48.src
			end
			return
		else
			local v58 = p49 ~= nil and true or p48 == nil
			local v59 = v55.build
			local v60 = string.sub(v56, 1, 1) == "p" and "A" or "B"
			if v58 then
				if v60 == "A" then
					v59.hA = v59.hA + 1
				else
					v59.hB = v59.hB + 1
				end
			elseif v60 == "A" then
				v59.okA = v59.okA + 1
			else
				v59.okB = v59.okB + 1
			end
			if v58 then
				v_u_25("build", v56, p49 or "missing", p50 or "none", p51)
			end
			if v58 then
				local v61
				if p48 and (p53 and p49) then
					v61 = p48.src
				else
					v61 = p49 and "failed" or "none"
				end
				if p48 == nil and p49 == nil then
					v_u_46(v55, "build", p47, "missing", "none", nil, p52, "none")
				else
					v_u_46(v55, "build", p47, p49, p50 or "?", p51, p52, v61)
				end
				if v55.failure and (v55.failure.at == "build" and v55.counts == nil) then
					v55.counts = v55.build
				end
			end
		end
	else
		return
	end
end
function v_u_3.Check(p62, p63, p64, p65, p66) -- name: Check
	-- upvalues: (ref) v_u_4, (copy) v_u_3, (copy) v_u_25, (copy) v_u_46
	local v67 = v_u_4
	if v67 then
		if p62 == "early" then
			v67.early = true
		end
		local v68 = {
			["hA"] = 0,
			["hB"] = 0,
			["okA"] = 0,
			["okB"] = 0
		}
		local v69 = false
		for v70, v71 in p63.clip.fighters do
			local v72 = p63.puppets[v70]
			if v71.n > 0 and not v72 then
				p66(v70)
			end
			local v73 = p63.states[v70]
			if v71.n <= 0 or (not v73 or (not v73.present or v70 == p63.focus and p64)) then
				continue
			end
			local v74, v75
			if v72 then
				v74 = p65(v72)
				v75 = v_u_3.Evaluate(v74)
				if not v75 and (v72.alive and (v72.root.Position - v73.cf.Position).Magnitude > 3) then
					v75 = "drift"
				end
			else
				v75 = "missing"
				v74 = nil
			end
			local v76 = v71.id
			local v77 = v75 ~= nil
			local v78 = string.sub(v76, 1, 1) == "p" and "A" or "B"
			if v77 then
				if v78 == "A" then
					v68.hA = v68.hA + 1
				else
					v68.hB = v68.hB + 1
				end
			elseif v78 == "A" then
				v68.okA = v68.okA + 1
			else
				v68.okB = v68.okB + 1
			end
			if v75 then
				v_u_25(p62, v71.id, v75, not v72 and "none" or v72.src, v74)
			end
			if not v75 or v67.failure then
				continue
			end
			v_u_46(v67, p62, v70, v75, not v72 and "none" or v72.src, v74, not v72 and -1 or v72.liveParts, "none")
			v69 = true
		end
		if v69 then
			v67.counts = v68
		end
	end
end
function v_u_3.Frame(p79, p80) -- name: Frame
	-- upvalues: (ref) v_u_4
	local v81 = v_u_4
	if v81 then
		v81.frames = v81.frames + 1
		local v82 = p80.CFrame
		local v83 = v82.LookVector
		local v84 = v82.Position
		local v85 = p79.clip.fighters[p79.focus].team
		local v86 = false
		for v87, v88 in p79.clip.fighters do
			local v89 = p79.states[v87]
			if v87 == p79.focus or not (v89 and v89.present) then
				continue
			end
			local v90 = v89.cf.Position + Vector3.new(0, 1, 0)
			local v91, v92 = p80:WorldToViewportPoint(v90)
			v86 = v92 and v91.Z > 0 and true or v86
			if v88.team == v85 then
				continue
			end
			local v93 = v89.flags
			if not bit32.btest(v93, 1) then
				continue
			end
			local v94 = v90 - v84
			if v94.Magnitude <= 1 then
				continue
			end
			local v95 = v83:Dot(v94.Unit)
			local v96 = math.clamp(v95, -1, 1)
			local v97 = math.acos(v96)
			local v98 = math.deg(v97)
			if v98 >= v81.aimBest then
				continue
			end
			v81.aimBest = v98
		end
		if v86 then
			v81.onFrames = v81.onFrames + 1
		end
	end
end
function v_u_3.Shot(p99, p100) -- name: Shot
	-- upvalues: (ref) v_u_4
	local v101 = v_u_4
	if v101 and #v101.shots < 32 then
		local v102 = p99.CFrame
		local v103 = p100 - v102.Position
		if v103.Magnitude >= 2 then
			local v104 = v101.shots
			local v105 = v102.LookVector:Dot(v103.Unit)
			local v106 = math.clamp(v105, -1, 1)
			local v107 = math.acos(v106)
			local v108 = math.deg(v107)
			table.insert(v104, v108)
		end
	else
		return
	end
end
local function v_u_119(p109) -- name: view
	local v110 = p109.shots
	local v111
	if #v110 == 0 then
		v111 = nil
	else
		local v112 = table.clone(v110)
		table.sort(v112)
		local v113 = #v112 / 2
		v111 = v112[math.ceil(v113)]
	end
	local v114 = v111 == nil and "-" or (v111 < 2 and "<2" or (v111 < 5 and "<5" or (v111 < 15 and "<15" or "15+")))
	local v115 = p109.aimBest
	local v116 = v115 == (1 / 0) and "-" or (v115 < 5 and "<5" or (v115 < 15 and "<15" or (v115 < 45 and "<45" or "45+")))
	local v117
	if p109.frames > 0 then
		local v118 = p109.onFrames / p109.frames
		v117 = p109.onFrames == 0 and "0" or (v118 < 0.25 and "<25" or (v118 < 0.75 and "<75" or "75+"))
	else
		v117 = "-"
	end
	return string.format("shot=%s aim=%s onscr=%s", v114, v116, v117)
end
function v_u_3.Flush() -- name: Flush
	-- upvalues: (ref) v_u_4, (copy) v_u_119, (copy) v_u_2, (ref) v_u_5
	local v120 = v_u_4
	if v120 and not v120.emitted then
		v120.emitted = true
		local v121 = v120.shots
		local v122
		if #v121 == 0 then
			v122 = nil
		else
			local v123 = table.clone(v121)
			table.sort(v123)
			local v124 = #v123 / 2
			v122 = v123[math.ceil(v124)]
		end
		if not v120.failure and (v122 and (#v120.shots >= 2 and v122 >= 15)) then
			local v125 = v120.ids[v120.focus] or "?"
			v120.failure = {
				["index"] = nil,
				["why"] = "aim",
				["k"] = nil,
				["src"] = "-",
				["at"] = "clip",
				["self"] = nil,
				["focus"] = true,
				["st"] = nil,
				["live"] = -1,
				["fix"] = "none",
				["index"] = v120.focus,
				["k"] = string.sub(v125, 1, 1) == "p" and "A" or "B",
				["self"] = v125 == v120.me
			}
		end
		local v126 = v120.failure
		local v127 = nil
		if v126 then
			local v128 = v126.st
			local v129 = v120.counts or v120.build
			local v130 = string.format
			local v131 = "[ReplayDiag] hidden why=%s k=%s src=%s at=%s self=%s foc=%s fp=%s parts=%s live=%s vis=%s tr=%s ltm=%s far=%s loose=%s par=%s wrap=%s fix=%s hA=%s hB=%s okA=%s okB=%s %s"
			local v132 = v126.why
			local v133 = v126.k
			local v134 = v126.src
			local v135 = v126.at
			local v136 = v126.self and "1" or "0"
			local v137 = v126.focus and "1" or "0"
			local v138 = v120.fp and "1" or "0"
			local v139
			if v128 then
				local v140 = v128.parts
				v139 = v140 < 0 and "-" or (v140 == 0 and "0" or (v140 < 5 and "1+" or (v140 < 10 and "5+" or (v140 < 20 and "10+" or "20+"))))
			else
				v139 = "-"
			end
			local v141 = v126.live
			local v142 = v141 < 0 and "-" or (v141 == 0 and "0" or (v141 < 5 and "1+" or (v141 < 10 and "5+" or (v141 < 20 and "10+" or "20+"))))
			local v143
			if v128 then
				local v144 = v128.vis
				local v145 = v128.parts
				v143 = v144 <= 0 and "0" or (v145 <= v144 and "all" or (v145 <= v144 * 2 and "most" or "some"))
			else
				v143 = "-"
			end
			local v146
			if v128 then
				local v147 = v128.tr
				local v148 = v128.parts
				v146 = v147 <= 0 and "0" or (v148 <= v147 and "all" or (v148 <= v147 * 2 and "most" or "some"))
			else
				v146 = "-"
			end
			local v149
			if v128 then
				local v150 = v128.ltm
				local v151 = v128.parts
				v149 = v150 <= 0 and "0" or (v151 <= v150 and "all" or (v151 <= v150 * 2 and "most" or "some"))
			else
				v149 = "-"
			end
			local v152
			if v128 then
				local v153 = v128.far
				local v154 = v128.parts
				v152 = v153 <= 0 and "0" or (v154 <= v153 and "all" or (v154 <= v153 * 2 and "most" or "some"))
			else
				v152 = "-"
			end
			local v155
			if v128 then
				local v156 = v128.loose
				local v157 = v128.parts
				v155 = v156 <= 0 and "0" or (v157 <= v156 and "all" or (v157 <= v156 * 2 and "most" or "some"))
			else
				v155 = "-"
			end
			local v158 = v128 and (v128.parented and "1" or "0") or "-"
			local v159
			if v128 then
				local v160 = v128.wrap
				v159 = v160 < 0 and "-" or (v160 == 0 and "0" or (v160 < 5 and "1+" or (v160 < 10 and "5+" or (v160 < 20 and "10+" or "20+"))))
			else
				v159 = "-"
			end
			local v161 = v126.fix
			local v162 = v129.hA
			local v163 = v162 >= 2 and "2+" or tostring(v162)
			local v164 = v129.hB
			local v165 = v164 >= 2 and "2+" or tostring(v164)
			local v166 = v129.okA
			local v167 = v166 >= 2 and "2+" or tostring(v166)
			local v168 = v129.okB
			v127 = v130(v131, v132, v133, v134, v135, v136, v137, v138, v139, v142, v143, v146, v149, v152, v155, v158, v159, v161, v163, v165, v167, v168 >= 2 and "2+" or tostring(v168), v_u_119(v120))
			warn(v127)
		elseif v120.early and (math.random() < 0.1 or v_u_2:IsStudio() and workspace:GetAttribute("ReplayDiagAlways") == true) then
			local v169 = v120.build
			local v170 = {}
			for v171 in v120.srcs do
				table.insert(v170, v171)
			end
			table.sort(v170)
			local v172 = string.format
			local v173 = v120.fp and "1" or "0"
			local v174 = v120.ids[v120.focus] or "?"
			local v175 = (string.sub(v174, 1, 1) == "p" and "A" or "B") == "A" and "1" or "0"
			local v176 = v120.ids[v120.focus] == v120.me and "1" or "0"
			local v177 = v169.okA + v169.hA
			local v178 = v177 >= 2 and "2+" or tostring(v177)
			local v179 = v169.okB + v169.hB
			v127 = v172("[ReplayDiag] ok fp=%s focA=%s mine=%s A=%s B=%s src=%s %s", v173, v175, v176, v178, v179 >= 2 and "2+" or tostring(v179), #v170 <= 0 and "-" or table.concat(v170, "+"), v_u_119(v120))
			warn(v127)
		end
		v_u_5 = v127
	end
end
function v_u_3.End() -- name: End
	-- upvalues: (copy) v_u_3, (ref) v_u_4
	v_u_3.Flush()
	v_u_4 = nil
end
function v_u_3.LastLine() -- name: LastLine
	-- upvalues: (ref) v_u_5, (copy) v_u_7
	return v_u_5, v_u_7
end
return v_u_3