local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v3 = {}
({
	["key"] = "R",
	["action"] = "Reload",
	["pad"] = nil,
	["label"] = "reload",
	["reload"] = true
}).pad = Enum.KeyCode.ButtonX
local v_u_4 = {}
local v5 = {
	["bit"] = 0,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "draw",
			["pad"] = Enum.KeyCode.ButtonR2
		},
		{
			["key"] = "M2",
			["action"] = "Aim",
			["pad"] = nil,
			["label"] = "zoom",
			["pad"] = Enum.KeyCode.ButtonL2
		}
	}
}
v_u_4.Bow = v5
local v6 = {
	["bit"] = 1,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "fire",
			["pad"] = Enum.KeyCode.ButtonR2
		},
		{
			["key"] = "M2",
			["action"] = "Aim",
			["pad"] = nil,
			["label"] = "aim",
			["pad"] = Enum.KeyCode.ButtonL2
		}
	}
}
v_u_4.Crossbow = v6
local v7 = {
	["bit"] = 2,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "fire",
			["pad"] = Enum.KeyCode.ButtonR2
		},
		{
			["key"] = "M2",
			["action"] = "Aim",
			["pad"] = nil,
			["label"] = "aim",
			["pad"] = Enum.KeyCode.ButtonL2
		}
	}
}
v_u_4.Musket = v7
local v8 = {
	["bit"] = 3,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "fire",
			["pad"] = Enum.KeyCode.ButtonR2
		},
		{
			["key"] = "M2",
			["action"] = "Aim",
			["pad"] = nil,
			["label"] = "aim",
			["pad"] = Enum.KeyCode.ButtonL2
		}
	}
}
v_u_4.Pistol = v8
local v9 = {
	["bit"] = 4,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "fire",
			["pad"] = Enum.KeyCode.ButtonR2
		}
	}
}
v_u_4.Blunderbuss = v9
local v10 = {
	["bit"] = 5,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "throw",
			["pad"] = Enum.KeyCode.ButtonR2
		}
	}
}
v_u_4.Knives = v10
local v11 = {
	["bit"] = 6,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "throw",
			["pad"] = Enum.KeyCode.ButtonR2
		},
		{
			["key"] = "M2",
			["action"] = "Aim",
			["pad"] = nil,
			["label"] = "cancel",
			["pad"] = Enum.KeyCode.ButtonL2
		}
	}
}
v_u_4.Javelin = v11
local v12 = {
	["bit"] = 7,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "sling",
			["pad"] = Enum.KeyCode.ButtonR2
		}
	}
}
v_u_4.Sling = v12
local v13 = {
	["bit"] = 8,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "attack",
			["pad"] = Enum.KeyCode.ButtonR2
		},
		{
			["key"] = "M2",
			["action"] = "Aim",
			["pad"] = nil,
			["label"] = "block",
			["pad"] = Enum.KeyCode.ButtonL2
		}
	}
}
v_u_4.Sword = v13
local v14 = {
	["bit"] = 9,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "chop",
			["pad"] = Enum.KeyCode.ButtonR2
		},
		{
			["key"] = "M2",
			["action"] = "Aim",
			["pad"] = nil,
			["label"] = "heavy",
			["pad"] = Enum.KeyCode.ButtonL2
		}
	}
}
v_u_4.Axe = v14
local v15 = {
	["bit"] = 10,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "thrust",
			["pad"] = Enum.KeyCode.ButtonR2
		},
		{
			["key"] = "M2",
			["action"] = "Aim",
			["pad"] = nil,
			["label"] = "lunge",
			["pad"] = Enum.KeyCode.ButtonL2
		}
	}
}
v_u_4.Spear = v15
local v16 = {
	["bit"] = 11,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "stab",
			["pad"] = Enum.KeyCode.ButtonR2
		}
	}
}
v_u_4.Dagger = v16
local v17 = {
	["bit"] = 12,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "smash",
			["pad"] = Enum.KeyCode.ButtonR2
		}
	}
}
v_u_4.Club = v17
local v18 = {
	["bit"] = 13,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "throw",
			["pad"] = Enum.KeyCode.ButtonR2
		},
		{
			["key"] = "M2",
			["action"] = "Aim",
			["pad"] = nil,
			["label"] = "cancel",
			["pad"] = Enum.KeyCode.ButtonL2
		}
	}
}
v_u_4.Bomb = v18
local v19 = {
	["bit"] = 14,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "eat",
			["pad"] = Enum.KeyCode.ButtonR2
		}
	}
}
v_u_4.Herbs = v19
local v20 = {
	["bit"] = 15,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "set",
			["pad"] = Enum.KeyCode.ButtonR2
		}
	}
}
v_u_4.Trap = v20
local v21 = {
	["bit"] = 16,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "use",
			["pad"] = Enum.KeyCode.ButtonR2
		}
	}
}
v_u_4.Bandage = v21
local v22 = {
	["bit"] = 17,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "eat",
			["pad"] = Enum.KeyCode.ButtonR2
		}
	}
}
v_u_4.Tonic = v22
local v23 = {
	["bit"] = 18,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "blow",
			["pad"] = Enum.KeyCode.ButtonR2
		}
	}
}
v_u_4.Horn = v23
local v24 = {
	["bit"] = 19,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "bash",
			["pad"] = Enum.KeyCode.ButtonR2
		},
		{
			["key"] = "M2",
			["action"] = "Aim",
			["pad"] = nil,
			["label"] = "block",
			["pad"] = Enum.KeyCode.ButtonL2
		}
	}
}
v_u_4.Shield = v24
local v25 = {
	["bit"] = 20,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "build",
			["pad"] = Enum.KeyCode.ButtonR2
		}
	}
}
v_u_4.Wall = v25
local v26 = {
	["bit"] = 21,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "punch",
			["pad"] = Enum.KeyCode.ButtonR2
		},
		{
			["key"] = "M2",
			["action"] = "Aim",
			["pad"] = nil,
			["label"] = "dash",
			["pad"] = Enum.KeyCode.ButtonL2
		}
	}
}
v_u_4.Gauntlets = v26
local v27 = {
	["bit"] = 22,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "sweep",
			["pad"] = Enum.KeyCode.ButtonR2
		},
		{
			["key"] = "M2",
			["action"] = "Aim",
			["pad"] = nil,
			["label"] = "dash",
			["pad"] = Enum.KeyCode.ButtonL2
		}
	}
}
v_u_4.Scythe = v27
local v28 = {
	["bit"] = 23,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "cut",
			["pad"] = Enum.KeyCode.ButtonR2
		},
		{
			["key"] = "M2",
			["action"] = "Aim",
			["pad"] = nil,
			["label"] = "parry",
			["pad"] = Enum.KeyCode.ButtonL2
		}
	}
}
v_u_4.Katana = v28
local v29 = {
	["bit"] = 24,
	["acts"] = nil,
	["acts"] = {
		{
			["key"] = "M1",
			["action"] = "Attack",
			["pad"] = nil,
			["label"] = "chop",
			["pad"] = Enum.KeyCode.ButtonR2
		},
		{
			["key"] = "M2",
			["action"] = "Aim",
			["pad"] = nil,
			["label"] = "throw",
			["pad"] = Enum.KeyCode.ButtonL2
		}
	}
}
v_u_4.Hatchets = v29
function v3.Init(p_u_30) -- name: Init
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_4
	local v_u_31 = p_u_30.UI
	local v_u_32 = p_u_30.Theme
	local v_u_33 = p_u_30.State
	local v_u_34 = p_u_30.WeaponInfo
	local v_u_35 = v_u_32.Colors
	local v_u_36 = v_u_32.Fonts
	local v_u_37 = v_u_1.LocalPlayer
	local v_u_38 = 0
	local v_u_39 = 0
	local v_u_40 = false
	local function v48() -- name: loadFromProfile
		-- upvalues: (copy) v_u_33, (ref) v_u_40, (ref) v_u_38, (ref) v_u_39
		local v41 = v_u_33.Profile
		if v41 then
			v41 = v_u_33.Profile.settings
		end
		if v_u_33.HasProfile and type(v41) == "table" then
			v_u_40 = true
			local v42 = v41.tutKinds
			if type(v42) == "number" then
				local v43 = v_u_38
				local v44 = v41.tutKinds
				v_u_38 = bit32.bor(v43, v44)
			end
			local v45 = v41.tutMatches
			if type(v45) == "number" then
				local v46 = v_u_39
				local v47 = v41.tutMatches
				v_u_39 = math.max(v46, v47)
			end
		end
	end
	local v49 = v_u_33.Profile
	if v49 then
		v49 = v_u_33.Profile.settings
	end
	local v_u_50
	if v_u_33.HasProfile and type(v49) == "table" then
		v_u_40 = true
		local v51 = v49.tutKinds
		if type(v51) == "number" then
			local v52 = v49.tutKinds
			local v53 = v_u_38
			v_u_38 = bit32.bor(v53, v52)
			v_u_50 = v_u_38
		else
			v_u_50 = v_u_38
		end
		local v54 = v49.tutMatches
		if type(v54) == "number" then
			local v55 = v49.tutMatches
			v_u_39 = math.max(v_u_39, v55)
		end
	else
		v_u_50 = v_u_38
	end
	v_u_33.ProfileChanged:Connect(v48)
	local v_u_56 = false
	v_u_33.MatchEvent:Connect(function(p57)
		-- upvalues: (ref) v_u_40, (ref) v_u_56, (ref) v_u_39, (copy) v_u_33, (copy) p_u_30
		if p57 == "MatchStart" and v_u_40 then
			v_u_56 = v_u_39 < 3
			if v_u_56 then
				v_u_39 = v_u_39 + 1
				local v_u_58 = v_u_39
				if v_u_33.Mock then
					return
				end
				local v_u_59 = "tutMatches"
				task.spawn(function()
					-- upvalues: (ref) p_u_30, (copy) v_u_59, (copy) v_u_58
					p_u_30.Remotes.Invoke("ProfileAction", "SetSetting", v_u_59, v_u_58)
				end)
			end
		end
	end)
	local function v_u_70(p60, p61, p62, p63) -- name: newRow
		-- upvalues: (copy) v_u_31, (copy) v_u_36, (copy) v_u_35
		local v64 = v_u_31.new("CanvasGroup", {
			["Name"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["GroupTransparency"] = 0.45,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Name"] = "Hint_" .. p61.key,
			["Size"] = UDim2.fromOffset(0, 32),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["LayoutOrder"] = p62,
			["Parent"] = p60
		})
		local v65 = v_u_31.new
		local v66 = "UIListLayout"
		local v67 = {
			["FillDirection"] = Enum.FillDirection.Horizontal
		}
		local v68
		if p63 then
			v68 = Enum.HorizontalAlignment.Right
		else
			v68 = Enum.HorizontalAlignment.Left
		end
		v67.HorizontalAlignment = v68
		v67.VerticalAlignment = Enum.VerticalAlignment.Center
		v67.Padding = UDim.new(0, 8)
		v67.SortOrder = Enum.SortOrder.LayoutOrder
		v67.Parent = v64
		v65(v66, v67)
		v_u_31.ActionCap(p61.action, {
			["Gamepad"] = nil,
			["Height"] = 26,
			["TextSize"] = 15,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Gamepad"] = p61.pad,
			["LayoutOrder"] = p63 and 2 or 1,
			["Parent"] = v64
		})
		local v69 = v_u_31.new("TextLabel", {
			["Name"] = "Label",
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 18,
			["TextColor3"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(0, 26),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Text"] = p61.label,
			["FontFace"] = v_u_36.Bold,
			["TextColor3"] = v_u_35.Text,
			["LayoutOrder"] = p63 and 1 or 2,
			["Parent"] = v64
		})
		v_u_31.TextStroke(v_u_35.Void, 1, 0.55).Parent = v69
		return {
			["group"] = v64,
			["label"] = v69,
			["act"] = p61
		}
	end
	local v_u_71 = v_u_31.new("Frame", {
		["Name"] = "ActionStrip",
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Size"] = UDim2.fromOffset(200, 110),
		["Parent"] = p_u_30.Canvas.HUD
	})
	v_u_31.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Vertical,
		["HorizontalAlignment"] = Enum.HorizontalAlignment.Left,
		["VerticalAlignment"] = Enum.VerticalAlignment.Bottom,
		["Padding"] = UDim.new(0, 4),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_71
	})
	local v_u_72 = v_u_31.new("Frame", {
		["Name"] = "LeftHints",
		["AnchorPoint"] = Vector2.new(1, 1),
		["Size"] = UDim2.fromOffset(220, 68),
		["Visible"] = false,
		v_u_31.List(Enum.FillDirection.Vertical, 4, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Bottom),
		["Parent"] = p_u_30.Canvas.HUD
	})
	local v_u_73 = v_u_70(v_u_72, {
		["key"] = "C",
		["action"] = "Slide",
		["pad"] = nil,
		["label"] = "slide",
		["pad"] = Enum.KeyCode.ButtonB
	}, 1, true)
	v_u_73.group.GroupTransparency = 1
	local v_u_74 = v_u_70(v_u_72, {
		["key"] = "V",
		["action"] = "View",
		["pad"] = nil,
		["label"] = "first person",
		["pad"] = Enum.KeyCode.DPadUp
	}, 2, true)
	local v_u_75 = v_u_2:WaitForChild("Shared"):FindFirstChild("Camera")
	local v76, v_u_77 = pcall(function()
		-- upvalues: (copy) v_u_75
		if v_u_75 then
			return require(v_u_75)
		else
			return nil
		end
	end)
	if not v76 or type(v_u_77) ~= "table" then
		v_u_77 = nil
	end
	local function v79() -- name: paintView
		-- upvalues: (ref) v_u_77, (copy) v_u_74
		local v78
		if v_u_77 == nil or v_u_77.IsFirstPerson == nil then
			v78 = false
		else
			v78 = v_u_77.IsFirstPerson() == true
		end
		v_u_74.label.Text = v78 and "third person" or "first person"
	end
	local v80
	if v_u_77 == nil or v_u_77.IsFirstPerson == nil then
		v80 = false
	else
		v80 = v_u_77.IsFirstPerson() == true
	end
	v_u_74.label.Text = v80 and "third person" or "first person"
	if v_u_77 then
		local v81 = v_u_77.FirstPersonChanged
		if typeof(v81) == "RBXScriptSignal" then
			v_u_77.FirstPersonChanged:Connect(v79)
		end
	end
	local function v_u_90() -- name: layout
		-- upvalues: (copy) p_u_30, (copy) v_u_31, (copy) v_u_71, (copy) v_u_72
		local v82 = not p_u_30.HotbarWidth and 372 or p_u_30.HotbarWidth()
		local v83 = v_u_31.Compact and -8 or -18
		local v84 = v_u_71
		local v85 = UDim2.new
		local v86 = v82 / 2
		v84.Position = v85(0.5, math.floor(v86) + 22, 1, v83)
		local v87 = v_u_72
		local v88 = UDim2.new
		local v89 = v82 / 2
		v87.Position = v88(0.5, -(math.floor(v89) + 22), 1, v83)
	end
	v_u_90()
	v_u_31.LayoutChanged:Connect(v_u_90)
	local v_u_91 = {}
	local v_u_92 = nil
	local v_u_93 = 0
	local v_u_94 = nil
	local function v_u_100(p95) -- name: rebuild
		-- upvalues: (copy) v_u_91, (ref) v_u_92, (ref) v_u_4, (copy) v_u_70, (copy) v_u_71
		for _, v96 in v_u_91 do
			v96.group:Destroy()
		end
		table.clear(v_u_91)
		v_u_92 = p95
		if p95 then
			p95 = v_u_4[p95]
		end
		if p95 then
			local v97 = #p95.acts
			for v98, v99 in p95.acts do
				v_u_91[v98] = v_u_70(v_u_71, v99, v97 - v98, false)
			end
		end
	end
	local function v_u_111(p101) -- name: emphasize
		-- upvalues: (ref) v_u_93, (copy) v_u_91, (ref) v_u_50, (ref) v_u_4, (copy) v_u_33, (copy) p_u_30
		v_u_93 = os.clock() + 6
		for _, v102 in v_u_91 do
			v102.group.GroupTransparency = 1
		end
		local v103 = v_u_50
		local v104 = v_u_4[p101].bit
		local v105 = bit32.lshift(1, v104)
		if not bit32.btest(v103, v105) then
			local v106 = v_u_50
			local v107 = v_u_4[p101].bit
			local v108 = bit32.lshift(1, v107)
			v_u_50 = bit32.bor(v106, v108)
			local v_u_109 = v_u_50
			if v_u_33.Mock then
				return
			end
			local v_u_110 = "tutKinds"
			task.spawn(function()
				-- upvalues: (ref) p_u_30, (copy) v_u_110, (copy) v_u_109
				p_u_30.Remotes.Invoke("ProfileAction", "SetSetting", v_u_110, v_u_109)
			end)
		end
	end
	p_u_30.HeldWeaponChanged:Connect(function(p112)
		-- upvalues: (copy) v_u_34, (ref) v_u_4, (ref) v_u_92, (copy) v_u_100, (ref) v_u_40, (ref) v_u_50, (copy) p_u_30, (ref) v_u_94, (copy) v_u_111
		local v113
		if p112 == "bandage" then
			v113 = "Bandage"
		elseif p112 == "healing_tonic" then
			v113 = "Tonic"
		elseif p112 == "palisade" then
			v113 = "Wall"
		else
			v113 = v_u_34.Get(p112)
			if v113 then
				v113 = v113.kind
			end
			if type(v113) ~= "string" or not v_u_4[v113] then
				v113 = nil
			end
		end
		if v113 ~= v_u_92 then
			v_u_100(v113)
		end
		if v113 and v_u_40 then
			local v114 = v_u_50
			local v115 = v_u_4[v113].bit
			local v116 = bit32.lshift(1, v115)
			if not bit32.btest(v114, v116) then
				if p_u_30.HudHidden then
					v_u_94 = v113
					return
				end
				v_u_111(v113)
			end
		end
	end)
	p_u_30.HudHiddenChanged:Connect(function(p117)
		-- upvalues: (ref) v_u_94, (ref) v_u_92, (copy) v_u_111
		if not p117 and (v_u_94 and v_u_94 == v_u_92) then
			local v118 = v_u_94
			v_u_94 = nil
			task.defer(v_u_111, v118)
		end
	end)
	local v_u_119 = false
	local v_u_120 = nil
	local v_u_121 = os.clock()
	local function v_u_127() -- name: planarSpeed
		-- upvalues: (copy) v_u_37, (ref) v_u_120, (ref) v_u_121
		local v122 = v_u_37.Character
		if v122 then
			v122 = v122:FindFirstChild("HumanoidRootPart")
		end
		local v123 = os.clock()
		if not (v122 and v122:IsA("BasePart")) then
			v_u_120 = nil
			return 0
		end
		local v124 = v122.Position
		local v125
		if v_u_120 and v_u_121 < v123 then
			local v126 = ((v124 - v_u_120) * Vector3.new(1, 0, 1)).Magnitude / (v123 - v_u_121)
			v125 = v126 > 120 and 0 or v126
		else
			v125 = 0
		end
		v_u_120 = v124
		v_u_121 = v123
		return v125
	end
	local v_u_128 = 0
	local v_u_129 = (-1 / 0)
	v_u_31.Every(v_u_71, 0.1, function()
		-- upvalues: (copy) v_u_31, (copy) v_u_33, (copy) p_u_30, (copy) v_u_91, (copy) v_u_37, (copy) v_u_71, (copy) v_u_90, (ref) v_u_93, (copy) v_u_32, (copy) v_u_35, (ref) v_u_40, (ref) v_u_56, (ref) v_u_39, (copy) v_u_127, (ref) v_u_128, (ref) v_u_129, (copy) v_u_72, (ref) v_u_119, (copy) v_u_73
		local v130 = not v_u_31.Touch
		if v130 then
			v130 = v_u_33.Get("CombatMode") ~= false and (v_u_33.IsAlive() and not p_u_30.HudHidden)
			if v130 then
				v130 = not v_u_33.Watching()
			end
			if v130 then
				if #v_u_91 > 0 then
					local v131 = v_u_37.Character
					if v131 then
						v131 = v131:FindFirstChildOfClass("Tool")
					end
					if not (v131 and v131:IsA("Tool")) then
						v131 = nil
					end
					v130 = v131 ~= nil
				else
					v130 = false
				end
			end
		end
		v_u_71.Visible = v130
		if v130 then
			v_u_90()
			local v132 = v_u_37.Character
			if v132 then
				v132 = v132:FindFirstChildOfClass("Tool")
			end
			if not (v132 and v132:IsA("Tool")) then
				v132 = nil
			end
			local v133 = v132:GetAttribute("Ammo")
			local v134 = v132:GetAttribute("MaxAmmo")
			local v135 = v132:GetAttribute("Reloading") == true
			local v136
			if type(v133) == "number" and (type(v134) == "number" and v134 > 0) then
				v136 = v133 <= 0
			else
				v136 = false
			end
			local v137 = os.clock() < v_u_93
			for _, v138 in v_u_91 do
				local v139
				if v138.act.reload == true then
					v139 = v136 or v135
				else
					v139 = false
				end
				local v140 = (v137 or v139) and 0 or 0.45
				local v141 = v138.group.GroupTransparency - v140
				if math.abs(v141) > 0.01 then
					v_u_31.Tween(v138.group, v_u_32.Tween.Smooth, {
						["GroupTransparency"] = v140
					})
				end
				if not v138.act.reload then
					continue
				end
				v138.label.Text = v135 and "reloading" or "reload"
				local v142 = v138.label
				local v143
				if v139 then
					v143 = v_u_35.Warning
				else
					v143 = v_u_35.Text
				end
				v142.TextColor3 = v143
			end
		end
		local v144 = v_u_40
		if v144 then
			if v_u_33.InMatch() then
				v144 = v_u_56
			else
				v144 = v_u_39 < 3
			end
		end
		local v145 = v_u_127()
		local v146 = false
		local v147, v148
		if v144 and not v_u_31.Touch then
			local v149 = v_u_33.Get("CombatMode") ~= false and (v_u_33.IsAlive() and not p_u_30.HudHidden)
			if v149 then
				v149 = not v_u_33.Watching()
			end
			if v149 then
				local v150 = v_u_37.Character
				v_u_128 = (v145 <= 12 or (not v150 or v150:GetAttribute("Sliding") == true)) and 0 or v_u_128 + 1
				if v_u_128 >= 3 then
					v_u_129 = os.clock()
				end
				v146 = os.clock() - v_u_129 < 1.5
				v147 = v_u_72
				v148 = not v_u_31.Touch and (v_u_33.Get("CombatMode") ~= false and (v_u_33.IsAlive() and not p_u_30.HudHidden))
				if v148 then
					v148 = not v_u_33.Watching()
				end
				v147.Visible = v148
				if v146 ~= v_u_119 then
					v_u_119 = v146
					v_u_31.Tween(v_u_73.group, v_u_32.Tween.Smooth, {
						["GroupTransparency"] = v146 and 0.35 or 1
					})
				end
			else
				v_u_128 = 0
				v147 = v_u_72
				v148 = not v_u_31.Touch and (v_u_33.Get("CombatMode") ~= false and (v_u_33.IsAlive() and not p_u_30.HudHidden))
				if v148 then
					v148 = not v_u_33.Watching()
				end
				v147.Visible = v148
				if v146 ~= v_u_119 then
					v_u_119 = v146
					v_u_31.Tween(v_u_73.group, v_u_32.Tween.Smooth, {
						["GroupTransparency"] = v146 and 0.35 or 1
					})
				end
			end
		else
			v_u_128 = 0
			v147 = v_u_72
			v148 = not v_u_31.Touch and (v_u_33.Get("CombatMode") ~= false and (v_u_33.IsAlive() and not p_u_30.HudHidden))
			if v148 then
				v148 = not v_u_33.Watching()
			end
			v147.Visible = v148
			if v146 ~= v_u_119 then
				v_u_119 = v146
				v_u_31.Tween(v_u_73.group, v_u_32.Tween.Smooth, {
					["GroupTransparency"] = v146 and 0.35 or 1
				})
			end
			return
		end
	end)
	function p_u_30.Debug.tutorial(p151)
		-- upvalues: (ref) v_u_50, (ref) v_u_39, (copy) v_u_33, (copy) p_u_30, (ref) v_u_40, (ref) v_u_92, (copy) v_u_91
		if p151 ~= "reset" then
			return {
				["kindsMask"] = v_u_50,
				["matchesSeen"] = v_u_39,
				["loaded"] = v_u_40,
				["kind"] = v_u_92,
				["rows"] = #v_u_91
			}
		end
		v_u_50 = 0
		v_u_39 = 0
		if not v_u_33.Mock then
			local v_u_152 = "tutKinds"
			local v_u_153 = 0
			task.spawn(function()
				-- upvalues: (ref) p_u_30, (copy) v_u_152, (copy) v_u_153
				p_u_30.Remotes.Invoke("ProfileAction", "SetSetting", v_u_152, v_u_153)
			end)
		end
		if not v_u_33.Mock then
			local v_u_154 = "tutMatches"
			local v_u_155 = 0
			task.spawn(function()
				-- upvalues: (ref) p_u_30, (copy) v_u_154, (copy) v_u_155
				p_u_30.Remotes.Invoke("ProfileAction", "SetSetting", v_u_154, v_u_155)
			end)
		end
		return true
	end
	function p_u_30.Debug.hints(p156)
		-- upvalues: (ref) v_u_4, (copy) v_u_100, (copy) v_u_111, (ref) v_u_92, (copy) v_u_91, (copy) v_u_71, (copy) v_u_72
		if type(p156) ~= "string" or not v_u_4[p156] then
			return {
				["kind"] = v_u_92,
				["rows"] = #v_u_91,
				["visible"] = v_u_71.Visible,
				["slide"] = v_u_72.Visible
			}
		end
		v_u_100(p156)
		v_u_111(p156)
		return true
	end
end
return v3