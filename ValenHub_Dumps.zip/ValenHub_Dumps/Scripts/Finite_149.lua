local v_u_5 = {
	["Authority"] = "?",
	["Number"] = function(p1) -- name: Number
		local v2
		if p1 == p1 and p1 > -10000000 then
			v2 = p1 < 10000000
		else
			v2 = false
		end
		return v2
	end,
	["Vector"] = function(p3) -- name: Vector
		-- upvalues: (copy) v_u_5
		local v4 = v_u_5.Number(p3.X) and v_u_5.Number(p3.Y)
		if v4 then
			v4 = v_u_5.Number(p3.Z)
		end
		return v4
	end
}
local v_u_6 = {}
function v_u_5.Say(p7) -- name: Say
	-- upvalues: (copy) v_u_6, (copy) v_u_5
	if not v_u_6[p7] then
		v_u_6[p7] = true
		warn((("[CameraNaN] %* auth=%*"):format(p7, v_u_5.Authority)))
	end
	return false
end
function v_u_5.HealSpring(p8, p9, p10) -- name: HealSpring
	-- upvalues: (copy) v_u_5
	local v11 = p8.value
	local v12 = p8.velocity
	local v13
	if typeof(v11) == "Vector3" then
		v13 = v_u_5.Vector(v11)
		if v13 then
			v13 = v_u_5.Vector(v12)
		end
	else
		v13 = v_u_5.Number(v11)
		if v13 then
			v13 = v_u_5.Number(v12)
		end
	end
	if not v13 then
		v_u_5.Say("spring " .. p10)
		local v14 = p8.target
		local v15
		if typeof(v14) == "Vector3" then
			v15 = v_u_5.Vector(v14)
		elseif type(v14) == "number" then
			v15 = v_u_5.Number(v14)
		else
			v15 = false
		end
		if v15 then
			p9 = v14
		end
		p8:Snap(p9)
	end
end
function v_u_5.Offset(p16) -- name: Offset
	-- upvalues: (copy) v_u_5
	local v17 = p16.CameraOffset()
	if v_u_5.Vector(v17) then
		return v17
	end
	v_u_5.Say("own offset")
	p16.Reset()
	return Vector3.new(0, 0, 0)
end
return v_u_5