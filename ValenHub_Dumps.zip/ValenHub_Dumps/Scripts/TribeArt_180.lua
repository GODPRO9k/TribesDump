local v1 = {
	["Glyphs"] = {
		["wolf"] = "rbxassetid://103294253045430",
		["bear"] = "rbxassetid://119817019975025",
		["raven"] = "rbxassetid://95452614081567",
		["eagle"] = "rbxassetid://132143371267590",
		["serpent"] = "rbxassetid://111398178043120",
		["boar"] = "rbxassetid://122538714213287",
		["stag"] = "rbxassetid://109736005223031",
		["fox"] = "rbxassetid://98185289233426",
		["owl"] = "rbxassetid://73564834170515",
		["shark"] = "rbxassetid://104566016694177",
		["flame"] = "rbxassetid://74673338900305",
		["sun"] = "rbxassetid://111308660167806",
		["moon"] = "rbxassetid://93131210400569",
		["star"] = "rbxassetid://139549221842117",
		["bolt"] = "rbxassetid://121532608395791",
		["mountain"] = "rbxassetid://71826835602613",
		["wave"] = "rbxassetid://130263518306194",
		["tree"] = "rbxassetid://101659134457755",
		["crown"] = "rbxassetid://120853244596337",
		["swords"] = "rbxassetid://115487831072175",
		["axe"] = "rbxassetid://135863535845962",
		["bow"] = "rbxassetid://105336611235703",
		["shield"] = "rbxassetid://71544127544618",
		["gem"] = "rbxassetid://107327471848356",
		["lion"] = "rbxassetid://109566884076599",
		["dragon"] = "rbxassetid://125232866889236",
		["scorpion"] = "rbxassetid://108473381838949",
		["anchor"] = "rbxassetid://99620447453108",
		["bull"] = "rbxassetid://71018969453238",
		["octopus"] = "rbxassetid://104556206185646",
		["trident"] = "rbxassetid://106741894116769",
		["skull"] = "rbxassetid://124926688638948",
		["ram"] = "rbxassetid://131305685252963",
		["griffin"] = "rbxassetid://122593931679065",
		["claws"] = "rbxassetid://104853532955675"
	},
	["Badge"] = "rbxassetid://105064836886896",
	["BadgeOutline"] = "rbxassetid://126060611469386"
}
local v2 = {
	["image"] = "rbxassetid://136229380711520",
	["size"] = nil,
	["regions"] = nil,
	["size"] = Vector2.new(1024, 640)
}
local v3 = {
	["AuroraGlacier"] = {
		["mask"] = "rbxassetid://104128130413271",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			581,
			35,
			809,
			232
		},
		["anchor"] = { 691.2, 125.5 }
	},
	["DriftwoodCove"] = {
		["mask"] = "rbxassetid://86312921653019",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			70,
			396,
			232,
			564
		},
		["anchor"] = { 107.5, 514.1 }
	},
	["EmberCanyon"] = {
		["mask"] = "rbxassetid://83645865073314",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			211,
			357,
			388,
			599
		},
		["anchor"] = { 297, 453.3 }
	},
	["FrostfangPass"] = {
		["mask"] = "rbxassetid://97282624258431",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			209,
			49,
			408,
			230
		},
		["anchor"] = { 297, 125.1 }
	},
	["GiantwoodGrove"] = {
		["mask"] = "rbxassetid://87640740247804",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			323,
			196,
			508,
			399
		},
		["anchor"] = { 409.6, 259.2 }
	},
	["HarvestHollow"] = {
		["mask"] = "rbxassetid://125786174124327",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			459,
			190,
			664,
			393
		},
		["anchor"] = { 572.9, 250.6 }
	},
	["HighlandHenge"] = {
		["mask"] = "rbxassetid://128053752894532",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			158,
			201,
			349,
			392
		},
		["anchor"] = { 256, 273.2 }
	},
	["IcefallFjord"] = {
		["mask"] = "rbxassetid://79251405780094",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			389,
			27,
			596,
			226
		},
		["anchor"] = { 491.5, 140.7 }
	},
	["MangroveMarsh"] = {
		["mask"] = "rbxassetid://135901541990391",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			22,
			242,
			226,
			418
		},
		["anchor"] = { 128, 290.5 }
	},
	["MirageOutpost"] = {
		["mask"] = "rbxassetid://124522272362487",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			797,
			391,
			941,
			576
		},
		["anchor"] = { 875.5, 484.4 }
	},
	["OchreQuarry"] = {
		["mask"] = "rbxassetid://73697089863870",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			639,
			366,
			822,
			578
		},
		["anchor"] = { 753.7, 414 }
	},
	["OvergrownRuins"] = {
		["mask"] = "rbxassetid://135088899201774",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			61,
			101,
			222,
			253
		},
		["anchor"] = { 143.4, 153.9 }
	},
	["SakuraCitadel"] = {
		["mask"] = "rbxassetid://84946065869114",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			793,
			242,
			1005,
			406
		},
		["anchor"] = { 890.9, 289.5 }
	},
	["SandstoneOasis"] = {
		["mask"] = "rbxassetid://81292266017511",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			499,
			385,
			702,
			597
		},
		["anchor"] = { 610.3, 463.9 }
	},
	["SunstoneTemple"] = {
		["mask"] = "rbxassetid://79010305213468",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			615,
			205,
			825,
			402
		},
		["anchor"] = { 727, 302.3 }
	},
	["TitansAmphitheatre"] = {
		["mask"] = "rbxassetid://119496223859135",
		["bbox"] = nil,
		["anchor"] = nil,
		["bbox"] = {
			355,
			377,
			557,
			614
		},
		["anchor"] = { 450.6, 443.2 }
	},
	["Uncharted2"] = {
		["mask"] = "rbxassetid://127480050309635",
		["bbox"] = nil,
		["anchor"] = nil,
		["uncharted"] = true,
		["bbox"] = {
			789,
			92,
			966,
			250
		},
		["anchor"] = { 870.4, 165.3 }
	}
}
v2.regions = v3
v1.Map = v2
return v1