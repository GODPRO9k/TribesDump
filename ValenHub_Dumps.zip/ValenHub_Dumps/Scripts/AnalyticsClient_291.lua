local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = game:GetService("Workspace")
local v7 = {}
local function v_u_13() -- name: platform
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_6
	if v_u_1:IsTenFootInterface() then
		return "Console"
	end
	if not v_u_5.TouchEnabled or v_u_5.MouseEnabled then
		return "Desktop"
	end
	local v8 = v_u_6.CurrentCamera
	local v9 = os.clock()
	while (not v8 or v8.ViewportSize.X <= 1) and os.clock() - v9 < 5 do
		task.wait(0.1)
		v8 = v_u_6.CurrentCamera
	end
	local v10
	if v8 then
		v10 = v8.ViewportSize
	else
		v10 = Vector2.zero
	end
	local v11 = v10.X
	local v12 = v10.Y
	return math.min(v11, v12) >= 600 and "Tablet" or "Phone"
end
function v7.Start() -- name: Start
	-- upvalues: (copy) v_u_4, (copy) v_u_13, (copy) v_u_2, (copy) v_u_3
	local v14 = require(v_u_4:WaitForChild("Shared"):WaitForChild("Net"))
	local v_u_15 = v14.Event("AnalyticsReport")
	v_u_15:FireServer("Platform", (v_u_13()))
	local v_u_16 = v_u_2.LocalPlayer
	local v_u_17 = 0
	local v_u_18 = 0
	v_u_3.RenderStepped:Connect(function(p19)
		-- upvalues: (copy) v_u_16, (ref) v_u_17, (ref) v_u_18
		if v_u_16:GetAttribute("State") == "Match" and (v_u_16:GetAttribute("Alive") == true and v_u_16:GetAttribute("ReplayPlaying") ~= true) then
			v_u_17 = v_u_17 + 1
			v_u_18 = v_u_18 + p19
		end
	end)
	v14.Event("MatchEvent").OnClientEvent:Connect(function(p20)
		-- upvalues: (ref) v_u_17, (ref) v_u_18, (copy) v_u_15
		if p20 == "RoundStart" then
			v_u_17 = 0
			v_u_18 = 0
		elseif p20 == "RoundEnd" then
			if v_u_18 >= 10 then
				local v21 = v_u_15
				local v22 = v_u_17 / v_u_18 * 10 + 0.5
				v21:FireServer("Fps", math.floor(v22) / 10)
			end
			v_u_17 = 0
			v_u_18 = 0
		end
	end)
end
return v7