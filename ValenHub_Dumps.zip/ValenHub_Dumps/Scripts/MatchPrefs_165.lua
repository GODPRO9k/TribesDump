local v_u_1 = {
	["REGIONS"] = {
		{
			["id"] = "NA",
			["name"] = "North America"
		},
		{
			["id"] = "SA",
			["name"] = "South America"
		},
		{
			["id"] = "EU",
			["name"] = "Europe"
		},
		{
			["id"] = "MEA",
			["name"] = "Middle East & Africa"
		},
		{
			["id"] = "AS",
			["name"] = "Asia"
		},
		{
			["id"] = "OC",
			["name"] = "Oceania"
		}
	},
	["DEFAULTS"] = {
		["mmNoBots"] = 0,
		["mmAutoRegion"] = 1,
		["mmRegions"] = 0,
		["mmPremium"] = 0
	}
}
v_u_1.RANGES = {
	["mmNoBots"] = { 0, 1 },
	["mmAutoRegion"] = { 0, 1 },
	["mmRegions"] = { 0, 2 ^ (#v_u_1.REGIONS) - 1 },
	["mmPremium"] = { 0, 1 }
}
v_u_1.PREMIUM_MIN_AGE = 7
v_u_1.PREMIUM_ATTR = "PremiumQueue"
v_u_1.PREMIUM_WANT_ATTR = "PremiumWant"
function v_u_1.PremiumEligible(p2, p3) -- name: PremiumEligible
	-- upvalues: (copy) v_u_1
	local v4
	if type(p2) == "number" and (v_u_1.PREMIUM_MIN_AGE < p2 and type(p3) == "number") then
		v4 = p3 > 0
	else
		v4 = false
	end
	return v4
end
function v_u_1.Has(p5, p6) -- name: Has
	local v7
	if type(p5) == "number" and p5 == p5 then
		local v8 = math.clamp(p5, 0, 1048576)
		local v9 = math.floor(v8)
		local v10 = p6 - 1
		local v11 = bit32.lshift(1, v10)
		v7 = bit32.band(v9, v11) ~= 0
	else
		v7 = false
	end
	return v7
end
function v_u_1.With(p12, p13, p14) -- name: With
	local v15 = p13 - 1
	local v16 = bit32.lshift(1, v15)
	if p14 then
		return bit32.bor(p12, v16)
	end
	local v17 = bit32.bnot(v16)
	return bit32.band(p12, v17)
end
function v_u_1.WantsPremium(p18) -- name: WantsPremium
	local v19
	if type(p18) == "table" then
		local v20 = p18.mmPremium
		if v20 == true or v20 == 1 then
			return true
		end
		if v20 == false or v20 == 0 then
			return false
		end
		v19 = false
	else
		v19 = false
	end
	return v19
end
function v_u_1.Read(p21) -- name: Read
	-- upvalues: (copy) v_u_1
	if type(p21) == "table" then
		local v22 = p21.mmNoBots
		local v23
		if v22 == true or v22 == 1 then
			v23 = true
		else
			local _ = v22 == false or v22 == 0
			v23 = false
		end
		local v24 = p21.mmAutoRegion
		if (v24 == true or v24 == 1) and true or v24 ~= false and v24 ~= 0 then
			return v23, nil
		else
			local v25 = {}
			for v26, v27 in v_u_1.REGIONS do
				if not v_u_1.Has(p21.mmRegions, v26) then
					continue
				end
				local v28 = v27.id
				table.insert(v25, v28)
			end
			if #v25 > 0 then
				return v23, v25
			else
				return v23, nil
			end
		end
	else
		return false, nil
	end
end
return v_u_1