local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = require(script.Parent.Util)
local v_u_5 = require(script.Parent.Effects)
local v_u_6 = require(script.Parent.Quality)
local v_u_7 = {}
local v_u_8 = v_u_1.LocalPlayer
v_u_7.POSE = {
	["RightShoulder"] = Vector3.new(102, 64, -24),
	["RightElbow"] = Vector3.new(11, 0, 0),
	["RightWrist"] = Vector3.new(-23, 0, 117),
	["LeftShoulder"] = Vector3.new(102, -119, -8),
	["LeftElbow"] = Vector3.new(0, 0, 0),
	["LeftWrist"] = Vector3.new(0, 0, 0)
}
local v_u_9 = Color3.fromRGB(80, 170, 240)
local v_u_10 = {}
local v_u_11 = {}
local function v_u_21() -- name: rebuildPose
	-- upvalues: (copy) v_u_7, (copy) v_u_11
	for v12, v13 in v_u_7.POSE do
		local v14 = v_u_11
		local v15 = CFrame.Angles
		local v16 = v13.X
		local v17 = math.rad(v16)
		local v18 = v13.Y
		local v19 = math.rad(v18)
		local v20 = v13.Z
		v14[v12] = v15(v17, v19, (math.rad(v20)))
	end
end
v_u_21()
local function v_u_26(p22) -- name: findMotors
	-- upvalues: (copy) v_u_7
	local v23 = {}
	for v24 in v_u_7.POSE do
		local v25 = p22:FindFirstChild(v24, true)
		if not (v25 and (v25:IsA("Motor6D") or v25:IsA("AnimationConstraint"))) then
			continue
		end
		v23[v24] = v25
	end
	return v23
end
local function v_u_29() -- name: makeShield
	-- upvalues: (copy) v_u_9
	local v27 = Instance.new("Part")
	v27.Name = "GuardShimmer"
	v27.Anchored = true
	v27.CanCollide = false
	v27.CanQuery = false
	v27.CanTouch = false
	v27.CastShadow = false
	v27.Size = Vector3.new(1, 1, 1)
	v27.Material = Enum.Material.ForceField
	v27.Color = v_u_9
	v27.Transparency = 1
	local v28 = Instance.new("SpecialMesh")
	v28.MeshType = Enum.MeshType.Sphere
	v28.Scale = Vector3.new(3.8, 4, 1.4)
	v28.Parent = v27
	v27.Parent = workspace:FindFirstChild("FX") or workspace
	return v27
end
local function v_u_31(p30) -- name: toolOf
	return p30:FindFirstChildOfClass("Tool")
end
function v_u_7.Set(p32, p33) -- name: Set
	-- upvalues: (copy) v_u_10, (copy) v_u_26
	if p32 then
		local v34 = v_u_10[p32]
		if not v34 then
			v34 = {
				["char"] = nil,
				["target"] = 0,
				["alpha"] = 0,
				["motors"] = nil,
				["shield"] = nil,
				["highlight"] = nil,
				["lastImpact"] = 0,
				["char"] = p32,
				["motors"] = v_u_26(p32)
			}
			v_u_10[p32] = v34
		end
		v34.target = p33 and 1 or 0
		if p33 then
			v34.motors = v_u_26(p32)
		end
	end
end
function v_u_7.SetLocal(p35) -- name: SetLocal
	-- upvalues: (copy) v_u_7, (copy) v_u_8
	v_u_7.Set(v_u_8.Character, p35)
end
function v_u_7.IsGuarding(p36) -- name: IsGuarding
	-- upvalues: (copy) v_u_10
	if p36 then
		p36 = v_u_10[p36]
	end
	local v37
	if p36 == nil then
		v37 = false
	else
		v37 = p36.target > 0
	end
	return v37
end
function v_u_7.Impact(p38, p39) -- name: Impact
	-- upvalues: (copy) v_u_10, (copy) v_u_4, (copy) v_u_31, (copy) v_u_5, (copy) v_u_3
	if p38 then
		local v40 = v_u_10[p38]
		local v41 = v_u_4.Drawn(v_u_31(p38))
		local v42
		if v41 then
			v42 = v41:FindFirstChild("Tip", true)
		else
			v42 = v41
		end
		if v41 then
			v41 = v41:FindFirstChild("Handle")
		end
		local v43
		if v42 and (v42:IsA("Attachment") and (v41 and v41:IsA("BasePart"))) then
			v43 = v41.Position:Lerp(v42.WorldPosition, 0.6)
		else
			v43 = v_u_4.Drawn(p38:FindFirstChild("HumanoidRootPart"))
			if v43 then
				v43 = (v43.CFrame * CFrame.new(0, 1, -1.6)).Position
			end
		end
		if v43 then
			v_u_5.Burst("Block_Spark", CFrame.new(v43), 1.4)
			v_u_5.Burst("Impact_Sparks", CFrame.new(v43), 1)
			v_u_4.Sound("Block_Hit", v43)
		end
		if v40 then
			v40.lastImpact = os.clock()
			local v44 = v40.shield
			local v45 = v44 and v44:FindFirstChildOfClass("SpecialMesh")
			if v45 then
				v45.Scale = Vector3.new(4.8, 5, 1.8)
				v_u_3:Create(v45, TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Scale"] = Vector3.new(3.8, 4, 1.4)
				}):Play()
			end
			local v46 = v40.highlight
			if v46 then
				v46.OutlineTransparency = 0
			end
		end
		if p39 then
			v_u_4.Shake(0.35, 0.12)
			v_u_4.Recoil(1.6, (math.random() - 0.5) * 1.5)
		end
	end
end
local function v_u_66(p47) -- name: step
	-- upvalues: (copy) v_u_10, (copy) v_u_11, (copy) v_u_8, (copy) v_u_4, (copy) v_u_29, (copy) v_u_6, (copy) v_u_9
	for v48, v49 in v_u_10 do
		if v48:IsDescendantOf(workspace) then
			local v50
			if v49.target > v49.alpha then
				v50 = p47 / 0.08
			else
				v50 = p47 / 0.12
			end
			if v49.target > v49.alpha then
				local v51 = v49.target
				local v52 = v49.alpha + v50
				v49.alpha = math.min(v51, v52)
			else
				local v53 = v49.target
				local v54 = v49.alpha - v50
				v49.alpha = math.max(v53, v54)
			end
			if v49.alpha <= 0 and v49.target <= 0 then
				if v49.shield then
					v49.shield:Destroy()
					v49.shield = nil
				end
				if v49.highlight then
					v49.highlight:Destroy()
					v49.highlight = nil
				end
				v_u_10[v49.char] = nil
			else
				local v55 = v49.alpha * v49.alpha * (3 - v49.alpha * 2)
				for v56, v57 in v49.motors do
					local v58 = v_u_11[v56]
					if not (v58 and v57.Parent) then
						continue
					end
					v57.Transform = v57.Transform:Lerp(v58, v55)
				end
				if v48 == v_u_8.Character and v_u_4.InFirstPerson() then
					if v49.shield then
						v49.shield:Destroy()
						v49.shield = nil
					end
					if not v49.highlight then
						break
					end
					v49.highlight:Destroy()
					v49.highlight = nil
				else
					if v48:FindFirstChild("HumanoidRootPart") then
						if not v49.shield then
							v49.shield = v_u_29()
						end
						local v59 = v49.shield
						local v60 = 1 - (os.clock() - v49.lastImpact) / 0.25
						v59.Transparency = 1 - v55 * (math.clamp(v60, 0, 1) * 0.2 + 0.8)
					end
					local v61
					if v_u_6.highlights then
						v61 = v48:FindFirstChildOfClass("Tool")
					else
						v61 = nil
					end
					local v62
					if v61 then
						v62 = v_u_4.Drawn(v61)
					else
						v62 = nil
					end
					if not v62 then
						break
					end
					local v63 = v49.highlight
					if not v63 or v63.Parent ~= v62 then
						if v63 then
							v63:Destroy()
						end
						v63 = Instance.new("Highlight")
						v63.Name = "GuardHighlight"
						v63.Adornee = v62
						v63.DepthMode = Enum.HighlightDepthMode.Occluded
						v63.FillColor = v_u_9
						v63.OutlineColor = Color3.fromRGB(90, 185, 250)
						v63.Parent = v62
						v49.highlight = v63
					end
					local v64 = 1 - (os.clock() - v49.lastImpact) / 0.25
					local v65 = math.clamp(v64, 0, 1)
					v63.FillTransparency = 1
					v63.OutlineTransparency = 1 - v55 * (v65 * 0.45 + 0.55)
				end
			end
		else
			if v49.shield then
				v49.shield:Destroy()
				v49.shield = nil
			end
			if v49.highlight then
				v49.highlight:Destroy()
				v49.highlight = nil
			end
			v_u_10[v49.char] = nil
		end
	end
end
local function v_u_71() -- name: placeShields
	-- upvalues: (copy) v_u_10, (copy) v_u_4
	for v67, v68 in v_u_10 do
		local v69 = v68.shield
		if not v69 then
			continue
		end
		local v70 = v_u_4.Drawn(v67:FindFirstChild("HumanoidRootPart"))
		if not (v70 and v70:IsA("BasePart")) then
			continue
		end
		v69.CFrame = v70.CFrame * CFrame.new(0, 1.1, -1.6)
	end
end
local v_u_72 = game:GetService("CollectionService")
local v_u_73 = {}
local function v_u_76(p_u_74) -- name: watchModel
	-- upvalues: (copy) v_u_73, (copy) v_u_8, (copy) v_u_7
	if not v_u_73[p_u_74] and p_u_74 ~= v_u_8.Character then
		v_u_73[p_u_74] = true
		local function v75() -- name: apply
			-- upvalues: (ref) v_u_7, (copy) p_u_74
			v_u_7.Set(p_u_74, p_u_74:GetAttribute("Blocking") == true)
		end
		p_u_74:GetAttributeChangedSignal("Blocking"):Connect(v75)
		p_u_74.Destroying:Once(function()
			-- upvalues: (ref) v_u_73, (copy) p_u_74
			v_u_73[p_u_74] = nil
		end)
		if p_u_74:GetAttribute("Blocking") == true then
			v_u_7.Set(p_u_74, p_u_74:GetAttribute("Blocking") == true)
		end
	end
end
local function v_u_78(p77) -- name: watchPlayer
	-- upvalues: (copy) v_u_8, (copy) v_u_76
	if p77 ~= v_u_8 then
		p77.CharacterAdded:Connect(v_u_76)
		if p77.Character then
			v_u_76(p77.Character)
		end
	end
end
local function v_u_83() -- name: reconcile
	-- upvalues: (copy) v_u_8, (copy) v_u_10, (copy) v_u_7, (copy) v_u_1, (copy) v_u_72
	for _, v79 in v_u_1:GetPlayers() do
		local v80 = v79.Character
		if not v80 or (v80 == v_u_8.Character or (not v80:IsDescendantOf(workspace) or (v80:GetAttribute("Blocking") ~= true or v_u_10[v80]))) then
			continue
		end
		v_u_7.Set(v80, true)
	end
	for _, v81 in { "Combatant", "Bot" } do
		for _, v82 in v_u_72:GetTagged(v81) do
			if not v82:IsA("Model") or (not v82 or (v82 == v_u_8.Character or (not v82:IsDescendantOf(workspace) or (v82:GetAttribute("Blocking") ~= true or v_u_10[v82])))) then
				continue
			end
			v_u_7.Set(v82, true)
		end
	end
end
local v_u_84 = false
function v_u_7.Init() -- name: Init
	-- upvalues: (ref) v_u_84, (copy) v_u_2, (copy) v_u_66, (copy) v_u_71, (copy) v_u_83, (copy) v_u_1, (copy) v_u_8, (copy) v_u_76, (copy) v_u_78, (copy) v_u_72
	if not v_u_84 then
		v_u_84 = true
		v_u_2.PreSimulation:Connect(v_u_66)
		v_u_2:BindToRenderStep("TribesGuardShields", Enum.RenderPriority.Camera.Value - 1, v_u_71)
		task.spawn(function()
			-- upvalues: (ref) v_u_83
			while true do
				task.wait(1)
				local v85 = v_u_83
				pcall(v85)
			end
		end)
		for _, v86 in v_u_1:GetPlayers() do
			if v86 == v_u_8 then
				continue
			end
			v86.CharacterAdded:Connect(v_u_76)
			if not v86.Character then
				continue
			end
			v_u_76(v86.Character)
		end
		v_u_1.PlayerAdded:Connect(v_u_78)
		for _, v87 in { "Combatant", "Bot" } do
			v_u_72:GetInstanceAddedSignal(v87):Connect(function(p88)
				-- upvalues: (ref) v_u_76
				if p88:IsA("Model") then
					v_u_76(p88)
				end
			end)
			for _, v89 in v_u_72:GetTagged(v87) do
				if not v89:IsA("Model") then
					continue
				end
				v_u_76(v89)
			end
		end
	end
end
function v_u_7.RebuildPose() -- name: RebuildPose
	-- upvalues: (copy) v_u_21
	v_u_21()
end
return v_u_7