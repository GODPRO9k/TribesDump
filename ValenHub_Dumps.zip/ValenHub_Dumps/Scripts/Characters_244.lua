local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("Players")
local v3 = {}
local v_u_4 = { "Combatant", "Bot" }
local v_u_5 = game:GetService("RunService"):IsStudio()
local v_u_6 = {}
local v_u_7 = {}
local v_u_8 = true
local v_u_9 = false
local function v_u_10() -- name: markDirty
	-- upvalues: (ref) v_u_8
	v_u_8 = true
end
local function v_u_14(p11) -- name: addTagged
	-- upvalues: (copy) v_u_1, (copy) v_u_7, (copy) v_u_6
	for _, v12 in v_u_1:GetTagged(p11) do
		if not v12:IsA("Model") or (not v12.Parent or (v_u_7[v12] or table.find(v_u_6, v12))) then
			continue
		end
		local v13 = v_u_6
		table.insert(v13, v12)
	end
end
local function v_u_19() -- name: rebuild
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_2, (copy) v_u_4, (copy) v_u_14, (copy) v_u_5, (ref) v_u_8
	table.clear(v_u_6)
	table.clear(v_u_7)
	for _, v15 in v_u_2:GetPlayers() do
		local v16 = v15.Character
		if not (v16 and v16.Parent) then
			continue
		end
		local v17 = v_u_6
		table.insert(v17, v16)
		v_u_7[v16] = v15
	end
	for _, v18 in v_u_4 do
		v_u_14(v18)
	end
	if v_u_5 then
		v_u_14("CharacterLoadTest")
	end
	v_u_8 = false
end
local function v_u_23() -- name: start
	-- upvalues: (ref) v_u_9, (copy) v_u_2, (copy) v_u_10, (ref) v_u_8, (copy) v_u_4, (copy) v_u_1, (copy) v_u_5
	if not v_u_9 then
		v_u_9 = true
		for _, v20 in v_u_2:GetPlayers() do
			v20.CharacterAdded:Connect(v_u_10)
			v20.CharacterRemoving:Connect(v_u_10)
			v20:GetPropertyChangedSignal("Character"):Connect(v_u_10)
		end
		v_u_2.PlayerAdded:Connect(function(p21)
			-- upvalues: (ref) v_u_10, (ref) v_u_8
			p21.CharacterAdded:Connect(v_u_10)
			p21.CharacterRemoving:Connect(v_u_10)
			p21:GetPropertyChangedSignal("Character"):Connect(v_u_10)
			v_u_8 = true
		end)
		v_u_2.PlayerRemoving:Connect(v_u_10)
		for _, v22 in v_u_4 do
			v_u_1:GetInstanceAddedSignal(v22):Connect(v_u_10)
			v_u_1:GetInstanceRemovedSignal(v22):Connect(v_u_10)
		end
		if v_u_5 then
			v_u_1:GetInstanceAddedSignal("CharacterLoadTest"):Connect(v_u_10)
			v_u_1:GetInstanceRemovedSignal("CharacterLoadTest"):Connect(v_u_10)
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_8
			while true do
				task.wait(1)
				v_u_8 = true
			end
		end)
	end
end
function v3.List() -- name: List
	-- upvalues: (copy) v_u_23, (ref) v_u_8, (copy) v_u_19, (copy) v_u_6
	v_u_23()
	if v_u_8 then
		v_u_19()
	end
	return v_u_6
end
function v3.PlayerOf(p24) -- name: PlayerOf
	-- upvalues: (copy) v_u_23, (ref) v_u_8, (copy) v_u_19, (copy) v_u_7
	v_u_23()
	if v_u_8 then
		v_u_19()
	end
	return v_u_7[p24]
end
return v3