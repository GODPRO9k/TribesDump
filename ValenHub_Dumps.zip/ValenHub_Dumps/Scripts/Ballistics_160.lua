local v_u_22 = {
	["MAX_LIFETIME"] = 5,
	["MAX_DISTANCE"] = 1200,
	["new"] = function(p1, p2, p3, p4) -- name: new
		return {
			["pos"] = nil,
			["vel"] = nil,
			["gravity"] = nil,
			["radius"] = nil,
			["age"] = 0,
			["traveled"] = 0,
			["pos"] = p1,
			["vel"] = p2,
			["gravity"] = p3,
			["radius"] = p4 or 0
		}
	end,
	["Advance"] = function(p5, p6) -- name: Advance
		local v7 = -p5.gravity
		local v8 = Vector3.new(0, v7, 0)
		local v9 = p5.vel * p6 + v8 * (p6 * 0.5 * p6)
		local v10 = p5.pos
		p5.pos = v10 + v9
		p5.vel = p5.vel + v8 * p6
		p5.age = p5.age + p6
		p5.traveled = p5.traveled + v9.Magnitude
		return v10, v9
	end,
	["Expired"] = function(p11) -- name: Expired
		-- upvalues: (copy) v_u_22
		return p11.age > v_u_22.MAX_LIFETIME and true or p11.traveled > v_u_22.MAX_DISTANCE
	end,
	["Cast"] = function(p12, p13, p14, p15) -- name: Cast
		if p13.Magnitude < 0.0001 then
			return nil
		end
		if p14 > 0 then
			local v16 = workspace.Spherecast
			local v17 = workspace
			local v18, v19 = pcall(v16, v17, p12, p14, p13, p15)
			if v18 then
				return v19
			end
		end
		return workspace:Raycast(p12, p13, p15)
	end,
	["Velocity"] = function(p20, p21) -- name: Velocity
		return p20.Unit * p21
	end
}
return v_u_22