local v1 = game:GetService("UserInputService")
local v2 = {}
local v_u_3 = {}
v1.TouchStarted:Connect(function(p4)
	-- upvalues: (copy) v_u_3
	v_u_3[p4] = Vector2.new(p4.Position.X, p4.Position.Y)
end)
v1.TouchEnded:Connect(function(p_u_5)
	-- upvalues: (copy) v_u_3
	task.defer(function()
		-- upvalues: (ref) v_u_3, (copy) p_u_5
		v_u_3[p_u_5] = nil
	end)
end)
function v2.BeganOn(p6, p7) -- name: BeganOn
	-- upvalues: (copy) v_u_3
	if p7.UserInputType ~= Enum.UserInputType.Touch then
		return true
	end
	local v8 = v_u_3[p7]
	if v8 == nil then
		return true
	end
	local v9 = p6.AbsolutePosition
	local v10 = p6.AbsoluteSize
	local v11
	if v8.X >= v9.X - 6 and (v8.X <= v9.X + v10.X + 6 and v8.Y >= v9.Y - 6) then
		v11 = v8.Y <= v9.Y + v10.Y + 6
	else
		v11 = false
	end
	return v11
end
return v2