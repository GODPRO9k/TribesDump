local v1 = {
	["nock"] = {
		["contact"] = 0,
		["release"] = 0.16,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.05,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.008, 0.014, 0),
				["rot"] = Vector3.new(0, 0, -6)
			},
			{
				["t"] = 0.16,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["release"] = {
		["contact"] = 0,
		["release"] = 0.55,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0, "twang" },
			{ 0.3, "nock", "Equip_Bow" }
		},
		["keys"] = {
			{
				["t"] = 0.017,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.006, -0.004, -0.06),
				["rot"] = Vector3.new(-8, 2, -18)
			},
			{
				["t"] = 0.08,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.006, -0.002, -0.03),
				["rot"] = Vector3.new(-12, 2, -26)
			},
			{
				["t"] = 0.18,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.004, -0.002, -0.01),
				["rot"] = Vector3.new(-6, 1, -14)
			},
			{
				["t"] = 0.3,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.022, 0.006),
				["rot"] = Vector3.new(-4, 0, -5)
			},
			{
				["t"] = 0.42,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.012, 0),
				["rot"] = Vector3.new(2, 0, 2)
			},
			{
				["t"] = 0.55,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = {
		["contact"] = 0,
		["release"] = 0.36,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.26, "nock", "Equip_Bow" }
		},
		["keys"] = {
			{
				["t"] = 0.16,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.022, 0),
				["rot"] = Vector3.new(3, 2, 6)
			},
			{
				["t"] = 0.26,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.005, 0),
				["rot"] = Vector3.new(-0.6, 0, -1.4)
			},
			{
				["t"] = 0.36,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	}
}
local v2 = {
	["nock"] = v1.nock,
	["release"] = {
		["contact"] = 0,
		["release"] = 0.55,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0, "twang" },
			{ 0.3, "glint", "Crossbow_Ready" }
		},
		["keys"] = {
			{
				["t"] = 0.016,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.02, 0.1),
				["rot"] = Vector3.new(16, -2, -6)
			},
			{
				["t"] = 0.07,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.004, 0.014, 0.06),
				["rot"] = Vector3.new(10, -1, -24)
			},
			{
				["t"] = 0.14,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.002, 0.004, 0.015),
				["rot"] = Vector3.new(3, 0, -8)
			},
			{
				["t"] = 0.26,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.014, 0.004),
				["rot"] = Vector3.new(-3.5, 0, 2.5)
			},
			{
				["t"] = 0.3,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.006, -0.004),
				["rot"] = Vector3.new(1.5, 0, -1)
			},
			{
				["t"] = 0.4,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.001, 0),
				["rot"] = Vector3.new(0.3, 0, -0.2)
			},
			{
				["t"] = 0.55,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = v1.draw
}
local function v13(p3, p4, p5, p6, p7, p8, p9, p10, p11, p12) -- name: A
	return {
		["t"] = p3,
		["pos"] = Vector3.new(p4, p5, p6),
		["tip"] = Vector3.new(p7, p8, p9),
		["edge"] = Vector3.new(p10, p11, p12)
	}
end
local v14 = {
	["chop_r"] = {
		["contact"] = 0.2,
		["release"] = 0.76,
		["smear"] = nil,
		["keys"] = nil,
		["smear"] = { 0.15, 0.27 },
		["keys"] = {
			v13(0.08, 0.66, 0.02, -0.5, 0.757, 0.636, 0.151, -0.222, 0.467, -0.856),
			v13(0.15, 0.42, 0.44, -0.5, 0.1, 0.78, -0.62, -0.992, 0.127, 0),
			v13(0.2, 0.1, -0.14, -0.5, -0.35, 0.35, -0.869, -0.707, -0.707, 0),
			v13(0.25, -0.45, -0.44, -0.5, -0.766, -0.317, -0.559, -0.187, -0.722, 0.666),
			v13(0.34, -0.6, -0.62, -0.46, -0.636, -0.757, 0.151, 0.467, -0.222, 0.856),
			v13(0.52, 0.2, -0.8, -0.52, -0.3, 0.8, -0.5, -0.6, 0, -0.8),
			{
				["t"] = 0.65,
				["rest"] = nil,
				["rest"] = Vector3.new(0, 0.015, 0)
			},
			{
				["t"] = 0.76,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["chop_l"] = {
		["contact"] = 0.2,
		["release"] = 0.7,
		["smear"] = nil,
		["keys"] = nil,
		["smear"] = { 0.15, 0.26 },
		["keys"] = {
			v13(0.06, 0.14, -0.82, -0.46, 0.25, -0.8, -0.55, -0.95, -0.05, -0.3),
			v13(0.11, -0.5, -0.78, -0.46, -0.7, -0.5, -0.5, 0.5, -0.7, 0),
			v13(0.15, -0.56, -0.3, -0.5, -0.82, -0.12, -0.56, 0.145, -0.989, 0),
			v13(0.2, 0.1, -0.14, -0.5, -0.35, 0.35, -0.869, -0.707, -0.707, 0),
			v13(0.25, 0.56, 0.02, -0.5, 0.3, 0.7, -0.65, -0.919, 0.394, 0),
			v13(0.34, 0.72, 0.3, -0.46, 0.8, 0.5, 0.3, -0.53, 0.848, 0),
			{
				["t"] = 0.54,
				["rest"] = nil,
				["rest"] = Vector3.new(0, -0.01, 0)
			},
			{
				["t"] = 0.7,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["heavy"] = {
		["contact"] = 0.16,
		["release"] = 0.84,
		["smear"] = nil,
		["keys"] = nil,
		["smear"] = { 0.1, 0.2 },
		["keys"] = {
			v13(0.06, 0.66, 0.3, -0.46, 0.3, 0.6, 0.74, 0, 0.75, -0.66),
			v13(0.12, 0.42, 0.42, -0.5, 0.2, 0.85, -0.49, -0.973, 0.229, 0),
			v13(0.16, 0.17, -0.17, -0.5, -0.22, 0.62, -0.75, -0.942, -0.334, 0),
			v13(0.19, -0.02, -0.34, -0.5, -0.66, 0, -0.75, 0, -1, 0),
			v13(0.22, -0.01, -0.325, -0.5, -0.62, 0.08, -0.78, -0.128, -0.992, 0),
			v13(0.4, 0, -0.33, -0.5, -0.63, 0.04, -0.78, -0.063, -0.998, 0),
			v13(0.47, 0.14, -0.36, -0.5, -0.5, 0.35, -0.79, -0.573, -0.819, 0),
			v13(0.56, 0.31, -0.26, -0.57, -0.26, 0.86, -0.44, -0.6, 0, -0.8),
			{
				["t"] = 0.7,
				["rest"] = nil,
				["rest"] = Vector3.new(0, 0.02, 0)
			},
			{
				["t"] = 0.84,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = {
		["contact"] = 0,
		["release"] = 0.38,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.07,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.08, -0.1, 0.02),
				["rot"] = Vector3.new(-15, -6, -60)
			},
			{
				["t"] = 0.16,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.025, 0),
				["rot"] = Vector3.new(-4, 0, 6)
			},
			{
				["t"] = 0.25,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.008, 0),
				["rot"] = Vector3.new(1.5, 0, -1)
			},
			{
				["t"] = 0.38,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	}
}
local v15 = {
	["smash"] = {
		["contact"] = 0.17,
		["release"] = 0.66,
		["smear"] = nil,
		["keys"] = nil,
		["smear"] = { 0.12, 0.22 },
		["keys"] = {
			v13(0.07, 0.66, 0.2, -0.48, 0.45, 0.7, 0.55, -0.7, 0.45, 0),
			v13(0.12, 0.42, 0.5, -0.5, -0.05, 0.85, -0.52, -0.998, -0.059, 0),
			v13(0.17, 0.14, -0.16, -0.5, -0.45, 0.45, -0.77, -0.707, -0.707, 0),
			v13(0.21, -0.12, -0.55, -0.48, -0.6, -0.1, -0.79, 0.164, -0.986, 0),
			v13(0.32, -0.15, -0.78, -0.46, -0.3, -0.85, -0.43, 0.943, -0.333, 0),
			v13(0.46, 0.24, -0.82, -0.5, 0, 0.85, -0.5, -0.6, 0, -0.8),
			{
				["t"] = 0.56,
				["rest"] = nil,
				["rest"] = Vector3.new(0, 0.015, 0)
			},
			{
				["t"] = 0.66,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["swing"] = {
		["contact"] = 0.17,
		["release"] = 0.68,
		["smear"] = nil,
		["keys"] = nil,
		["smear"] = { 0.12, 0.24 },
		["keys"] = {
			v13(0.07, 0.74, -0.1, -0.5, 0.5, 0.6, -0.62, -0.768, 0.64, 0),
			v13(0.12, 0.7, -0.12, -0.5, 0.25, 0.6, -0.76, -0.923, 0.385, 0),
			v13(0.17, 0.05, -0.2, -0.5, -0.05, 0.6, -0.8, -0.997, -0.083, 0),
			v13(0.225, -0.62, -0.25, -0.5, -0.35, 0.55, -0.76, -0.844, -0.537, 0),
			v13(0.32, -0.85, -0.55, -0.46, -0.8, 0.1, -0.59, -0.124, -0.992, 0),
			v13(0.45, 0.22, -0.84, -0.48, -0.2, 0.85, -0.5, -0.6, 0, -0.8),
			{
				["t"] = 0.56,
				["rest"] = nil,
				["rest"] = Vector3.new(0, 0.015, 0)
			},
			{
				["t"] = 0.68,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = {
		["contact"] = 0,
		["release"] = 0.44,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.07,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.1, -0.08, 0.02),
				["rot"] = Vector3.new(-6, -4, -95)
			},
			{
				["t"] = 0.15,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.015, 0.035, 0),
				["rot"] = Vector3.new(2, 0, 10)
			},
			{
				["t"] = 0.23,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.025, 0),
				["rot"] = Vector3.new(-2, 0, -2)
			},
			{
				["t"] = 0.32,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.005, 0),
				["rot"] = Vector3.new(0.5, 0, 0.5)
			},
			{
				["t"] = 0.44,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	}
}
local function v22(p16) -- name: straight
	local v17 = p16 or 1
	local v18 = {}
	local v19 = 0.02 * v17
	local v20 = -0.006 * v17
	local v21 = 0.06 * v17
	__set_list(v18, 1, {{
	["t"] = 0.017,
	["rest"] = nil,
	["rot"] = nil,
	["rest"] = Vector3.new(v19, v20, v21),
	["rot"] = Vector3.new(4, -3, -4)
}, {
	["t"] = 0.044,
	["rest"] = nil,
	["rot"] = nil,
	["rest"] = Vector3.new(-0.13, 0.085, -0.1),
	["rot"] = Vector3.new(-4, 9, -8)
}, {
	["t"] = 0.07,
	["rest"] = nil,
	["rot"] = nil,
	["rest"] = Vector3.new(-0.275, 0.19, -0.23),
	["rot"] = Vector3.new(-8, 16, -12)
}, {
	["t"] = 0.1,
	["rest"] = nil,
	["rot"] = nil,
	["rest"] = Vector3.new(-0.292, 0.2, -0.252),
	["rot"] = Vector3.new(-9, 17, -12)
}, {
	["t"] = 0.2,
	["rest"] = nil,
	["rot"] = nil,
	["rest"] = Vector3.new(-0.05, 0.012, -0.035),
	["rot"] = Vector3.new(-2, 3, -2)
}, {
	["t"] = 0.28,
	["rest"] = nil,
	["rot"] = nil,
	["rest"] = Vector3.new(0.012, -0.028, 0.008),
	["rot"] = Vector3.new(2, 0, 1)
}, {
	["t"] = 0.36,
	["rest"] = Vector3.new(0, 0, 0)
}})
	return v18
end
local function v24(p23) -- name: tuck
	return {
		{
			["t"] = 0.06,
			["rest"] = nil,
			["rot"] = nil,
			["rest"] = Vector3.new(0.02, 0.01, 0.045),
			["rot"] = Vector3.new(7, -3, -4)
		},
		{
			["t"] = 0.2,
			["rest"] = nil,
			["rot"] = nil,
			["rest"] = Vector3.new(0.022, 0.012, 0.048),
			["rot"] = Vector3.new(7, -3, -4)
		},
		{
			["t"] = nil,
			["rest"] = Vector3.new(0, 0, 0),
			["t"] = p23
		}
	}
end
local v25 = {
	["jab"] = {
		["contact"] = 0.07,
		["release"] = 0.36,
		["smear"] = nil,
		["smearLeft"] = true,
		["keys"] = nil,
		["left"] = nil,
		["smear"] = { 0.025, 0.1 },
		["keys"] = v24(0.36),
		["left"] = v22()
	},
	["cross"] = {
		["contact"] = 0.07,
		["release"] = 0.36,
		["smear"] = nil,
		["keys"] = nil,
		["left"] = nil,
		["smear"] = { 0.025, 0.1 },
		["keys"] = v22(1.25),
		["left"] = v24(0.36)
	},
	["hook"] = {
		["contact"] = 0.07,
		["release"] = 0.38,
		["smear"] = nil,
		["smearLeft"] = true,
		["keys"] = nil,
		["left"] = nil,
		["smear"] = { 0.02, 0.105 },
		["keys"] = v24(0.38),
		["left"] = {
			{
				["t"] = 0.022,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.15, 0.13, -0.02),
				["rot"] = Vector3.new(-4, -30, -22)
			},
			{
				["t"] = 0.046,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.04, 0.165, -0.1),
				["rot"] = Vector3.new(-6, 10, 30)
			},
			{
				["t"] = 0.07,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.25, 0.17, -0.16),
				["rot"] = Vector3.new(-6, 24, 50)
			},
			{
				["t"] = 0.105,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.34, 0.16, -0.13),
				["rot"] = Vector3.new(-6, 32, 58)
			},
			{
				["t"] = 0.22,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.06, 0.02, -0.01),
				["rot"] = Vector3.new(-2, 6, 10)
			},
			{
				["t"] = 0.3,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.012, -0.026, 0.006),
				["rot"] = Vector3.new(2, -1, -2)
			},
			{
				["t"] = 0.38,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["upper"] = {
		["contact"] = 0.07,
		["release"] = 0.44,
		["smear"] = nil,
		["fx"] = nil,
		["keys"] = nil,
		["left"] = nil,
		["smear"] = { 0.025, 0.105 },
		["fx"] = {
			{ 0.07, "flare" }
		},
		["keys"] = {
			{
				["t"] = 0.022,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.09, 0.05),
				["rot"] = Vector3.new(-26, 0, -6)
			},
			{
				["t"] = 0.046,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.11, 0.075, -0.065),
				["rot"] = Vector3.new(-6, 3, -2)
			},
			{
				["t"] = 0.07,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.2, 0.21, -0.13),
				["rot"] = Vector3.new(12, 0, -4)
			},
			{
				["t"] = 0.105,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.22, 0.28, -0.15),
				["rot"] = Vector3.new(20, 0, -4)
			},
			{
				["t"] = 0.24,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.035, 0.03, 0),
				["rot"] = Vector3.new(0, 0, 0)
			},
			{
				["t"] = 0.34,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, -0.028, 0.006),
				["rot"] = Vector3.new(-3, 0, 0)
			},
			{
				["t"] = 0.44,
				["rest"] = Vector3.new(0, 0, 0)
			}
		},
		["left"] = v24(0.44)
	},
	["lunge"] = {
		["contact"] = 0.224,
		["release"] = 0.9,
		["smear"] = nil,
		["keys"] = nil,
		["left"] = nil,
		["smear"] = { 0.1, 0.32 },
		["keys"] = {
			{
				["t"] = 0.096,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.035, 0.02, 0.09),
				["rot"] = Vector3.new(8, -5, -8)
			},
			{
				["t"] = 0.16,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.12, 0.08, -0.12),
				["rot"] = Vector3.new(-4, 8, -8)
			},
			{
				["t"] = 0.224,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.3, 0.2, -0.33),
				["rot"] = Vector3.new(-8, 16, -12)
			},
			{
				["t"] = 0.35,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.315, 0.205, -0.35),
				["rot"] = Vector3.new(-9, 17, -12)
			},
			{
				["t"] = 0.576,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.07, 0.015, -0.05),
				["rot"] = Vector3.new(-3, 2, -3)
			},
			{
				["t"] = 0.736,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.014, -0.03, 0.01),
				["rot"] = Vector3.new(2, 0, 1)
			},
			{
				["t"] = 0.9,
				["rest"] = Vector3.new(0, 0, 0)
			}
		},
		["left"] = {
			{
				["t"] = 0.096,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, -0.01, 0.03),
				["rot"] = Vector3.new(4, 0, -3)
			},
			{
				["t"] = 0.224,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.04, -0.03, 0.07),
				["rot"] = Vector3.new(8, 0, -6)
			},
			{
				["t"] = 0.48,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.035, -0.025, 0.06),
				["rot"] = Vector3.new(7, 0, -5)
			},
			{
				["t"] = 0.9,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = {
		["contact"] = 0,
		["release"] = 0.38,
		["fx"] = nil,
		["keys"] = nil,
		["left"] = nil,
		["fx"] = {
			{ 0.1, "knock", "Gauntlet_Equip" }
		},
		["keys"] = {
			{
				["t"] = 0.06,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.11, -0.12, 0),
				["rot"] = Vector3.new(-10, 12, -45)
			},
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.225, 0.17, -0.03),
				["rot"] = Vector3.new(-4, 18, -66)
			},
			{
				["t"] = 0.13,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.205, 0.16, -0.028),
				["rot"] = Vector3.new(-3, 16, -58)
			},
			{
				["t"] = 0.2,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.024, 0.034, 0),
				["rot"] = Vector3.new(2, -3, 6)
			},
			{
				["t"] = 0.28,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.006, -0.008, 0),
				["rot"] = Vector3.new(-1, 0, 0)
			},
			{
				["t"] = 0.38,
				["rest"] = Vector3.new(0, 0, 0)
			}
		},
		["left"] = {
			{
				["t"] = 0.06,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.11, -0.12, 0),
				["rot"] = Vector3.new(-10, 12, -45)
			},
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.225, 0.17, -0.03),
				["rot"] = Vector3.new(-4, 18, -66)
			},
			{
				["t"] = 0.13,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.205, 0.16, -0.028),
				["rot"] = Vector3.new(-3, 16, -58)
			},
			{
				["t"] = 0.2,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.024, 0.034, 0),
				["rot"] = Vector3.new(2, -3, 6)
			},
			{
				["t"] = 0.28,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.006, -0.008, 0),
				["rot"] = Vector3.new(-1, 0, 0)
			},
			{
				["t"] = 0.38,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	}
}
local v26 = (Vector3.new(0, 0.5, 0.866)).Unit
local v27 = (Vector3.new(0, 1, 0) - v26 * v26.Y).Unit
local v28 = v26:Cross(v27).Unit
local v29 = {}
local v30 = {
	["contact"] = 0.2,
	["release"] = 0.74,
	["smear"] = nil,
	["refreshAt"] = 0.44,
	["keys"] = nil,
	["smear"] = { 0.12, 0.31 }
}
local v31 = {}
local v32 = v27 * 0.8090169943749475 + v28 * -0.5877852522924731
local v33 = -v27 * -0.5877852522924731 + v28 * 0.8090169943749475
local v34 = v13(0.06, 0.44, -0.465, -0.42, v32.X, v32.Y, v32.Z, v33.X, v33.Y, v33.Z)
local v35 = v27 * 0.13917310096006547 + v28 * -0.9902680687415704
local v36 = -v27 * -0.9902680687415704 + v28 * 0.13917310096006547
local v37 = v13(0.105, 0.43, -0.465, -0.43, v35.X, v35.Y, v35.Z, v36.X, v36.Y, v36.Z)
local v38 = v27 * 0.6691306063588582 + v28 * -0.7431448254773942
local v39 = -v27 * -0.7431448254773942 + v28 * 0.6691306063588582
local v40 = v13(0.15, 0.38, -0.475, -0.44, v38.X, v38.Y, v38.Z, v39.X, v39.Y, v39.Z)
local v41 = v27 * 0.9993908270190958 + v28 * -0.03489949670250097
local v42 = -v27 * -0.03489949670250097 + v28 * 0.9993908270190958
local v43 = v13(0.2, 0.3, -0.485, -0.45, v41.X, v41.Y, v41.Z, v42.X, v42.Y, v42.Z)
local v44 = v27 * 0.6946583704589973 + v28 * 0.7193398003386511
local v45 = -v27 * 0.7193398003386511 + v28 * 0.6946583704589973
local v46 = v13(0.24, 0.22, -0.495, -0.44, v44.X, v44.Y, v44.Z, v45.X, v45.Y, v45.Z)
local v47 = v27 * -0.034899496702500955 + v28 * 0.9993908270190958
local v48 = -v27 * 0.9993908270190958 + v28 * -0.034899496702500955
local v49 = v13(0.28, 0.14, -0.53, -0.42, v47.X, v47.Y, v47.Z, v48.X, v48.Y, v48.Z)
local v50 = v27 * -0.6427876096865394 + v28 * 0.766044443118978
local v51 = -v27 * 0.766044443118978 + v28 * -0.6427876096865394
local v52 = v13(0.32, 0.18, -0.7, -0.41, v50.X, v50.Y, v50.Z, v51.X, v51.Y, v51.Z)
local v53 = v27 * -0.984807753012208 + v28 * -0.17364817766693047
local v54 = -v27 * -0.17364817766693047 + v28 * -0.984807753012208
local v55 = v13(0.37, 0.3, -0.95, -0.42, v53.X, v53.Y, v53.Z, v54.X, v54.Y, v54.Z)
local v56 = v27 * -0.17364817766693033 + v28 * -0.984807753012208
local v57 = -v27 * -0.984807753012208 + v28 * -0.17364817766693033
__set_list(v31, 1, {v34, v37, v40, v43, v46, v49, v52, v55, v13(0.42, 0.46, -1, -0.42, v56.X, v56.Y, v56.Z, v57.X, v57.Y, v57.Z), {
	["t"] = 0.49,
	["rest"] = nil,
	["rot"] = nil,
	["rest"] = Vector3.new(0.12, -0.32, 0.02),
	["rot"] = Vector3.new(0, 0, -60)
}, {
	["t"] = 0.58,
	["rest"] = nil,
	["rot"] = nil,
	["rest"] = Vector3.new(0.02, 0, 0),
	["rot"] = Vector3.new(0, 0, -14)
}, {
	["t"] = 0.65,
	["rest"] = nil,
	["rot"] = nil,
	["rest"] = Vector3.new(0, 0.012, 0),
	["rot"] = Vector3.new(0, 0, 3)
}, {
	["t"] = 0.74,
	["rest"] = Vector3.new(0, 0, 0)
}})
v30.keys = v31
v29.sweep_r = v30
local v58 = {
	["contact"] = 0.2,
	["release"] = 0.66,
	["smear"] = nil,
	["refreshAt"] = 0.44,
	["keys"] = nil,
	["smear"] = { 0.14, 0.34 }
}
local v59 = {}
local v60 = v27 * 0.8660254037844387 + v28 * 0.49999999999999994
local v61 = -v27 * 0.49999999999999994 + v28 * 0.8660254037844387
local v62 = v13(0.06, 0.38, -0.72, -0.42, v60.X, v60.Y, v60.Z, v61.X, v61.Y, v61.Z)
local v63 = v27 * -0.08715574274765824 + v28 * 0.9961946980917455
local v64 = -(-v27 * 0.9961946980917455 + v28 * -0.08715574274765824)
local v65 = v13(0.11, 0.2, -0.92, -0.42, v63.X, v63.Y, v63.Z, v64.X, v64.Y, v64.Z)
local v66 = v27 * -0.034899496702500955 + v28 * 0.9993908270190958
local v67 = -(-v27 * 0.9993908270190958 + v28 * -0.034899496702500955)
local v68 = v13(0.15, 0.13, -0.62, -0.42, v66.X, v66.Y, v66.Z, v67.X, v67.Y, v67.Z)
local v69 = v27 * 0.6156614753256583 + v28 * 0.788010753606722
local v70 = -(-v27 * 0.788010753606722 + v28 * 0.6156614753256583)
local v71 = v13(0.18, 0.2, -0.53, -0.44, v69.X, v69.Y, v69.Z, v70.X, v70.Y, v70.Z)
local v72 = v27 * 0.9993908270190958 + v28 * 0.03489949670250097
local v73 = -(-v27 * 0.03489949670250097 + v28 * 0.9993908270190958)
local v74 = v13(0.23, 0.3, -0.485, -0.45, v72.X, v72.Y, v72.Z, v73.X, v73.Y, v73.Z)
local v75 = v27 * 0.6946583704589973 + v28 * -0.7193398003386511
local v76 = -(-v27 * -0.7193398003386511 + v28 * 0.6946583704589973)
local v77 = v13(0.27, 0.36, -0.485, -0.44, v75.X, v75.Y, v75.Z, v76.X, v76.Y, v76.Z)
local v78 = v27 * -0.034899496702500955 + v28 * -0.9993908270190958
local v79 = -(-v27 * -0.9993908270190958 + v28 * -0.034899496702500955)
local v80 = v13(0.31, 0.42, -0.5, -0.42, v78.X, v78.Y, v78.Z, v79.X, v79.Y, v79.Z)
local v81 = v27 * -0.4383711467890775 + v28 * -0.8987940462991669
local v82 = -(-v27 * -0.8987940462991669 + v28 * -0.4383711467890775)
local v83 = v13(0.36, 0.5, -0.6, -0.4, v81.X, v81.Y, v81.Z, v82.X, v82.Y, v82.Z)
local v84 = v27 * 0.5000000000000001 + v28 * -0.8660254037844386
local v85 = -(-v27 * -0.8660254037844386 + v28 * 0.5000000000000001)
__set_list(v59, 1, {v62, v65, v68, v71, v74, v77, v80, v83, v13(0.42, 0.52, -0.7, -0.42, v84.X, v84.Y, v84.Z, v85.X, v85.Y, v85.Z), {
	["t"] = 0.54,
	["rest"] = nil,
	["rest"] = Vector3.new(0, 0.015, 0)
}, {
	["t"] = 0.66,
	["rest"] = Vector3.new(0, 0, 0)
}})
v58.keys = v59
v29.sweep_l = v58
local v86 = {
	["contact"] = 0.208,
	["release"] = 0.8,
	["smear"] = nil,
	["smearWidth"] = 1.35,
	["refreshAt"] = 0.46,
	["lungeRef"] = 0.2,
	["keys"] = nil,
	["smear"] = { 0.16, 0.26 }
}
local v87 = {}
local v88 = v27 * 0.5000000000000001 + v28 * -0.8660254037844386
local v89 = -v27 * -0.8660254037844386 + v28 * 0.5000000000000001
local v90 = v13(0.03, 0.66, -0.58, -0.42, v88.X, v88.Y, v88.Z, v89.X, v89.Y, v89.Z)
local v91 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v90.tip = v91:VectorToWorldSpace(v90.tip)
v90.edge = v91:VectorToWorldSpace(v90.edge)
local v92 = v27 * 0.4848096202463371 + v28 * -0.8746197071393957
local v93 = -v27 * -0.8746197071393957 + v28 * 0.4848096202463371
local v94 = v13(0.042, 0.655, -0.58, -0.42, v92.X, v92.Y, v92.Z, v93.X, v93.Y, v93.Z)
local v95 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v94.tip = v95:VectorToWorldSpace(v94.tip)
v94.edge = v95:VectorToWorldSpace(v94.edge)
local v96 = v27 * 0.4771587602596084 + v28 * -0.8788171126619654
local v97 = -v27 * -0.8788171126619654 + v28 * 0.4771587602596084
local v98 = v13(0.09, 0.651, -0.574, -0.43, v96.X, v96.Y, v96.Z, v97.X, v97.Y, v97.Z)
local v99 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v98.tip = v99:VectorToWorldSpace(v98.tip)
v98.edge = v99:VectorToWorldSpace(v98.edge)
local v100 = v27 * 0.4539904997395468 + v28 * -0.8910065241883678
local v101 = -v27 * -0.8910065241883678 + v28 * 0.4539904997395468
local v102 = v13(0.14, 0.64, -0.57, -0.43, v100.X, v100.Y, v100.Z, v101.X, v101.Y, v101.Z)
local v103 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v102.tip = v103:VectorToWorldSpace(v102.tip)
v102.edge = v103:VectorToWorldSpace(v102.edge)
local v104 = v27 * 0.766044443118978 + v28 * -0.6427876096865393
local v105 = -v27 * -0.6427876096865393 + v28 * 0.766044443118978
local v106 = v13(0.175, 0.53, -0.53, -0.45, v104.X, v104.Y, v104.Z, v105.X, v105.Y, v105.Z)
local v107 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v106.tip = v107:VectorToWorldSpace(v106.tip)
v106.edge = v107:VectorToWorldSpace(v106.edge)
local v108 = v27 * 0.9993908270190958 + v28 * -0.03489949670250097
local v109 = -v27 * -0.03489949670250097 + v28 * 0.9993908270190958
local v110 = v13(0.208, 0.36, -0.47, -0.46, v108.X, v108.Y, v108.Z, v109.X, v109.Y, v109.Z)
local v111 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v110.tip = v111:VectorToWorldSpace(v110.tip)
v110.edge = v111:VectorToWorldSpace(v110.edge)
local v112 = v27 * 0.882947592858927 + v28 * 0.4694715627858908
local v113 = -v27 * 0.4694715627858908 + v28 * 0.882947592858927
local v114 = v13(0.233, 0.29, -0.51, -0.45, v112.X, v112.Y, v112.Z, v113.X, v113.Y, v113.Z)
local v115 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v114.tip = v115:VectorToWorldSpace(v114.tip)
v114.edge = v115:VectorToWorldSpace(v114.edge)
local v116 = v27 * 0.7986355100472928 + v28 * 0.6018150231520483
local v117 = -v27 * 0.6018150231520483 + v28 * 0.7986355100472928
local v118 = v13(0.258, 0.26, -0.55, -0.44, v116.X, v116.Y, v116.Z, v117.X, v117.Y, v117.Z)
local v119 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v118.tip = v119:VectorToWorldSpace(v118.tip)
v118.edge = v119:VectorToWorldSpace(v118.edge)
local v120 = v27 * 0.766044443118978 + v28 * 0.6427876096865393
local v121 = -v27 * 0.6427876096865393 + v28 * 0.766044443118978
local v122 = v13(0.287, 0.24, -0.6, -0.43, v120.X, v120.Y, v120.Z, v121.X, v121.Y, v121.Z)
local v123 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v122.tip = v123:VectorToWorldSpace(v122.tip)
v122.edge = v123:VectorToWorldSpace(v122.edge)
local v124 = v27 * 0.6691306063588582 + v28 * 0.7431448254773942
local v125 = -v27 * 0.7431448254773942 + v28 * 0.6691306063588582
local v126 = v13(0.317, 0.22, -0.68, -0.42, v124.X, v124.Y, v124.Z, v125.X, v125.Y, v125.Z)
local v127 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v126.tip = v127:VectorToWorldSpace(v126.tip)
v126.edge = v127:VectorToWorldSpace(v126.edge)
local v128 = v27 * -0.08715574274765824 + v28 * 0.9961946980917455
local v129 = -v27 * 0.9961946980917455 + v28 * -0.08715574274765824
local v130 = v13(0.36, 0.18, -0.78, -0.41, v128.X, v128.Y, v128.Z, v129.X, v129.Y, v129.Z)
local v131 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v130.tip = v131:VectorToWorldSpace(v130.tip)
v130.edge = v131:VectorToWorldSpace(v130.edge)
local v132 = v27 * -0.9063077870366499 + v28 * 0.4226182617406995
local v133 = -v27 * 0.4226182617406995 + v28 * -0.9063077870366499
local v134 = v13(0.41, 0.3, -0.95, -0.42, v132.X, v132.Y, v132.Z, v133.X, v133.Y, v133.Z)
local v135 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v134.tip = v135:VectorToWorldSpace(v134.tip)
v134.edge = v135:VectorToWorldSpace(v134.edge)
local v136 = v27 * -0.7071067811865477 + v28 * -0.7071067811865475
local v137 = -v27 * -0.7071067811865475 + v28 * -0.7071067811865477
local v138 = v13(0.46, 0.46, -1, -0.42, v136.X, v136.Y, v136.Z, v137.X, v137.Y, v137.Z)
local v139 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v138.tip = v139:VectorToWorldSpace(v138.tip)
v138.edge = v139:VectorToWorldSpace(v138.edge)
__set_list(v87, 1, {v90, v94, v98, v102, v106, v110, v114, v118, v122, v126, v130, v134, v138, {
	["t"] = 0.53,
	["rest"] = nil,
	["rot"] = nil,
	["rest"] = Vector3.new(0.12, -0.32, 0.02),
	["rot"] = Vector3.new(0, 0, -60)
}, {
	["t"] = 0.62,
	["rest"] = nil,
	["rot"] = nil,
	["rest"] = Vector3.new(0.02, 0, 0),
	["rot"] = Vector3.new(0, 0, -14)
}, {
	["t"] = 0.7,
	["rest"] = nil,
	["rot"] = nil,
	["rest"] = Vector3.new(0, 0.012, 0),
	["rot"] = Vector3.new(0, 0, 3)
}})
__set_list(v87, 17, {{
	["t"] = 0.8,
	["rest"] = Vector3.new(0, 0, 0)
}})
v86.keys = v87
v29.lunge = v86
local v140 = {
	["contact"] = 0.208,
	["release"] = 0.8,
	["smear"] = nil,
	["smearWidth"] = 1.35,
	["refreshAt"] = 0.5,
	["lungeRef"] = 0.2,
	["keys"] = nil,
	["smear"] = { 0.16, 0.26 }
}
local v141 = {}
local v142 = v27 * 0.6156614753256583 + v28 * 0.788010753606722
local v143 = -(-v27 * 0.788010753606722 + v28 * 0.6156614753256583)
local v144 = v13(0.03, 0.3, -0.62, -0.42, v142.X, v142.Y, v142.Z, v143.X, v143.Y, v143.Z)
local v145 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v144.tip = v145:VectorToWorldSpace(v144.tip)
v144.edge = v145:VectorToWorldSpace(v144.edge)
local v146 = v27 * 0.6018150231520484 + v28 * 0.7986355100472928
local v147 = -(-v27 * 0.7986355100472928 + v28 * 0.6018150231520484)
local v148 = v13(0.042, 0.298, -0.622, -0.42, v146.X, v146.Y, v146.Z, v147.X, v147.Y, v147.Z)
local v149 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v148.tip = v149:VectorToWorldSpace(v148.tip)
v148.edge = v149:VectorToWorldSpace(v148.edge)
local v150 = v27 * 0.5591929034707468 + v28 * 0.8290375725550417
local v151 = -(-v27 * 0.8290375725550417 + v28 * 0.5591929034707468)
local v152 = v13(0.14, 0.29, -0.62, -0.43, v150.X, v150.Y, v150.Z, v151.X, v151.Y, v151.Z)
local v153 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v152.tip = v153:VectorToWorldSpace(v152.tip)
v152.edge = v153:VectorToWorldSpace(v152.edge)
local v154 = v27 * 0.848048096156426 + v28 * 0.5299192642332049
local v155 = -(-v27 * 0.5299192642332049 + v28 * 0.848048096156426)
local v156 = v13(0.175, 0.29, -0.54, -0.45, v154.X, v154.Y, v154.Z, v155.X, v155.Y, v155.Z)
local v157 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v156.tip = v157:VectorToWorldSpace(v156.tip)
v156.edge = v157:VectorToWorldSpace(v156.edge)
local v158 = v27 * 0.9993908270190958 + v28 * -0.03489949670250097
local v159 = -(-v27 * -0.03489949670250097 + v28 * 0.9993908270190958)
local v160 = v13(0.208, 0.36, -0.47, -0.46, v158.X, v158.Y, v158.Z, v159.X, v159.Y, v159.Z)
local v161 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v160.tip = v161:VectorToWorldSpace(v160.tip)
v160.edge = v161:VectorToWorldSpace(v160.edge)
local v162 = v27 * 0.8290375725550416 + v28 * -0.5591929034707469
local v163 = -(-v27 * -0.5591929034707469 + v28 * 0.8290375725550416)
local v164 = v13(0.233, 0.45, -0.42, -0.45, v162.X, v162.Y, v162.Z, v163.X, v163.Y, v163.Z)
local v165 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v164.tip = v165:VectorToWorldSpace(v164.tip)
v164.edge = v165:VectorToWorldSpace(v164.edge)
local v166 = v27 * 0.6691306063588582 + v28 * -0.7431448254773942
local v167 = -(-v27 * -0.7431448254773942 + v28 * 0.6691306063588582)
local v168 = v13(0.258, 0.52, -0.4, -0.44, v166.X, v166.Y, v166.Z, v167.X, v167.Y, v167.Z)
local v169 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v168.tip = v169:VectorToWorldSpace(v168.tip)
v168.edge = v169:VectorToWorldSpace(v168.edge)
local v170 = v27 * 0.5877852522924731 + v28 * -0.8090169943749475
local v171 = -(-v27 * -0.8090169943749475 + v28 * 0.5877852522924731)
local v172 = v13(0.29, 0.56, -0.4, -0.43, v170.X, v170.Y, v170.Z, v171.X, v171.Y, v171.Z)
local v173 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v172.tip = v173:VectorToWorldSpace(v172.tip)
v172.edge = v173:VectorToWorldSpace(v172.edge)
local v174 = v27 * 0.5000000000000001 + v28 * -0.8660254037844386
local v175 = -(-v27 * -0.8660254037844386 + v28 * 0.5000000000000001)
local v176 = v13(0.33, 0.6, -0.46, -0.43, v174.X, v174.Y, v174.Z, v175.X, v175.Y, v175.Z)
local v177 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v176.tip = v177:VectorToWorldSpace(v176.tip)
v176.edge = v177:VectorToWorldSpace(v176.edge)
local v178 = v27 * -0.3420201433256687 + v28 * -0.9396926207859084
local v179 = -v27 * -0.9396926207859084 + v28 * -0.3420201433256687
local v180 = v13(0.4, 0.55, -1, -0.42, v178.X, v178.Y, v178.Z, v179.X, v179.Y, v179.Z)
local v181 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), 0.6108652381980153)
v180.tip = v181:VectorToWorldSpace(v180.tip)
v180.edge = v181:VectorToWorldSpace(v180.edge)
__set_list(v141, 1, {v144, v148, v152, v156, v160, v164, v168, v172, v176, v180, {
	["t"] = 0.5,
	["rest"] = nil,
	["rot"] = nil,
	["rest"] = Vector3.new(0.12, -0.32, 0.02),
	["rot"] = Vector3.new(0, 0, -60)
}, {
	["t"] = 0.6,
	["rest"] = nil,
	["rot"] = nil,
	["rest"] = Vector3.new(0.02, 0, 0),
	["rot"] = Vector3.new(0, 0, -14)
}, {
	["t"] = 0.69,
	["rest"] = nil,
	["rot"] = nil,
	["rest"] = Vector3.new(0, 0.012, 0),
	["rot"] = Vector3.new(0, 0, 3)
}, {
	["t"] = 0.8,
	["rest"] = Vector3.new(0, 0, 0)
}})
v140.keys = v141
v29.lunge_b = v140
v29.draw = {
	["contact"] = 0,
	["release"] = 0.36,
	["keys"] = nil,
	["keys"] = {
		{
			["t"] = 0.06,
			["rest"] = nil,
			["rot"] = nil,
			["rest"] = Vector3.new(0.24, -0.27, 0.02),
			["rot"] = Vector3.new(0, 0, -46)
		},
		{
			["t"] = 0.13,
			["rest"] = nil,
			["rot"] = nil,
			["rest"] = Vector3.new(0, 0.02, 0),
			["rot"] = Vector3.new(0, 0, -12)
		},
		{
			["t"] = 0.22,
			["rest"] = nil,
			["rot"] = nil,
			["rest"] = Vector3.new(-0.005, 0.012, 0),
			["rot"] = Vector3.new(0, 0, 4)
		},
		{
			["t"] = 0.36,
			["rest"] = Vector3.new(0, 0, 0)
		}
	}
}
local v182 = CFrame.fromAxisAngle(Vector3.new(0, 0, 1), -0.2617993877991494)
local v183 = {}
local v_u_184 = {}
local v185 = {
	["thrust"] = {
		["contact"] = 0.1,
		["release"] = 0.48,
		["smear"] = nil,
		["fx"] = nil,
		["keys"] = nil,
		["smear"] = { 0.07, 0.15 },
		["fx"] = {
			{ 0.1, "puncture" }
		},
		["keys"] = {
			{
				["t"] = 0.05,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.035, -0.03, 0.1),
				["rot"] = Vector3.new(6, 22, 0)
			},
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.09, 0.04, -0.28),
				["rot"] = Vector3.new(5.5, 21, 0)
			},
			{
				["t"] = 0.17,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.095, 0.042, -0.31),
				["rot"] = Vector3.new(4.5, 21, 0)
			},
			{
				["t"] = 0.31,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, -0.006, 0.04),
				["rot"] = Vector3.new(2.5, 0, 0)
			},
			{
				["t"] = 0.48,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["thrust2"] = {
		["contact"] = 0.1,
		["release"] = 0.48,
		["smear"] = nil,
		["fx"] = nil,
		["keys"] = nil,
		["smear"] = { 0.07, 0.15 },
		["fx"] = {
			{ 0.1, "puncture" }
		},
		["keys"] = {
			{
				["t"] = 0.05,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.06, 0.07, 0.1),
				["rot"] = Vector3.new(18, 44, -24)
			},
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.155, -0.045, -0.28),
				["rot"] = Vector3.new(2, 28, -32)
			},
			{
				["t"] = 0.17,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.16, -0.04, -0.31),
				["rot"] = Vector3.new(1, 28, -28)
			},
			{
				["t"] = 0.31,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, -0.004, 0.04),
				["rot"] = Vector3.new(2.5, 0, 0)
			},
			{
				["t"] = 0.48,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["lunge"] = {
		["contact"] = 0.06,
		["release"] = 0.62,
		["smear"] = nil,
		["fx"] = nil,
		["keys"] = nil,
		["smear"] = { 0.03, 0.12 },
		["fx"] = {
			{ 0.06, "puncture" }
		},
		["keys"] = {
			{
				["t"] = 0.06,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.09, -0.01, -0.38),
				["rot"] = Vector3.new(12, 20, 6)
			},
			{
				["t"] = 0.3,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.095, -0.008, -0.4),
				["rot"] = Vector3.new(11, 20, 6)
			},
			{
				["t"] = 0.46,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.004, 0.035),
				["rot"] = Vector3.new(2, 0, 0)
			},
			{
				["t"] = 0.62,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = {
		["contact"] = 0,
		["release"] = 0.4,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.08,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.06, -0.07, 0.03),
				["rot"] = Vector3.new(-6, -45, -4)
			},
			{
				["t"] = 0.17,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.02, 0),
				["rot"] = Vector3.new(2, 7, 2)
			},
			{
				["t"] = 0.26,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.006, 0),
				["rot"] = Vector3.new(-0.5, -1.5, -0.5)
			},
			{
				["t"] = 0.4,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	}
}
local v186 = {
	["fire"] = {
		["contact"] = 0,
		["release"] = 0.56,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0, "muzzle" },
			{ 0, "pan" }
		},
		["keys"] = {
			{
				["t"] = 0.018,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.004, 0.02, 0.12),
				["rot"] = Vector3.new(14, -3, -6)
			},
			{
				["t"] = 0.045,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.008, 0.019, 0.115),
				["rot"] = Vector3.new(13.5, -3.5, -12)
			},
			{
				["t"] = 0.075,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.012, 0.016, 0.1),
				["rot"] = Vector3.new(12, -4, -20)
			},
			{
				["t"] = 0.14,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.006, 0.006, 0.035),
				["rot"] = Vector3.new(3.5, -1.2, -6)
			},
			{
				["t"] = 0.25,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.008, -0.01),
				["rot"] = Vector3.new(-2.5, 0, 1.5)
			},
			{
				["t"] = 0.4,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.001, 0.001),
				["rot"] = Vector3.new(0.3, 0, -0.2)
			},
			{
				["t"] = 0.56,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["reload"] = {
		["contact"] = 0,
		["release"] = 2.56,
		["span"] = 2.4,
		["fx"] = nil,
		["rod"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.12, "half", "Gun_Cock" },
			{
				0.3,
				"prime",
				"Gun_Cock",
				1.25
			},
			{ 0.4, "powder" },
			{ 0.64, "powder" },
			{
				0.84,
				"beat",
				"Musket_Ramrod",
				1.1
			},
			{ 1.03, "puff", "Musket_Ramrod_Tap" },
			{ 1.33, "puff", "Musket_Ramrod_Tap" },
			{ 1.63, "puff", "Musket_Ramrod_Tap" },
			{ 1.66, "beat", "Musket_Ramrod" },
			{
				1.95,
				"beat",
				"Musket_Ramrod_Tap",
				1.3
			},
			{ 2.4, "click", "Gun_Cock" }
		},
		["rod"] = {
			{ 0.84, 0 },
			{ 0.95, 1 },
			{ 0.955, 3.3 },
			{ 0.99, 2.6 },
			{ 1, 2.5 },
			{ 1.03, 2.08 },
			{ 1.2, 2.4 },
			{ 1.28, 2.37 },
			{ 1.3, 2.3 },
			{ 1.33, 2.08 },
			{ 1.5, 2.4 },
			{ 1.58, 2.37 },
			{ 1.6, 2.3 },
			{ 1.63, 2.08 },
			{ 1.82, 3.3 },
			{ 1.825, 1 },
			{ 1.98, 0 }
		},
		["keys"] = {
			{
				["t"] = 0.18,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.08, 0.03),
				["rot"] = Vector3.new(60, -8, 4)
			},
			{
				["t"] = 0.27,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.09, 0.03),
				["rot"] = Vector3.new(65, -9, 7)
			},
			{
				["t"] = 0.4,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.075, 0.03),
				["rot"] = Vector3.new(75, -8, 13)
			},
			{
				["t"] = 0.52,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.095, 0.03),
				["rot"] = Vector3.new(77, -8, -3)
			},
			{
				["t"] = 0.64,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.075, 0.03),
				["rot"] = Vector3.new(75, -8, 13)
			},
			{
				["t"] = 0.76,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.092, 0.03),
				["rot"] = Vector3.new(77, -8, -3)
			},
			{
				["t"] = 0.86,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.085, 0.03),
				["rot"] = Vector3.new(62, -8, 5)
			},
			{
				["t"] = 0.98,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.095, 0.03),
				["rot"] = Vector3.new(66, -8, 5)
			},
			{
				["t"] = 1.03,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.06, 0.03),
				["rot"] = Vector3.new(61, -8, 5)
			},
			{
				["t"] = 1.16,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.085, 0.03),
				["rot"] = Vector3.new(62, -8, 5)
			},
			{
				["t"] = 1.28,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.095, 0.03),
				["rot"] = Vector3.new(66, -8, 5)
			},
			{
				["t"] = 1.33,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.06, 0.03),
				["rot"] = Vector3.new(61, -8, 5)
			},
			{
				["t"] = 1.46,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.085, 0.03),
				["rot"] = Vector3.new(62, -8, 5)
			},
			{
				["t"] = 1.58,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.095, 0.03),
				["rot"] = Vector3.new(66, -8, 5)
			},
			{
				["t"] = 1.63,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.06, 0.03),
				["rot"] = Vector3.new(61, -8, 5)
			},
			{
				["t"] = 1.76,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.085, 0.03),
				["rot"] = Vector3.new(62, -8, 5)
			},
			{
				["t"] = 2.02,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, -0.035, 0.02),
				["rot"] = Vector3.new(-7, -3, -4)
			},
			{
				["t"] = 2.22,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.005, 0, 0.005),
				["rot"] = Vector3.new(-1, 0, 12)
			},
			{
				["t"] = 2.34,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.004, -0.012, 0),
				["rot"] = Vector3.new(-5, -3, 14)
			},
			{
				["t"] = 2.4,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.016, 0.016),
				["rot"] = Vector3.new(5, 0, -4)
			},
			{
				["t"] = 2.56,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = {
		["contact"] = 0,
		["release"] = 0.5,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.38, "click", "Equip_Gun" }
		},
		["keys"] = {
			{
				["t"] = 0.09,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, -0.12, 0.04),
				["rot"] = Vector3.new(-26, -8, -36)
			},
			{
				["t"] = 0.2,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.035, 0),
				["rot"] = Vector3.new(8, 2, 6)
			},
			{
				["t"] = 0.32,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.009, 0),
				["rot"] = Vector3.new(-1.8, 0, -1.4)
			},
			{
				["t"] = 0.38,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.006, 0.006),
				["rot"] = Vector3.new(2.5, 0, -2)
			},
			{
				["t"] = 0.5,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	}
}
local v187 = {
	["fire"] = {
		["contact"] = 0,
		["release"] = 0.6,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0, "muzzle" },
			{ 0, "pan" }
		},
		["keys"] = {
			{
				["t"] = 0.016,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.03, 0.08),
				["rot"] = Vector3.new(30, -3, -10)
			},
			{
				["t"] = 0.05,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.029, 0.076),
				["rot"] = Vector3.new(28.5, -3, -9.5)
			},
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.021, 0.056),
				["rot"] = Vector3.new(21, -2, -7)
			},
			{
				["t"] = 0.14,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.0135, 0.036),
				["rot"] = Vector3.new(13.5, -1.5, -4.5)
			},
			{
				["t"] = 0.2,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.004, 0.01),
				["rot"] = Vector3.new(3, 0, -1)
			},
			{
				["t"] = 0.28,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.005, -0.004),
				["rot"] = Vector3.new(-2.5, 0, 0.8)
			},
			{
				["t"] = 0.42,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.001, 0.001),
				["rot"] = Vector3.new(0.4, 0, -0.1)
			},
			{
				["t"] = 0.6,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["reload"] = {
		["contact"] = 0,
		["release"] = 1.52,
		["span"] = 1.4,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{
				0.12,
				"beat",
				"Musket_Ramrod",
				1.25
			},
			{ 0.3, "powder" },
			{ 0.5, "powder" },
			{ 0.9, "puff", "Musket_Ramrod_Tap" },
			{ 0.9, "half" },
			{ 1.4, "click", "Gun_Cock" }
		},
		["keys"] = {
			{
				["t"] = 0.12,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, 0.06, 0.03),
				["rot"] = Vector3.new(64, 6, 6)
			},
			{
				["t"] = 0.2,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, 0.072, 0.03),
				["rot"] = Vector3.new(69, 7, 9)
			},
			{
				["t"] = 0.3,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, 0.062, 0.03),
				["rot"] = Vector3.new(66, 6, 14)
			},
			{
				["t"] = 0.4,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, 0.075, 0.03),
				["rot"] = Vector3.new(68, 6, 4)
			},
			{
				["t"] = 0.5,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, 0.064, 0.03),
				["rot"] = Vector3.new(66, 6, 13)
			},
			{
				["t"] = 0.6,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, 0.07, 0.03),
				["rot"] = Vector3.new(67, 6, 5)
			},
			{
				["t"] = 0.72,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, 0.068, 0.03),
				["rot"] = Vector3.new(67, 6, 8)
			},
			{
				["t"] = 0.83,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, 0.08, 0.03),
				["rot"] = Vector3.new(71, 6, 8)
			},
			{
				["t"] = 0.9,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, 0.055, 0.03),
				["rot"] = Vector3.new(61, 6, 8)
			},
			{
				["t"] = 0.98,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, 0.065, 0.03),
				["rot"] = Vector3.new(66, 6, 8)
			},
			{
				["t"] = 1.05,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.05, 0.04, 0.02),
				["rot"] = Vector3.new(30, 2, -70)
			},
			{
				["t"] = 1.12,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.06, 0.02, 0.01),
				["rot"] = Vector3.new(10, 0, -160)
			},
			{
				["t"] = 1.19,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.05, 0, 0),
				["rot"] = Vector3.new(0, 0, -250)
			},
			{
				["t"] = 1.26,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, -0.008, 0),
				["rot"] = Vector3.new(-2, 0, -340)
			},
			{
				["t"] = 1.33,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.006, 0),
				["rot"] = Vector3.new(-2, 0, -363)
			},
			{
				["t"] = 1.4,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.016, 0.012),
				["rot"] = Vector3.new(6, 0, -365)
			},
			{
				["t"] = 1.46,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.003, 0),
				["rot"] = Vector3.new(-0.8, 0, -359.5)
			},
			{
				["t"] = 1.52,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = {
		["contact"] = 0,
		["release"] = 0.4,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.29, "click", "Equip_Gun" }
		},
		["keys"] = {
			{
				["t"] = 0.04,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, -0.3, 0.03),
				["rot"] = Vector3.new(-170, -6, 0)
			},
			{
				["t"] = 0.12,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, -0.04, 0.01),
				["rot"] = Vector3.new(-265, -3, 0)
			},
			{
				["t"] = 0.2,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.016, 0),
				["rot"] = Vector3.new(-356, 0, 2)
			},
			{
				["t"] = 0.29,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.004, 0),
				["rot"] = Vector3.new(-361, 0, -0.5)
			},
			{
				["t"] = 0.4,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	}
}
local v188 = {
	["bash"] = {
		["contact"] = 0.09,
		["release"] = 0.47,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.05,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.045, -0.03, 0.052),
				["rot"] = Vector3.new(8, -30, -10)
			},
			{
				["t"] = 0.07,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.115, -0.013, 0.015),
				["rot"] = Vector3.new(0, -25, -8)
			},
			{
				["t"] = 0.09,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.27, 0.08, -0.02),
				["rot"] = Vector3.new(-7, -18, -5)
			},
			{
				["t"] = 0.11,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.3, 0.1, -0.07),
				["rot"] = Vector3.new(-10, -14, -3)
			},
			{
				["t"] = 0.16,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.22, 0.04, -0.03),
				["rot"] = Vector3.new(-2, -14, -1)
			},
			{
				["t"] = 0.245,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.1, -0.06, 0.005),
				["rot"] = Vector3.new(3, -6, 3)
			},
			{
				["t"] = 0.335,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.018, -0.018, 0.004),
				["rot"] = Vector3.new(1.5, 2, -1.5)
			},
			{
				["t"] = 0.47,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["bash2"] = {
		["contact"] = 0.09,
		["release"] = 0.47,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.05,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, -0.055, 0.05),
				["rot"] = Vector3.new(11, -26, -3)
			},
			{
				["t"] = 0.07,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.13, -0.046, 0.015),
				["rot"] = Vector3.new(2, -23, 1)
			},
			{
				["t"] = 0.09,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.3, 0.05, -0.02),
				["rot"] = Vector3.new(-7, -20, 5)
			},
			{
				["t"] = 0.11,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.33, 0.065, -0.07),
				["rot"] = Vector3.new(-10, -16, 7)
			},
			{
				["t"] = 0.16,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.25, 0.01, -0.03),
				["rot"] = Vector3.new(-2, -15, 4)
			},
			{
				["t"] = 0.245,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.11, -0.075, 0.005),
				["rot"] = Vector3.new(3, -6, -1)
			},
			{
				["t"] = 0.335,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.015, -0.02, 0.004),
				["rot"] = Vector3.new(1.5, 2, 1)
			},
			{
				["t"] = 0.47,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["block_in"] = {
		["contact"] = 0,
		["release"] = 0.24,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.035,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.06, -0.07, 0.02),
				["rot"] = Vector3.new(-6, 14, 8)
			},
			{
				["t"] = 0.08,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.004, 0.011, -0.004),
				["rot"] = Vector3.new(-4, -3, -4)
			},
			{
				["t"] = 0.15,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.002, -0.005, 0.002),
				["rot"] = Vector3.new(1, 1, 1)
			},
			{
				["t"] = 0.24,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["block_out"] = {
		["contact"] = 0,
		["release"] = 0.26,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.05,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.01, 0.015, 0),
				["rot"] = Vector3.new(-2, 0, -1)
			},
			{
				["t"] = 0.13,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.024, -0.04, 0.008),
				["rot"] = Vector3.new(3.2, -4.8, 4)
			},
			{
				["t"] = 0.19,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.004, 0.008, 0),
				["rot"] = Vector3.new(-1, 1, -1)
			},
			{
				["t"] = 0.26,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["block_hit"] = {
		["contact"] = 0,
		["release"] = 0.3,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.025,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, -0.016, 0.024),
				["rot"] = Vector3.new(6, -2, -5)
			},
			{
				["t"] = 0.06,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.006, -0.01, 0.014),
				["rot"] = Vector3.new(3.5, -1, -3)
			},
			{
				["t"] = 0.14,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.001, 0.004, -0.005),
				["rot"] = Vector3.new(-1.5, 0.5, 1)
			},
			{
				["t"] = 0.3,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = {
		["contact"] = 0,
		["release"] = 0.38,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.09,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, -0.06, 0),
				["rot"] = Vector3.new(-6, -20, -6)
			},
			{
				["t"] = 0.18,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.015, 0.02, 0),
				["rot"] = Vector3.new(3, 6, 3)
			},
			{
				["t"] = 0.27,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.004, -0.006, 0),
				["rot"] = Vector3.new(-1, -1.5, -0.5)
			},
			{
				["t"] = 0.38,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	}
}
local v189 = {
	["fire"] = {
		["contact"] = 0,
		["release"] = 0.5,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0, "muzzle" },
			{ 0, "pan" }
		},
		["keys"] = {
			{
				["t"] = 0.016,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.004, 0.032, 0.2),
				["rot"] = Vector3.new(19, -4, -12)
			},
			{
				["t"] = 0.045,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.004, 0.03, 0.19),
				["rot"] = Vector3.new(18, -4, -12)
			},
			{
				["t"] = 0.12,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.006, 0.04),
				["rot"] = Vector3.new(4, -1, -3)
			},
			{
				["t"] = 0.2,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.01, -0.012),
				["rot"] = Vector3.new(-3, 0, 1.5)
			},
			{
				["t"] = 0.34,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.001, 0.001),
				["rot"] = Vector3.new(0.4, 0, -0.1)
			},
			{
				["t"] = 0.5,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["reload"] = {
		["contact"] = 0,
		["release"] = 1.64,
		["span"] = 1.5,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.1, "half" },
			{
				0.14,
				"beat",
				"Musket_Ramrod",
				0.85
			},
			{
				0.26,
				"prime",
				"Gun_Cock",
				1.25
			},
			{ 0.34, "powder" },
			{ 0.56, "powder" },
			{ 0.95, "puff", "Musket_Ramrod_Tap" },
			{ 1.5, "click", "Gun_Cock" }
		},
		["keys"] = {
			{
				["t"] = 0.14,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.06, 0.035),
				["rot"] = Vector3.new(50, -5, 4)
			},
			{
				["t"] = 0.22,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.072, 0.035),
				["rot"] = Vector3.new(55, -6, 7)
			},
			{
				["t"] = 0.34,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.06, 0.035),
				["rot"] = Vector3.new(52, -5, 14)
			},
			{
				["t"] = 0.45,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.075, 0.035),
				["rot"] = Vector3.new(54, -5, -2)
			},
			{
				["t"] = 0.56,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.062, 0.035),
				["rot"] = Vector3.new(52, -5, 13)
			},
			{
				["t"] = 0.68,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.07, 0.035),
				["rot"] = Vector3.new(53, -5, -1)
			},
			{
				["t"] = 0.78,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.068, 0.035),
				["rot"] = Vector3.new(53, -5, 5)
			},
			{
				["t"] = 0.88,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.095, 0.035),
				["rot"] = Vector3.new(58, -5, 5)
			},
			{
				["t"] = 0.95,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.045, 0.035),
				["rot"] = Vector3.new(50, -5, 5)
			},
			{
				["t"] = 1.06,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.07, 0.035),
				["rot"] = Vector3.new(53, -5, 5)
			},
			{
				["t"] = 1.26,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, -0.035, 0.02),
				["rot"] = Vector3.new(-7, -3, -4)
			},
			{
				["t"] = 1.4,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.005, 0, 0.005),
				["rot"] = Vector3.new(-1, 0, 12)
			},
			{
				["t"] = 1.46,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.004, 0),
				["rot"] = Vector3.new(-1.5, 0, 10)
			},
			{
				["t"] = 1.5,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.016, 0.016),
				["rot"] = Vector3.new(5, 0, -4)
			},
			{
				["t"] = 1.64,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = {
		["contact"] = 0,
		["release"] = 0.46,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.34, "click", "Equip_Gun" }
		},
		["keys"] = {
			{
				["t"] = 0.08,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, -0.12, 0.04),
				["rot"] = Vector3.new(-28, -10, -42)
			},
			{
				["t"] = 0.18,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.035, 0),
				["rot"] = Vector3.new(8, 2, 8)
			},
			{
				["t"] = 0.28,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.009, 0),
				["rot"] = Vector3.new(-1.8, 0, -1.4)
			},
			{
				["t"] = 0.34,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.006, 0.006),
				["rot"] = Vector3.new(2.5, 0, -2)
			},
			{
				["t"] = 0.46,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	}
}
local v190 = {
	["fire"] = {
		["contact"] = 0,
		["release"] = 0.36,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0, "twang" }
		},
		["keys"] = {
			{
				["t"] = 0.016,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.01, 0.06),
				["rot"] = Vector3.new(8, -1, -3)
			},
			{
				["t"] = 0.05,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.007, 0.035),
				["rot"] = Vector3.new(4.5, -0.5, -1.5)
			},
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.003, -0.006),
				["rot"] = Vector3.new(-1.4, 0, 0.5)
			},
			{
				["t"] = 0.2,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.0005, 0.001),
				["rot"] = Vector3.new(0.2, 0, 0)
			},
			{
				["t"] = 0.36,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["reload"] = {
		["contact"] = 0,
		["release"] = 1.6,
		["span"] = 1.5,
		["fx"] = nil,
		["string"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.22, "beat", "Crossbow_Crank" },
			{ 1, "click", "Gun_Cock" },
			{ 1.3, "bolt", "Crossbow_Ready" },
			{ 1.45, "glint" }
		},
		["string"] = {
			{ 0, 1 },
			{ 0.22, 1 },
			{ 0.62, 0.15 },
			{ 0.94, 0.06 },
			{ 0.975, 0.06 },
			{ 1, 0 }
		},
		["keys"] = {
			{
				["t"] = 0.14,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.1, 0.02),
				["rot"] = Vector3.new(-40, 2, 5.5)
			},
			{
				["t"] = 0.22,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.11, 0.02),
				["rot"] = Vector3.new(-44, 2, 3.5)
			},
			{
				["t"] = 0.42,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.104, 0.045),
				["rot"] = Vector3.new(-40, 2, 4.5)
			},
			{
				["t"] = 0.62,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.094, 0.07),
				["rot"] = Vector3.new(-35, 2, 6.5)
			},
			{
				["t"] = 0.66,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.004, -0.091, 0.074),
				["rot"] = Vector3.new(-33.5, 2, 4.5)
			},
			{
				["t"] = 0.7,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.004, -0.09, 0.078),
				["rot"] = Vector3.new(-33, 2, 8.5)
			},
			{
				["t"] = 0.74,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.004, -0.089, 0.08),
				["rot"] = Vector3.new(-32.5, 2, 4.5)
			},
			{
				["t"] = 0.78,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.004, -0.088, 0.082),
				["rot"] = Vector3.new(-32, 2, 8.5)
			},
			{
				["t"] = 0.82,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.004, -0.087, 0.085),
				["rot"] = Vector3.new(-31.5, 2, 4.5)
			},
			{
				["t"] = 0.86,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.004, -0.086, 0.088),
				["rot"] = Vector3.new(-31, 2, 8.5)
			},
			{
				["t"] = 0.9,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.004, -0.0855, 0.09),
				["rot"] = Vector3.new(-30.5, 2, 4.5)
			},
			{
				["t"] = 0.94,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.003, -0.085, 0.092),
				["rot"] = Vector3.new(-30, 2, 8.5)
			},
			{
				["t"] = 0.975,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.086, 0.092),
				["rot"] = Vector3.new(-30, 2, 6.5)
			},
			{
				["t"] = 1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.115, 0.068),
				["rot"] = Vector3.new(-39, 2, 3.5)
			},
			{
				["t"] = 1.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.102, 0.064),
				["rot"] = Vector3.new(-35, 2, 5.5)
			},
			{
				["t"] = 1.26,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.03, 0.03),
				["rot"] = Vector3.new(-14, 3, -5)
			},
			{
				["t"] = 1.3,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.04, 0.03),
				["rot"] = Vector3.new(-17, 3, -5)
			},
			{
				["t"] = 1.42,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.012, -0.006),
				["rot"] = Vector3.new(4, -1, 1.5)
			},
			{
				["t"] = 1.51,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.003, 0),
				["rot"] = Vector3.new(-1, 0, -0.5)
			},
			{
				["t"] = 1.6,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = {
		["contact"] = 0,
		["release"] = 0.43,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.31, "click", "Crossbow_Ready" }
		},
		["keys"] = {
			{
				["t"] = 0.08,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, -0.12, 0.04),
				["rot"] = Vector3.new(-25, -8, -40)
			},
			{
				["t"] = 0.17,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.025, 0),
				["rot"] = Vector3.new(6, 2, 8)
			},
			{
				["t"] = 0.27,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.006, 0),
				["rot"] = Vector3.new(-1.4, 0, -1)
			},
			{
				["t"] = 0.31,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.004, 0.004),
				["rot"] = Vector3.new(2, 0, -1.5)
			},
			{
				["t"] = 0.43,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	}
}
for v191, v192 in v29.lunge.keys do
	local v193 = table.clone(v192)
	if v193.tip and (v193.edge and v193.t >= 0.17) then
		v193.tip = v182:VectorToWorldSpace(v193.tip)
		v193.edge = v182:VectorToWorldSpace(v193.edge)
	end
	v183[v191] = v193
end
local v194 = table.clone(v29.lunge)
v194.keys = v183
v29.lunge_c = v194
local v195 = {
	["windup"] = {
		["contact"] = 0,
		["release"] = 0.2,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.02, 0.05),
				["rot"] = Vector3.new(6, -2, -2)
			},
			{
				["t"] = 0.2,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["throw"] = {
		["contact"] = 0,
		["release"] = 0.3,
		["vanish"] = 0.055,
		["smear"] = nil,
		["keys"] = nil,
		["smear"] = { 0, 0.06 },
		["keys"] = {
			{
				["t"] = 0.05,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.12, 0.025, -0.46),
				["rot"] = Vector3.new(-8, 8, 0)
			},
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.13, 0.025, -0.48),
				["rot"] = Vector3.new(-8, 8, 0)
			},
			{
				["t"] = 0.3,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["redraw"] = {
		["contact"] = 0,
		["release"] = 0.36,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.16, "beat", "Equip_Item" }
		},
		["keys"] = {
			{
				["t"] = 0.16,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.02, 0),
				["rot"] = Vector3.new(3, 0, 4)
			},
			{
				["t"] = 0.26,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.008, 0),
				["rot"] = Vector3.new(-1.2, 0, -1.2)
			},
			{
				["t"] = 0.36,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = v185.draw
}
local v196 = {
	["windup"] = {
		["contact"] = 0,
		["release"] = 0.24,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.12,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.02, 0.1),
				["rot"] = Vector3.new(8, -2, -3)
			},
			{
				["t"] = 0.24,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["throw"] = {
		["contact"] = 0,
		["release"] = 0.34,
		["vanish"] = 0.06,
		["smear"] = nil,
		["keys"] = nil,
		["smear"] = { 0, 0.065 },
		["keys"] = {
			{
				["t"] = 0.055,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.17, 0.02, -0.52),
				["rot"] = Vector3.new(-12, 9, 0)
			},
			{
				["t"] = 0.11,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.18, 0.02, -0.54),
				["rot"] = Vector3.new(-12, 9, 0)
			},
			{
				["t"] = 0.34,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["redraw"] = v195.redraw,
	["draw"] = v195.draw
}
local v197 = require(script.Parent:WaitForChild("BladeClips"))
local function v208(p198, p199, p200, p201, p202, p203, p204, p205, p206, p207) -- name: B
	return {
		["t"] = p198,
		["pos"] = Vector3.new(p199, p200, p201),
		["tip"] = Vector3.new(p202, p203, p204),
		["edge"] = Vector3.new(p205, p206, p207)
	}
end
local function v217(p209, p210, p211, p212) -- name: lift
	local v213 = {}
	for v214, v215 in p209 do
		local v216 = table.clone(v215)
		if p211 <= v214 and (v214 <= p212 and v216.pos) then
			v216.pos = v216.pos + Vector3.new(0, p210, 0)
		end
		v213[v214] = v216
	end
	return v213
end
local v218 = v197.SWORD
local v219 = {
	["slash_r"] = {
		["contact"] = v218.slash_r.contact,
		["release"] = v218.slash_r.release,
		["smear"] = v218.slash_r.smear,
		["keys"] = v217(v217(v217(v218.slash_r.keys, 0.08, 2, 4), -0.07, 5, 6), -0.09, 6, 6)
	},
	["slash_l"] = {
		["contact"] = 0.09,
		["release"] = 0.54,
		["smear"] = nil,
		["keys"] = nil,
		["smear"] = { 0.04, 0.15 },
		["keys"] = {
			{
				["t"] = 0.03,
				["pos"] = nil,
				["tip"] = nil,
				["edge"] = nil,
				["pos"] = Vector3.new(-0.66, -0.83, -0.46),
				["tip"] = Vector3.new(-0.45, 0.8, -0.4),
				["edge"] = Vector3.new(-0.1, 0, -1)
			},
			v218.slash_l.keys[2],
			v218.slash_l.keys[3],
			v218.slash_l.keys[4],
			v218.slash_l.keys[5],
			v208(0.31, 0.92, -0.62, -0.46, 0.5, -0.7, -0.5, 0.5, 0, 0.866),
			{
				["t"] = 0.44,
				["rest"] = nil,
				["rest"] = Vector3.new(0, 0.025, 0)
			},
			{
				["t"] = 0.54,
				["rest"] = nil,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["rise"] = {
		["contact"] = 0.09,
		["release"] = 0.56,
		["smear"] = nil,
		["keys"] = nil,
		["smear"] = { 0.045, 0.17 },
		["keys"] = {
			v208(0.035, -0.3, -0.56, -0.5, -0.545, -0.784, 0.297, -0.57, 0.087, -0.817),
			v208(0.065, -0.16, -0.32, -0.5, -0.52, -0.1, -0.85, 0.3, 0.9, -0.3),
			v208(0.09, 0.02, -0.1, -0.5, -0.35, 0.35, -0.869, 0.707, 0.707, 0),
			v208(0.125, 0.3, 0.14, -0.5, 0.2, 0.75, -0.63, 0.75, 0.25, 0.6),
			v208(0.165, 0.6, 0.42, -0.5, 0.493, 0.789, -0.367, 0.616, -0.018, 0.788),
			v208(0.24, 0.7, 0.5, -0.48, 0.774, 0.593, 0.225, 0.155, -0.521, 0.84),
			v208(0.32, 0.76, 0.6, -0.48, 0.79, 0.58, 0.2, 0.15, -0.52, 0.84),
			{
				["t"] = 0.45,
				["rest"] = nil,
				["rest"] = Vector3.new(0, -0.025, 0)
			},
			{
				["t"] = 0.56,
				["rest"] = nil,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["finisher"] = {
		["contact"] = 0.09,
		["release"] = 0.61,
		["smear"] = nil,
		["keys"] = nil,
		["smear"] = { 0.04, 0.16 },
		["keys"] = {
			v208(0.03, 0.52, 0.5, -0.5, 0.757, 0.636, 0.151, -0.222, 0.467, -0.856),
			v208(0.058, 0.4, 0.36, -0.5, 0.187, 0.722, -0.666, -0.766, -0.317, -0.559),
			v218.finisher.keys[3],
			v218.finisher.keys[4],
			v218.finisher.keys[5],
			v218.finisher.keys[6],
			v218.finisher.keys[7],
			v218.finisher.keys[8]
		}
	},
	["parry_in"] = {
		["contact"] = 0,
		["release"] = 0.2,
		["keys"] = nil,
		["keys"] = {
			v208(0.03, 0.36, -0.27, -0.5, -0.1, 0.95, -0.3, -0.4, 0.2, -0.9),
			v208(0.085, 0.27, -0.19, -0.52, -0.92, 0.28, -0.27, 0.06, 0.35, -0.93),
			v208(0.12, 0.26, -0.18, -0.52, -0.93, 0.25, -0.26, 0.06, 0.33, -0.94),
			(v208(0.2, 0.266, -0.176, -0.52, -0.92, 0.29, -0.27, 0.06, 0.35, -0.93))
		}
	},
	["parry_hold"] = {
		["contact"] = 0,
		["release"] = 1,
		["keys"] = nil,
		["keys"] = { v208(0.5, 0.255, -0.187, -0.52, -0.92, 0.26, -0.28, 0.06, 0.34, -0.94), (v208(1, 0.266, -0.176, -0.52, -0.92, 0.29, -0.27, 0.06, 0.35, -0.93)) }
	},
	["parry_out"] = {
		["contact"] = 0,
		["release"] = 0.23,
		["keys"] = nil,
		["keys"] = {
			v208(0.04, 0.37, -0.36, -0.51, -0.42, 0.3, -0.86, 0.91, 0.157, -0.378),
			{
				["t"] = 0.16,
				["rest"] = nil,
				["rest"] = Vector3.new(0, 0.02, 0)
			},
			{
				["t"] = 0.23,
				["rest"] = nil,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["parry_hit"] = {
		["contact"] = 0,
		["release"] = 0.41,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0, "block_spark", "Katana_Parry" },
			{ 0.02, "glint" }
		},
		["keys"] = {
			v208(0.035, 0.28, -0.21, -0.5, -0.88, 0.34, -0.29, 0.08, 0.36, -0.93),
			v208(0.18, 0.26, -0.184, -0.52, -0.92, 0.27, -0.27, 0.06, 0.34, -0.94),
			v208(0.23, 0.37, -0.36, -0.51, -0.42, 0.3, -0.86, 0.91, 0.157, -0.378),
			{
				["t"] = 0.34,
				["rest"] = nil,
				["rest"] = Vector3.new(0, 0.02, 0)
			},
			{
				["t"] = 0.41,
				["rest"] = nil,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = {
		["contact"] = 0,
		["release"] = 0.44,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.15, "glint" }
		},
		["keys"] = {
			v208(0.05, -0.08, -0.6, -0.5, -0.95, 0.12, -0.28, 0, 1, -0.1),
			v208(0.15, 0.32, -0.38, -0.52, 0.25, 0.55, -0.8, -0.8, 0.3, -0.52),
			{
				["t"] = 0.24,
				["rest"] = nil,
				["rest"] = Vector3.new(0, 0.03, 0)
			},
			{
				["t"] = 0.34,
				["rest"] = nil,
				["rest"] = Vector3.new(0, -0.006, 0)
			},
			{
				["t"] = 0.44,
				["rest"] = nil,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	}
}
local v220 = {
	v13(0.024, 0.44, 0.04, -0.46, -0.347, 0.905, -0.248, -0.132, -0.309, -0.942),
	v13(0.046, 0.33, 0.43, -0.46, 0.317, 0.766, -0.559, -0.722, -0.187, -0.666),
	v13(0.07, 0.06, -0.06, -0.46, -0.35, 0.35, -0.869, -0.707, -0.707, 0),
	v13(0.115, -0.49, -0.43, -0.46, -0.78, -0.379, -0.499, -0.119, -0.692, 0.712),
	v13(0.175, -0.57, -0.57, -0.42, -0.636, -0.757, 0.151, 0.467, -0.222, 0.856),
	v13(0.245, 0.2, -0.61, -0.44, -0.2, 0.85, -0.5, -0.6, 0, -0.8),
	{
		["t"] = 0.315,
		["rest"] = nil,
		["rest"] = Vector3.new(0, 0.02, 0)
	},
	{
		["t"] = 0.395,
		["rest"] = Vector3.new(0, 0, 0)
	}
}
local v221 = {
	v13(0.03, -0.2, -0.43, -0.46, -0.545, -0.784, 0.297, -0.57, 0.087, -0.817),
	v13(0.07, 0.02, -0.08, -0.46, -0.35, 0.35, -0.869, 0.707, 0.707, 0),
	v13(0.11, 0.51, 0.35, -0.46, 0.493, 0.789, -0.367, 0.616, -0.018, 0.788),
	v13(0.17, 0.63, 0.45, -0.44, 0.774, 0.593, 0.225, 0.155, -0.521, 0.84),
	{
		["t"] = 0.26,
		["rest"] = nil,
		["rest"] = Vector3.new(0, 0.01, 0)
	},
	{
		["t"] = 0.34,
		["rest"] = Vector3.new(0, 0, 0)
	}
}
local function v223(p222) -- name: hold
	return {
		{
			["t"] = 0.05,
			["rest"] = nil,
			["rot"] = nil,
			["rest"] = Vector3.new(0.02, 0.015, 0.04),
			["rot"] = Vector3.new(8, -2, -4)
		},
		{
			["t"] = 0.16,
			["rest"] = nil,
			["rot"] = nil,
			["rest"] = Vector3.new(0.022, 0.016, 0.042),
			["rot"] = Vector3.new(8, -2, -4)
		},
		{
			["t"] = nil,
			["rest"] = Vector3.new(0, 0, 0),
			["t"] = p222
		}
	}
end
local v224 = {
	["chop_r"] = {
		["contact"] = 0.06,
		["release"] = 0.395,
		["smear"] = nil,
		["keys"] = nil,
		["left"] = nil,
		["smear"] = { 0.045, 0.125 },
		["keys"] = v220,
		["left"] = v223(0.395)
	},
	["chop_l"] = {
		["contact"] = 0.06,
		["release"] = 0.395,
		["smear"] = nil,
		["smearLeft"] = true,
		["keys"] = nil,
		["left"] = nil,
		["smear"] = { 0.045, 0.125 },
		["keys"] = v223(0.395),
		["left"] = v220
	},
	["double"] = {
		["contact"] = 0.06,
		["release"] = 0.42,
		["smear"] = nil,
		["fx"] = nil,
		["keys"] = nil,
		["left"] = nil,
		["smear"] = { 0.045, 0.125 },
		["fx"] = {
			{ 0.07, "flare" }
		},
		["keys"] = v221,
		["left"] = v220
	},
	["one_r"] = {
		["contact"] = 0.06,
		["release"] = 0.395,
		["smear"] = nil,
		["keys"] = nil,
		["smear"] = { 0.045, 0.125 },
		["keys"] = v220
	},
	["one_b"] = {
		["contact"] = 0.06,
		["release"] = 0.34,
		["smear"] = nil,
		["keys"] = nil,
		["smear"] = { 0.035, 0.12 },
		["keys"] = v221
	},
	["throw"] = {
		["contact"] = 0,
		["release"] = 0.36,
		["vanishLeft"] = 0.08,
		["smear"] = nil,
		["smearLeft"] = true,
		["keys"] = nil,
		["left"] = nil,
		["smear"] = { 0.05, 0.08 },
		["keys"] = {
			{
				["t"] = 0.06,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.012, -0.01, 0.02),
				["rot"] = Vector3.new(-4, 0, 2)
			},
			{
				["t"] = 0.18,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.004, 0.006, 0),
				["rot"] = Vector3.new(1, 0, 0)
			},
			{
				["t"] = 0.36,
				["rest"] = Vector3.new(0, 0, 0)
			}
		},
		["left"] = {
			{
				["t"] = 0.05,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.07, 0.11, 0.1),
				["rot"] = Vector3.new(48, -12, 22)
			},
			{
				["t"] = 0.07,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.08, 0.13, -0.2),
				["rot"] = Vector3.new(-20, 12, 12)
			},
			{
				["t"] = 0.08,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.17, 0.1, -0.33),
				["rot"] = Vector3.new(-48, 16, 8)
			},
			{
				["t"] = 0.12,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.3, 0.06, -0.55),
				["rot"] = Vector3.new(-70, 20, 6)
			},
			{
				["t"] = 0.36,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = {
		["contact"] = 0,
		["release"] = 0.37,
		["fx"] = nil,
		["keys"] = nil,
		["left"] = nil,
		["fx"] = {
			{ 0.14, "beat", "Hatchet_Catch" }
		},
		["keys"] = {
			{
				["t"] = 0.02,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.18, -0.45, 0.03),
				["rot"] = Vector3.new(-150, 0, -25)
			},
			{
				["t"] = 0.04,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.14, -0.18, 0.02),
				["rot"] = Vector3.new(-240, 0, -16)
			},
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.05, -0.02, 0.01),
				["rot"] = Vector3.new(-340, 0, -4)
			},
			{
				["t"] = 0.14,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.035, 0),
				["rot"] = Vector3.new(-362, 0, 4)
			},
			{
				["t"] = 0.21,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.018, 0),
				["rot"] = Vector3.new(-361, 0, -2)
			},
			{
				["t"] = 0.28,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.005, 0),
				["rot"] = Vector3.new(-359, 0, 0)
			},
			{
				["t"] = 0.37,
				["rest"] = Vector3.new(0, 0, 0)
			}
		},
		["left"] = {
			{
				["t"] = 0.02,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.18, -0.45, 0.03),
				["rot"] = Vector3.new(-150, 0, -25)
			},
			{
				["t"] = 0.04,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.14, -0.18, 0.02),
				["rot"] = Vector3.new(-240, 0, -16)
			},
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.05, -0.02, 0.01),
				["rot"] = Vector3.new(-340, 0, -4)
			},
			{
				["t"] = 0.14,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.035, 0),
				["rot"] = Vector3.new(-362, 0, 4)
			},
			{
				["t"] = 0.21,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.018, 0),
				["rot"] = Vector3.new(-361, 0, -2)
			},
			{
				["t"] = 0.28,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.005, 0),
				["rot"] = Vector3.new(-359, 0, 0)
			},
			{
				["t"] = 0.37,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	}
}
local v225 = {
	["drawFrom"] = {
		["rest"] = Vector3.new(0.04, -0.52, 0.04),
		["rot"] = Vector3.new(-30, -20, -20)
	},
	["draw"] = {
		["contact"] = 0,
		["release"] = 0.42,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.25, "beat", "Equip_Item" }
		},
		["keys"] = {
			{
				["t"] = 0.09,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.01, 0.085, 0.02),
				["rot"] = Vector3.new(100, -5, 0)
			},
			{
				["t"] = 0.17,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.11, 0.02),
				["rot"] = Vector3.new(215, 0, 5)
			},
			{
				["t"] = 0.25,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.035, 0),
				["rot"] = Vector3.new(345, 0, -3)
			},
			{
				["t"] = 0.33,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.008, 0),
				["rot"] = Vector3.new(362, 0, 1)
			},
			{
				["t"] = 0.42,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["throw"] = {
		["contact"] = 0,
		["release"] = 0.32,
		["vanish"] = 0.03,
		["smear"] = nil,
		["keys"] = nil,
		["smear"] = { 0, 0.04 },
		["keys"] = {
			{
				["t"] = 0.03,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.2, 0.15, -0.34),
				["rot"] = Vector3.new(-50, 10, 12)
			},
			{
				["t"] = 0.065,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.48, 0.24, -0.72),
				["rot"] = Vector3.new(-78, 12, 14)
			},
			{
				["t"] = 0.32,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	}
}
v225.redraw = v225.draw
local v226 = {
	["windup"] = {
		["contact"] = 0,
		["release"] = 0.2,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.02, 0.03, 0.04),
				["rot"] = Vector3.new(10, -2, -4)
			},
			{
				["t"] = 0.2,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["throw"] = {
		["contact"] = 0,
		["release"] = 0.32,
		["vanish"] = 0.06,
		["smear"] = nil,
		["keys"] = nil,
		["smear"] = { 0, 0.07 },
		["keys"] = {
			{
				["t"] = 0.04,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.2, 0.16, -0.36),
				["rot"] = Vector3.new(-52, 10, 12)
			},
			{
				["t"] = 0.08,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.36, 0.22, -0.6),
				["rot"] = Vector3.new(-70, 12, 14)
			},
			{
				["t"] = 0.32,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["redraw"] = {
		["contact"] = 0,
		["release"] = 0.34,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.14, "beat", "Equip_Item" }
		},
		["keys"] = {
			{
				["t"] = 0.14,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.025, 0),
				["rot"] = Vector3.new(5, 0, 5)
			},
			{
				["t"] = 0.24,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.006, 0),
				["rot"] = Vector3.new(-1, 0, -1)
			},
			{
				["t"] = 0.34,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = {
		["contact"] = 0,
		["release"] = 0.36,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.15,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.025, 0),
				["rot"] = Vector3.new(5, 0, 5)
			},
			{
				["t"] = 0.25,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.006, 0),
				["rot"] = Vector3.new(-1, 0, -1)
			},
			{
				["t"] = 0.36,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	}
}
local v227 = {
	["use_in"] = {
		["contact"] = 0,
		["release"] = 0.2,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.02, 0.012, 0.02),
				["rot"] = Vector3.new(6, 4, 4)
			},
			{
				["t"] = 0.2,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["use_loop"] = {
		["contact"] = 0,
		["release"] = 0.2,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.075, "crumbs", "Herbs_Chew" }
		},
		["keys"] = {
			{
				["t"] = 0.05,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.006, 0.04),
				["rot"] = Vector3.new(8, 0, 3)
			},
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.025, -0.02),
				["rot"] = Vector3.new(-10, 0, -3)
			},
			{
				["t"] = 0.15,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.004, 0),
				["rot"] = Vector3.new(1, 0, 0)
			},
			{
				["t"] = 0.2,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["use_done"] = {
		["contact"] = 0,
		["release"] = 0.38,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.02, "sparkle" }
		},
		["keys"] = {
			{
				["t"] = 0.08,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.02, 0),
				["rot"] = Vector3.new(6, 0, 3)
			},
			{
				["t"] = 0.22,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.008, 0),
				["rot"] = Vector3.new(-1.5, 0, -0.8)
			},
			{
				["t"] = 0.38,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = v226.draw
}
local v228 = {
	["use_in"] = {
		["contact"] = 0,
		["release"] = 0.2,
		["eyeRoll"] = true,
		["strip"] = nil,
		["keys"] = nil,
		["strip"] = {
			{ 0, 0.25 },
			{ 0.2, 1 }
		},
		["keys"] = {
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, -0.03, 0),
				["rot"] = Vector3.new(6, 4, 180)
			},
			{
				["t"] = 0.2,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0, 0),
				["rot"] = Vector3.new(0, 0, 360)
			}
		}
	},
	["use_loop"] = {
		["contact"] = 0,
		["release"] = 0.25,
		["fx"] = nil,
		["strip"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.04, "beat", "Bandage_Wrap" }
		},
		["strip"] = {
			{ 0, 1 },
			{ 0.04, 1.15 },
			{ 0.25, 1 }
		},
		["keys"] = {
			{
				["t"] = 0.04,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, -0.02, 0),
				["rot"] = Vector3.new(0, 0, -6)
			},
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.004, 0.003, 0),
				["rot"] = Vector3.new(0, 0, -1)
			},
			{
				["t"] = 0.17,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.012, 0.01, 0.01),
				["rot"] = Vector3.new(3, 0, 4)
			},
			{
				["t"] = 0.25,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["use_done"] = {
		["contact"] = 0,
		["release"] = 0.4,
		["fx"] = nil,
		["strip"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.06, "sparkle" }
		},
		["strip"] = {
			{ 0, 1 },
			{ 0.03, 0.8 },
			{ 0.4, 0.25 }
		},
		["keys"] = {
			{
				["t"] = 0.03,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.03, -0.02, 0),
				["rot"] = Vector3.new(0, 0, -8)
			},
			{
				["t"] = 0.12,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.02, 0),
				["rot"] = Vector3.new(6, 0, 3)
			},
			{
				["t"] = 0.25,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.008, 0),
				["rot"] = Vector3.new(-1.5, 0, -0.8)
			},
			{
				["t"] = 0.4,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = v226.draw
}
local v229 = {
	["use_in"] = {
		["contact"] = 0,
		["release"] = 0.24,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.2, "ring" }
		},
		["keys"] = {
			{
				["t"] = 0.1,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, -0.012, 0.03),
				["rot"] = Vector3.new(-4, 0, -2)
			},
			{
				["t"] = 0.18,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.01, -0.01),
				["rot"] = Vector3.new(14, 0, 3)
			},
			{
				["t"] = 0.24,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["use_loop"] = {
		["contact"] = 0,
		["release"] = 0.214,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.07, "ring" }
		},
		["keys"] = {
			{
				["t"] = 0.036,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.0015, 0.003, 0),
				["rot"] = Vector3.new(13.8, 0, 0.9)
			},
			{
				["t"] = 0.071,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.0015, -0.001, 0),
				["rot"] = Vector3.new(13.2, 0, -0.8)
			},
			{
				["t"] = 0.107,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.0015, 0.0025, 0),
				["rot"] = Vector3.new(13.8, 0, 0.7)
			},
			{
				["t"] = 0.143,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.0015, -0.001, 0),
				["rot"] = Vector3.new(13.2, 0, -0.8)
			},
			{
				["t"] = 0.179,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.0015, 0.003, 0),
				["rot"] = Vector3.new(13.8, 0, 0.9)
			},
			{
				["t"] = 0.214,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.001, 0),
				["rot"] = Vector3.new(13.4, 0, 0)
			}
		}
	},
	["use_done"] = {
		["contact"] = 0,
		["release"] = 0.34,
		["keys"] = nil,
		["keys"] = {
			{
				["t"] = 0.12,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0, 0.012, 0),
				["rot"] = Vector3.new(4, 0, 2)
			},
			{
				["t"] = 0.34,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["draw"] = v226.draw
}
local v230 = {
	["place"] = {
		["contact"] = 0,
		["release"] = 0.34,
		["vanish"] = 0.2,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.19, "dust", "Trap_Set" }
		},
		["keys"] = {
			{
				["t"] = 0.07,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.01, 0.085, 0),
				["rot"] = Vector3.new(10, 0, -3)
			},
			{
				["t"] = 0.15,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.04, -0.2, -0.14),
				["rot"] = Vector3.new(20, 0, 2)
			},
			{
				["t"] = 0.22,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.09, -0.36, -0.2),
				["rot"] = Vector3.new(30, 0, 2)
			},
			{
				["t"] = 0.34,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["redraw"] = v226.redraw,
	["draw"] = v226.draw
}
local v231 = {
	["place"] = {
		["contact"] = 0,
		["release"] = 0.4,
		["vanish"] = 0.2,
		["fx"] = nil,
		["keys"] = nil,
		["fx"] = {
			{ 0.2, "dust", "Impact_Wood" }
		},
		["keys"] = {
			{
				["t"] = 0.12,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(0.01, 0.06, 0.05),
				["rot"] = Vector3.new(18, 0, -4)
			},
			{
				["t"] = 0.2,
				["rest"] = nil,
				["rot"] = nil,
				["rest"] = Vector3.new(-0.03, -0.38, -0.12),
				["rot"] = Vector3.new(-10, 0, 0)
			},
			{
				["t"] = 0.4,
				["rest"] = Vector3.new(0, 0, 0)
			}
		}
	},
	["redraw"] = v226.redraw,
	["draw"] = v226.draw
}
v_u_184.SETS = {
	["Musket"] = v186,
	["Blunderbuss"] = v189,
	["Pistol"] = v187,
	["Crossbow"] = v190,
	["Bow"] = v1,
	["Axe"] = v14,
	["Club"] = v15,
	["Spear"] = v185,
	["Shield"] = v188,
	["Knives"] = {
		["throw"] = {
			["contact"] = 0,
			["release"] = 0.18,
			["vanish"] = 0.05,
			["smear"] = nil,
			["keys"] = nil,
			["smear"] = { 0.015, 0.06 },
			["keys"] = {
				{
					["t"] = 0.02,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.02, 0.035, 0.05),
					["rot"] = Vector3.new(22, -2, -10)
				},
				{
					["t"] = 0.05,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(-0.16, 0.1, -0.3),
					["rot"] = Vector3.new(-60, 14, 12)
				},
				{
					["t"] = 0.1,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(-0.17, 0.08, -0.32),
					["rot"] = Vector3.new(-70, 14, 12)
				},
				{
					["t"] = 0.18,
					["rest"] = Vector3.new(0, 0, 0)
				}
			}
		},
		["throw2"] = {
			["contact"] = 0,
			["release"] = 0.18,
			["vanish"] = 0.05,
			["smear"] = nil,
			["keys"] = nil,
			["smear"] = { 0.015, 0.06 },
			["keys"] = {
				{
					["t"] = 0.02,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.025, 0.03, 0.05),
					["rot"] = Vector3.new(18, -6, 2)
				},
				{
					["t"] = 0.05,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(-0.2, 0.05, -0.3),
					["rot"] = Vector3.new(-52, 24, -14)
				},
				{
					["t"] = 0.1,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(-0.21, 0.04, -0.32),
					["rot"] = Vector3.new(-60, 24, -14)
				},
				{
					["t"] = 0.18,
					["rest"] = Vector3.new(0, 0, 0)
				}
			}
		},
		["redraw"] = {
			["contact"] = 0,
			["release"] = 0.18,
			["eyeRoll"] = true,
			["pivot"] = 0.12,
			["fx"] = nil,
			["keys"] = nil,
			["fx"] = {
				{ 0.15, "beat", "Knife_Ready" }
			},
			["keys"] = {
				{
					["t"] = 0.05,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.02, -0.03, 0.02),
					["rot"] = Vector3.new(0, 0, 120)
				},
				{
					["t"] = 0.1,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.01, 0, 0.01),
					["rot"] = Vector3.new(0, 0, 240)
				},
				{
					["t"] = 0.15,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0, 0.012, 0),
					["rot"] = Vector3.new(0, 0, 362)
				},
				{
					["t"] = 0.18,
					["rest"] = Vector3.new(0, 0, 0)
				}
			}
		},
		["draw"] = {
			["contact"] = 0,
			["release"] = 0.34,
			["eyeRoll"] = true,
			["pivot"] = 0.12,
			["keys"] = nil,
			["keys"] = {
				{
					["t"] = 0.08,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.02, -0.12, 0.02),
					["rot"] = Vector3.new(0, 0, 120)
				},
				{
					["t"] = 0.16,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.01, -0.035, 0.01),
					["rot"] = Vector3.new(0, 0, 240)
				},
				{
					["t"] = 0.24,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0, 0.014, 0),
					["rot"] = Vector3.new(0, 0, 364)
				},
				{
					["t"] = 0.28,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0, 0.002, 0),
					["rot"] = Vector3.new(0, 0, 359)
				},
				{
					["t"] = 0.34,
					["rest"] = Vector3.new(0, 0, 0)
				}
			}
		}
	},
	["Javelin"] = v195,
	["Sling"] = {
		["throw"] = {
			["contact"] = 0,
			["release"] = 0.44,
			["loose"] = 0.033,
			["eyeRoll"] = true,
			["fx"] = nil,
			["keys"] = nil,
			["fx"] = {
				{ 0.41, "beat", "Equip_Item" }
			},
			["keys"] = {
				{
					["t"] = 0.033,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(-0.06, 0.06, -0.1),
					["rot"] = Vector3.new(-30, 6, 40)
				},
				{
					["t"] = 0.1,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(-0.03, 0.05, -0.03),
					["rot"] = Vector3.new(-10, 3, 120)
				},
				{
					["t"] = 0.18,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(-0.01, 0.04, 0),
					["rot"] = Vector3.new(-4, 0, 240)
				},
				{
					["t"] = 0.27,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0, 0.004, 0),
					["rot"] = Vector3.new(0, 0, 362)
				},
				{
					["t"] = 0.38,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0, -0.02, 0),
					["rot"] = Vector3.new(-4, 0, 360)
				},
				{
					["t"] = 0.44,
					["rest"] = Vector3.new(0, 0, 0)
				}
			}
		},
		["draw"] = {
			["contact"] = 0,
			["release"] = 0.38,
			["eyeRoll"] = true,
			["keys"] = nil,
			["keys"] = {
				{
					["t"] = 0.08,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.02, -0.1, 0.02),
					["rot"] = Vector3.new(0, 0, 150)
				},
				{
					["t"] = 0.18,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.01, 0.01, 0),
					["rot"] = Vector3.new(0, 0, 300)
				},
				{
					["t"] = 0.27,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0, 0.004, 0),
					["rot"] = Vector3.new(0, 0, 362)
				},
				{
					["t"] = 0.38,
					["rest"] = Vector3.new(0, 0, 0)
				}
			}
		}
	},
	["Bomb"] = v226,
	["Herbs"] = v227,
	["Horn"] = v229,
	["Trap"] = v230,
	["Gauntlets"] = v25,
	["Scythe"] = v29,
	["Katana"] = v219,
	["Hatchets"] = v224
}
v_u_184.ITEMS = {
	["longbow"] = v2,
	["bolas"] = {
		["drawFrom"] = {
			["rest"] = Vector3.new(0.04, -0.46, 0.04),
			["rot"] = Vector3.new(0, 0, 0)
		},
		["throw"] = {
			["contact"] = 0,
			["release"] = 0.3,
			["vanish"] = 0.07,
			["smear"] = nil,
			["eyeRoll"] = true,
			["keys"] = nil,
			["smear"] = { 0.02, 0.07 },
			["keys"] = {
				{
					["t"] = 0.025,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.02, 0.06, 0.02),
					["rot"] = Vector3.new(0, 0, 70)
				},
				{
					["t"] = 0.05,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(-0.05, 0.1, -0.08),
					["rot"] = Vector3.new(0, 0, 170)
				},
				{
					["t"] = 0.07,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(-0.14, 0.06, -0.2),
					["rot"] = Vector3.new(-10, 10, 230)
				},
				{
					["t"] = 0.3,
					["rest"] = Vector3.new(0, 0, 0)
				}
			}
		},
		["redraw"] = {
			["contact"] = 0,
			["release"] = 0.34,
			["keys"] = nil,
			["keys"] = {
				{
					["t"] = 0.14,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.01, 0.012, 0),
					["rot"] = Vector3.new(8, -6, 6)
				},
				{
					["t"] = 0.24,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0, -0.006, 0),
					["rot"] = Vector3.new(-2, 2, -1.5)
				},
				{
					["t"] = 0.34,
					["rest"] = Vector3.new(0, 0, 0)
				}
			}
		},
		["draw"] = {
			["contact"] = 0,
			["release"] = 0.38,
			["keys"] = nil,
			["keys"] = {
				{
					["t"] = 0.15,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.01, 0.012, 0),
					["rot"] = Vector3.new(8, -6, 6)
				},
				{
					["t"] = 0.26,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0, -0.006, 0),
					["rot"] = Vector3.new(-2, 2, -1.5)
				},
				{
					["t"] = 0.38,
					["rest"] = Vector3.new(0, 0, 0)
				}
			}
		}
	},
	["chakram"] = {
		["throw"] = {
			["contact"] = 0,
			["release"] = 0.34,
			["vanish"] = 0.05,
			["smear"] = nil,
			["keys"] = nil,
			["smear"] = { 0.01, 0.07 },
			["keys"] = {
				{
					["t"] = 0.025,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.08, 0.03, -0.12),
					["rot"] = Vector3.new(-4, -25, -8)
				},
				{
					["t"] = 0.05,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.18, 0.04, -0.28),
					["rot"] = Vector3.new(-10, -52, -10)
				},
				{
					["t"] = 0.1,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.2, 0.03, -0.3),
					["rot"] = Vector3.new(-10, -56, -10)
				},
				{
					["t"] = 0.34,
					["rest"] = Vector3.new(0, 0, 0)
				}
			}
		},
		["draw"] = {
			["contact"] = 0,
			["release"] = 0.42,
			["eyeRoll"] = true,
			["fx"] = nil,
			["keys"] = nil,
			["fx"] = {
				{ 0.3, "glint", "Knife_Ready" }
			},
			["keys"] = {
				{
					["t"] = 0.1,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.02, -0.11, 0.02),
					["rot"] = Vector3.new(0, 0, 120)
				},
				{
					["t"] = 0.2,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.01, -0.03, 0.01),
					["rot"] = Vector3.new(0, 0, 240)
				},
				{
					["t"] = 0.3,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0, 0.012, 0),
					["rot"] = Vector3.new(0, 0, 362)
				},
				{
					["t"] = 0.35,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0, 0.002, 0),
					["rot"] = Vector3.new(0, 0, 359)
				},
				{
					["t"] = 0.42,
					["rest"] = Vector3.new(0, 0, 0)
				}
			}
		},
		["redraw"] = {
			["contact"] = 0,
			["release"] = 0.34,
			["fx"] = nil,
			["keys"] = nil,
			["fx"] = {
				{ 0.2, "glint", "Knife_Ready" }
			},
			["keys"] = {
				{
					["t"] = 0.14,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0.01, 0.03, 0),
					["rot"] = Vector3.new(8, -6, 6)
				},
				{
					["t"] = 0.2,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0, -0.02, 0),
					["rot"] = Vector3.new(-3, 0, -2)
				},
				{
					["t"] = 0.27,
					["rest"] = nil,
					["rot"] = nil,
					["rest"] = Vector3.new(0, 0.004, 0),
					["rot"] = Vector3.new(0.5, 0, 0.5)
				},
				{
					["t"] = 0.34,
					["rest"] = Vector3.new(0, 0, 0)
				}
			}
		}
	},
	["bandage"] = v228,
	["harpoon"] = v196,
	["palisade"] = v231,
	["beehive"] = v225
}
v_u_184.DRAW = {
	["Musket"] = {
		["rest"] = Vector3.new(0.04, -0.26, 0.08),
		["rot"] = Vector3.new(-55, -18, -50)
	},
	["Blunderbuss"] = {
		["rest"] = Vector3.new(0.04, -0.24, 0.08),
		["rot"] = Vector3.new(-55, -18, -60)
	},
	["Pistol"] = {
		["rest"] = Vector3.new(0.04, -0.2, 0.06),
		["rot"] = Vector3.new(-90, -10, 0)
	},
	["Crossbow"] = {
		["rest"] = Vector3.new(0.04, -0.26, 0.08),
		["rot"] = Vector3.new(-50, -16, -55)
	},
	["Bow"] = {
		["rest"] = Vector3.new(0.04, -0.32, 0.05),
		["rot"] = Vector3.new(-20, -30, -40)
	},
	["Axe"] = {
		["rest"] = Vector3.new(0.16, -0.4, 0.04),
		["rot"] = Vector3.new(-60, -10, -110)
	},
	["Club"] = {
		["rest"] = Vector3.new(0.18, -0.26, 0.04),
		["rot"] = Vector3.new(-10, -6, -140)
	},
	["Spear"] = {
		["rest"] = Vector3.new(0.12, -0.22, 0.06),
		["rot"] = Vector3.new(-20, -85, 10)
	},
	["Shield"] = {
		["rest"] = Vector3.new(0.3, -0.26, 0.04),
		["rot"] = Vector3.new(-20, -85, -15)
	},
	["Knives"] = {
		["rest"] = Vector3.new(0.04, -0.32, 0.04),
		["rot"] = Vector3.new(0, 0, 0)
	},
	["Javelin"] = {
		["rest"] = Vector3.new(0.12, -0.22, 0.06),
		["rot"] = Vector3.new(-20, -85, 10)
	},
	["Sling"] = {
		["rest"] = Vector3.new(0.04, -0.3, 0.04),
		["rot"] = Vector3.new(0, 0, 0)
	},
	["Bomb"] = {
		["rest"] = Vector3.new(0.04, -0.3, 0.04),
		["rot"] = Vector3.new(-30, -20, -20)
	},
	["Herbs"] = {
		["rest"] = Vector3.new(0.04, -0.3, 0.04),
		["rot"] = Vector3.new(-30, -20, -20)
	},
	["Horn"] = {
		["rest"] = Vector3.new(0.04, -0.3, 0.04),
		["rot"] = Vector3.new(-30, -20, -20)
	},
	["Trap"] = {
		["rest"] = Vector3.new(0.04, -0.3, 0.04),
		["rot"] = Vector3.new(-30, -20, -20)
	},
	["Gauntlets"] = {
		["rest"] = Vector3.new(0.06, -0.34, 0.06),
		["rot"] = Vector3.new(-40, 0, 0)
	},
	["Scythe"] = {
		["rest"] = Vector3.new(0.46, -0.5, 0.04),
		["rot"] = Vector3.new(0, 0, -55)
	},
	["Katana"] = v197.Frame(Vector3.new(-0.34, -0.82, -0.48), Vector3.new(-0.98, -0.05, -0.2), Vector3.new(0, 1, 0)),
	["Hatchets"] = {
		["rest"] = Vector3.new(0.06, -0.52, 0.06),
		["rot"] = Vector3.new(-30, 0, -40)
	}
}
v_u_184.HIDE = {
	["Knives"] = 0.03,
	["Javelin"] = 0.42,
	["Bomb"] = 0.38,
	["Trap"] = 0.25
}
local v232 = {
	["bolas"] = "Knives",
	["chakram"] = "Knives",
	["bandage"] = "Herbs",
	["longbow"] = "Bow",
	["harpoon"] = "Javelin",
	["palisade"] = "Trap",
	["beehive"] = "Bomb"
}
local v233 = {}
for v234, v235 in { v_u_184.SETS, v_u_184.ITEMS } do
	for v238, v237 in v235 do
		if v234 ~= 1 then
			local v238 = v232[v238]
		end
		for v239, v240 in v237 do
			if type(v240) ~= "table" or (not v240.keys or v233[v240]) then
				continue
			end
			v233[v240] = true
			local v241
			if (v239 == "draw" or v239 == "redraw") and v238 then
				v241 = v237.drawFrom or v_u_184.DRAW[v238]
			else
				v241 = nil
			end
			if type(v241) ~= "table" then
				v241 = nil
			end
			v197.Subdivide(v240, 60, v241)
			if not v240.left then
				continue
			end
			v240.left = v197.Subdivide({
				["keys"] = v240.left
			}, 60, v241).keys
		end
	end
end
function v_u_184.Pick(p242, p243, _, p244) -- name: Pick
	local v245 = p243 % 2 == 0
	if p242 == "Katana" then
		return ({
			"slash_r",
			"slash_l",
			"rise",
			"finisher"
		})[(p243 - 1) % 4 + 1]
	elseif p242 == "Hatchets" then
		return p244 and (v245 and "one_b" or "one_r") or ({
			"chop_r",
			"chop_l",
			"chop_r",
			"double"
		})[(p243 - 1) % 4 + 1]
	elseif p242 == "Axe" then
		return v245 and "chop_l" or "chop_r"
	elseif p242 == "Club" then
		return v245 and "swing" or "smash"
	elseif p242 == "Spear" then
		return v245 and "thrust2" or "thrust"
	elseif p242 == "Shield" then
		return "bash"
	elseif p242 == "Gauntlets" then
		return ({
			"jab",
			"cross",
			"hook",
			"upper"
		})[(p243 - 1) % 4 + 1]
	else
		return p242 == "Scythe" and (v245 and "sweep_l" or "sweep_r") or nil
	end
end
function v_u_184.For(p246, p247) -- name: For
	-- upvalues: (copy) v_u_184
	local v248 = v_u_184.SETS[p247]
	local v249
	if p246 then
		v249 = v_u_184.ITEMS[p246]
	else
		v249 = nil
	end
	if not v249 then
		return v248
	end
	if not v248 then
		return v249
	end
	local v250 = table.clone(v248)
	for v251, v252 in v249 do
		v250[v251] = v252
	end
	return v250
end
return v_u_184