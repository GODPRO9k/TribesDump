local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = require(v_u_2:WaitForChild("Shared"):WaitForChild("Keybinds"))
return {
	["Init"] = function(p_u_6) -- name: Init
		-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (copy) v_u_4
		local v_u_7 = p_u_6.UI
		local v_u_8 = p_u_6.Theme
		local v_u_9 = p_u_6.State
		local v_u_10 = p_u_6.WeaponIcon
		local v_u_11 = v_u_8.Colors
		local v12 = v_u_8.Fonts
		local v_u_13 = v_u_1.LocalPlayer
		local v14 = 0.3
		local v_u_15 = v_u_2.Shared:FindFirstChild("Config")
		local v16, v17 = pcall(function()
			-- upvalues: (copy) v_u_15
			if v_u_15 then
				return require(v_u_15)
			else
				return nil
			end
		end)
		if v16 and type(v17) == "table" then
			local v18 = v17.LOADOUT_SWAP_CUTOFF
			if type(v18) == "number" then
				v14 = v17.LOADOUT_SWAP_CUTOFF
			end
		end
		local v_u_19 = v14 + 0.12
		local v_u_20 = v14 + 0.25
		local v_u_21 = v_u_7.new("Frame", {
			["Name"] = "LoadoutSwap",
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Size"] = UDim2.fromOffset(800, 90),
			["Parent"] = p_u_6.Canvas.HUD
		})
		local v_u_22 = v_u_7.new("Frame", {
			["Name"] = "Header",
			["Size"] = UDim2.new(1, 0, 0, 22),
			v_u_7.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
			["Parent"] = v_u_21
		})
		local v_u_23 = v_u_7.ActionCap("NextLoadout", {
			["Height"] = 20,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Parent"] = v_u_22
		})
		local v_u_24 = v_u_7.new("TextLabel", {
			["Name"] = "Title",
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["Text"] = "SWITCH LOADOUT",
			["FontFace"] = nil,
			["TextSize"] = 15,
			["TextColor3"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromOffset(0, 20),
			["FontFace"] = v12.Heavy,
			["TextColor3"] = v_u_11.TextDim,
			["Parent"] = v_u_22
		})
		local v_u_25 = v_u_7.TextStroke(v_u_11.Void, 1.5, 0.35)
		v_u_25.Parent = v_u_24
		local v_u_26 = v_u_7.new("Frame", {
			["Name"] = "Cards",
			["Position"] = UDim2.fromOffset(0, 26),
			["Size"] = UDim2.new(1, 0, 0, 58),
			v_u_7.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
			["Parent"] = v_u_21
		})
		local v_u_27 = nil
		local v_u_28 = nil
		local v_u_29 = false
		local v_u_30 = {}
		for v_u_31 = 1, 5 do
			local v32 = v_u_7.new("TextButton", {
				["Name"] = "Slot" .. v_u_31,
				["Size"] = UDim2.fromOffset(128, 60),
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = v_u_11.Panel,
				["BackgroundTransparency"] = 0.25,
				["LayoutOrder"] = v_u_31,
				v_u_7.Corner(10),
				["Parent"] = v_u_26
			})
			local v33 = v_u_7.Stroke(v_u_11.Stroke, 1.5, 0.82)
			v33.Parent = v32
			local v34 = v_u_7.new("TextLabel", {
				["Name"] = "Num",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 15,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["ZIndex"] = 3,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(7, 3),
				["Size"] = UDim2.fromOffset(16, 16),
				["Text"] = tostring(v_u_31),
				["FontFace"] = v12.Display,
				["TextColor3"] = v_u_11.TextDim,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Parent"] = v32
			})
			local v35 = v_u_7.TextStroke(v_u_11.Void, 1.5, 0.3)
			v35.Parent = v34
			local v36 = v_u_7.new("Frame", {
				["Name"] = "Icons",
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.new(0.5, 0, 0.5, 3),
				["Size"] = UDim2.new(1, -10, 0, 40),
				v_u_7.List(Enum.FillDirection.Horizontal, 2, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
				["Parent"] = v32
			})
			local v37 = {}
			for v38 = 1, 3 do
				v37[v38] = v_u_7.new("Frame", {
					["Name"] = nil,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Visible"] = false,
					["ZIndex"] = 2,
					["Parent"] = nil,
					["Name"] = "I" .. v38,
					["Size"] = UDim2.fromOffset(38, 38),
					["LayoutOrder"] = v38,
					["Parent"] = v36
				})
			end
			local v39 = v_u_7.new("TextLabel", {
				["Name"] = "More",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 13,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["Visible"] = false,
				["ZIndex"] = 3,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(1, 1),
				["Position"] = UDim2.new(1, -6, 1, -2),
				["Size"] = UDim2.fromOffset(30, 16),
				["FontFace"] = v12.Display,
				["TextColor3"] = v_u_11.TextDim,
				["TextXAlignment"] = Enum.TextXAlignment.Right,
				["Parent"] = v32
			})
			local v40 = v_u_7.TextStroke(v_u_11.Void, 1.5, 0.3)
			v40.Parent = v39
			local v_u_41 = {
				["btn"] = nil,
				["stroke"] = nil,
				["num"] = nil,
				["numStroke"] = nil,
				["icons"] = nil,
				["holders"] = nil,
				["more"] = nil,
				["moreStroke"] = nil,
				["sig"] = nil,
				["hover"] = false,
				["btn"] = v32,
				["stroke"] = v33,
				["num"] = v34,
				["numStroke"] = v35,
				["icons"] = v36,
				["holders"] = v37,
				["more"] = v39,
				["moreStroke"] = v40
			}
			v_u_30[v_u_31] = v_u_41
			v32.Activated:Connect(function()
				-- upvalues: (ref) v_u_27, (copy) v_u_31
				v_u_27(v_u_31, "tap")
			end)
			v32.MouseEnter:Connect(function()
				-- upvalues: (copy) v_u_41, (ref) v_u_28
				v_u_41.hover = true
				if v_u_28 then
					v_u_28()
				end
			end)
			v32.MouseLeave:Connect(function()
				-- upvalues: (copy) v_u_41, (ref) v_u_28
				v_u_41.hover = false
				if v_u_28 then
					v_u_28()
				end
			end)
			for _, v42 in v37 do
				v42.ChildAdded:Connect(function()
					-- upvalues: (ref) v_u_28, (ref) v_u_29
					if v_u_28 and not v_u_29 then
						v_u_29 = true
						task.defer(function()
							-- upvalues: (ref) v_u_29, (ref) v_u_28
							v_u_29 = false
							if v_u_28 then
								v_u_28()
							end
						end)
					end
				end)
			end
		end
		local v_u_43 = 0
		local v_u_44 = 1
		local v_u_45 = 0
		local v_u_46 = 0
		local v_u_47 = nil
		local function v_u_54(p48) -- name: idsOf
			-- upvalues: (copy) v_u_9
			local v49 = v_u_9.LoadoutSlot(p48)
			local v50 = {}
			for _, v51 in v49 and (v49.items or {}) or {} do
				if type(v51) ~= "string" then
					continue
				end
				table.insert(v50, v51)
			end
			if v49 then
				local v52 = v49.armor
				if type(v52) == "string" then
					local v53 = v49.armor
					table.insert(v50, v53)
				end
			end
			return v50
		end
		local v_u_55 = {
			["outline"] = false,
			["glow"] = true,
			["glowColor"] = nil,
			["glowTransparency"] = 1,
			["transparency"] = 0.98,
			["glowColor"] = Color3.fromRGB(120, 132, 158)
		}
		local function v_u_67(p56, p57) -- name: fillCard
			-- upvalues: (copy) v_u_54, (copy) v_u_10, (copy) v_u_55
			local v58 = v_u_54(p57)
			local v59 = table.concat(v58, ",")
			if p56.sig ~= v59 then
				p56.sig = v59
				local v60 = #v58
				local v61 = math.min(v60, 3)
				for v62, v63 in p56.holders do
					local v64
					if v62 <= v61 then
						v64 = v58[v62]
					else
						v64 = nil
					end
					v63.Visible = v64 ~= nil
					v_u_10.Set(v63, v64, v_u_55)
				end
				p56.more.Visible = v61 < #v58
				local v65 = p56.more
				local v66 = #v58 - v61
				v65.Text = "+" .. tostring(v66)
			end
		end
		local v_u_68 = 0
		local v_u_69 = 0
		local function v_u_85() -- name: paint
			-- upvalues: (ref) v_u_68, (copy) v_u_30, (ref) v_u_43, (ref) v_u_44, (copy) v_u_11, (copy) v_u_8, (copy) v_u_10, (copy) v_u_24, (copy) v_u_25, (copy) v_u_7, (copy) v_u_23
			local v70 = v_u_68
			local v71 = 1 - v70
			for v72, v73 in v_u_30 do
				if v_u_43 < v72 then
					continue
				end
				local v74 = v72 == v_u_44
				local v75 = v73.btn
				local v76
				if v74 then
					v76 = v_u_11.Accent
				elseif v73.hover then
					v76 = v_u_11.PanelHi
				else
					v76 = v_u_11.Panel
				end
				v75.BackgroundColor3 = v76
				v73.btn.BackgroundTransparency = (v74 and 0.06 or 0.25) + (1 - (v74 and 0.06 or 0.25)) * v71
				local v77 = v73.stroke
				local v78
				if v74 then
					v78 = v_u_8.Lighten(v_u_11.Accent, 0.45)
				else
					v78 = v_u_11.Stroke
				end
				v77.Color = v78
				v73.stroke.Thickness = v74 and 2 or 1.5
				v73.stroke.Transparency = (v74 and 0.15 or 0.82) + (1 - (v74 and 0.15 or 0.82)) * v71
				local v79 = v73.num
				local v80
				if v74 then
					v80 = v_u_11.Text
				else
					v80 = v_u_11.TextDim
				end
				v79.TextColor3 = v80
				v73.num.TextTransparency = v71
				v73.numStroke.Transparency = v71 * 0.7 + 0.3
				local v81 = v73.more
				local v82
				if v74 then
					v82 = v_u_11.Text
				else
					v82 = v_u_11.TextDim
				end
				v81.TextColor3 = v82
				v73.more.TextTransparency = v71
				v73.moreStroke.Transparency = v71 * 0.7 + 0.3
				v73.btn.Interactable = v70 >= 0.5
				for _, v83 in v73.holders do
					if not v83.Visible then
						continue
					end
					v_u_10.SetTransparency(v83, v71 * 0.98)
					local v84 = v83:FindFirstChild("WeaponGlow")
					if not (v84 and v84:IsA("ImageLabel")) then
						continue
					end
					v84.ImageTransparency = v71 * 0.55 + 0.45
				end
			end
			v_u_24.TextTransparency = v71
			v_u_25.Transparency = v71 * 0.65 + 0.35
			v_u_7.SetCapFade(v_u_23, v71)
		end
		local function v_u_101() -- name: layout
			-- upvalues: (copy) v_u_7, (ref) v_u_43, (copy) v_u_9, (copy) v_u_30, (copy) v_u_26, (copy) v_u_22, (copy) v_u_21, (copy) p_u_6
			local v86 = v_u_7.Compact
			local v87
			if v_u_9.HasLoadoutSlots() then
				local v88 = v_u_9.LoadoutSlotCount()
				v87 = math.min(v88, 5)
			else
				v87 = 0
			end
			v_u_43 = v87
			local v89 = v86 and 108 or 128
			local v90 = v86 and 44 or 60
			local v91 = v86 and 30 or 38
			local v92 = v86 and 6 or 8
			for v93, v94 in v_u_30 do
				v94.btn.Visible = v93 <= v_u_43
				v94.btn.Size = UDim2.fromOffset(v89, v90)
				v94.icons.Size = UDim2.new(1, -8, 0, v91 + 2)
				for _, v95 in v94.holders do
					v95.Size = UDim2.fromOffset(v91, v91)
				end
			end
			local v96 = v_u_26:FindFirstChildOfClass("UIListLayout")
			if v96 then
				v96.Padding = UDim.new(0, v92)
				local v97
				if v86 then
					v97 = Enum.FillDirection.Vertical
				else
					v97 = Enum.FillDirection.Horizontal
				end
				v96.FillDirection = v97
			end
			local v98 = v_u_43
			local v99 = math.max(v98, 1)
			if v86 then
				v_u_22.Visible = false
				v_u_26.Position = UDim2.new()
				v_u_26.Size = UDim2.fromScale(1, 1)
				v_u_21.AnchorPoint = Vector2.new(0, 0.5)
				v_u_21.Size = UDim2.fromOffset(v89, v99 * v90 + (v99 - 1) * v92)
				v_u_21.Position = UDim2.new(0, 12, 0.45, 0)
			else
				v_u_22.Visible = true
				v_u_26.Position = UDim2.fromOffset(0, 26)
				v_u_26.Size = UDim2.new(1, 0, 0, v90)
				v_u_21.AnchorPoint = Vector2.new(0.5, 1)
				v_u_21.Size = UDim2.fromOffset(v99 * v89 + (v99 - 1) * v92, v90 + 26)
				local v100 = not p_u_6.HotbarTop and 104 or p_u_6.HotbarTop()
				v_u_21.Position = UDim2.new(0.5, 0, 1, -(v100 + 70 + 28 + 6))
			end
		end
		v_u_101()
		v_u_7.LayoutChanged:Connect(v_u_101)
		if p_u_6.HotbarChanged then
			p_u_6.HotbarChanged.Event:Connect(v_u_101)
		end
		local function v_u_105() -- name: refreshCards
			-- upvalues: (copy) v_u_9, (ref) v_u_43, (copy) v_u_101, (ref) v_u_45, (ref) v_u_44, (copy) v_u_67, (copy) v_u_30, (copy) v_u_85
			local v102
			if v_u_9.HasLoadoutSlots() then
				local v103 = v_u_9.LoadoutSlotCount()
				v102 = math.min(v103, 5)
			else
				v102 = 0
			end
			if v102 ~= v_u_43 then
				v_u_101()
			end
			if v_u_45 == 0 then
				v_u_44 = v_u_9.ActiveLoadout()
			end
			for v104 = 1, v_u_43 do
				v_u_67(v_u_30[v104], v104)
			end
			v_u_85()
		end
		local function v_u_109() -- name: baseOk
			-- upvalues: (copy) v_u_9, (copy) p_u_6, (copy) v_u_13
			local v106 = v_u_9.InMatch() and v_u_9.IsAlive() and (v_u_9.Get("CombatMode") ~= false and not (p_u_6.HudHidden or p_u_6.MenuManager.IsOpen()))
			if v106 then
				if v_u_13:GetAttribute("ReplayPlaying") == true then
					v106 = false
				else
					local v107
					if v_u_9.HasLoadoutSlots() then
						local v108 = v_u_9.LoadoutSlotCount()
						v107 = math.min(v108, 5)
					else
						v107 = 0
					end
					v106 = v107 >= 2
				end
			end
			return v106
		end
		local v_u_110 = false
		local function v_u_115(p111) -- name: setShown
			-- upvalues: (ref) v_u_110, (ref) v_u_69, (ref) v_u_46, (ref) v_u_45, (copy) v_u_105, (copy) v_u_7, (copy) v_u_21, (copy) v_u_8
			if p111 ~= v_u_110 then
				v_u_110 = p111
				v_u_69 = p111 and 1 or 0
				if p111 then
					v_u_46 = v_u_46 + 1
					v_u_45 = 0
					v_u_105()
					local v112 = v_u_7.SlideIn
					local v113 = v_u_21
					local v114
					if v_u_7.Compact then
						v114 = Vector2.new(-18, 0)
					else
						v114 = Vector2.new(0, 18)
					end
					v112(v113, v114, v_u_8.Tween.Smooth)
				end
			end
		end
		local v_u_116 = nil
		local function v_u_129(p117) -- name: frame
			-- upvalues: (copy) v_u_9, (copy) v_u_115, (copy) v_u_20, (copy) v_u_109, (ref) v_u_68, (ref) v_u_69, (copy) v_u_85
			local v118, v119 = v_u_9.PhaseClock()
			local v120 = (v118 ~= "PreRound" or v119 <= 0) and -1 or v119 - v_u_9.Now()
			local v121 = v_u_115
			local v122
			if v_u_20 < v120 then
				v122 = v_u_109()
			else
				v122 = false
			end
			v121(v122)
			if v_u_68 ~= v_u_69 then
				local v123 = p117 / (v_u_68 < v_u_69 and 0.18 or 0.14)
				local v124
				if v_u_68 < v_u_69 then
					local v125 = v_u_69
					local v126 = v_u_68 + v123
					v124 = math.min(v125, v126)
				else
					local v127 = v_u_69
					local v128 = v_u_68 - v123
					v124 = math.max(v127, v128)
				end
				v_u_68 = v124
				v_u_85()
			end
		end
		local function v132() -- name: watch
			-- upvalues: (copy) v_u_9, (ref) v_u_116, (ref) v_u_3, (copy) v_u_129, (ref) v_u_110, (ref) v_u_68, (ref) v_u_69, (copy) v_u_105, (copy) v_u_21, (ref) v_u_43
			local v130 = v_u_9.InMatch()
			if v130 and not v_u_116 then
				v_u_116 = v_u_3.RenderStepped:Connect(v_u_129)
			elseif not v130 and v_u_116 then
				v_u_116:Disconnect()
				v_u_116 = nil
				v_u_110 = false
				v_u_68 = 0
				v_u_69 = 0
			end
			v_u_105()
			local v131 = v_u_21
			if v130 then
				v130 = v_u_43 >= 2
			end
			v131.Visible = v130
		end
		v132()
		v_u_9.PlayerStateChanged:Connect(v132)
		v_u_9.ProfileChanged:Connect(function()
			-- upvalues: (copy) v_u_9, (copy) v_u_105, (copy) v_u_21, (ref) v_u_43
			if v_u_9.InMatch() then
				v_u_105()
				v_u_21.Visible = v_u_43 >= 2
			end
		end)
		local function v_u_150(p133, p134)
			-- upvalues: (ref) v_u_110, (ref) v_u_43, (ref) v_u_44, (copy) v_u_7, (copy) v_u_30, (copy) v_u_9, (copy) v_u_19, (copy) v_u_85, (copy) p_u_6, (ref) v_u_46, (ref) v_u_45, (ref) v_u_47, (copy) v_u_26
			if v_u_110 and (p133 >= 1 and v_u_43 >= p133) then
				if p133 == v_u_44 then
					if p134 == "tap" then
						v_u_7.Bump(v_u_30[p133].btn, 0.05)
					end
					return
				else
					local v135, v136 = v_u_9.PhaseClock()
					if ((v135 ~= "PreRound" or v136 <= 0) and -1 or v136 - v_u_9.Now()) >= v_u_19 then
						v_u_44 = p133
						v_u_85()
						v_u_7.Bump(v_u_30[p133].btn, 0.08)
						p_u_6.Sounds.Play("Equip")
						v_u_46 = v_u_46 + 1
						local v_u_137 = v_u_46
						v_u_45 = v_u_45 + 1
						local v138 = task.delay
						local v139, v140 = v_u_9.PhaseClock()
						v138(v_u_19 < ((v139 ~= "PreRound" or v140 <= 0) and -1 or v140 - v_u_9.Now()) - 0.15 and 0.15 or 0, function()
							-- upvalues: (ref) v_u_44, (copy) v_u_137, (ref) v_u_46, (ref) v_u_47, (ref) v_u_9, (ref) v_u_45, (ref) v_u_85, (ref) v_u_19, (ref) v_u_7, (ref) v_u_26, (ref) p_u_6
							local v141 = v_u_44
							local v142 = v_u_137 ~= v_u_46
							if v142 or v141 == (v_u_47 or v_u_9.ActiveLoadout()) then
								local v143 = v_u_45 - 1
								v_u_45 = math.max(0, v143)
								if not v142 then
									v_u_85()
								end
								return
							else
								local v144, v145 = v_u_9.PhaseClock()
								if ((v144 ~= "PreRound" or v145 <= 0) and -1 or v145 - v_u_9.Now()) < v_u_19 then
									local v146 = v_u_45 - 1
									v_u_45 = math.max(0, v146)
									if v_u_137 == v_u_46 then
										v_u_44 = v_u_9.ActiveLoadout()
										v_u_85()
										v_u_7.Shake(v_u_26, 6)
										p_u_6.Sounds.Play("Error")
									end
								else
									v_u_47 = v141
									local v147 = p_u_6.ProfileAction("SelectLoadout", v141)
									local v148 = v_u_45 - 1
									v_u_45 = math.max(0, v148)
									if v_u_47 == v141 then
										v_u_47 = nil
									end
									if v147 then
										v_u_9.Profile.activeLoadout = v141
										local v149 = v_u_9.Profile.loadouts
										if type(v149) == "table" and v_u_9.Profile.loadouts[v141] then
											v_u_9.Profile.loadout = v_u_9.Profile.loadouts[v141]
										end
										if v_u_45 == 0 then
											v_u_44 = v_u_9.ActiveLoadout()
											v_u_85()
											return
										end
									elseif v_u_137 == v_u_46 then
										v_u_44 = v_u_9.ActiveLoadout()
										v_u_85()
										v_u_7.Shake(v_u_26, 6)
										p_u_6.Sounds.Play("Error")
									end
								end
							end
						end)
					end
				end
			else
				return
			end
		end
		v_u_5.OnInput("Began", function(p151, p152)
			-- upvalues: (ref) v_u_110, (ref) v_u_4, (ref) v_u_5, (ref) v_u_43, (ref) v_u_150, (ref) v_u_44
			if v_u_110 and not (p152 or v_u_4:GetFocusedTextBox()) then
				if v_u_5.IsPad(p151, "NextLoadout") then
					if not v_u_5.PadBlocked() then
						if v_u_43 >= 2 then
							v_u_150((v_u_44 - 1 + 1) % v_u_43 + 1, "key")
						end
					end
				elseif v_u_5.IsPad(p151, "PrevLoadout") then
					if not v_u_5.PadBlocked() then
						if v_u_43 >= 2 then
							v_u_150((v_u_44 - 1 + -1) % v_u_43 + 1, "key")
						end
					end
				elseif v_u_5.ActionOf(p151) == "NextLoadout" then
					if v_u_43 < 2 then
						return
					end
					v_u_150((v_u_44 - 1 + 1) % v_u_43 + 1, "key")
				end
			end
		end)
		function p_u_6.Debug.loadoutSwap(p153, p154)
			-- upvalues: (ref) v_u_150, (ref) v_u_43, (ref) v_u_44, (copy) v_u_30, (ref) v_u_110, (copy) v_u_21, (ref) v_u_68, (copy) v_u_9, (ref) v_u_45
			if p153 == "pick" then
				v_u_150(tonumber(p154) or 1, "tap")
			elseif p153 == "next" and v_u_43 >= 2 then
				v_u_150((v_u_44 - 1 + 1) % v_u_43 + 1, "key")
			end
			local v155 = {}
			for v156 = 1, v_u_43 do
				v155[v156] = v_u_30[v156].sig or ""
			end
			local v157 = {
				["shown"] = v_u_110,
				["visible"] = v_u_21.Visible,
				["fade"] = v_u_68,
				["selected"] = v_u_44,
				["active"] = v_u_9.ActiveLoadout(),
				["busy"] = v_u_45,
				["count"] = v_u_43
			}
			local v158, v159 = v_u_9.PhaseClock()
			v157.timeLeft = (v158 ~= "PreRound" or v159 <= 0) and -1 or v159 - v_u_9.Now()
			v157.cards = v155
			v157.rect = {
				v_u_21.AbsolutePosition.X,
				v_u_21.AbsolutePosition.Y,
				v_u_21.AbsoluteSize.X,
				v_u_21.AbsoluteSize.Y
			}
			return v157
		end
		p_u_6.LoadoutSwap = {
			["IsShown"] = function() -- name: IsShown
				-- upvalues: (ref) v_u_110
				return v_u_110
			end
		}
	end
}