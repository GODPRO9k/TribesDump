local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v4 = require(v2:WaitForChild("Shared"):WaitForChild("Net"))
local v_u_5 = require(script.Parent:WaitForChild("Player"))
local v_u_6 = require(script.Parent:WaitForChild("Puppets"))
local v_u_7 = require(script.Parent:WaitForChild("ViewStream"))
v_u_7.Start()
local v_u_8 = v_u_1.LocalPlayer
local v_u_9 = {}
v4.Event("MatchEvent").OnClientEvent:Connect(function(p10, p11)
	-- upvalues: (copy) v_u_3, (copy) v_u_9, (copy) v_u_5, (copy) v_u_6
	if p10 == "PlayOfTheGame" then
		if v_u_3:IsStudio() then
			local v12 = v_u_9
			table.insert(v12, p11)
			if #v_u_9 > 6 then
				table.remove(v_u_9, 1)
			end
		end
		local v13 = v_u_5.Play
		local v14, v15 = pcall(v13, p11)
		if not v14 then
			warn("[Replay] play failed:", v15)
			local v16 = v_u_5.Stop
			pcall(v16, "error")
			return
		end
	else
		if p10 == "MatchStart" then
			v_u_5.Stop("new match")
			v_u_6.ClearCache()
			return
		end
		if p10 == "RoundStart" then
			task.delay(3, function()
				-- upvalues: (ref) v_u_6
				local v17 = v_u_6.CacheMatch
				pcall(v17)
			end)
		end
	end
end)
v_u_8:GetAttributeChangedSignal("MatchId"):Connect(function()
	-- upvalues: (copy) v_u_5
	v_u_5.Stop("match changed")
end)
v_u_8:GetAttributeChangedSignal("State"):Connect(function()
	-- upvalues: (copy) v_u_8, (copy) v_u_5, (copy) v_u_6
	if v_u_8:GetAttribute("State") ~= "Match" then
		v_u_5.Stop("left the match")
		v_u_6.ClearCache()
	end
end)
if v_u_3:IsStudio() then
	local v18 = Instance.new("BindableFunction")
	v18.Name = "ReplayDebug"
	function v18.OnInvoke(p19, p_u_20)
		-- upvalues: (copy) v_u_5, (copy) v_u_7, (copy) v_u_9, (copy) v_u_6, (copy) v_u_3, (copy) v_u_1
		if p19 == "skip" then
			v_u_5.Skip()
			return true
		elseif p19 == "stop" then
			v_u_5.Stop("debug")
			return true
		elseif p19 == "viewsent" then
			return v_u_7.Sent()
		elseif p19 == "rate" then
			local v21 = v_u_5.DebugRate
			if type(p_u_20) ~= "number" then
				p_u_20 = nil
			end
			v21(p_u_20)
			return true
		elseif p19 == "camlog" then
			local v22 = v_u_5.DebugCamLog
			if type(p_u_20) ~= "boolean" then
				p_u_20 = nil
			end
			return v22(p_u_20)
		elseif p19 == "clips" then
			local v23 = {}
			for v24, v25 in v_u_9 do
				v23[v24] = {
					["focusId"] = v25.focusId,
					["name"] = v25.name,
					["title"] = v25.title,
					["duration"] = v25.duration,
					["startTime"] = v25.startTime,
					["bytes"] = buffer.len(v25.clip)
				}
			end
			return v23
		elseif p19 == "replay" then
			local v26 = v_u_9[type(p_u_20) ~= "number" and #v_u_9 or p_u_20]
			if not v26 then
				return false
			end
			v_u_5.Play(v26)
			return true
		elseif p19 == "frame" then
			local v27 = require(script.Parent:WaitForChild("Overlay")).DebugFrame
			if type(p_u_20) ~= "number" then
				p_u_20 = nil
			end
			return v27(p_u_20)
		elseif p19 == "diag" then
			local v28, v29 = require(script.Parent:WaitForChild("Diag")).LastLine()
			return {
				["line"] = v28,
				["hidden"] = v29
			}
		elseif p19 == "cache" then
			v_u_6.CacheMatch()
			return true
		elseif p19 == "clearcache" then
			v_u_6.ClearCache()
			return true
		elseif p19 == "trace" then
			local v30 = require(script.Parent:WaitForChild("PoseTrace"))
			if p_u_20 == false then
				v30.Stop()
			else
				v30.Start()
			end
			return v30.Active()
		elseif p19 == "freeze" then
			local v31 = v_u_5.DebugFreeze
			if type(p_u_20) ~= "number" then
				p_u_20 = nil
			end
			v31(p_u_20)
			return true
		elseif p19 == "sidecam" then
			v_u_3:UnbindFromRenderStep("TribesReplaySideCam")
			if type(p_u_20) ~= "string" then
				return false
			end
			local v_u_32 = {
				40,
				-40,
				90,
				-90,
				140,
				-140,
				0,
				180
			}
			local v_u_33 = 1
			local v_u_34 = RaycastParams.new()
			v_u_34.FilterType = Enum.RaycastFilterType.Exclude
			v_u_34.IgnoreWater = true
			v_u_3:BindToRenderStep("TribesReplaySideCam", Enum.RenderPriority.Camera.Value + 10, function()
				-- upvalues: (ref) v_u_5, (copy) p_u_20, (ref) v_u_6, (ref) v_u_1, (copy) v_u_34, (copy) v_u_32, (ref) v_u_33
				local v35 = v_u_5.DebugPuppet(p_u_20) or v_u_6.FindLive(p_u_20)
				local v36
				if v35 then
					v36 = v35:FindFirstChild("HumanoidRootPart")
				else
					v36 = v35
				end
				if v36 and v36:IsA("BasePart") then
					local v37 = { v35 }
					for _, v38 in { "Replay", "FX", "Projectiles" } do
						local v39 = workspace:FindFirstChild(v38)
						if not v39 then
							continue
						end
						table.insert(v37, v39)
					end
					for _, v40 in v_u_1:GetPlayers() do
						if not v40.Character then
							continue
						end
						local v41 = v40.Character
						table.insert(v37, v41)
					end
					v_u_34.FilterDescendantsInstances = v37
					local v42 = select(2, v36.CFrame:ToEulerAnglesYXZ())
					local v43 = v36.Position + Vector3.new(0, 1.2, 0)
					local v44 = workspace
					local v45 = v_u_33
					local v46 = CFrame.fromEulerAnglesYXZ
					local v47 = v_u_32[v45]
					if v44:Spherecast(v43, 0.5, v43 + v46(0, v42 + math.rad(v47), 0):VectorToWorldSpace(Vector3.new(0, 0.8, -8)) - v43, v_u_34) then
						for v48 = 1, #v_u_32 do
							local v49 = workspace
							local v50 = CFrame.fromEulerAnglesYXZ
							local v51 = v_u_32[v48]
							if v49:Spherecast(v43, 0.5, v43 + v50(0, v42 + math.rad(v51), 0):VectorToWorldSpace(Vector3.new(0, 0.8, -8)) - v43, v_u_34) then
								continue
							end
							v_u_33 = v48
						end
					end
					local v52 = workspace.CurrentCamera
					v52.CameraType = Enum.CameraType.Scriptable
					local v53 = CFrame.lookAt
					local v54 = v_u_33
					local v55 = CFrame.fromEulerAnglesYXZ
					local v56 = v_u_32[v54]
					v52.CFrame = v53(v43 + v55(0, v42 + math.rad(v56), 0):VectorToWorldSpace(Vector3.new(0, 0.8, -8)), v36.Position + Vector3.new(0, 0.6, 0))
					v52.FieldOfView = 60
				end
			end)
			return true
		elseif p19 == "match" then
			local v57 = require(script.Parent:WaitForChild("PoseTrace"))
			if type(p_u_20) ~= "table" then
				return false
			end
			local v58 = v_u_5.DebugPuppet(p_u_20[1])
			if not v58 then
				return "no puppet"
			end
			local v59, v60, v61 = v57.BestMatch(p_u_20[1], v58, p_u_20[2], p_u_20[3])
			return {
				["t"] = v59,
				["meanDeg"] = v60,
				["joints"] = v61
			}
		elseif p19 == "anim" then
			return v_u_5.DebugAnim()
		elseif p19 == "poses" then
			return require(script.Parent:WaitForChild("PoseTrace")).Report()
		else
			return v_u_5.DebugState()
		end
	end
	v18.Parent = v_u_8
end