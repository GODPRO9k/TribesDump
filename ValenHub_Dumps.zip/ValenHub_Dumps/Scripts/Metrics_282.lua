local v_u_1 = game:GetService("Players")
local v2 = game:GetService("RunService")
local v_u_3 = {}
local v_u_4 = {
	["fx"] = 0,
	["fxTime"] = 0,
	["projTime"] = 0
}
v_u_3.projLive = 0
v_u_3.sounds = 0
local v_u_5 = {}
function v_u_3.AddFx(p6, p7) -- name: AddFx
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	local v8 = v_u_4
	v8.fx = v8.fx + 1
	local v9 = v_u_4
	v9.fxTime = v9.fxTime + p6
	if p7 then
		v_u_5[p7] = (v_u_5[p7] or 0) + p6
	end
end
function v_u_3.AddProj(p10, p11) -- name: AddProj
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v12 = v_u_4
	v12.projTime = v12.projTime + p10
	v_u_3.projLive = p11
end
local v_u_13 = 0
local v_u_14 = 0
local v_u_15 = 0
local v_u_16 = os.clock()
v2.RenderStepped:Connect(function(p17)
	-- upvalues: (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16, (copy) v_u_1, (copy) v_u_4, (copy) v_u_3, (copy) v_u_5
	v_u_13 = v_u_13 + 1
	v_u_14 = v_u_14 + p17
	local v18 = v_u_15
	v_u_15 = math.max(v18, p17)
	local v19 = os.clock()
	if v19 - v_u_16 >= 1 then
		local v20 = v19 - v_u_16
		v_u_16 = v19
		local v21 = v_u_1.LocalPlayer:FindFirstChildOfClass("PlayerScripts")
		if v21 then
			local v22 = workspace:FindFirstChild("FX")
			local v23 = v_u_4.fx / v20 + 0.5
			v21:SetAttribute("CombatFxPerSec", (math.floor(v23)))
			local v24 = v_u_4.fxTime / v20 * 1000 * 100 + 0.5
			v21:SetAttribute("CombatFxMsPerSec", math.floor(v24) / 100)
			local v25 = v_u_4.projTime / v20 * 1000 * 100 + 0.5
			v21:SetAttribute("CombatProjMsPerSec", math.floor(v25) / 100)
			v21:SetAttribute("CombatProjLive", v_u_3.projLive)
			v21:SetAttribute("CombatFxLive", v22 and #v22:GetChildren() or 0)
			v21:SetAttribute("CombatSounds", v_u_3.sounds)
			local v26 = "CombatFrameMsAvg"
			local v27
			if v_u_13 > 0 then
				local v28 = v_u_14 / v_u_13 * 1000 * 10 + 0.5
				v27 = math.floor(v28) / 10
			else
				v27 = 0
			end
			v21:SetAttribute(v26, v27)
			local v29 = v_u_15 * 1000 * 10 + 0.5
			v21:SetAttribute("CombatFrameMsMax", math.floor(v29) / 10)
			local v30 = {}
			for v31, v32 in v_u_5 do
				local v33 = string.format
				local v34 = v32 / v20 * 1000
				table.insert(v30, v33("%s=%.1f", v31, v34))
			end
			table.sort(v30)
			v21:SetAttribute("CombatFxMsByKind", table.concat(v30, " "))
		end
		table.clear(v_u_5)
		local v35 = v_u_4
		local v36 = v_u_4
		v_u_4.fx = 0
		v35.fxTime = 0
		v36.projTime = 0
		v_u_13 = 0
		v_u_14 = 0
		v_u_15 = 0
	end
end)
return v_u_3