local v_u_1 = game:GetService("Workspace")
local v2 = {}
local v_u_3 = 1
local v_u_4 = {
	["yaw"] = 0,
	["pitch"] = -0.13962634015954636,
	["fov"] = 70,
	["pivotY"] = 0,
	["aimW"] = 0,
	["aimFovW"] = 0,
	["punch"] = 0,
	["deadAt"] = nil,
	["orbit"] = 0,
	["duration"] = 10,
	["segments"] = nil,
	["seg"] = 1,
	["arm"] = 1,
	["offset"] = Vector3.new(2.9, 0, 10.5),
	["action"] = 0,
	["actionWant"] = 0,
	["aimed"] = false,
	["fpW"] = 0,
	["firstPerson"] = false,
	["segments"] = {}
}
local v_u_5 = RaycastParams.new()
v_u_5.FilterType = Enum.RaycastFilterType.Include
v_u_5.IgnoreWater = true
function v2.SetWorld(p6) -- name: SetWorld
	-- upvalues: (copy) v_u_5
	v_u_5.FilterDescendantsInstances = p6
end
function v2.SetSegments(p7) -- name: SetSegments
	-- upvalues: (copy) v_u_4
	table.sort(p7, function(p8, p9)
		return p8.t0 < p9.t0
	end)
	v_u_4.segments = p7
	v_u_4.seg = 1
end
function v2.SetShoulderSide(p10) -- name: SetShoulderSide
	-- upvalues: (ref) v_u_3
	v_u_3 = p10 < 0 and -1 or 1
end
function v2.Begin(p11, p12) -- name: Begin
	-- upvalues: (copy) v_u_4
	local v13 = v_u_4
	local v14 = p11.LookVector
	local v15 = -v14.X
	local v16 = -v14.Z
	v13.yaw = math.atan2(v15, v16)
	v_u_4.pitch = -0.13962634015954636
	v_u_4.fov = 70
	v_u_4.pivotY = p11.Position.Y + 3.1
	v_u_4.aimW = 0
	v_u_4.aimFovW = 0
	v_u_4.punch = 0
	v_u_4.deadAt = nil
	v_u_4.orbit = 0
	v_u_4.duration = p12
	v_u_4.seg = 1
	v_u_4.arm = 1
	v_u_4.offset = Vector3.new(2.9, 0, 10.5)
	v_u_4.action = 0
	v_u_4.actionWant = 0
	v_u_4.aimed = false
	v_u_4.fpW = 0
	v_u_4.firstPerson = false
end
function v2.InFirstPerson() -- name: InFirstPerson
	-- upvalues: (copy) v_u_4
	return v_u_4.firstPerson
end
function v2.SetAction(p17) -- name: SetAction
	-- upvalues: (copy) v_u_4
	v_u_4.actionWant = math.clamp(p17, 0, 1)
end
function v2.SetAimed(p18) -- name: SetAimed
	-- upvalues: (copy) v_u_4
	v_u_4.aimed = p18
end
function v2.OnKill() -- name: OnKill
	-- upvalues: (copy) v_u_4
	v_u_4.punch = 1
end
function v2.OnShot(_, _) -- name: OnShot end
local function v_u_34(p19) -- name: aimAt
	-- upvalues: (copy) v_u_4
	local v20 = v_u_4.segments
	while v_u_4.seg <= #v20 and v20[v_u_4.seg].t1 < p19 do
		local v21 = v_u_4
		v21.seg = v21.seg + 1
	end
	local v22 = v_u_4.seg - 1
	local v23 = math.max(1, v22)
	local v24 = #v20
	local v25 = v_u_4.seg + 1
	local v26 = 0
	local v27 = nil
	for v28 = v23, math.min(v24, v25) do
		local v29 = v20[v28]
		local v30
		if v29.t0 <= p19 and p19 <= v29.t1 then
			local v31 = (p19 - v29.t0) / 0.28
			local v32 = (v29.t1 - p19) / 0.4 + (p19 <= v29.shot and 1 or 0)
			local v33 = math.min(1, v31, v32)
			v30 = math.clamp(v33, 0, 1)
		else
			v30 = 0
		end
		if v26 >= v30 then
			continue
		end
		v27 = v29
		v26 = v30
	end
	if v27 then
		return v26, v27.point
	else
		return v26, nil
	end
end
function v2.Update(p35, p36, p37, p38, p39, p40) -- name: Update
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_5, (copy) v_u_34, (ref) v_u_3
	local v41
	if p38 then
		v41 = p38.Position
	else
		v41 = nil
	end
	if v41 and p39 then
		v_u_4.deadAt = nil
		local v42 = v41.Y + 3.1
		local v43 = v41 + Vector3.new(0, 1.5, 0)
		local v44 = v_u_1:Spherecast(v43, 0.4, Vector3.new(0, 1.6, 0), v_u_5)
		if v44 then
			local v45 = v43.Y
			local v46 = v44.Distance - 0.4
			v42 = v45 + math.max(0, v46)
		end
		local v47 = v_u_4
		local v48 = v47.pivotY
		local v49 = v42 - v_u_4.pivotY
		local v50 = p36 * -10
		v47.pivotY = v48 + v49 * (1 - math.exp(v50))
	elseif v41 and not v_u_4.deadAt then
		v_u_4.deadAt = p37
	end
	local v51
	if v41 then
		local v52 = v41.X
		local v53 = v_u_4.pivotY
		local v54 = v41.Z
		v51 = Vector3.new(v52, v53, v54)
	else
		v51 = p35.CFrame.Position
	end
	if v_u_4.deadAt and v41 then
		v51 = v41 + Vector3.new(0, 1.2, 0)
	end
	local v55
	if p40 == nil then
		v55 = false
	else
		v55 = p40.valid
		if v55 then
			v55 = p39
		end
	end
	local v56
	if p38 and p39 then
		local v57 = p38.LookVector
		local v58 = -v57.X
		local v59 = -v57.Z
		v56 = math.atan2(v58, v59)
	else
		v56 = v_u_4.yaw
	end
	local v60, v61 = v_u_34(p37)
	if v55 then
		v60 = 0
		v61 = nil
	end
	v_u_4.aimW = v60
	local v62 = v_u_4
	local v63 = v62.aimFovW
	local v64 = (v_u_4.aimed and p39 and 1 or 0) - v_u_4.aimFovW
	local v65 = p36 * -8
	v62.aimFovW = v63 + v64 * (1 - math.exp(v65))
	local v66 = v_u_4
	local v67 = v66.action
	local v68 = v_u_4.actionWant - v_u_4.action
	local v69 = p36 * -3
	v66.action = v67 + v68 * (1 - math.exp(v69))
	local v70 = v_u_4.deadAt and 0 or v_u_4.action * (1 - v60)
	local v71 = v_u_3 * (v_u_4.aimFovW * -0.10000000000000009 + 2.9 + v70 * 0.8)
	local v72 = v_u_4.aimFovW * -2.5 + 10.5
	local v73
	if v61 and v60 > 0 then
		local v74 = v_u_4.yaw
		local v75 = v_u_4.pitch
		for _ = 1, 2 do
			local v76 = (v61 - (v51 + CFrame.fromEulerAnglesYXZ(v75, v74, 0):VectorToWorldSpace(v_u_4.offset))).Unit
			local v77 = -v76.X
			local v78 = -v76.Z
			v74 = math.atan2(v77, v78)
			local v79 = v76.Y
			local v80 = math.clamp(v79, -1, 1)
			v75 = math.asin(v80)
		end
		v56 = v56 + ((v74 - v56 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793) * v60
		v73 = (v75 - -0.13962634015954636) * v60 + -0.13962634015954636
	else
		v73 = -0.13962634015954636
	end
	if v_u_4.deadAt then
		local v81 = v_u_4
		v81.yaw = v81.yaw + p36 * 0.35
		v56 = v_u_4.yaw
		v73 = -0.4188790204786391
	end
	if v55 then
		local v82 = v_u_4
		local v83 = v_u_4
		local v84 = p40.yaw
		local v85 = p40.pitch
		local v86 = math.clamp(v85, -1.3962634015954636, 1.361356816555577)
		v82.yaw = v84
		v83.pitch = v86
	else
		local v87 = v60 > 0 and 16 or 9
		local v88 = v_u_4
		local v89 = v88.yaw
		local v90 = (v56 - v_u_4.yaw + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
		local v91 = -v87 * p36
		v88.yaw = v89 + v90 * (1 - math.exp(v91))
		local v92 = v_u_4
		local v93 = v92.pitch
		local v94 = v73 - v_u_4.pitch
		local v95 = -(v60 > 0 and 14 or 6) * p36
		v92.pitch = v93 + v94 * (1 - math.exp(v95))
		local v96 = v_u_4
		local v97 = v_u_4.pitch
		v96.pitch = math.clamp(v97, -1.2217304763960306, 1.0471975511965976)
	end
	local v98 = p37 / 1
	local v99 = 1 - (1 - math.clamp(v98, 0, 1)) ^ 3
	local v100 = (17 - v72) * (1 - v99)
	local v101 = (1 - v99) * 4.5
	local v102 = (1 - v99) * 0.5235987755982988
	local v103 = v_u_4
	local v104 = v_u_4.punch - p36 * 1.6
	v103.punch = math.max(0, v104)
	local v105
	if v_u_4.punch > 0.85 then
		v105 = (1 - v_u_4.punch) / 0.15
	else
		v105 = v_u_4.punch / 0.85
	end
	local v106
	if v55 then
		v106 = p40.fov - v105 * 4
	else
		v106 = v_u_4.aimFovW * -20 + 70 - v105 * 6
	end
	if v_u_4.deadAt then
		local v107 = (p37 - v_u_4.deadAt) * 2
		v72 = v72 + math.min(3, v107)
	end
	local v108 = CFrame.fromEulerAnglesYXZ(v_u_4.pitch - (1 - v99) * 0.10471975511965978, v_u_4.yaw + v102, 0)
	local v109 = table.create(4, 0)
	local v110 = table.create(4, Vector3.new(0, 0, 0))
	for v111 = 1, 4 do
		local v112 = v72 + v100
		local v113
		if v111 == 1 then
			v113 = Vector3.new(v71, 0, v112)
		elseif v111 == 2 then
			local v114 = -v71
			v113 = Vector3.new(v114, 0, v112)
		elseif v111 == 3 then
			local v115 = v71 * 0.7
			local v116 = v112 * 0.8
			v113 = Vector3.new(v115, -1.6, v116)
		else
			local v117 = v71 * 0.7
			local v118 = v112 * 0.85
			v113 = Vector3.new(v117, 2.2, v118)
		end
		local v119 = v101 + v70 * 0.5
		local v120 = v113 + Vector3.new(0, v119, 0)
		v110[v111] = v120
		local v121 = v108:VectorToWorldSpace(v120)
		local v122 = v121.Magnitude
		if v122 < 0.001 then
			v122 = 0
		else
			local v123 = v_u_1:Spherecast(v51, 0.6, v121, v_u_5)
			if v123 then
				v122 = v123.Distance
			end
		end
		v109[v111] = v122 / v120.Magnitude
	end
	local v124 = v_u_4.arm
	if v109[1] >= 0.92 then
		v124 = 1
	elseif v109[v124] < 0.92 then
		local v125 = v109[1] > v109[v124] + 0.15 and 1 or v124
		local v126 = v109[2] > v109[v125] + 0.15 and 2 or v125
		local v127 = v109[3] > v109[v126] + 0.15 and 3 or v126
		v124 = v109[4] > v109[v127] + 0.15 and 4 or v127
	end
	v_u_4.arm = v124
	local v128 = v_u_4
	local v129 = v_u_4.offset
	local v130 = v110[v124]
	local v131 = p36 * -7
	v128.offset = v129:Lerp(v130, 1 - math.exp(v131))
	local v132 = v108:VectorToWorldSpace(v_u_4.offset)
	local v133 = v132.Magnitude
	if v133 < 0.001 then
		v133 = 0
	else
		local v134 = v_u_1:Spherecast(v51, 0.6, v132, v_u_5)
		if v134 then
			v133 = v134.Distance
		end
	end
	local v135 = v133 - 0.2
	local v136 = v132.Magnitude
	local v137 = math.min(v135, v136)
	local v138 = v132.Magnitude
	local v139 = math.min(3.2, v138)
	local v140 = math.max(v137, v139)
	local v141 = v51 + v132.Unit * v140
	local v142 = CFrame.lookAt(v141, v141 + v108.LookVector)
	local v143 = v55 and (p40 and (p40.first and (p40.eye and p37 >= 0.7))) and 1 or 0
	if v_u_4.fpW < v143 then
		local v144 = v_u_4
		local v145 = v_u_4.fpW + p36 / 0.2
		v144.fpW = math.min(v143, v145)
	elseif v143 < v_u_4.fpW then
		local v146 = v_u_4
		local v147 = v_u_4.fpW - p36 / 0.2
		v146.fpW = math.max(v143, v147)
	end
	v_u_4.firstPerson = v_u_4.fpW >= 0.5
	local v148
	if v_u_4.fpW > 0 and (p40 and p40.eye) then
		local v149 = CFrame.new
		local v150 = p40.eye
		local v151 = p40.bobY
		local v152 = v149(v150 + Vector3.new(0, v151, 0))
		local v153 = CFrame.fromEulerAnglesYXZ
		local v154 = p40.pitch
		v148 = v152 * v153(math.clamp(v154, -1.3962634015954636, 1.361356816555577), p40.yaw, 0) * CFrame.Angles(0, 0, p40.bobRoll)
		local v155 = v_u_4.fpW * v_u_4.fpW * (3 - v_u_4.fpW * 2)
		if v155 < 1 then
			v148 = v142:Lerp(v148, v155)
		end
	else
		v148 = v142
	end
	p35.CFrame = v148
	p35.FieldOfView = v106
end
function v2.Stats() -- name: Stats
	-- upvalues: (copy) v_u_4
	return {
		["aimW"] = v_u_4.aimW,
		["arm"] = v_u_4.arm,
		["offset"] = v_u_4.offset,
		["pivotY"] = v_u_4.pivotY,
		["segments"] = #v_u_4.segments
	}
end
return v2