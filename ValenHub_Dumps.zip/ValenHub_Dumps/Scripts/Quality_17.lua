local v_u_1 = game:GetService("Players")
local v2 = game:GetService("UserInputService")
local v_u_3 = {}
local v_u_4 = {
	["High"] = {
		["stepCap"] = 14,
		["stepRadius"] = 90,
		["maxSteps"] = 16,
		["remoteHz"] = 20,
		["remoteDust"] = true,
		["dustScale"] = 1,
		["twistRange"] = 70,
		["propFadeEvery"] = 1
	},
	["Medium"] = {
		["stepCap"] = 10,
		["stepRadius"] = 70,
		["maxSteps"] = 12,
		["remoteHz"] = 15,
		["remoteDust"] = true,
		["dustScale"] = 0.75,
		["twistRange"] = 45,
		["propFadeEvery"] = 2
	},
	["Low"] = {
		["stepCap"] = 6,
		["stepRadius"] = 45,
		["maxSteps"] = 8,
		["remoteHz"] = 10,
		["remoteDust"] = false,
		["dustScale"] = 0.5,
		["twistRange"] = 25,
		["propFadeEvery"] = 4
	}
}
local v5 = v2.TouchEnabled
if v5 then
	v5 = not v2.MouseEnabled
end
v_u_3.level = v5 and "Medium" or "High"
v_u_3.budget = v_u_4[v_u_3.level]
local v_u_6 = false
local function v_u_11(p7) -- name: refresh
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v8 = p7:GetAttribute("CharacterQuality")
	local v9 = p7:GetAttribute("CombatQualityLevel")
	local v10 = v_u_3.level
	if v8 == "Low" or (v8 == "Medium" or v8 == "High") then
		v9 = v8
	elseif v9 ~= "Low" and (v9 ~= "Medium" and v9 ~= "High") then
		v9 = v10
	end
	v_u_3.level = v9
	v_u_3.budget = v_u_4[v9]
	p7:SetAttribute("CharacterQualityLevel", v9)
end
function v_u_3.Start() -- name: Start
	-- upvalues: (ref) v_u_6, (copy) v_u_1, (copy) v_u_11
	if v_u_6 then
		return
	else
		v_u_6 = true
		local v12 = v_u_1.LocalPlayer
		local v_u_13 = v12:FindFirstChildOfClass("PlayerScripts") or v12:WaitForChild("PlayerScripts", 10)
		if v_u_13 then
			v_u_11(v_u_13)
			v_u_13:GetAttributeChangedSignal("CharacterQuality"):Connect(function()
				-- upvalues: (ref) v_u_11, (copy) v_u_13
				v_u_11(v_u_13)
			end)
			v_u_13:GetAttributeChangedSignal("CombatQualityLevel"):Connect(function()
				-- upvalues: (ref) v_u_11, (copy) v_u_13
				v_u_11(v_u_13)
			end)
		end
	end
end
return v_u_3