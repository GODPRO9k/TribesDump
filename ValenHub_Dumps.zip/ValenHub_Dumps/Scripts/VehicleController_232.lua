local v_u_1 = script.Parent.Parent:WaitForChild("InputContexts"):WaitForChild("VehicleContext")
local v_u_2 = v_u_1:WaitForChild("ThrottleAction")
local v_u_3 = v_u_1:WaitForChild("SteerAction")
require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
local v_u_4 = {}
v_u_4.__index = v_u_4
function v_u_4.new() -- name: new
	-- upvalues: (copy) v_u_4
	local v5 = v_u_4
	local v6 = setmetatable({}, v5)
	v6.enabled = false
	v6.vehicleSeat = nil
	return v6
end
function v_u_4.Enable(p7, p8, p9) -- name: Enable
	-- upvalues: (copy) v_u_1
	if p8 == p7.enabled and p9 == p7.vehicleSeat then
		return
	else
		p7.enabled = p8
		if p8 then
			if p9 then
				p7.vehicleSeat = p9
				v_u_1.Enabled = true
			end
		else
			v_u_1.Enabled = false
			p7.vehicleSeat = nil
			return
		end
	end
end
function v_u_4.Update(p10, p11, p12) -- name: Update
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	if not p10.vehicleSeat then
		return p11, false
	end
	if not p12 then
		local v13 = p10.vehicleSeat.Occupant.RootPart.CFrame:VectorToObjectSpace(p11)
		p10.vehicleSeat.ThrottleFloat = p10:ComputeThrottle(v13)
		p10.vehicleSeat.SteerFloat = p10:ComputeSteer(v13)
		return Vector3.new(0, 0, 0), true
	end
	local v14 = v_u_2:GetState()
	local v15 = v_u_3:GetState()
	local v16 = -v14
	local v17 = p11 + Vector3.new(v15, 0, v16)
	p10.vehicleSeat.ThrottleFloat = -v17.Z
	p10.vehicleSeat.SteerFloat = v17.X
	return v17, true
end
function v_u_4.ComputeThrottle(_, p18) -- name: ComputeThrottle
	return p18 == Vector3.new(0, 0, 0) and 0 or -p18.Z
end
function v_u_4.ComputeSteer(_, p19) -- name: ComputeSteer
	if p19 == Vector3.new(0, 0, 0) then
		return 0
	end
	local v20 = -p19.x
	local v21 = -p19.z
	return -math.atan2(v20, v21) * 57.29577951308232
end
return v_u_4