local v_u_10 = {
	["CONTEXT"] = "TribesInputs",
	["ACTIONS"] = {
		{
			["name"] = "Slide",
			["kind"] = nil,
			["keys"] = nil,
			["kind"] = Enum.InputActionType.Bool,
			["keys"] = { Enum.KeyCode.C, Enum.KeyCode.LeftControl, Enum.KeyCode.ButtonB }
		},
		{
			["name"] = "Jump",
			["kind"] = nil,
			["keys"] = nil,
			["kind"] = Enum.InputActionType.Bool,
			["keys"] = { Enum.KeyCode.Space, Enum.KeyCode.ButtonA }
		},
		{
			["name"] = "Aim",
			["kind"] = nil,
			["keys"] = nil,
			["kind"] = Enum.InputActionType.Bool,
			["keys"] = {}
		},
		{
			["name"] = "Charge",
			["kind"] = nil,
			["keys"] = nil,
			["kind"] = Enum.InputActionType.Bool,
			["keys"] = {}
		},
		{
			["name"] = "Block",
			["kind"] = nil,
			["keys"] = nil,
			["kind"] = Enum.InputActionType.Bool,
			["keys"] = {}
		},
		{
			["name"] = "Reload",
			["kind"] = nil,
			["keys"] = nil,
			["kind"] = Enum.InputActionType.Bool,
			["keys"] = {}
		},
		{
			["name"] = "Use",
			["kind"] = nil,
			["keys"] = nil,
			["kind"] = Enum.InputActionType.Bool,
			["keys"] = {}
		},
		{
			["name"] = "Lunge",
			["kind"] = nil,
			["keys"] = nil,
			["kind"] = Enum.InputActionType.Bool,
			["keys"] = {}
		},
		{
			["name"] = "Facing",
			["kind"] = nil,
			["keys"] = nil,
			["kind"] = Enum.InputActionType.Direction2D,
			["keys"] = {}
		},
		{
			["name"] = "Look",
			["kind"] = nil,
			["keys"] = nil,
			["kind"] = Enum.InputActionType.Direction2D,
			["keys"] = {}
		},
		{
			["name"] = "Hold",
			["kind"] = nil,
			["keys"] = nil,
			["kind"] = Enum.InputActionType.Direction1D,
			["keys"] = {}
		}
	},
	["HOLD_SCALE"] = 8,
	["HOLD_SLOTS"] = 7,
	["Build"] = function(p1) -- name: Build
		-- upvalues: (copy) v_u_10
		local v2 = p1:FindFirstChild(v_u_10.CONTEXT)
		if v2 and v2:IsA("InputContext") then
			return v2
		end
		local v3 = Instance.new("InputContext")
		v3.Name = v_u_10.CONTEXT
		for _, v4 in v_u_10.ACTIONS do
			local v5 = Instance.new("InputAction")
			v5.Name = v4.name
			v5.Type = v4.kind
			for v6, v7 in v4.keys do
				local v8 = Instance.new("InputBinding")
				v8.Name = "Key" .. v6
				v8.KeyCode = v7
				v8.Parent = v5
			end
			local v9 = Instance.new("InputBinding")
			v9.Name = "Script"
			v9.Type = Enum.InputBindingType.Scriptable
			v9.Parent = v5
			v5.Parent = v3
		end
		v3.Parent = p1
		return v3
	end
}
return v_u_10