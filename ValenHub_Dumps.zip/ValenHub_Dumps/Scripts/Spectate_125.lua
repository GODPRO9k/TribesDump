local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
return {
	["Init"] = function(p_u_3) -- name: Init
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		local v_u_4 = p_u_3.UI
		local v_u_5 = p_u_3.Theme
		local v_u_6 = p_u_3.State
		local v_u_7 = p_u_3.Portraits
		local v_u_8 = p_u_3.WeaponIcon
		local v_u_9 = v_u_5.Colors
		local v10 = v_u_5.Fonts
		local v_u_11 = v_u_1.LocalPlayer
		local v12 = v_u_4.new("Frame", {
			["Name"] = "Spectate",
			["Size"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = p_u_3.Canvas.HUD
		})
		local v_u_13 = v_u_4.new("Frame", {
			["Name"] = "EliminatedBy",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.fromScale(0.5, 0.58),
			["Size"] = UDim2.fromOffset(470, 116),
			["Parent"] = v12
		})
		local v_u_14 = v_u_4.Panel({
			["Name"] = "Inner",
			["Size"] = nil,
			["BackgroundTransparency"] = 0.12,
			["StrokeColor"] = nil,
			["StrokeTransparency"] = 0.3,
			["Trim"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["StrokeColor"] = v_u_9.Enemy,
			["Trim"] = v_u_9.Enemy,
			["Parent"] = v_u_13
		})
		local v_u_15 = v_u_4.new("ImageLabel", {
			["Name"] = "Killer",
			["Position"] = UDim2.fromOffset(14, 14),
			["Size"] = UDim2.fromOffset(88, 88),
			["BackgroundColor3"] = v_u_5.Darken(v_u_9.Enemy, 0.6),
			["ScaleType"] = Enum.ScaleType.Crop,
			v_u_4.Corner(v_u_5.Radius.Pill),
			v_u_4.Stroke(v_u_9.Enemy, 2.5, 0.1),
			["Parent"] = v_u_14
		})
		local v_u_16 = v_u_4.DisplayText({
			["Name"] = "Title",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "ELIMINATED BY",
			["TextSize"] = 26,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["StrokeThickness"] = 2,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(118, 12),
			["Size"] = UDim2.new(1, -190, 0, 32),
			["TextColor3"] = v_u_9.Enemy,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v_u_14
		})
		local v_u_17 = v_u_4.new("TextLabel", {
			["Name"] = "Name",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextScaled"] = true,
			["TextXAlignment"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(118, 44),
			["Size"] = UDim2.new(1, -190, 0, 34),
			["FontFace"] = v10.Heavy,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v_u_14
		})
		v_u_4.new("UITextSizeConstraint", {
			["MaxTextSize"] = 30,
			["MinTextSize"] = 12,
			["Parent"] = nil,
			["Parent"] = v_u_17
		})
		v_u_4.TextStroke(v_u_9.Void, 1.5, 0.3).Parent = v_u_17
		local v_u_18 = v_u_4.new("TextLabel", {
			["Name"] = "Sub",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 16,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(118, 80),
			["Size"] = UDim2.new(1, -190, 0, 20),
			["FontFace"] = v10.Bold,
			["TextColor3"] = v_u_9.TextDim,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v_u_14
		})
		local v_u_19 = v_u_4.new("Frame", {
			["Name"] = "Weapon",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -14, 0.5, 0),
			["Size"] = UDim2.fromOffset(64, 64),
			["Parent"] = v_u_14
		})
		local v_u_20 = 0
		local function v_u_34(p21, p22, p23, p24, p25) -- name: showCard
			-- upvalues: (ref) v_u_20, (copy) v_u_16, (copy) v_u_17, (copy) v_u_9, (copy) v_u_15, (copy) v_u_7, (copy) v_u_4, (copy) p_u_3, (copy) v_u_18, (copy) v_u_8, (copy) v_u_19, (copy) v_u_13, (copy) v_u_14, (copy) v_u_5
			v_u_20 = v_u_20 + 1
			local v_u_26 = v_u_20
			v_u_16.Text = p21 == "" and "YOU WERE ELIMINATED" or "ELIMINATED BY"
			v_u_17.Text = p21
			local v27 = v_u_17
			local v28
			if p25 then
				v28 = v_u_9.Ally
			else
				v28 = v_u_9.Text
			end
			v27.TextColor3 = v28
			v_u_15.Visible = p21 ~= ""
			if p22 then
				v_u_7.Apply(v_u_15, p22, 150)
			else
				v_u_15.Image = v_u_4.Assets.Icons.Skull
				v_u_15.ScaleType = Enum.ScaleType.Fit
			end
			local v29 = {}
			if type(p23) == "string" and p23 ~= "" then
				local v30 = string.upper
				local v31 = p_u_3.WeaponInfo.Name
				table.insert(v29, v30(v31(p23)))
			end
			if p24 then
				table.insert(v29, "HEADSHOT")
			end
			v_u_18.Text = table.concat(v29, "  \194\183  ")
			local v32 = v_u_8.Set
			local v33 = v_u_19
			if type(p23) ~= "string" or p23 == "" then
				p23 = nil
			end
			v32(v33, p23)
			v_u_13.Visible = true
			v_u_4.Unfade(v_u_14)
			v_u_4.SlideIn(v_u_14, Vector2.new(0, 30), v_u_5.Tween.PopSmall, UDim2.new())
			task.delay(3.2, function()
				-- upvalues: (copy) v_u_26, (ref) v_u_20, (ref) v_u_4, (ref) v_u_14, (ref) v_u_13
				if v_u_26 == v_u_20 then
					v_u_4.FadeOut(v_u_14, TweenInfo.new(0.3))
					task.delay(0.32, function()
						-- upvalues: (ref) v_u_26, (ref) v_u_20, (ref) v_u_13
						if v_u_26 == v_u_20 then
							v_u_13.Visible = false
						end
					end)
				end
			end)
		end
		local v_u_35 = nil
		local v_u_36 = v_u_4.new("Frame", {
			["Name"] = "Respawn",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, v_u_4.Compact and 0.3 or 0.36),
			["Size"] = UDim2.fromOffset(500, 220),
			["Parent"] = v12
		})
		local v_u_37 = v_u_4.new("TextLabel", {
			["Name"] = "Tag",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "RESPAWNING IN",
			["FontFace"] = nil,
			["TextSize"] = 26,
			["TextColor3"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 0.5, -70),
			["Size"] = UDim2.fromOffset(500, 30),
			["FontFace"] = v10.Heavy,
			["TextColor3"] = v_u_9.Accent,
			["Parent"] = v_u_36
		})
		v_u_4.TextStroke(v_u_9.Void, 2, 0.2).Parent = v_u_37
		local v_u_38 = v_u_4.new("TextLabel", {
			["Name"] = "Digit",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 100,
			["TextColor3"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(0.5, 0, 0.5, 8),
			["Size"] = UDim2.fromOffset(300, 130),
			["FontFace"] = v10.Display,
			["TextColor3"] = v_u_9.Bone,
			["Parent"] = v_u_36
		})
		v_u_4.TextStroke(v_u_9.Void, 2, 0.15).Parent = v_u_38
		local v_u_39 = v_u_4.new("UIScale", {
			["Parent"] = v_u_38
		})
		v_u_4.LayoutChanged:Connect(function()
			-- upvalues: (copy) v_u_36, (copy) v_u_4
			v_u_36.Position = UDim2.fromScale(0.5, v_u_4.Compact and 0.3 or 0.36)
		end)
		local v_u_40 = nil
		local function v_u_51(p_u_41) -- name: startRespawn
			-- upvalues: (ref) v_u_40, (ref) v_u_35, (copy) v_u_36, (copy) v_u_38, (copy) v_u_4, (copy) v_u_37, (ref) v_u_2, (copy) v_u_11, (copy) p_u_3, (copy) v_u_39
			if v_u_40 then
				v_u_40:Disconnect()
				v_u_40 = nil
				v_u_35()
			end
			v_u_36.Visible = false
			local v_u_42 = os.clock() + p_u_41
			local v_u_43 = 0
			v_u_38.Text = ""
			v_u_36.Visible = true
			v_u_4.Unfade(v_u_37)
			v_u_40 = v_u_2.RenderStepped:Connect(function()
				-- upvalues: (ref) v_u_40, (copy) v_u_42, (ref) v_u_11, (copy) p_u_41, (ref) v_u_35, (ref) v_u_36, (ref) v_u_43, (ref) v_u_38, (ref) p_u_3, (ref) v_u_39, (ref) v_u_4
				if v_u_40 then
					local v44 = v_u_42 - os.clock()
					if v44 <= 0 or v_u_11:GetAttribute("Alive") == true and v44 < p_u_41 - 0.5 then
						if v_u_40 then
							v_u_40:Disconnect()
							v_u_40 = nil
							v_u_35()
						end
						v_u_36.Visible = false
					else
						local v45 = math.ceil(v44)
						local v46 = v45 - v44
						if v45 ~= v_u_43 then
							v_u_43 = v45
							v_u_38.Text = tostring(v45)
							if v45 <= 3 then
								p_u_3.Sounds.Play("Match/Countdown_" .. v45)
							end
						end
						local v47
						if v46 < 0.2 then
							local v48 = v46 / 0.2 - 1
							v47 = 1.4 - (v48 * 2.5 * v48 * v48 + 1 + v48 * 1.5 * v48) * 0.4
						else
							v47 = 1 - 0.03 * (v46 - 0.2) / 0.8
						end
						v_u_39.Scale = (v_u_4.Compact and 1.3 or 1.6) * v47
						local v49 = v_u_38
						local v50 = v46 / 0.06
						v49.TextTransparency = 1 - math.min(1, v50)
					end
				else
					return
				end
			end)
			v_u_35()
		end
		local v_u_52 = v_u_4.Panel({
			["Name"] = "SpectateBar",
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["BackgroundTransparency"] = 0.15,
			["Trim"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Size"] = UDim2.fromOffset(440, 76),
			["Trim"] = v_u_9.Accent,
			["Parent"] = v12
		})
		local v_u_53 = v_u_4.new("TextLabel", {
			["Name"] = "Tag",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "SPECTATING",
			["FontFace"] = nil,
			["TextSize"] = 15,
			["TextColor3"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(84, 8),
			["Size"] = UDim2.new(1, -168, 0, 20),
			["FontFace"] = v10.Heavy,
			["TextColor3"] = v_u_9.TextDim,
			["Parent"] = v_u_52
		})
		local v_u_54 = v_u_4.new("TextLabel", {
			["Name"] = "Target",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextScaled"] = true,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(84, 28),
			["Size"] = UDim2.new(1, -168, 0, 36),
			["FontFace"] = v10.Display,
			["Parent"] = v_u_52
		})
		v_u_4.new("UITextSizeConstraint", {
			["MaxTextSize"] = 30,
			["MinTextSize"] = 12,
			["Parent"] = nil,
			["Parent"] = v_u_54
		})
		v_u_4.TextStroke(v_u_9.Void, 2, 0.2).Parent = v_u_54
		local v_u_58 = v_u_4.IconButton({
			["Name"] = "Prev",
			["IconName"] = "chevLeft",
			["IconScale"] = 0.5,
			["Size"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Color"] = nil,
			["Parent"] = nil,
			["OnClick"] = nil,
			["Size"] = UDim2.fromOffset(64, 60),
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 8, 0.5, 0),
			["Color"] = v_u_9.Raised,
			["Parent"] = v_u_52,
			["OnClick"] = function() -- name: OnClick
				-- upvalues: (copy) p_u_3
				local v55 = p_u_3.MenuManager.Camera()
				if v55 then
					local v56 = v55.SpectateNext
					if type(v56) == "function" then
						local v57 = v55.SpectateNext
						pcall(v57, -1)
					end
				end
			end
		})
		local v_u_62 = v_u_4.IconButton({
			["Name"] = "Next",
			["IconName"] = "chevRight",
			["IconScale"] = 0.5,
			["Size"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Color"] = nil,
			["Parent"] = nil,
			["OnClick"] = nil,
			["Size"] = UDim2.fromOffset(64, 60),
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -8, 0.5, 0),
			["Color"] = v_u_9.Raised,
			["Parent"] = v_u_52,
			["OnClick"] = function() -- name: OnClick
				-- upvalues: (copy) p_u_3
				local v59 = p_u_3.MenuManager.Camera()
				if v59 then
					local v60 = v59.SpectateNext
					if type(v60) == "function" then
						local v61 = v59.SpectateNext
						pcall(v61, 1)
					end
				end
			end
		})
		local v_u_63 = v_u_4.Button({
			["Name"] = "StopWatching",
			["Text"] = "STOP WATCHING",
			["TextSize"] = 17,
			["Style"] = "Dark",
			["Icon"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["Icon"] = v_u_4.Glyph("door-open-arrow-to-bottom-right", 18, v_u_9.TextDim),
			["Size"] = UDim2.fromOffset(230, 46),
			["Parent"] = v_u_52
		})
		v_u_63.Instance.AnchorPoint = Vector2.new(0.5, 1)
		v_u_63.Instance.Position = UDim2.new(0.5, 0, 0, -10)
		local v_u_64 = false
		v_u_63.Activated:Connect(function()
			-- upvalues: (ref) v_u_64, (copy) p_u_3, (copy) v_u_63
			if not v_u_64 and p_u_3.Custom then
				v_u_64 = true
				v_u_63:SetText("\226\128\166")
				task.spawn(function()
					-- upvalues: (ref) p_u_3, (ref) v_u_64, (ref) v_u_63
					local v65, v66 = p_u_3.Custom.Action("Watch", false)
					v_u_64 = false
					v_u_63:SetText("STOP WATCHING")
					if not v65 and v66 then
						p_u_3.Toast(tostring(v66), "error")
					end
				end)
			end
		end)
		local v_u_67 = true
		local function v_u_70() -- name: layout
			-- upvalues: (copy) p_u_3, (copy) v_u_52, (copy) v_u_4, (ref) v_u_67, (copy) v_u_53, (copy) v_u_54
			if p_u_3.HotbarTop then
				p_u_3.HotbarTop()
			end
			v_u_52.Position = UDim2.new(0.5, 0, 1, -(v_u_4.Compact and 16 or 40))
			local v68 = v_u_67 and 84 or 20
			local v69 = v_u_67 and (v_u_4.Compact and 460 or 440) or 320
			v_u_52.Size = UDim2.fromOffset(v69, v_u_4.Touch and 84 or 76)
			v_u_53.Position = UDim2.fromOffset(v68, 8)
			v_u_53.Size = UDim2.new(1, v68 * -2, 0, 20)
			v_u_54.Position = UDim2.fromOffset(v68, 28)
			v_u_54.Size = UDim2.new(1, v68 * -2, 0, 36)
		end
		v_u_70()
		v_u_4.LayoutChanged:Connect(v_u_70)
		local v_u_71 = ""
		local v_u_72 = ""
		local function v91() -- name: refreshBar
			-- upvalues: (copy) v_u_6, (copy) p_u_3, (ref) v_u_40, (ref) v_u_72, (copy) v_u_63, (ref) v_u_67, (copy) v_u_70, (copy) v_u_58, (copy) v_u_62, (ref) v_u_71, (copy) v_u_54, (copy) v_u_5, (copy) v_u_9, (copy) v_u_53, (copy) v_u_52, (copy) v_u_4
			local v73 = v_u_6.Get("SpectateMode")
			local v74 = v_u_6.Watching()
			local v75 = (v_u_6.InMatch() or v74) and (v73 == "follow" and not p_u_3.HudHidden)
			if v75 then
				v75 = v_u_40 == nil
			end
			local v76 = v_u_6.Get("SpectateTargetName")
			local v77 = v_u_6.Get("SpectateTargetId")
			if v74 and (type(v77) == "string" and (v77 ~= "" and (v77 ~= v_u_72 and p_u_3.Custom))) then
				v_u_72 = v77
				task.spawn(p_u_3.Custom.Action, "WatchTarget", v77)
			elseif not v74 then
				v_u_72 = ""
			end
			local v78 = v_u_63.Instance
			local v79
			if v74 then
				v79 = not p_u_3.HudHidden
			else
				v79 = v74
			end
			v78.Visible = v79
			if v75 then
				local v80 = v_u_6.Get("SpectateCount")
				local v81 = (type(v80) ~= "number" and 0 or v80) > 1
				if v81 ~= v_u_67 then
					v_u_67 = v81
					v_u_70()
				end
				v_u_58.Visible = v_u_67
				v_u_62.Visible = v_u_67
				local v82 = v_u_6.Get("SpectateTargetId")
				local v83, v84 = v_u_6.FindMember(v82)
				local v85 = v84 == nil and true or v_u_6.IsAllyTeam(v84)
				local v86 = string.upper
				if type(v76) ~= "string" or v76 == "" then
					if v83 then
						v76 = v83.name
					else
						v76 = v74 and "Loading the match..." or "?"
					end
				end
				local v87 = v86((tostring(v76)))
				local v88 = v87 ~= v_u_71
				v_u_71 = v87
				v_u_54.Text = v87
				local v89 = v_u_54
				local v90
				if v85 then
					v90 = v_u_5.Lighten(v_u_9.Ally, 0.2)
				else
					v90 = v_u_5.Lighten(v_u_9.Enemy, 0.1)
				end
				v89.TextColor3 = v90
				v_u_53.Text = v74 and "WATCHING" or "SPECTATING"
				if not v_u_52.Visible then
					v_u_52.Visible = true
					v_u_4.Unfade(v_u_52)
					v_u_4.SlideIn(v_u_52, Vector2.new(0, 30), v_u_5.Tween.PopSmall)
					p_u_3.MenuManager.PushMouse("Spectate")
					return
				end
				if v88 then
					v_u_4.Bump(v_u_54, 0.06)
					return
				end
			elseif v_u_52.Visible then
				v_u_52.Visible = false
				p_u_3.MenuManager.PopMouse("Spectate")
			end
		end
		local v_u_92 = v_u_20
		local v_u_93 = v_u_40
		local v_u_94 = v91
		for _, v95 in {
			"SpectateMode",
			"SpectateTargetId",
			"SpectateTargetName",
			"SpectateKillerName",
			"SpectateCount"
		} do
			v_u_11:GetAttributeChangedSignal(v95):Connect(v_u_94)
		end
		v_u_6.AttrChanged:Connect(function(p96)
			-- upvalues: (ref) v_u_94, (copy) v_u_6, (ref) v_u_92, (copy) v_u_13
			if p96 == "SpectateMode" or (p96 == "SpectateTargetName" or (p96 == "SpectateCount" or p96 == "State")) then
				v_u_94()
			end
			if p96 == "Alive" and v_u_6.Get("Alive") == true then
				v_u_92 = v_u_92 + 1
				v_u_13.Visible = false
			end
		end)
		p_u_3.HudHiddenChanged:Connect(v_u_94)
		v_u_6.PlayerStateChanged:Connect(function(p97)
			-- upvalues: (ref) v_u_92, (copy) v_u_13, (ref) v_u_94
			if p97 ~= "Match" then
				v_u_92 = v_u_92 + 1
				v_u_13.Visible = false
			end
			v_u_94()
		end)
		v_u_6.WatchChanged:Connect(function()
			-- upvalues: (copy) v_u_70, (ref) v_u_94
			v_u_70()
			v_u_94()
		end)
		p_u_3.OnMatchEvent(function(p98, p99)
			-- upvalues: (copy) v_u_6, (copy) v_u_34, (copy) v_u_51, (ref) v_u_92, (copy) v_u_13, (ref) v_u_93, (ref) v_u_94, (copy) v_u_36
			if p98 == "Elimination" and (type(p99) == "table" and p99.victimId == v_u_6.MyId()) then
				local v100 = p99.killerName
				local v101
				if type(v100) == "string" and p99.killerName ~= "" then
					v101 = p99.killerId ~= p99.victimId
				else
					v101 = false
				end
				local v102
				if v101 then
					v102 = v_u_6.FindMember(p99.killerId)
				else
					v102 = nil
				end
				local v103 = v_u_34
				local v104 = not v101 and "" or p99.killerName
				local v105 = p99.weaponId
				local v106 = p99.headshot == true
				if v101 then
					v101 = v_u_6.IsAllyTeam(p99.killerTeam)
				end
				v103(v104, v102, v105, v106, v101)
				local v107 = p99.secondWind
				local v108 = tonumber(v107)
				if v108 and v108 > 0 then
					v_u_51(v108)
					return
				end
			elseif p98 == "RoundStart" or (p98 == "RoundEnd" or p98 == "MatchEnd") then
				v_u_92 = v_u_92 + 1
				v_u_13.Visible = false
				if v_u_93 then
					v_u_93:Disconnect()
					v_u_93 = nil
					v_u_94()
				end
				v_u_36.Visible = false
			end
		end)
		v_u_94()
		function p_u_3.Debug.spectate(p109, p110, p111)
			-- upvalues: (copy) v_u_6, (ref) v_u_94
			v_u_6.SetMockAttr("SpectateMode", p109)
			v_u_6.SetMockAttr("SpectateTargetName", p110)
			v_u_6.SetMockAttr("SpectateCount", p111)
			v_u_94()
			return true
		end
	end
}