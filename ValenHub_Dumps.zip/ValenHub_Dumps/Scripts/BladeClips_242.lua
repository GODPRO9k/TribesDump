local v_u_7 = {
	["Frame"] = function(p1, p2, p3) -- name: Frame
		local v4 = p2.Magnitude <= 0.0001 and Vector3.new(0, 1, 0) or p2.Unit
		local v5 = p3 - v4 * p3:Dot(v4)
		if v5.Magnitude < 0.001 then
			v5 = v4:Cross(Vector3.new(1, 0, 0))
			if v5.Magnitude < 0.001 then
				v5 = v4:Cross(Vector3.new(0, 0, 1))
			end
		end
		local v6 = -v5.Unit
		return CFrame.fromMatrix(p1, v4:Cross(v6), v4, v6)
	end
}
local v8 = {}
local v9 = {
	["contact"] = 0.09,
	["release"] = 0.58,
	["smear"] = nil,
	["keys"] = nil,
	["smear"] = { 0.04, 0.15 },
	["keys"] = {
		{
			["t"] = 0.03,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.46, -0.1, -0.5),
			["tip"] = Vector3.new(0.42, 0.88, -0.22),
			["edge"] = Vector3.new(0.1, 0, -1)
		},
		{
			["t"] = 0.055,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.58, -0.1, -0.5),
			["tip"] = Vector3.new(0.883, 0.2, -0.469),
			["edge"] = Vector3.new(-0.469, 0, -0.883)
		},
		{
			["t"] = 0.09,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.04, -0.2, -0.5),
			["tip"] = Vector3.new(0.574, 0.12, -0.819),
			["edge"] = Vector3.new(-0.819, 0, -0.574)
		},
		{
			["t"] = 0.14,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(-0.64, -0.36, -0.5),
			["tip"] = Vector3.new(-0.139, 0.05, -0.99),
			["edge"] = Vector3.new(-0.99, 0, 0.139)
		},
		{
			["t"] = 0.24,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(-0.86, -0.56, -0.46),
			["tip"] = Vector3.new(-0.866, -0.05, -0.5),
			["edge"] = Vector3.new(-0.5, 0, 0.866)
		},
		{
			["t"] = 0.37,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.22, -0.84, -0.48),
			["tip"] = Vector3.new(-0.2, 0.85, -0.5),
			["edge"] = Vector3.new(-0.6, 0, -0.8)
		},
		{
			["t"] = 0.47,
			["rest"] = nil,
			["rest"] = Vector3.new(0, 0.025, 0)
		},
		{
			["t"] = 0.58,
			["rest"] = nil,
			["rest"] = Vector3.new(0, 0, 0)
		}
	}
}
v8.slash_r = v9
local v10 = {
	["contact"] = 0.09,
	["release"] = 0.5,
	["smear"] = nil,
	["keys"] = nil,
	["smear"] = { 0.04, 0.15 },
	["keys"] = {
		{
			["t"] = 0.03,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(-0.42, -0.66, -0.46),
			["tip"] = Vector3.new(-0.45, 0.8, -0.4),
			["edge"] = Vector3.new(-0.1, 0, -1)
		},
		{
			["t"] = 0.055,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(-0.58, -0.18, -0.5),
			["tip"] = Vector3.new(-0.883, 0.2, -0.469),
			["edge"] = Vector3.new(0.469, 0, -0.883)
		},
		{
			["t"] = 0.09,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(-0.02, -0.17, -0.5),
			["tip"] = Vector3.new(-0.574, 0.14, -0.819),
			["edge"] = Vector3.new(0.819, 0, -0.574)
		},
		{
			["t"] = 0.14,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.64, -0.07, -0.5),
			["tip"] = Vector3.new(0.139, 0.1, -0.99),
			["edge"] = Vector3.new(0.99, 0, 0.139)
		},
		{
			["t"] = 0.24,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.86, -0.3, -0.46),
			["tip"] = Vector3.new(0.75, -0.45, -0.48),
			["edge"] = Vector3.new(0.5, 0, 0.866)
		},
		{
			["t"] = 0.4,
			["rest"] = nil,
			["rest"] = Vector3.new(0, 0.025, 0)
		},
		{
			["t"] = 0.5,
			["rest"] = nil,
			["rest"] = Vector3.new(0, 0, 0)
		}
	}
}
v8.slash_l = v10
local v11 = {
	["contact"] = 0.09,
	["release"] = 0.61,
	["smear"] = nil,
	["keys"] = nil,
	["smear"] = { 0.04, 0.16 },
	["keys"] = {
		{
			["t"] = 0.03,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.4, 0.04, -0.5),
			["tip"] = Vector3.new(0.757, 0.636, 0.151),
			["edge"] = Vector3.new(-0.222, 0.467, -0.856)
		},
		{
			["t"] = 0.055,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.4, 0.18, -0.5),
			["tip"] = Vector3.new(0.187, 0.722, -0.666),
			["edge"] = Vector3.new(-0.766, -0.317, -0.559)
		},
		{
			["t"] = 0.09,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.1, -0.14, -0.5),
			["tip"] = Vector3.new(-0.35, 0.35, -0.869),
			["edge"] = Vector3.new(-0.707, -0.707, 0)
		},
		{
			["t"] = 0.145,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(-0.45, -0.44, -0.5),
			["tip"] = Vector3.new(-0.766, -0.317, -0.559),
			["edge"] = Vector3.new(-0.187, -0.722, 0.666)
		},
		{
			["t"] = 0.26,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(-0.66, -0.66, -0.44),
			["tip"] = Vector3.new(-0.636, -0.757, 0.151),
			["edge"] = Vector3.new(0.467, -0.222, 0.856)
		},
		{
			["t"] = 0.4,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.22, -0.84, -0.48),
			["tip"] = Vector3.new(-0.2, 0.85, -0.5),
			["edge"] = Vector3.new(-0.6, 0, -0.8)
		},
		{
			["t"] = 0.5,
			["rest"] = nil,
			["rest"] = Vector3.new(0, 0.025, 0)
		},
		{
			["t"] = 0.61,
			["rest"] = nil,
			["rest"] = Vector3.new(0, 0, 0)
		}
	}
}
v8.finisher = v11
local v12 = {
	["contact"] = 0,
	["release"] = 0.3,
	["keys"] = nil,
	["keys"] = {
		{
			["t"] = 0.12,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.4, -0.36, -0.56),
			["tip"] = Vector3.new(0.05, 0.55, -0.83),
			["edge"] = Vector3.new(-0.7, 0.1, -0.7)
		},
		{
			["t"] = 0.2,
			["rest"] = nil,
			["rest"] = Vector3.new(0, 0.03, 0)
		},
		{
			["t"] = 0.3,
			["rest"] = nil,
			["rest"] = Vector3.new(0, 0, 0)
		}
	}
}
v8.draw = v12
v_u_7.SWORD = v8
local v13 = {}
local v14 = {
	["contact"] = 0.06,
	["release"] = 0.395,
	["smear"] = nil,
	["keys"] = nil,
	["smear"] = { 0.045, 0.125 },
	["keys"] = {
		{
			["t"] = 0.024,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.42, 0.04, -0.44),
			["tip"] = Vector3.new(-0.347, 0.905, -0.248),
			["edge"] = Vector3.new(-0.132, -0.309, -0.942)
		},
		{
			["t"] = 0.046,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.32, 0.42, -0.44),
			["tip"] = Vector3.new(0.317, 0.766, -0.559),
			["edge"] = Vector3.new(-0.722, -0.187, -0.666)
		},
		{
			["t"] = 0.07,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.06, -0.06, -0.44),
			["tip"] = Vector3.new(-0.35, 0.35, -0.869),
			["edge"] = Vector3.new(-0.707, -0.707, 0)
		},
		{
			["t"] = 0.115,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(-0.48, -0.42, -0.44),
			["tip"] = Vector3.new(-0.78, -0.379, -0.499),
			["edge"] = Vector3.new(-0.119, -0.692, 0.712)
		},
		{
			["t"] = 0.175,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(-0.56, -0.56, -0.4),
			["tip"] = Vector3.new(-0.636, -0.757, 0.151),
			["edge"] = Vector3.new(0.467, -0.222, 0.856)
		},
		{
			["t"] = 0.245,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.2, -0.6, -0.42),
			["tip"] = Vector3.new(-0.2, 0.85, -0.5),
			["edge"] = Vector3.new(-0.6, 0, -0.8)
		},
		{
			["t"] = 0.315,
			["rest"] = nil,
			["rest"] = Vector3.new(0, 0.02, 0)
		},
		{
			["t"] = 0.395,
			["rest"] = nil,
			["rest"] = Vector3.new(0, 0, 0)
		}
	}
}
v13.cut = v14
local v15 = {
	["contact"] = 0.06,
	["release"] = 0.34,
	["smear"] = nil,
	["keys"] = nil,
	["smear"] = { 0.035, 0.12 },
	["keys"] = {
		{
			["t"] = 0.03,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(-0.2, -0.42, -0.44),
			["tip"] = Vector3.new(-0.545, -0.784, 0.297),
			["edge"] = Vector3.new(-0.57, 0.087, -0.817)
		},
		{
			["t"] = 0.07,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.02, -0.08, -0.44),
			["tip"] = Vector3.new(-0.35, 0.35, -0.869),
			["edge"] = Vector3.new(0.707, 0.707, 0)
		},
		{
			["t"] = 0.11,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.5, 0.34, -0.44),
			["tip"] = Vector3.new(0.493, 0.789, -0.367),
			["edge"] = Vector3.new(0.616, -0.018, 0.788)
		},
		{
			["t"] = 0.17,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.62, 0.44, -0.42),
			["tip"] = Vector3.new(0.774, 0.593, 0.225),
			["edge"] = Vector3.new(0.155, -0.521, 0.84)
		},
		{
			["t"] = 0.26,
			["rest"] = nil,
			["rest"] = Vector3.new(0, -0.02, 0)
		},
		{
			["t"] = 0.34,
			["rest"] = nil,
			["rest"] = Vector3.new(0, 0, 0)
		}
	}
}
v13.back = v15
local v16 = {
	["contact"] = 0,
	["release"] = 0.25,
	["keys"] = nil,
	["keys"] = {
		{
			["t"] = 0.07,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.38, -0.42, -0.52),
			["tip"] = Vector3.new(-0.347, 0.905, -0.248),
			["edge"] = Vector3.new(-0.929, -0.294, 0.227)
		},
		{
			["t"] = 0.12,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.35, -0.31, -0.56),
			["tip"] = Vector3.new(-0.347, 0.905, -0.248),
			["edge"] = Vector3.new(0.132, 0.309, 0.942)
		},
		{
			["t"] = 0.17,
			["pos"] = nil,
			["tip"] = nil,
			["edge"] = nil,
			["pos"] = Vector3.new(0.34, -0.25, -0.58),
			["tip"] = Vector3.new(-0.347, 0.905, -0.248),
			["edge"] = Vector3.new(0.929, 0.294, -0.227)
		},
		{
			["t"] = 0.25,
			["rest"] = nil,
			["rest"] = Vector3.new(0, 0, 0)
		}
	}
}
v13.draw = v16
v_u_7.DAGGER = v13
v_u_7.SETS = {
	["Sword"] = v_u_7.SWORD,
	["Dagger"] = v_u_7.DAGGER
}
v_u_7.DRAW = {
	["Sword"] = v_u_7.Frame(Vector3.new(0.46, -0.78, -0.46), Vector3.new(-0.15, -0.2, -0.97), Vector3.new(-0.7, 0.7, 0)),
	["Dagger"] = v_u_7.Frame(Vector3.new(0.42, -0.62, -0.44), Vector3.new(-0.15, -0.2, -0.97), Vector3.new(-0.7, 0.7, 0))
}
function v_u_7.Pick(p17, p18, p19) -- name: Pick
	local v20 = p18 % 2 == 0
	return p17 == "Dagger" and (v20 and "back" or "cut") or (p19 and "finisher" or (v20 and "slash_l" or "slash_r"))
end
function v_u_7.Subdivide(p21, p22, p23) -- name: Subdivide
	local v24 = p23 and {
		["t"] = 0,
		["rest"] = nil,
		["rot"] = nil,
		["rest"] = p23.rest or Vector3.new(0, 0, 0),
		["rot"] = p23.rot or Vector3.new(0, 0, 0)
	} or nil
	local v25 = {}
	local v26 = p22 or 60
	for _, v27 in p21.keys do
		if v24 and (v24.rest and v27.rest) then
			local v28 = v24.rot or Vector3.new(0, 0, 0)
			local v29 = v27.rot or Vector3.new(0, 0, 0)
			local v30 = v29 - v28
			if not v27.rot then
				local v31 = (v28.X + 180) % 360 - 180
				local v32 = (v28.Y + 180) % 360 - 180
				local v33 = (v28.Z + 180) % 360 - 180
				v30 = -Vector3.new(v31, v32, v33)
				v29 = v28 + v30
			end
			local v34 = v30.X
			local v35 = math.abs(v34)
			local v36 = v30.Y
			local v37 = math.abs(v36)
			local v38 = v30.Z
			local v39 = math.abs(v38)
			local v40 = math.max(v35, v37, v39) / v26
			local v41 = math.ceil(v40)
			for v42 = 1, v41 - 1 do
				local v43 = v42 / v41
				local v44 = {
					["t"] = v24.t + (v27.t - v24.t) * v43,
					["rest"] = v24.rest:Lerp(v27.rest, v43),
					["rot"] = v28:Lerp(v29, v43)
				}
				table.insert(v25, v44)
			end
		end
		table.insert(v25, v27)
		v24 = v27
	end
	p21.keys = v25
	return p21
end
function v_u_7.Turn(p45, p46) -- name: Turn
	local v47
	if p46 and p46.Magnitude > 0.001 then
		v47 = CFrame.fromAxisAngle(-p46.Unit, p45.Z * 0.017453292519943295)
	else
		v47 = CFrame.fromEulerAnglesYXZ(0, 0, p45.Z * 0.017453292519943295)
	end
	return v47 * CFrame.fromEulerAnglesYXZ(p45.X * 0.017453292519943295, p45.Y * 0.017453292519943295, 0)
end
function v_u_7.StartFrame(p48, p49) -- name: StartFrame
	-- upvalues: (copy) v_u_7
	if typeof(p48) == "CFrame" then
		return p48
	end
	local v50 = p48.rest or Vector3.new(0, 0, 0)
	local v51 = p48.rot or Vector3.new(0, 0, 0)
	return CFrame.new(p49.Position + v50) * v_u_7.Turn(v51) * p49.Rotation
end
function v_u_7.Eval(p_u_52, p_u_53, p54, p55, p56, p_u_57) -- name: Eval
	-- upvalues: (copy) v_u_7
	local v_u_58 = p55 or 1
	local v_u_59 = p56 or CFrame.identity
	local v_u_60 = p_u_52.keys
	local v_u_61 = #v_u_60
	local function v_u_70(p62, p63) -- name: knotV
		-- upvalues: (copy) p_u_53, (copy) v_u_60, (copy) v_u_59, (ref) v_u_7, (copy) p_u_52
		if p62 == 0 then
			if p63 == 1 then
				return p_u_53.Position
			elseif p63 == 2 then
				return p_u_53.UpVector
			else
				return p_u_53.LookVector
			end
		else
			local v64 = v_u_60[p62]
			if v64.rest then
				local v65 = v64.rot
				local v66 = v_u_59
				if v65 then
					local v67 = v_u_7.Turn
					local v68
					if p_u_52.eyeRoll then
						v68 = v_u_59.Position + v64.rest
					else
						v68 = nil
					end
					v66 = v67(v65, v68) * v_u_59.Rotation
				end
				if p63 == 1 then
					local v69 = v_u_59.Position + v64.rest
					if p_u_52.pivot and v65 then
						v69 = v69 + (v_u_59.UpVector - v66.UpVector) * p_u_52.pivot
					end
					return v69
				elseif p63 == 2 then
					return v66.UpVector
				else
					return v66.LookVector
				end
			elseif p63 == 1 then
				return v64.pos
			elseif p63 == 2 then
				return v64.tip.Unit
			else
				return v64.edge.Unit
			end
		end
	end
	if (v_u_61 == 0 and 0 or v_u_60[v_u_61].t * v_u_58) <= p54 then
		return v_u_7.Frame(v_u_70(v_u_61, 1), v_u_70(v_u_61, 2), (v_u_70(v_u_61, 3)))
	end
	local v71 = 0
	while v71 < v_u_61 - 1 do
		local v72 = v71 + 1
		if (v72 == 0 and 0 or v_u_60[v72].t * v_u_58) >= p54 then
			break
		end
		v71 = v71 + 1
	end
	local v73 = v71 == 0 and 0 or v_u_60[v71].t * v_u_58
	local v74 = v71 + 1
	local v75 = (v74 == 0 and 0 or v_u_60[v74].t * v_u_58) - v73
	local v76 = math.max(v75, 0.0001)
	local v77 = (p54 - v73) / v76
	local v78 = math.clamp(v77, 0, 1)
	local v79 = v78 * v78
	local v80 = v78 * v78 * v78
	local v81 = v80 * 2 - v79 * 3 + 1
	local v82 = v80 - v79 * 2 + v78
	local v83 = v80 * -2 + v79 * 3
	local v84 = v80 - v79
	local v85 = {}
	local function v93(p86, p87) -- name: tangent
		-- upvalues: (copy) p_u_57, (copy) v_u_61, (copy) v_u_70, (copy) v_u_60, (copy) v_u_58
		if p86 <= 0 then
			if p_u_57 then
				if p87 == 1 then
					return p_u_57.pos
				elseif p87 == 2 then
					return p_u_57.tip
				else
					return p_u_57.edge
				end
			else
				return Vector3.new(0, 0, 0)
			end
		else
			if v_u_61 <= p86 then
				return Vector3.new(0, 0, 0)
			end
			local v88 = v_u_70(p86 + 1, p87) - v_u_70(p86 - 1, p87)
			local v89 = p86 + 1
			local v90 = v89 == 0 and 0 or v_u_60[v89].t * v_u_58
			local v91 = p86 - 1
			local v92 = v90 - (v91 == 0 and 0 or v_u_60[v91].t * v_u_58)
			return v88 / math.max(v92, 0.0001)
		end
	end
	for v94 = 1, 3 do
		local v95 = v_u_70(v71, v94)
		local v96 = v_u_70(v71 + 1, v94)
		v85[v94] = v95 * v81 + v93(v71, v94) * (v82 * v76) + v96 * v83 + v93(v71 + 1, v94) * (v84 * v76)
	end
	return v_u_7.Frame(v85[1], v85[2], v85[3])
end
return v_u_7