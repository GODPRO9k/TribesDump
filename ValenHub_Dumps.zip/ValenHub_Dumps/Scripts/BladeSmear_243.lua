local v_u_1 = {
	["SEGMENTS"] = 12,
	["LAYERS"] = 2
}
local v_u_2 = nil
local v_u_3 = {}
local v_u_4 = {}
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = false
local function v_u_20() -- name: build
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_4, (ref) v_u_5, (ref) v_u_6, (ref) v_u_7
	local v9 = Instance.new("Part")
	v9.Name = "TribesBladeSmear"
	v9.Anchored = true
	v9.CanCollide = false
	v9.CanQuery = false
	v9.CanTouch = false
	v9.CastShadow = false
	v9.Transparency = 1
	v9.Size = Vector3.new(0.05, 0.05, 0.05)
	for v10 = 1, v_u_1.LAYERS do
		local v11 = {}
		local v12 = {}
		for v13 = 1, v_u_1.SEGMENTS + 1 do
			local v14 = Instance.new("Attachment")
			v14.Parent = v9
			v11[v13] = v14
		end
		for v15 = 1, v_u_1.SEGMENTS do
			local v16 = Instance.new("Beam")
			v16.Attachment0 = v11[v15]
			v16.Attachment1 = v11[v15 + 1]
			v16.FaceCamera = false
			v16.Segments = 1
			v16.LightEmission = 0.2
			v16.LightInfluence = 0.3
			v16.ZOffset = v10 * 0.01
			v16.Enabled = false
			v16.Parent = v9
			v12[v15] = v16
		end
		v_u_3[v10] = v11
		v_u_4[v10] = v12
	end
	local v17 = Instance.new("Attachment")
	v17.Parent = v9
	v_u_5 = v17
	local v18 = Instance.new("ParticleEmitter")
	v18.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	v18.Enabled = false
	v18.LightEmission = 0.4
	v18.LightInfluence = 0.2
	v18.Color = ColorSequence.new(Color3.fromRGB(255, 214, 140), Color3.fromRGB(255, 140, 60))
	v18.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(1, 0) })
	v18.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(1, 1) })
	v18.Lifetime = NumberRange.new(0.12, 0.26)
	v18.Speed = NumberRange.new(1.2, 3)
	v18.SpreadAngle = Vector2.new(180, 180)
	v18.Drag = 7
	v18.Acceleration = Vector3.new(0, -4, 0)
	v18.LockedToPart = true
	v18.Parent = v17
	v_u_6 = v18
	local v19 = Instance.new("ParticleEmitter")
	v19.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	v19.Enabled = false
	v19.LightEmission = 0.4
	v19.LightInfluence = 0
	v19.Color = ColorSequence.new(Color3.fromRGB(255, 236, 200))
	v19.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.06), NumberSequenceKeypoint.new(0.25, 0.16), NumberSequenceKeypoint.new(1, 0) })
	v19.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.15), NumberSequenceKeypoint.new(1, 1) })
	v19.Lifetime = NumberRange.new(0.1, 0.12)
	v19.Speed = NumberRange.new(0)
	v19.Rotation = NumberRange.new(0, 45)
	v19.LockedToPart = true
	v19.Parent = v17
	v_u_7 = v19
	return v9
end
function v_u_1.Draw(p21, p22, p23, p24, p25, p26, p27) -- name: Draw
	-- upvalues: (copy) v_u_1, (ref) v_u_2, (copy) v_u_20, (copy) v_u_3, (copy) v_u_4, (ref) v_u_8
	local v28 = #p24
	local v29 = v_u_1.SEGMENTS + 1
	local v30 = math.min(v28, v29)
	if v30 < 2 then
		v_u_1.Hide()
		return
	else
		local v31 = v_u_2 or v_u_20()
		v_u_2 = v31
		v31.CFrame = p22
		if v31.Parent ~= p21 then
			v31.Parent = p21
		end
		local v32 = v_u_3[p23]
		local v33 = v_u_4[p23]
		if v32 then
			local v34 = ColorSequence.new(p27)
			for v35 = 1, v30 do
				v32[v35].CFrame = p24[v35]
			end
			for v36 = 1, v_u_1.SEGMENTS do
				local v37 = v33[v36]
				if v36 < v30 then
					v37.Width0 = p25[v36]
					v37.Width1 = p25[v36 + 1]
					v37.Transparency = NumberSequence.new(p26[v36], p26[v36 + 1])
					v37.Color = v34
					v37.Enabled = true
				else
					if not v37.Enabled then
						continue
					end
					v37.Enabled = false
				end
			end
			v_u_8 = true
		end
	end
end
function v_u_1.Hide() -- name: Hide
	-- upvalues: (ref) v_u_8, (copy) v_u_4
	if v_u_8 then
		v_u_8 = false
		for _, v38 in v_u_4 do
			for _, v39 in v38 do
				v39.Enabled = false
			end
		end
	end
end
function v_u_1.Follow(p40) -- name: Follow
	-- upvalues: (ref) v_u_2
	local v41 = v_u_2
	if v41 and v41.Parent then
		v41.CFrame = p40
	end
end
function v_u_1.Spark(p42, p43, p44) -- name: Spark
	-- upvalues: (ref) v_u_2, (copy) v_u_20, (ref) v_u_5, (ref) v_u_6, (ref) v_u_7
	local v45 = v_u_2 or v_u_20()
	v_u_2 = v45
	v45.CFrame = p43
	if v45.Parent ~= p42 then
		v45.Parent = p42
	end
	local v46 = v_u_5
	local v47 = v_u_6
	if v46 and v47 then
		v46.Position = p44
		v47:Emit(18)
		if v_u_7 then
			v_u_7:Emit(1)
		end
	end
end
return v_u_1