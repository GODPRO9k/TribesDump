local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("Workspace")
return {
	["Init"] = function(p_u_3) -- name: Init
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		local v_u_4 = p_u_3.State
		local v_u_5 = v_u_1.LocalPlayer
		local v_u_6 = v_u_4.MyId()
		local v_u_7 = 0
		local function v_u_9() -- name: mockProfile
			-- upvalues: (copy) v_u_4
			local v8 = {
				["level"] = 7,
				["xp"] = 340,
				["xpToNext"] = 505,
				["shells"] = 1250,
				["owned"] = nil,
				["loadout"] = nil,
				["loadouts"] = nil,
				["activeLoadout"] = 1,
				["loadoutNames"] = nil,
				["stats"] = nil,
				["settings"] = nil,
				["owned"] = {},
				["loadout"] = {
					["items"] = nil,
					["armor"] = false,
					["ammo"] = nil,
					["items"] = {
						"longbow",
						"obsidian_dagger",
						"bandage",
						"smoke_bomb"
					},
					["ammo"] = {
						["arrows"] = 2
					}
				},
				["loadouts"] = {
					{
						["items"] = nil,
						["armor"] = false,
						["ammo"] = nil,
						["items"] = {
							"longbow",
							"obsidian_dagger",
							"bandage",
							"smoke_bomb"
						},
						["ammo"] = {
							["arrows"] = 2
						}
					},
					{
						["items"] = nil,
						["armor"] = false,
						["ammo"] = nil,
						["items"] = {
							"short_bow",
							"bronze_sword",
							"throwing_knives",
							"bandage",
							"smoke_bomb"
						},
						["ammo"] = {
							["arrows"] = 1
						}
					},
					{
						["items"] = nil,
						["armor"] = "hide_armor",
						["items"] = { "battle_axe", "throwing_knives", "fire_bomb" }
					},
					{
						["items"] = nil,
						["armor"] = "bronze_armor",
						["items"] = { "war_club", "bandage" }
					},
					{
						["items"] = nil,
						["armor"] = false,
						["ammo"] = nil,
						["items"] = {
							"short_bow",
							"healing_tonic",
							"smoke_bomb",
							"bear_trap"
						},
						["ammo"] = {
							["arrows"] = 1
						}
					}
				},
				["loadoutNames"] = {
					"Sniper",
					"",
					"Brawler",
					"Tank",
					"Support"
				},
				["stats"] = {
					["matches"] = 12,
					["wins"] = 7,
					["losses"] = 5,
					["kills"] = 41,
					["deaths"] = 22,
					["streak"] = 2,
					["bestStreak"] = 4,
					["roundsWon"] = 38
				},
				["settings"] = {}
			}
			v_u_4.SetProfile(v8)
			v_u_4.SetMockAttr("Level", 7)
			v_u_4.SetMockAttr("XP", 340)
			v_u_4.SetMockAttr("Shells", 1250)
		end
		local v_u_10 = {
			"Grimtooth",
			"Ashfang",
			"Mossback",
			"Redhawk",
			"Stonejaw",
			"Quickreed",
			"Emberly",
			"Thornwick"
		}
		local function v_u_19(p11, p12, p13, p14, p15, p16, p17, p18) -- name: member
			return {
				["id"] = nil,
				["name"] = nil,
				["userId"] = nil,
				["isBot"] = nil,
				["alive"] = true,
				["connected"] = true,
				["kills"] = nil,
				["deaths"] = nil,
				["damage"] = nil,
				["assists"] = 1,
				["level"] = nil,
				["loadout"] = nil,
				["id"] = p11,
				["name"] = p12,
				["userId"] = p13,
				["isBot"] = p14,
				["kills"] = p15,
				["deaths"] = p16,
				["damage"] = p17,
				["level"] = p18,
				["loadout"] = {
					["primary"] = "short_bow",
					["secondary"] = "throwing_knives",
					["melee"] = "bronze_sword",
					["utility"] = "fire_bomb"
				}
			}
		end
		local v_u_20 = nil
		local function v_u_22() -- name: newSnapshot
			-- upvalues: (ref) v_u_20, (copy) v_u_4, (copy) v_u_19, (copy) v_u_6, (copy) v_u_5, (copy) v_u_10
			local v21 = {
				["matchId"] = "mock",
				["mapId"] = "SunstoneTemple",
				["mapName"] = "Sunstone Temple",
				["mapThumb"] = "",
				["phase"] = "Intro",
				["phaseEndsAt"] = nil,
				["round"] = 1,
				["roundsToWin"] = 3,
				["ringRadius"] = 0,
				["ringCenter"] = false,
				["teams"] = nil,
				["phaseEndsAt"] = v_u_4.Now() + 4,
				["teams"] = {
					{
						["name"] = "Wolf",
						["score"] = 0,
						["members"] = nil,
						["members"] = { v_u_19(v_u_6, v_u_5.DisplayName, v_u_5.UserId, false, 0, 0, 0, 7), v_u_19("b1", v_u_10[1], false, true, 0, 0, 0, 5), (v_u_19("p1", "Roblox", 1, false, 0, 0, 0, 12)) }
					},
					{
						["name"] = "Raven",
						["score"] = 0,
						["members"] = nil,
						["members"] = { v_u_19("b2", v_u_10[2], false, true, 0, 0, 0, 6), v_u_19("b3", v_u_10[3], false, true, 0, 0, 0, 4), (v_u_19("p2", "builderman", 156, false, 0, 0, 0, 9)) }
					}
				}
			}
			v_u_20 = v21
			return v_u_20
		end
		local function v_u_26(p23) -- name: find
			-- upvalues: (ref) v_u_20
			for v24 = 1, 2 do
				for _, v25 in v_u_20.teams[v24].members do
					if v25.id ~= p23 then
						continue
					end
					return v25, v24
				end
			end
			return nil, nil
		end
		local function v_u_38(p27, p28, p29, p30) -- name: eliminate
			-- upvalues: (copy) v_u_26, (copy) v_u_4, (ref) v_u_20, (copy) v_u_6
			local v31, v32 = v_u_26(p28)
			local v33
			if p27 then
				v33 = v_u_26(p27)
			else
				v33 = nil
			end
			if v31 then
				v31.alive = false
				v31.deaths = v31.deaths + 1
				if v33 then
					v33.kills = v33.kills + 1
					v33.damage = v33.damage + 100
				end
				local v34 = v_u_4.InjectEvent
				local v35 = "Elimination"
				local v36 = {
					["killerId"] = nil,
					["victimId"] = nil,
					["weaponId"] = nil,
					["headshot"] = nil,
					["assistId"] = false,
					["killerName"] = nil,
					["victimName"] = nil,
					["killerTeam"] = 0,
					["victimTeam"] = nil,
					["killerId"] = p27 or false,
					["victimId"] = p28,
					["weaponId"] = p29 or false,
					["headshot"] = p30 == true
				}
				local v37
				if v33 then
					v37 = v33.name
				else
					v37 = false
				end
				v36.killerName = v37
				v36.victimName = v31.name
				v36.victimTeam = v32
				v34(v35, v36)
				v_u_4.InjectSnapshot(v_u_20)
				if p28 == v_u_6 then
					v_u_4.SetMockAttr("Alive", false)
				end
			end
		end
		local function v_u_41() -- name: resetAlive
			-- upvalues: (ref) v_u_20, (copy) v_u_4
			for _, v39 in v_u_20.teams[1].members do
				v39.alive = true
			end
			for _, v40 in v_u_20.teams[2].members do
				v40.alive = true
			end
			v_u_4.SetMockAttr("Alive", true)
			v_u_4.SetMockAttr("SpectateMode", "none")
		end
		local v_u_52 = {
			["intro"] = function()
				-- upvalues: (copy) v_u_22, (copy) v_u_4, (ref) v_u_20
				v_u_22()
				v_u_4.SetMockAttr("State", "Match")
				v_u_4.SetMockAttr("MatchId", "mock")
				v_u_4.SetMockAttr("Team", 1)
				v_u_4.SetMockAttr("Alive", true)
				v_u_4.InjectSnapshot(v_u_20)
				v_u_4.InjectEvent("MatchStart", {
					["matchId"] = "mock",
					["mapName"] = nil,
					["mapThumb"] = nil,
					["teams"] = nil,
					["mapName"] = v_u_20.mapName,
					["mapThumb"] = v_u_20.mapThumb,
					["teams"] = v_u_20.teams
				})
			end,
			["preround"] = function()
				-- upvalues: (ref) v_u_20, (copy) v_u_52, (copy) v_u_41, (copy) v_u_4
				if not v_u_20 then
					v_u_52.intro()
				end
				v_u_41()
				v_u_20.phase = "PreRound"
				v_u_20.phaseEndsAt = v_u_4.Now() + 8
				v_u_4.InjectSnapshot(v_u_20)
				v_u_4.InjectEvent("RoundStart", {
					["round"] = v_u_20.round
				})
			end,
			["live"] = function()
				-- upvalues: (ref) v_u_20, (copy) v_u_52, (copy) v_u_4
				if not v_u_20 then
					v_u_52.intro()
				end
				v_u_20.phase = "Live"
				v_u_20.phaseEndsAt = v_u_4.Now() + 75
				v_u_4.InjectSnapshot(v_u_20)
			end,
			["feed"] = function()
				-- upvalues: (copy) v_u_38
				v_u_38("b2", "b1", "longbow", false)
				task.wait(0.4)
				v_u_38("p1", "b3", "throwing_knives", true)
				task.wait(0.4)
				v_u_38("p2", "p1", "war_club", false)
			end,
			["mykill"] = function(p42)
				-- upvalues: (copy) v_u_38, (copy) v_u_6
				v_u_38(v_u_6, p42 or "b2", "short_bow", true)
			end,
			["death"] = function()
				-- upvalues: (copy) v_u_38, (copy) v_u_6, (copy) v_u_4
				v_u_38("p2", v_u_6, "musket", true)
				v_u_4.SetMockAttr("SpectateMode", "death")
			end,
			["follow"] = function()
				-- upvalues: (copy) v_u_4, (copy) v_u_10
				v_u_4.SetMockAttr("SpectateMode", "follow")
				v_u_4.SetMockAttr("SpectateTargetId", "b1")
				v_u_4.SetMockAttr("SpectateTargetName", v_u_10[1])
			end,
			["roundend"] = function(p43)
				-- upvalues: (ref) v_u_20, (copy) v_u_4, (copy) v_u_6
				local v44 = p43 or 1
				local v45 = v_u_20.teams[v44]
				v45.score = v45.score + 1
				v_u_20.phase = "RoundEnd"
				v_u_20.phaseEndsAt = v_u_4.Now() + 4
				v_u_4.InjectSnapshot(v_u_20)
				v_u_4.InjectEvent("RoundEnd", {
					["round"] = v_u_20.round,
					["winnerTeam"] = v44,
					["mvpId"] = v_u_6
				})
			end,
			["overtime"] = function()
				-- upvalues: (ref) v_u_20, (copy) v_u_4
				v_u_20.phase = "Overtime"
				v_u_20.phaseEndsAt = v_u_4.Now() + 25
				v_u_4.InjectSnapshot(v_u_20)
				v_u_20.ringRadius = 90
				v_u_4.InjectEvent("Overtime", {})
			end,
			["matchend"] = function(p46)
				-- upvalues: (ref) v_u_20, (copy) v_u_52, (copy) v_u_26, (copy) v_u_6, (copy) v_u_4
				if not v_u_20 then
					v_u_52.intro()
				end
				local v47 = p46 ~= false
				local v48 = v_u_26(v_u_6)
				if v48 then
					v48.kills = 9
					v48.deaths = 3
					v48.damage = 1240
				end
				local v49 = v_u_26("b1")
				if v49 then
					v49.kills = 4
					v49.damage = 610
				end
				local v50 = v_u_26("p2")
				if v50 then
					v50.kills = 7
					v50.damage = 980
				end
				v_u_20.teams[1].score = v47 and 2 or 1
				v_u_20.teams[2].score = v47 and 1 or 2
				v_u_20.phase = "MatchEnd"
				v_u_20.phaseEndsAt = v_u_4.Now() + 10
				v_u_4.InjectSnapshot(v_u_20)
				local v51 = {
					["winnerTeam"] = v47 and 1 or 2,
					["mvpId"] = v_u_6,
					["you"] = {
						["kills"] = 9,
						["deaths"] = 3,
						["assists"] = 2,
						["damage"] = 1240,
						["xp"] = 420,
						["shells"] = 95,
						["levelShells"] = 25,
						["levelBefore"] = 7,
						["levelAfter"] = 8,
						["xpBefore"] = 340,
						["xpAfter"] = 255,
						["xpToNextBefore"] = 505,
						["xpToNextAfter"] = 605,
						["streak"] = nil,
						["won"] = nil,
						["trophies"] = nil,
						["tribe"] = nil,
						["lines"] = nil,
						["streak"] = v47 and 3 or 0,
						["won"] = v47,
						["trophies"] = {
							["before"] = 0,
							["after"] = nil,
							["delta"] = nil,
							["rankBefore"] = 1,
							["rankAfter"] = 1,
							["floor"] = false,
							["after"] = v47 and 30 or 0,
							["delta"] = v47 and 30 or 0
						},
						["tribe"] = {
							["tag"] = "SURF",
							["renown"] = 3,
							["mates"] = 1
						},
						["lines"] = {
							{
								["label"] = "Match played",
								["xp"] = 40,
								["shells"] = 20
							},
							{
								["label"] = "Victory",
								["xp"] = 60,
								["shells"] = 40
							},
							{
								["label"] = "Eliminations",
								["xp"] = 120,
								["shells"] = 45
							},
							{
								["label"] = "Assists",
								["xp"] = 5,
								["shells"] = 0
							},
							{
								["label"] = "Rounds won",
								["xp"] = 45,
								["shells"] = 0
							},
							{
								["label"] = "MVP",
								["xp"] = 25,
								["shells"] = 15
							},
							{
								["label"] = "Win streak",
								["xp"] = 24,
								["shells"] = 0
							},
							{
								["label"] = "Rookie bonus",
								["xp"] = 159,
								["shells"] = 0
							}
						}
					}
				}
				v_u_4.InjectEvent("MatchEnd", v51)
			end
		}
		local v_u_53 = 0
		function v_u_52.unqueue()
			-- upvalues: (ref) v_u_53, (copy) v_u_4
			v_u_53 = v_u_53 + 1
			v_u_4.SetMockAttr("QueueFound", false)
			v_u_4.SetMockAttr("QueuedAt", 0)
			v_u_4.SetMockAttr("Queued", false)
		end
		function v_u_52.found()
			-- upvalues: (copy) v_u_4
			v_u_4.SetMockAttr("QueueFound", true)
		end
		function v_u_52.queue(p54)
			-- upvalues: (ref) v_u_53, (copy) v_u_4, (copy) v_u_52
			v_u_53 = v_u_53 + 1
			local v_u_55 = v_u_53
			v_u_4.SetMockAttr("QueueFound", false)
			v_u_4.SetMockAttr("QueuedAt", v_u_4.Now())
			v_u_4.SetMockAttr("Queued", true)
			if p54 and p54 > 0 then
				task.delay(p54, function()
					-- upvalues: (copy) v_u_55, (ref) v_u_53, (ref) v_u_4, (ref) v_u_52
					if v_u_55 == v_u_53 and v_u_4.Mock then
						v_u_52.found()
					end
				end)
			end
		end
		function v_u_52.lowhp(p56)
			-- upvalues: (copy) v_u_5
			local v57 = v_u_5.Character
			if v57 then
				v57 = v57:FindFirstChildOfClass("Humanoid")
			end
			if v57 then
				v57.Health = p56 or 22
			end
		end
		local function v_u_69(p58) -- name: run
			-- upvalues: (copy) v_u_4, (ref) v_u_7, (copy) p_u_3, (ref) v_u_20, (copy) v_u_9, (copy) v_u_5, (copy) v_u_10, (copy) v_u_52
			if p58 == nil or p58 == "" then
				if v_u_4.Mock then
					v_u_7 = v_u_7 + 1
					v_u_4.Mock = nil
					p_u_3.Fighters.TrustAllUserIds = false
					v_u_20 = nil
					v_u_4.ClearMockAttrs()
					v_u_4.InjectSnapshot(nil)
					v_u_4.Refresh()
					v_u_4.FetchMatch()
				end
				return
			else
				v_u_7 = v_u_7 + 1
				local v_u_59 = v_u_7
				v_u_4.Mock = p58
				p_u_3.Fighters.TrustAllUserIds = true
				v_u_4.ClearMockAttrs()
				v_u_9()
				if p58 == "lobby" then
					v_u_4.SetMockAttr("State", "Lobby")
					local function v67(p60) -- name: board
						-- upvalues: (ref) v_u_5, (ref) v_u_10
						local v61 = {}
						for v62 = 1, 10 do
							local v63 = {}
							local v64
							if v62 == 3 then
								v64 = v_u_5.UserId
							else
								v64 = v62 % 3 == 0 and 1 or -v62
							end
							v63.userId = v64
							local v65
							if v62 == 3 then
								v65 = v_u_5.DisplayName
							else
								v65 = v_u_10[(v62 + p60) % #v_u_10 + 1]
							end
							v63.name = v65
							local v66 = 900 / v62
							v63.value = math.floor(v66) + p60
							v61[v62] = v63
						end
						return v61
					end
					v_u_4.InjectLeaderboards({
						["Wins"] = v67(0),
						["Kills"] = v67(3),
						["Level"] = v67(5)
					})
					return
				elseif p58 == "match" then
					task.spawn(function()
						-- upvalues: (ref) v_u_52, (copy) v_u_59, (ref) v_u_7, (ref) v_u_20
						v_u_52.intro()
						task.wait(4)
						if v_u_59 == v_u_7 then
							v_u_52.preround()
							task.wait(3)
							if v_u_59 == v_u_7 then
								v_u_52.live()
								task.wait(2)
								if v_u_59 == v_u_7 then
									v_u_52.mykill("b2")
									task.wait(2.5)
									if v_u_59 == v_u_7 then
										v_u_52.feed()
										task.wait(2)
										if v_u_59 == v_u_7 then
											v_u_52.mykill("b3")
											task.wait(3)
											if v_u_59 == v_u_7 then
												v_u_52.roundend(1)
												task.wait(4)
												if v_u_59 == v_u_7 then
													local v68 = v_u_20
													v68.round = v68.round + 1
													v_u_52.preround()
													task.wait(3)
													if v_u_59 == v_u_7 then
														v_u_52.live()
													end
												else
													return
												end
											else
												return
											end
										else
											return
										end
									else
										return
									end
								else
									return
								end
							else
								return
							end
						else
							return
						end
					end)
				elseif p58 == "matchend" then
					v_u_52.intro()
					p_u_3.SetHudHidden("Intro", false)
					v_u_52.live()
					v_u_52.matchend(true)
				end
			end
		end
		function p_u_3.Debug._mockProfileAction(p70, p71, p72)
			-- upvalues: (copy) v_u_4
			local v_u_73 = v_u_4.Profile
			local v74 = nil
			if p70 == "SetLoadout" then
				if type(p71) == "table" then
					local v75 = {
						["items"] = table.clone(p71.items or {}),
						["armor"] = p71.armor or false
					}
					local v76 = p71.ammo
					local v77
					if type(v76) == "table" then
						v77 = table.clone(p71.ammo)
					else
						v77 = nil
					end
					v75.ammo = v77
					local v78 = type(p72) ~= "number" and (v_u_73.activeLoadout or 1) or p72
					local v79 = v_u_73.loadouts
					if type(v79) == "table" then
						v_u_73.loadouts[v78] = v75
					end
					if v78 == (v_u_73.activeLoadout or 1) then
						v_u_73.loadout = v75
					end
				end
			elseif p70 == "SelectLoadout" then
				local v80 = v_u_73.loadouts
				if type(v80) ~= "table" or (type(p71) ~= "number" or not v_u_73.loadouts[p71]) then
					return false, "Bad slot"
				end
				v_u_73.activeLoadout = p71
				v_u_73.loadout = v_u_73.loadouts[p71]
			elseif p70 == "RenameLoadout" then
				local v81 = v_u_73.loadoutNames
				if type(v81) ~= "table" or type(p71) ~= "number" then
					return false, "Bad slot"
				end
				local v82 = tostring(p72 or "")
				v74 = string.sub(v82, 1, 16)
				v_u_73.loadoutNames[p71] = v74
			end
			task.defer(function()
				-- upvalues: (ref) v_u_4, (copy) v_u_73
				v_u_4.ProfileChanged:Fire(v_u_73)
			end)
			return true, nil, v74
		end
		function p_u_3.Debug._mockQueueAction(p83)
			-- upvalues: (copy) v_u_52, (ref) v_u_53, (copy) v_u_4, (ref) v_u_7, (copy) p_u_3, (copy) v_u_9, (ref) v_u_20, (copy) v_u_69
			if p83 == "Queue" or p83 == "PlayAgain" then
				v_u_52.queue(2.5)
				local v_u_84 = v_u_53
				task.delay(3.7, function()
					-- upvalues: (copy) v_u_84, (ref) v_u_53, (ref) v_u_4, (ref) v_u_52, (ref) v_u_7, (ref) p_u_3, (ref) v_u_9, (ref) v_u_20
					if v_u_84 == v_u_53 and (v_u_4.Mock and v_u_4.Get("QueueFound") == true) then
						v_u_52.unqueue()
						v_u_7 = v_u_7 + 1
						local v_u_85 = v_u_7
						v_u_4.Mock = "match"
						p_u_3.Fighters.TrustAllUserIds = true
						v_u_4.ClearMockAttrs()
						v_u_9()
						task.spawn(function()
							-- upvalues: (ref) v_u_52, (copy) v_u_85, (ref) v_u_7, (ref) v_u_20
							v_u_52.intro()
							task.wait(4)
							if v_u_85 == v_u_7 then
								v_u_52.preround()
								task.wait(3)
								if v_u_85 == v_u_7 then
									v_u_52.live()
									task.wait(2)
									if v_u_85 == v_u_7 then
										v_u_52.mykill("b2")
										task.wait(2.5)
										if v_u_85 == v_u_7 then
											v_u_52.feed()
											task.wait(2)
											if v_u_85 == v_u_7 then
												v_u_52.mykill("b3")
												task.wait(3)
												if v_u_85 == v_u_7 then
													v_u_52.roundend(1)
													task.wait(4)
													if v_u_85 == v_u_7 then
														local v86 = v_u_20
														v86.round = v86.round + 1
														v_u_52.preround()
														task.wait(3)
														if v_u_85 == v_u_7 then
															v_u_52.live()
														end
													else
														return
													end
												else
													return
												end
											else
												return
											end
										else
											return
										end
									else
										return
									end
								else
									return
								end
							else
								return
							end
						end)
					end
				end)
			elseif p83 == "Cancel" then
				v_u_52.unqueue()
			elseif p83 == "LeaveMatch" then
				v_u_69("lobby")
			end
			return true, nil
		end
		function p_u_3.Debug.mock(p87)
			-- upvalues: (copy) v_u_69, (copy) v_u_4
			v_u_69(p87)
			return v_u_4.Mock or "off"
		end
		function p_u_3.Debug.mockStep(p88, ...)
			-- upvalues: (copy) v_u_52, (copy) v_u_4, (copy) p_u_3, (copy) v_u_9, (ref) v_u_7
			local v89 = v_u_52[p88]
			if not v89 then
				return "unknown step " .. tostring(p88)
			end
			if not v_u_4.Mock then
				v_u_4.Mock = "match"
				p_u_3.Fighters.TrustAllUserIds = true
				v_u_9()
			end
			v_u_7 = v_u_7 + 1
			v89(...)
			return true
		end
		local function v92() -- name: fromAttr
			-- upvalues: (ref) v_u_2, (copy) v_u_69
			local v90 = v_u_2:GetAttribute("UIMock")
			local v91 = v_u_69
			if type(v90) ~= "string" then
				v90 = nil
			end
			v91(v90)
		end
		v_u_2:GetAttributeChangedSignal("UIMock"):Connect(v92)
		if v_u_2:GetAttribute("UIMock") then
			task.delay(1, v92)
		end
	end
}