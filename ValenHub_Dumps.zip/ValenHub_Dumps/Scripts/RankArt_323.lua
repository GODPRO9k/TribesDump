local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.Ranks)
local v_u_3 = require(v1.Shared.UIAssets)
local v_u_4 = require(script.Parent.UI)
local v_u_5 = require(script.Parent.Theme)
local v_u_6 = v_u_5.Colors
local v_u_7 = v_u_5.Fonts
local v8 = Color3.fromRGB
local v_u_9 = {
	["Ranks"] = v_u_2
}
local v_u_10 = {
	["bronze"] = {
		["main"] = v8(214, 136, 78),
		["dark"] = v8(104, 56, 26)
	},
	["silver"] = {
		["main"] = v8(206, 216, 232),
		["dark"] = v8(92, 104, 126)
	},
	["gold"] = {
		["main"] = v8(255, 204, 64),
		["dark"] = v8(150, 98, 8)
	},
	["platinum"] = {
		["main"] = v8(146, 236, 222),
		["dark"] = v8(38, 118, 120)
	},
	["diamond"] = {
		["main"] = v8(86, 202, 255),
		["dark"] = v8(18, 86, 176)
	},
	["master"] = {
		["main"] = v8(186, 116, 255),
		["dark"] = v8(76, 30, 150)
	},
	["grandmaster"] = {
		["main"] = v8(255, 84, 96),
		["dark"] = v8(128, 18, 34)
	},
	["immortal"] = {
		["main"] = v8(255, 226, 120),
		["dark"] = v8(34, 26, 18)
	}
}
function v_u_9.Color(p11) -- name: Color
	-- upvalues: (copy) v_u_2, (copy) v_u_10
	local v12 = v_u_10[v_u_2.Get(p11).id] or v_u_10.bronze
	return v12.main, v12.dark
end
local function v_u_23(p13, p14, p15) -- name: drawFallback
	-- upvalues: (copy) v_u_9, (copy) v_u_4, (copy) v_u_5, (copy) v_u_2, (copy) v_u_7, (copy) v_u_6
	local v16, v17 = v_u_9.Color(p14)
	local v18 = v_u_4.new("Frame", {
		["Name"] = "Body",
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(0.68, 0.68),
		["Rotation"] = 45,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["ZIndex"] = p15,
		v_u_4.Corner(UDim.new(0.14, 0)),
		v_u_4.Gradient(v_u_5.Lighten(v16, 0.25), v17, 90),
		v_u_4.Stroke(v_u_5.Lighten(v16, 0.5), 1.5, 0.15),
		["Parent"] = p13
	})
	v_u_4.new("Frame", {
		["Name"] = "Core",
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(0.5, 0.5),
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["ZIndex"] = p15 + 1,
		v_u_4.Corner(UDim.new(0.18, 0)),
		v_u_4.Gradient(v17, v_u_5.Lighten(v16, 0.1), 90),
		["Parent"] = v18
	})
	local v19 = v_u_4.new
	local v20 = {
		["Name"] = "Tier",
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v21 = string.upper
	local v22 = v_u_2.Get(p14).name
	v20.Text = v21((string.sub(v22, 1, 1)))
	v20.FontFace = v_u_7.Display
	v20.TextScaled = true
	v20.TextColor3 = v_u_6.Text
	v20.ZIndex = p15 + 2
	__set_list(v20, 1, {v_u_4.new("UITextSizeConstraint", {
	["MaxTextSize"] = 200,
	["MinTextSize"] = 6
}), v_u_4.new("UIPadding", {
	["PaddingTop"] = UDim.new(0.33, 0),
	["PaddingBottom"] = UDim.new(0.33, 0),
	["PaddingLeft"] = UDim.new(0.3, 0),
	["PaddingRight"] = UDim.new(0.3, 0)
}), (v_u_4.TextStroke(v_u_6.Void, 1, 0.4))})
	v20.Parent = p13
	v19("TextLabel", v20)
end
function v_u_9.SetEmblem(p24, p25) -- name: SetEmblem
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_23
	local v26 = tonumber(p25) or 1
	local v27 = math.floor(v26)
	local v28 = v_u_2.Count
	local v29 = math.clamp(v27, 1, v28())
	if p24:GetAttribute("Rank") == v29 then
		return
	else
		p24:SetAttribute("Rank", v29)
		for _, v30 in p24:GetChildren() do
			if not v30:IsA("GuiObject") then
				continue
			end
			v30:Destroy()
		end
		local v31 = p24.ZIndex
		local v32 = v_u_3.Ranks
		local v33
		if type(v32) == "table" then
			v33 = v_u_3.Ranks or nil
		else
			v33 = nil
		end
		if v33 then
			v33 = v33[v_u_2.Get(v29).id]
		end
		if type(v33) ~= "string" or v33 == "" then
			v33 = nil
		end
		if v33 then
			v_u_4.new("ImageLabel", {
				["Name"] = "Art",
				["Size"] = nil,
				["Image"] = nil,
				["ScaleType"] = nil,
				["ZIndex"] = nil,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Image"] = v33,
				["ScaleType"] = Enum.ScaleType.Fit,
				["ZIndex"] = v31,
				["Parent"] = p24
			})
		else
			v_u_23(p24, v29, v31)
		end
	end
end
function v_u_9.Emblem(p34, p35, p36) -- name: Emblem
	-- upvalues: (copy) v_u_4, (copy) v_u_9
	local v37 = p36 or {}
	local v38 = v_u_4.new("Frame", {
		["Name"] = v37.Name or "RankEmblem",
		["Size"] = UDim2.fromOffset(p35, p35),
		["Position"] = v37.Position or UDim2.new(),
		["AnchorPoint"] = v37.AnchorPoint or Vector2.zero,
		["LayoutOrder"] = v37.LayoutOrder or 0,
		["ZIndex"] = v37.ZIndex or 1,
		["Parent"] = v37.Parent
	})
	v_u_9.SetEmblem(v38, p34)
	return v38
end
function v_u_9.Trophy(p39, p40) -- name: Trophy
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_6
	local v41 = p40 or {}
	local v42 = v_u_3.Icons
	local v43
	if type(v42) == "table" then
		v43 = v_u_3.Icons.Trophy or nil
	else
		v43 = nil
	end
	if type(v43) == "string" and v43 ~= "" then
		return v_u_4.new("ImageLabel", {
			["Name"] = "Trophy",
			["Size"] = nil,
			["Position"] = nil,
			["AnchorPoint"] = nil,
			["LayoutOrder"] = nil,
			["ZIndex"] = nil,
			["Image"] = nil,
			["ScaleType"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(p39, p39),
			["Position"] = v41.Position or UDim2.new(),
			["AnchorPoint"] = v41.AnchorPoint or Vector2.zero,
			["LayoutOrder"] = v41.LayoutOrder or 0,
			["ZIndex"] = v41.ZIndex or 1,
			["Image"] = v43,
			["ScaleType"] = Enum.ScaleType.Fit,
			["Parent"] = v41.Parent
		})
	end
	local v44 = v_u_4.new("Frame", {
		["Name"] = "Trophy",
		["Size"] = nil,
		["Position"] = nil,
		["AnchorPoint"] = nil,
		["LayoutOrder"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(p39, p39),
		["Position"] = v41.Position or UDim2.new(),
		["AnchorPoint"] = v41.AnchorPoint or Vector2.zero,
		["LayoutOrder"] = v41.LayoutOrder or 0,
		["ZIndex"] = v41.ZIndex or 1,
		["Parent"] = v41.Parent
	})
	v_u_4.new("Frame", {
		["Name"] = "Cup",
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromScale(0.5, 0.08),
		["Size"] = UDim2.fromScale(0.62, 0.52),
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["ZIndex"] = v41.ZIndex or 1,
		v_u_4.new("UICorner", {
			["CornerRadius"] = UDim.new(0.45, 0)
		}),
		v_u_4.Gradient(v_u_5.Lighten(v_u_6.Gold, 0.3), v_u_5.Darken(v_u_6.Gold, 0.35), 90),
		["Parent"] = v44
	})
	v_u_4.new("Frame", {
		["Name"] = "Base",
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.fromScale(0.5, 0.94),
		["Size"] = UDim2.fromScale(0.5, 0.16),
		["BackgroundColor3"] = v_u_5.Darken(v_u_6.Gold, 0.2),
		["ZIndex"] = v41.ZIndex or 1,
		v_u_4.Corner(UDim.new(0.3, 0)),
		["Parent"] = v44
	})
	v_u_4.new("Frame", {
		["Name"] = "Stem",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromScale(0.5, 0.58),
		["Size"] = UDim2.fromScale(0.14, 0.24),
		["BackgroundColor3"] = v_u_5.Darken(v_u_6.Gold, 0.25),
		["ZIndex"] = v41.ZIndex or 1,
		["Parent"] = v44
	})
	return v44
end
function v_u_9.Chip(p45, p46, p47) -- name: Chip
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2
	local v48 = p47 or {}
	local v49 = v_u_4.new
	local v50 = {
		["Name"] = v48.Name or "RankChip",
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.fromOffset(0, p46),
		["Position"] = v48.Position or UDim2.new(),
		["AnchorPoint"] = v48.AnchorPoint or Vector2.zero,
		["LayoutOrder"] = v48.LayoutOrder or 0,
		["BackgroundTransparency"] = 1,
		["ZIndex"] = v48.ZIndex or 1
	}
	local v51 = v_u_4.List
	local v52 = Enum.FillDirection.Horizontal
	local v53 = p46 * 0.18
	__set_list(v50, 1, {(v51(v52, math.floor(v53), Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center))})
	v50.Parent = v48.Parent
	local v54 = v49("Frame", v50)
	local v_u_55 = v_u_9.Emblem(1, p46, {
		["LayoutOrder"] = 1,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["ZIndex"] = v48.ZIndex,
		["Parent"] = v54
	})
	local v_u_56
	if v48.ShowName then
		local v57 = v_u_4.new
		local v58 = {
			["Name"] = "RankName",
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromOffset(0, p46),
			["Text"] = "",
			["FontFace"] = v_u_7.Heavy
		}
		local v59 = p46 * 0.5
		v58.TextSize = math.floor(v59)
		v58.TextColor3 = v_u_6.Text
		v58.LayoutOrder = 2
		v58.ZIndex = v48.ZIndex or 1
		__set_list(v58, 1, {(v_u_4.TextStroke(v_u_6.Void, 1.5, 0.35))})
		v58.Parent = v54
		v_u_56 = v57("TextLabel", v58)
	else
		v_u_56 = nil
	end
	local v60 = v_u_9.Trophy
	local v61 = p46 * 0.62
	v60(math.floor(v61), {
		["LayoutOrder"] = 3,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["ZIndex"] = v48.ZIndex,
		["Parent"] = v54
	})
	local v62 = v_u_4.new
	local v63 = {
		["Name"] = "Trophies",
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.fromOffset(0, p46),
		["Text"] = "0",
		["FontFace"] = v_u_7.Display
	}
	local v64 = p46 * 0.56
	v63.TextSize = math.floor(v64)
	v63.TextColor3 = v48.TextColor3 or v_u_6.Text
	v63.LayoutOrder = 4
	v63.ZIndex = v48.ZIndex or 1
	__set_list(v63, 1, {(v_u_4.TextStroke(v_u_6.Void, 1.5, 0.35))})
	v63.Parent = v54
	local v_u_65 = v62("TextLabel", v63)
	local function v72(p66) -- name: set
		-- upvalues: (ref) v_u_2, (ref) v_u_9, (copy) v_u_55, (copy) v_u_65, (ref) v_u_4, (ref) v_u_56
		local v67 = tonumber(p66) or 0
		local v68 = math.floor(v67)
		local v69 = math.max(0, v68)
		local v70 = v_u_2.RankOf(v69)
		v_u_9.SetEmblem(v_u_55, v70)
		v_u_65.Text = v_u_4.FormatNumber(v69)
		if v_u_56 then
			local v71 = v_u_9.Color(v70)
			v_u_56.Text = string.upper(v_u_2.Get(v70).name)
			v_u_56.TextColor3 = v71
		end
	end
	v72(tonumber(p45) or 0)
	return v54, v72
end
return v_u_9