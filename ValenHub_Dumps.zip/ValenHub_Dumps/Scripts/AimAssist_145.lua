local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v3 = game:GetService("RunService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = require(script.Parent:WaitForChild("Fighters"))
local v_u_7 = {
	["TOUCH"] = {
		["ranged"] = {
			["radius"] = 3,
			["minDeg"] = 4.5,
			["maxDeg"] = 12,
			["friction"] = 0.5,
			["track"] = 0.5,
			["trackPitch"] = 0.3,
			["pull"] = 0.15,
			["range"] = 320
		},
		["aimed"] = {
			["radius"] = 2.6,
			["minDeg"] = 3.5,
			["maxDeg"] = 10,
			["friction"] = 0.42,
			["track"] = 0.6,
			["trackPitch"] = 0.35,
			["pull"] = 0.12,
			["range"] = 420
		},
		["scoped"] = {
			["radius"] = 1.8,
			["minDeg"] = 1.6,
			["maxDeg"] = 6,
			["friction"] = 0.45,
			["track"] = 0.45,
			["trackPitch"] = 0.25,
			["pull"] = 0.06,
			["range"] = 600
		},
		["melee"] = {
			["radius"] = 3.5,
			["minDeg"] = 8,
			["maxDeg"] = 24,
			["friction"] = 0.7,
			["track"] = 0.35,
			["trackPitch"] = 0.15,
			["pull"] = 0.08,
			["range"] = 16
		}
	},
	["GAMEPAD"] = {
		["ranged"] = {
			["radius"] = 2.6,
			["minDeg"] = 5,
			["maxDeg"] = 10,
			["friction"] = 0.55,
			["track"] = 0.35,
			["trackPitch"] = 0.2,
			["pull"] = 0.1,
			["range"] = 320
		},
		["aimed"] = {
			["radius"] = 2.3,
			["minDeg"] = 5,
			["maxDeg"] = 9,
			["friction"] = 0.5,
			["track"] = 0.4,
			["trackPitch"] = 0.25,
			["pull"] = 0.08,
			["range"] = 420
		},
		["scoped"] = {
			["radius"] = 1.6,
			["minDeg"] = 5,
			["maxDeg"] = 8,
			["friction"] = 0.55,
			["track"] = 0.3,
			["trackPitch"] = 0.15,
			["pull"] = 0.05,
			["range"] = 600
		},
		["melee"] = {
			["radius"] = 3.2,
			["minDeg"] = 8,
			["maxDeg"] = 22,
			["friction"] = 0.6,
			["track"] = 0.25,
			["trackPitch"] = 0.1,
			["pull"] = 0.06,
			["range"] = 16
		}
	},
	["SCOPE_FOV"] = 42
}
local v_u_8 = {
	["Fists"] = true,
	["Sword"] = true,
	["Axe"] = true,
	["Spear"] = true,
	["Dagger"] = true,
	["Club"] = true,
	["Gauntlets"] = true,
	["Scythe"] = true,
	["Katana"] = true,
	["Hatchets"] = true
}
local v_u_9 = {
	["Bow"] = true,
	["Crossbow"] = true,
	["Musket"] = true,
	["Pistol"] = true,
	["Blunderbuss"] = true,
	["Knives"] = true,
	["Javelin"] = true,
	["Sling"] = true
}
local v_u_10 = v2.LocalPlayer
local v_u_11 = v3:IsStudio()
local v_u_12 = true
local v_u_13 = nil
local v_u_14 = nil
local function v_u_18() -- name: combat
	-- upvalues: (ref) v_u_14
	if v_u_14 == nil then
		local v_u_15 = script.Parent.Parent:FindFirstChild("Combat")
		local v16, v17 = pcall(function()
			-- upvalues: (copy) v_u_15
			return require(v_u_15)
		end)
		if not v16 or type(v17) ~= "table" then
			v17 = false
		end
		v_u_14 = v17
	end
	if v_u_14 then
		return v_u_14
	else
		return nil
	end
end
local v_u_19 = nil
local v_u_20 = false
local v_u_21 = (-1 / 0)
local v_u_22 = (-1 / 0)
local v_u_23 = (-1 / 0)
local v_u_24 = (-1 / 0)
local v_u_25 = nil
local v_u_26 = nil
local v_u_27 = nil
local v_u_28 = nil
local v_u_29 = nil
local v_u_30 = 0
local v_u_31 = 0
local v_u_32 = Vector2.zero
local v_u_33 = 0
local v_u_34 = {
	["frames"] = 0,
	["slowed"] = 0,
	["trackDeg"] = 0,
	["pullDeg"] = 0,
	["searches"] = 0,
	["rays"] = 0,
	["lastDeg"] = -1,
	["lastCone"] = -1
}
local v_u_35 = RaycastParams.new()
v_u_35.FilterType = Enum.RaycastFilterType.Exclude
v_u_35.IgnoreWater = true
local function v_u_41(p36, p37) -- name: isEnemy
	-- upvalues: (copy) v_u_10
	if p36 == p37 then
		return false
	end
	local v38 = v_u_10:GetAttribute("MatchId")
	if type(v38) ~= "string" or v38 == "" then
		return p36:HasTag("TrainingDummy")
	end
	local v39 = p36:GetAttribute("Team")
	local v40
	if p36:GetAttribute("MatchId") == v38 and v39 ~= nil then
		v40 = v39 ~= v_u_10:GetAttribute("Team")
	else
		v40 = false
	end
	return v40
end
local function v_u_51(p42, p43, p44, p45) -- name: classify
	-- upvalues: (copy) v_u_18, (copy) v_u_8, (copy) v_u_9, (copy) v_u_7, (ref) v_u_24
	local v46 = p42:FindFirstChildOfClass("Tool")
	local v47
	if v46 then
		local v48 = v46:GetAttribute("WeaponId")
		local v49 = v_u_18()
		if type(v48) == "string" and v49 then
			local v50 = v49.Kind
			v47 = type(v50) == "function" and (v49.Kind(v48) or "?") or "?"
		else
			v47 = "?"
		end
	else
		v47 = "Fists"
	end
	return v_u_8[v47] and "melee" or (v_u_9[v47] and (p43 and (p44 <= v_u_7.SCOPE_FOV and "scoped" or "aimed") or ((p45 or os.clock() - v_u_24 < 0.25) and "aimed" or "ranged")) or nil)
end
local function v_u_63(p52, p53, p54, p55) -- name: closestOnSegment
	local v56 = p55 - p54
	local v57 = p54 - p52
	local v58 = v56:Dot(v56)
	local v59 = v56:Dot(p53)
	local v60 = v58 - v59 * v59
	local v61
	if v60 > 1e-6 then
		local v62 = (v59 * p53:Dot(v57) - v56:Dot(v57)) / v60
		v61 = math.clamp(v62, 0, 1)
	else
		v61 = 0
	end
	return p54 + v56 * v61
end
local function v_u_73(p64) -- name: body
	local v65 = p64:FindFirstChild("HumanoidRootPart")
	if not (v65 and v65:IsA("BasePart")) then
		v65 = nil
	end
	local v66 = p64:FindFirstChild("UpperTorso")
	if not (v66 and v66:IsA("BasePart")) then
		v66 = nil
	end
	if not v66 then
		v66 = p64:FindFirstChild("Torso")
		if not (v66 and v66:IsA("BasePart")) then
			v66 = nil
		end
	end
	local v67 = p64:FindFirstChild("Head")
	if not (v67 and v67:IsA("BasePart")) then
		v67 = nil
	end
	local v68 = v65 or v66
	if not v68 then
		return nil, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0), Vector3.new(0, 0, 0), nil
	end
	local v69 = v68.Position
	local v70 = v69 - Vector3.new(0, 2.2, 0)
	local v71
	if v67 then
		v71 = v67.Position + Vector3.new(0, 0.4, 0)
	else
		v71 = v69 + Vector3.new(0, 2.2, 0)
	end
	local v72
	if v66 then
		v72 = v66.Position + Vector3.new(0, 0.3, 0)
	else
		v72 = v69 + Vector3.new(0, 0.8, 0)
	end
	return v68, v70, v71, v72, v66 or v68
end
local v_u_74 = {
	["deg"] = 0,
	["cone"] = 0,
	["point"] = Vector3.new(0, 0, 0),
	["capsule"] = Vector3.new(0, 0, 0)
}
local function v_u_98(p75, p76, p77, p78, p79) -- name: evaluate
	-- upvalues: (copy) v_u_5, (copy) v_u_73, (copy) v_u_63, (copy) v_u_74
	local v80 = p75:FindFirstChildOfClass("Humanoid")
	if not v80 or (v80.Health <= 0 or not p75:IsDescendantOf(v_u_5)) then
		return false
	end
	local v81, v82, v83, v84 = v_u_73(p75)
	if not v81 or (v81.Position - p79).Magnitude > p78.range then
		return false
	end
	local v85 = v_u_63(p76, p77, v82, v83)
	local v86 = v85 - p76
	local v87 = v86.Magnitude
	if v87 < 0.5 then
		return false
	end
	local v88 = p77:Dot(v86 / v87)
	local v89 = math.clamp(v88, -1, 1)
	local v90 = math.acos(v89)
	local v91 = math.deg(v90)
	local v92 = p78.radius / v87
	local v93 = math.atan(v92)
	local v94 = math.deg(v93)
	local v95 = p78.minDeg
	local v96 = p78.maxDeg
	local v97 = math.clamp(v94, v95, v96)
	v_u_74.deg = v91
	v_u_74.cone = v97
	v_u_74.capsule = v85
	v_u_74.point = v_u_63(p76, p77, v81.Position - Vector3.new(0, 0.8, 0), v84)
	return true
end
local function v_u_106(p99, p100, p101) -- name: sees
	-- upvalues: (copy) v_u_34, (copy) v_u_5, (copy) v_u_35, (copy) v_u_18
	local v102 = v_u_34
	v102.rays = v102.rays + 1
	local v103 = v_u_5:Raycast(p99, p100 - p99, v_u_35)
	if v103 and not v103.Instance:IsDescendantOf(p101) then
		return false
	end
	local v104 = v_u_18()
	if v104 then
		local v105 = v104.SmokeBlocks
		if type(v105) == "function" and v104.SmokeBlocks(p99, p100) then
			return false
		end
	end
	return true
end
local v_u_107 = {
	{
		["m"] = nil,
		["s"] = 0
	},
	{
		["m"] = nil,
		["s"] = 0
	},
	{
		["m"] = nil,
		["s"] = 0
	}
}
local function v_u_131(p_u_108, p_u_109, p_u_110, p111, p_u_112, p_u_113) -- name: search
	-- upvalues: (copy) v_u_34, (copy) v_u_41, (copy) v_u_98, (copy) v_u_74, (ref) v_u_19, (copy) v_u_107, (copy) v_u_6, (copy) v_u_10, (copy) v_u_1, (copy) v_u_35, (copy) v_u_106
	local v114 = v_u_34
	v114.searches = v114.searches + 1
	local v_u_115 = 0
	local function v125(p116) -- name: consider
		-- upvalues: (ref) v_u_41, (copy) p_u_112, (ref) v_u_98, (copy) p_u_108, (copy) p_u_109, (copy) p_u_110, (copy) p_u_113, (ref) v_u_74, (ref) v_u_19, (ref) v_u_115, (ref) v_u_107
		if v_u_41(p116, p_u_112) and v_u_98(p116, p_u_108, p_u_109, p_u_110, p_u_113) then
			if v_u_74.deg <= v_u_74.cone then
				local v117 = v_u_74.deg / v_u_74.cone * (p116 == v_u_19 and 0.7 or 1)
				local v118 = v_u_115 + 1
				if v_u_115 >= 3 then
					if v_u_107[3].s <= v117 then
						return
					end
					v118 = 3
				else
					v_u_115 = v_u_115 + 1
				end
				while v118 > 1 and v117 < v_u_107[v118 - 1].s do
					local v119 = v_u_107[v118]
					local v120 = v_u_107[v118]
					local v121 = v_u_107[v118 - 1].m
					local v122 = v_u_107[v118 - 1].s
					v119.m = v121
					v120.s = v122
					v118 = v118 - 1
				end
				local v123 = v_u_107[v118]
				local v124 = v_u_107[v118]
				v123.m = p116
				v124.s = v117
			end
		else
			return
		end
	end
	for _, v126 in v_u_6.List() do
		v125(v126)
	end
	if v_u_10:GetAttribute("State") ~= "Match" then
		for _, v127 in v_u_1:GetTagged("TrainingDummy") do
			if not v127:IsA("Model") then
				continue
			end
			v125(v127)
		end
	end
	v_u_35.FilterDescendantsInstances = p111
	for v128 = 1, v_u_115 do
		local v129 = v_u_107[v128].m
		if not v_u_98(v129, p_u_108, p_u_109, p_u_110, p_u_113) then
			continue
		end
		if v_u_106(p_u_108, v_u_74.point, v129) then
			return v129, true
		end
		local v130 = v129:FindFirstChild("Head")
		if not (v130 and v130:IsA("BasePart")) then
			v130 = nil
		end
		if not (v130 and v_u_106(p_u_108, v130.Position, v129)) then
			continue
		end
		return v129, false
	end
	return nil, false
end
function v_u_7.Apply(p132, p133, p134, p135, p136, p137, p138, p139, p140, p141) -- name: Apply
	-- upvalues: (ref) v_u_30, (ref) v_u_31, (ref) v_u_23, (ref) v_u_24, (ref) v_u_22, (ref) v_u_19, (ref) v_u_28, (ref) v_u_29, (copy) v_u_34, (ref) v_u_13, (copy) v_u_4, (copy) v_u_10, (copy) v_u_5, (ref) v_u_12, (ref) v_u_21, (ref) v_u_27, (ref) v_u_25, (copy) v_u_51, (ref) v_u_26, (copy) v_u_7, (ref) v_u_20, (copy) v_u_131, (copy) v_u_98, (copy) v_u_74, (copy) v_u_73
	local v142 = os.clock()
	local v143
	if v_u_30 == 0 then
		v143 = p133
	else
		local v144 = v_u_31 * p132
		local v145 = v_u_30
		if math.abs(v144) >= math.abs(v145) then
			v144 = v_u_30
		end
		v_u_30 = v_u_30 - v144
		v143 = p133 + v144
	end
	local v146 = p133 ~= 0 and true or p134 ~= 0
	if v146 then
		v_u_23 = v142
	end
	if p141 then
		v_u_24 = v142
	end
	local v147 = v142 - v_u_22 > 0.25
	v_u_22 = v142
	if v147 then
		v_u_19 = nil
		v_u_28 = nil
		v_u_29 = nil
		local v148 = v_u_34
		v_u_34.lastDeg = -1
		v148.lastCone = -1
	end
	local v149
	if v_u_13 == nil then
		local v150 = v_u_4.PreferredInput
		v149 = v150 == Enum.PreferredInput.Touch and "touch" or (v150 == Enum.PreferredInput.Gamepad and "gamepad" or nil)
	elseif v_u_13 == "mouse" then
		v149 = nil
	else
		v149 = v_u_13
	end
	local v151 = v_u_10.Character
	local v152
	if v151 then
		v152 = v151:FindFirstChild("HumanoidRootPart")
		if not (v152 and v152:IsA("BasePart")) then
			v152 = nil
		end
	else
		v152 = v151
	end
	local v153 = v_u_5.CurrentCamera
	if not (v_u_12 and (p137 and (v149 and (v151 and (v152 and v153))))) then
		v_u_19 = nil
		v_u_28 = nil
		v_u_29 = nil
		local v154 = v_u_34
		v_u_34.lastDeg = -1
		v154.lastCone = -1
		return v143, p134
	end
	local v155 = v151:FindFirstChildOfClass("Humanoid")
	local v156
	if v155 == nil then
		v156 = false
	else
		v156 = v155.MoveDirection.Magnitude > 0.1
	end
	if v142 - v_u_23 >= 0.35 and not (v156 or (p139 or p141)) then
		v_u_19 = nil
		v_u_28 = nil
		v_u_29 = nil
		local v157 = v_u_34
		v_u_34.lastDeg = -1
		v157.lastCone = -1
		return v143, p134
	end
	local v158 = v153.CFrame.Position
	local v159 = CFrame.fromEulerAnglesYXZ(p136, p135, 0).LookVector
	local v160 = v152.Position
	if v147 or v142 - v_u_21 >= 0.05 then
		v_u_21 = v142
		v_u_27 = v149
		v_u_25 = v_u_51(v151, p139, p140, p141)
		local v161 = v_u_25
		local v162
		if v149 and v161 then
			local v163
			if v149 == "gamepad" then
				v163 = v_u_7.GAMEPAD
			else
				v163 = v_u_7.TOUCH
			end
			v162 = v163[v161]
		else
			v162 = nil
		end
		v_u_26 = v162
		if v_u_26 then
			local v164, v165 = v_u_131(v158, v159, v_u_26, p138, v151, v160)
			v_u_19 = v164
			v_u_20 = v165
		else
			v_u_19 = nil
		end
	end
	local v166 = v_u_26
	local v167 = v_u_19
	if not (v166 and v167) then
		v_u_19 = nil
		v_u_28 = nil
		v_u_29 = nil
		local v168 = v_u_34
		v_u_34.lastDeg = -1
		v168.lastCone = -1
		return v143, p134
	end
	if not v_u_98(v167, v158, v159, v166, v160) or v_u_74.deg > v_u_74.cone * 1.25 then
		v_u_19 = nil
		v_u_28 = nil
		v_u_29 = nil
		local v169 = v_u_34
		v_u_34.lastDeg = -1
		v169.lastCone = -1
		return v143, p134
	end
	local v170 = v_u_34
	v170.frames = v170.frames + 1
	local v171 = v_u_34
	local v172 = v_u_34
	local v173 = v_u_74.deg
	local v174 = v_u_74.cone
	v171.lastDeg = v173
	v172.lastCone = v174
	local v175 = (v_u_74.deg / v_u_74.cone - 0.6) / 0.4
	local v176 = math.clamp(v175, 0, 1)
	local v177 = 1 - v176 * v176 * (3 - v176 * 2)
	local v178 = (v_u_74.deg / v_u_74.cone - 0.85) / 0.4
	local v179 = math.clamp(v178, 0, 1)
	local v180 = 1 - v179 * v179 * (3 - v179 * 2)
	local v181
	if v146 and v177 > 0 then
		local v182 = (v_u_74.point - v158).Unit
		local v183 = -v182.X
		local v184 = -v182.Z
		local v185 = (math.atan2(v183, v184) - p135 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
		local v186 = v182.Y
		local v187 = math.clamp(v186, -1, 1)
		local v188 = math.asin(v187) - p136
		local v189 = p133 * v185 + p134 * v188 > 0
		local v190 = 1 - (1 - v166.friction) * v177 * (v189 and 0.35 or 1)
		v143 = v143 + p133 * (v190 - 1)
		v181 = p134 + p134 * (v190 - 1)
		if v190 < 0.999 then
			local v191 = v_u_34
			v191.slowed = v191.slowed + 1
		end
		if v_u_20 and v166.pull > 0 then
			local v192 = v185 * v185 + v188 * v188
			local v193 = math.sqrt(v192)
			local v194 = p133 * p133 + p134 * p134
			local v195 = math.sqrt(v194)
			if v193 > 0.0001 then
				local v196 = v166.pull * v177 * v195
				local v197 = v193 * 0.5
				local v198 = math.min(v196, v197)
				v143 = v143 + v185 / v193 * v198
				v181 = v181 + v188 / v193 * v198
				local v199 = v_u_34
				v199.pullDeg = v199.pullDeg + math.deg(v198)
			end
		end
	else
		v181 = p134
	end
	local _, _, _, _, v200 = v_u_73(v167)
	if v200 then
		local v201 = v160 + Vector3.new(0, 1.5, 0)
		local v202 = (v200.Position - v201).Unit
		local v203 = v_u_28
		if v203 and (v_u_29 == v167 and (p132 > 0 and p132 < 0.1)) then
			local v204 = -v202.X
			local v205 = -v202.Z
			local v206 = math.atan2(v204, v205)
			local v207 = -v203.X
			local v208 = -v203.Z
			local v209 = (v206 - math.atan2(v207, v208) + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
			local v210 = v202.Y
			local v211 = math.clamp(v210, -1, 1)
			local v212 = math.asin(v211)
			local v213 = v203.Y
			local v214 = math.clamp(v213, -1, 1)
			local v215 = v212 - math.asin(v214)
			if math.abs(v209) < 0.13962634015954636 and math.abs(v215) < 0.13962634015954636 then
				local v216 = p132 * 1.5707963267948966
				local v217 = v209 * v166.track * v180
				local v218 = -v216
				local v219 = math.clamp(v217, v218, v216)
				local v220 = v215 * v166.trackPitch * v180
				local v221 = -v216
				local v222 = math.clamp(v220, v221, v216)
				v143 = v143 + v219
				v181 = v181 + v222
				local v223 = v_u_34
				local v224 = v223.trackDeg
				local v225 = math.abs(v219) + math.abs(v222)
				v223.trackDeg = v224 + math.deg(v225)
			end
		end
		v_u_28 = v202
		v_u_29 = v167
	end
	return v143, v181
end
function v_u_7.Shot(p226, p227, p228, p229, p230, p231) -- name: Shot
	-- upvalues: (ref) v_u_13, (copy) v_u_4, (copy) v_u_10, (copy) v_u_5, (ref) v_u_12, (copy) v_u_51, (copy) v_u_7, (copy) v_u_131, (copy) v_u_98, (copy) v_u_73, (copy) v_u_74
	local v232
	if v_u_13 == nil then
		local v233 = v_u_4.PreferredInput
		v232 = v233 == Enum.PreferredInput.Touch and "touch" or (v233 == Enum.PreferredInput.Gamepad and "gamepad" or nil)
	elseif v_u_13 == "mouse" then
		v232 = nil
	else
		v232 = v_u_13
	end
	local v234 = v_u_10.Character
	local v235
	if v234 then
		v235 = v234:FindFirstChild("HumanoidRootPart")
		if not (v235 and v235:IsA("BasePart")) then
			v235 = nil
		end
	else
		v235 = v234
	end
	local v236 = v_u_5.CurrentCamera
	if not (v_u_12 and (v232 and (v234 and (v235 and v236)))) then
		return nil
	end
	local v237 = v_u_51(v234, p229, p230, p231)
	local v238
	if v232 and v237 then
		local v239
		if v232 == "gamepad" then
			v239 = v_u_7.GAMEPAD
		else
			v239 = v_u_7.TOUCH
		end
		v238 = v239[v237]
	else
		v238 = nil
	end
	if not (v238 and v237) then
		return nil
	end
	local v240 = v236.CFrame.Position
	local v241 = CFrame.fromEulerAnglesYXZ(p228, p227, 0).LookVector
	local v242, v243 = v_u_131(v240, v241, v238, p226, v234, v235.Position)
	if not (v242 and v_u_98(v242, v240, v241, v238, v235.Position)) then
		return nil
	end
	local _, _, _, _, v244 = v_u_73(v242)
	return v244 and {
		["model"] = v242,
		["part"] = v244,
		["point"] = v_u_74.point,
		["deg"] = v_u_74.deg,
		["cone"] = v_u_74.cone,
		["class"] = v237,
		["input"] = v232,
		["torsoVisible"] = v243
	} or nil
end
function v_u_7.Nudge(p245, p246) -- name: Nudge
	-- upvalues: (ref) v_u_30, (ref) v_u_31
	v_u_30 = p245
	v_u_31 = p245 / math.max(p246, 0.004166666666666667)
end
function v_u_7.IsAssistedInput() -- name: IsAssistedInput
	-- upvalues: (ref) v_u_13, (copy) v_u_4
	local v247
	if v_u_13 == nil then
		local v248 = v_u_4.PreferredInput
		v247 = v248 == Enum.PreferredInput.Touch and "touch" or (v248 == Enum.PreferredInput.Gamepad and "gamepad" or nil)
	elseif v_u_13 == "mouse" then
		v247 = nil
	else
		v247 = v_u_13
	end
	return v247 ~= nil
end
function v_u_7.InputKind() -- name: InputKind
	-- upvalues: (ref) v_u_13, (copy) v_u_4
	if v_u_13 == nil then
		local v249 = v_u_4.PreferredInput
		return v249 == Enum.PreferredInput.Touch and "touch" or (v249 == Enum.PreferredInput.Gamepad and "gamepad" or nil)
	elseif v_u_13 == "mouse" then
		return nil
	else
		return v_u_13
	end
end
function v_u_7.SetEnabled(p250) -- name: SetEnabled
	-- upvalues: (ref) v_u_12, (ref) v_u_19, (ref) v_u_28, (ref) v_u_29, (copy) v_u_34, (ref) v_u_30
	v_u_12 = p250 == true
	if not v_u_12 then
		v_u_19 = nil
		v_u_28 = nil
		v_u_29 = nil
		local v251 = v_u_34
		v_u_34.lastDeg = -1
		v251.lastCone = -1
		v_u_30 = 0
	end
end
function v_u_7.IsEnabled() -- name: IsEnabled
	-- upvalues: (ref) v_u_12
	return v_u_12
end
function v_u_7.TakeInjected() -- name: TakeInjected
	-- upvalues: (ref) v_u_33, (ref) v_u_32
	if v_u_33 <= 0 then
		return Vector2.zero
	end
	v_u_33 = v_u_33 - 1
	return v_u_32
end
function v_u_7.Stats() -- name: Stats
	-- upvalues: (ref) v_u_19, (copy) v_u_34, (ref) v_u_25, (ref) v_u_27
	return {
		["aimAssistTarget"] = not v_u_19 and "" or v_u_19.Name,
		["aimAssistDeg"] = v_u_34.lastDeg,
		["aimAssistCone"] = v_u_34.lastCone,
		["aimAssistFrames"] = v_u_34.frames,
		["aimAssistSlowed"] = v_u_34.slowed,
		["aimAssistTrackDeg"] = v_u_34.trackDeg,
		["aimAssistPullDeg"] = v_u_34.pullDeg,
		["aimAssistSearches"] = v_u_34.searches,
		["aimAssistRays"] = v_u_34.rays,
		["aimAssistClass"] = v_u_25 or "",
		["aimAssistInput"] = v_u_27 or ""
	}
end
function v_u_7.Debug(p252, p253, p254, p255) -- name: Debug
	-- upvalues: (copy) v_u_7, (ref) v_u_12, (ref) v_u_13, (copy) v_u_4, (ref) v_u_33, (copy) v_u_34, (copy) v_u_11, (ref) v_u_32
	if p252 == "state" then
		local v256 = v_u_7.Stats()
		v256.enabled = v_u_12
		v256.forced = v_u_13 or false
		local v257
		if v_u_13 == nil then
			local v258 = v_u_4.PreferredInput
			v257 = v258 == Enum.PreferredInput.Touch and "touch" or (v258 == Enum.PreferredInput.Gamepad and "gamepad" or nil)
		elseif v_u_13 == "mouse" then
			v257 = nil
		else
			v257 = v_u_13
		end
		v256.assisted = v257 ~= nil
		v256.injectLeft = v_u_33
		return v256
	end
	if p252 == "reset" then
		for v259 in v_u_34 do
			v_u_34[v259] = 0
		end
		local v260 = v_u_34
		v_u_34.lastDeg = -1
		v260.lastCone = -1
		return true
	end
	if not v_u_11 then
		return nil
	end
	if p252 == "force" then
		if p253 ~= "touch" and (p253 ~= "gamepad" and p253 ~= "mouse") then
			p253 = nil
		end
		v_u_13 = p253
		return v_u_13 or false
	end
	if p252 ~= "inject" then
		return nil
	end
	v_u_32 = Vector2.new(tonumber(p253) or 0, tonumber(p254) or 0)
	local v261 = tonumber(p255) or 1
	local v262 = math.floor(v261)
	v_u_33 = math.clamp(v262, 0, 100000)
	return true
end
return v_u_7