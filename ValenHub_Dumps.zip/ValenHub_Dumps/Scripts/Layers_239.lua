local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("SoundService")
local v3 = {}
local v_u_4 = {}
local v_u_5 = nil
function v3.Init(p6) -- name: Init
	-- upvalues: (ref) v_u_5, (copy) v_u_1, (copy) v_u_4
	v_u_5 = p6
	v_u_1.Heartbeat:Connect(function(p7)
		-- upvalues: (ref) v_u_4
		for _, v8 in v_u_4 do
			local v9 = -v8.rate * p7
			local v10 = 1 - math.exp(v9)
			v8.current = v8.current + (v8.target - v8.current) * v10
			local v11 = v8.target - v8.current
			if math.abs(v11) < 0.002 then
				v8.current = v8.target
			end
			local v12 = v8.sound
			if v8.current <= 0.001 and v8.target == 0 then
				v8.current = 0
				if v12.IsPlaying then
					v12:Pause()
				end
			elseif v8.target > 0 and not (v12.IsPlaying or v8.ended) then
				if v8.started then
					v12:Resume()
				else
					v8.started = true
					v12:Play()
				end
			end
			local v13 = v8.base * v8.current
			local v14 = v12.Volume - v13
			if math.abs(v14) <= 0.0001 then
				continue
			end
			v12.Volume = v13
		end
	end)
end
function v3.Get(p15, p16, p17) -- name: Get
	-- upvalues: (copy) v_u_4, (ref) v_u_5, (copy) v_u_2
	local v18 = v_u_4[p15]
	if v18 and v18.name == p16 then
		return v18
	end
	if v18 then
		v18.sound:Destroy()
		v_u_4[p15] = nil
	end
	local v_u_19 = v_u_5.Clone(p16)
	if not v_u_19 then
		return nil
	end
	v_u_19.Name = "Layer_" .. p15
	local v20 = v_u_19.Volume
	v_u_19.Volume = 0
	v_u_19.Parent = v_u_2
	local v_u_21 = {
		["key"] = nil,
		["name"] = nil,
		["sound"] = nil,
		["base"] = nil,
		["current"] = 0,
		["target"] = 0,
		["rate"] = nil,
		["ended"] = false,
		["started"] = false,
		["key"] = p15,
		["name"] = p16,
		["sound"] = v_u_19,
		["base"] = v20,
		["rate"] = p17 or 0.8
	}
	v_u_19.Ended:Connect(function()
		-- upvalues: (copy) v_u_19, (copy) v_u_21
		if not v_u_19.Looped then
			v_u_21.ended = true
		end
	end)
	v_u_4[p15] = v_u_21
	return v_u_21
end
function v3.Find(p22) -- name: Find
	-- upvalues: (copy) v_u_4
	return v_u_4[p22]
end
function v3.SetTarget(p23, p24, p25) -- name: SetTarget
	-- upvalues: (copy) v_u_4
	local v26 = v_u_4[p23]
	if v26 then
		v26.target = math.clamp(p24, 0, 2)
		if p25 then
			v26.rate = p25
		end
	end
end
function v3.Restart(p27, p28) -- name: Restart
	-- upvalues: (copy) v_u_4
	local v29 = v_u_4[p27]
	if v29 then
		v29.ended = false
		v29.started = true
		v29.sound.TimePosition = 0
		v29.sound:Play()
		v29.target = p28 or v29.target
	end
end
function v3.FadeAll(p30, p31) -- name: FadeAll
	-- upvalues: (copy) v_u_4
	for v32, v33 in v_u_4 do
		local v34 = #p30
		if string.sub(v32, 1, v34) ~= p30 or p31 and p31[v32] then
			continue
		end
		v33.target = 0
	end
end
function v3.Audible(p35) -- name: Audible
	-- upvalues: (copy) v_u_4
	local v36 = {}
	for v37, v38 in v_u_4 do
		local v39 = #p35
		if string.sub(v37, 1, v39) ~= p35 or (not v38.sound.IsPlaying or v38.current <= 0.02) then
			continue
		end
		table.insert(v36, v38)
	end
	table.sort(v36, function(p40, p41)
		return p40.current > p41.current
	end)
	return v36
end
function v3.Debug() -- name: Debug
	-- upvalues: (copy) v_u_4
	local v42 = {}
	for v43, v44 in v_u_4 do
		local v45 = string.format
		local v46 = v44.name
		local v47 = v44.current
		local v48 = v44.target
		local v49 = v44.sound.IsPlaying and " playing" or ""
		table.insert(v42, v45("%s=%s %.2f/%.2f%s", v43, v46, v47, v48, v49))
	end
	table.sort(v42)
	return v42
end
return v3