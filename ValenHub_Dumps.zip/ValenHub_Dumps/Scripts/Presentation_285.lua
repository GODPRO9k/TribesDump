local v1 = Color3.fromRGB(226, 160, 84)
local v2 = Color3.fromRGB(150, 110, 200)
local v3 = Color3.fromRGB(205, 180, 140)
local v_u_4 = {
	["Fists"] = {
		["crosshair"] = "Melee",
		["swings"] = nil,
		["swingSound"] = "Swing_Punch",
		["hitSound"] = "Hit_Punch",
		["hitDelay"] = 0.08,
		["noSlash"] = true,
		["swings"] = { "Punch_R", "Punch_L" }
	},
	["Sword"] = {
		["crosshair"] = "Melee",
		["hold"] = "Hold_Sword",
		["block"] = "Sword_Guard",
		["swings"] = nil,
		["swingSound"] = "Sword_Swing",
		["hitSound"] = "Sword_Hit",
		["hitDelay"] = 0.09,
		["equip"] = "Equip_Sword",
		["trail"] = 0.28,
		["slashColor"] = nil,
		["swings"] = { "Sword_Swing1", "Sword_Swing2", "Sword_Swing3" },
		["slashColor"] = v1
	},
	["Shield"] = {
		["crosshair"] = "Melee",
		["hold"] = "Shield_Hold",
		["block"] = "Shield_Block",
		["swings"] = nil,
		["swingSound"] = "Swing_Heavy",
		["hitSound"] = "Hit_Melee_Heavy",
		["hitDelay"] = 0.09,
		["equip"] = "Equip_Heavy",
		["noSlash"] = true,
		["shake"] = 0.25,
		["swings"] = { "Shield_Bash" }
	},
	["Gauntlets"] = {
		["crosshair"] = "Melee",
		["hold"] = "Gauntlets_Hold",
		["swings"] = nil,
		["lunge"] = "Gauntlets_Dash",
		["lungeAnimSpeed"] = 1,
		["swingSound"] = "Gauntlet_Swing",
		["hitSound"] = "Gauntlet_Hit",
		["lungeSound"] = "Gauntlet_Dash",
		["hitDelay"] = 0.07,
		["equip"] = "Gauntlet_Equip",
		["noSlash"] = true,
		["shake"] = 0.14,
		["swings"] = {
			"Gauntlets_Jab",
			"Gauntlets_Cross",
			"Gauntlets_Hook",
			"Gauntlets_Upper"
		}
	},
	["Scythe"] = {
		["crosshair"] = "Melee",
		["hold"] = "Scythe_Hold",
		["swings"] = nil,
		["lunge"] = "Scythe_Dash",
		["lungeAnimSpeed"] = 1,
		["lungeSound"] = "Scythe_Reap",
		["lungeSlash"] = true,
		["lungeLines"] = true,
		["refreshSound"] = "Charge_Full",
		["swingSound"] = "Scythe_Swing",
		["hitSound"] = "Scythe_Hit",
		["hitDelay"] = 0.2,
		["equip"] = "Equip_Heavy",
		["trail"] = 0.4,
		["slashColor"] = nil,
		["shake"] = 0.3,
		["slam"] = false,
		["swings"] = { "Scythe_Sweep1", "Scythe_Sweep2" },
		["slashColor"] = Color3.fromRGB(190, 200, 215)
	},
	["Katana"] = {
		["crosshair"] = "Melee",
		["hold"] = "Katana_Hold",
		["swings"] = nil,
		["parry"] = "Katana_Parry",
		["parryHold"] = "Katana_ParryHold",
		["swingSound"] = "Katana_Swing",
		["hitSound"] = "Katana_Hit",
		["parrySound"] = "Katana_Flick",
		["hitDelay"] = 0.08,
		["equip"] = "Katana_Draw",
		["trail"] = 0.24,
		["slashColor"] = nil,
		["shake"] = 0.16,
		["swings"] = {
			"Katana_Slash1",
			"Katana_Slash2",
			"Katana_Slash3",
			"Katana_Slash4"
		},
		["slashColor"] = Color3.fromRGB(150, 196, 236)
	},
	["Hatchets"] = {
		["crosshair"] = "Melee",
		["hold"] = "Hatchets_Hold",
		["swings"] = nil,
		["oneSwings"] = nil,
		["throw"] = "Hatchets_Throw",
		["swingSound"] = "Hatchet_Swing",
		["hitSound"] = "Hatchet_Hit",
		["throwSound"] = "Hatchet_Throw",
		["hitDelay"] = 0.08,
		["equip"] = "Hatchet_Catch",
		["trail"] = 0.2,
		["slashColor"] = nil,
		["shake"] = 0.16,
		["swings"] = {
			"Hatchets_ChopR",
			"Hatchets_ChopL",
			"Hatchets_ChopR",
			"Hatchets_Double"
		},
		["oneSwings"] = { "Hatchets_ChopR", "Hatchets_Backhand" },
		["slashColor"] = Color3.fromRGB(214, 170, 120)
	},
	["Axe"] = {
		["crosshair"] = "Melee",
		["hold"] = "Hold_Heavy",
		["swings"] = nil,
		["heavyCharge"] = "Axe_Charge",
		["heavySwing"] = "Axe_Heavy",
		["swingSound"] = "Axe_Swing",
		["heavySound"] = "Axe_Heavy",
		["chargeSound"] = "Melee_Charge",
		["hitSound"] = "Axe_Hit",
		["hitDelay"] = 0.2,
		["heavyDelay"] = 0.16,
		["equip"] = "Equip_Heavy",
		["trail"] = 0.4,
		["slashColor"] = nil,
		["shake"] = 0.3,
		["swings"] = { "Axe_Swing1", "Axe_Swing2" },
		["slashColor"] = v1
	},
	["Spear"] = {
		["crosshair"] = "Melee",
		["hold"] = "Hold_Spear",
		["swings"] = nil,
		["lungeCharge"] = "Spear_Charge",
		["lunge"] = "Spear_Stab",
		["swingSound"] = "Spear_Stab",
		["lungeSound"] = "Spear_Lunge",
		["chargeSound"] = "Spear_Charge",
		["hitSound"] = "Spear_Hit",
		["hitDelay"] = 0.1,
		["equip"] = "Equip_Blade",
		["trail"] = 0.25,
		["slashColor"] = nil,
		["noSlash"] = true,
		["swings"] = { "Spear_Stab" },
		["slashColor"] = v1
	},
	["Dagger"] = {
		["crosshair"] = "Melee",
		["hold"] = "Hold_Sword",
		["swings"] = nil,
		["swingSound"] = "Dagger_Swing",
		["hitSound"] = "Dagger_Hit",
		["critSound"] = "Backstab",
		["hitDelay"] = 0.06,
		["equip"] = "Equip_Blade",
		["trail"] = 0.18,
		["slashColor"] = nil,
		["swings"] = { "Dagger_Swing1", "Dagger_Swing2" },
		["slashColor"] = v2
	},
	["Club"] = {
		["crosshair"] = "Melee",
		["hold"] = "Hold_Heavy",
		["swings"] = nil,
		["swingSound"] = "Club_Swing",
		["hitSound"] = "Club_Hit",
		["hitDelay"] = 0.17,
		["equip"] = "Equip_Heavy",
		["trail"] = 0.35,
		["slashColor"] = nil,
		["shake"] = 0.35,
		["swingSpeed"] = 1.1,
		["swings"] = { "Axe_Swing1", "Axe_Swing2" },
		["slashColor"] = v3
	},
	["Bow"] = {
		["crosshair"] = "Bow",
		["hold"] = "Hold_Bow",
		["draw"] = "Bow_Draw",
		["aim"] = "Bow_Aim",
		["fire"] = "Bow_Fire",
		["drawSound"] = "ShortBow_Draw",
		["fullSound"] = "Bow_Full",
		["fireSound"] = "ShortBow_Fire",
		["bodySound"] = "Arrow_Flesh",
		["worldSound"] = "Arrow_Thunk",
		["equip"] = "Equip_Bow",
		["glow"] = nil,
		["glow"] = Color3.fromRGB(255, 196, 110)
	},
	["Crossbow"] = {
		["crosshair"] = "Gun",
		["hold"] = "Crossbow_Aim",
		["fire"] = "Crossbow_Fire",
		["fireAnimSpeed"] = 1,
		["reload"] = "Crossbow_Reload",
		["fireSound"] = "Crossbow_Fire",
		["reloadSound"] = "Crossbow_Crank",
		["reloadSound2"] = "Crossbow_Reload",
		["reloadDoneSound"] = "Crossbow_Ready",
		["emptySound"] = "Dry_Fire",
		["bodySound"] = "Arrow_Flesh",
		["worldSound"] = "Arrow_Thunk",
		["equip"] = "Equip_Crossbow",
		["kick"] = 2.2,
		["shake"] = 0.25
	},
	["Musket"] = {
		["crosshair"] = "Gun",
		["hold"] = "Crossbow_Aim",
		["fire"] = "Crossbow_Fire",
		["reload"] = "Crossbow_Reload",
		["fireSound"] = "Musket_Fire",
		["reloadSound"] = "Musket_Reload",
		["reloadDoneSound"] = "Gun_Cock",
		["emptySound"] = "Dry_Fire",
		["bodySound"] = "Hit_Melee_Heavy",
		["worldSound"] = "Impact_Dirt",
		["equip"] = "Equip_Gun",
		["kick"] = 11,
		["shake"] = 0.55,
		["puff"] = true,
		["flash"] = true
	},
	["Pistol"] = {
		["crosshair"] = "Gun",
		["hold"] = "Pistol_Hold",
		["aim"] = "Pistol_Aim",
		["fire"] = "Pistol_Fire",
		["fireAnimSpeed"] = 1,
		["reload"] = "Pistol_Reload",
		["fireSound"] = "Flintlock_Fire",
		["reloadSound"] = "Flintlock_Reload",
		["reloadDoneSound"] = "Gun_Cock",
		["emptySound"] = "Dry_Fire",
		["bodySound"] = "Hit_Melee_Heavy",
		["worldSound"] = "Impact_Dirt",
		["equip"] = "Equip_Gun",
		["kick"] = 7,
		["shake"] = 0.35,
		["puff"] = true,
		["flash"] = true
	},
	["Blunderbuss"] = {
		["crosshair"] = "Spread",
		["hold"] = "Crossbow_Aim",
		["fire"] = "Crossbow_Fire",
		["reload"] = "Crossbow_Reload",
		["fireSound"] = "Blunderbuss_Fire",
		["reloadSound"] = "Blunderbuss_Reload",
		["reloadDoneSound"] = "Gun_Cock",
		["emptySound"] = "Dry_Fire",
		["bodySound"] = "Hit_Melee",
		["worldSound"] = "Impact_Dirt",
		["equip"] = "Equip_Gun",
		["kick"] = 13,
		["shake"] = 0.7,
		["puff"] = true,
		["flash"] = true
	},
	["Knives"] = {
		["crosshair"] = "Throw",
		["hold"] = "Hold_Item",
		["throw"] = "Throw",
		["throwSound"] = "Knife_Throw",
		["readySound"] = "Knife_Ready",
		["bodySound"] = "Knife_Hit",
		["worldSound"] = "Knife_Thunk",
		["equip"] = "Equip_Blade",
		["throwAnimSpeed"] = 1.8
	},
	["Javelin"] = {
		["crosshair"] = "Throw",
		["hold"] = "Hold_Spear",
		["windup"] = "Throw_Windup",
		["throw"] = "Throw",
		["windupSound"] = "Javelin_Draw",
		["throwSound"] = "Javelin_Throw",
		["bodySound"] = "Spear_Hit",
		["worldSound"] = "Javelin_Hit",
		["equip"] = "Equip_Item",
		["arc"] = nil,
		["arc"] = Color3.fromRGB(255, 225, 170)
	},
	["Sling"] = {
		["crosshair"] = "Throw",
		["hold"] = "Hold_Item",
		["throw"] = "Throw",
		["throwSound"] = "Sling_Fire",
		["whirlLoop"] = "Sling_Whirl",
		["bodySound"] = "Stone_Hit",
		["worldSound"] = "Impact_Stone",
		["equip"] = "Equip_Bow",
		["throwAnimSpeed"] = 1.5
	},
	["Bomb"] = {
		["crosshair"] = "Throw",
		["hold"] = "Hold_Item",
		["windup"] = "Throw_Windup",
		["throw"] = "Throw",
		["windupSound"] = "Throw_Windup",
		["throwSound"] = "FireBomb_Throw",
		["fuseLoop"] = "FireBomb_Fuse",
		["equip"] = "Equip_Item",
		["arc"] = nil,
		["arcSmoke"] = nil,
		["arc"] = Color3.fromRGB(255, 150, 60),
		["arcSmoke"] = Color3.fromRGB(200, 204, 212)
	},
	["Herbs"] = {
		["crosshair"] = "Use",
		["hold"] = "Hold_Item",
		["use"] = "Use_Bandage",
		["useSound"] = "Herbs_Chew",
		["healSound"] = "Herbs_Heal",
		["doneSound"] = "Heal_Done",
		["label"] = "CHEWING HERBS",
		["color"] = nil,
		["equip"] = "Equip_Item",
		["color"] = Color3.fromRGB(120, 220, 110)
	},
	["Trap"] = {
		["crosshair"] = "Use",
		["hold"] = "Hold_Item",
		["use"] = "Use_Bandage",
		["useSound"] = "Trap_Set",
		["armedSound"] = "Trap_Armed",
		["snapSound"] = "Trap_Snap",
		["label"] = "SETTING TRAP",
		["color"] = nil,
		["equip"] = "Equip_Item",
		["color"] = Color3.fromRGB(215, 170, 110)
	},
	["Horn"] = {
		["crosshair"] = "Use",
		["hold"] = "Hold_Item",
		["use"] = "Use_Drink",
		["useSound"] = "Equip_Item",
		["label"] = "BLOWING THE HORN",
		["color"] = nil,
		["equip"] = "Equip_Item",
		["color"] = Color3.fromRGB(226, 190, 110)
	}
}
local v_u_5 = {
	["longbow"] = {
		["drawSound"] = "Longbow_Draw",
		["fireSound"] = "Longbow_Fire",
		["hold"] = "Headhunter_Aim",
		["fire"] = "Headhunter_Shoot",
		["fireAnimSpeed"] = 1,
		["draw"] = false,
		["aim"] = false
	},
	["smoke_bomb"] = {
		["throwSound"] = "Throw",
		["fuseLoop"] = "FireBomb_Fuse"
	},
	["bandage"] = {
		["useSound"] = "Bandage_Wrap",
		["healSound"] = "Herbs_Heal",
		["label"] = "BANDAGING",
		["color"] = nil,
		["color"] = Color3.fromRGB(230, 214, 180)
	},
	["palisade"] = {
		["useSound"] = "Equip_Heavy",
		["label"] = "BUILDING",
		["color"] = nil,
		["color"] = Color3.fromRGB(214, 180, 130)
	},
	["harpoon"] = {
		["throwSound"] = "Harpoon_Throw",
		["bodySound"] = "Harpoon_Hit",
		["worldSound"] = "Harpoon_Thunk",
		["equip"] = "Equip_Heavy",
		["throwAnimSpeed"] = 1.05,
		["recoil"] = 3,
		["shake"] = 0.3
	},
	["healing_tonic"] = {
		["useSound"] = "Drink",
		["label"] = "DRINKING TONIC",
		["color"] = nil,
		["color"] = Color3.fromRGB(110, 200, 170)
	},
	["caltrops"] = {
		["windupSound"] = "Throw_Windup",
		["throwSound"] = "Throw",
		["fuseLoop"] = false,
		["arc"] = nil,
		["arc"] = Color3.fromRGB(196, 200, 210)
	},
	["beehive"] = {
		["windupSound"] = "Throw_Windup",
		["throwSound"] = "Throw",
		["fuseLoop"] = "Bees_Loop",
		["arc"] = nil,
		["arc"] = Color3.fromRGB(236, 190, 70)
	}
}
local v_u_6 = {}
return {
	["For"] = function(p7, p8) -- name: For
		-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_6
		local v9 = v_u_4[p8 or "Fists"] or v_u_4.Fists
		local v10
		if p7 then
			v10 = v_u_5[p7]
		else
			v10 = p7
		end
		if not v10 then
			return v9
		end
		local v11 = p7 .. "|" .. (p8 or "")
		local v12 = v_u_6[v11]
		if v12 then
			return v12
		end
		local v13 = table.clone(v9)
		for v14, v15 in v10 do
			if v15 == false then
				v13[v14] = nil
			else
				v13[v14] = v15
			end
		end
		v_u_6[v11] = v13
		return v13
	end,
	["Kind"] = function(p16) -- name: Kind
		-- upvalues: (copy) v_u_4
		return v_u_4[p16 or "Fists"] or v_u_4.Fists
	end
}