local v1, v2 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserExcludeNonCollidableForPathfinding")
end)
local v_u_3 = v1 and v2
local v4, v5 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserClickToMoveSupportAgentCanClimb2")
end)
local v_u_6 = v4 and v5
local v_u_7 = game:GetService("UserInputService")
local v_u_8 = game:GetService("PathfindingService")
local v9 = game:GetService("Players")
game:GetService("Debris")
local v_u_10 = game:GetService("Workspace")
local v_u_11 = game:GetService("CollectionService")
local v_u_12 = game:GetService("GuiService")
local v13 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
local v_u_14 = v13.getUserFlag("UserRaycastUpdateAPI2")
local v_u_15 = v13.getUserFlag("UserPlayerScriptsCTMDirectPlayerData")
local v_u_16 = v13.getUserFlag("UserPSIASClickToMoveRelaxTeleport")
local v_u_17 = v13.getUserFlag("UserPlayerScriptsRefactor2")
local v_u_18 = v13.getUserFlag("UserDoubleJumpButtonFix")
local v19 = script.Parent.Parent:WaitForChild("InputContexts"):WaitForChild("CharacterContext")
local v_u_20 = v19:WaitForChild("ClickToMoveAction")
local v_u_21 = v19:WaitForChild("ClickToMovePositionAction")
local v_u_22 = true
local v_u_23 = true
local v_u_24 = false
local v_u_25 = 1
local v_u_26 = 8
local v_u_27 = v9.LocalPlayer
local v_u_28 = require(script.Parent:WaitForChild("ClickToMoveDisplay"))
local v_u_29 = RaycastParams.new()
v_u_29.FilterType = Enum.RaycastFilterType.Exclude
local v_u_30 = {}
if not v_u_14 then
	local function v_u_33(p31) -- name: FindCharacterAncestor
		-- upvalues: (copy) v_u_33
		if p31 then
			local v32 = p31:FindFirstChildOfClass("Humanoid")
			if v32 then
				return p31, v32
			else
				return v_u_33(p31.Parent)
			end
		else
			return
		end
	end
	v_u_30.FindCharacterAncestor = v_u_33
	local function v_u_44(p34, p35, p36) -- name: Raycast
		-- upvalues: (copy) v_u_10, (copy) v_u_33, (copy) v_u_44
		local v37 = p36 or {}
		local v38, v39, v40, v41 = v_u_10:FindPartOnRayWithIgnoreList(p34, v37)
		if not v38 then
			return nil, nil
		end
		if p35 and v38.CanCollide == false then
			local v42 = not v38 or v38:FindFirstChildOfClass("Humanoid")
			if not v42 then
				local v43
				v43, v42 = v_u_33(v38.Parent)
			end
			if v42 == nil then
				table.insert(v37, v38)
				return v_u_44(p34, p35, v37)
			end
		end
		return v38, v39, v40, v41
	end
	v_u_30.Raycast = v_u_44
end
local v_u_45 = {}
local v_u_46 = nil
local v_u_47 = nil
local v_u_48 = nil
local v_u_49 = nil
local function v_u_60(p50) -- name: UpdateIgnoreTag
	-- upvalues: (ref) v_u_47, (ref) v_u_48, (ref) v_u_49, (ref) v_u_46, (copy) v_u_27, (copy) v_u_11
	if p50 ~= v_u_47 then
		if v_u_48 then
			v_u_48:Disconnect()
			v_u_48 = nil
		end
		if v_u_49 then
			v_u_49:Disconnect()
			v_u_49 = nil
		end
		v_u_47 = p50
		local v51 = {}
		local v52 = v_u_27
		if v52 then
			v52 = v_u_27.Character
		end
		__set_list(v51, 1, {v52})
		v_u_46 = v51
		if v_u_47 ~= nil then
			local v53 = v_u_11:GetTagged(v_u_47)
			for _, v54 in ipairs(v53) do
				local v55 = v_u_46
				table.insert(v55, v54)
			end
			v_u_48 = v_u_11:GetInstanceAddedSignal(v_u_47):Connect(function(p56)
				-- upvalues: (ref) v_u_46
				local v57 = v_u_46
				table.insert(v57, p56)
			end)
			v_u_49 = v_u_11:GetInstanceRemovedSignal(v_u_47):Connect(function(p58)
				-- upvalues: (ref) v_u_46
				for v59 = 1, #v_u_46 do
					if v_u_46[v59] ~= p58 then
						continue
					end
					v_u_46[v59] = v_u_46[#v_u_46]
					table.remove(v_u_46)
					return
				end
			end)
		end
	end
end
local function v_u_125(p61) -- name: getCollidableExtentsSize
	if p61 == nil or p61.PrimaryPart == nil then
		return
	else
		assert(p61, "")
		local v62 = p61.PrimaryPart
		assert(v62, "")
		local v63 = p61.PrimaryPart.CFrame:Inverse()
		local v64 = Vector3.new(inf, inf, inf)
		local v65 = Vector3.new(-inf, -inf, -inf)
		for _, v66 in pairs(p61:GetDescendants()) do
			if not (v66:IsA("BasePart") and v66.CanCollide) then
				continue
			end
			local v67 = v63 * v66.CFrame
			local v68 = v66.Size.X / 2
			local v69 = v66.Size.Y / 2
			local v70 = v66.Size.Z / 2
			local v71 = Vector3.new(v68, v69, v70)
			local v72 = {}
			local v73 = v71.X
			local v74 = v71.Y
			local v75 = v71.Z
			local v76 = Vector3.new(v73, v74, v75)
			local v77 = v71.X
			local v78 = v71.Y
			local v79 = -v71.Z
			local v80 = Vector3.new(v77, v78, v79)
			local v81 = v71.X
			local v82 = -v71.Y
			local v83 = v71.Z
			local v84 = Vector3.new(v81, v82, v83)
			local v85 = v71.X
			local v86 = -v71.Y
			local v87 = -v71.Z
			local v88 = Vector3.new(v85, v86, v87)
			local v89 = -v71.X
			local v90 = v71.Y
			local v91 = v71.Z
			local v92 = Vector3.new(v89, v90, v91)
			local v93 = -v71.X
			local v94 = v71.Y
			local v95 = -v71.Z
			local v96 = Vector3.new(v93, v94, v95)
			local v97 = -v71.X
			local v98 = -v71.Y
			local v99 = v71.Z
			local v100 = Vector3.new(v97, v98, v99)
			local v101 = -v71.X
			local v102 = -v71.Y
			local v103 = -v71.Z
			__set_list(v72, 1, {v76, v80, v84, v88, v92, v96, v100, (Vector3.new(v101, v102, v103))})
			for _, v104 in ipairs(v72) do
				local v105 = v67 * v104
				local v106 = v64.X
				local v107 = v105.X
				local v108 = math.min(v106, v107)
				local v109 = v64.Y
				local v110 = v105.Y
				local v111 = math.min(v109, v110)
				local v112 = v64.Z
				local v113 = v105.Z
				local v114 = math.min(v112, v113)
				v64 = Vector3.new(v108, v111, v114)
				local v115 = v65.X
				local v116 = v105.X
				local v117 = math.max(v115, v116)
				local v118 = v65.Y
				local v119 = v105.Y
				local v120 = math.max(v118, v119)
				local v121 = v65.Z
				local v122 = v105.Z
				local v123 = math.max(v121, v122)
				v65 = Vector3.new(v117, v120, v123)
			end
		end
		local v124 = v65 - v64
		if v124.X < 0 or (v124.Y < 0 or v124.Z < 0) then
			return nil
		else
			return v124
		end
	end
end
local function v_u_200(p126, p127, p128) -- name: Pather
	-- upvalues: (ref) v_u_24, (copy) v_u_27, (copy) v_u_45, (ref) v_u_25, (copy) v_u_3, (copy) v_u_125, (copy) v_u_6, (copy) v_u_8, (ref) v_u_22, (copy) v_u_28, (ref) v_u_26, (copy) v_u_16, (copy) v_u_14, (copy) v_u_29, (ref) v_u_46, (copy) v_u_10
	local v_u_129 = {}
	local v130
	if p128 == nil then
		v130 = v_u_24
		p128 = true
	else
		v130 = p128
	end
	v_u_129.Cancelled = false
	v_u_129.Started = false
	v_u_129.Finished = Instance.new("BindableEvent")
	v_u_129.PathFailed = Instance.new("BindableEvent")
	v_u_129.PathComputing = false
	v_u_129.PathComputed = false
	v_u_129.OriginalTargetPoint = p126
	v_u_129.TargetPoint = p126
	v_u_129.TargetSurfaceNormal = p127
	v_u_129.DiedConn = nil
	v_u_129.SeatedConn = nil
	v_u_129.BlockedConn = nil
	v_u_129.TeleportedConn = nil
	v_u_129.CurrentPoint = 0
	v_u_129.HumanoidOffsetFromPath = Vector3.new(0, 0, 0)
	v_u_129.CurrentWaypointPosition = nil
	v_u_129.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
	v_u_129.CurrentWaypointPlaneDistance = 0
	v_u_129.CurrentWaypointNeedsJump = false
	v_u_129.CurrentHumanoidPosition = Vector3.new(0, 0, 0)
	v_u_129.CurrentHumanoidVelocity = 0
	v_u_129.NextActionMoveDirection = Vector3.new(0, 0, 0)
	v_u_129.NextActionJump = false
	v_u_129.Timeout = 0
	local v131 = v_u_27
	local v132
	if v131 then
		v132 = v131.Character
	else
		v132 = v131
	end
	local v133
	if v132 then
		v133 = v_u_45[v131]
		if not v133 or v133.Parent ~= v132 then
			v_u_45[v131] = nil
			v133 = v132:FindFirstChildOfClass("Humanoid")
			if v133 then
				v_u_45[v131] = v133
			end
		end
	else
		v133 = nil
	end
	v_u_129.Humanoid = v133
	v_u_129.OriginPoint = nil
	v_u_129.AgentCanFollowPath = false
	v_u_129.DirectPath = false
	v_u_129.DirectPathRiseFirst = false
	v_u_129.stopTraverseFunc = nil
	v_u_129.setPointFunc = nil
	v_u_129.pointList = nil
	local v134 = v_u_129.Humanoid
	if v134 then
		v134 = v_u_129.Humanoid.RootPart
	end
	if v134 then
		v_u_129.OriginPoint = v134.CFrame.Position
		local v135 = 2
		local v136 = 5
		local v137 = true
		local v138 = v_u_129.Humanoid.SeatPart
		if v138 and v138:IsA("VehicleSeat") then
			local v139 = v138:FindFirstAncestorOfClass("Model")
			if v139 then
				local v140 = v139.PrimaryPart
				v139.PrimaryPart = v138
				if p128 then
					local v141 = v139:GetExtentsSize()
					local v142 = v_u_25 * 0.5
					local v143 = v141.X * v141.X + v141.Z * v141.Z
					v135 = v142 * math.sqrt(v143)
					v136 = v_u_25 * v141.Y
					v_u_129.AgentCanFollowPath = true
					v_u_129.DirectPath = p128
					v137 = false
				end
				v139.PrimaryPart = v140
			end
		else
			local v144 = nil
			if v_u_3 then
				local v145 = v_u_27
				if v145 then
					v145 = v_u_27.Character
				end
				if v145 ~= nil then
					v144 = v_u_125(v145)
				end
			end
			if v144 == nil then
				local v146 = v_u_27
				if v146 then
					v146 = v_u_27.Character
				end
				v144 = v146:GetExtentsSize()
			end
			assert(v144, "")
			local v147 = v_u_25 * 0.5
			local v148 = v144.X * v144.X + v144.Z * v144.Z
			v135 = v147 * math.sqrt(v148)
			v136 = v_u_25 * v144.Y
			v137 = v_u_129.Humanoid.JumpPower > 0
			v_u_129.AgentCanFollowPath = true
			v_u_129.DirectPath = v130
			v_u_129.DirectPathRiseFirst = v_u_129.Humanoid.Sit
		end
		if v_u_6 then
			v_u_129.pathResult = v_u_8:CreatePath({
				["AgentRadius"] = nil,
				["AgentHeight"] = nil,
				["AgentCanJump"] = nil,
				["AgentCanClimb"] = true,
				["AgentRadius"] = v135,
				["AgentHeight"] = v136,
				["AgentCanJump"] = v137
			})
		else
			v_u_129.pathResult = v_u_8:CreatePath({
				["AgentRadius"] = v135,
				["AgentHeight"] = v136,
				["AgentCanJump"] = v137
			})
		end
	end
	function v_u_129.Cleanup(_) -- name: Cleanup
		-- upvalues: (copy) v_u_129
		if v_u_129.stopTraverseFunc then
			v_u_129.stopTraverseFunc()
			v_u_129.stopTraverseFunc = nil
		end
		if v_u_129.BlockedConn then
			v_u_129.BlockedConn:Disconnect()
			v_u_129.BlockedConn = nil
		end
		if v_u_129.DiedConn then
			v_u_129.DiedConn:Disconnect()
			v_u_129.DiedConn = nil
		end
		if v_u_129.SeatedConn then
			v_u_129.SeatedConn:Disconnect()
			v_u_129.SeatedConn = nil
		end
		if v_u_129.TeleportedConn then
			v_u_129.TeleportedConn:Disconnect()
			v_u_129.TeleportedConn = nil
		end
		v_u_129.Started = false
	end
	function v_u_129.Cancel(_) -- name: Cancel
		-- upvalues: (copy) v_u_129
		v_u_129.Cancelled = true
		v_u_129:Cleanup()
	end
	function v_u_129.IsActive(_) -- name: IsActive
		-- upvalues: (copy) v_u_129
		local v149 = v_u_129.AgentCanFollowPath and v_u_129.Started
		if v149 then
			v149 = not v_u_129.Cancelled
		end
		return v149
	end
	function v_u_129.OnPathInterrupted(_) -- name: OnPathInterrupted
		-- upvalues: (copy) v_u_129
		v_u_129.Cancelled = true
		v_u_129:OnPointReached(false)
	end
	function v_u_129.ComputePath(_) -- name: ComputePath
		-- upvalues: (copy) v_u_129
		if v_u_129.OriginPoint then
			if v_u_129.PathComputed or v_u_129.PathComputing then
				return
			end
			v_u_129.PathComputing = true
			if v_u_129.AgentCanFollowPath then
				if v_u_129.DirectPath then
					v_u_129.pointList = { PathWaypoint.new(v_u_129.OriginPoint, Enum.PathWaypointAction.Walk), PathWaypoint.new(v_u_129.TargetPoint, v_u_129.DirectPathRiseFirst and Enum.PathWaypointAction.Jump or Enum.PathWaypointAction.Walk) }
					v_u_129.PathComputed = true
				else
					v_u_129.pathResult:ComputeAsync(v_u_129.OriginPoint, v_u_129.TargetPoint)
					v_u_129.pointList = v_u_129.pathResult:GetWaypoints()
					v_u_129.BlockedConn = v_u_129.pathResult.Blocked:Connect(function(p150)
						-- upvalues: (ref) v_u_129
						v_u_129:OnPathBlocked(p150)
					end)
					v_u_129.PathComputed = v_u_129.pathResult.Status == Enum.PathStatus.Success
				end
			end
			v_u_129.PathComputing = false
		end
	end
	function v_u_129.IsValidPath(_) -- name: IsValidPath
		-- upvalues: (copy) v_u_129
		v_u_129:ComputePath()
		local v151 = v_u_129.PathComputed
		if v151 then
			v151 = v_u_129.AgentCanFollowPath
		end
		return v151
	end
	v_u_129.Recomputing = false
	function v_u_129.OnPathBlocked(_, p152) -- name: OnPathBlocked
		-- upvalues: (copy) v_u_129, (ref) v_u_22, (ref) v_u_28
		if v_u_129.CurrentPoint <= p152 and not v_u_129.Recomputing then
			v_u_129.Recomputing = true
			if v_u_129.stopTraverseFunc then
				v_u_129.stopTraverseFunc()
				v_u_129.stopTraverseFunc = nil
			end
			v_u_129.OriginPoint = v_u_129.Humanoid.RootPart.CFrame.Position
			v_u_129.pathResult:ComputeAsync(v_u_129.OriginPoint, v_u_129.TargetPoint)
			v_u_129.pointList = v_u_129.pathResult:GetWaypoints()
			if #v_u_129.pointList > 0 then
				v_u_129.HumanoidOffsetFromPath = v_u_129.pointList[1].Position - v_u_129.OriginPoint
			end
			v_u_129.PathComputed = v_u_129.pathResult.Status == Enum.PathStatus.Success
			if v_u_22 then
				local v153 = v_u_129
				local v154 = v_u_129
				local v155, v156 = v_u_28.CreatePathDisplay(v_u_129.pointList)
				v153.stopTraverseFunc = v155
				v154.setPointFunc = v156
			end
			if v_u_129.PathComputed then
				v_u_129.CurrentPoint = 1
				v_u_129:OnPointReached(true)
			else
				v_u_129.PathFailed:Fire()
				v_u_129:Cleanup()
			end
			v_u_129.Recomputing = false
		end
	end
	function v_u_129.OnRenderStepped(_, p157) -- name: OnRenderStepped
		-- upvalues: (copy) v_u_129, (ref) v_u_26
		if v_u_129.Started and not v_u_129.Cancelled then
			v_u_129.Timeout = v_u_129.Timeout + p157
			if v_u_26 < v_u_129.Timeout then
				v_u_129:OnPointReached(false)
				return
			end
			v_u_129.CurrentHumanoidPosition = v_u_129.Humanoid.RootPart.Position + v_u_129.HumanoidOffsetFromPath
			v_u_129.CurrentHumanoidVelocity = v_u_129.Humanoid.RootPart.Velocity
			while v_u_129.Started and v_u_129:IsCurrentWaypointReached() do
				v_u_129:OnPointReached(true)
			end
			if v_u_129.Started then
				v_u_129.NextActionMoveDirection = v_u_129.CurrentWaypointPosition - v_u_129.CurrentHumanoidPosition
				if v_u_129.NextActionMoveDirection.Magnitude > 1e-6 then
					v_u_129.NextActionMoveDirection = v_u_129.NextActionMoveDirection.Unit
				else
					v_u_129.NextActionMoveDirection = Vector3.new(0, 0, 0)
				end
				if v_u_129.CurrentWaypointNeedsJump then
					v_u_129.NextActionJump = true
					v_u_129.CurrentWaypointNeedsJump = false
					return
				end
				v_u_129.NextActionJump = false
			end
		end
	end
	function v_u_129.IsCurrentWaypointReached(_) -- name: IsCurrentWaypointReached
		-- upvalues: (copy) v_u_129
		local v158
		if v_u_129.CurrentWaypointPlaneNormal == Vector3.new(0, 0, 0) then
			v158 = true
		else
			local v159 = v_u_129.CurrentWaypointPlaneNormal:Dot(v_u_129.CurrentHumanoidPosition) - v_u_129.CurrentWaypointPlaneDistance
			local v160 = 0.0625 * -v_u_129.CurrentWaypointPlaneNormal:Dot(v_u_129.CurrentHumanoidVelocity)
			v158 = v159 < math.max(1, v160)
		end
		if v158 then
			v_u_129.CurrentWaypointPosition = nil
			v_u_129.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
			v_u_129.CurrentWaypointPlaneDistance = 0
		end
		return v158
	end
	function v_u_129.OnPointReached(_, p161) -- name: OnPointReached
		-- upvalues: (copy) v_u_129
		if p161 and not v_u_129.Cancelled then
			if v_u_129.setPointFunc then
				v_u_129.setPointFunc(v_u_129.CurrentPoint)
			end
			local v162 = v_u_129.CurrentPoint + 1
			if #v_u_129.pointList < v162 then
				if v_u_129.stopTraverseFunc then
					v_u_129.stopTraverseFunc()
				end
				v_u_129.Finished:Fire()
				v_u_129:Cleanup()
			else
				local v163 = v_u_129.pointList[v_u_129.CurrentPoint]
				local v164 = v_u_129.pointList[v162]
				local v165 = v_u_129.Humanoid:GetState()
				if (v165 == Enum.HumanoidStateType.FallingDown or v165 == Enum.HumanoidStateType.Freefall) and true or v165 == Enum.HumanoidStateType.Jumping then
					local v166 = v164.Action == Enum.PathWaypointAction.Jump
					if not v166 and v_u_129.CurrentPoint > 1 then
						local v167 = v_u_129.pointList[v_u_129.CurrentPoint - 1]
						local v168 = v163.Position - v167.Position
						local v169 = v164.Position - v163.Position
						v166 = Vector2.new(v168.x, v168.z).Unit:Dot(Vector2.new(v169.x, v169.z).Unit) < 0.996
					end
					if v166 then
						v_u_129.Humanoid.FreeFalling:Wait()
						wait(0.1)
					end
				end
				v_u_129:MoveToNextWayPoint(v163, v164, v162)
			end
		else
			v_u_129.PathFailed:Fire()
			v_u_129:Cleanup()
			return
		end
	end
	function v_u_129.MoveToNextWayPoint(_, p170, p171, p172) -- name: MoveToNextWayPoint
		-- upvalues: (copy) v_u_129, (ref) v_u_6
		v_u_129.CurrentWaypointPlaneNormal = p170.Position - p171.Position
		if not v_u_6 or p171.Label ~= "Climb" then
			local v173 = v_u_129
			local v174 = v_u_129.CurrentWaypointPlaneNormal.X
			local v175 = v_u_129.CurrentWaypointPlaneNormal.Z
			v173.CurrentWaypointPlaneNormal = Vector3.new(v174, 0, v175)
		end
		if v_u_129.CurrentWaypointPlaneNormal.Magnitude > 1e-6 then
			v_u_129.CurrentWaypointPlaneNormal = v_u_129.CurrentWaypointPlaneNormal.Unit
			v_u_129.CurrentWaypointPlaneDistance = v_u_129.CurrentWaypointPlaneNormal:Dot(p171.Position)
		else
			v_u_129.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
			v_u_129.CurrentWaypointPlaneDistance = 0
		end
		v_u_129.CurrentWaypointNeedsJump = p171.Action == Enum.PathWaypointAction.Jump
		v_u_129.CurrentWaypointPosition = p171.Position
		v_u_129.CurrentPoint = p172
		v_u_129.Timeout = 0
	end
	function v_u_129.Start(_, p176) -- name: Start
		-- upvalues: (copy) v_u_129, (ref) v_u_28, (ref) v_u_22, (ref) v_u_16
		if v_u_129.AgentCanFollowPath then
			if v_u_129.Started then
				return
			else
				v_u_129.Started = true
				v_u_28.CancelFailureAnimation()
				if v_u_22 and (p176 == nil or p176) then
					local v177 = v_u_129
					local v178 = v_u_129
					local v179, v180 = v_u_28.CreatePathDisplay(v_u_129.pointList, v_u_129.OriginalTargetPoint)
					v177.stopTraverseFunc = v179
					v178.setPointFunc = v180
				end
				if #v_u_129.pointList > 0 then
					local v181 = v_u_129
					local v182 = v_u_129.pointList[1].Position.Y - v_u_129.OriginPoint.Y
					v181.HumanoidOffsetFromPath = Vector3.new(0, v182, 0)
					v_u_129.CurrentHumanoidPosition = v_u_129.Humanoid.RootPart.Position + v_u_129.HumanoidOffsetFromPath
					v_u_129.CurrentHumanoidVelocity = v_u_129.Humanoid.RootPart.Velocity
					v_u_129.SeatedConn = v_u_129.Humanoid.Seated:Connect(function(_, _)
						-- upvalues: (ref) v_u_129
						v_u_129:OnPathInterrupted()
					end)
					v_u_129.DiedConn = v_u_129.Humanoid.Died:Connect(function()
						-- upvalues: (ref) v_u_129
						v_u_129:OnPathInterrupted()
					end)
					if v_u_16 then
						v_u_129.lastPosition = v_u_129.Humanoid.RootPart.CFrame.Position
						v_u_129.TeleportedConn = v_u_129.Humanoid.RootPart:GetPropertyChangedSignal("CFrame"):Connect(function()
							-- upvalues: (ref) v_u_129
							local v183 = v_u_129.Humanoid.RootPart.CFrame.Position
							local v184 = (v183 - v_u_129.lastPosition).Magnitude
							v_u_129.lastPosition = v183
							if v_u_129.Humanoid.WalkSpeed < v184 then
								v_u_129:OnPathInterrupted()
							end
						end)
					else
						v_u_129.TeleportedConn = v_u_129.Humanoid.RootPart:GetPropertyChangedSignal("CFrame"):Connect(function()
							-- upvalues: (ref) v_u_129
							v_u_129:OnPathInterrupted()
						end)
					end
					v_u_129.CurrentPoint = 1
					v_u_129:OnPointReached(true)
				else
					v_u_129.PathFailed:Fire()
					if v_u_129.stopTraverseFunc then
						v_u_129.stopTraverseFunc()
					end
				end
			end
		else
			v_u_129.PathFailed:Fire()
			return
		end
	end
	local v185 = v_u_129.TargetPoint + v_u_129.TargetSurfaceNormal * 1.5
	if v_u_14 then
		local v186 = v_u_29
		local v187
		if v_u_46 then
			v187 = v_u_46
		else
			v_u_46 = {}
			local v188 = v_u_46
			assert(v188, "")
			local v189 = v_u_46
			local v190 = v_u_27
			if v190 then
				v190 = v_u_27.Character
			end
			table.insert(v189, v190)
			v187 = v_u_46
		end
		v186.FilterDescendantsInstances = v187
		local v191 = v_u_10:Raycast(v185, Vector3.new(-0, -50, -0), v_u_29)
		if v191 then
			v_u_129.TargetPoint = v191.Position
		end
	else
		local v192 = Ray.new(v185, Vector3.new(0, -50, 0))
		local v193 = v_u_10
		local v194
		if v_u_46 then
			v194 = v_u_46
		else
			v_u_46 = {}
			local v195 = v_u_46
			assert(v195, "")
			local v196 = v_u_46
			local v197 = v_u_27
			if v197 then
				v197 = v_u_27.Character
			end
			table.insert(v196, v197)
			v194 = v_u_46
		end
		local v198, v199 = v193:FindPartOnRayWithIgnoreList(v192, v194)
		if v198 then
			v_u_129.TargetPoint = v199
		end
	end
	v_u_129:ComputePath()
	return v_u_129
end
local function v_u_203(p201) -- name: GetEquippedTool
	if p201 ~= nil then
		for _, v202 in pairs(p201:GetChildren()) do
			if not v202:IsA("Tool") then
				continue
			end
			return v202
		end
	end
end
local function v_u_212(p204) -- name: calculateLocalMoveVector
	-- upvalues: (copy) v_u_10
	local v205 = p204.X
	local v206 = p204.Z
	local v207 = Vector3.new(v205, 0, v206)
	if v207.Magnitude < 1e-6 then
		return Vector2.zero
	end
	local v208 = v207.Unit
	local v209 = v_u_10.CurrentCamera
	if not v209 then
		return Vector2.new(v208.X, -v208.Z)
	end
	local _, v210, _ = v209.CFrame:ToEulerAnglesYXZ()
	local v211 = CFrame.Angles(0, v210, 0):VectorToObjectSpace(v208)
	return Vector2.new(v211.X, -v211.Z)
end
local v_u_213 = {}
v_u_213.__index = v_u_213
function v_u_213.new(_) -- name: new
	-- upvalues: (copy) v_u_213, (copy) v_u_18, (copy) v_u_15
	local v214 = v_u_213
	local v215 = setmetatable({}, v214)
	v215.mouse2DownTime = tick()
	v215.mouse2DownPos = Vector2.new()
	v215.mouse2UpTime = tick()
	v215.humanoidDiedConn = nil
	v215.characterChildAddedConn = nil
	v215.onCharacterAddedConn = nil
	v215.characterChildRemovedConn = nil
	v215.renderSteppedConn = nil
	v215.menuOpenedConnection = nil
	v215.preferredInputChangedConnection = nil
	if not v_u_18 then
		v215.jumpEnabled = true
	end
	v215.clickPressedConn = nil
	v215.clickReleasedConn = nil
	v215.shouldCleanupPath = false
	if not v_u_15 then
		v215.lastPatherMoveVector = Vector2.new(0, 0)
	end
	v215.lastPatherJumped = false
	v215.playerData = nil
	v215.running = false
	return v215
end
local v_u_216 = nil
local v_u_217 = nil
local v_u_218 = nil
function v_u_213.CleanupPath(p219) -- name: CleanupPath
	-- upvalues: (ref) v_u_216, (ref) v_u_217, (ref) v_u_218
	if v_u_216 then
		v_u_216:Cancel()
		v_u_216 = nil
	end
	if v_u_217 then
		v_u_217:Disconnect()
		v_u_217 = nil
	end
	if v_u_218 then
		v_u_218:Disconnect()
		v_u_218 = nil
	end
	p219.shouldCleanupPath = true
end
function v_u_213.HandleMoveTo(p_u_220, p221, p_u_222, p_u_223, p_u_224, p_u_225) -- name: HandleMoveTo
	-- upvalues: (ref) v_u_216, (ref) v_u_217, (copy) v_u_203, (ref) v_u_218, (ref) v_u_23, (copy) v_u_28
	p_u_220.shouldCleanupPath = false
	if v_u_216 then
		p_u_220:CleanupPath()
	end
	v_u_216 = p221
	p221:Start(p_u_225)
	v_u_217 = p221.Finished.Event:Connect(function()
		-- upvalues: (copy) p_u_220, (copy) p_u_223, (ref) v_u_203, (copy) p_u_224
		p_u_220:CleanupPath()
		local v226 = p_u_223 and v_u_203(p_u_224)
		if v226 then
			v226:Activate()
		end
	end)
	v_u_218 = p221.PathFailed.Event:Connect(function()
		-- upvalues: (copy) p_u_220, (copy) p_u_225, (ref) v_u_23, (ref) v_u_216, (ref) v_u_28, (copy) p_u_222
		p_u_220:CleanupPath()
		if p_u_225 == nil or p_u_225 then
			local v227 = v_u_23
			if v227 then
				local v228 = v_u_216
				if v228 then
					v228 = v_u_216:IsActive()
				end
				v227 = not v228
			end
			if v227 then
				v_u_28.PlayFailureAnimation()
			end
			v_u_28.DisplayFailureWaypoint(p_u_222)
		end
	end)
end
function v_u_213.ShowPathFailedFeedback(_, p229) -- name: ShowPathFailedFeedback
	-- upvalues: (ref) v_u_216, (ref) v_u_23, (copy) v_u_28
	if v_u_216 and v_u_216:IsActive() then
		v_u_216:Cancel()
	end
	if v_u_23 then
		v_u_28.PlayFailureAnimation()
	end
	v_u_28.DisplayFailureWaypoint(p229)
end
function v_u_213.OnTap(p230, p231, p232) -- name: OnTap
	-- upvalues: (copy) v_u_10, (copy) v_u_27, (copy) v_u_45, (copy) v_u_14, (ref) v_u_46, (copy) v_u_29, (copy) v_u_200, (copy) v_u_30, (copy) v_u_203
	local v233 = v_u_10.CurrentCamera
	local v234 = v_u_27.Character
	local v235 = v_u_27
	local v236
	if v235 then
		v236 = v235.Character
	else
		v236 = v235
	end
	local v237
	if v236 then
		v237 = v_u_45[v235]
		if not v237 or v237.Parent ~= v236 then
			v_u_45[v235] = nil
			v237 = v236:FindFirstChildOfClass("Humanoid")
			if v237 then
				v_u_45[v235] = v237
			end
		end
	else
		v237 = nil
	end
	local v238
	if v237 == nil then
		v238 = false
	else
		v238 = v237.Health > 0
	end
	if v238 then
		if #p231 == 1 or p232 then
			if v233 then
				local v239 = v233:ScreenPointToRay(p231[1].X, p231[1].Y)
				if v_u_14 then
					local v240 = nil
					local v241
					if v_u_46 then
						v241 = v_u_46
					else
						v_u_46 = {}
						local v242 = v_u_46
						assert(v242, "")
						local v243 = v_u_46
						local v244 = v_u_27
						if v244 then
							v244 = v_u_27.Character
						end
						table.insert(v243, v244)
						v241 = v_u_46
					end
					if not v241 then
						v241 = {}
					end
					local v245 = true
					v_u_29.FilterDescendantsInstances = v241
					local v246 = v_u_10:Raycast(v239.Origin, v239.Direction * 1000, v_u_29)
					if v246 then
						local v247 = v246.Instance
						if not v247.CanCollide then
							while true do
								local v248 = v247:FindFirstChildOfClass("Humanoid")
								local v249 = v247.Parent
								if v248 or not v249 then
									break
								end
								v247 = v249
							end
							if v248 or not v249 then
								v240 = v247
							else
								table.insert(v241, v249)
								v245 = false
								v240 = nil
							end
						end
					end
					if not v245 then
						continue
					end
					if v246 and v234 then
						local v250 = v246.Position
						if p232 then
							v240 = nil
						else
							p232 = v250
						end
						p230:CleanupPath()
						local v251 = v_u_200(p232, v246.Normal)
						if v251:IsValidPath() then
							p230:HandleMoveTo(v251, p232, v240, v234)
						else
							v251:Cleanup()
							p230:ShowPathFailedFeedback(p232)
						end
					else
						return
					end
				end
				local v252 = Ray.new(v239.Origin, v239.Direction * 1000)
				local v253 = v_u_30.Raycast
				local v254 = true
				local v255
				if v_u_46 then
					v255 = v_u_46
				else
					v_u_46 = {}
					local v256 = v_u_46
					assert(v256, "")
					local v257 = v_u_46
					local v258 = v_u_27
					if v258 then
						v258 = v_u_27.Character
					end
					table.insert(v257, v258)
					v255 = v_u_46
				end
				local v259, v260, v261 = v253(v252, v254, v255)
				local v262, _ = v_u_30.FindCharacterAncestor(v259)
				if p232 then
					v262 = nil
				else
					p232 = v260
				end
				if p232 and v234 then
					p230:CleanupPath()
					local v263 = v_u_200(p232, v261)
					if v263:IsValidPath() then
						p230:HandleMoveTo(v263, p232, v262, v234)
					else
						v263:Cleanup()
						p230:ShowPathFailedFeedback(p232)
					end
				end
			end
		else
			local v264 = #p231 >= 2 and (v233 and v_u_203(v234))
			if v264 then
				v264:Activate()
			end
		end
	end
end
function v_u_213.DisconnectEvents(p265) -- name: DisconnectEvents
	local v266 = p265.humanoidDiedConn
	if v266 then
		v266:Disconnect()
	end
	local v267 = p265.characterChildAddedConn
	if v267 then
		v267:Disconnect()
	end
	local v268 = p265.onCharacterAddedConn
	if v268 then
		v268:Disconnect()
	end
	local v269 = p265.renderSteppedConn
	if v269 then
		v269:Disconnect()
	end
	local v270 = p265.characterChildRemovedConn
	if v270 then
		v270:Disconnect()
	end
	local v271 = p265.menuOpenedConnection
	if v271 then
		v271:Disconnect()
	end
	local v272 = p265.preferredInputChangedConnection
	if v272 then
		v272:Disconnect()
	end
	local v273 = p265.clickPressedConn
	if v273 then
		v273:Disconnect()
	end
	local v274 = p265.clickReleasedConn
	if v274 then
		v274:Disconnect()
	end
end
function v_u_213.OnPreferredInputChanged(_) -- name: OnPreferredInputChanged
	-- upvalues: (copy) v_u_27, (copy) v_u_7
	local v275 = v_u_27.Character
	if v275 then
		local v276 = v_u_7.PreferredInput == Enum.PreferredInput.Touch
		for _, v277 in pairs(v275:GetChildren()) do
			if not v277:IsA("Tool") then
				continue
			end
			v277.ManualActivationOnly = v276
		end
	end
end
function v_u_213.OnCharacterAdded(p_u_278, p279) -- name: OnCharacterAdded
	-- upvalues: (copy) v_u_20, (copy) v_u_12, (copy) v_u_21, (copy) v_u_17, (ref) v_u_216, (copy) v_u_7
	p_u_278:DisconnectEvents()
	p_u_278.clickPressedConn = v_u_20.Pressed:Connect(function()
		-- upvalues: (ref) v_u_12, (ref) v_u_21, (ref) v_u_17, (copy) p_u_278
		local v280, _ = v_u_12:GetGuiInset()
		local v281 = v_u_21:GetState()
		if v281.X ~= -1 or v281.Y ~= -1 then
			local v282
			if v_u_17 then
				local v283 = v_u_12:GetInsetArea(Enum.ScreenInsets.None).Min
				v282 = Vector2.new(v281.X + v283.X, v281.Y + v283.Y)
			else
				v282 = Vector2.new(v281.X - v280.X, v281.Y - v280.Y)
			end
			p_u_278.mouse2DownPos = v282
			p_u_278.mouse2DownTime = tick()
		end
	end)
	p_u_278.clickReleasedConn = v_u_20.Released:Connect(function()
		-- upvalues: (copy) p_u_278, (ref) v_u_216
		p_u_278.mouse2UpTime = tick()
		local v284 = p_u_278.mouse2DownPos
		if p_u_278.playerData and p_u_278.playerData.actions.MoveAction then
			local v285 = v_u_216 or p_u_278.playerData.actions.MoveAction:GetState().Magnitude <= 0
			if p_u_278.mouse2UpTime - p_u_278.mouse2DownTime < 0.25 and v285 then
				p_u_278:OnTap({ v284 })
			end
		end
	end)
	p_u_278.menuOpenedConnection = v_u_12.MenuOpened:Connect(function()
		-- upvalues: (copy) p_u_278
		p_u_278:CleanupPath()
	end)
	local function v_u_288(p286) -- name: OnCharacterChildAdded
		-- upvalues: (ref) v_u_7, (copy) p_u_278
		if v_u_7.PreferredInput == Enum.PreferredInput.Touch and p286:IsA("Tool") then
			p286.ManualActivationOnly = true
		end
		if p286:IsA("Humanoid") then
			local v287 = p_u_278.humanoidDiedConn
			if v287 then
				v287:Disconnect()
			end
			p_u_278.humanoidDiedConn = p286.Died:Connect(function() end)
		end
	end
	p_u_278.characterChildAddedConn = p279.ChildAdded:Connect(function(p289)
		-- upvalues: (copy) v_u_288
		v_u_288(p289)
	end)
	p_u_278.characterChildRemovedConn = p279.ChildRemoved:Connect(function(p290)
		-- upvalues: (ref) v_u_7
		if v_u_7.PreferredInput == Enum.PreferredInput.Touch and p290:IsA("Tool") then
			p290.ManualActivationOnly = false
		end
	end)
	for _, v291 in pairs(p279:GetChildren()) do
		v_u_288(v291)
	end
	p_u_278.preferredInputChangedConnection = v_u_7:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		-- upvalues: (copy) p_u_278
		p_u_278:OnPreferredInputChanged()
	end)
end
function v_u_213.Start(p292) -- name: Start
	p292:Enable(true)
end
function v_u_213.Stop(p293) -- name: Stop
	p293:Enable(false)
end
function v_u_213.Enable(p_u_294, p295, p296, p297) -- name: Enable
	-- upvalues: (copy) v_u_27, (copy) v_u_18, (copy) v_u_7, (copy) v_u_20, (copy) v_u_21
	if p295 then
		if not p_u_294.running then
			if v_u_27.Character then
				p_u_294:OnCharacterAdded(v_u_27.Character)
			end
			p_u_294.onCharacterAddedConn = v_u_27.CharacterAdded:Connect(function(p298)
				-- upvalues: (copy) p_u_294
				p_u_294:OnCharacterAdded(p298)
			end)
			p_u_294.running = true
		end
		if not v_u_18 then
			p_u_294.touchJumpController = p297
			if p_u_294.touchJumpController then
				p_u_294.touchJumpController:Enable(p_u_294.jumpEnabled)
			end
		end
	else
		if p_u_294.running then
			p_u_294:DisconnectEvents()
			p_u_294:CleanupPath()
			if v_u_7.PreferredInput == Enum.PreferredInput.Touch then
				local v299 = v_u_27.Character
				if v299 then
					for _, v300 in pairs(v299:GetChildren()) do
						if not v300:IsA("Tool") then
							continue
						end
						v300.ManualActivationOnly = false
					end
				end
			end
			p_u_294.running = false
		end
		if not v_u_18 then
			if p_u_294.touchJumpController and not p_u_294.jumpEnabled then
				p_u_294.touchJumpController:Enable(true)
			end
			p_u_294.touchJumpController = nil
		end
	end
	v_u_20.Enabled = p295
	v_u_21.Enabled = p295
	p_u_294.wasdEnabled = p295 and p296 and p296 or false
	p_u_294.enabled = p295
end
function v_u_213.Update(p301, p302, p303) -- name: Update
	-- upvalues: (ref) v_u_216, (copy) v_u_15, (copy) v_u_212, (copy) v_u_28
	local v304 = p302.actions.MoveAction
	assert(v304)
	local v305 = p302.actions.JumpAction
	assert(v305)
	if not p301.playerData then
		p301.playerData = p302
	end
	local v306 = v_u_216
	if v306 then
		v306:OnRenderStepped(p303)
		if v_u_216 and v_u_216 == v306 then
			if v_u_15 then
				local v307 = v_u_212(v306.NextActionMoveDirection)
				local v308 = p302.actions.MoveAction:FindFirstChild("ClickToMoveScriptableBinding")
				if v308 then
					v308:Fire(v307)
				end
				p302.moveVector = v307
				if v306.NextActionJump then
					local v309 = p302.actions.JumpAction:GetState() ~= true and p302.actions.JumpAction:FindFirstChild("ClickToMoveScriptableBinding")
					if v309 then
						v309:Fire(true)
					end
					p301.lastPatherJumped = true
					p302.isJumping = true
				elseif p301.lastPatherJumped then
					local v310 = p302.actions.JumpAction:GetState() == true and p302.actions.JumpAction:FindFirstChild("ClickToMoveScriptableBinding")
					if v310 then
						v310:Fire(false)
					end
					p301.lastPatherJumped = false
					p302.isJumping = false
				end
			else
				local v311 = p302.actions.MoveAction:GetState()
				local v_u_312 = v_u_212(v306.NextActionMoveDirection)
				if (v311 - p301.lastPatherMoveVector).Magnitude > 1e-6 then
					p301:CleanupPath()
					v_u_28.CancelFailureAnimation()
				else
					p301.lastPatherMoveVector = v_u_312
					local v_u_313 = p302.actions.MoveAction:FindFirstChild("ClickToMoveScriptableBinding")
					if v_u_313 then
						local v314, _ = pcall(function()
							-- upvalues: (copy) v_u_313, (copy) v_u_312
							v_u_313.Type = Enum.InputBindingType.Scriptable
							v_u_313:Fire(v_u_312)
						end)
						if not v314 then
							p302.actions.MoveAction:Fire(v_u_312)
						end
					else
						p302.actions.MoveAction:Fire(v_u_312)
					end
					if v306.NextActionJump then
						if p302.actions.JumpAction:GetState() ~= true then
							local v_u_315 = p302.actions.JumpAction:FindFirstChild("ClickToMoveScriptableBinding")
							if v_u_315 then
								local v316, _ = pcall(function()
									-- upvalues: (copy) v_u_315
									v_u_315.Type = Enum.InputBindingType.Scriptable
									v_u_315:Fire(true)
								end)
								if not v316 then
									p302.actions.JumpAction:Fire(true)
								end
							else
								p302.actions.JumpAction:Fire(true)
							end
							p301.lastPatherJumped = true
						end
					elseif p301.lastPatherJumped then
						if p302.actions.JumpAction:GetState() == true then
							local v_u_317 = p302.actions.JumpAction:FindFirstChild("ClickToMoveScriptableBinding")
							if v_u_317 then
								local v318, _ = pcall(function()
									-- upvalues: (copy) v_u_317
									v_u_317.Type = Enum.InputBindingType.Scriptable
									v_u_317:Fire(false)
								end)
								if not v318 then
									p302.actions.JumpAction:Fire(false)
								end
							else
								p302.actions.JumpAction:Fire(false)
							end
						end
						p301.lastPatherJumped = false
					end
				end
			end
		else
			if not v_u_15 then
				p301.lastPatherMoveVector = Vector2.zero
			end
			if p301.lastPatherJumped then
				local v319 = p302.actions.JumpAction:GetState() == true and p302.actions.JumpAction:FindFirstChild("ClickToMoveScriptableBinding")
				if v319 then
					v319:Fire(false)
				end
				p301.lastPatherJumped = false
			end
		end
	end
	if p301.shouldCleanupPath then
		p301.shouldCleanupPath = false
		if v_u_15 then
			local v320 = p302.actions.MoveAction:FindFirstChild("ClickToMoveScriptableBinding")
			if v320 then
				v320:Fire(Vector2.zero)
			end
			p302.moveVector = Vector2.zero
			p301.lastPatherJumped = false
			local v321 = p302.actions.JumpAction:FindFirstChild("ClickToMoveScriptableBinding")
			if v321 then
				v321:Fire(false)
			end
			p302.isJumping = false
			return
		end
		p301.lastPatherMoveVector = Vector2.zero
		local v322 = p302.actions.MoveAction:FindFirstChild("ClickToMoveScriptableBinding")
		if v322 then
			v322:Fire(Vector2.zero)
		end
		p301.lastPatherJumped = false
		local v323 = p302.actions.JumpAction:FindFirstChild("ClickToMoveScriptableBinding")
		if v323 then
			v323:Fire(false)
		end
	end
end
function v_u_213.SetShowPath(_, p324) -- name: SetShowPath
	-- upvalues: (ref) v_u_22
	v_u_22 = p324
end
function v_u_213.GetShowPath(_) -- name: GetShowPath
	-- upvalues: (ref) v_u_22
	return v_u_22
end
function v_u_213.SetWaypointTexture(_, p325) -- name: SetWaypointTexture
	-- upvalues: (copy) v_u_28
	v_u_28.SetWaypointTexture(p325)
end
function v_u_213.GetWaypointTexture(_) -- name: GetWaypointTexture
	-- upvalues: (copy) v_u_28
	return v_u_28.GetWaypointTexture()
end
function v_u_213.SetWaypointRadius(_, p326) -- name: SetWaypointRadius
	-- upvalues: (copy) v_u_28
	v_u_28.SetWaypointRadius(p326)
end
function v_u_213.GetWaypointRadius(_) -- name: GetWaypointRadius
	-- upvalues: (copy) v_u_28
	return v_u_28.GetWaypointRadius()
end
function v_u_213.SetEndWaypointTexture(_, p327) -- name: SetEndWaypointTexture
	-- upvalues: (copy) v_u_28
	v_u_28.SetEndWaypointTexture(p327)
end
function v_u_213.GetEndWaypointTexture(_) -- name: GetEndWaypointTexture
	-- upvalues: (copy) v_u_28
	return v_u_28.GetEndWaypointTexture()
end
function v_u_213.SetWaypointsAlwaysOnTop(_, p328) -- name: SetWaypointsAlwaysOnTop
	-- upvalues: (copy) v_u_28
	v_u_28.SetWaypointsAlwaysOnTop(p328)
end
function v_u_213.GetWaypointsAlwaysOnTop(_) -- name: GetWaypointsAlwaysOnTop
	-- upvalues: (copy) v_u_28
	return v_u_28.GetWaypointsAlwaysOnTop()
end
function v_u_213.SetFailureAnimationEnabled(_, p329) -- name: SetFailureAnimationEnabled
	-- upvalues: (ref) v_u_23
	v_u_23 = p329
end
function v_u_213.GetFailureAnimationEnabled(_) -- name: GetFailureAnimationEnabled
	-- upvalues: (ref) v_u_23
	return v_u_23
end
function v_u_213.SetIgnoredPartsTag(_, p330) -- name: SetIgnoredPartsTag
	-- upvalues: (copy) v_u_60
	v_u_60(p330)
end
function v_u_213.GetIgnoredPartsTag(_) -- name: GetIgnoredPartsTag
	-- upvalues: (ref) v_u_47
	return v_u_47
end
function v_u_213.SetUseDirectPath(_, p331) -- name: SetUseDirectPath
	-- upvalues: (ref) v_u_24
	v_u_24 = p331
end
function v_u_213.GetUseDirectPath(_) -- name: GetUseDirectPath
	-- upvalues: (ref) v_u_24
	return v_u_24
end
function v_u_213.SetAgentSizeIncreaseFactor(_, p332) -- name: SetAgentSizeIncreaseFactor
	-- upvalues: (ref) v_u_25
	v_u_25 = p332 / 100 + 1
end
function v_u_213.GetAgentSizeIncreaseFactor(_) -- name: GetAgentSizeIncreaseFactor
	-- upvalues: (ref) v_u_25
	return (v_u_25 - 1) * 100
end
function v_u_213.SetUnreachableWaypointTimeout(_, p333) -- name: SetUnreachableWaypointTimeout
	-- upvalues: (ref) v_u_26
	v_u_26 = p333
end
function v_u_213.GetUnreachableWaypointTimeout(_) -- name: GetUnreachableWaypointTimeout
	-- upvalues: (ref) v_u_26
	return v_u_26
end
if not v_u_18 then
	function v_u_213.SetUserJumpEnabled(p334, p335) -- name: SetUserJumpEnabled
		p334.jumpEnabled = p335
		if p334.touchJumpController then
			p334.touchJumpController:Enable(p335)
		end
	end
	function v_u_213.GetUserJumpEnabled(p336) -- name: GetUserJumpEnabled
		return p336.jumpEnabled
	end
end
function v_u_213.MoveTo(p337, p338, p339, p340) -- name: MoveTo
	-- upvalues: (copy) v_u_27, (copy) v_u_200
	local v341 = v_u_27.Character
	if v341 == nil then
		return false
	end
	local v342 = v_u_200(p338, Vector3.new(0, 1, 0), p340)
	if not (v342 and v342:IsValidPath()) then
		return false
	end
	p337:HandleMoveTo(v342, p338, nil, v341, p339)
	return true
end
return v_u_213