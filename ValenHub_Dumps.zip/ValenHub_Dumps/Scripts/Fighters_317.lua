local v_u_1 = game:GetService("Players")
local v2 = game:GetService("CollectionService")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = {
	["Added"] = require(v3:WaitForChild("Shared"):WaitForChild("Signal")).new(),
	["TAGS"] = { "Combatant", "Bot" }
}
local v_u_5 = {}
local v_u_6 = {}
local function v_u_13(p_u_7) -- name: add
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_5, (copy) v_u_4
	if p_u_7:IsA("Model") and not v_u_6[p_u_7] then
		v_u_6[p_u_7] = p_u_7:GetAttributeChangedSignal("CombatantId"):Connect(function()
			-- upvalues: (copy) p_u_7, (ref) v_u_1, (ref) v_u_5, (ref) v_u_4
			local v8 = p_u_7
			local v9 = v8:GetAttribute("CombatantId")
			if type(v9) ~= "string" or v9 == "" then
				local v10 = v_u_1:GetPlayerFromCharacter(v8)
				if v10 then
					v9 = "p" .. v10.UserId
				else
					v9 = nil
				end
			end
			if v9 then
				v_u_5[v9] = v8
				v_u_4.Added:Fire(v9, v8)
			end
		end)
		local v11 = p_u_7:GetAttribute("CombatantId")
		if type(v11) ~= "string" or v11 == "" then
			local v12 = v_u_1:GetPlayerFromCharacter(p_u_7)
			if v12 then
				v11 = "p" .. v12.UserId
			else
				v11 = nil
			end
		end
		if v11 then
			v_u_5[v11] = p_u_7
			v_u_4.Added:Fire(v11, p_u_7)
		end
	end
end
local function v_u_18(p14) -- name: remove
	-- upvalues: (copy) v_u_6, (copy) v_u_5
	local v15 = v_u_6[p14]
	if v15 then
		v15:Disconnect()
		v_u_6[p14] = nil
	end
	for v16, v17 in v_u_5 do
		if v17 ~= p14 then
			continue
		end
		v_u_5[v16] = nil
	end
end
local v_u_19 = {}
for _, v20 in v_u_4.TAGS do
	for _, v21 in v2:GetTagged(v20) do
		v_u_13(v21)
	end
	v2:GetInstanceAddedSignal(v20):Connect(v_u_13)
	v2:GetInstanceRemovedSignal(v20):Connect(v_u_18)
end
local function v23(p22) -- name: watchPlayer
	-- upvalues: (copy) v_u_19, (copy) v_u_13, (copy) v_u_18
	v_u_19[p22.UserId] = true
	if p22.Character then
		v_u_13(p22.Character)
	end
	p22.CharacterAdded:Connect(v_u_13)
	p22.CharacterRemoving:Connect(v_u_18)
end
for _, v24 in v_u_1:GetPlayers() do
	v_u_19[v24.UserId] = true
	if v24.Character then
		v_u_13(v24.Character)
	end
	v24.CharacterAdded:Connect(v_u_13)
	v24.CharacterRemoving:Connect(v_u_18)
end
v_u_1.PlayerAdded:Connect(v23)
function v_u_4.Find(p25) -- name: Find
	-- upvalues: (copy) v_u_5, (copy) v_u_1
	if type(p25) ~= "string" then
		return nil
	end
	local v26 = v_u_5[p25]
	if v26 and v26.Parent then
		return v26
	end
	if string.sub(p25, 1, 1) == "p" then
		local v27 = string.sub(p25, 2)
		local v28 = tonumber(v27)
		if v28 then
			v28 = v_u_1:GetPlayerByUserId(v28)
		end
		if v28 and v28.Character then
			return v28.Character
		end
	end
	return nil
end
function v_u_4.IsRealUserId(p29) -- name: IsRealUserId
	-- upvalues: (copy) v_u_19
	local v30
	if type(p29) == "number" and p29 > 0 then
		v30 = v_u_19[p29] == true
	else
		v30 = false
	end
	return v30
end
v_u_4.TrustAllUserIds = false
return v_u_4