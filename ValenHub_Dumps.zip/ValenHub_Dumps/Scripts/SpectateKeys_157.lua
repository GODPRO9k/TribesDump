local v_u_1 = game:GetService("ContextActionService")
local v_u_2 = game:GetService("Players")
local v_u_3 = require(script.Parent.Parent:WaitForChild("Keybinds"))
local v4 = {}
local v_u_5 = Enum.ContextActionPriority.High.Value + 100
local v_u_6 = false
local v_u_7 = nil
local function v_u_12(p8) -- name: overButton
	-- upvalues: (copy) v_u_2
	local v9 = v_u_2.LocalPlayer
	if v9 then
		v9 = v_u_2.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	end
	if not v9 then
		return false
	end
	local v10 = p8.Position
	for _, v11 in v9:GetGuiObjectsAtPosition(v10.X, v10.Y) do
		if not (v11:IsA("GuiButton") and (v11.Active and v11.Visible)) then
			continue
		end
		return true
	end
	return false
end
local function v_u_16() -- name: inputs
	-- upvalues: (copy) v_u_3
	local v13 = { Enum.UserInputType.MouseButton1, Enum.UserInputType.MouseButton2 }
	for _, v14 in { "SpectateNext", "SpectatePrev" } do
		for _, v15 in v_u_3.PadInputs(v14) do
			if table.find(v13, v15) then
				continue
			end
			table.insert(v13, v15)
		end
	end
	return v13
end
v4.Inputs = v_u_16
function v4.SetActive(p17, p18) -- name: SetActive
	-- upvalues: (ref) v_u_7, (ref) v_u_6, (copy) v_u_1, (copy) v_u_12, (copy) v_u_3, (copy) v_u_5, (copy) v_u_16
	v_u_7 = p18
	if p17 == v_u_6 then
		return
	else
		v_u_6 = p17
		if p17 then
			local v19 = v_u_1
			local function v25(_, p20, p21)
				-- upvalues: (ref) v_u_12, (ref) v_u_3, (ref) v_u_7
				if p20 ~= Enum.UserInputState.Begin then
					return Enum.ContextActionResult.Pass
				end
				local v22 = p21.UserInputType == Enum.UserInputType.MouseButton1 and true or p21.UserInputType == Enum.UserInputType.MouseButton2
				if v22 and v_u_12(p21) then
					return Enum.ContextActionResult.Pass
				end
				local v23
				if v22 then
					v23 = p21.UserInputType == Enum.UserInputType.MouseButton2
				else
					if v_u_3.PadBlocked() then
						return Enum.ContextActionResult.Pass
					end
					local v24 = v_u_3.IsPad(p21, "SpectateNext")
					v23 = v_u_3.IsPad(p21, "SpectatePrev")
					if not (v24 or v23) then
						return Enum.ContextActionResult.Pass
					end
					if v23 then
						v23 = not v24
					end
				end
				if v_u_7 then
					v_u_7(v23 and -1 or 1)
				end
				return Enum.ContextActionResult.Sink
			end
			local v26 = v_u_5
			local v27 = v_u_16()
			v19:BindActionAtPriority("TribesSpectateCycle", v25, false, v26, table.unpack(v27))
		else
			v_u_1:UnbindAction("TribesSpectateCycle")
		end
	end
end
v_u_3.PadChanged:Connect(function(p28)
	-- upvalues: (ref) v_u_6, (copy) v_u_1, (copy) v_u_12, (copy) v_u_3, (ref) v_u_7, (copy) v_u_5, (copy) v_u_16
	if v_u_6 and (table.find(p28, "SpectateNext") or table.find(p28, "SpectatePrev")) then
		v_u_1:UnbindAction("TribesSpectateCycle")
		local v29 = v_u_1
		local function v35(_, p30, p31)
			-- upvalues: (ref) v_u_12, (ref) v_u_3, (ref) v_u_7
			if p30 ~= Enum.UserInputState.Begin then
				return Enum.ContextActionResult.Pass
			end
			local v32 = p31.UserInputType == Enum.UserInputType.MouseButton1 and true or p31.UserInputType == Enum.UserInputType.MouseButton2
			if v32 and v_u_12(p31) then
				return Enum.ContextActionResult.Pass
			end
			local v33
			if v32 then
				v33 = p31.UserInputType == Enum.UserInputType.MouseButton2
			else
				if v_u_3.PadBlocked() then
					return Enum.ContextActionResult.Pass
				end
				local v34 = v_u_3.IsPad(p31, "SpectateNext")
				v33 = v_u_3.IsPad(p31, "SpectatePrev")
				if not (v34 or v33) then
					return Enum.ContextActionResult.Pass
				end
				if v33 then
					v33 = not v34
				end
			end
			if v_u_7 then
				v_u_7(v33 and -1 or 1)
			end
			return Enum.ContextActionResult.Sink
		end
		local v36 = v_u_5
		local v37 = v_u_16()
		v29:BindActionAtPriority("TribesSpectateCycle", v35, false, v36, table.unpack(v37))
	end
end)
function v4.IsActive() -- name: IsActive
	-- upvalues: (ref) v_u_6
	return v_u_6
end
return v4