local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = v_u_2:IsStudio()
local v_u_4 = require(script.Parent.Parent:WaitForChild("Simulation"))
local v5 = require(script.Parent:WaitForChild("FrameClock"))
local v_u_6 = require(script.Parent:WaitForChild("BodyProxy"))
local v7 = {}
local v_u_8 = v_u_4.CORRECTION_MAX or 20
local v_u_9 = Vector3.new(0, 0, 0)
local v_u_10 = Vector3.new(0, 0, 0)
local v_u_11 = Vector3.new(0, 0, 0)
local v_u_12 = 0
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = 0
local v_u_17 = 0
local v_u_18 = {}
local v_u_19 = {}
local v_u_20 = v5.new()
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = nil
local v_u_25 = 0
local v_u_26 = false
local v_u_27 = 0
local v_u_28 = 0
local v_u_29 = 1
local v_u_30 = 0
local v_u_31 = false
local v_u_32 = true
local v_u_33 = nil
local v_u_34 = nil
local v_u_35 = nil
local v_u_36 = nil
local function v_u_69(p37, p38, p39, p40, p41, p42, p43) -- name: traceFrame
	-- upvalues: (ref) v_u_36, (ref) v_u_9, (ref) v_u_11
	local v44 = v_u_36
	if v44 and #v44 < 20000 then
		local v45 = {}
		local v46 = os.clock() * 10000 + 0.5
		local v47 = math.floor(v46) / 10000
		local v48 = p37 * 10000 + 0.5
		local v49 = math.floor(v48) / 10000
		local v50 = p38 * 10000 + 0.5
		local v51 = math.floor(v50) / 10000
		local v52 = p41.X * 10000 + 0.5
		local v53 = math.floor(v52) / 10000
		local v54 = p41.Y * 10000 + 0.5
		local v55 = math.floor(v54) / 10000
		local v56 = p41.Z * 10000 + 0.5
		local v57 = math.floor(v56) / 10000
		local v58 = (v_u_9.X + v_u_11.X) * 10000 + 0.5
		local v59 = math.floor(v58) / 10000
		local v60 = (v_u_9.Y + v_u_11.Y) * 10000 + 0.5
		local v61 = math.floor(v60) / 10000
		local v62 = (v_u_9.Z + v_u_11.Z) * 10000 + 0.5
		local v63 = math.floor(v62) / 10000
		local v64 = p42.X * 10000 + 0.5
		local v65 = math.floor(v64) / 10000
		local v66 = p42.Y * 10000 + 0.5
		local v67 = math.floor(v66) / 10000
		local v68 = p42.Z * 10000 + 0.5
		__set_list(v45, 1, {v47, v49, v51, p39, p40 and 1 or 0, v53, v55, v57, v59, v61, v63, v65, v67, math.floor(v68) / 10000, p43 and 1 or 0})
		table.insert(v44, v45)
	end
end
local function v_u_74(_) -- name: onStep
	-- upvalues: (copy) v_u_2, (ref) v_u_26, (ref) v_u_25, (copy) v_u_20, (ref) v_u_21, (ref) v_u_23, (ref) v_u_24, (ref) v_u_22
	if v_u_2:IsResimulating() then
		v_u_26 = true
	else
		v_u_25 = v_u_25 + 1
		v_u_20:Step()
	end
	local v70 = v_u_21
	if v70 then
		local v71 = v70.CFrame
		local v72 = v71.Rotation
		local v73 = v71.Position
		v_u_23 = v72
		v_u_24 = v73
		v_u_22 = v70
	else
		v_u_23 = nil
		v_u_24 = nil
		v_u_22 = nil
	end
end
local function v_u_82(p75, p76, p77) -- name: noteCorrection
	-- upvalues: (ref) v_u_16, (ref) v_u_17, (copy) v_u_19, (copy) v_u_3, (copy) v_u_18
	v_u_16 = v_u_16 + 1
	if v_u_17 < p75 then
		v_u_17 = p75
	end
	local v78 = v_u_19
	local v79 = {
		p76,
		p77.X,
		p77.Y,
		p77.Z
	}
	table.insert(v78, v79)
	if #v_u_19 > 64 then
		table.remove(v_u_19, 1)
	end
	if v_u_3 then
		local v80 = v_u_18
		local v81 = string.format
		table.insert(v80, v81("%.2f:%.2f", p76, p75))
		if #v_u_18 > 40 then
			table.remove(v_u_18, 1)
		end
	end
end
local function v_u_119(p83) -- name: step
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (ref) v_u_21, (copy) v_u_4, (ref) v_u_25, (ref) v_u_26, (ref) v_u_31, (copy) v_u_20, (ref) v_u_13, (ref) v_u_15, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_33, (ref) v_u_34, (ref) v_u_35, (copy) v_u_6, (ref) v_u_23, (ref) v_u_24, (ref) v_u_14, (ref) v_u_30, (copy) v_u_8, (ref) v_u_12, (copy) v_u_82, (ref) v_u_32, (ref) v_u_22, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (ref) v_u_36, (copy) v_u_69
	local v84 = v_u_1.LocalPlayer
	if v84 then
		v84 = v84.Character
	end
	local v85
	if v84 then
		v85 = v84:FindFirstChild("HumanoidRootPart")
	else
		v85 = v84
	end
	if not (v85 and (v85:IsA("BasePart") and v84:IsDescendantOf(workspace))) then
		v85 = nil
	end
	local v86 = v_u_3
	if v86 then
		v86 = workspace:GetAttribute("CamSmoothingOff") == true
	end
	v_u_21 = v85
	local v87 = v_u_4.TakeCorrection()
	local v88 = v_u_25
	local v89 = v_u_26
	v_u_25 = 0
	v_u_26 = false
	local v90
	if v_u_31 then
		local v91 = v_u_20
		local v92 = os.clock()
		local v93 = v_u_3
		if v93 then
			v93 = workspace:GetAttribute("SmoothingInterp") == true
		end
		v90 = v91:Alpha(v92, v93)
	else
		v90 = 1
	end
	if v85 and not v86 then
		local v94 = v85.CFrame
		if v94.Position == v94.Position and v94.LookVector == v94.LookVector then
			local v95 = v85:GetAttribute("STp")
			local v96
			if v85 == v_u_13 then
				v96 = v95 == v_u_14
			else
				v96 = false
			end
			local v97 = false
			if v96 and (v89 and (v88 == 0 and v_u_15)) then
				local v98 = v94.Position - v_u_15
				if v98.Magnitude > 0.02 then
					v87 = v87 + v98
					v_u_30 = v_u_30 + 1
					v97 = true
				end
				v_u_4.RebaseCorrection()
			end
			local v99 = os.clock()
			if v96 then
				if v87 ~= Vector3.new(0, 0, 0) then
					local v100 = v87.Magnitude
					if v_u_8 < v100 then
						v_u_9 = Vector3.new(0, 0, 0)
						v_u_10 = Vector3.new(0, 0, 0)
						v_u_11 = Vector3.new(0, 0, 0)
					else
						if v_u_11 == Vector3.new(0, 0, 0) then
							v_u_12 = v99
						end
						v_u_11 = v_u_11 - v87
						v_u_82(v100, v99, v87)
					end
				end
			else
				v_u_9 = Vector3.new(0, 0, 0)
				v_u_10 = Vector3.new(0, 0, 0)
				v_u_11 = Vector3.new(0, 0, 0)
				v_u_23 = nil
				v_u_24 = nil
				v_u_20:Reset()
			end
			if v_u_11 ~= Vector3.new(0, 0, 0) and v99 - v_u_12 >= 0.05 then
				v_u_9 = v_u_9 + v_u_11
				v_u_11 = Vector3.new(0, 0, 0)
				local v101 = v_u_9.Magnitude
				if v101 > 0.0001 then
					local v102 = v_u_10:Dot(v_u_9) / v101
					if v102 > 0 then
						v_u_10 = v_u_10 - v_u_9 * (v102 / v101)
					end
				end
			end
			local v103 = v94.Position
			v_u_13 = v85
			v_u_14 = v95
			v_u_15 = v103
			local v104 = math.min(p83, 0.1)
			if v_u_11 == Vector3.new(0, 0, 0) or v_u_11:Dot(v_u_9) >= 0 then
				local v105 = v104 * -16
				local v106 = math.exp(v105)
				local v107 = v_u_10 + v_u_9 * 16
				local v108 = (v_u_9 + v107 * v104) * v106
				local v109 = (v_u_10 - v107 * 16 * v104) * v106
				v_u_9 = v108
				v_u_10 = v109
				if v_u_9.Magnitude < 0.003 and v_u_10.Magnitude < 0.05 then
					v_u_9 = Vector3.new(0, 0, 0)
					v_u_10 = Vector3.new(0, 0, 0)
				end
			end
			local v110 = v_u_24
			local v111 = v_u_23
			local v112
			if v_u_32 and (v90 < 1 and (v96 and (v110 and (v111 and v_u_22 == v85)))) then
				local v113 = v94.Position - v110
				if v113.Magnitude < 6 then
					v112 = CFrame.new(v94.Position - v113 * (1 - v90)) * v111:Lerp(v94.Rotation, v90)
					v_u_27 = v_u_27 + 1
					v_u_28 = v_u_28 + v90
					local v114 = v_u_29
					v_u_29 = math.min(v114, v90)
				else
					v112 = v94
				end
			else
				v112 = v94
			end
			local v115 = v_u_9 + v_u_11
			if v_u_3 then
				local v116 = workspace:GetAttribute("SmoothingForceOffset")
				if typeof(v116) == "Vector3" then
					v115 = v115 + v116
				end
			end
			if v_u_36 then
				v_u_69(v104, v90, v88, v89, v87, v94.Position - v112.Position, v97)
			end
			local v117 = v112.Position + v115
			if v117 ~= v117 or v112.LookVector ~= v112.LookVector then
				v_u_9 = Vector3.new(0, 0, 0)
				v_u_10 = Vector3.new(0, 0, 0)
				v_u_11 = Vector3.new(0, 0, 0)
				v_u_23 = nil
				v_u_24 = nil
				v_u_20:Reset()
				v112 = v94
				v115 = Vector3.new(0, 0, 0)
			end
			v_u_33 = v94
			v_u_35 = v112 + v115
			local v118
			if v_u_32 then
				v118 = v_u_35
			else
				v118 = nil
			end
			v_u_34 = v118
			v_u_6.Render(v85, v_u_34)
			if not v_u_6.IsShown() then
				v_u_34 = nil
				v_u_35 = v94 + v115
			end
		else
			v_u_13 = nil
			v_u_15 = nil
			v_u_9 = Vector3.new(0, 0, 0)
			v_u_10 = Vector3.new(0, 0, 0)
			v_u_11 = Vector3.new(0, 0, 0)
			v_u_23 = nil
			v_u_24 = nil
			v_u_33 = nil
			v_u_34 = nil
			v_u_35 = nil
			v_u_6.Render(nil, nil)
		end
	else
		v_u_13 = nil
		v_u_15 = nil
		v_u_9 = Vector3.new(0, 0, 0)
		v_u_10 = Vector3.new(0, 0, 0)
		v_u_11 = Vector3.new(0, 0, 0)
		v_u_33 = nil
		v_u_34 = nil
		v_u_35 = nil
		if v85 then
			v_u_33 = v85.CFrame
			v_u_35 = v_u_33
		end
		v_u_6.Render(nil, nil)
		return
	end
end
local v_u_120 = false
function v7.Start() -- name: Start
	-- upvalues: (ref) v_u_120, (copy) v_u_2, (copy) v_u_119, (copy) v_u_6, (copy) v_u_4, (copy) v_u_74, (ref) v_u_31, (copy) v_u_3
	if not v_u_120 and v_u_2:IsClient() then
		v_u_120 = true
		v_u_2:BindToRenderStep("TribesSmoothing", Enum.RenderPriority.First.Value, v_u_119)
		v_u_2:BindToRenderStep("TribesDrawnBodyHide", Enum.RenderPriority.Last.Value + 1, v_u_6.EnforceHidden)
		local function v121()
			-- upvalues: (ref) v_u_4, (ref) v_u_74
			v_u_4.BindStep(v_u_74, 0)
		end
		local v122, v123 = pcall(v121)
		v_u_31 = v122
		if not v122 and v_u_3 then
			warn("[Smoothing] BindToSimulation unavailable, no interpolation (glide only): " .. tostring(v123))
		end
	end
end
function v7.Offset() -- name: Offset
	-- upvalues: (ref) v_u_9, (ref) v_u_11
	return v_u_9 + v_u_11
end
function v7.CameraOffset() -- name: CameraOffset
	-- upvalues: (ref) v_u_35, (ref) v_u_33
	local v124 = v_u_35
	local v125 = v_u_33
	return not (v124 and v125) and Vector3.new(0, 0, 0) or v124.Position - v125.Position
end
function v7.DrawnCFrame() -- name: DrawnCFrame
	-- upvalues: (ref) v_u_35
	return v_u_35
end
function v7.Drawn(p126) -- name: Drawn
	-- upvalues: (copy) v_u_6
	return v_u_6.Drawn(p126)
end
function v7.DrawnModel() -- name: DrawnModel
	-- upvalues: (copy) v_u_6
	return v_u_6.Model()
end
v7.DrawnChanged = v_u_6.Changed
function v7.SetBody(p127) -- name: SetBody
	-- upvalues: (ref) v_u_32, (copy) v_u_6
	v_u_32 = p127 == true
	v_u_6.SetEnabled(v_u_32)
end
function v7.BodyOn() -- name: BodyOn
	-- upvalues: (ref) v_u_32
	return v_u_32
end
function v7.CorrectionsSince(p128) -- name: CorrectionsSince
	-- upvalues: (copy) v_u_19
	local v129 = {}
	for _, v130 in v_u_19 do
		if p128 > v130[1] then
			continue
		end
		table.insert(v129, v130)
	end
	return v129
end
function v7.SimCFrame(p131) -- name: SimCFrame
	return p131.CFrame
end
function v7.Trace(p132) -- name: Trace
	-- upvalues: (copy) v_u_3, (ref) v_u_36
	if not v_u_3 then
		return nil
	end
	local v133 = v_u_36
	v_u_36 = p132 and {} or nil
	return v133
end
function v7.Reset() -- name: Reset
	-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_13, (ref) v_u_15, (ref) v_u_23, (ref) v_u_24, (copy) v_u_20
	v_u_9 = Vector3.new(0, 0, 0)
	v_u_10 = Vector3.new(0, 0, 0)
	v_u_11 = Vector3.new(0, 0, 0)
	v_u_13 = nil
	v_u_15 = nil
	v_u_23 = nil
	v_u_24 = nil
	v_u_20:Reset()
end
function v7.Stats() -- name: Stats
	-- upvalues: (ref) v_u_16, (ref) v_u_17, (ref) v_u_9, (ref) v_u_11, (copy) v_u_18, (ref) v_u_32, (ref) v_u_31, (ref) v_u_30, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (copy) v_u_6
	local v134 = {
		["smoothedCorrections"] = v_u_16,
		["largestCorrection"] = v_u_17,
		["smoothingOffset"] = (v_u_9 + v_u_11).Magnitude,
		["recentCorrections"] = table.concat(v_u_18, ","),
		["smoothingBody"] = v_u_32,
		["smoothingStepHook"] = v_u_31,
		["smoothingNoStepCorrections"] = v_u_30,
		["interpFrames"] = v_u_27,
		["interpAlphaAvg"] = v_u_27 <= 0 and 1 or v_u_28 / v_u_27,
		["interpAlphaMin"] = v_u_29
	}
	for v135, v136 in v_u_6.Stats() do
		v134[v135] = v136
	end
	return v134
end
return v7