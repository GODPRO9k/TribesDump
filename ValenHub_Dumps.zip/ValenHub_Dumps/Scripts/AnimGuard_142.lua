local v1 = game:GetService("RunService")
local v_u_2 = {}
local v_u_3 = v1:IsStudio()
local v_u_4 = v1:IsServer() and "DroppedServer" or "DroppedClient"
local v_u_5 = {
	"^rbxassetid://%d+$",
	"^rbxasset://[%w_%-%./]+$",
	"^https?://www%.roblox%.com/[Aa]sset/?%?[Ii][Dd]=%d+$",
	"^https?://assetdelivery%.roblox%.com/v1/[Aa]sset/?%?[Ii][Dd]=%d+$"
}
function v_u_2.IsContentId(p6) -- name: IsContentId
	-- upvalues: (copy) v_u_5
	for _, v7 in v_u_5 do
		if not string.match(p6, v7) then
			continue
		end
		return true
	end
	return false
end
function v_u_2.IsText(p8) -- name: IsText
	return string.find(p8, "://", 1, true) == nil
end
local v_u_9 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_11(p_u_10) -- name: drop
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	if v_u_3 then
		script:SetAttribute(v_u_4, (script:GetAttribute(v_u_4) or 0) + 1)
	end
	pcall(function()
		-- upvalues: (copy) p_u_10
		p_u_10:Stop(0)
	end)
	pcall(function()
		-- upvalues: (copy) p_u_10
		p_u_10:Destroy()
	end)
end
function v_u_2.Watch(p_u_12, p_u_13) -- name: Watch
	-- upvalues: (copy) v_u_9, (copy) v_u_2, (copy) v_u_11
	if not v_u_9[p_u_12] then
		v_u_9[p_u_12] = true
		local function v19(p_u_14) -- name: check
			-- upvalues: (ref) v_u_2, (copy) p_u_12, (ref) v_u_11, (copy) p_u_13
			local v16, v17 = pcall(function()
				-- upvalues: (copy) p_u_14
				local v15 = p_u_14.Animation
				if v15 then
					v15 = v15.AnimationId
				end
				return v15
			end)
			if not v16 or type(v17) ~= "string" then
				v17 = nil
			end
			local v18 = v17 and v_u_2.IsText(v17) and "text id" or (p_u_14.WeightTarget <= 0.01 and #p_u_12:GetPlayingAnimationTracks() > 48 and "over budget" or nil)
			if v18 then
				v_u_11(p_u_14)
				if p_u_13 then
					p_u_13(p_u_14, v18)
				end
			end
		end
		for _, v_u_20 in p_u_12:GetPlayingAnimationTracks() do
			local v22, v23 = pcall(function()
				-- upvalues: (copy) v_u_20
				local v21 = v_u_20.Animation
				if v21 then
					v21 = v21.AnimationId
				end
				return v21
			end)
			if not v22 or type(v23) ~= "string" then
				v23 = nil
			end
			if not (v23 and v_u_2.IsText(v23)) then
				continue
			end
			v_u_11(v_u_20)
			if not p_u_13 then
				continue
			end
			p_u_13(v_u_20, "text id")
		end
		p_u_12.AnimationPlayed:Connect(v19)
	end
end
return v_u_2