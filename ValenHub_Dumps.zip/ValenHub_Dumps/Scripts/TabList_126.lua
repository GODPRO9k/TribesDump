local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v4 = v2:WaitForChild("Shared")
local v_u_5 = require(v4:WaitForChild("Keybinds"))
local v_u_6 = require(v4:WaitForChild("Tribes"))
local v_u_7 = require(script.Parent.Parent.RankArt)
local v8 = {}
local v_u_9 = {
	["width"] = 900,
	["row"] = 52,
	["portrait"] = 40,
	["text"] = 19,
	["gearX"] = 330,
	["gear"] = 34,
	["k"] = 640,
	["d"] = 705,
	["a"] = 770,
	["dmg"] = 845
}
local v_u_10 = {
	["width"] = 640,
	["row"] = 36,
	["portrait"] = 30,
	["text"] = 16,
	["gearX"] = 0,
	["gear"] = 0,
	["k"] = 385,
	["d"] = 440,
	["a"] = 495,
	["dmg"] = 565
}
function v8.Init(p_u_11) -- name: Init
	-- upvalues: (copy) v_u_1, (copy) v_u_9, (copy) v_u_6, (copy) v_u_7, (copy) v_u_10, (copy) v_u_5, (copy) v_u_3
	local v_u_12 = p_u_11.UI
	local v_u_13 = p_u_11.Theme
	local v_u_14 = p_u_11.State
	local v_u_15 = p_u_11.Portraits
	local v_u_16 = p_u_11.WeaponIcon
	local v_u_17 = v_u_13.Colors
	local v_u_18 = v_u_13.Fonts
	local v_u_19 = p_u_11.MenuManager
	local v_u_20 = v_u_1.LocalPlayer
	local v_u_21 = Color3.fromRGB(142, 149, 166)
	local v_u_22 = require(script.Parent.Parent:WaitForChild("TribeEmblem"))
	v_u_22.Init(v_u_12)
	local v_u_23 = v_u_12.new("Frame", {
		["Name"] = "TabList",
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(v_u_9.width, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["BackgroundColor3"] = v_u_17.Panel,
		["BackgroundTransparency"] = 0.08,
		["Visible"] = false,
		["ZIndex"] = 40,
		v_u_12.Corner(16),
		v_u_12.Stroke(v_u_17.Stroke, 1, 0.85),
		v_u_12.Padding(14, 16, 16, 16),
		v_u_12.List(Enum.FillDirection.Vertical, 10),
		["Parent"] = p_u_11.Canvas.HUD
	})
	local v_u_24 = v_u_9
	local v_u_25 = v_u_12.new("TextButton", {
		["Name"] = "TapToClose",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["Selectable"] = false,
		["AnchorPoint"] = nil,
		["Visible"] = false,
		["ZIndex"] = 45,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Parent"] = p_u_11.Canvas.HUD
	})
	local v_u_26 = v_u_12.new("Frame", {
		["Name"] = "Clash",
		["Size"] = UDim2.new(1, 0, 0, 60),
		["LayoutOrder"] = 1,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Visible"] = false,
		["ClipsDescendants"] = true,
		["ZIndex"] = 40,
		v_u_12.Corner(12),
		["Parent"] = v_u_23
	})
	local v_u_27 = v_u_12.Gradient(v_u_17.Ally, v_u_17.Enemy, 0)
	v_u_27.Parent = v_u_26
	local v_u_28 = { v_u_22.new(44, {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["ZIndex"] = 41,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 10, 0.5, 0),
			["Parent"] = v_u_26
		}), v_u_22.new(44, {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["ZIndex"] = 41,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -10, 0.5, 0),
			["Parent"] = v_u_26
		}) }
	local function v35(p29) -- name: clashTag
		-- upvalues: (copy) v_u_12, (copy) v_u_18, (copy) v_u_17, (copy) v_u_26
		local v30 = v_u_12.new
		local v31 = "TextLabel"
		local v32 = {
			["Name"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 22,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 41,
			["Parent"] = nil,
			["Name"] = "Tag" .. p29,
			["FontFace"] = v_u_18.Display,
			["TextColor3"] = v_u_17.Text
		}
		local v33
		if p29 == 1 then
			v33 = Enum.TextXAlignment.Left
		else
			v33 = Enum.TextXAlignment.Right
		end
		v32.TextXAlignment = v33
		v32.AnchorPoint = Vector2.new(p29 == 1 and 0 or 1, 0.5)
		v32.Position = UDim2.new(p29 == 1 and 0 or 1, p29 == 1 and 64 or -64, 0.5, 0)
		v32.Size = UDim2.fromOffset(120, 26)
		v32.Parent = v_u_26
		local v34 = v30(v31, v32)
		v_u_12.TextStroke(v_u_17.Void, 1.5, 0.4).Parent = v34
		return v34
	end
	local v_u_36 = { v35(1), (v35(2)) }
	local v_u_37 = v_u_12.new("TextLabel", {
		["Name"] = "Title",
		["Text"] = "TRIBE CLASH",
		["FontFace"] = nil,
		["TextSize"] = 24,
		["TextColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 41,
		["Parent"] = nil,
		["FontFace"] = v_u_18.Display,
		["TextColor3"] = Color3.fromRGB(255, 214, 110),
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 8),
		["Size"] = UDim2.new(1, -380, 0, 26),
		["Parent"] = v_u_26
	})
	v_u_12.TextStroke(v_u_17.Void, 2, 0.3).Parent = v_u_37
	local v_u_38 = v_u_12.new("TextLabel", {
		["Name"] = "Sub",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 12,
		["TextColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["TextTruncate"] = nil,
		["ZIndex"] = 41,
		["Parent"] = nil,
		["FontFace"] = v_u_18.Heavy,
		["TextColor3"] = v_u_17.Text,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 36),
		["Size"] = UDim2.new(1, -300, 0, 14),
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Parent"] = v_u_26
	})
	v_u_12.TextStroke(v_u_17.Void, 1, 0.5).Parent = v_u_38
	local v_u_39 = {}
	local v_u_40 = {}
	local function v56(p41) -- name: makeBlock
		-- upvalues: (copy) v_u_12, (copy) v_u_23, (copy) v_u_17, (copy) v_u_22, (copy) v_u_18, (copy) v_u_13
		local v42 = v_u_12.new("Frame", {
			["Name"] = "Team" .. p41,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = p41 + 1,
			["ZIndex"] = 40,
			v_u_12.List(Enum.FillDirection.Vertical, 6),
			["Parent"] = v_u_23
		})
		local v43 = v_u_12.new("Frame", {
			["Name"] = "Top",
			["Size"] = nil,
			["LayoutOrder"] = 0,
			["ZIndex"] = 40,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 28),
			["Parent"] = v42
		})
		local v44 = v_u_12.new("Frame", {
			["Name"] = "Left",
			["Size"] = UDim2.new(1, -200, 1, 0),
			["ZIndex"] = 40,
			v_u_12.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
			["Parent"] = v43
		})
		local v45 = v_u_12.new("Frame", {
			["Name"] = "Bar",
			["Size"] = UDim2.fromOffset(4, 18),
			["LayoutOrder"] = 1,
			["BackgroundColor3"] = v_u_17.Ally,
			["ZIndex"] = 40,
			v_u_12.Corner(2),
			["Parent"] = v44
		})
		local v46 = v_u_12.new("Frame", {
			["Name"] = "Crest",
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Visible"] = false,
			["ZIndex"] = 40,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(24, 26),
			["Parent"] = v44
		})
		local v47 = v_u_22.new(24, {
			["ZIndex"] = 41,
			["Parent"] = nil,
			["Parent"] = v46
		})
		local v48 = v_u_12.new("TextLabel", {
			["Name"] = "Title",
			["Text"] = "",
			["RichText"] = true,
			["FontFace"] = nil,
			["TextSize"] = 16,
			["TextColor3"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 3,
			["ZIndex"] = 40,
			["Parent"] = nil,
			["FontFace"] = v_u_18.Heavy,
			["TextColor3"] = v_u_17.Text,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromOffset(0, 20),
			["Parent"] = v44
		})
		local v49 = v_u_12.new("Frame", {
			["Name"] = "Score",
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromOffset(0, 22),
			["LayoutOrder"] = 4,
			["BackgroundColor3"] = v_u_17.Ally,
			["BackgroundTransparency"] = 0.7,
			["ZIndex"] = 40,
			v_u_12.Corner(v_u_13.Radius.Pill),
			v_u_12.Padding(0, 9, 0, 9),
			["Parent"] = v44
		})
		local v50 = v_u_12.new("TextLabel", {
			["Name"] = "Text",
			["Text"] = "0",
			["FontFace"] = nil,
			["TextSize"] = 16,
			["TextColor3"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["ZIndex"] = 41,
			["Parent"] = nil,
			["FontFace"] = v_u_18.Display,
			["TextColor3"] = v_u_17.Text,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromScale(0, 1),
			["Parent"] = v49
		})
		local v51 = v_u_12.new("Frame", {
			["Name"] = "Glory",
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromOffset(0, 22),
			["LayoutOrder"] = 5,
			["Visible"] = false,
			["BackgroundColor3"] = Color3.fromRGB(255, 186, 46),
			["BackgroundTransparency"] = 0.82,
			["ZIndex"] = 40,
			v_u_12.Corner(v_u_13.Radius.Pill),
			v_u_12.Padding(0, 9, 0, 9),
			["Parent"] = v44
		})
		local v52 = v_u_12.new("TextLabel", {
			["Name"] = "Text",
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 12,
			["TextColor3"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["ZIndex"] = 41,
			["Parent"] = nil,
			["FontFace"] = v_u_18.Heavy,
			["TextColor3"] = Color3.fromRGB(255, 196, 80),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromScale(0, 1),
			["Parent"] = v51
		})
		local v53 = {}
		for v54, v55 in {
			"K",
			"D",
			"A",
			"DMG"
		} do
			v53[v54] = v_u_12.new("TextLabel", {
				["Name"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 13,
				["TextColor3"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 40,
				["Parent"] = nil,
				["Name"] = v55,
				["Text"] = v55,
				["FontFace"] = v_u_18.Heavy,
				["TextColor3"] = v_u_17.TextDim,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.new(0, 0, 0.5, 0),
				["Size"] = UDim2.fromOffset(v54 == 4 and 80 or 60, 16),
				["Parent"] = v43
			})
		end
		return {
			["frame"] = v42,
			["bar"] = v45,
			["crest"] = v47,
			["crestHolder"] = v46,
			["title"] = v48,
			["score"] = v50,
			["scorePill"] = v49,
			["chip"] = v51,
			["chipText"] = v52,
			["caps"] = v53,
			["list"] = v_u_12.new("Frame", {
				["Name"] = "Rows",
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["LayoutOrder"] = 1,
				["ZIndex"] = 40,
				v_u_12.List(Enum.FillDirection.Vertical, 6),
				["Parent"] = v42
			})
		}
	end
	v_u_39[1] = v56(1)
	v_u_39[2] = v56(2)
	local function v_u_61() -- name: placeColumns
		-- upvalues: (ref) v_u_24, (copy) v_u_39
		local v57 = {
			v_u_24.k,
			v_u_24.d,
			v_u_24.a,
			v_u_24.dmg
		}
		for _, v58 in v_u_39 do
			for v59, v60 in v58.caps do
				v60.Position = UDim2.new(0, v57[v59], 0.5, 0)
			end
		end
	end
	local function v_u_80(p62) -- name: makeRow
		-- upvalues: (copy) v_u_12, (ref) v_u_24, (copy) v_u_17, (copy) v_u_39, (copy) v_u_13, (copy) v_u_18, (copy) v_u_21
		local v63 = v_u_12.new("Frame", {
			["Name"] = "R_" .. p62,
			["Size"] = UDim2.new(1, 0, 0, v_u_24.row),
			["BackgroundColor3"] = v_u_17.Void,
			["BackgroundTransparency"] = 0.45,
			["ZIndex"] = 40,
			v_u_12.Corner(10),
			["Parent"] = v_u_39[1].list
		})
		local v64 = v_u_12.Stroke(v_u_17.Accent, 2, 0)
		v64.Enabled = false
		v64.Parent = v63
		local v65 = v_u_12.new("Frame", {
			["Name"] = "Tribe",
			["Position"] = UDim2.fromOffset(0, 8),
			["Size"] = UDim2.new(0, 3, 1, -16),
			["BackgroundColor3"] = v_u_17.Text,
			["Visible"] = false,
			["ZIndex"] = 42,
			v_u_12.Corner(2),
			["Parent"] = v63
		})
		local v66 = v_u_12.new("ImageLabel", {
			["Name"] = "Img",
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 6, 0.5, 0),
			["Size"] = UDim2.fromOffset(v_u_24.portrait, v_u_24.portrait),
			["BackgroundColor3"] = v_u_17.Raised,
			["ScaleType"] = Enum.ScaleType.Crop,
			["ZIndex"] = 41,
			v_u_12.Corner(v_u_13.Radius.Pill),
			["Parent"] = v63
		})
		local v67 = v_u_24.portrait + 14
		local v68
		if v_u_24.gear > 0 then
			v68 = v_u_24.gearX
		else
			v68 = v_u_24.k - 40
		end
		local v69 = v68 - v67 - 10
		local v70 = v_u_12.new("TextLabel", {
			["Name"] = "Name",
			["Text"] = "",
			["RichText"] = true,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 41,
			["Parent"] = nil,
			["FontFace"] = v_u_18.Heavy,
			["TextSize"] = v_u_24.text,
			["TextColor3"] = v_u_17.Text,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Position"] = UDim2.new(0, v67, 0.5, -v_u_24.text + 1),
			["Size"] = UDim2.fromOffset(v69, v_u_24.text + 2),
			["Parent"] = v63
		})
		local v71 = v_u_12.new("TextLabel", {
			["Name"] = "Sub",
			["Text"] = "",
			["RichText"] = true,
			["FontFace"] = nil,
			["TextSize"] = 12,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 41,
			["Parent"] = nil,
			["FontFace"] = v_u_18.SemiBold,
			["TextColor3"] = v_u_21,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Position"] = UDim2.new(0, v67, 0.5, 3),
			["Size"] = UDim2.fromOffset(v69, 14),
			["Parent"] = v63
		})
		local v72 = v_u_12.new
		local v73 = {
			["Name"] = "Gear",
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, v_u_24.gearX, 0.5, 0)
		}
		local v74 = UDim2.fromOffset
		local v75 = v_u_24.k - 40 - v_u_24.gearX
		v73.Size = v74(math.max(0, v75), v_u_24.gear)
		v73.Visible = v_u_24.gear > 0
		v73.ZIndex = 41
		__set_list(v73, 1, {(v_u_12.List(Enum.FillDirection.Horizontal, 4, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center))})
		v73.Parent = v63
		local v76 = v72("Frame", v73)
		local v77 = {}
		for v78, v79 in {
			v_u_24.k,
			v_u_24.d,
			v_u_24.a,
			v_u_24.dmg
		} do
			v77[v78] = v_u_12.new("TextLabel", {
				["Text"] = "0",
				["FontFace"] = nil,
				["TextSize"] = nil,
				["TextColor3"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 41,
				["Parent"] = nil,
				["FontFace"] = v_u_18.Display,
				["TextSize"] = v_u_24.text + 3,
				["TextColor3"] = v_u_17.Text,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.new(0, v79, 0.5, 0),
				["Size"] = UDim2.fromOffset(v78 == 4 and 80 or 60, v_u_24.row),
				["Parent"] = v63
			})
		end
		return {
			["frame"] = nil,
			["stroke"] = nil,
			["stripe"] = nil,
			["img"] = nil,
			["name"] = nil,
			["sub"] = nil,
			["gear"] = nil,
			["gearKey"] = "",
			["cells"] = nil,
			["frame"] = v63,
			["stroke"] = v64,
			["stripe"] = v65,
			["img"] = v66,
			["name"] = v70,
			["sub"] = v71,
			["gear"] = v76,
			["cells"] = v77
		}
	end
	local function v_u_90(p81) -- name: teamTribe
		local v82 = {}
		local v83 = nil
		local v84 = 0
		local v85
		if type(p81) == "table" then
			local v86 = p81.members
			v85 = type(v86) ~= "table" and {} or p81.members
		else
			v85 = {}
		end
		for _, v87 in v85 do
			local v88 = v87.tribe
			if type(v88) ~= "table" then
				continue
			end
			local v89 = v88.id
			if type(v89) ~= "number" then
				continue
			end
			v82[v88.id] = (v82[v88.id] or 0) + 1
			if v82[v88.id] < 2 or v84 >= v82[v88.id] then
				continue
			end
			v84 = v82[v88.id]
			v83 = v88
		end
		return v83, v84
	end
	local v_u_91 = {}
	v_u_14.MatchEvent:Connect(function(p92, p93)
		-- upvalues: (copy) v_u_14, (copy) v_u_91
		if p92 == "MatchStart" and type(p93) == "table" then
			local v94 = v_u_14.Match
			local v95 = v94 and v94.mapId or (p93.mapId or "")
			local v96 = tostring(v95)
			local v97 = v_u_91
			local v98 = p93.holder
			local v99
			if type(v98) == "table" then
				v99 = p93.holder
			else
				v99 = false
			end
			v97[v96] = v99
		end
	end)
	local v_u_100 = false
	local function v_u_110(p101) -- name: mapHolder
		-- upvalues: (copy) v_u_91, (copy) p_u_11, (ref) v_u_100
		local v102 = p101.mapId or ""
		local v103 = tostring(v102)
		local v104 = v_u_91[v103]
		if v104 ~= nil then
			return v104 or nil
		end
		local v105 = p_u_11.Tribes
		if v105 then
			v105 = p_u_11.Tribes.CachedTerritories()
		end
		local v106 = v105 and v105.maps
		if v106 then
			v106 = v105.maps[v103]
		end
		if not v106 then
			if p_u_11.Tribes and not v_u_100 then
				v_u_100 = true
				task.spawn(function()
					-- upvalues: (ref) p_u_11, (ref) v_u_100
					p_u_11.Tribes.Territories(false)
					v_u_100 = false
				end)
			end
			return nil
		end
		local v107 = v106.holder and v105.tribes
		if v107 then
			local v108 = v105.tribes
			local v109 = v106.holder
			v107 = v108[tostring(v109)]
		end
		v_u_91[v103] = v107 or false
		return v107
	end
	local function v_u_166(p111, p112, p113, p114, p115) -- name: paintRow
		-- upvalues: (copy) v_u_14, (ref) v_u_6, (copy) v_u_17, (copy) v_u_15, (copy) v_u_22, (ref) v_u_7, (copy) v_u_12, (ref) v_u_24, (copy) v_u_16
		local v116 = p112.id == v_u_14.MyId()
		local v117
		if p115 == nil then
			v117 = false
		else
			local v118 = p112.tribe
			if type(v118) == "table" then
				v117 = p112.tribe.id == p115.id
			else
				v117 = false
			end
		end
		p111.stripe.Visible = v117
		if v117 then
			p111.stripe.BackgroundColor3 = v_u_6.Color(p115.color1)
		end
		local v119 = p112.alive ~= false
		local v120 = p112.connected == false
		p111.frame.LayoutOrder = p114
		p111.stroke.Enabled = v116
		local v121 = p111.frame
		local v122
		if v116 then
			v122 = v_u_17.AccentDeep
		else
			v122 = v_u_17.Void
		end
		v121.BackgroundColor3 = v122
		p111.frame.BackgroundTransparency = v116 and 0.4 or 0.45
		v_u_15.Apply(p111.img, p112, 60)
		local v123 = v_u_15.SetTint
		local v124 = p111.img
		local v125
		if v119 then
			v125 = Color3.new(1, 1, 1)
		else
			v125 = Color3.fromRGB(110, 110, 120)
		end
		v123(v124, v125, v119 and 0 or 0.35)
		local v126 = ""
		local v127 = p112.tribe
		if type(v127) == "table" then
			local v128 = p112.tribe.tag
			if type(v128) == "string" then
				v126 = string.format("<font color=\"#%s\">%s</font> ", v_u_22.TagColor(p112.tribe.color1):ToHex(), v_u_22.Tag(p112.tribe.tag))
			end
		end
		local v129 = p111.name
		local v130 = p112.name or "?"
		v129.Text = v126 .. tostring(v130) .. (v116 and "  (you)" or "")
		local v131 = p111.name
		local v132
		if v120 then
			v132 = v_u_17.TextMuted
		elseif v119 then
			v132 = v_u_17.Text
		else
			v132 = v_u_17.TextDim
		end
		v131.TextColor3 = v132
		local v133 = v_u_7.Ranks.RankOf
		local v134 = p112.trophies
		local v135 = v133(tonumber(v134) or 0)
		local v136 = string.format("<font color=\"#%s\">%s</font>", v_u_7.Color(v135):ToHex(), v_u_7.Ranks.Get(v135).name)
		local v137 = p111.sub
		local v138 = p112.level
		v137.Text = ("Lv %*  \194\183  "):format(tonumber(v138) or 1) .. v136 .. (v120 and "  \194\183  left the match" or (v119 and "" or "  \194\183  eliminated"))
		local v139 = {}
		local v140 = p112.kills
		local v141 = tonumber(v140) or 0
		local v142 = p112.deaths
		local v143 = tonumber(v142) or 0
		local v144 = p112.assists
		local v145 = tonumber(v144) or 0
		local v146 = p112.damage
		__set_list(v139, 1, {v141, v143, v145, tonumber(v146) or 0})
		for v147, v148 in p111.cells do
			local v149
			if v147 == 4 then
				v149 = v_u_12.FormatCompact(v139[v147])
			else
				local v150 = v139[v147]
				v149 = tostring(v150)
			end
			v148.Text = v149
			local v151
			if v147 == 1 and v139[1] > 0 then
				local v152
				if p113 then
					v152 = v_u_17.Ally
				else
					v152 = v_u_17.Enemy
				end
				v151 = v152:Lerp(v_u_17.Text, 0.35)
			elseif v119 then
				v151 = v_u_17.Text
			else
				v151 = v_u_17.TextDim
			end
			v148.TextColor3 = v151
		end
		if v_u_24.gear > 0 then
			local v153 = p112.loadout
			local v154
			if type(v153) == "table" then
				local v155 = p112.loadout.items
				v154 = type(v155) ~= "table" and {} or p112.loadout.items
			else
				v154 = {}
			end
			local v156 = p112.loadout
			local v157
			if type(v156) == "table" then
				local v158 = p112.loadout.armor
				if type(v158) == "string" then
					v157 = p112.loadout.armor
				else
					v157 = nil
				end
			else
				v157 = nil
			end
			local v159 = table.concat(v154, ",") .. "|" .. tostring(v157)
			if v159 ~= p111.gearKey then
				p111.gearKey = v159
				for _, v160 in p111.gear:GetChildren() do
					if not v160:IsA("GuiObject") then
						continue
					end
					v160:Destroy()
				end
				local v161 = table.clone(v154)
				if v157 then
					table.insert(v161, v157)
				end
				for v162, v163 in v161 do
					if v162 > 6 then
						break
					end
					local v164 = v_u_12.new("Frame", {
						["Name"] = "G" .. v162,
						["Size"] = UDim2.fromOffset(v_u_24.gear, v_u_24.gear),
						["LayoutOrder"] = v162,
						["BackgroundColor3"] = v_u_17.Raised,
						["BackgroundTransparency"] = 0.5,
						["ZIndex"] = 41,
						v_u_12.Corner(8),
						["Parent"] = p111.gear
					})
					local v165 = v_u_12.new("Frame", {
						["Name"] = "Icon",
						["Size"] = nil,
						["ZIndex"] = 42,
						["Parent"] = nil,
						["Size"] = UDim2.fromScale(1, 1),
						["Parent"] = v164
					})
					v_u_16.Set(v165, v163, {
						["glow"] = false
					})
				end
			end
		end
	end
	local function v_u_244() -- name: paint
		-- upvalues: (copy) v_u_14, (copy) v_u_90, (copy) v_u_26, (copy) v_u_23, (copy) v_u_17, (copy) v_u_28, (copy) v_u_36, (copy) v_u_22, (copy) v_u_27, (ref) v_u_6, (copy) v_u_110, (copy) v_u_38, (copy) v_u_39, (copy) v_u_40, (copy) v_u_80, (copy) v_u_166
		local v167 = v_u_14.Match
		if v167 then
			local v168 = v167.teams
			if type(v168) == "table" then
				local v169 = v_u_14.MyTeam()
				local v170 = { v169, v169 == 1 and 2 or 1 }
				local v171 = {}
				local v172 = {
					{},
					{}
				}
				local v173 = {}
				for v174, v175 in v170 do
					local v176, v177 = v_u_90(v167.teams[v175])
					v171[v174] = v176 and {
						["tribe"] = v176,
						["n"] = v177
					} or nil
					for _, v178 in v167.teams[v175] and (v167.teams[v175].members or {}) or {} do
						local v179 = v178.tribe
						if type(v179) ~= "table" then
							continue
						end
						local v180 = v178.tribe.id
						if type(v180) ~= "number" then
							continue
						end
						v172[v174][v178.tribe.id] = true
					end
				end
				local v181
				if v171[1] == nil or v171[2] == nil then
					v181 = false
				else
					v181 = v171[1].tribe.id ~= v171[2].tribe.id
				end
				v_u_26.Visible = v181
				local v182 = v_u_23:FindFirstChildOfClass("UIStroke")
				local v183
				if v181 then
					v183 = Color3.fromRGB(255, 196, 80)
				else
					v183 = v_u_17.Stroke
				end
				v182.Color = v183
				v_u_23:FindFirstChildOfClass("UIStroke").Transparency = v181 and 0.45 or 0.85
				if v181 then
					for v184 = 1, 2 do
						local v185 = v171[v184].tribe
						v_u_28[v184]:Set(v185.icon, v185.color1, v185.color2, v185.tag)
						v_u_36[v184].Text = v_u_22.Tag(v185.tag)
					end
					v_u_27.Color = ColorSequence.new(v_u_6.Color(v171[1].tribe.color1):Lerp(v_u_17.Panel, 0.55), v_u_6.Color(v171[2].tribe.color1):Lerp(v_u_17.Panel, 0.55))
					local v186 = string.upper
					local v187 = v167.mapName or "this map"
					local v188 = v186((tostring(v187)))
					local v189 = v_u_110(v167)
					if v189 and (v189.id == v171[1].tribe.id or v189.id == v171[2].tribe.id) then
						v_u_38.Text = ("%* DEFENDS %*"):format(v_u_22.Tag(v189.tag), v188)
					elseif v189 then
						v_u_38.Text = ("%*  \194\183  HELD BY %*"):format(v188, (v_u_22.Tag(v189.tag)))
					else
						v_u_38.Text = ("GLORY DECIDES WHO HOLDS %*"):format(v188)
					end
				end
				for v190, v191 in v170 do
					local v192 = v167.teams[v191]
					local v193 = v_u_39[v190]
					local v194 = v191 == v169
					local v195
					if v194 then
						v195 = v_u_17.Ally
					else
						v195 = v_u_17.Enemy
					end
					local v196 = v171[v190]
					v193.bar.BackgroundColor3 = v195
					v193.scorePill.BackgroundColor3 = v195
					local v197 = v193.score
					local v198 = v192 and (v192.score or 0) or 0
					v197.Text = tostring(v198)
					v193.crestHolder.Visible = v196 ~= nil
					if v196 then
						local v199 = v196.tribe
						v193.crest:Set(v199.icon, v199.color1, v199.color2, v199.tag)
						local v200 = v193.title
						local v201 = string.format
						local v202 = v_u_22.TagColor(v199.color1):ToHex()
						local v203 = v_u_22.Tag(v199.tag)
						local v204 = string.upper
						local v205 = v199.name or ""
						v200.Text = v201("<font color=\"#%s\">%s</font>  %s", v202, v203, v204((tostring(v205))))
						v193.title.TextColor3 = v_u_17.Text
						local v206 = v172[3 - v190][v199.id] == true
						v193.chip.Visible = true
						local v207 = v193.chipText
						local v208
						if v206 then
							v208 = "SPLIT  \194\183  NO GLORY"
						else
							local v209 = string.format
							local v210 = v_u_6.STACK_MULT
							local v211 = v196.n
							local v212 = v210[math.clamp(v211, 1, 3)]
							v208 = v209("\195\151%s GLORY", (tostring(v212)))
						end
						v207.Text = v208
						local v213 = v193.chipText
						local v214
						if v206 then
							v214 = v_u_17.TextDim
						else
							v214 = Color3.fromRGB(255, 196, 80)
						end
						v213.TextColor3 = v214
						v193.chip.BackgroundTransparency = v206 and 0.9 or 0.82
					else
						local v215 = v193.title
						local v216 = string.upper
						local v217 = v192 and v192.name or (v194 and "Your team" or "Enemies")
						v215.Text = v216((tostring(v217)))
						v193.title.TextColor3 = v195:Lerp(v_u_17.Text, 0.25)
						v193.chip.Visible = false
					end
					local v218 = table.clone(v192 and v192.members or {})
					table.sort(v218, function(p219, p220)
						local v221 = p219.kills
						local v222 = (tonumber(v221) or 0) * 100
						local v223 = p219.damage
						local v224 = v222 + (tonumber(v223) or 0)
						local v225 = p219.assists
						local v226 = v224 + (tonumber(v225) or 0) * 40
						local v227 = p220.kills
						local v228 = (tonumber(v227) or 0) * 100
						local v229 = p220.damage
						local v230 = v228 + (tonumber(v229) or 0)
						local v231 = p220.assists
						local v232 = v230 + (tonumber(v231) or 0) * 40
						if v226 ~= v232 then
							return v232 < v226
						end
						local v233 = p219.name
						local v234 = tostring(v233)
						local v235 = p220.name
						return v234 < tostring(v235)
					end)
					for v236, v237 in v218 do
						if type(v237) ~= "table" then
							continue
						end
						local v238 = v237.id
						if type(v238) ~= "string" then
							continue
						end
						v173[v237.id] = true
						local v239 = v_u_40[v237.id]
						if not v239 then
							v239 = v_u_80(v237.id)
							v_u_40[v237.id] = v239
						end
						v239.frame.Parent = v193.list
						local v240 = v_u_166
						local v241
						if v171[v190] then
							v241 = v171[v190].tribe
						else
							v241 = nil
						end
						v240(v239, v237, v194, v236, v241)
					end
				end
				for v242, v243 in v_u_40 do
					if v173[v242] then
						continue
					end
					v243.frame:Destroy()
					v_u_40[v242] = nil
				end
				return
			end
		end
	end
	local function v_u_258() -- name: layout
		-- upvalues: (copy) v_u_12, (ref) v_u_10, (ref) v_u_9, (ref) v_u_24, (copy) v_u_40, (copy) v_u_23, (copy) v_u_26, (copy) v_u_37, (copy) v_u_38, (copy) v_u_61
		local v245
		if v_u_12.Compact then
			v245 = v_u_10
		else
			v245 = v_u_9
		end
		if v245 ~= v_u_24 then
			v_u_24 = v245
			for v246, v247 in v_u_40 do
				v247.frame:Destroy()
				v_u_40[v246] = nil
			end
		end
		local v248 = v_u_12.CanvasSize()
		local v249 = v_u_23
		local v250 = UDim2.fromOffset
		local v251 = v248.X - 24
		local v252 = v_u_24.width
		local v253 = math.min(v252, 240)
		local v254 = v_u_24.width
		v249.Size = v250(math.clamp(v251, v253, v254), 0)
		local v255 = v_u_12.Compact
		local v256 = v_u_23:FindFirstChildOfClass("UIPadding")
		if v256 then
			v256.PaddingTop = UDim.new(0, v255 and 10 or 14)
			v256.PaddingBottom = UDim.new(0, v255 and 10 or 16)
		end
		local v257 = v_u_23:FindFirstChildOfClass("UIListLayout")
		if v257 then
			v257.Padding = UDim.new(0, v255 and 6 or 10)
		end
		v_u_26.Size = UDim2.new(1, 0, 0, v255 and 50 or 60)
		v_u_37.Position = UDim2.new(0.5, 0, 0, v255 and 4 or 8)
		v_u_38.Position = UDim2.new(0.5, 0, 0, v255 and 30 or 36)
		v_u_61()
	end
	local v_u_259 = false
	local v_u_260 = false
	local v_u_261 = nil
	local function v_u_270() -- name: update
		-- upvalues: (ref) v_u_261, (ref) v_u_259, (ref) v_u_260, (copy) v_u_14, (copy) v_u_20, (copy) v_u_19, (copy) v_u_23, (copy) v_u_258, (copy) v_u_244, (copy) v_u_12, (copy) v_u_25
		local v262
		if v_u_261 == nil then
			v262 = v_u_259 or v_u_260
		else
			v262 = v_u_261
		end
		local v263 = v262 and (v_u_261 ~= true and v_u_14.SeesMatch())
		if v263 then
			if v_u_14.Phase() == "MatchEnd" or v_u_20:GetAttribute("ReplayPlaying") == true then
				v263 = false
			else
				v263 = v_u_19.Current() == nil
			end
		end
		if not v263 then
			local v264 = v_u_14.SeesMatch()
			if v264 then
				if v_u_14.Phase() == "MatchEnd" or v_u_20:GetAttribute("ReplayPlaying") == true then
					v264 = false
				else
					v264 = v_u_19.Current() == nil
				end
			end
			local v265
			if v264 then
				v265 = v_u_260
			else
				v265 = false
			end
			v_u_260 = v265
		end
		if v263 and not v_u_23.Visible then
			v_u_258()
			v_u_244()
			v_u_23.Visible = true
			v_u_12.Pop(v_u_23, 0.97)
		elseif v263 then
			v_u_244()
		else
			v_u_23.Visible = false
		end
		local v266 = v_u_25
		local v267 = v_u_23.Visible
		if v267 then
			v267 = v_u_260
		end
		v266.Visible = v267
		if v_u_25.Visible then
			task.defer(function()
				-- upvalues: (ref) v_u_12, (ref) v_u_25, (ref) v_u_23
				local v268 = v_u_12.Scale
				local v269 = math.max(v268, 0.01)
				v_u_25.Position = v_u_23.Position
				v_u_25.Size = UDim2.fromOffset(v_u_23.AbsoluteSize.X / v269, v_u_23.AbsoluteSize.Y / v269)
			end)
		end
	end
	v_u_5.OnInput("Began", function(p271, p272)
		-- upvalues: (ref) v_u_3, (ref) v_u_5, (copy) v_u_14, (ref) v_u_259, (copy) v_u_270
		if not v_u_3:GetFocusedTextBox() then
			if v_u_5.ActionOf(p271) == "Scoreboard" and not p272 or v_u_5.IsPad(p271, "Scoreboard") and (v_u_14.SeesMatch() and not v_u_5.PadBlocked()) then
				v_u_259 = true
				v_u_270()
			end
		end
	end)
	v_u_5.OnInput("Ended", function(p273)
		-- upvalues: (ref) v_u_5, (ref) v_u_259, (copy) v_u_270
		if v_u_5.ActionOf(p273) == "Scoreboard" or v_u_5.IsPad(p273, "Scoreboard") then
			v_u_259 = false
			v_u_270()
		end
	end)
	local function v_u_275() -- name: hookScoreboard
		-- upvalues: (copy) p_u_11, (copy) v_u_12, (ref) v_u_260, (copy) v_u_270
		local v274 = p_u_11.Scoreboard
		if v274 and not v274:FindFirstChild("TabListOpen") then
			v_u_12.new("TextButton", {
				["Name"] = "TabListOpen",
				["Text"] = "",
				["AutoButtonColor"] = false,
				["Selectable"] = false,
				["Size"] = nil,
				["ZIndex"] = 30,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v274
			}).Activated:Connect(function()
				-- upvalues: (ref) v_u_260, (ref) v_u_270
				v_u_260 = not v_u_260
				v_u_270()
			end)
		end
	end
	v_u_275()
	v_u_25.Activated:Connect(function()
		-- upvalues: (ref) v_u_260, (copy) v_u_270
		if v_u_260 then
			v_u_260 = false
			v_u_270()
		end
	end)
	v_u_14.MatchChanged:Connect(function()
		-- upvalues: (copy) v_u_275, (copy) v_u_23, (ref) v_u_259, (ref) v_u_260, (copy) v_u_270
		v_u_275()
		if v_u_23.Visible or (v_u_259 or v_u_260) then
			v_u_270()
		end
	end)
	v_u_14.PlayerStateChanged:Connect(function()
		-- upvalues: (ref) v_u_259, (ref) v_u_260, (copy) v_u_270
		v_u_259 = false
		v_u_260 = false
		v_u_270()
	end)
	v_u_14.WatchChanged:Connect(function()
		-- upvalues: (ref) v_u_259, (ref) v_u_260, (copy) v_u_270
		v_u_259 = false
		v_u_260 = false
		v_u_270()
	end)
	v_u_19.Changed:Connect(function()
		-- upvalues: (copy) v_u_270
		v_u_270()
	end)
	v_u_20:GetAttributeChangedSignal("ReplayPlaying"):Connect(v_u_270)
	v_u_12.OnResize(function()
		-- upvalues: (copy) v_u_23, (copy) v_u_258
		if v_u_23.Visible then
			v_u_258()
		end
	end)
	v_u_12.LayoutChanged:Connect(function()
		-- upvalues: (copy) v_u_23, (copy) v_u_258, (copy) v_u_244
		if v_u_23.Visible then
			v_u_258()
			v_u_244()
		end
	end)
	v_u_258()
	function p_u_11.Debug.tablist(p276)
		-- upvalues: (ref) v_u_261, (copy) v_u_270, (copy) v_u_23
		local v277
		if p276 == nil then
			v277 = nil
		else
			v277 = p276 == true
		end
		v_u_261 = v277
		v_u_270()
		return {
			["visible"] = v_u_23.Visible,
			["rows"] = #v_u_23:GetDescendants()
		}
	end
end
return v8