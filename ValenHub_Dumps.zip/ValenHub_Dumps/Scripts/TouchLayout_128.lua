local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("StarterGui")
local v_u_5 = game:GetService("TextChatService")
local v_u_6 = game:GetService("UserInputService")
local v7 = {}
local v_u_8 = nil
local v_u_9 = {
	{
		["name"] = "Attack",
		["gui"] = "CombatTouch",
		["root"] = "Root",
		["label"] = "ATTACK"
	},
	{
		["name"] = "Secondary",
		["gui"] = "CombatTouch",
		["root"] = "Root",
		["label"] = "ALT"
	},
	{
		["name"] = "Reload",
		["gui"] = "CombatTouch",
		["root"] = "Root",
		["label"] = "RELOAD"
	},
	{
		["name"] = "Jump",
		["gui"] = "CharacterTouch",
		["root"] = "Buttons",
		["label"] = "JUMP"
	},
	{
		["name"] = "Slide",
		["gui"] = "CharacterTouch",
		["root"] = "Buttons",
		["label"] = "SLIDE"
	},
	{
		["name"] = "View",
		["gui"] = "CharacterTouch",
		["root"] = "Buttons",
		["label"] = "1P / 3P"
	}
}
function v7.Init(p_u_10) -- name: Init
	-- upvalues: (copy) v_u_2, (copy) v_u_9, (copy) v_u_1, (ref) v_u_8, (copy) v_u_5, (copy) v_u_4, (copy) v_u_3, (copy) v_u_6
	local v_u_11 = p_u_10.UI
	local v_u_12 = p_u_10.Theme
	local v_u_13 = p_u_10.State
	local v_u_14 = v_u_12.Colors
	local v_u_15 = v_u_12.Fonts
	local _ = v_u_2.LocalPlayer
	local v_u_16 = p_u_10.PlayerGui
	local v_u_17 = false
	local function v_u_24() -- name: applySaved
		-- upvalues: (ref) v_u_17, (ref) v_u_9, (copy) v_u_16, (copy) v_u_13
		if not v_u_17 then
			for _, v18 in v_u_9 do
				local v19 = v_u_16:FindFirstChild(v18.gui)
				if not (v19 and v19:IsA("ScreenGui")) then
					v19 = nil
				end
				if not v19 then
					continue
				end
				local v20 = v18.name
				local v21 = v_u_13.Profile
				if v21 then
					v21 = v_u_13.Profile.settings
				end
				local v22
				if type(v21) == "table" then
					v22 = v21["touch_" .. v20]
				else
					v22 = false
				end
				local v23 = type(v22) ~= "string" and "" or v22
				if v23 == "" then
					v23 = nil
				end
				if v19:GetAttribute("Override_" .. v18.name) == v23 then
					continue
				end
				v19:SetAttribute("Override_" .. v18.name, v23)
			end
		end
	end
	v_u_13.ProfileChanged:Connect(v_u_24)
	v_u_16.ChildAdded:Connect(function(p25)
		-- upvalues: (copy) v_u_24
		if p25.Name == "CombatTouch" or p25.Name == "CharacterTouch" then
			task.defer(v_u_24)
		end
	end)
	task.defer(v_u_24)
	local v_u_26 = nil
	local v_u_27 = nil
	local v_u_28 = {}
	local v_u_29 = {}
	local v_u_30 = {}
	local v_u_31 = nil
	local v_u_32 = nil
	local v_u_33 = ""
	local v_u_34 = 0
	local function v_u_44(p35, p36) -- name: encode
		-- upvalues: (ref) v_u_27
		local v37 = v_u_27.AbsoluteSize
		local v38 = string.format
		local v39 = p35.x / v37.X * 1000 + 0.5
		local v40 = math.floor(v39)
		local v41 = p35.y / v37.Y * 1000 + 0.5
		local v42 = math.floor(v41)
		local v43 = p35.d / math.max(p36, 1) * 1000 + 0.5
		return v38("%d,%d,%d", v40, v42, (math.floor(v43)))
	end
	local function v_u_53(p45) -- name: push
		-- upvalues: (copy) v_u_29, (ref) v_u_9, (copy) v_u_16, (copy) v_u_44
		local v46 = v_u_29[p45]
		for _, v47 in v_u_9 do
			if v47.name ~= p45 then
				continue
			end
			local v48 = v_u_16:FindFirstChild(v47.gui)
			if not (v48 and v48:IsA("ScreenGui")) then
				v48 = nil
			end
			local v49 = v_u_16:FindFirstChild(v47.gui)
			if not (v49 and v49:IsA("ScreenGui")) then
				v49 = nil
			end
			if v49 then
				v49 = v49:FindFirstChild(v47.root)
			end
			if v49 then
				v49 = v49:FindFirstChild(v47.name)
			end
			if not (v49 and v49:IsA("GuiObject")) then
				v49 = nil
			end
			if not (v48 and (v49 and v46)) then
				continue
			end
			local v50 = v49:GetAttribute("DefaultSize")
			local v51 = "Override_" .. p45
			local v52 = v_u_44
			if type(v50) ~= "number" then
				v50 = v46.d
			end
			v48:SetAttribute(v51, v52(v46, v50))
		end
	end
	local function v_u_58() -- name: readLive
		-- upvalues: (ref) v_u_27, (ref) v_u_9, (copy) v_u_16, (copy) v_u_29
		local v54 = v_u_27
		for _, v55 in v_u_9 do
			local v56 = v_u_16:FindFirstChild(v55.gui)
			if not (v56 and v56:IsA("ScreenGui")) then
				v56 = nil
			end
			if v56 then
				v56 = v56:FindFirstChild(v55.root)
			end
			if v56 then
				v56 = v56:FindFirstChild(v55.name)
			end
			if not (v56 and v56:IsA("GuiObject")) then
				v56 = nil
			end
			if not v56 or v56.AbsoluteSize.X <= 4 then
				continue
			end
			local v57 = v56.AbsolutePosition + v56.AbsoluteSize / 2 - v54.AbsolutePosition
			v_u_29[v55.name] = {
				["x"] = v57.X,
				["y"] = v57.Y,
				["d"] = v56.AbsoluteSize.X
			}
		end
	end
	local v_u_59 = nil
	local v_u_60 = 0
	local function v_u_64() -- name: hotbarRect
		-- upvalues: (ref) v_u_27, (copy) p_u_10, (copy) v_u_11
		local v61 = v_u_27.AbsoluteSize
		local v62 = (not p_u_10.HotbarWidth and 404 or p_u_10.HotbarWidth()) * v_u_11.Scale + 16
		local v63 = ((not p_u_10.HotbarTop and 84 or p_u_10.HotbarTop()) + 58) * v_u_11.Scale
		return Vector2.new(v61.X / 2 - v62 / 2, v61.Y - v63), Vector2.new(v62, v63)
	end
	local function v_u_76(p65, p66, p67) -- name: hitsBox
		local v68 = p65.x
		local v69 = p66.X
		local v70 = p66.X + p67.X
		local v71 = math.clamp(v68, v69, v70)
		local v72 = p65.y
		local v73 = p66.Y
		local v74 = p66.Y + p67.Y
		local v75 = math.clamp(v72, v73, v74)
		return (Vector2.new(v71, v75) - Vector2.new(p65.x, p65.y)).Magnitude < p65.d / 2
	end
	local function v_u_89(p77, p78) -- name: valid
		-- upvalues: (ref) v_u_27, (ref) v_u_59, (copy) v_u_76, (copy) v_u_64, (ref) v_u_1, (ref) v_u_60, (copy) v_u_29, (copy) v_u_28
		local v79 = v_u_27.AbsoluteSize
		local v80 = p78.d / 2
		if p78.x - v80 < 0 or (p78.y - v80 < 0 or (p78.x + v80 > v79.X or p78.y + v80 > v79.Y)) then
			return false
		end
		local v81 = v_u_59
		if v81 and (v_u_27 and v_u_76(p78, v81.AbsolutePosition - v_u_27.AbsolutePosition, v81.AbsoluteSize)) then
			return false
		end
		local v82, v83 = v_u_64()
		if v_u_76(p78, v82, v83) then
			return false
		end
		local v84 = v_u_1.TopbarInset
		local v85 = v_u_60
		local v86 = v84.Min.X
		v_u_60 = math.max(v85, v86)
		if v84.Height > 0 and v_u_76(p78, Vector2.zero, Vector2.new(v_u_60, v84.Max.Y)) then
			return false
		end
		for v87, v88 in v_u_29 do
			if v87 == p77 or (not v_u_28[v87] or (not v_u_28[v87].frame.Visible or (Vector2.new(p78.x, p78.y) - Vector2.new(v88.x, v88.y)).Magnitude >= v80 + v88.d / 2 + 6)) then
				continue
			end
			return false
		end
		return true
	end
	local function v_u_98(p90) -- name: clampInside
		-- upvalues: (ref) v_u_27
		local v91 = v_u_27.AbsoluteSize
		local v92 = p90.d / 2
		local v93 = {}
		local v94 = p90.x
		local v95 = v91.X - v92
		v93.x = math.clamp(v94, v92, v95)
		local v96 = p90.y
		local v97 = v91.Y - v92
		v93.y = math.clamp(v96, v92, v97)
		v93.d = p90.d
		return v93
	end
	local function v_u_113() -- name: paintHandles
		-- upvalues: (copy) v_u_28, (copy) v_u_29, (ref) v_u_31, (copy) v_u_14, (ref) v_u_32, (ref) v_u_34, (ref) v_u_33
		for v99, v100 in v_u_28 do
			local v101 = v_u_29[v99]
			v100.frame.Visible = v101 ~= nil
			if v101 then
				v100.frame.Position = UDim2.fromOffset(v101.x, v101.y)
				v100.frame.Size = UDim2.fromOffset(v101.d, v101.d)
			end
			local v102 = v99 == v_u_31
			local v103 = v100.stroke
			local v104
			if v102 then
				v104 = v_u_14.Accent
			else
				v104 = v_u_14.Text
			end
			v103.Color = v104
			v100.stroke.Transparency = v102 and 0 or 0.35
			v100.stroke.Thickness = v102 and 3 or 2
			v100.knob.Visible = v102
			v100.frame.BackgroundTransparency = v102 and 0.8 or 0.9
		end
		if v_u_32 then
			local v105 = v_u_31
			if v105 then
				v105 = v_u_29[v_u_31]
			end
			if os.clock() < v_u_34 then
				v_u_32.Text = v_u_33
				v_u_32.TextColor3 = v_u_14.Danger
				return
			end
			local v106 = v_u_32
			local v107
			if v105 then
				local v108 = string.format
				local v109 = v_u_28[v_u_31].spec.label
				local v110 = v105.d
				v107 = v108("%s  \194\183  %d", v109, (math.floor(v110)))
			else
				v107 = "TAP A BUTTON"
			end
			v106.Text = v107
			local v111 = v_u_32
			local v112
			if v105 then
				v112 = v_u_14.Text
			else
				v112 = v_u_14.TextDim
			end
			v111.TextColor3 = v112
		end
	end
	local function v_u_122(p114, p115) -- name: tryMove
		-- upvalues: (copy) v_u_98, (copy) v_u_89, (ref) v_u_33, (ref) v_u_34, (copy) v_u_113, (copy) v_u_29, (copy) v_u_53
		local v116 = v_u_98
		local v117 = {}
		local v118 = p115.x / 8 + 0.5
		v117.x = math.floor(v118) * 8
		local v119 = p115.y / 8 + 0.5
		v117.y = math.floor(v119) * 8
		v117.d = p115.d
		local v120 = v116(v117)
		if v_u_89(p114, v120) then
			v_u_29[p114] = v120
			v_u_53(p114)
			v_u_34 = 0
			v_u_113()
			return true
		else
			local v121 = os.clock() + 1.2
			v_u_33 = "TOO CLOSE"
			v_u_34 = v121
			v_u_113()
			return false
		end
	end
	local function v_u_131(p123, p124) -- name: tryResize
		-- upvalues: (copy) v_u_29, (copy) v_u_98, (copy) v_u_89, (ref) v_u_33, (ref) v_u_34, (copy) v_u_113, (copy) v_u_53
		local v125 = v_u_29[p123]
		if not v125 then
			return false
		end
		local v126 = p124 / 4 + 0.5
		local v127 = math.floor(v126) * 4
		local v128 = math.clamp(v127, 52, 170)
		local v129 = v_u_98({
			["x"] = v125.x,
			["y"] = v125.y,
			["d"] = v128
		})
		if v_u_89(p123, v129) then
			v_u_29[p123] = v129
			v_u_53(p123)
			v_u_113()
			return true
		end
		local v130 = os.clock() + 1.2
		v_u_33 = "NO ROOM"
		v_u_34 = v130
		v_u_113()
		return false
	end
	local v_u_132 = nil
	local v_u_133 = nil
	local function v_u_207() -- name: build
		-- upvalues: (copy) v_u_16, (ref) v_u_26, (copy) v_u_11, (copy) v_u_14, (ref) v_u_27, (ref) v_u_31, (copy) v_u_113, (copy) v_u_15, (ref) v_u_3, (ref) v_u_17, (copy) v_u_64, (ref) v_u_9, (copy) v_u_12, (copy) v_u_28, (ref) v_u_132, (copy) v_u_29, (copy) p_u_10, (ref) v_u_59, (ref) v_u_1, (ref) v_u_32, (copy) v_u_131, (copy) v_u_58, (ref) v_u_133, (ref) v_u_6, (copy) v_u_122
		local v134 = Instance.new("ScreenGui")
		v134.Name = "TR_TouchEditor"
		v134.ResetOnSpawn = false
		v134.IgnoreGuiInset = true
		v134.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
		v134.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		v134.DisplayOrder = 60
		v134.Enabled = false
		v134.Parent = v_u_16
		v_u_26 = v134
		local v_u_135 = v_u_11.new("TextButton", {
			["Name"] = "Root",
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.72,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = v_u_14.Void,
			["Parent"] = v134
		})
		v_u_27 = v_u_135
		local v136 = v_u_11.new("Frame", {
			["Name"] = "Grid",
			["Size"] = nil,
			["ClipsDescendants"] = true,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v_u_135
		})
		for v137 = 1, 60 do
			v_u_11.new("Frame", {
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.94,
				["BorderSizePixel"] = 0,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(v137 * 8 * 4, 0),
				["Size"] = UDim2.new(0, 1, 1, 0),
				["BackgroundColor3"] = v_u_14.Text,
				["Parent"] = v136
			})
			v_u_11.new("Frame", {
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.94,
				["BorderSizePixel"] = 0,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(0, v137 * 8 * 4),
				["Size"] = UDim2.new(1, 0, 0, 1),
				["BackgroundColor3"] = v_u_14.Text,
				["Parent"] = v136
			})
		end
		v_u_135.Activated:Connect(function()
			-- upvalues: (ref) v_u_31, (ref) v_u_113
			v_u_31 = nil
			v_u_113()
		end)
		local v_u_138 = v_u_11.new("Frame", {
			["Name"] = "HotbarZone",
			["BackgroundColor3"] = v_u_14.Text,
			["BackgroundTransparency"] = 0.9,
			["ZIndex"] = 2,
			v_u_11.Corner(10),
			v_u_11.Stroke(v_u_14.Text, 1, 0.7),
			["Parent"] = v_u_135
		})
		v_u_11.new("TextLabel", {
			["Size"] = nil,
			["Text"] = "HOTBAR",
			["FontFace"] = nil,
			["TextSize"] = 13,
			["TextColor3"] = nil,
			["ZIndex"] = 2,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["FontFace"] = v_u_15.Heavy,
			["TextColor3"] = v_u_14.TextDim,
			["Parent"] = v_u_138
		})
		v_u_3.Heartbeat:Connect(function()
			-- upvalues: (ref) v_u_17, (ref) v_u_64, (copy) v_u_138
			if v_u_17 then
				local v139, v140 = v_u_64()
				v_u_138.Position = UDim2.fromOffset(v139.X, v139.Y)
				v_u_138.Size = UDim2.fromOffset(v140.X, v140.Y)
			end
		end)
		for _, v_u_141 in v_u_9 do
			local v142 = v_u_11.new("TextButton", {
				["Name"] = v_u_141.name,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["BackgroundColor3"] = v_u_14.Accent,
				["BackgroundTransparency"] = 0.9,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["ZIndex"] = 5,
				v_u_11.Corner(v_u_12.Radius.Pill),
				["Parent"] = v_u_135
			})
			local v143 = v_u_11.Stroke(v_u_14.Text, 2, 0.35)
			v143.Parent = v142
			local v144 = v_u_11.new("TextLabel", {
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 12,
				["TextColor3"] = nil,
				["ZIndex"] = 5,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 1, 4),
				["Size"] = UDim2.fromOffset(120, 16),
				["Text"] = v_u_141.label,
				["FontFace"] = v_u_15.Heavy,
				["TextColor3"] = v_u_14.TextDim,
				["Parent"] = v142
			})
			v_u_11.TextStroke(v_u_14.Void, 1, 0.3).Parent = v144
			local v145 = v_u_11.new("TextButton", {
				["Name"] = "Resize",
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.854, 0.854),
				["Size"] = UDim2.fromOffset(30, 30),
				["BackgroundColor3"] = v_u_14.Accent,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["Visible"] = false,
				["ZIndex"] = 7,
				v_u_11.Corner(v_u_12.Radius.Pill),
				v_u_11.Stroke(v_u_14.Text, 2, 0),
				["Parent"] = v142
			})
			v_u_28[v_u_141.name] = {
				["spec"] = v_u_141,
				["frame"] = v142,
				["stroke"] = v143,
				["label"] = v144,
				["knob"] = v145
			}
			local function v_u_155(p146, p147) -- name: begin
				-- upvalues: (ref) v_u_132, (ref) v_u_29, (copy) v_u_141, (ref) v_u_31, (ref) v_u_27, (ref) v_u_11, (ref) v_u_113, (ref) p_u_10
				local v148 = p146.UserInputType
				if (v148 == Enum.UserInputType.Touch or v148 == Enum.UserInputType.MouseButton1) and (p146.UserInputState == Enum.UserInputState.Begin and not v_u_132) then
					local v149 = v_u_29[v_u_141.name]
					if v149 then
						v_u_31 = v_u_141.name
						local v150 = v_u_27
						local v151
						if p146.UserInputType == Enum.UserInputType.Touch then
							v151 = Vector2.new(p146.Position.X, p146.Position.Y) - v150.AbsolutePosition
						else
							v151 = v_u_11.PointerAbs() - v150.AbsolutePosition
						end
						local v152 = v151 - Vector2.new(v149.x, v149.y)
						local v153 = {
							["input"] = p146,
							["name"] = v_u_141.name,
							["mode"] = p147,
							["offset"] = v152,
							["d0"] = v149.d
						}
						local v154 = v152.Magnitude
						v153.dist0 = math.max(v154, 8)
						v_u_132 = v153
						v_u_113()
						p_u_10.Sounds.Play("Select")
					end
				else
					return
				end
			end
			v142.InputBegan:Connect(function(p156)
				-- upvalues: (copy) v_u_155
				v_u_155(p156, "move")
			end)
			v145.InputBegan:Connect(function(p157)
				-- upvalues: (copy) v_u_155
				v_u_155(p157, "resize")
			end)
		end
		local v_u_158 = v_u_11.new("Frame", {
			["Name"] = "Toolbar",
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Size"] = UDim2.fromOffset(476, 44),
			["BackgroundColor3"] = v_u_14.Panel,
			["BackgroundTransparency"] = 0.08,
			["ZIndex"] = 10,
			v_u_11.Corner(14),
			v_u_11.Stroke(v_u_14.Stroke, 1, 0.88),
			v_u_11.Padding(0, 4),
			v_u_11.List(Enum.FillDirection.Horizontal, 4, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
			["Parent"] = v_u_135
		})
		v_u_59 = v_u_158
		local v_u_159 = v_u_11.new("UIScale", {
			["Parent"] = v_u_158
		})
		local function v175() -- name: placeBar
			-- upvalues: (copy) v_u_135, (ref) v_u_1, (copy) v_u_159, (copy) v_u_158
			local v160 = v_u_135.AbsoluteSize
			local v161 = v_u_1.TopbarInset
			local v162 = v160.X >= 1000 and 1.15 or 1
			local v163 = v162 * 44 / 2 + 8
			local v164 = v160.X - 12
			local v165
			if v161.Height > 0 then
				v165 = v161.Min.X + 8
				v163 = v161.Min.Y + v161.Height / 2
				local v166 = v161.Max.X - 8
				v164 = math.min(v164, v166)
			else
				v165 = 12
			end
			local v167 = (v164 - v165) / 476
			local v168 = math.min(v162, v167)
			if v168 >= 0.8 then
				v_u_159.Scale = v168
				v_u_158.Position = UDim2.fromOffset(v165, v163)
			else
				local v169 = (v160.X - 24) / 476
				local v170 = math.min(v162, v169)
				v_u_159.Scale = v170
				local v171 = v_u_158
				local v172 = UDim2.fromOffset
				local v173 = (v160.X - v170 * 476) / 2
				local v174 = v163 + 22
				v171.Position = v172(v173, math.max(v174, 44) + 6 + v170 * 44 / 2)
			end
		end
		v175()
		v_u_135:GetPropertyChangedSignal("AbsoluteSize"):Connect(v175)
		v_u_1:GetPropertyChangedSignal("TopbarInset"):Connect(v175)
		v_u_32 = v_u_11.new("TextLabel", {
			["Name"] = "Selected",
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 14,
			["TextColor3"] = nil,
			["TextTruncate"] = nil,
			["LayoutOrder"] = 1,
			["ZIndex"] = 10,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(116, 36),
			["FontFace"] = v_u_15.Heavy,
			["TextColor3"] = v_u_14.TextDim,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v_u_158
		})
		local function v180(p176, p177, p178, p_u_179) -- name: stepBtn
			-- upvalues: (ref) v_u_11, (ref) v_u_14, (copy) v_u_158, (ref) v_u_31, (ref) v_u_29, (ref) v_u_131, (ref) p_u_10
			v_u_11.IconButton({
				["Name"] = nil,
				["IconName"] = nil,
				["IconScale"] = 0.42,
				["Size"] = nil,
				["Color"] = nil,
				["Transparency"] = 0.1,
				["LayoutOrder"] = nil,
				["ZIndex"] = 10,
				["Parent"] = nil,
				["Name"] = p176,
				["IconName"] = p177,
				["Size"] = UDim2.fromOffset(36, 36),
				["Color"] = v_u_14.Raised,
				["LayoutOrder"] = p178,
				["Parent"] = v_u_158
			}).Activated:Connect(function()
				-- upvalues: (ref) v_u_31, (ref) v_u_29, (ref) v_u_131, (copy) p_u_179, (ref) p_u_10
				if v_u_31 and v_u_29[v_u_31] then
					if v_u_131(v_u_31, v_u_29[v_u_31].d + p_u_179) then
						p_u_10.Sounds.Play("Tick", {
							["pitch"] = p_u_179 > 0 and 1.15 or 0.9
						})
						return
					end
					p_u_10.Sounds.Play("Error")
				end
			end)
		end
		v180("Smaller", "minus", 2, -8)
		v180("Bigger", "plus", 3, 8)
		v_u_11.new("Frame", {
			["Name"] = "Gap",
			["Size"] = nil,
			["LayoutOrder"] = 4,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(6, 1),
			["Parent"] = v_u_158
		})
		local function v187(p181, p182, p183, p184, p185, p186) -- name: action
			-- upvalues: (ref) v_u_11, (copy) v_u_158
			v_u_11.Button({
				["Name"] = nil,
				["Text"] = nil,
				["TextSize"] = 15,
				["Style"] = nil,
				["Radius"] = 10,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["ZIndex"] = 10,
				["Parent"] = nil,
				["Name"] = p181,
				["Text"] = p182,
				["Style"] = p183,
				["Size"] = UDim2.fromOffset(p184, 36),
				["LayoutOrder"] = p185,
				["Parent"] = v_u_158
			}).Activated:Connect(p186)
		end
		v187("Reset", "RESET", "Dark", 80, 5, function()
			-- upvalues: (ref) v_u_9, (ref) v_u_16, (ref) v_u_58, (ref) v_u_29, (ref) v_u_113
			for _, v188 in v_u_9 do
				local v189 = v_u_16:FindFirstChild(v188.gui)
				if not (v189 and v189:IsA("ScreenGui")) then
					v189 = nil
				end
				if not v189 then
					continue
				end
				v189:SetAttribute("Override_" .. v188.name, nil)
			end
			task.wait()
			task.wait()
			v_u_58()
			for v190 in v_u_29 do
				local v191 = v_u_29[v190]
				local v192 = v_u_29[v190].x / 8 + 0.5
				v191.x = math.floor(v192) * 8
				local v193 = v_u_29[v190]
				local v194 = v_u_29[v190].y / 8 + 0.5
				v193.y = math.floor(v194) * 8
			end
			v_u_113()
		end)
		v187("Cancel", "CANCEL", "Dark", 90, 6, function()
			-- upvalues: (ref) v_u_133
			v_u_133(false)
		end)
		v187("Save", "SAVE", "Primary", 80, 7, function()
			-- upvalues: (ref) v_u_133
			v_u_133(true)
		end)
		v_u_6.InputChanged:Connect(function(p195)
			-- upvalues: (ref) v_u_132, (ref) v_u_27, (ref) v_u_11, (ref) v_u_29, (ref) v_u_122, (ref) v_u_131
			local v196 = v_u_132
			if v196 then
				if v196.input.UserInputType == Enum.UserInputType.Touch then
					if p195 ~= v196.input then
						return
					end
				elseif p195.UserInputType ~= Enum.UserInputType.MouseMovement then
					return
				end
				local v197 = v196.input
				local v198 = v_u_27
				local v199
				if v197.UserInputType == Enum.UserInputType.Touch then
					v199 = Vector2.new(v197.Position.X, v197.Position.Y) - v198.AbsolutePosition
				else
					v199 = v_u_11.PointerAbs() - v198.AbsolutePosition
				end
				local v200 = v_u_29[v196.name]
				if v200 then
					if v196.mode == "move" then
						v_u_122(v196.name, {
							["x"] = v199.X - v196.offset.X,
							["y"] = v199.Y - v196.offset.Y,
							["d"] = v200.d
						})
					else
						local v201 = (v199 - Vector2.new(v200.x, v200.y)).Magnitude
						v_u_131(v196.name, v196.d0 * v201 / v196.dist0)
					end
				else
					return
				end
			else
				return
			end
		end)
		local function v204(p202) -- name: ended
			-- upvalues: (ref) v_u_132
			local v203 = v_u_132
			if v203 then
				if v203.input.UserInputType == Enum.UserInputType.Touch then
					if p202 ~= v203.input then
						return
					end
				elseif p202.UserInputType ~= Enum.UserInputType.MouseButton1 then
					return
				end
				v_u_132 = nil
			end
		end
		v_u_6.InputEnded:Connect(v204)
		v_u_6.TouchEnded:Connect(v204)
		v_u_3.Heartbeat:Connect(function()
			-- upvalues: (ref) v_u_17, (ref) v_u_132, (ref) v_u_29, (ref) v_u_58, (ref) v_u_113
			if v_u_17 then
				local v205 = v_u_132
				if v205 then
					v205 = v_u_132.name
				end
				local v206
				if v205 then
					v206 = v_u_29[v205]
				else
					v206 = v205
				end
				v_u_58()
				if v205 and v206 then
					v_u_29[v205] = v206
				end
				v_u_113()
			end
		end)
	end
	local function v_u_214() -- name: open
		-- upvalues: (ref) v_u_17, (ref) v_u_26, (copy) v_u_207, (ref) v_u_60, (ref) v_u_1, (copy) p_u_10, (ref) v_u_8, (ref) v_u_5, (ref) v_u_4, (copy) v_u_30, (ref) v_u_9, (copy) v_u_16, (ref) v_u_31, (ref) v_u_34, (copy) v_u_29, (copy) v_u_58, (copy) v_u_113
		if not v_u_17 then
			if not v_u_26 then
				v_u_207()
			end
			v_u_17 = true
			v_u_60 = v_u_1.TopbarInset.Min.X
			p_u_10.MenuManager.CloseAll(true)
			p_u_10.MenuManager.PushMouse("TouchEditor")
			p_u_10.SetHudHidden("TouchEditor", true)
			if p_u_10.TopbarSettings and p_u_10.TopbarSettings.SetHidden then
				p_u_10.TopbarSettings.SetHidden("TouchEditor", true)
			end
			if not v_u_8 then
				local v_u_208 = {}
				local function v211()
					-- upvalues: (ref) v_u_5, (copy) v_u_208, (ref) v_u_4
					local v209 = v_u_5:FindFirstChildOfClass("ChatWindowConfiguration")
					local v210 = v_u_5:FindFirstChildOfClass("ChatInputBarConfiguration")
					if v209 then
						v_u_208.window = v209.Enabled
						v209.Enabled = false
					end
					if v210 then
						v_u_208.bar = v210.Enabled
						v210.Enabled = false
					end
					v_u_208.core = v_u_4:GetCoreGuiEnabled(Enum.CoreGuiType.Chat)
					v_u_4:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, false)
				end
				pcall(v211)
				v_u_8 = v_u_208
			end
			table.clear(v_u_30)
			for _, v212 in v_u_9 do
				local v213 = v_u_16:FindFirstChild(v212.gui)
				if not (v213 and v213:IsA("ScreenGui")) then
					v213 = nil
				end
				if not v213 then
					continue
				end
				v_u_30[v212.name] = v213:GetAttribute("Override_" .. v212.name)
				v213:SetAttribute("EditPreview", true)
			end
			v_u_31 = nil
			v_u_34 = 0
			v_u_26.Enabled = true
			task.wait()
			task.wait()
			table.clear(v_u_29)
			v_u_58()
			v_u_113()
			p_u_10.Sounds.Play("Open")
		end
	end
	v_u_133 = function(p215)
		-- upvalues: (ref) v_u_17, (ref) v_u_132, (ref) v_u_9, (copy) v_u_16, (copy) v_u_30, (ref) v_u_26, (copy) p_u_10, (ref) v_u_8, (ref) v_u_5, (ref) v_u_4, (copy) v_u_13, (copy) v_u_24
		if v_u_17 then
			v_u_132 = nil
			local v_u_216 = {}
			for _, v217 in v_u_9 do
				local v218 = v_u_16:FindFirstChild(v217.gui)
				if not (v218 and v218:IsA("ScreenGui")) then
					v218 = nil
				end
				if not v218 then
					continue
				end
				local v219 = v218:GetAttribute("Override_" .. v217.name)
				v_u_216[v217.name] = type(v219) ~= "string" and "" or v219
				if not p215 then
					v218:SetAttribute("Override_" .. v217.name, v_u_30[v217.name])
				end
				v218:SetAttribute("EditPreview", nil)
			end
			v_u_26.Enabled = false
			v_u_17 = false
			p_u_10.MenuManager.PopMouse("TouchEditor")
			p_u_10.SetHudHidden("TouchEditor", false)
			if p_u_10.TopbarSettings and p_u_10.TopbarSettings.SetHidden then
				p_u_10.TopbarSettings.SetHidden("TouchEditor", false)
			end
			local v_u_220 = v_u_8
			if v_u_220 then
				v_u_8 = nil
				local function v223()
					-- upvalues: (ref) v_u_5, (copy) v_u_220, (ref) v_u_4
					local v221 = v_u_5:FindFirstChildOfClass("ChatWindowConfiguration")
					local v222 = v_u_5:FindFirstChildOfClass("ChatInputBarConfiguration")
					if v221 and v_u_220.window ~= nil then
						v221.Enabled = v_u_220.window
					end
					if v222 and v_u_220.bar ~= nil then
						v222.Enabled = v_u_220.bar
					end
					if v_u_220.core ~= nil then
						v_u_4:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, v_u_220.core)
					end
				end
				pcall(v223)
			end
			if p215 then
				p_u_10.Sounds.Play("Equip")
				local v_u_224 = v_u_13.Profile.settings
				if type(v_u_224) ~= "table" then
					v_u_224 = {}
					v_u_13.Profile.settings = v_u_224
				end
				task.spawn(function()
					-- upvalues: (ref) v_u_9, (copy) v_u_216, (ref) v_u_13, (ref) p_u_10, (ref) v_u_224, (ref) v_u_24
					local v225 = true
					for _, v226 in v_u_9 do
						local v227 = v_u_216[v226.name] or ""
						local v228 = v226.name
						local v229 = v_u_13.Profile
						if v229 then
							v229 = v_u_13.Profile.settings
						end
						local v230
						if type(v229) == "table" then
							v230 = v229["touch_" .. v228]
						else
							v230 = false
						end
						if (type(v230) ~= "string" and "" or v230) == v227 then
							continue
						end
						if p_u_10.ProfileAction("SetSetting", "touch_" .. v226.name, v227) then
							v_u_224["touch_" .. v226.name] = v227
						else
							v225 = false
						end
					end
					p_u_10.Toast(v225 and "Controls saved" or "Couldn\'t save every button", v225 and "info" or "error")
					v_u_24()
				end)
			else
				p_u_10.Sounds.Play("Close")
			end
		else
			return
		end
	end
	v_u_13.PlayerStateChanged:Connect(function()
		-- upvalues: (ref) v_u_17, (ref) v_u_133
		if v_u_17 then
			v_u_133(false)
		end
	end)
	function p_u_10.OpenTouchEditor()
		-- upvalues: (copy) v_u_214
		task.spawn(v_u_214)
	end
	function p_u_10.Debug.touchEditor(p231, p232, p233, p234)
		-- upvalues: (copy) v_u_214, (ref) v_u_133, (copy) v_u_29, (copy) v_u_122, (copy) v_u_131, (ref) v_u_59, (ref) v_u_1, (ref) v_u_17, (ref) v_u_31, (ref) v_u_32
		if p231 == "open" then
			task.spawn(v_u_214)
		elseif p231 == "save" then
			v_u_133(true)
		elseif p231 == "cancel" then
			v_u_133(false)
		elseif p231 == "move" and (type(p232) == "string" and v_u_29[p232]) then
			v_u_122(p232, {
				["x"] = tonumber(p233) or v_u_29[p232].x,
				["y"] = tonumber(p234) or v_u_29[p232].y,
				["d"] = v_u_29[p232].d
			})
		elseif p231 == "size" and type(p232) == "string" then
			v_u_131(p232, tonumber(p233) or 80)
		end
		local v235 = {}
		for v236, v237 in v_u_29 do
			v235[v236] = string.format("%d,%d,%d", v237.x, v237.y, v237.d)
		end
		local v238 = v_u_59
		local v239 = v238 and {
			["x"] = v238.AbsolutePosition.X,
			["y"] = v238.AbsolutePosition.Y,
			["w"] = v238.AbsoluteSize.X,
			["h"] = v238.AbsoluteSize.Y
		} or nil
		local v240 = v_u_1.TopbarInset
		local v241 = {
			["editing"] = v_u_17,
			["rects"] = v235,
			["selected"] = v_u_31,
			["bar"] = v239,
			["inset"] = {
				v240.Min.X,
				v240.Min.Y,
				v240.Max.X,
				v240.Max.Y
			}
		}
		local v242 = v_u_32
		if v242 then
			v242 = v_u_32.Text
		end
		v241.label = v242
		return v241
	end
end
return v7