local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
local v5 = {}
local v_u_6 = {
	{
		["id"] = "Classic",
		["chip"] = "NOW"
	},
	{
		["id"] = "Pitch",
		["chip"] = "A"
	},
	{
		["id"] = "Builds",
		["chip"] = "B"
	},
	{
		["id"] = "Briefing",
		["chip"] = "C"
	}
}
local v7 = Color3.fromRGB
local v_u_8 = {
	["bow"] = v7(56, 189, 248),
	["gun"] = v7(251, 146, 60),
	["melee"] = v7(248, 113, 113),
	["throwable"] = v7(167, 139, 250),
	["utility"] = v7(250, 204, 21),
	["healing"] = v7(74, 222, 128),
	["armor"] = v7(148, 197, 255)
}
local v_u_9 = {
	["bronze_sword,short_bow,bandage|hide_armor"] = {
		["name"] = "ALL-ROUNDER",
		["line"] = "Sword, bow and armor.\nReady for anything."
	},
	["short_bow,throwing_knives,smoke_bomb,bandage|hide_armor"] = {
		["name"] = "ARCHER",
		["line"] = "Bow, knives and armor.\nFight from range."
	},
	["war_club,short_bow,smoke_bomb,bandage|hide_armor"] = {
		["name"] = "BRAWLER",
		["line"] = "Hammer, bow and armor.\nWin up close."
	},
	["bronze_sword,throwing_knives,sling,bandage,smoke_bomb|hide_armor"] = {
		["name"] = "DUELIST",
		["line"] = "Sword, knives and smoke.\nOutplay them."
	},
	["short_bow,war_club,bandage|hide_armor"] = {
		["name"] = "HUNTER",
		["line"] = "Bow and hammer.\nHit hard at any range."
	}
}
function v5.Init(p_u_10) -- name: Init
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_3, (copy) v_u_8, (copy) v_u_9, (copy) v_u_6, (copy) v_u_4
	local v_u_11 = p_u_10.UI
	local v_u_12 = p_u_10.Theme
	local v_u_13 = p_u_10.State
	local v_u_14 = p_u_10.MenuManager
	local v_u_15 = p_u_10.WeaponInfo
	local v_u_16 = p_u_10.WeaponIcon
	local v_u_17 = p_u_10.Portraits
	local v_u_18 = v_u_12.Colors
	local v_u_19 = v_u_12.Fonts
	local v_u_20 = v_u_1.LocalPlayer
	local v_u_21 = p_u_10.LobbyHud
	if v_u_21 then
		local v_u_22 = v_u_21.PlayButton
		local v23 = require(v_u_2:WaitForChild("Shared"):WaitForChild("Config"))
		local v_u_24 = {}
		v_u_14.Changed:Connect(function(p25)
			-- upvalues: (copy) v_u_13, (copy) v_u_20, (copy) v_u_24, (copy) p_u_10
			if p25 and (p25 ~= "Welcome" and not v_u_13.InMatch()) and (v_u_20:GetAttribute("LoadingShownMs") ~= nil and not v_u_24.Menu) then
				if v_u_13.Mock then
					return
				end
				if p_u_10.Remotes.Fire("AnalyticsReport", "Menu", nil) then
					v_u_24.Menu = true
				end
			end
		end)
		local v26 = v_u_3:IsStudio() or game.PlaceId == v23.STAGING_PLACE_ID
		local v_u_27 = "Builds"
		local v_u_28 = v_u_11.new("Frame", {
			["Name"] = "Welcome",
			["Size"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = p_u_10.Canvas.Menus
		})
		local v_u_29 = v_u_11.new("Frame", {
			["Name"] = "WelcomeDim",
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 1,
			["Visible"] = false,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = v_u_18.Void,
			["Parent"] = p_u_10.Canvas.Backdrop
		})
		local v_u_30 = v_u_11.new("Frame", {
			["Name"] = "Card",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(560, 360),
			["Parent"] = v_u_28
		})
		local v_u_31 = v_u_11.new("UIScale", {
			["Parent"] = v_u_30
		})
		v_u_11.DropShadow(v_u_30, 18, 8, 0.45)
		local v_u_32 = v_u_11.Panel({
			["Name"] = "Panel",
			["Size"] = nil,
			["BackgroundTransparency"] = 0.04,
			["StrokeColor"] = nil,
			["StrokeTransparency"] = 0.55,
			["StrokeThickness"] = 1.5,
			["Radius"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["StrokeColor"] = v_u_18.Accent,
			["Radius"] = UDim.new(0, 18),
			["Parent"] = v_u_30
		})
		local v_u_33 = nil
		local v_u_34 = nil
		local v_u_35 = false
		local v_u_36 = 0
		local v_u_37 = false
		local v_u_38 = false
		local v_u_39 = false
		local v_u_40 = 0
		local v_u_41 = false
		local v_u_42 = 0
		local v_u_43 = nil
		local function v_u_46() -- name: fight
			-- upvalues: (ref) v_u_39, (ref) v_u_37, (ref) v_u_38, (ref) v_u_41, (copy) p_u_10, (ref) v_u_33, (copy) v_u_14
			if not v_u_39 and v_u_37 then
				v_u_39 = true
				v_u_38 = true
				v_u_41 = false
				p_u_10.Sounds.Play("Queue_Join")
				v_u_33.fight:SetText("STARTING\226\128\166")
				task.spawn(function()
					-- upvalues: (ref) v_u_33, (ref) p_u_10, (ref) v_u_39, (ref) v_u_14, (ref) v_u_38
					local v44 = os.clock()
					while v_u_33 and (v_u_33.selecting and os.clock() - v44 < 1.5) do
						task.wait()
					end
					local v45 = p_u_10.QueueAction("FirstMatch")
					v_u_39 = false
					if v45 then
						if v_u_14.IsOpen("Welcome") then
							v_u_14.Close("Welcome", nil)
							return
						end
					else
						v_u_38 = false
						if v_u_33 then
							v_u_33.fight:SetText("FIGHT")
						end
					end
				end)
			end
		end
		local function v_u_47() -- name: explore
			-- upvalues: (ref) v_u_39, (ref) v_u_37, (ref) v_u_38, (ref) v_u_41, (copy) p_u_10, (copy) v_u_14
			if not v_u_39 and v_u_37 then
				v_u_38 = true
				v_u_41 = false
				p_u_10.Sounds.Play("Click")
				if v_u_14.IsOpen("Welcome") then
					v_u_14.Close("Welcome", nil)
				end
				task.spawn(p_u_10.QueueAction, "Explore")
			end
		end
		local function v_u_48() -- name: customize
			-- upvalues: (ref) v_u_39, (ref) v_u_37, (ref) v_u_41, (ref) v_u_42, (copy) v_u_14
			if not v_u_39 and v_u_37 then
				v_u_41 = true
				v_u_42 = 0
				v_u_14.Open("Loadout")
				if not v_u_14.IsOpen("Loadout") then
					v_u_41 = false
				end
			end
		end
		local function v_u_58(p_u_49, p_u_50, p_u_51, p52) -- name: stacker
			-- upvalues: (copy) v_u_11
			local v_u_53 = p52
			return {
				["row"] = function(p54, p55) -- name: row
					-- upvalues: (ref) v_u_53, (ref) v_u_11, (copy) p_u_50, (copy) p_u_51, (copy) p_u_49
					v_u_53 = v_u_53 + (p55 or 0)
					local v56 = v_u_11.new("Frame", {
						["Position"] = UDim2.fromOffset(p_u_50, v_u_53),
						["Size"] = UDim2.fromOffset(p_u_51, p54),
						["Parent"] = p_u_49
					})
					v_u_53 = v_u_53 + p54
					return v56
				end,
				["skip"] = function(p57) -- name: skip
					-- upvalues: (ref) v_u_53
					v_u_53 = v_u_53 + p57
				end,
				["y"] = function() -- name: y
					-- upvalues: (ref) v_u_53
					return v_u_53
				end
			}
		end
		local function v_u_70(p59, p60, p61, p62, p63, p64) -- name: heading
			-- upvalues: (copy) v_u_11, (copy) v_u_19, (copy) v_u_18
			v_u_11.new("TextLabel", {
				["Name"] = "Overline",
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = nil,
				["TextColor3"] = nil,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Text"] = p60,
				["FontFace"] = v_u_19.Heavy,
				["TextSize"] = v_u_11.Compact and 18 or 16,
				["TextColor3"] = v_u_18.Accent,
				["Parent"] = p59.row(v_u_11.Compact and 20 or 18)
			})
			v_u_11.new("TextLabel", {
				["Name"] = "Title",
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = nil,
				["TextColor3"] = nil,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Text"] = p61,
				["FontFace"] = v_u_19.Display,
				["TextSize"] = p62,
				["TextColor3"] = v_u_18.Text,
				["Parent"] = p59.row(p62 + 4, 6)
			})
			if p63 then
				local v65 = v_u_11.Compact and 21 or 19
				local v66 = v_u_11.new
				local v67 = {
					["Name"] = "Blurb",
					["Size"] = nil,
					["Text"] = nil,
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextWrapped"] = true,
					["Parent"] = nil,
					["Size"] = UDim2.fromScale(1, 1),
					["Text"] = p63,
					["FontFace"] = v_u_19.Medium,
					["TextSize"] = v65,
					["TextColor3"] = v_u_18.TextDim
				}
				local v68 = p59.row
				local v69 = v65 * 1.3 * (p64 or 1)
				v67.Parent = v68(math.ceil(v69), 6)
				v66("TextLabel", v67)
			end
		end
		local function v_u_74(p71) -- name: fightButton
			-- upvalues: (copy) v_u_11, (copy) v_u_18
			local v72 = v_u_11.Button
			local v73 = {
				["Name"] = "Fight",
				["Text"] = "FIGHT",
				["TextSize"] = nil,
				["Style"] = "Primary",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Radius"] = 16,
				["Icon"] = nil,
				["LayoutOrder"] = nil,
				["Sound"] = false,
				["Parent"] = nil,
				["TextSize"] = p71.TextSize,
				["AnchorPoint"] = p71.AnchorPoint,
				["Position"] = p71.Position,
				["Size"] = p71.Size,
				["Icon"] = v_u_11.Image(v_u_11.Assets.Icons.CrossedArrows, {
					["Size"] = UDim2.fromOffset(36, 34),
					["ImageColor3"] = v_u_18.Text
				}),
				["LayoutOrder"] = p71.LayoutOrder,
				["Parent"] = p71.Parent
			}
			return v72(v73)
		end
		local function v_u_81(p75) -- name: customizeButton
			-- upvalues: (copy) v_u_11, (copy) v_u_18, (copy) v_u_48
			local v76 = v_u_11.Button
			local v77 = {
				["Name"] = "Customize",
				["Text"] = "CUSTOMIZE",
				["TextSize"] = nil,
				["Style"] = "Dark",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Radius"] = 14,
				["Icon"] = nil,
				["Parent"] = nil,
				["TextSize"] = p75.TextSize,
				["AnchorPoint"] = p75.AnchorPoint,
				["Position"] = p75.Position,
				["Size"] = p75.Size
			}
			local v78 = v_u_11.Icon
			local v79 = p75.TextSize * 0.95
			v77.Icon = v78("pencil", math.floor(v79), v_u_18.Text)
			v77.Parent = p75.Parent
			local v80 = v76(v77)
			v80.Activated:Connect(v_u_48)
			return v80
		end
		local function v_u_91(p82) -- name: exploreLink
			-- upvalues: (copy) v_u_11, (copy) v_u_19, (copy) v_u_18, (copy) v_u_12, (copy) v_u_47
			local v_u_83 = v_u_11.new("TextButton", {
				["Name"] = "Explore",
				["BackgroundTransparency"] = 1,
				["Text"] = "Explore the lobby first",
				["FontFace"] = nil,
				["TextColor3"] = nil,
				["AutoButtonColor"] = false,
				["FontFace"] = v_u_19.Bold,
				["TextColor3"] = v_u_18.TextDim
			})
			for v84, v85 in p82 do
				v_u_83[v84] = v85
			end
			v_u_83.MouseEnter:Connect(function()
				-- upvalues: (ref) v_u_11, (copy) v_u_83, (ref) v_u_12, (ref) v_u_18
				v_u_11.Tween(v_u_83, v_u_12.Tween.Fast, {
					["TextColor3"] = v_u_18.Text
				})
			end)
			v_u_83.MouseLeave:Connect(function()
				-- upvalues: (ref) v_u_11, (copy) v_u_83, (ref) v_u_12, (ref) v_u_18
				v_u_11.Tween(v_u_83, v_u_12.Tween.Fast, {
					["TextColor3"] = v_u_18.TextDim
				})
			end)
			v_u_83.Activated:Connect(v_u_47)
			if v_u_11.Touch then
				local v86 = v_u_11.new
				local v87 = {
					["Name"] = "Hit",
					["Text"] = "",
					["BackgroundTransparency"] = 1,
					["AutoButtonColor"] = false,
					["Selectable"] = false,
					["Size"] = nil,
					["Parent"] = nil
				}
				local v88 = UDim2.new
				local v89 = v_u_11.Scale
				local v90 = 46 / math.max(v89, 0.1)
				v87.Size = v88(1, 0, 0, (math.ceil(v90)))
				v87.Parent = v_u_83
				v86("TextButton", v87).Activated:Connect(v_u_47)
			end
			return v_u_83
		end
		local function v_u_99(p92, p93, p94) -- name: actionRow
			-- upvalues: (copy) v_u_11, (copy) v_u_74, (copy) v_u_91
			local v95 = v_u_11.Compact and 88 or 80
			local v96 = p92.row(v95, p94)
			local v97 = v_u_11.Compact and 260 or 230
			local v98 = v_u_74({
				["Size"] = UDim2.fromOffset(p93 - v97 - 12, v95),
				["TextSize"] = v_u_11.Compact and 44 or 42,
				["Parent"] = v96
			})
			v_u_91({
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.fromScale(1, 0),
				["Size"] = UDim2.fromOffset(v97, v95),
				["TextSize"] = v_u_11.Compact and 20 or 18,
				["Parent"] = v96
			})
			return v98
		end
		local function v_u_111(p100) -- name: kitOf
			-- upvalues: (copy) v_u_15
			local v101 = v_u_15.Normalize(p100)
			local v102 = {}
			for _, v103 in v101.items do
				local v104 = v_u_15.Get(v103)
				if not v104 then
					continue
				end
				local v105 = {
					["icon"] = v103,
					["name"] = v104.name,
					["points"] = v104.points,
					["cat"] = v104.category
				}
				table.insert(v102, v105)
			end
			local v106 = v101.armor and v_u_15.Get(v101.armor)
			if v106 then
				local v107 = {
					["icon"] = nil,
					["name"] = nil,
					["points"] = nil,
					["cat"] = "armor",
					["icon"] = v101.armor,
					["name"] = v106.name,
					["points"] = v106.points
				}
				table.insert(v102, v107)
			end
			for _, v108 in v_u_15.AmmoTypes() do
				local v109 = v101.ammo[v108.id] or 0
				if v109 <= 0 then
					continue
				end
				local v110 = {
					["icon"] = "ammo_" .. v108.id,
					["name"] = v108.name,
					["points"] = v109 * v108.points,
					["cat"] = v108.id == "arrows" and "bow" or "gun"
				}
				table.insert(v102, v110)
			end
			return v102, v_u_15.Cost(v101)
		end
		local function v_u_119(p112) -- name: loadoutSig
			-- upvalues: (copy) v_u_15
			local v113 = v_u_15.Normalize(p112)
			local v114 = {}
			local v115 = v_u_15.Normalize(v113)
			__set_list(v114, 1, {table.concat(v115.items, ",") .. "|" .. (v115.armor or "")})
			for _, v116 in v_u_15.AmmoTypes() do
				local v117 = v113.ammo[v116.id] or 0
				local v118 = tostring(v117)
				table.insert(v114, v118)
			end
			return table.concat(v114, "|")
		end
		local function v_u_141(p120, p121, p122, p123, p124) -- name: itemTile
			-- upvalues: (copy) v_u_11, (ref) v_u_8, (copy) v_u_18, (copy) v_u_16, (copy) v_u_19, (copy) v_u_12
			local v125 = v_u_11.new
			local v126 = {
				["Name"] = "Tile",
				["Size"] = UDim2.fromOffset(p122, p122),
				["BackgroundColor3"] = Color3.new(1, 1, 1),
				["LayoutOrder"] = p124 or 0
			}
			local v127 = v_u_11.Corner
			local v128 = p122 * 0.15
			local v129 = math.floor(v128)
			__set_list(v126, 1, {(v127((math.max(6, v129))))})
			v126.Parent = p120
			local v130 = v125("Frame", v126)
			local v131 = v_u_8[p121.cat] or v_u_18.Accent
			v_u_11.Gradient(v131:Lerp(v_u_18.Panel, 0.6799999999999999), v_u_18.PanelHi:Lerp(v_u_18.Panel, 0.6), 115).Parent = v130
			v_u_11.Stroke(v_u_18.Stroke, 1, 0.88).Parent = v130
			local v132 = v_u_11.new("Frame", {
				["Name"] = "Icon",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 2,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromScale(0.9, 0.9),
				["Parent"] = v130
			})
			v_u_16.Set(v132, p121.icon, {
				["outline"] = false,
				["glow"] = false
			})
			local v133
			if p123 then
				local v134 = p122 * 0.27
				local v135 = math.floor(v134)
				local v136 = math.max(18, v135)
				local v137 = v_u_11.new
				local v138 = {
					["Name"] = "Cost",
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1, -4, 0, 4),
					["Size"] = UDim2.fromOffset(v136, v136),
					["BackgroundColor3"] = v_u_18.Void,
					["BackgroundTransparency"] = 0.2
				}
				local v139 = p121.points
				v138.Text = tostring(v139)
				v138.FontFace = v_u_19.Heavy
				local v140 = v136 * 0.66
				v138.TextSize = math.floor(v140)
				v138.TextColor3 = v_u_18.Text
				v138.ZIndex = 3
				__set_list(v138, 1, {(v_u_11.Corner(v_u_12.Radius.Pill))})
				v138.Parent = v130
				v133 = v137("TextLabel", v138)
			else
				v133 = nil
			end
			return v130, v132, v133
		end
		local function v_u_162(p142, p143, p144, p145, p146) -- name: kitStrip
			-- upvalues: (copy) v_u_11, (copy) v_u_141, (copy) v_u_19, (copy) v_u_18
			local v147 = #p143
			local v148 = math.max(v147, 1)
			local v149 = (p144 - (v148 - 1) * 10) / v148
			local v150 = math.floor(v149)
			local v151 = math.min(p145, v150)
			local v152 = p145 - 14 <= v151
			local v153 = p146 + 6
			local v154 = v151 + (not v152 and 0 or v153 + 4)
			local v155 = v_u_11.new("Frame", {
				["Name"] = "Kit",
				["Size"] = UDim2.fromOffset(p144, v154),
				v_u_11.List(Enum.FillDirection.Horizontal, 10, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Top),
				["Parent"] = p142
			})
			local v156 = {}
			for v157, v158 in p143 do
				local v159 = v_u_11.new("Frame", {
					["Name"] = "Item" .. v157,
					["Size"] = UDim2.fromOffset(v151, v154),
					["LayoutOrder"] = v157,
					["Parent"] = v155
				})
				local _, v160, v161 = v_u_141(v159, v158, v151, true)
				if v152 then
					v_u_11.new("TextLabel", {
						["Name"] = "Name",
						["Position"] = nil,
						["Size"] = nil,
						["Text"] = nil,
						["FontFace"] = nil,
						["TextSize"] = nil,
						["TextColor3"] = nil,
						["TextTruncate"] = nil,
						["Parent"] = nil,
						["Position"] = UDim2.fromOffset(-4, v151 + 4),
						["Size"] = UDim2.fromOffset(v151 + 8, v153),
						["Text"] = v158.name,
						["FontFace"] = v_u_19.Bold,
						["TextSize"] = p146,
						["TextColor3"] = v_u_18.TextDim,
						["TextTruncate"] = Enum.TextTruncate.AtEnd,
						["Parent"] = v159
					})
				end
				v156[v157] = {
					["icon"] = v160,
					["cost"] = v161,
					["points"] = v158.points
				}
			end
			return v155, v156, v154
		end
		local function v_u_169(p163, p164, p165, p166) -- name: pointsReadout
			-- upvalues: (copy) v_u_11, (copy) v_u_19, (copy) v_u_18
			local v167 = v_u_11.new("Frame", {
				["Name"] = "Points",
				["AnchorPoint"] = p164.AnchorPoint,
				["Position"] = p164.Position,
				["Size"] = p164.Size,
				v_u_11.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
				["Parent"] = p163
			})
			local v168 = v_u_11.new("TextLabel", {
				["Name"] = "Num",
				["AutomaticSize"] = nil,
				["Size"] = nil,
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = nil,
				["TextColor3"] = nil,
				["LayoutOrder"] = 1,
				["Parent"] = nil,
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["Size"] = UDim2.new(0, 0, 1, 0),
				["FontFace"] = v_u_19.Heavy,
				["TextSize"] = p165,
				["TextColor3"] = v_u_18.Text,
				["Parent"] = v167
			})
			v_u_11.new("TextLabel", {
				["Name"] = "Word",
				["AutomaticSize"] = nil,
				["Size"] = nil,
				["Text"] = "POINTS",
				["FontFace"] = nil,
				["TextSize"] = nil,
				["TextColor3"] = nil,
				["LayoutOrder"] = 2,
				["Parent"] = nil,
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["Size"] = UDim2.new(0, 0, 1, 0),
				["FontFace"] = v_u_19.Heavy,
				["TextSize"] = p166,
				["TextColor3"] = v_u_18.TextMuted,
				["Parent"] = v167
			})
			return v168
		end
		local function v_u_186(p170, p171, p172, p173) -- name: pointsMeter
			-- upvalues: (copy) v_u_15, (copy) v_u_11, (copy) v_u_18, (copy) v_u_12
			local v174 = v_u_15.Budget()
			local v175 = math.max(v174, 1)
			local v176 = (p171 - (v175 - 1) * 3) / v175
			local v177 = math.floor(v176)
			local v178 = v_u_11.new("Frame", {
				["Name"] = "Meter",
				["Position"] = p173,
				["Size"] = UDim2.fromOffset(p171, p172),
				v_u_11.List(Enum.FillDirection.Horizontal, 3, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
				["Parent"] = p170
			})
			local v_u_179 = {}
			for v180 = 1, v175 do
				v_u_179[v180] = v_u_11.new("Frame", {
					["Name"] = "P" .. v180,
					["Size"] = UDim2.fromOffset(v177, p172),
					["BackgroundColor3"] = v_u_18.Raised,
					["LayoutOrder"] = v180,
					v_u_11.Corner(3),
					["Parent"] = v178
				})
			end
			return function(p181, p182)
				-- upvalues: (copy) v_u_179, (ref) v_u_18, (ref) v_u_11, (ref) v_u_12
				for v183, v184 in v_u_179 do
					local v185
					if v183 <= p181 then
						v185 = v_u_18.Accent
					else
						v185 = v_u_18.Raised
					end
					if p182 then
						v184.BackgroundColor3 = v185
					else
						v_u_11.Tween(v184, v_u_12.Tween.Fast, {
							["BackgroundColor3"] = v185
						})
					end
				end
			end
		end
		local v_u_383 = {
			["Classic"] = function(p187) -- name: Classic
				-- upvalues: (copy) v_u_11, (copy) v_u_19, (copy) v_u_18, (copy) v_u_74, (copy) v_u_91, (ref) v_u_43, (copy) v_u_31
				local v188 = v_u_11.Compact
				local v_u_189 = v188 and 6 or 20
				v_u_11.Padding(28, 34, v_u_189, 34).Parent = p187
				local v_u_190 = v_u_11.new("UIListLayout", {
					["SortOrder"] = Enum.SortOrder.LayoutOrder,
					["HorizontalAlignment"] = Enum.HorizontalAlignment.Center,
					["Padding"] = UDim.new(0, 8),
					["Parent"] = p187
				})
				v_u_11.new("TextLabel", {
					["Name"] = "Overline",
					["Size"] = nil,
					["Text"] = "WELCOME TO TRIBES",
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["LayoutOrder"] = 1,
					["Parent"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 18),
					["FontFace"] = v_u_19.Heavy,
					["TextSize"] = v188 and 18 or 16,
					["TextColor3"] = v_u_18.Accent,
					["Parent"] = p187
				})
				v_u_11.new("TextLabel", {
					["Name"] = "Title",
					["Size"] = nil,
					["Text"] = "READY TO FIGHT?",
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["LayoutOrder"] = 2,
					["Parent"] = nil,
					["Size"] = UDim2.new(1, 0, 0, v188 and 52 or 48),
					["FontFace"] = v_u_19.Display,
					["TextSize"] = v188 and 48 or 46,
					["TextColor3"] = v_u_18.Text,
					["Parent"] = p187
				})
				v_u_11.new("TextLabel", {
					["Name"] = "Blurb",
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["Text"] = "Team up 3v3 with bows, swords and spears.\nLast tribe standing wins the round.",
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextWrapped"] = true,
					["LayoutOrder"] = 3,
					["Parent"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y,
					["FontFace"] = v_u_19.Medium,
					["TextSize"] = v188 and 21 or 19,
					["TextColor3"] = v_u_18.TextDim,
					["Parent"] = p187
				})
				v_u_11.new("Frame", {
					["Name"] = "Gap",
					["Size"] = nil,
					["LayoutOrder"] = 4,
					["Parent"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 10),
					["Parent"] = p187
				})
				local v191 = v_u_74({
					["Size"] = nil,
					["TextSize"] = nil,
					["LayoutOrder"] = 5,
					["Parent"] = nil,
					["Size"] = UDim2.new(1, 0, 0, v188 and 88 or 84),
					["TextSize"] = v188 and 46 or 44,
					["Parent"] = p187
				})
				v_u_91({
					["Size"] = nil,
					["TextSize"] = nil,
					["LayoutOrder"] = 6,
					["Parent"] = nil,
					["Size"] = UDim2.new(1, 0, 0, v188 and 80 or 44),
					["TextSize"] = v188 and 21 or 18,
					["Parent"] = p187
				})
				v_u_190:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
					-- upvalues: (ref) v_u_43
					task.defer(v_u_43)
				end)
				return {
					["width"] = v188 and 600 or 560,
					["fight"] = v191,
					["measure"] = function() -- name: measure
						-- upvalues: (ref) v_u_11, (ref) v_u_31, (copy) v_u_190, (copy) v_u_189
						local v192 = v_u_11.Scale * v_u_31.Scale
						local v193 = math.max(v192, 0.01)
						local v194 = v_u_190.AbsoluteContentSize.Y / v193
						local v195 = (v194 <= 50 and 300 or v194) + 28 + v_u_189
						return math.ceil(v195)
					end
				}
			end,
			["Pitch"] = function(p_u_196) -- name: Pitch
				-- upvalues: (copy) v_u_11, (copy) v_u_58, (copy) v_u_70, (copy) v_u_111, (copy) v_u_13, (copy) v_u_15, (copy) v_u_18, (copy) v_u_19, (copy) v_u_169, (copy) v_u_162, (copy) v_u_186, (copy) v_u_81, (copy) v_u_74, (copy) v_u_91, (copy) v_u_119
				local v197 = v_u_11.Compact and 680 or 620
				local v198 = v_u_11.Compact and 30 or 32
				local v199 = v197 - v198 * 2
				local v200 = v_u_58(p_u_196, v198, v199, v_u_11.Compact and 20 or 26)
				v_u_70(v200, "COMPETITIVE 3V3 ARENA", "BUILD YOUR LOADOUT", v_u_11.Compact and 48 or 46, "Spend your gear points on any weapons, armor and healing.\nThen fight 3v3. Last tribe standing wins the round.", 2)
				local v201, v_u_202 = v_u_111(v_u_13.Loadout())
				local v203 = v_u_15.Budget()
				local v204 = v199 - 28
				local v205 = v200.row(0, v_u_11.Compact and 10 or 14)
				v205.Name = "Loadout"
				v205.BackgroundColor3 = v_u_18.Inset
				v205.BackgroundTransparency = 0.3
				v_u_11.Corner(14).Parent = v205
				v_u_11.Stroke(v_u_18.Stroke, 1, 0.9).Parent = v205
				local v206 = v_u_11.new
				local v207 = {
					["Name"] = "Label",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "YOUR LOADOUT",
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(14, 12)
				}
				local v208 = UDim2.fromOffset
				local v209 = v204 * 0.6
				v207.Size = v208(math.floor(v209), 20)
				v207.FontFace = v_u_19.Heavy
				v207.TextSize = v_u_11.Compact and 16 or 14
				v207.TextColor3 = v_u_18.TextMuted
				v207.TextXAlignment = Enum.TextXAlignment.Left
				v207.Parent = v205
				v206("TextLabel", v207)
				local v210 = v_u_169
				local v211 = {
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1, -14, 0, 12)
				}
				local v212 = UDim2.fromOffset
				local v213 = v204 * 0.4
				v211.Size = v212(math.floor(v213), 20)
				local v214 = v210(v205, v211, v_u_11.Compact and 19 or 17, v_u_11.Compact and 15 or 13)
				local v215, _, v216 = v_u_162(v205, v201, v204, v_u_11.Compact and 90 or 88, v_u_11.Compact and 15 or 13)
				v215.Position = UDim2.fromOffset(14, 42)
				local v_u_217 = v_u_186(v205, v204, 8, UDim2.fromOffset(14, 42 + v216 + 10))
				local v218 = 42 + v216 + 10 + 8 + 14
				v205.Size = UDim2.fromOffset(v199, v218)
				v200.skip(v218)
				local v219 = v_u_11.Compact and 88 or 80
				local v220 = v200.row(v219, v_u_11.Compact and 10 or 14)
				local v221 = v199 * 0.37
				local v222 = math.floor(v221)
				v_u_81({
					["Size"] = UDim2.fromOffset(v222, v219),
					["TextSize"] = v_u_11.Compact and 24 or 22,
					["Parent"] = v220
				})
				local v223 = v_u_74({
					["Position"] = UDim2.fromOffset(v222 + 12, 0),
					["Size"] = UDim2.fromOffset(v199 - v222 - 12, v219),
					["TextSize"] = v_u_11.Compact and 44 or 42,
					["Parent"] = v220
				})
				v_u_91({
					["Size"] = UDim2.fromScale(1, 1),
					["TextSize"] = v_u_11.Compact and 21 or 18,
					["Parent"] = v200.row(v_u_11.Compact and 60 or 40, 2)
				})
				v200.skip(v_u_11.Compact and 2 or 12)
				v214.Text = v_u_202 .. " / " .. v203
				v_u_217(v_u_202, true)
				local v_u_224 = 0
				return {
					["width"] = v197,
					["height"] = v200.y(),
					["fight"] = v223,
					["signature"] = function() -- name: signature
						-- upvalues: (ref) v_u_119, (ref) v_u_13
						return v_u_119(v_u_13.Loadout())
					end,
					["opened"] = function() -- name: opened
						-- upvalues: (ref) v_u_224, (copy) v_u_217, (copy) v_u_202, (copy) p_u_196
						v_u_224 = v_u_224 + 1
						local v_u_225 = v_u_224
						v_u_217(0, true)
						task.spawn(function()
							-- upvalues: (ref) v_u_202, (copy) v_u_225, (ref) v_u_224, (ref) p_u_196, (ref) v_u_217
							task.wait(0.3)
							for v226 = 1, v_u_202 do
								if v_u_225 ~= v_u_224 or not p_u_196.Parent then
									return
								end
								v_u_217(v226)
								task.wait(0.045)
							end
						end)
					end
				}
			end,
			["Builds"] = function(p_u_227) -- name: Builds
				-- upvalues: (copy) v_u_11, (copy) v_u_58, (copy) v_u_70, (copy) v_u_13, (copy) v_u_18, (copy) v_u_12, (copy) v_u_19, (ref) v_u_39, (ref) v_u_37, (copy) p_u_10, (copy) v_u_111, (ref) v_u_9, (copy) v_u_15, (ref) v_u_8, (copy) v_u_16, (copy) v_u_141, (ref) v_u_41, (ref) v_u_42, (copy) v_u_14, (copy) v_u_74, (copy) v_u_91, (copy) v_u_119
				local v228 = v_u_11.Compact and 1090 or 1000
				local v229 = v228 - 56
				local v230 = v_u_58(p_u_227, 28, v229, v_u_11.Compact and 16 or 24)
				v_u_70(v230, "COMPETITIVE 3V3 ARENA", "CHOOSE YOUR LOADOUT", v_u_11.Compact and 48 or 46, "Every fighter brings their own gear. Pick a build to start, or make your own.", 1)
				local v231 = v_u_13.LoadoutSlotCount
				local v_u_232 = math.min(3, v231())
				local v233 = v_u_232 + 1
				local v234 = (v229 - (v233 - 1) * 12) / v233
				local v_u_235 = math.floor(v234)
				local v_u_236 = v_u_11.Compact and 80 or 92
				local v_u_237 = v_u_11.Compact and 22 or 20
				local v_u_238 = v_u_11.Compact and 16 or 15
				local v_u_239 = v_u_237 + 4
				local v240 = v_u_238 * 1.3 * 2
				local v_u_241 = math.ceil(v240)
				local v_u_242 = v_u_11.Compact and 34 or 36
				local v_u_243 = v_u_236 + 10 + 8 + v_u_239 + 2 + v_u_241 + 8 + v_u_242 + 12
				local v_u_244 = v230.row(v_u_243, v_u_11.Compact and 18 or 20)
				local v_u_245 = Color3.fromRGB(226, 230, 238)
				local v_u_246 = Color3.new(1, 1, 1)
				local v_u_247 = v_u_236 + 10 + 8 + v_u_239 + 2 + v_u_241 + 8
				local function v259(p248, p249, p250, p251) -- name: shell
					-- upvalues: (ref) v_u_11, (copy) v_u_235, (copy) v_u_243, (copy) v_u_244, (copy) v_u_245, (ref) v_u_18, (ref) v_u_12, (copy) v_u_246, (copy) v_u_236, (copy) v_u_239, (ref) v_u_19, (copy) v_u_237, (copy) v_u_241, (copy) v_u_238, (copy) v_u_247, (copy) v_u_242
					local v252 = v_u_11.new("TextButton", {
						["Name"] = p249,
						["Position"] = UDim2.fromOffset((p248 - 1) * (v_u_235 + 12), 0),
						["Size"] = UDim2.fromOffset(v_u_235, v_u_243),
						["Parent"] = v_u_244
					})
					local v_u_253 = v_u_11.new("Frame", {
						["Name"] = "Face",
						["Size"] = UDim2.fromScale(1, 1),
						["BackgroundColor3"] = v_u_245,
						v_u_11.Corner(14),
						v_u_11.Gradient(v_u_18.PanelHi, v_u_18.Panel, 90),
						["Parent"] = v252
					})
					local v254 = v_u_11.Stroke(v_u_18.StrokeSoft, 1.5, 0)
					v254.Parent = v_u_253
					v252.MouseEnter:Connect(function()
						-- upvalues: (ref) v_u_11, (copy) v_u_253, (ref) v_u_12, (ref) v_u_246
						local v255 = {
							["BackgroundColor3"] = v_u_246
						}
						v_u_11.Tween(v_u_253, v_u_12.Tween.Fast, v255)
					end)
					v252.MouseLeave:Connect(function()
						-- upvalues: (ref) v_u_11, (copy) v_u_253, (ref) v_u_12, (ref) v_u_245
						local v256 = {
							["BackgroundColor3"] = v_u_245
						}
						v_u_11.Tween(v_u_253, v_u_12.Tween.Fast, v256)
					end)
					local v257 = v_u_11.new("Frame", {
						["Name"] = "Hero",
						["Position"] = UDim2.fromOffset(10, 10),
						["Size"] = UDim2.fromOffset(v_u_235 - 20, v_u_236),
						["BackgroundColor3"] = Color3.new(1, 1, 1),
						v_u_11.Corner(10),
						["Parent"] = v_u_253
					})
					local v258 = v_u_11.Pill("EQUIPPED", v_u_18.Accent, {
						["Name"] = "Equipped",
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Height"] = nil,
						["TextSize"] = nil,
						["Transparency"] = 0,
						["ZIndex"] = 4,
						["Parent"] = nil,
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.fromScale(0.5, 0),
						["Height"] = v_u_11.Compact and 24 or 22,
						["TextSize"] = v_u_11.Compact and 14 or 13,
						["Parent"] = v252
					})
					v_u_11.new("TextLabel", {
						["Name"] = "Name",
						["Position"] = nil,
						["Size"] = nil,
						["Text"] = nil,
						["FontFace"] = nil,
						["TextSize"] = nil,
						["TextColor3"] = nil,
						["TextTruncate"] = nil,
						["Parent"] = nil,
						["Position"] = UDim2.fromOffset(12, v_u_236 + 10 + 8),
						["Size"] = UDim2.fromOffset(v_u_235 - 24, v_u_239),
						["Text"] = p250,
						["FontFace"] = v_u_19.Heavy,
						["TextSize"] = v_u_237,
						["TextColor3"] = v_u_18.Text,
						["TextTruncate"] = Enum.TextTruncate.AtEnd,
						["Parent"] = v_u_253
					})
					v_u_11.new("TextLabel", {
						["Name"] = "Line",
						["Position"] = nil,
						["Size"] = nil,
						["Text"] = nil,
						["FontFace"] = nil,
						["TextSize"] = nil,
						["TextColor3"] = nil,
						["TextWrapped"] = true,
						["TextYAlignment"] = nil,
						["Parent"] = nil,
						["Position"] = UDim2.fromOffset(12, v_u_236 + 10 + 8 + v_u_239 + 2),
						["Size"] = UDim2.fromOffset(v_u_235 - 24, v_u_241),
						["Text"] = p251,
						["FontFace"] = v_u_19.Medium,
						["TextSize"] = v_u_238,
						["TextColor3"] = v_u_18.TextDim,
						["TextYAlignment"] = Enum.TextYAlignment.Top,
						["Parent"] = v_u_253
					})
					return v252, v254, v257, v258, v_u_11.new("Frame", {
						["Name"] = "Rest",
						["Position"] = UDim2.fromOffset(12, v_u_247),
						["Size"] = UDim2.fromOffset(v_u_235 - 24, v_u_242),
						v_u_11.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
						["Parent"] = v_u_253
					})
				end
				local v_u_260 = {}
				local v_u_261 = nil
				local v_u_262 = {
					["width"] = nil,
					["selecting"] = false,
					["width"] = v228
				}
				local function v_u_269() -- name: paint
					-- upvalues: (ref) v_u_261, (ref) v_u_13, (copy) v_u_260, (copy) v_u_232, (ref) v_u_18
					local v263 = v_u_261 or v_u_13.ActiveLoadout()
					for v264, v265 in v_u_260 do
						local v266
						if v264 <= v_u_232 then
							v266 = v264 == v263
						else
							v266 = v_u_232 < v263
						end
						local v267 = v265.stroke
						local v268
						if v266 then
							v268 = v_u_18.Accent
						else
							v268 = v_u_18.StrokeSoft
						end
						v267.Color = v268
						v265.stroke.Thickness = v266 and 2.5 or 1.5
						v265.pill.Visible = v266
					end
				end
				local function v_u_273(p_u_270) -- name: pick
					-- upvalues: (ref) v_u_39, (copy) v_u_262, (ref) v_u_37, (ref) v_u_13, (ref) v_u_11, (copy) v_u_260, (ref) p_u_10, (ref) v_u_261, (copy) v_u_269, (copy) p_u_227
					if v_u_39 or (v_u_262.selecting or not v_u_37) then
						return
					elseif v_u_13.ActiveLoadout() == p_u_270 then
						v_u_11.Bump(v_u_260[p_u_270].pill, 0.12)
					else
						p_u_10.Sounds.Play("Select")
						local v271 = v_u_262
						v_u_261 = p_u_270
						v271.selecting = true
						v_u_269()
						task.spawn(function()
							-- upvalues: (ref) p_u_10, (copy) p_u_270, (ref) v_u_261, (ref) v_u_262, (ref) p_u_227, (ref) v_u_269
							p_u_10.ProfileAction("SelectLoadout", p_u_270)
							local v272 = v_u_262
							v_u_261 = nil
							v272.selecting = false
							if p_u_227.Parent then
								v_u_269()
							end
						end)
					end
				end
				for v_u_274 = 1, v_u_232 do
					local v275 = v_u_13.LoadoutSlot(v_u_274)
					local v276 = v_u_111(v275)
					local v277 = v_u_9
					local v278 = v_u_15.Normalize(v275)
					local v279 = v277[table.concat(v278.items, ",") .. "|" .. (v278.armor or "")]
					local v280 = v_u_13.LoadoutCustomName(v_u_274)
					local v281
					if v280 == "" then
						v281 = not v279 and "YOUR BUILD" or v279.name
					else
						v281 = string.upper(v280)
					end
					local v282, v283, v284, v285, v286 = v259(v_u_274, "Build" .. v_u_274, v281, not v279 and "Your own mix of gear." or v279.line)
					local v287 = v276[1]
					local v288 = v287 and v_u_8[v287.cat] or v_u_18.Accent
					v_u_11.Gradient(v288:Lerp(v_u_18.Panel, 0.5800000000000001), v_u_18.PanelHi:Lerp(v_u_18.Panel, 0.6), 115).Parent = v284
					if v287 then
						local v289 = v_u_11.new("Frame", {
							["Name"] = "Icon",
							["AnchorPoint"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["ZIndex"] = 2,
							["Parent"] = nil,
							["AnchorPoint"] = Vector2.new(0.5, 0.5),
							["Position"] = UDim2.fromScale(0.5, 0.5),
							["Size"] = UDim2.fromOffset(v_u_236 - 6, v_u_236 - 6),
							["Parent"] = v284
						})
						v_u_16.Set(v289, v287.icon, {
							["outline"] = false,
							["glow"] = false
						})
					end
					local v290 = #v276 - 1
					local v291 = math.max(v290, 1)
					local v292 = (v_u_235 - 24 - (v291 - 1) * 6) / v291
					local v293 = math.floor(v292)
					local v294 = math.min(v_u_242, v293)
					for v295 = 2, #v276 do
						v_u_141(v286, v276[v295], v294, false, v295)
					end
					v_u_260[v_u_274] = {
						["stroke"] = v283,
						["pill"] = v285
					}
					v282.Activated:Connect(function()
						-- upvalues: (copy) v_u_273, (copy) v_u_274
						v_u_273(v_u_274)
					end)
				end
				local v296, v297, v298, v299, v300 = v259(v233, "Own", "BUILD YOUR OWN", "Mix any gear you own.\nEvery item costs points.")
				local v301 = v_u_18.Accent
				v_u_11.Gradient(v301:Lerp(v_u_18.Panel, 0.7), v_u_18.PanelHi:Lerp(v_u_18.Panel, 0.6), 115).Parent = v298
				local v302 = v_u_11.new("Frame", {
					["Name"] = "Plus",
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Size"] = UDim2.fromOffset(v_u_11.Compact and 48 or 52, v_u_11.Compact and 48 or 52),
					["BackgroundColor3"] = v_u_18.AccentDark,
					v_u_11.Corner(v_u_12.Radius.Pill),
					["Parent"] = v298
				})
				v_u_11.Icon("plus", 24, v_u_18.Text, {
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Parent"] = v302
				})
				local v303 = (v_u_235 - 24 - 24) / 5
				local v304 = math.floor(v303)
				local v305 = math.min(v_u_242, v304)
				for v306 = 1, 5 do
					local v307 = v_u_11.new
					local v308 = {
						["Name"] = "Slot" .. v306,
						["Size"] = UDim2.fromOffset(v305, v305),
						["BackgroundColor3"] = v_u_18.Inset,
						["LayoutOrder"] = v306
					}
					local v309 = v_u_11.Corner
					local v310 = v305 * 0.15
					local v311 = math.floor(v310)
					__set_list(v308, 1, {(v309((math.max(6, v311))))})
					v308.Parent = v300
					local v312 = v307("Frame", v308)
					v_u_11.Stroke(v_u_18.StrokeSoft, 1, 0.2).Parent = v312
					local v313 = v_u_11.Icon
					local v314 = v305 * 0.34
					v313("plus", math.floor(v314), v_u_18.TextMuted, {
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.fromScale(0.5, 0.5),
						["Parent"] = v312
					})
				end
				v_u_260[v233] = {
					["stroke"] = v297,
					["pill"] = v299
				}
				v296.Activated:Connect(function()
					-- upvalues: (ref) p_u_10, (ref) v_u_39, (ref) v_u_37, (ref) v_u_41, (ref) v_u_42, (ref) v_u_14
					p_u_10.Sounds.Play("Click")
					if not v_u_39 then
						if not v_u_37 then
							return
						end
						v_u_41 = true
						v_u_42 = 0
						v_u_14.Open("Loadout")
						if not v_u_14.IsOpen("Loadout") then
							v_u_41 = false
						end
					end
				end)
				local v315
				if v233 == 4 then
					v315 = v_u_235 * 2 + 12
				else
					local v316 = v_u_11.Compact and 480 or 460
					v315 = math.min(v229, v316)
				end
				local v317 = v_u_11.Compact and 88 or 80
				v_u_262.fight = v_u_74({
					["AnchorPoint"] = Vector2.new(0.5, 0),
					["Position"] = UDim2.fromScale(0.5, 0),
					["Size"] = UDim2.fromOffset(v315, v317),
					["TextSize"] = v_u_11.Compact and 44 or 42,
					["Parent"] = v230.row(v317, v_u_11.Compact and 10 or 16)
				})
				v_u_91({
					["AnchorPoint"] = Vector2.new(0.5, 0),
					["Position"] = UDim2.fromScale(0.5, 0),
					["Size"] = UDim2.new(0, v315, 1, 0),
					["TextSize"] = v_u_11.Compact and 20 or 18,
					["Parent"] = v230.row(v_u_11.Compact and 56 or 42, 2)
				})
				v230.skip(v_u_11.Compact and 2 or 10)
				v_u_262.height = v230.y()
				function v_u_262.signature()
					-- upvalues: (ref) v_u_13, (ref) v_u_119
					local v318 = v_u_13.LoadoutSlotCount
					local v319 = {}
					for v320 = 1, math.min(3, v318()) do
						local v321 = v_u_119(v_u_13.LoadoutSlot(v320)) .. "#" .. v_u_13.LoadoutCustomName(v320)
						table.insert(v319, v321)
					end
					return table.concat(v319, ";")
				end
				v_u_262.refresh = v_u_269
				function v_u_262.pick(p322)
					-- upvalues: (copy) v_u_260, (copy) v_u_232, (copy) v_u_273
					if v_u_260[p322] and p322 <= v_u_232 then
						v_u_273(p322)
					end
				end
				v_u_269()
				return v_u_262
			end,
			["Briefing"] = function(p_u_323) -- name: Briefing
				-- upvalues: (copy) v_u_11, (copy) v_u_58, (copy) v_u_70, (copy) v_u_111, (copy) v_u_13, (copy) v_u_15, (copy) v_u_18, (copy) v_u_19, (copy) v_u_169, (copy) v_u_162, (copy) v_u_186, (copy) v_u_81, (copy) v_u_12, (copy) v_u_17, (copy) v_u_20, (copy) v_u_99, (copy) v_u_119
				local v324 = v_u_11.Compact and 1090 or 1000
				local v325 = v324 - 56
				local v326 = v_u_58(p_u_323, 28, v325, v_u_11.Compact and 18 or 24)
				v_u_70(v326, "WELCOME TO TRIBES", "COMPETITIVE 3V3. YOUR OWN LOADOUT.", v_u_11.Compact and 44 or 42)
				local v327, v_u_328 = v_u_111(v_u_13.Loadout())
				local v_u_329 = v_u_15.Budget()
				local v330 = v325 * 0.36
				local v331 = math.floor(v330)
				local v332 = v325 - v331 - 14
				local v333 = v326.row(0, v_u_11.Compact and 10 or 14)
				local v334 = v_u_11.new("Frame", {
					["Name"] = "Loadout",
					["Position"] = UDim2.fromOffset(v331 + 14, 0),
					["BackgroundColor3"] = Color3.new(1, 1, 1),
					v_u_11.Corner(14),
					v_u_11.Gradient(v_u_18.AccentDeep:Lerp(v_u_18.Panel, 0.62), v_u_18.Panel, 100),
					["Parent"] = v333
				})
				v_u_11.Stroke(v_u_18.Accent, 1.5, 0.5).Parent = v334
				local v335 = v332 - 32
				local v336 = v_u_11.new
				local v337 = {
					["Name"] = "Label",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "YOUR LOADOUT",
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(16, 14)
				}
				local v338 = UDim2.fromOffset
				local v339 = v335 * 0.5
				v337.Size = v338(math.floor(v339), 20)
				v337.FontFace = v_u_19.Heavy
				v337.TextSize = v_u_11.Compact and 17 or 15
				v337.TextColor3 = v_u_18.Accent
				v337.TextXAlignment = Enum.TextXAlignment.Left
				v337.Parent = v334
				v336("TextLabel", v337)
				local v340 = v_u_169
				local v341 = {
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1, -16, 0, 14)
				}
				local v342 = UDim2.fromOffset
				local v343 = v335 * 0.5
				v341.Size = v342(math.floor(v343), 20)
				local v_u_344 = v340(v334, v341, v_u_11.Compact and 20 or 18, v_u_11.Compact and 15 or 13)
				local v345 = v_u_11.Compact and 19 or 17
				v_u_11.new("TextLabel", {
					["Name"] = "Sub",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "Every item costs gear points. Spend them your way.",
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(16, 38),
					["Size"] = UDim2.fromOffset(v335, v345 + 6),
					["FontFace"] = v_u_19.Medium,
					["TextSize"] = v345,
					["TextColor3"] = v_u_18.TextDim,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Parent"] = v334
				})
				local v346 = v345 + 38 + 6 + 10
				local v347, v_u_348, v349 = v_u_162(v334, v327, v335, v_u_11.Compact and 84 or 80, v_u_11.Compact and 15 or 13)
				v347.Position = UDim2.fromOffset(16, v346)
				local v350 = v346 + v349 + 10
				local v_u_351 = v_u_186(v334, v335, 8, UDim2.fromOffset(16, v350))
				local v352 = v350 + 8 + 12
				local v353 = v_u_11.Compact and 56 or 48
				local v354 = v_u_11.Compact and 214 or 190
				v_u_11.new("TextLabel", {
					["Name"] = "More",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "Unlock muskets, spears, traps and heavier armor as you play.",
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextWrapped"] = true,
					["TextXAlignment"] = nil,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(16, v352),
					["Size"] = UDim2.fromOffset(v335 - v354 - 14, v353),
					["FontFace"] = v_u_19.Medium,
					["TextSize"] = v_u_11.Compact and 17 or 15,
					["TextColor3"] = v_u_18.TextMuted,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Parent"] = v334
				})
				v_u_81({
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1, -16, 0, v352),
					["Size"] = UDim2.fromOffset(v354, v353),
					["TextSize"] = v_u_11.Compact and 22 or 20,
					["Parent"] = v334
				})
				local v355 = v352 + v353 + 16
				v334.Size = UDim2.fromOffset(v332, v355)
				local v356 = v_u_11.new("Frame", {
					["Name"] = "Fight",
					["Size"] = UDim2.fromOffset(v331, v355),
					["BackgroundColor3"] = v_u_18.Inset,
					["BackgroundTransparency"] = 0.3,
					v_u_11.Corner(14),
					["Parent"] = v333
				})
				v_u_11.Stroke(v_u_18.Stroke, 1, 0.9).Parent = v356
				v_u_11.new("TextLabel", {
					["Name"] = "Label",
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "THE FIGHT",
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(16, 14),
					["Size"] = UDim2.fromOffset(v331 - 32, 20),
					["FontFace"] = v_u_19.Heavy,
					["TextSize"] = v_u_11.Compact and 17 or 15,
					["TextColor3"] = v_u_18.TextMuted,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Parent"] = v356
				})
				local v_u_357 = v_u_11.Compact and 42 or 38
				local v_u_358 = v_u_11.new("Frame", {
					["Name"] = "Teams",
					["Position"] = UDim2.fromOffset(0, 50),
					["Size"] = UDim2.fromOffset(v331, v_u_357),
					v_u_11.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
					["Parent"] = v356
				})
				local function v366(p359, p360, p361) -- name: fighter
					-- upvalues: (ref) v_u_11, (copy) v_u_357, (ref) v_u_18, (ref) v_u_12, (copy) v_u_358, (ref) v_u_17, (ref) v_u_20
					local v362 = v_u_11.new("Frame", {
						["Name"] = "Fighter",
						["Size"] = UDim2.fromOffset(v_u_357, v_u_357),
						["BackgroundColor3"] = p360:Lerp(v_u_18.Panel, 0.72),
						["LayoutOrder"] = p359,
						v_u_11.Corner(v_u_12.Radius.Pill),
						["Parent"] = v_u_358
					})
					v_u_11.Stroke(p360, 2, 0).Parent = v362
					if p361 then
						local v363 = v_u_11.new("ImageLabel", {
							["Name"] = "You",
							["Size"] = UDim2.fromScale(1, 1),
							["ScaleType"] = Enum.ScaleType.Crop,
							v_u_11.Corner(v_u_12.Radius.Pill),
							["Parent"] = v362
						})
						v_u_17.Apply(v363, {
							["userId"] = v_u_20.UserId
						}, 150)
					else
						local v364 = v_u_11.Icon
						local v365 = v_u_357 * 0.56
						v364("person", math.floor(v365), p360, {
							["AnchorPoint"] = Vector2.new(0.5, 0.5),
							["Position"] = UDim2.fromScale(0.5, 0.5),
							["Parent"] = v362
						})
					end
				end
				v366(1, v_u_18.Ally, true)
				v366(2, v_u_18.Ally, false)
				v366(3, v_u_18.Ally, false)
				v_u_11.new("TextLabel", {
					["Name"] = "Vs",
					["Size"] = nil,
					["Text"] = "VS",
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["LayoutOrder"] = 4,
					["Parent"] = nil,
					["Size"] = UDim2.fromOffset(v_u_11.Compact and 38 or 34, v_u_357),
					["FontFace"] = v_u_19.Display,
					["TextSize"] = v_u_11.Compact and 22 or 20,
					["TextColor3"] = v_u_18.TextDim,
					["Parent"] = v_u_358
				})
				v366(5, v_u_18.Enemy, false)
				v366(6, v_u_18.Enemy, false)
				v366(7, v_u_18.Enemy, false)
				local v367 = { "Two tribes of three", "One life each round", "Last tribe standing wins" }
				local v368 = v_u_11.Compact and 40 or 38
				local v369 = v_u_357 + 50
				local v370 = (v355 - v369 - #v367 * v368) / 2
				local v371 = v369 + math.floor(v370)
				for v372, v373 in v367 do
					local v374 = v371 + (v372 - 1) * v368
					v_u_11.new("Frame", {
						["Name"] = "Dot" .. v372,
						["AnchorPoint"] = Vector2.new(0, 0.5),
						["Position"] = UDim2.fromOffset(18, v374 + v368 / 2),
						["Size"] = UDim2.fromOffset(8, 8),
						["BackgroundColor3"] = v_u_18.Accent,
						v_u_11.Corner(2),
						["Parent"] = v356
					})
					v_u_11.new("TextLabel", {
						["Name"] = "Fact" .. v372,
						["Position"] = UDim2.fromOffset(38, v374),
						["Size"] = UDim2.fromOffset(v331 - 32 - 22, v368),
						["Text"] = v373,
						["FontFace"] = v_u_19.Bold,
						["TextSize"] = v_u_11.Compact and 20 or 18,
						["TextColor3"] = v_u_18.Text,
						["TextXAlignment"] = Enum.TextXAlignment.Left,
						["Parent"] = v356
					})
				end
				v333.Size = UDim2.fromOffset(v325, v355)
				v326.skip(v355)
				local v375 = v_u_99(v326, v325, v_u_11.Compact and 10 or 14)
				v326.skip(v_u_11.Compact and 12 or 14);
				(function() -- name: settle
					-- upvalues: (copy) v_u_344, (copy) v_u_328, (copy) v_u_329, (copy) v_u_351, (copy) v_u_348, (ref) v_u_11
					v_u_344.Text = v_u_328 .. " / " .. v_u_329
					v_u_351(v_u_328, true)
					for _, v376 in v_u_348 do
						v_u_11.GetScaleObj(v376.icon).Scale = 1
						if not v376.cost then
							continue
						end
						v376.cost.Visible = true
					end
				end)()
				local v_u_377 = 0
				return {
					["width"] = v324,
					["height"] = v326.y(),
					["fight"] = v375,
					["signature"] = function() -- name: signature
						-- upvalues: (ref) v_u_119, (ref) v_u_13
						return v_u_119(v_u_13.Loadout())
					end,
					["opened"] = function() -- name: opened
						-- upvalues: (ref) v_u_377, (copy) v_u_344, (copy) v_u_329, (copy) v_u_351, (copy) v_u_348, (ref) v_u_11, (copy) p_u_323, (ref) v_u_12
						v_u_377 = v_u_377 + 1
						local v_u_378 = v_u_377
						v_u_344.Text = "0 / " .. v_u_329
						v_u_351(0, true)
						for _, v379 in v_u_348 do
							v_u_11.GetScaleObj(v379.icon).Scale = 0.001
							if not v379.cost then
								continue
							end
							v379.cost.Visible = false
						end
						task.spawn(function()
							-- upvalues: (ref) v_u_348, (copy) v_u_378, (ref) v_u_377, (ref) p_u_323, (ref) v_u_11, (ref) v_u_12, (ref) v_u_344, (ref) v_u_329, (ref) v_u_351
							task.wait(0.4)
							local v380 = 0
							for _, v381 in v_u_348 do
								if v_u_378 ~= v_u_377 or not p_u_323.Parent then
									return
								end
								local v382 = v_u_11.GetScaleObj(v381.icon)
								v382.Scale = 0.5
								v_u_11.Tween(v382, v_u_12.Tween.Pop, {
									["Scale"] = 1
								})
								if v381.cost then
									v381.cost.Visible = true
								end
								v380 = v380 + v381.points
								v_u_344.Text = v380 .. " / " .. v_u_329
								v_u_351(v380)
								task.wait(0.17)
							end
						end)
					end
				}
			end
		}
		v_u_43 = function()
			-- upvalues: (ref) v_u_33, (copy) v_u_30, (copy) v_u_11, (copy) v_u_31, (copy) v_u_12
			if v_u_33 then
				local v384 = v_u_33.width
				local v385
				if v_u_33.measure then
					v385 = v_u_33.measure()
				else
					v385 = v_u_33.height
				end
				v_u_30.Size = UDim2.fromOffset(v384, v385)
				local v386 = v_u_11.CanvasSize()
				local v387 = v_u_11.TopInset()
				local v388
				if v386.X > 200 then
					v388 = v386.Y > 200
				else
					v388 = false
				end
				local v389
				if v388 then
					local v390 = (v386.Y - v387 - 16) / v385
					local v391 = (v386.X - 32) / v384
					local v392 = math.min(v390, v391)
					v389 = math.clamp(v392, 0.3, 1)
				else
					v389 = 1
				end
				v_u_31.Scale = v389
				local v393
				if v388 then
					local v394 = v387 + v385 * v389 / 2 + 4 - v386.Y / 2
					v393 = math.max(0, v394)
				else
					v393 = 0
				end
				local v395 = UDim2.new(0.5, 0, 0.5, v393)
				if v_u_30:GetAttribute("_slideTarget") == nil then
					v_u_30.Position = v395
				else
					v_u_30:SetAttribute("_slideTarget", v395)
					v_u_11.Tween(v_u_30, v_u_12.Tween.Fast, {
						["Position"] = v395
					}).Completed:Connect(function(p396)
						-- upvalues: (ref) v_u_30
						if p396 == Enum.PlaybackState.Completed then
							v_u_30:SetAttribute("_slideTarget", nil)
						end
					end)
				end
			else
				return
			end
		end
		local function v_u_400() -- name: build
			-- upvalues: (ref) v_u_34, (copy) v_u_11, (copy) v_u_32, (copy) v_u_383, (ref) v_u_27, (copy) v_u_46, (ref) v_u_33, (ref) v_u_35, (copy) v_u_30, (ref) v_u_43, (ref) v_u_37
			if v_u_34 then
				v_u_34:Destroy()
			end
			local v397 = v_u_11.new("Frame", {
				["Name"] = "Body",
				["Size"] = nil,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v_u_32
			})
			v_u_34 = v397
			local v398 = v_u_383[v_u_27](v397)
			v398.version = v_u_27
			v398.compact = v_u_11.Compact
			local v399
			if v398.signature then
				v399 = v398.signature()
			else
				v399 = nil
			end
			v398.sig = v399
			v398.fight.Activated:Connect(v_u_46)
			v_u_33 = v398
			v_u_35 = false
			v_u_11.ResetFade(v_u_30)
			v_u_43()
			if v_u_37 and v_u_11.Gamepad then
				game:GetService("GuiService").SelectedObject = v_u_33.fight.Instance
			end
		end
		if v_u_27 == "Classic" then
			v_u_400()
		end
		v_u_11.LayoutChanged:Connect(function()
			-- upvalues: (ref) v_u_33, (copy) v_u_400, (ref) v_u_35, (copy) v_u_11, (ref) v_u_39, (ref) v_u_36, (ref) v_u_43
			if v_u_33 then
				if v_u_33 then
					if (v_u_35 or v_u_33.compact ~= v_u_11.Compact) and (not v_u_39 and v_u_36 <= os.clock()) then
						v_u_400()
					end
				else
					v_u_400()
				end
			end
			v_u_43()
		end)
		v_u_11.ScaleChanged:Connect(v_u_43)
		v_u_13.ProfileChanged:Connect(function()
			-- upvalues: (ref) v_u_33, (ref) v_u_35
			if v_u_33 and v_u_33.signature then
				if v_u_33.signature() == v_u_33.sig then
					if v_u_33.refresh then
						v_u_33.refresh()
					end
				else
					v_u_35 = true
				end
			else
				return
			end
		end)
		local v_u_401 = {}
		local function v_u_406(p402) -- name: setVersion
			-- upvalues: (copy) v_u_383, (ref) v_u_39, (ref) v_u_36, (ref) v_u_27, (ref) v_u_33, (copy) v_u_400, (copy) v_u_401, (copy) v_u_18, (ref) v_u_37
			if type(p402) ~= "string" or (not v_u_383[p402] or (v_u_39 or os.clock() < v_u_36)) then
				return false
			end
			if p402 ~= v_u_27 then
				v_u_27 = p402
				if v_u_33 then
					v_u_400()
				end
				for v403, v404 in v_u_401 do
					local v405
					if v403 == v_u_27 then
						v405 = v_u_18.Accent
					else
						v405 = v_u_18.Raised
					end
					v404.BackgroundColor3 = v405
				end
				if v_u_37 and (v_u_33 and v_u_33.opened) then
					v_u_33.opened()
				end
			end
			return true
		end
		local v_u_407
		if v26 then
			local v_u_408 = v_u_11.new("Frame", {
				["Name"] = "VersionSwitch",
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 6),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["BackgroundColor3"] = v_u_18.Void,
				["BackgroundTransparency"] = 0.2,
				v_u_11.Corner(v_u_12.Radius.Pill),
				v_u_11.Padding(4, 5, 4, 14),
				v_u_11.List(Enum.FillDirection.Horizontal, 5, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
				["Parent"] = v_u_28
			})
			local v_u_409 = v_u_11.new("TextLabel", {
				["Name"] = "Label",
				["AutomaticSize"] = nil,
				["Size"] = nil,
				["Text"] = "STAGING PREVIEW",
				["FontFace"] = nil,
				["TextColor3"] = nil,
				["LayoutOrder"] = 0,
				["Parent"] = nil,
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["Size"] = UDim2.new(0, 0, 1, 0),
				["FontFace"] = v_u_19.Heavy,
				["TextColor3"] = v_u_18.TextMuted,
				["Parent"] = v_u_408
			})
			v_u_407 = v_u_27
			for v410, v_u_411 in v_u_6 do
				local v412 = v_u_11.new("TextButton", {
					["Name"] = v_u_411.id,
					["BackgroundColor3"] = v_u_18.Raised,
					["Text"] = v_u_411.chip,
					["FontFace"] = v_u_19.Heavy,
					["TextColor3"] = v_u_18.Text,
					["LayoutOrder"] = v410,
					v_u_11.Corner(v_u_12.Radius.Pill),
					["Parent"] = v_u_408
				})
				v412.Activated:Connect(function()
					-- upvalues: (copy) p_u_10, (copy) v_u_406, (copy) v_u_411
					p_u_10.Sounds.Play("Click")
					v_u_406(v_u_411.id)
				end)
				v_u_401[v_u_411.id] = v412
			end
			local function v415() -- name: sizeSwitch
				-- upvalues: (copy) v_u_11, (copy) v_u_408, (copy) v_u_409, (copy) v_u_401
				local v413 = v_u_11.Compact
				v_u_408.Size = UDim2.fromOffset(0, v413 and 54 or 40)
				v_u_409.TextSize = v413 and 15 or 13
				for _, v414 in v_u_401 do
					v414.Size = UDim2.fromOffset(v413 and 74 or 52, v413 and 46 or 32)
					v414.TextSize = v413 and 18 or 15
				end
			end
			v415()
			v_u_11.LayoutChanged:Connect(v415)
			for v416, v417 in v_u_401 do
				local v418
				if v416 == v_u_407 then
					v418 = v_u_18.Accent
				else
					v418 = v_u_18.Raised
				end
				v417.BackgroundColor3 = v418
			end
		else
			v_u_407 = v_u_27
		end
		local v421 = {
			["blur"] = false,
			["back"] = nil,
			["open"] = nil,
			["close"] = nil,
			["back"] = function() -- name: back
				-- upvalues: (copy) v_u_11, (ref) v_u_33
				if v_u_11.Gamepad then
					game:GetService("GuiService").SelectedObject = v_u_33.fight.Instance
				end
				return true
			end,
			["open"] = function() -- name: open
				-- upvalues: (ref) v_u_40, (ref) v_u_37, (ref) v_u_39, (ref) v_u_41, (ref) v_u_33, (copy) v_u_400, (ref) v_u_35, (copy) v_u_11, (ref) v_u_36, (copy) p_u_10, (ref) v_u_43, (copy) v_u_28, (copy) v_u_29, (copy) v_u_30, (copy) v_u_24, (copy) v_u_13
				v_u_40 = v_u_40 + 1
				v_u_37 = true
				v_u_39 = false
				v_u_41 = false
				if v_u_33 then
					if (v_u_35 or v_u_33.compact ~= v_u_11.Compact) and (not v_u_39 and v_u_36 <= os.clock()) then
						v_u_400()
					end
				else
					v_u_400()
				end
				v_u_33.fight:SetText("FIGHT")
				p_u_10.SetHudHidden("Welcome", true)
				if p_u_10.TopbarSettings then
					p_u_10.TopbarSettings.SetHidden("Welcome", true)
				end
				v_u_43()
				v_u_28.Visible = true
				v_u_29.Visible = true
				v_u_29.BackgroundTransparency = 1
				v_u_11.Tween(v_u_29, TweenInfo.new(0.35, Enum.EasingStyle.Quad), {
					["BackgroundTransparency"] = 0.5
				})
				v_u_11.Enter(v_u_30, Vector2.new(0, 28), 0.05, v_u_30.Position)
				p_u_10.Sounds.Play("Open")
				if not v_u_24.Welcome and (not v_u_13.Mock and p_u_10.Remotes.Fire("AnalyticsReport", "Welcome", nil)) then
					v_u_24.Welcome = true
				end
				if v_u_11.Gamepad then
					game:GetService("GuiService").SelectedObject = v_u_33.fight.Instance
				end
				if v_u_33.opened then
					v_u_33.opened()
				end
			end,
			["close"] = function(p419) -- name: close
				-- upvalues: (ref) v_u_40, (ref) v_u_37, (ref) v_u_41, (copy) p_u_10, (ref) v_u_38, (copy) v_u_13, (copy) v_u_11, (copy) v_u_29, (copy) v_u_28, (ref) v_u_36, (copy) v_u_30
				v_u_40 = v_u_40 + 1
				local v_u_420 = v_u_40
				v_u_37 = false
				if not v_u_41 then
					p_u_10.SetHudHidden("Welcome", false)
					if p_u_10.TopbarSettings then
						p_u_10.TopbarSettings.SetHidden("Welcome", false)
					end
					if not (v_u_38 or v_u_13.InMatch()) then
						v_u_38 = true
						task.spawn(p_u_10.QueueAction, "DismissWelcome")
					end
				end
				v_u_11.Tween(v_u_29, TweenInfo.new(p419 and 0 or 0.2), {
					["BackgroundTransparency"] = 1
				})
				if p419 then
					v_u_28.Visible = false
					v_u_29.Visible = false
				else
					v_u_36 = os.clock() + 0.3
					v_u_11.FadeOut(v_u_30, TweenInfo.new(0.16))
					task.delay(0.2, function()
						-- upvalues: (copy) v_u_420, (ref) v_u_40, (ref) v_u_28, (ref) v_u_29, (ref) v_u_11, (ref) v_u_30
						if v_u_420 == v_u_40 then
							v_u_28.Visible = false
							v_u_29.Visible = false
							v_u_11.Unfade(v_u_30)
						end
					end)
				end
			end
		}
		v_u_14.Register("Welcome", v421)
		v_u_13.PlayerStateChanged:Connect(function()
			-- upvalues: (copy) v_u_13, (ref) v_u_38, (copy) v_u_20, (copy) v_u_14
			if v_u_13.InMatch() then
				v_u_38 = v_u_38 or v_u_20:GetAttribute("WelcomeCard") ~= true
				if v_u_14.IsOpen("Welcome") then
					v_u_14.Close("Welcome", true)
				end
			end
		end)
		local function v_u_423() -- name: detourTick
			-- upvalues: (ref) v_u_41, (ref) v_u_37, (copy) v_u_14, (ref) v_u_42, (copy) v_u_20, (ref) v_u_38, (copy) v_u_13, (copy) p_u_10
			if v_u_41 and not v_u_37 then
				if v_u_14.IsOpen() then
					v_u_42 = 0
					return
				else
					v_u_42 = v_u_42 + 0.1
					if v_u_42 < 0.2 then
						return
					else
						local v422 = v_u_20:GetAttribute("WelcomeCard") == true and not v_u_38
						if v422 then
							v422 = not v_u_37
						end
						if v422 and (v_u_20:GetAttribute("LoadingShownMs") ~= nil and (not v_u_13.InMatch() and (v_u_13.Get("Queued") ~= true and v_u_13.Get("Teleporting") ~= true))) then
							v_u_14.Open("Welcome")
						else
							v_u_41 = false
							p_u_10.SetHudHidden("Welcome", false)
							if p_u_10.TopbarSettings then
								p_u_10.TopbarSettings.SetHidden("Welcome", false)
							end
						end
					end
				end
			else
				return
			end
		end
		local v_u_424 = {
			{
				["spread"] = 3,
				["t"] = 0.5
			},
			{
				["spread"] = 8,
				["t"] = 0.7
			},
			{
				["spread"] = 14,
				["t"] = 0.83
			},
			{
				["spread"] = 21,
				["t"] = 0.92
			}
		}
		local v425 = Color3.fromRGB(150, 210, 255)
		local v_u_426 = v_u_11.new("Frame", {
			["Name"] = "NudgeGlow",
			["Size"] = nil,
			["ZIndex"] = 0,
			["Visible"] = false,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v_u_22.Instance
		})
		local v_u_427 = {}
		local v_u_428 = false
		local v_u_429 = false
		local v_u_430 = false
		local v_u_431 = nil
		local function v_u_433() -- name: readyForCard
			-- upvalues: (copy) v_u_20, (copy) v_u_13, (copy) p_u_10, (copy) v_u_14
			local v432 = v_u_20:GetAttribute("LoadingShownMs") ~= nil and v_u_13.HasProfile and (not (v_u_13.InMatch() or p_u_10.HudHidden) and (v_u_20.Character ~= nil and not v_u_14.IsOpen()))
			if v432 then
				if v_u_13.Get("Queued") == true then
					v432 = false
				else
					v432 = v_u_13.Get("Teleporting") ~= true
				end
			end
			return v432
		end
		local v_u_434 = 0
		for v435, v436 in v_u_424 do
			v_u_427[v435] = v_u_11.new("Frame", {
				["Name"] = "Halo" .. v435,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.new(1, v436.spread * 2, 1, v436.spread * 2),
				["BackgroundColor3"] = v_u_18.Accent,
				["BackgroundTransparency"] = 1,
				["ZIndex"] = 0,
				v_u_11.Corner(16 + v436.spread),
				["Parent"] = v_u_426
			})
		end
		local v_u_437 = v_u_11.new("Frame", {
			["Name"] = "Ripple",
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromScale(1, 1),
			["ZIndex"] = 0,
			v_u_11.Corner(16),
			["Parent"] = v_u_426
		})
		local v_u_438 = v_u_11.Stroke(v425, 2, 1)
		v_u_438.Parent = v_u_437
		local v_u_439 = Instance.new("NumberValue")
		v_u_439.Parent = v_u_426
		local v_u_440 = 0
		local function v444() -- name: paintGlow
			-- upvalues: (ref) v_u_440, (copy) v_u_439, (copy) v_u_424, (copy) v_u_427
			local v441 = v_u_440 * (0.55 + 0.45 * v_u_439.Value)
			for v442, v443 in v_u_424 do
				v_u_427[v442].BackgroundTransparency = 1 - (1 - v443.t) * v441
			end
		end
		v_u_439.Changed:Connect(v444)
		local v_u_445 = nil
		local v_u_446 = 0
		local function v_u_456(p447, p448, p_u_449) -- name: fadeGlow
			-- upvalues: (ref) v_u_440, (copy) v_u_439, (copy) v_u_424, (copy) v_u_427, (ref) v_u_4
			local v_u_450 = Instance.new("NumberValue")
			v_u_450.Value = v_u_440
			v_u_450.Changed:Connect(function(p451)
				-- upvalues: (ref) v_u_440, (ref) v_u_439, (ref) v_u_424, (ref) v_u_427
				v_u_440 = p451
				local v452 = v_u_440 * (0.55 + 0.45 * v_u_439.Value)
				for v453, v454 in v_u_424 do
					v_u_427[v453].BackgroundTransparency = 1 - (1 - v454.t) * v452
				end
			end)
			local v455 = v_u_4:Create(v_u_450, TweenInfo.new(p448, Enum.EasingStyle.Quad), {
				["Value"] = p447
			})
			v455.Completed:Connect(function()
				-- upvalues: (copy) v_u_450, (copy) p_u_449
				v_u_450:Destroy()
				if p_u_449 then
					p_u_449()
				end
			end)
			v455:Play()
		end
		local function v_u_461(p457) -- name: setGlow
			-- upvalues: (ref) v_u_428, (ref) v_u_446, (ref) v_u_445, (copy) v_u_426, (copy) v_u_439, (copy) v_u_456, (ref) v_u_4, (copy) v_u_437, (copy) v_u_438, (copy) v_u_11, (copy) v_u_24, (copy) v_u_13, (copy) p_u_10
			if p457 ~= v_u_428 then
				v_u_428 = p457
				v_u_446 = v_u_446 + 1
				local v_u_458 = v_u_446
				if v_u_445 then
					v_u_445:Cancel()
					v_u_445 = nil
				end
				if p457 then
					v_u_426.Visible = true
					v_u_439.Value = 0
					v_u_456(1, 0.6)
					local v459 = v_u_4:Create(v_u_439, TweenInfo.new(1.4, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
						["Value"] = 1
					})
					v_u_445 = v459
					v459:Play()
					task.spawn(function()
						-- upvalues: (copy) v_u_458, (ref) v_u_446, (ref) v_u_437, (ref) v_u_438, (ref) v_u_11
						task.wait(0.8)
						while v_u_458 == v_u_446 do
							v_u_437.Size = UDim2.fromScale(1, 1)
							v_u_438.Transparency = 0.25
							local v460 = TweenInfo.new(1.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
							v_u_11.Tween(v_u_437, v460, {
								["Size"] = UDim2.new(1, 52, 1, 52)
							})
							v_u_11.Tween(v_u_438, v460, {
								["Transparency"] = 1
							})
							task.wait(2.6)
						end
					end)
					if not v_u_24["Nudge:Glow"] then
						if v_u_13.Mock then
							return
						end
						if p_u_10.Remotes.Fire("AnalyticsReport", "Nudge", "Glow") then
							v_u_24["Nudge:Glow"] = true
							return
						end
					end
				else
					v_u_438.Transparency = 1
					v_u_456(0, 0.15, function()
						-- upvalues: (copy) v_u_458, (ref) v_u_446, (ref) v_u_426
						if v_u_458 == v_u_446 then
							v_u_426.Visible = false
						end
					end)
				end
			end
		end
		local v_u_462 = v_u_11.Panel({
			["Name"] = "PlayCallout",
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["BackgroundTransparency"] = 0.08,
			["StrokeColor"] = nil,
			["StrokeTransparency"] = 0.4,
			["StrokeThickness"] = 1.5,
			["Radius"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Size"] = UDim2.fromOffset(0, 52),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["StrokeColor"] = v_u_18.Accent,
			["Radius"] = UDim.new(0, 14),
			["Parent"] = v_u_21.Root
		})
		v_u_11.Padding(0, 10, 0, 18).Parent = v_u_462
		local v463 = v_u_11.new("Frame", {
			["Name"] = "Row",
			["Size"] = UDim2.fromScale(0, 1),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			v_u_11.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
			["Parent"] = v_u_462
		})
		local v_u_464 = v_u_11.new("TextLabel", {
			["Name"] = "Text",
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Text"] = "Start your first match",
			["FontFace"] = nil,
			["TextSize"] = 20,
			["TextColor3"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Size"] = UDim2.new(0, 0, 1, 0),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["FontFace"] = v_u_19.Heavy,
			["TextColor3"] = v_u_18.Text,
			["Parent"] = v463
		})
		local v465 = v_u_11.new("Frame", {
			["Name"] = "Arrow",
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(30, 30),
			["Parent"] = v463
		})
		local v_u_466 = v_u_11.new("Frame", {
			["Name"] = "Bob",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(30, 30),
			["Parent"] = v465
		})
		local v_u_467 = v_u_11.Icon("chevRight", 22, v_u_18.Accent, {
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Parent"] = v_u_466
		})
		local v_u_468 = nil
		local v_u_469 = 0
		local function v_u_476() -- name: placeCallout
			-- upvalues: (copy) v_u_11, (copy) v_u_22, (copy) v_u_21, (copy) v_u_462
			local v470 = v_u_11.Scale
			local v471 = math.max(v470, 0.01)
			local v472 = v_u_22.Instance
			local v473 = v_u_21.Root
			local v474 = (v472.AbsolutePosition.X - v473.AbsolutePosition.X) / v471 - 14
			local v475 = (v472.AbsolutePosition.Y - v473.AbsolutePosition.Y) / v471 + (v472.AbsoluteSize.Y / v471 - 3) / 2
			v_u_462.Position = UDim2.fromOffset(math.floor(v474), (math.floor(v475)))
		end
		local v477 = v_u_11.Compact
		v_u_464.TextSize = v477 and 22 or 20
		v_u_462.Size = UDim2.fromOffset(0, v477 and 56 or 52)
		v_u_467.Size = UDim2.fromOffset(v477 and 24 or 22, v477 and 24 or 22)
		v_u_11.LayoutChanged:Connect(function() -- name: sizeCallout
			-- upvalues: (copy) v_u_11, (copy) v_u_464, (copy) v_u_462, (copy) v_u_467
			local v478 = v_u_11.Compact
			v_u_464.TextSize = v478 and 22 or 20
			v_u_462.Size = UDim2.fromOffset(0, v478 and 56 or 52)
			v_u_467.Size = UDim2.fromOffset(v478 and 24 or 22, v478 and 24 or 22)
		end)
		v_u_22.Instance:GetPropertyChangedSignal("AbsolutePosition"):Connect(function()
			-- upvalues: (ref) v_u_430, (copy) v_u_476
			if v_u_430 then
				v_u_476()
			end
		end)
		v_u_22.Instance:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
			-- upvalues: (ref) v_u_430, (copy) v_u_476
			if v_u_430 then
				v_u_476()
			end
		end)
		local function v_u_482(p479) -- name: setCallout
			-- upvalues: (ref) v_u_430, (ref) v_u_469, (ref) v_u_468, (copy) v_u_466, (copy) v_u_476, (copy) v_u_11, (copy) v_u_462, (ref) v_u_4, (copy) v_u_24, (copy) v_u_13, (copy) p_u_10
			if p479 ~= v_u_430 then
				v_u_430 = p479
				v_u_469 = v_u_469 + 1
				local v_u_480 = v_u_469
				if v_u_468 then
					v_u_468:Cancel()
					v_u_468 = nil
					v_u_466.Position = UDim2.fromScale(0.5, 0.5)
				end
				if p479 then
					v_u_476()
					v_u_11.Unfade(v_u_462)
					v_u_462.Visible = true
					v_u_11.Enter(v_u_462, Vector2.new(-18, 0), 0, v_u_462.Position)
					local v481 = v_u_4:Create(v_u_466, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
						["Position"] = UDim2.new(0.5, 5, 0.5, 0)
					})
					v_u_468 = v481
					v481:Play()
					if not v_u_24["Nudge:Callout"] then
						if v_u_13.Mock then
							return
						end
						if p_u_10.Remotes.Fire("AnalyticsReport", "Nudge", "Callout") then
							v_u_24["Nudge:Callout"] = true
							return
						end
					end
				else
					v_u_11.FadeOut(v_u_462, TweenInfo.new(0.14))
					task.delay(0.16, function()
						-- upvalues: (copy) v_u_480, (ref) v_u_469, (ref) v_u_462, (ref) v_u_11
						if v_u_480 == v_u_469 then
							v_u_462.Visible = false
							v_u_11.Unfade(v_u_462)
						end
					end)
				end
			end
		end
		v_u_22.Activated:Connect(function()
			-- upvalues: (ref) v_u_429, (ref) v_u_428, (ref) v_u_446, (ref) v_u_445, (copy) v_u_438, (copy) v_u_456, (copy) v_u_426, (ref) v_u_430, (ref) v_u_469, (ref) v_u_468, (copy) v_u_466, (copy) v_u_11, (copy) v_u_462
			v_u_429 = true
			if v_u_428 ~= false then
				v_u_428 = false
				v_u_446 = v_u_446 + 1
				local v_u_483 = v_u_446
				if v_u_445 then
					v_u_445:Cancel()
					v_u_445 = nil
				end
				v_u_438.Transparency = 1
				v_u_456(0, 0.15, function()
					-- upvalues: (copy) v_u_483, (ref) v_u_446, (ref) v_u_426
					if v_u_483 == v_u_446 then
						v_u_426.Visible = false
					end
				end)
			end
			if v_u_430 ~= false then
				v_u_430 = false
				v_u_469 = v_u_469 + 1
				local v_u_484 = v_u_469
				if v_u_468 then
					v_u_468:Cancel()
					v_u_468 = nil
					v_u_466.Position = UDim2.fromScale(0.5, 0.5)
				end
				v_u_11.FadeOut(v_u_462, TweenInfo.new(0.14))
				task.delay(0.16, function()
					-- upvalues: (copy) v_u_484, (ref) v_u_469, (ref) v_u_462, (ref) v_u_11
					if v_u_484 == v_u_469 then
						v_u_462.Visible = false
						v_u_11.Unfade(v_u_462)
					end
				end)
			end
		end)
		v_u_11.Every(v_u_28, 0.1, function()
			-- upvalues: (copy) v_u_20, (copy) v_u_13, (copy) v_u_21, (copy) v_u_24, (copy) p_u_10, (ref) v_u_33, (copy) v_u_400, (ref) v_u_35, (copy) v_u_11, (ref) v_u_39, (ref) v_u_36, (copy) v_u_423, (ref) v_u_38, (ref) v_u_37, (copy) v_u_433, (ref) v_u_431, (copy) v_u_14, (ref) v_u_429, (copy) v_u_22, (ref) v_u_434, (copy) v_u_461, (copy) v_u_482
			local v485 = v_u_20:GetAttribute("LoadingShownMs") ~= nil and (v_u_13.HasProfile and not v_u_13.InMatch())
			if v485 then
				v485 = v_u_21.Root.Visible
			end
			if v485 then
				local v486 = time() * 10
				local v487 = math.floor(v486) / 10
				local v488 = "Loaded" .. (type(v487) ~= "string" and "" or ":" .. v487)
				if not v_u_24[v488] and (not v_u_13.Mock and p_u_10.Remotes.Fire("AnalyticsReport", "Loaded", v487)) then
					v_u_24[v488] = true
				end
			end
			if v_u_33 then
				if v_u_33 then
					if (v_u_35 or v_u_33.compact ~= v_u_11.Compact) and (not v_u_39 and v_u_36 <= os.clock()) then
						v_u_400()
					end
				else
					v_u_400()
				end
			end
			v_u_423()
			local v489 = v_u_20:GetAttribute("WelcomeCard") == true and not v_u_38
			if v489 then
				v489 = not v_u_37
			end
			if v489 and v_u_433() then
				v_u_431 = v_u_431 or os.clock()
				if os.clock() - v_u_431 >= 0.6 then
					v_u_431 = nil
					v_u_14.Open("Welcome")
				end
			else
				v_u_431 = nil
			end
			local v490
			if v_u_429 or (v_u_13.Mock or not v_u_13.HasProfile) then
				v490 = false
			else
				local v491 = v_u_13.Profile
				if v491 then
					v491 = v_u_13.Profile.stats
				end
				if type(v491) == "table" then
					local v492 = v491.matches
					if (tonumber(v492) or 0) > 0 then
						v490 = false
					else
						v490 = v_u_20:GetAttribute("WelcomeCard") ~= true
					end
				else
					v490 = false
				end
			end
			if v490 then
				local v493 = v_u_20:GetAttribute("LoadingShownMs") ~= nil and (v_u_13.HasProfile and not v_u_13.InMatch())
				if v493 then
					v493 = v_u_21.Root.Visible
				end
				v490 = v493 and (v_u_22.Instance.Visible and not v_u_14.IsOpen())
				if v490 then
					v490 = v_u_13.Get("Queued") ~= true
				end
			end
			if v490 then
				v_u_434 = v_u_434 + 0.1
			end
			v_u_461(v490)
			local v494 = v_u_482
			if v490 then
				if v_u_434 >= 6 then
					v490 = v_u_13.Get("CombatMode") ~= true
				else
					v490 = false
				end
			end
			v494(v490)
		end)
		if v_u_3:IsStudio() or game.PlaceId == v23.STAGING_PLACE_ID then
			function p_u_10.ReplayNewPlayer(p495)
				-- upvalues: (copy) p_u_10, (ref) v_u_38, (ref) v_u_39, (ref) v_u_429, (ref) v_u_434, (ref) v_u_431, (ref) v_u_41, (ref) v_u_428, (ref) v_u_446, (ref) v_u_445, (copy) v_u_438, (copy) v_u_456, (copy) v_u_426, (ref) v_u_430, (ref) v_u_469, (ref) v_u_468, (copy) v_u_466, (copy) v_u_11, (copy) v_u_462, (copy) v_u_24, (copy) v_u_14
				local v496 = p_u_10.QueueAction(p495 and "ReplayFullHub" or "ReplayNewPlayer")
				if v496 then
					v_u_38 = false
					v_u_39 = false
					v_u_429 = false
					v_u_434 = 0
					v_u_431 = nil
					if v_u_41 then
						v_u_41 = false
						p_u_10.SetHudHidden("Welcome", false)
						if p_u_10.TopbarSettings then
							p_u_10.TopbarSettings.SetHidden("Welcome", false)
						end
					end
					if v_u_428 ~= false then
						v_u_428 = false
						v_u_446 = v_u_446 + 1
						local v_u_497 = v_u_446
						if v_u_445 then
							v_u_445:Cancel()
							v_u_445 = nil
						end
						v_u_438.Transparency = 1
						v_u_456(0, 0.15, function()
							-- upvalues: (copy) v_u_497, (ref) v_u_446, (ref) v_u_426
							if v_u_497 == v_u_446 then
								v_u_426.Visible = false
							end
						end)
					end
					if v_u_430 ~= false then
						v_u_430 = false
						v_u_469 = v_u_469 + 1
						local v_u_498 = v_u_469
						if v_u_468 then
							v_u_468:Cancel()
							v_u_468 = nil
							v_u_466.Position = UDim2.fromScale(0.5, 0.5)
						end
						v_u_11.FadeOut(v_u_462, TweenInfo.new(0.14))
						task.delay(0.16, function()
							-- upvalues: (copy) v_u_498, (ref) v_u_469, (ref) v_u_462, (ref) v_u_11
							if v_u_498 == v_u_469 then
								v_u_462.Visible = false
								v_u_11.Unfade(v_u_462)
							end
						end)
					end
					table.clear(v_u_24)
					v_u_14.CloseAll()
					p_u_10.Toast(p495 and "Full hub: FIGHT sends you to a match server" or "New-player flow reset", "success")
				end
				return v496
			end
		end
		function p_u_10.Debug.onboarding(p499, p500)
			-- upvalues: (copy) v_u_46, (copy) v_u_47, (copy) v_u_48, (copy) v_u_406, (ref) v_u_33, (ref) v_u_38, (ref) v_u_39, (ref) v_u_429, (ref) v_u_434, (ref) v_u_431, (ref) v_u_41, (copy) p_u_10, (ref) v_u_428, (ref) v_u_446, (ref) v_u_445, (copy) v_u_438, (copy) v_u_456, (copy) v_u_426, (ref) v_u_430, (ref) v_u_469, (ref) v_u_468, (copy) v_u_466, (copy) v_u_11, (copy) v_u_462, (copy) v_u_24, (copy) v_u_20, (ref) v_u_37, (ref) v_u_407, (copy) v_u_30, (copy) v_u_31, (copy) v_u_433, (copy) v_u_13, (copy) v_u_21, (copy) v_u_22, (copy) v_u_14
			if p499 == "fight" then
				task.spawn(v_u_46)
			elseif p499 == "explore" then
				task.spawn(v_u_47)
			elseif p499 == "customize" then
				task.spawn(v_u_48)
			else
				if p499 == "version" then
					return v_u_406(p500)
				end
				if p499 == "pick" then
					if not v_u_33 or (not v_u_33.pick or type(p500) ~= "number") then
						return false
					end
					task.spawn(v_u_33.pick, p500)
				elseif p499 == "reset" then
					v_u_38 = false
					v_u_39 = false
					v_u_429 = false
					v_u_434 = 0
					v_u_431 = nil
					if v_u_41 then
						v_u_41 = false
						p_u_10.SetHudHidden("Welcome", false)
						if p_u_10.TopbarSettings then
							p_u_10.TopbarSettings.SetHidden("Welcome", false)
						end
					end
					if v_u_428 ~= false then
						v_u_428 = false
						v_u_446 = v_u_446 + 1
						local v_u_501 = v_u_446
						if v_u_445 then
							v_u_445:Cancel()
							v_u_445 = nil
						end
						v_u_438.Transparency = 1
						v_u_456(0, 0.15, function()
							-- upvalues: (copy) v_u_501, (ref) v_u_446, (ref) v_u_426
							if v_u_501 == v_u_446 then
								v_u_426.Visible = false
							end
						end)
					end
					if v_u_430 ~= false then
						v_u_430 = false
						v_u_469 = v_u_469 + 1
						local v_u_502 = v_u_469
						if v_u_468 then
							v_u_468:Cancel()
							v_u_468 = nil
							v_u_466.Position = UDim2.fromScale(0.5, 0.5)
						end
						v_u_11.FadeOut(v_u_462, TweenInfo.new(0.14))
						task.delay(0.16, function()
							-- upvalues: (copy) v_u_502, (ref) v_u_469, (ref) v_u_462, (ref) v_u_11
							if v_u_502 == v_u_469 then
								v_u_462.Visible = false
								v_u_11.Unfade(v_u_462)
							end
						end)
					end
					table.clear(v_u_24)
				elseif p499 == "callout" then
					local v503 = v_u_434
					v_u_434 = math.max(v503, 6)
				end
			end
			local v504 = {}
			for v505 in v_u_24 do
				table.insert(v504, v505)
			end
			table.sort(v504)
			local v506 = {
				["want"] = v_u_20:GetAttribute("WelcomeCard") == true,
				["card"] = v_u_37,
				["version"] = v_u_407
			}
			local v507 = v_u_33
			if v507 then
				v507 = v_u_33.version
			end
			v506.built = v507
			v506.detour = v_u_41
			v506.size = string.format("%dx%d @%.2f", v_u_30.Size.X.Offset, v_u_30.Size.Y.Offset, v_u_31.Scale)
			v506.answered = v_u_38
			v506.ready = v_u_433()
			local v508 = v_u_20:GetAttribute("LoadingShownMs") ~= nil and (v_u_13.HasProfile and not v_u_13.InMatch())
			if v508 then
				v508 = v_u_21.Root.Visible
			end
			v506.lobbyShown = v508
			local v509
			if v_u_429 or (v_u_13.Mock or not v_u_13.HasProfile) then
				v509 = false
			else
				local v510 = v_u_13.Profile
				if v510 then
					v510 = v_u_13.Profile.stats
				end
				if type(v510) == "table" then
					local v511 = v510.matches
					if (tonumber(v511) or 0) > 0 then
						v509 = false
					else
						v509 = v_u_20:GetAttribute("WelcomeCard") ~= true
					end
				else
					v509 = false
				end
			end
			v506.eligible = v509
			local v512 = v_u_20:GetAttribute("LoadingShownMs") ~= nil and (v_u_13.HasProfile and not v_u_13.InMatch())
			if v512 then
				v512 = v_u_21.Root.Visible
			end
			local v513 = v512 and (v_u_22.Instance.Visible and not v_u_14.IsOpen())
			if v513 then
				v513 = v_u_13.Get("Queued") ~= true
			end
			v506.playOnScreen = v513
			v506.glow = v_u_428
			v506.callout = v_u_430
			local v514 = v_u_434 * 10
			v506.onScreen = math.floor(v514) / 10
			v506.pressed = v_u_429
			v506.sent = table.concat(v504, ",")
			return v506
		end
	end
end
return v5