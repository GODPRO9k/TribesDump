local v1 = script.Parent.Parent
local v_u_2 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Simulation"))
local v_u_3 = require(v1.Util)
local v_u_4 = require(v1.Hud)
local v_u_5 = require(v1.Effects)
local v_u_6 = require(v1.Guard)
local v_u_7 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Combat"))
require(v1.Touch)
local v_u_8 = {}
v_u_8.__index = v_u_8
function v_u_8.new(p9) -- name: new
	-- upvalues: (copy) v_u_8
	local v10 = v_u_8
	local v11 = setmetatable({}, v10)
	v11.ctx = p9
	v11.tuning = p9.tuning
	v11.preset = p9.preset
	v11.lastSwing = 0
	v11.combo = 0
	v11.holding = false
	v11.busyUntil = 0
	v11.blocking = false
	v11.blockHeld = false
	v11.guardFirst = false
	v11.strikes = 0
	v11.charging = nil
	v11.chargeStart = 0
	v11.lastSpecial = (-1 / 0)
	v11.bufferedAt = nil
	v11.fullPlayed = false
	v11.lastThrow = (-1 / 0)
	v11.thrownLocalUntil = 0
	v11.parryHeld = false
	v11.parrying = false
	v11.parryReadyAt = 0
	v11.lastParryUp = (-1 / 0)
	v11.parryUpAt = 0
	v11.conns = {}
	return v11
end
function v_u_8.OneHanded(p12) -- name: OneHanded
	local v13 = p12.tuning.oneHanded
	if type(v13) ~= "table" then
		return false
	end
	local v14 = p12.ctx.tool
	return v14 ~= nil and v14:GetAttribute("Thrown") == true and true or os.clock() < p12.thrownLocalUntil
end
function v_u_8.Cooldown(p15) -- name: Cooldown
	return p15:OneHanded() and (p15.tuning.oneHanded.cooldown or 0.45) or (p15.tuning.cooldown or 0.5)
end
function v_u_8.Equip(p_u_16) -- name: Equip
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_7
	local v_u_17 = p_u_16.ctx
	v_u_4.SetStyle("Melee")
	if p_u_16.preset.hold then
		v_u_3.PlayAnim(v_u_17.animator, p_u_16.preset.hold, 1, 0.2)
	end
	if p_u_16.preset.equip and v_u_17.tool then
		v_u_3.Sound(p_u_16.preset.equip, v_u_17.root)
	end
	local v_u_18 = v_u_17.tool
	local v19 = p_u_16.tuning.lunge
	if v_u_18 and (type(v19) == "table" and v19.refreshOnKill) then
		local v20 = p_u_16.conns
		local v21 = v_u_18:GetAttributeChangedSignal("Refreshed")
		local function v22()
			-- upvalues: (copy) p_u_16, (ref) v_u_4, (ref) v_u_3, (copy) v_u_17
			p_u_16.lastSpecial = (-1 / 0)
			v_u_4.SetArc(0)
			v_u_3.Sound(p_u_16.preset.refreshSound or "Charge_Full", v_u_17.root)
			v_u_17.emit("Refresh", {})
		end
		table.insert(v20, v21:Connect(v22))
	end
	if v_u_18 then
		local v23 = p_u_16.tuning.throw
		if type(v23) == "table" then
			local v_u_24 = v_u_18:GetAttribute("Thrown") == true
			local v25 = p_u_16.conns
			local v26 = v_u_18:GetAttributeChangedSignal("Thrown")
			local function v28()
				-- upvalues: (copy) v_u_18, (ref) v_u_24, (copy) p_u_16, (ref) v_u_7, (copy) v_u_17
				local v27 = v_u_18:GetAttribute("Thrown") == true
				if v27 ~= v_u_24 then
					v_u_24 = v27
					p_u_16.thrownLocalUntil = 0
					v_u_7.ShowOffHand(v_u_18, not v27)
					if not v27 then
						v_u_17.emit("Catch", {})
					end
				end
			end
			table.insert(v25, v26:Connect(v28))
		end
	end
end
function v_u_8.Unequip(p29) -- name: Unequip
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v30 = p29.ctx
	for _, v31 in p29.conns do
		v31:Disconnect()
	end
	table.clear(p29.conns)
	p29.holding = false
	p29.bufferedAt = nil
	if p29.blocking then
		p29:SetBlock(false)
	end
	p29.blockHeld = false
	p29.parryHeld = false
	p29:LowerParry(true, nil, true)
	if p29.charging then
		p29:CancelCharge()
	end
	if p29.preset.hold then
		v_u_3.StopAnim(v30.animator, p29.preset.hold, 0.15)
	end
	v_u_4.SetCharge(0)
end
function v_u_8.Detect(p32, p33, p34, p35) -- name: Detect
	-- upvalues: (copy) v_u_3
	local v36 = p32.ctx
	local v37 = v36.root
	local v38 = v36.char:FindFirstChild("Head")
	local v39
	if v38 then
		v39 = v38.Position
	else
		v39 = v37.Position
	end
	local v40 = v_u_3.GetAimRay()
	local v41 = v40.Direction.X
	local v42 = v40.Direction.Z
	local v43 = Vector3.new(v41, 0, v42)
	if v43.Magnitude < 0.05 then
		v43 = v37.CFrame.LookVector
	end
	local v44 = v43.Unit
	local v45 = math.rad(p34)
	local v46 = math.cos(v45)
	local v47 = v_u_3.Targets()
	local v48 = v_u_3.WorldParams(v47)
	local v49 = {}
	for _, v50 in v47 do
		if v_u_3.IsTeammate(v50) then
			continue
		end
		local v51 = v50:FindFirstChildOfClass("Humanoid")
		local v52 = v50:FindFirstChild("HumanoidRootPart")
		if not v51 or (not v52 or v51.Health <= 0) then
			continue
		end
		local v53 = v52.Position - v37.Position
		local v54 = v53.Magnitude
		if v54 > p33 + 1.2 then
			continue
		end
		local v55 = v53.Y
		if math.abs(v55) >= 8 then
			continue
		end
		local v56 = v53.X
		local v57 = v53.Z
		local v58 = Vector3.new(v56, 0, v57)
		local v59
		if v54 < 3.2 then
			v59 = true
		elseif v58.Magnitude > 0.05 then
			v59 = v46 <= v58.Unit:Dot(v44)
		else
			v59 = false
		end
		if not v59 or workspace:Raycast(v39, v52.Position - v39, v48) then
			continue
		end
		table.insert(v49, {
			["model"] = v50,
			["dist"] = v54
		})
	end
	table.sort(v49, function(p60, p61)
		return p60.dist < p61.dist
	end)
	local v62 = #v49
	local v63 = {}
	for v64 = 1, math.min(v62, p35) do
		local v65 = v49[v64].model
		table.insert(v63, v65)
	end
	return v63
end
local function v_u_82(p66, p67, p68, p69, p70, p71) -- name: predictImpacts
	-- upvalues: (copy) v_u_3, (copy) v_u_5
	if p68 then
		p68 = p68 * v_u_3.ItemBonus(p71)
	end
	for _, v72 in p66 do
		if not v_u_3.CanPredictHit(v72) then
			continue
		end
		local v73 = v72:FindFirstChild("UpperTorso") or (v72:FindFirstChild("Torso") or v72:FindFirstChild("HumanoidRootPart"))
		if not (v73 and v73:IsA("BasePart")) then
			continue
		end
		local v74 = false
		local v75 = v72:FindFirstChild("HumanoidRootPart")
		local v76
		if p68 and (p69 and (p69.backstabMult and (p70 and (v75 and v75:IsA("BasePart"))))) then
			local v77 = (p70.Position - v75.Position) * Vector3.new(1, 0, 1)
			local v78 = -(v75.CFrame.LookVector * Vector3.new(1, 0, 1))
			if v77.Magnitude > 0.05 and v78.Magnitude > 0.05 then
				local v79 = v77.Unit:Dot(v78.Unit)
				local v80 = p69.backstabAngle or 70
				local v81 = math.rad(v80)
				if math.cos(v81) <= v79 then
					v76 = p68 * p69.backstabMult
					v74 = true
				else
					v76 = p68
				end
			else
				v76 = p68
			end
		else
			v76 = p68
		end
		v_u_5.CharacterImpact(v73.Position, nil, false)
		v_u_5.PredictHit(v72, p67, v73.Position + Vector3.new(0, 1, 0), false, v76, v74)
	end
end
function v_u_8.Ready(p83) -- name: Ready
	local v84 = os.clock()
	local v85
	if p83.busyUntil <= v84 then
		v85 = v84 - p83.lastSwing >= p83:Cooldown()
	else
		v85 = false
	end
	return v85
end
function v_u_8.Swing(p_u_86) -- name: Swing
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_82
	local v_u_87 = p_u_86.ctx
	local v_u_88 = p_u_86.tuning
	local v_u_89 = p_u_86.preset
	local v_u_90 = os.clock()
	if not (p_u_86:Ready() and v_u_3.CanAct()) then
		return false
	end
	p_u_86.bufferedAt = nil
	local v91 = p_u_86:OneHanded()
	local v_u_92
	if v91 then
		v_u_92 = v_u_88.oneHanded.combo or { 1 }
	else
		v_u_92 = v_u_88.combo or { 1 }
	end
	if v_u_90 - p_u_86.lastSwing <= (v_u_88.comboWindow or 1) then
		p_u_86.combo = p_u_86.combo % #v_u_92 + 1
	else
		p_u_86.combo = 1
	end
	p_u_86.lastSwing = v_u_90
	local v_u_93 = p_u_86.combo
	local v_u_94
	if #v_u_92 > 2 then
		v_u_94 = v_u_93 == #v_u_92
	else
		v_u_94 = false
	end
	v_u_3.MeleeAssist(v_u_88.range or 8)
	v_u_3.FaceCamera()
	local v95
	if v91 then
		v95 = v_u_89.oneSwings
	else
		v95 = nil
	end
	local v96 = v95 or (v_u_89.swings or {})
	local v97 = v_u_93 - 1
	local v98 = #v96
	local v99 = v96[v97 % math.max(1, v98) + 1]
	v_u_3.PlayAnim(v_u_87.animator, v99, (v_u_89.swingSpeed or 1) * (v_u_94 and 0.95 or 1), 0.05)
	v_u_87.emit("Swing", {
		["step"] = v_u_93,
		["finisher"] = v_u_94,
		["hitDelay"] = v_u_89.hitDelay or 0.1,
		["oneHanded"] = v91
	})
	local v100 = v_u_89.hitDelay or 0.1
	local v101
	if v100 >= 0.15 then
		v101 = v100 - 0.04
	else
		local v102 = v100 - 0.1
		v101 = math.max(0, v102)
	end
	local function v104() -- name: whoosh
		-- upvalues: (ref) v_u_3, (copy) v_u_89, (copy) v_u_87, (copy) v_u_94
		local v103 = {
			["PlaybackSpeed"] = v_u_94 and 0.88 or 1
		}
		v_u_3.Sound(v_u_89.swingSound or "Swing_Sword", v_u_87.root, v103)
	end
	if v101 >= 0.05 then
		task.delay(v101, v104)
	else
		v_u_3.Sound(v_u_89.swingSound or "Swing_Sword", v_u_87.root, {
			["PlaybackSpeed"] = v_u_94 and 0.88 or 1
		})
	end
	local v105 = v_u_3.InFirstPerson()
	if v_u_89.trail and (v_u_89.trail > 0 and not v105) then
		v_u_5.Trail(v_u_87.tool, v_u_89.trail)
	end
	local v106 = v_u_89.hitDelay or 0.1
	p_u_86.strikes = p_u_86.strikes + 1
	if not v_u_89.noSlash and (v_u_87.tool and not v105) then
		task.delay(v106 * 0.6, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_87, (copy) v_u_93, (copy) v_u_94, (copy) v_u_89, (copy) v_u_88
			v_u_5.Slash(v_u_87.char, v_u_93, v_u_94, v_u_89.slashColor, v_u_88.range)
		end)
	end
	task.delay(v106, function()
		-- upvalues: (copy) p_u_86, (copy) v_u_87, (copy) v_u_88, (ref) v_u_3, (copy) v_u_90, (ref) v_u_82, (copy) v_u_89, (copy) v_u_92, (copy) v_u_93, (copy) v_u_94
		local v107 = p_u_86
		v107.strikes = v107.strikes - 1
		if v_u_87.alive() then
			local v108 = p_u_86:Detect(v_u_88.range or 8, v_u_88.arc or 60, v_u_88.maxTargets or 1)
			local v109 = v_u_87.send
			local v110 = {
				["tool"] = v_u_87.tool,
				["dir"] = v_u_3.GetAimRay().Direction,
				["hits"] = v108
			}
			local v111 = (os.clock() - v_u_90) * 1000
			v110.k = math.floor(v111)
			v109("Swing", v110)
			v_u_82(v108, v_u_89.hitSound or "Hit_Melee", (v_u_88.damage or 10) * (v_u_92[v_u_93] or 1), v_u_88, v_u_87.root, v_u_87.weaponId)
			if #v108 > 0 then
				v_u_3.Shake((v_u_89.shake or 0.18) * (v_u_94 and 1.4 or 1), 0.14)
				v_u_3.Recoil(v_u_94 and 1.4 or 0.7, (math.random() - 0.5) * 0.8)
			end
		end
	end)
	return true
end
local v_u_112 = (-1 / 0)
function v_u_8.CanGuard(p113) -- name: CanGuard
	-- upvalues: (copy) v_u_3
	local v114
	if p113.strikes <= 0 and os.clock() >= p113.busyUntil then
		v114 = v_u_3.CanAct()
	else
		v114 = false
	end
	return v114
end
function v_u_8.SetBlock(p115, p116) -- name: SetBlock
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_3, (ref) v_u_112
	local v117 = p115.ctx
	if p115.blocking == p116 then
		return
	else
		p115.blocking = p116
		if p116 then
			p115.bufferedAt = nil
		end
		v117.send("Block", {
			["tool"] = v117.tool,
			["on"] = p116
		})
		v117.emit("Block", {
			["on"] = p116
		})
		v_u_4.SetBlocking(p116)
		v_u_6.SetLocal(p116)
		if p116 then
			v_u_3.PlayAnim(v117.animator, p115.preset.block, 1, 0.1)
		else
			v_u_3.StopAnim(v117.animator, p115.preset.block, 0.12)
		end
		if p116 then
			local v118 = os.clock()
			if v118 - v_u_112 >= 0.5 then
				v_u_112 = v118
				v_u_3.Sound("Block_Up", v117.root)
			end
			v117.setSpeed("Block", p115.tuning.block and p115.tuning.block.speedMult or 0.6)
		else
			v117.setSpeed("Block", nil)
		end
	end
end
function v_u_8.SpecialInfo(p119, p120) -- name: SpecialInfo
	local v121
	if p120 == "Heavy" then
		v121 = p119.tuning.heavy
	else
		v121 = p119.tuning.lunge
	end
	return v121 or {}
end
function v_u_8.SpecialReady(p122, p123, p124) -- name: SpecialReady
	if p124 - p122.lastSpecial < (p123.cooldown or 1) then
		return false
	end
	local v125 = p122.ctx.tool
	if v125 then
		v125 = p122.ctx.tool:GetAttribute("Cooldown")
	end
	local v126
	if type(v125) == "number" then
		v126 = workspace:GetServerTimeNow() < v125
	else
		v126 = false
	end
	return not v126
end
function v_u_8.StartCharge(p127, p128) -- name: StartCharge
	-- upvalues: (copy) v_u_3
	local v129 = p127.ctx
	local v130 = os.clock()
	local v131 = p127:SpecialInfo(p128)
	if p127:SpecialReady(v131, v130) and (v130 >= p127.busyUntil and v_u_3.CanAct()) then
		p127.charging = p128
		p127.chargeStart = v130
		p127.bufferedAt = nil
		p127.fullPlayed = false
		v129.send("Charge", {
			["tool"] = nil,
			["kind"] = nil,
			["on"] = true,
			["tool"] = v129.tool,
			["kind"] = p128
		})
		v129.emit("Charge", {
			["kind"] = nil,
			["on"] = true,
			["time"] = nil,
			["kind"] = p128,
			["time"] = v131.charge or 0.6
		})
		local v132 = v_u_3.PlayHold
		local v133 = v129.animator
		local v134
		if p128 == "Heavy" then
			v134 = p127.preset.heavyCharge
		else
			v134 = p127.preset.lungeCharge
		end
		v132(v133, v134, 1)
		v_u_3.Sound(p127.preset.chargeSound or "Charge_Up", v129.root)
		v129.setSpeed("Charge", v131.speedMult or 0.55)
	end
end
function v_u_8.CancelCharge(p135) -- name: CancelCharge
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v136 = p135.ctx
	local v137 = p135.charging
	p135.charging = nil
	if v137 then
		v136.send("Charge", {
			["tool"] = nil,
			["kind"] = nil,
			["on"] = false,
			["tool"] = v136.tool,
			["kind"] = v137
		})
		v136.emit("Charge", {
			["kind"] = nil,
			["on"] = false,
			["kind"] = v137
		})
		local v138 = v_u_3.StopAnim
		local v139 = v136.animator
		local v140
		if v137 == "Heavy" then
			v140 = p135.preset.heavyCharge
		else
			v140 = p135.preset.lungeCharge
		end
		v138(v139, v140, 0.1)
	end
	v136.setSpeed("Charge", nil)
	v_u_4.SetCharge(0)
end
function v_u_8.Dash(p141) -- name: Dash
	-- upvalues: (copy) v_u_3
	local v142 = p141.ctx
	local v143 = p141:SpecialInfo("Lunge")
	local v144 = os.clock()
	if p141:SpecialReady(v143, v144) and (v144 >= p141.busyUntil and v_u_3.CanAct()) then
		p141.bufferedAt = nil
		v142.send("Charge", {
			["tool"] = nil,
			["kind"] = "Lunge",
			["on"] = true,
			["tool"] = v142.tool
		})
		p141.charging = "Lunge"
		p141.chargeStart = v144 - 1
		p141:ReleaseCharge()
	end
end
function v_u_8.ReleaseCharge(p_u_145) -- name: ReleaseCharge
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_82, (copy) v_u_2
	local v_u_146 = p_u_145.ctx
	local v_u_147 = p_u_145.tuning
	local v_u_148 = p_u_145.preset
	local v149 = p_u_145.charging
	if v149 then
		local v_u_150 = p_u_145:SpecialInfo(v149)
		if os.clock() - p_u_145.chargeStart < (v_u_150.charge or 0.6) then
			p_u_145:CancelCharge()
			return
		else
			p_u_145.charging = nil
			p_u_145.lastSpecial = os.clock()
			local v151 = v_u_3.StopAnim
			local v152 = v_u_146.animator
			local v153
			if v149 == "Heavy" then
				v153 = v_u_148.heavyCharge
			else
				v153 = v_u_148.lungeCharge
			end
			v151(v152, v153, 0.05)
			v_u_146.setSpeed("Charge", nil)
			v_u_4.SetCharge(0)
			v_u_4.SetArc(v_u_150.cooldown or 1, Color3.fromRGB(228, 232, 240))
			local v154 = v_u_3.MeleeAssist
			local v155
			if v149 == "Heavy" then
				v155 = v_u_150.range or (v_u_147.range or 9) + 1
			else
				v155 = (v_u_150.range or 12) + (v_u_150.distance or 16) * 0.5
			end
			v154(v155, v149 ~= "Heavy")
			v_u_3.FaceCamera()
			if v149 == "Heavy" then
				p_u_145.busyUntil = os.clock() + 0.55
				v_u_146.emit("Heavy", {
					["hitDelay"] = v_u_148.heavyDelay or 0.16
				})
				v_u_3.PlayAnim(v_u_146.animator, v_u_148.heavySwing or "Axe_Heavy", 1.15, 0.04)
				v_u_3.Sound(v_u_148.heavySound or "Swing_Heavy", v_u_146.root)
				local v156 = v_u_148.heavyDelay or 0.16
				if not v_u_3.InFirstPerson() then
					v_u_5.Trail(v_u_146.tool, 0.5)
					task.delay(v156 * 0.6, function()
						-- upvalues: (ref) v_u_5, (copy) v_u_146, (copy) v_u_148, (copy) v_u_150, (copy) v_u_147
						v_u_5.Slash(v_u_146.char, 1, true, v_u_148.slashColor, v_u_150.range or v_u_147.range)
					end)
				end
				task.delay(v156, function()
					-- upvalues: (copy) v_u_146, (copy) p_u_145, (copy) v_u_150, (copy) v_u_147, (ref) v_u_3, (ref) v_u_82, (copy) v_u_148, (ref) v_u_5
					if v_u_146.alive() then
						local v157 = p_u_145
						local v158 = v_u_150.range or (v_u_147.range or 9) + 1
						local v159 = (v_u_147.arc or 60) + 10
						local v160 = v157:Detect(v158, math.min(v159, 90), v_u_147.maxTargets or 2)
						v_u_146.send("Swing", {
							["tool"] = nil,
							["dir"] = nil,
							["hits"] = nil,
							["heavy"] = true,
							["tool"] = v_u_146.tool,
							["dir"] = v_u_3.GetAimRay().Direction,
							["hits"] = v160
						})
						v_u_82(v160, v_u_148.hitSound or "Hit_Melee_Heavy", v_u_150.damage, nil, v_u_146.root, v_u_146.weaponId)
						if v_u_148.slam == false then
							if #v160 > 0 then
								v_u_3.Shake(0.6, 0.15)
								v_u_3.Recoil(1.5, 0)
							end
						else
							v_u_3.Shake(#v160 > 0 and 0.9 or 0.45, 0.25)
							v_u_3.Recoil(#v160 > 0 and 2.5 or 1.2, 0)
						end
						if v_u_148.slam ~= false then
							local v161 = v_u_146.root.CFrame * CFrame.new(0, -2.8, -4)
							v_u_5.Burst("Ground_Slam", v161)
							v_u_5.GroundScuff(v161.Position)
						end
					end
				end)
			else
				p_u_145.busyUntil = os.clock() + 0.45
				local v162 = v_u_146.root
				local v163 = v_u_3.GetAimRay()
				local v164 = v163.Direction.X
				local v165 = v163.Direction.Z
				local v166 = Vector3.new(v164, 0, v165)
				local v_u_167
				if v166.Magnitude > 0.05 then
					v_u_167 = v166.Unit
				else
					v_u_167 = v162.CFrame.LookVector
				end
				v_u_3.PlayAnim(v_u_146.animator, v_u_148.lunge or "Spear_Stab", v_u_148.lungeAnimSpeed or 0.8, 0.03)
				v_u_3.Sound(v_u_148.lungeSound or "Lunge", v162)
				if not v_u_3.InFirstPerson() then
					v_u_5.Trail(v_u_146.tool, 0.4)
					if v_u_148.lungeSlash then
						task.delay(0.08, function()
							-- upvalues: (ref) v_u_5, (copy) v_u_146, (copy) v_u_148, (copy) v_u_150
							v_u_5.Slash(v_u_146.char, 1, true, v_u_148.slashColor, (v_u_150.range or 8) + 2)
						end)
					end
				end
				v_u_2.Pulse("Lunge", 0.15)
				local v168 = (v_u_150.distance or 16) / (v_u_150.speed or 70)
				local v169 = math.clamp(v168, 0.12, 0.35)
				v_u_3.FovKick(6, 0.05, v169 + 0.05)
				if v_u_148.lungeLines and v_u_3.InFirstPerson() then
					v_u_5.DashLines(v169 + 0.12)
				end
				v_u_146.emit("Lunge", {
					["time"] = v169
				})
				local v_u_170 = {}
				local v_u_171 = {}
				for v172 = 0, 3 do
					task.delay(v169 / 3 * v172, function()
						-- upvalues: (copy) p_u_145, (copy) v_u_150, (copy) v_u_147, (copy) v_u_170, (copy) v_u_171
						for _, v173 in p_u_145:Detect(v_u_150.range or 12, v_u_150.arc or 35, v_u_147.maxTargets or 2) do
							if v_u_170[v173] or #v_u_171 >= (v_u_147.maxTargets or 2) then
								continue
							end
							v_u_170[v173] = true
							local v174 = v_u_171
							table.insert(v174, v173)
						end
					end)
				end
				task.delay(v169, function()
					-- upvalues: (copy) v_u_146, (ref) v_u_167, (copy) v_u_171, (ref) v_u_82, (copy) v_u_148, (copy) v_u_150, (ref) v_u_3
					if v_u_146.alive() then
						v_u_146.send("Swing", {
							["tool"] = nil,
							["dir"] = nil,
							["hits"] = nil,
							["lunge"] = true,
							["tool"] = v_u_146.tool,
							["dir"] = v_u_167,
							["hits"] = v_u_171
						})
						v_u_82(v_u_171, v_u_148.hitSound or "Hit_Melee_Heavy", v_u_150.damage, nil, v_u_146.root, v_u_146.weaponId)
						if #v_u_171 > 0 then
							v_u_3.Shake(0.6, 0.15)
							v_u_3.Recoil(2, 0)
						end
					end
				end)
			end
		end
	else
		return
	end
end
function v_u_8.ParryReady(p175) -- name: ParryReady
	-- upvalues: (copy) v_u_3
	local v176 = p175.tuning.parry
	local v177 = os.clock()
	if type(v176) ~= "table" or (p175.parrying or (v177 < p175.parryReadyAt or v177 - p175.lastParryUp < 0.15)) then
		return false
	end
	local v178 = p175.ctx.tool
	if v178 then
		v178 = p175.ctx.tool:GetAttribute("Cooldown")
	end
	if type(v178) == "number" and workspace:GetServerTimeNow() < v178 then
		return false
	end
	local v179
	if p175.busyUntil <= v177 and v177 - p175.lastSwing >= p175:Cooldown() then
		v179 = v_u_3.CanAct()
	else
		v179 = false
	end
	return v179
end
function v_u_8.RaiseParry(p180) -- name: RaiseParry
	-- upvalues: (copy) v_u_3
	local v181 = p180.ctx
	local v182 = p180.tuning.parry
	if p180:ParryReady() then
		p180.parrying = true
		p180.lastParryUp = os.clock()
		p180.parryUpAt = p180.lastParryUp
		p180.bufferedAt = nil
		v_u_3.FaceCamera()
		v181.send("Parry", {
			["tool"] = nil,
			["on"] = true,
			["tool"] = v181.tool
		})
		v181.emit("Parry", {
			["on"] = true
		})
		v_u_3.PlayHold(v181.animator, p180.preset.parryHold or p180.preset.parry, 1)
		v_u_3.Sound(p180.preset.parrySound or "Katana_Flick", v181.root)
		v181.setSpeed("Parry", v182.speedMult or 0.7)
	end
end
function v_u_8.LowerParry(p183, p184, p185, p186) -- name: LowerParry
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	if p183.parrying then
		local v187 = p183.ctx
		p183.parrying = false
		local v188 = p183.tuning.parry
		if not p185 and type(v188) == "table" then
			local v189 = v188.cooldown or 1.6
			local v190 = p183.parryReadyAt
			local v191 = os.clock() + v189
			p183.parryReadyAt = math.max(v190, v191)
			if not p186 then
				v_u_4.SetArc(v189, Color3.fromRGB(150, 196, 236))
			end
		end
		if p184 then
			v187.send("Parry", {
				["tool"] = nil,
				["on"] = false,
				["tool"] = v187.tool
			})
		end
		if not p185 then
			v187.emit("Parry", {
				["on"] = false
			})
		end
		v_u_3.StopAnim(v187.animator, p183.preset.parryHold or p183.preset.parry, 0.15)
		v187.setSpeed("Parry", nil)
	end
end
function v_u_8.ParryUsed(p192) -- name: ParryUsed
	-- upvalues: (copy) v_u_4
	local v193 = p192.tuning.parry
	if type(v193) == "table" then
		local v194 = v193.cooldown or 1.6
		p192.parryReadyAt = os.clock() + v194
		v_u_4.SetArc(v194, Color3.fromRGB(150, 196, 236))
		p192:LowerParry(false, true)
	end
end
function v_u_8.Hurl(p_u_195) -- name: Hurl
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_5, (copy) v_u_4
	local v196 = p_u_195.ctx
	local v197 = p_u_195.tuning.throw
	local v198 = os.clock()
	if type(v197) == "table" and (not p_u_195:OneHanded() and (v198 - p_u_195.lastThrow >= (v197.cooldown or 0.45) and (v198 >= p_u_195.busyUntil and v_u_3.CanAct()))) then
		p_u_195.lastThrow = v198
		p_u_195.thrownLocalUntil = v198 + 0.8
		p_u_195.busyUntil = v198 + 0.2
		p_u_195.bufferedAt = nil
		v_u_3.FaceCamera()
		local v199 = v_u_3.ShotOrigin(nil)
		local v200 = v_u_3.AimPoint(v197.range or 170)
		local v201 = v_u_3.AssistDirection(v199, v_u_3.AimDirection(v199), true)
		local v202 = v197.speed or 120
		local v203 = v197.gravity or 0
		local v204 = (v200 - v199).Magnitude
		if v203 > 0 and v204 > 1 then
			local v205 = v204 / v202
			local v206 = v201 * v204
			local v207 = 0.5 * v203 * v205 * v205
			v201 = (v206 + Vector3.new(0, v207, 0)).Unit
		end
		local v208 = v196.nextId()
		v196.emit("Hurl", {})
		v_u_3.PlayAnim(v196.animator, p_u_195.preset.throw, 1.2, 0.03)
		v_u_3.Sound(p_u_195.preset.throwSound or "Hatchet_Throw", v196.root)
		v_u_7.ShowOffHand(v196.tool, false)
		v_u_5.Projectile(v_u_5.MyKey(v208), "Hatchet", v199, v201 * v202, v203, v196.char, {
			["damage"] = (v197.damage or 40) * v_u_3.ItemBonus(v196.weaponId),
			["tuning"] = v197
		})
		v196.send("Hurl", {
			["tool"] = v196.tool,
			["origin"] = v199,
			["dir"] = v201,
			["id"] = v208
		})
		v_u_4.SetArc(v197.cooldown or 0.45, Color3.fromRGB(214, 170, 120))
		local v_u_209 = v196.tool
		task.delay(0.85, function()
			-- upvalues: (copy) v_u_209, (copy) p_u_195, (ref) v_u_7
			if v_u_209 and (v_u_209.Parent and (v_u_209:GetAttribute("Thrown") ~= true and os.clock() >= p_u_195.thrownLocalUntil)) then
				v_u_7.ShowOffHand(v_u_209, true)
			end
		end)
	end
end
function v_u_8.Input(p210, p211, p212) -- name: Input
	local v213 = p210.tuning
	if p211 == "Primary" then
		p210.holding = p212
		if p212 then
			p210.guardFirst = false
			if p210.blocking then
				p210:SetBlock(false)
			end
			if p210.parrying then
				p210:LowerParry(true)
			end
			if not (p210.charging or p210:Swing()) then
				p210.bufferedAt = os.clock()
				return
			end
		end
	elseif p211 == "Secondary" then
		if v213.parry then
			p210.parryHeld = p212
			if p212 then
				p210:RaiseParry()
			else
				p210:LowerParry(true)
			end
		end
		if v213.throw then
			if p212 then
				p210:Hurl()
				return
			end
		else
			if v213.block then
				p210.blockHeld = p212
				if p212 then
					p210.guardFirst = true
					p210.bufferedAt = nil
				end
				if p212 then
					p212 = p210:CanGuard()
				end
				p210:SetBlock(p212)
				return
			end
			if v213.heavy then
				if p212 then
					p210:StartCharge("Heavy")
				else
					p210:ReleaseCharge()
				end
			end
			if v213.lunge and (v213.lunge.charge or 0.6) <= 0 then
				if p212 then
					p210:Dash()
					return
				end
			elseif v213.lunge then
				if p212 then
					p210:StartCharge("Lunge")
					return
				end
				p210:ReleaseCharge()
			end
		end
	end
end
function v_u_8.Update(p214, _) -- name: Update
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v215 = p214.tuning.parry
	if p214.parrying and type(v215) == "table" then
		local v216 = v215.maxHold
		if type(v216) == "number" and os.clock() - p214.parryUpAt >= v215.maxHold then
			p214:LowerParry(true)
		end
	end
	if p214.parryHeld and (not p214.parrying and (not p214.holding and p214:ParryReady())) then
		p214:RaiseParry()
	end
	if p214.blockHeld and (not p214.blocking and (not p214.charging and (not p214.bufferedAt and (p214.guardFirst or not p214.holding)))) and p214:CanGuard() then
		p214:SetBlock(true)
	end
	if p214.holding and not (p214.blocking or p214.charging) then
		p214:Swing()
	elseif p214.bufferedAt then
		if os.clock() - p214.bufferedAt > 0.2 or (p214.blocking or p214.charging) then
			p214.bufferedAt = nil
		else
			p214:Swing()
		end
	end
	if p214.charging then
		local v217 = p214:SpecialInfo(p214.charging)
		local v218 = (os.clock() - p214.chargeStart) / (v217.charge or 0.6)
		local v219 = math.clamp(v218, 0, 1)
		if v219 >= 1 and not p214.fullPlayed then
			p214.fullPlayed = true
			v_u_3.Sound("Charge_Full", p214.ctx.root)
		end
		v_u_4.SetCharge(v219)
	end
end
function v_u_8.Interrupt(p220) -- name: Interrupt
	if p220.blocking then
		p220:SetBlock(false)
	end
	if p220.charging then
		p220:CancelCharge()
	end
	p220:LowerParry(true)
	local v221 = p220.busyUntil
	local v222 = os.clock() + 0.2
	p220.busyUntil = math.max(v221, v222)
end
return v_u_8