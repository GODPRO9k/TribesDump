local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = require(script.Parent:WaitForChild("Characters"))
local v_u_4 = require(script.Parent:WaitForChild("Perf"))
local v_u_5 = require(script.Parent:WaitForChild("Quality"))
local v6 = {}
local v_u_7 = {}
local v_u_8 = {}
local function v_u_22(p9) -- name: rigFor
	-- upvalues: (copy) v_u_7, (copy) v_u_8
	local v10 = v_u_7[p9]
	if v10 and v10.root.Parent then
		return v10
	end
	local v11 = v_u_8[p9]
	if v11 and os.clock() - v11 < 1 then
		return nil
	end
	v_u_8[p9] = os.clock()
	local v12 = p9:FindFirstChildOfClass("Humanoid")
	local v13 = p9:FindFirstChild("HumanoidRootPart")
	local v14 = p9:FindFirstChild("LowerTorso")
	local v15 = p9:FindFirstChild("UpperTorso")
	if not (v12 and (v13 and (v14 and (v15 and v13:IsA("BasePart"))))) then
		return nil
	end
	local v16 = v14:FindFirstChild("Root")
	local v17 = v15:FindFirstChild("Waist")
	local v18
	if v16 == nil then
		v18 = false
	else
		v18 = v16:IsA("Motor6D") or v16:IsA("AnimationConstraint")
	end
	if v18 then
		local v19
		if v17 == nil then
			v19 = false
		else
			v19 = v17:IsA("Motor6D") or v17:IsA("AnimationConstraint")
		end
		if v19 then
			local _, v20, _ = v13.CFrame:ToEulerAnglesYXZ()
			local v21 = {
				["root"] = nil,
				["humanoid"] = nil,
				["rootJoint"] = nil,
				["waist"] = nil,
				["twist"] = 0,
				["bank"] = 0,
				["lastYaw"] = nil,
				["yawDt"] = 0,
				["yawRate"] = 0,
				["root"] = v13,
				["humanoid"] = v12,
				["rootJoint"] = v16,
				["waist"] = v17,
				["lastYaw"] = v20
			}
			v_u_7[p9] = v21
			v_u_8[p9] = nil
			return v21
		end
	end
	return nil
end
local v_u_23 = {}
local v_u_24 = {}
function v6.Track(p25, p26) -- name: Track
	-- upvalues: (copy) v_u_24
	v_u_24[p25] = p26
end
function v6.Untrack(p27) -- name: Untrack
	-- upvalues: (copy) v_u_24, (copy) v_u_7
	v_u_24[p27] = nil
	v_u_7[p27] = nil
end
local function v_u_58(_, p28, p29, p30, p31, p32) -- name: apply
	local v33 = p28.root
	local v34 = p30.X
	local v35 = p30.Z
	local v36 = Vector3.new(v34, 0, v35)
	local v37 = v36.Magnitude
	local v38
	if p31 and (v37 > 3 and (v37 < 32 and not p32)) then
		local v39 = v33.CFrame:VectorToObjectSpace(v36 / v37)
		local v40 = -v39.X
		local v41 = -v39.Z
		local v42 = math.atan2(v40, v41)
		if math.abs(v42) > 1.7453292519943295 then
			v42 = v42 - 3.141592653589793 * math.sign(v42)
		end
		local v43 = math.clamp(v42, -1.3089969389957472, 1.3089969389957472)
		local v44 = (v37 - 3) / 5
		v38 = v43 * math.clamp(v44, 0, 1)
	else
		v38 = 0
	end
	local v45 = p28.twist
	local v46 = v38 - p28.twist
	local v47 = p29 * -10
	p28.twist = v45 + v46 * (1 - math.exp(v47))
	local _, v48, _ = v33.CFrame:ToEulerAnglesYXZ()
	local v49 = (v48 - p28.lastYaw + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
	p28.lastYaw = v48
	p28.yawDt = p28.yawDt + p29
	if math.abs(v49) > 1e-6 then
		p28.yawRate = v49 / p28.yawDt
		p28.yawDt = 0
	elseif p28.yawDt > 0.05 then
		p28.yawRate = 0
	end
	local v50 = p28.yawRate
	local v51
	if p31 then
		local v52 = -v50 * v37 * 0.0022
		v51 = math.clamp(v52, -0.14, 0.14)
	else
		v51 = 0
	end
	local v53 = p28.bank
	local v54 = v51 - p28.bank
	local v55 = p29 * -8
	p28.bank = v53 + v54 * (1 - math.exp(v55))
	local v56 = p28.twist
	if math.abs(v56) > 0.001 then
		p28.rootJoint.Transform = p28.rootJoint.Transform * CFrame.Angles(0, p28.twist, p28.bank)
		p28.waist.Transform = p28.waist.Transform * CFrame.Angles(0, -p28.twist * 0.9, -p28.bank * 0.5)
		return
	else
		local v57 = p28.bank
		if math.abs(v57) > 0.001 then
			p28.rootJoint.Transform = p28.rootJoint.Transform * CFrame.Angles(0, p28.twist, p28.bank)
			p28.waist.Transform = p28.waist.Transform * CFrame.Angles(0, -p28.twist * 0.9, -p28.bank * 0.5)
		end
	end
end
local function v_u_80(p59) -- name: step
	-- upvalues: (copy) v_u_2, (copy) v_u_23, (copy) v_u_5, (copy) v_u_3, (copy) v_u_22, (copy) v_u_58, (copy) v_u_24, (copy) v_u_7, (copy) v_u_8
	if p59 > 0 then
		local v60 = v_u_2.CurrentCamera
		local v61 = not v60 and Vector3.new(0, 0, 0) or v60.CFrame.Position
		table.clear(v_u_23)
		local v62 = v_u_5.budget.twistRange * v_u_5.budget.twistRange
		for _, v63 in v_u_3.List() do
			local v64 = v_u_22(v63)
			if not v64 then
				continue
			end
			v_u_23[v63] = true
			local v65 = v64.root.Position - v61
			local v66
			if v62 < v65.X * v65.X + v65.Y * v65.Y + v65.Z * v65.Z or v64.humanoid.Health <= 0 then
				v64.twist = 0
				v64.bank = 0
				v66 = false
			else
				v66 = true
			end
			if not v66 then
				continue
			end
			local v67 = v64.humanoid:GetState()
			local v68 = v67 == Enum.HumanoidStateType.Running and true or v67 == Enum.HumanoidStateType.RunningNoPhysics
			v_u_58(v63, v64, p59, v64.root.AssemblyLinearVelocity, v68, v63:GetAttribute("Sliding") == true)
		end
		for v69, v70 in v_u_24 do
			if not v69.Parent then
				continue
			end
			local v71 = v_u_22(v69)
			if not v71 then
				continue
			end
			v_u_23[v69] = true
			local v72 = v71.root.Position - v61
			local v73
			if v62 < v72.X * v72.X + v72.Y * v72.Y + v72.Z * v72.Z or v71.humanoid.Health <= 0 then
				v71.twist = 0
				v71.bank = 0
				v73 = false
			else
				v73 = true
			end
			if not v73 then
				continue
			end
			local v74, v75, v76, v77 = pcall(v70)
			if not v74 or typeof(v75) ~= "Vector3" then
				continue
			end
			v_u_58(v69, v71, p59, v75, v76 == true, v77 == true)
		end
		for v78 in v_u_7 do
			if v_u_23[v78] then
				continue
			end
			v_u_7[v78] = nil
		end
		for v79 in v_u_8 do
			if v79.Parent then
				continue
			end
			v_u_8[v79] = nil
		end
	end
end
function v6.Start() -- name: Start
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_80
	v_u_1.PreSimulation:Connect(function(p81)
		-- upvalues: (ref) v_u_4, (ref) v_u_80
		local v82 = v_u_4.Begin()
		v_u_80(p81)
		v_u_4.End("Procedural", v82)
	end)
end
return v6