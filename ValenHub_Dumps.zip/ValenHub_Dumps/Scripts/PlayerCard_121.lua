local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("StarterGui")
local v_u_5 = game:GetService("TextChatService")
local v_u_6 = game:GetService("UserInputService")
local v_u_7 = game:GetService("Workspace")
local v8 = {}
local v9 = Color3.fromRGB
local v_u_10 = {
	{
		["min"] = 1,
		["name"] = "ROOKIE",
		["hi"] = nil,
		["lo"] = nil,
		["accent"] = nil,
		["deep"] = nil,
		["holo"] = 0.15,
		["hi"] = v9(178, 188, 206),
		["lo"] = v9(78, 86, 104),
		["accent"] = v9(168, 184, 210),
		["deep"] = v9(22, 26, 34)
	},
	{
		["min"] = 5,
		["name"] = "BRONZE",
		["hi"] = nil,
		["lo"] = nil,
		["accent"] = nil,
		["deep"] = nil,
		["holo"] = 0.3,
		["hi"] = v9(238, 168, 108),
		["lo"] = v9(116, 62, 30),
		["accent"] = v9(240, 158, 92),
		["deep"] = v9(34, 22, 15)
	},
	{
		["min"] = 10,
		["name"] = "SILVER",
		["hi"] = nil,
		["lo"] = nil,
		["accent"] = nil,
		["deep"] = nil,
		["holo"] = 0.45,
		["hi"] = v9(210, 220, 236),
		["lo"] = v9(98, 110, 134),
		["accent"] = v9(190, 206, 232),
		["deep"] = v9(22, 27, 38)
	},
	{
		["min"] = 20,
		["name"] = "GOLD",
		["hi"] = nil,
		["lo"] = nil,
		["accent"] = nil,
		["deep"] = nil,
		["holo"] = 0.6,
		["hi"] = v9(255, 214, 98),
		["lo"] = v9(160, 98, 18),
		["accent"] = v9(255, 194, 60),
		["deep"] = v9(36, 27, 10)
	},
	{
		["min"] = 35,
		["name"] = "DIAMOND",
		["hi"] = nil,
		["lo"] = nil,
		["accent"] = nil,
		["deep"] = nil,
		["holo"] = 0.8,
		["hi"] = v9(140, 234, 255),
		["lo"] = v9(26, 100, 192),
		["accent"] = v9(92, 206, 255),
		["deep"] = v9(10, 25, 44)
	},
	{
		["min"] = 50,
		["name"] = "MYTHIC",
		["hi"] = nil,
		["lo"] = nil,
		["accent"] = nil,
		["deep"] = nil,
		["holo"] = 1,
		["prism"] = true,
		["hi"] = v9(236, 146, 255),
		["lo"] = v9(66, 38, 156),
		["accent"] = v9(196, 132, 255),
		["deep"] = v9(25, 14, 44)
	}
}
local v_u_11 = ColorSequence.new({
	ColorSequenceKeypoint.new(0, v9(255, 120, 190)),
	ColorSequenceKeypoint.new(0.2, v9(190, 120, 255)),
	ColorSequenceKeypoint.new(0.4, v9(100, 190, 255)),
	ColorSequenceKeypoint.new(0.6, v9(110, 240, 190)),
	ColorSequenceKeypoint.new(0.8, v9(255, 222, 110)),
	ColorSequenceKeypoint.new(1, v9(255, 130, 170))
})
local v_u_12 = ColorSequence.new({
	ColorSequenceKeypoint.new(0, v9(255, 90, 170)),
	ColorSequenceKeypoint.new(0.17, v9(255, 200, 90)),
	ColorSequenceKeypoint.new(0.34, v9(120, 255, 150)),
	ColorSequenceKeypoint.new(0.5, v9(90, 220, 255)),
	ColorSequenceKeypoint.new(0.67, v9(150, 120, 255)),
	ColorSequenceKeypoint.new(0.84, v9(255, 110, 210)),
	ColorSequenceKeypoint.new(1, v9(255, 200, 90))
})
local function v_u_20(p13) -- name: holoBands
	local v14 = 1 - math.clamp(p13, 0, 1) * 0.22
	local v15 = {}
	for v16 = 0, 6 do
		local v17 = NumberSequenceKeypoint.new
		local v18 = v16 / 6
		local v19 = v16 % 2 == 0 and 1 or v14
		table.insert(v15, v17(v18, v19))
	end
	return NumberSequence.new(v15)
end
local v_u_21 = nil
function v8.Init(p_u_22) -- name: Init
	-- upvalues: (copy) v_u_2, (copy) v_u_12, (copy) v_u_10, (copy) v_u_11, (copy) v_u_20, (copy) v_u_1, (copy) v_u_7, (copy) v_u_3, (copy) v_u_6, (ref) v_u_21, (copy) v_u_5, (copy) v_u_4
	local v_u_23 = p_u_22.UI
	local v_u_24 = p_u_22.Theme
	local v_u_25 = p_u_22.State
	local v_u_26 = v_u_24.Colors
	local v_u_27 = v_u_24.Fonts
	local v_u_28 = p_u_22.Economy
	local v_u_29 = p_u_22.WeaponInfo
	local v_u_30 = p_u_22.WeaponIcon
	local v_u_31 = v_u_2.LocalPlayer
	local v_u_32 = v_u_23.Assets
	local v_u_33 = Instance.new("Model")
	v_u_33.Name = "TR_PlayerCard"
	local v_u_34 = Instance.new("Part")
	v_u_34.Name = "Card"
	v_u_34.Anchored = true
	v_u_34.CanCollide = false
	v_u_34.CanQuery = false
	v_u_34.CanTouch = false
	v_u_34.CastShadow = false
	v_u_34.Transparency = 1
	v_u_34.Size = Vector3.new(0.71428573, 1, 0.004)
	v_u_34.Parent = v_u_33
	local v_u_35 = Instance.new("Part")
	v_u_35.Name = "Shadow"
	v_u_35.Anchored = true
	v_u_35.CanCollide = false
	v_u_35.CanQuery = false
	v_u_35.CanTouch = false
	v_u_35.CastShadow = false
	v_u_35.Transparency = 1
	v_u_35.Size = Vector3.new(0.71428573, 1, 0.004)
	v_u_35.Parent = v_u_33
	local v_u_36 = Instance.new("Part")
	v_u_36.Name = "Backdrop"
	v_u_36.Anchored = true
	v_u_36.CanCollide = false
	v_u_36.CanQuery = false
	v_u_36.CanTouch = false
	v_u_36.CastShadow = false
	v_u_36.Transparency = 1
	v_u_36.Size = Vector3.new(0.71428573, 1, 0.004)
	v_u_36.Parent = v_u_33
	local function v41(p37, p38, p39, p40) -- name: surface
		-- upvalues: (copy) v_u_23, (copy) p_u_22
		return v_u_23.new("SurfaceGui", {
			["Name"] = nil,
			["Adornee"] = nil,
			["Face"] = nil,
			["AlwaysOnTop"] = false,
			["LightInfluence"] = 0,
			["Brightness"] = 1,
			["SizingMode"] = nil,
			["CanvasSize"] = nil,
			["ClipsDescendants"] = true,
			["ZIndexBehavior"] = nil,
			["ResetOnSpawn"] = false,
			["Enabled"] = false,
			["Parent"] = nil,
			["Name"] = p37,
			["Adornee"] = p38,
			["Face"] = p39,
			["SizingMode"] = Enum.SurfaceGuiSizingMode.FixedSize,
			["CanvasSize"] = p40,
			["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
			["Parent"] = p_u_22.PlayerGui
		})
	end
	local v_u_42 = v41("TR_CardFront", v_u_34, Enum.NormalId.Back, Vector2.new(500, 700))
	local v_u_43 = v41("TR_CardBack", v_u_34, Enum.NormalId.Front, Vector2.new(500, 700))
	local v_u_44 = v41("TR_CardShadow", v_u_35, Enum.NormalId.Back, Vector2.new(200, 200))
	local v_u_45 = v41("TR_CardBackdrop", v_u_36, Enum.NormalId.Back, Vector2.new(640, 360))
	local v_u_46 = v_u_23.new("ImageLabel", {
		["Name"] = "Shadow",
		["Size"] = nil,
		["Image"] = nil,
		["ImageColor3"] = nil,
		["ImageTransparency"] = 0.25,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Image"] = v_u_32.Icons.Glow,
		["ImageColor3"] = v_u_26.Void,
		["Parent"] = v_u_44
	})
	local v_u_47 = v_u_23.new("Frame", {
		["Name"] = "Dim",
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundColor3"] = v_u_26.Void,
		["Parent"] = v_u_45
	})
	local v_u_48 = v_u_23.new("ImageLabel", {
		["Name"] = "Vignette",
		["Size"] = nil,
		["Image"] = nil,
		["ImageColor3"] = nil,
		["ImageTransparency"] = 1,
		["ZIndex"] = 2,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Image"] = v_u_32.Fx.Vignette,
		["ImageColor3"] = v_u_26.Void,
		["Parent"] = v_u_45
	})
	local v_u_49 = v_u_23.new("ImageLabel", {
		["Name"] = "Spot",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Image"] = nil,
		["ImageTransparency"] = 1,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(420, 420),
		["Image"] = v_u_32.Icons.Glow,
		["Parent"] = v_u_45
	})
	local v_u_50 = v_u_23.new("ImageLabel", {
		["Name"] = "Rays",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Image"] = nil,
		["ImageTransparency"] = 1,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(620, 620),
		["Image"] = v_u_32.Fx.Rays,
		["Parent"] = v_u_45
	})
	local function v62(p51) -- name: buildFace
		-- upvalues: (copy) v_u_23, (copy) v_u_26, (copy) v_u_32
		local v52 = v_u_23.new("Frame", {
			["Name"] = "Card",
			["Size"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(500, 700),
			["Parent"] = p51
		})
		local v53 = v_u_23.new("UIScale", {
			["Parent"] = v52
		})
		local v54 = v_u_23.new("Frame", {
			["Name"] = "Rim",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			v_u_23.Corner(30),
			["Parent"] = v52
		})
		local v55 = v_u_23.new("UIGradient", {
			["Rotation"] = 62,
			["Parent"] = nil,
			["Parent"] = v54
		})
		v_u_23.new("UIStroke", {
			["Color"] = nil,
			["Thickness"] = 2,
			["Transparency"] = 0.3,
			["Parent"] = nil,
			["Color"] = v_u_26.Void,
			["Parent"] = v54
		})
		local v56 = v_u_23.new("Frame", {
			["Name"] = "Body",
			["Position"] = UDim2.fromOffset(12, 12),
			["Size"] = UDim2.new(1, -24, 1, -24),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["ClipsDescendants"] = true,
			v_u_23.Corner(21),
			["Parent"] = v52
		})
		local v57 = v_u_23.new("UIGradient", {
			["Rotation"] = 90,
			["Parent"] = nil,
			["Parent"] = v56
		})
		local v58 = v_u_23.new("UIStroke", {
			["Thickness"] = 1.5,
			["Transparency"] = 0.5,
			["Parent"] = nil,
			["Parent"] = v56
		})
		local v59 = v_u_23.new("ImageLabel", {
			["Name"] = "Glare",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Image"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 0.8,
			["ZIndex"] = 20,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.4),
			["Size"] = UDim2.fromOffset(900, 900),
			["Image"] = v_u_32.Icons.Glow,
			["ImageColor3"] = Color3.new(1, 1, 1),
			["Parent"] = v56
		})
		local v60 = v_u_23.new
		local v61 = {
			["Name"] = "Band",
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(1100, 150),
			["Rotation"] = -28,
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["ZIndex"] = 20,
			v_u_23.new("UIGradient", {
				["Rotation"] = 90,
				["Transparency"] = nil,
				["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0.86), NumberSequenceKeypoint.new(1, 1) })
			}),
			["Parent"] = v56
		}
		return {
			["gui"] = p51,
			["scale"] = v53,
			["rimGrad"] = v55,
			["body"] = v56,
			["bodyGrad"] = v57,
			["bodyStroke"] = v58,
			["glare"] = v59,
			["band"] = v60("Frame", v61)
		}
	end
	local v_u_63 = v62(v_u_42)
	local v_u_64 = v62(v_u_43)
	local function v86(p65, p66, p67, p68) -- name: emblem
		-- upvalues: (copy) v_u_23, (copy) v_u_24, (copy) v_u_26, (copy) v_u_27
		local v69 = v_u_23.new("Frame", {
			["Name"] = "Level",
			["AnchorPoint"] = p68 or Vector2.zero,
			["Position"] = p67,
			["Size"] = UDim2.fromOffset(p66, p66),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["ZIndex"] = 4,
			v_u_23.Corner(v_u_24.Radius.Pill),
			["Parent"] = p65
		})
		local v70 = v_u_23.new("UIGradient", {
			["Rotation"] = 90,
			["Parent"] = nil,
			["Parent"] = v69
		})
		local v71 = v_u_23.new("UIStroke", {
			["Color"] = nil,
			["Thickness"] = 2,
			["Transparency"] = 0.25,
			["Parent"] = nil,
			["Color"] = v_u_26.Void,
			["Parent"] = v69
		})
		local v72 = {
			["Name"] = "LV",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "LV",
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextXAlignment"] = nil,
			["ZIndex"] = 5,
			["Parent"] = nil
		}
		local v73 = UDim2.new
		local v74 = p66 * 0.12
		v72.Position = v73(0, 0, 0, (math.floor(v74)))
		local v75 = UDim2.new
		local v76 = p66 * 0.2
		v72.Size = v75(1, 0, 0, (math.floor(v76)))
		v72.FontFace = v_u_27.Heavy
		local v77 = p66 * 0.19
		v72.TextSize = math.floor(v77)
		v72.TextXAlignment = Enum.TextXAlignment.Center
		v72.Parent = v69
		v72.BackgroundTransparency = 1
		v72.TextXAlignment = v72.TextXAlignment or Enum.TextXAlignment.Left
		v72.TextColor3 = v72.TextColor3 or v_u_26.Text
		local v78 = v_u_23.new("TextLabel", v72)
		v_u_23.TextStroke(v_u_26.Void, 1.5, 0.35).Parent = v78
		local v79 = {
			["Name"] = "Num",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "1",
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextXAlignment"] = nil,
			["ZIndex"] = 5,
			["Parent"] = nil
		}
		local v80 = UDim2.new
		local v81 = p66 * 0.26
		v79.Position = v80(0, 0, 0, (math.floor(v81)))
		local v82 = UDim2.new
		local v83 = p66 * 0.62
		v79.Size = v82(1, 0, 0, (math.floor(v83)))
		v79.FontFace = v_u_27.Display
		local v84 = p66 * 0.5
		v79.TextSize = math.floor(v84)
		v79.TextXAlignment = Enum.TextXAlignment.Center
		v79.Parent = v69
		v79.BackgroundTransparency = 1
		v79.TextXAlignment = v79.TextXAlignment or Enum.TextXAlignment.Left
		v79.TextColor3 = v79.TextColor3 or v_u_26.Text
		local v85 = v_u_23.new("TextLabel", v79)
		v_u_23.TextStroke(v_u_26.Void, 2, 0.2).Parent = v85
		return {
			["frame"] = v69,
			["grad"] = v70,
			["ring"] = v71,
			["num"] = v85
		}
	end
	local v_u_87 = v86(v_u_63.body, 76, UDim2.fromOffset(14, 14))
	local v88 = {
		["Name"] = "DisplayName",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 38,
		["TextTruncate"] = nil,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(102, 16),
		["Size"] = UDim2.fromOffset(250, 42),
		["FontFace"] = v_u_27.Display,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Parent"] = v_u_63.body,
		["BackgroundTransparency"] = 1
	}
	v88.TextXAlignment = v88.TextXAlignment or Enum.TextXAlignment.Left
	v88.TextColor3 = v88.TextColor3 or v_u_26.Text
	local v_u_89 = v_u_23.new("TextLabel", v88)
	v_u_23.TextStroke(v_u_26.Void, 1.5, 0.4).Parent = v_u_89
	local v90 = {
		["Name"] = "Username",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 22,
		["TextColor3"] = nil,
		["TextTruncate"] = nil,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(103, 58),
		["Size"] = UDim2.fromOffset(353, 26),
		["FontFace"] = v_u_27.SemiBold,
		["TextColor3"] = v_u_26.TextDim,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Parent"] = v_u_63.body,
		["BackgroundTransparency"] = 1
	}
	v90.TextXAlignment = v90.TextXAlignment or Enum.TextXAlignment.Left
	v90.TextColor3 = v90.TextColor3 or v_u_26.Text
	local v_u_91 = v_u_23.new("TextLabel", v90)
	local v92 = v_u_23.new("Frame", {
		["Name"] = "Tier",
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -14, 0, 20),
		["Size"] = UDim2.fromOffset(0, 30),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["ZIndex"] = 4,
		v_u_23.Corner(v_u_24.Radius.Pill),
		v_u_23.Padding(0, 13, 0, 13),
		["Parent"] = v_u_63.body
	})
	local v_u_93 = v_u_23.new("UIGradient", {
		["Rotation"] = 90,
		["Parent"] = nil,
		["Parent"] = v92
	})
	local v94 = {
		["Name"] = "Label",
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Text"] = "ROOKIE",
		["FontFace"] = nil,
		["TextSize"] = 16,
		["TextXAlignment"] = nil,
		["ZIndex"] = 5,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(0, 30),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["FontFace"] = v_u_27.Display,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Parent"] = v92,
		["BackgroundTransparency"] = 1
	}
	v94.TextXAlignment = v94.TextXAlignment or Enum.TextXAlignment.Left
	v94.TextColor3 = v94.TextColor3 or v_u_26.Text
	local v_u_95 = v_u_23.new("TextLabel", v94)
	local v96 = v_u_23.new("Frame", {
		["Name"] = "Art",
		["Position"] = UDim2.fromOffset(14, 100),
		["Size"] = UDim2.fromOffset(448, 290),
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["ClipsDescendants"] = true,
		["ZIndex"] = 2,
		v_u_23.Corner(16),
		["Parent"] = v_u_63.body
	})
	local v_u_97 = v_u_23.new("UIGradient", {
		["Rotation"] = 90,
		["Parent"] = nil,
		["Parent"] = v96
	})
	local v_u_98 = v_u_23.new("UIStroke", {
		["Thickness"] = 1.5,
		["Transparency"] = 0.45,
		["Parent"] = nil,
		["Parent"] = v96
	})
	local v_u_99 = v_u_23.new("ImageLabel", {
		["Name"] = "Rays",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Image"] = nil,
		["ImageTransparency"] = 0.85,
		["ZIndex"] = 2,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.42),
		["Size"] = UDim2.fromOffset(640, 640),
		["Image"] = v_u_32.Fx.Rays,
		["Parent"] = v96
	})
	local v_u_100 = v_u_23.new("ImageLabel", {
		["Name"] = "Glow",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Image"] = nil,
		["ImageTransparency"] = 0.5,
		["ZIndex"] = 2,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.52),
		["Size"] = UDim2.fromOffset(480, 480),
		["Image"] = v_u_32.Icons.Glow,
		["Parent"] = v96
	})
	v_u_23.new("ImageLabel", {
		["Name"] = "FloorShadow",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Image"] = nil,
		["ImageColor3"] = nil,
		["ImageTransparency"] = 0.4,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 1, -16),
		["Size"] = UDim2.fromOffset(300, 70),
		["Image"] = v_u_32.Icons.Glow,
		["ImageColor3"] = v_u_26.Void,
		["Parent"] = v96
	})
	local v_u_101 = v_u_23.new("ImageLabel", {
		["Name"] = "Avatar",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Image"] = "",
		["ZIndex"] = 4,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, 24),
		["Size"] = UDim2.fromOffset(330, 330),
		["Parent"] = v96
	})
	local v_u_102 = v_u_23.new("Frame", {
		["Name"] = "Fade",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["ZIndex"] = 5,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, 70),
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Parent"] = v96
	})
	v_u_23.new("UIGradient", {
		["Rotation"] = 90,
		["Transparency"] = nil,
		["Parent"] = nil,
		["Transparency"] = NumberSequence.new(1, 0.2),
		["Parent"] = v_u_102
	})
	local v103 = {
		["Rotation"] = 58,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = v_u_12,
		["Parent"] = v_u_23.new("Frame", {
			["Name"] = "Holo",
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["Parent"] = v96
		})
	}
	local v_u_104 = v_u_23.new("UIGradient", v103)
	local v105 = Random.new(7)
	local v_u_106 = {}
	local v_u_107 = {}
	local v_u_108 = 0
	local function v115(p109, p110, p111, p112) -- name: xpBar
		-- upvalues: (copy) v_u_23, (copy) v_u_26, (copy) v_u_24
		local v113 = v_u_23.new("Frame", {
			["Name"] = "XpBar",
			["Position"] = p110,
			["Size"] = UDim2.fromOffset(p111, p112),
			["BackgroundColor3"] = v_u_26.Void,
			["BackgroundTransparency"] = 0.35,
			["ClipsDescendants"] = true,
			["ZIndex"] = 4,
			v_u_23.Corner(v_u_24.Radius.Pill),
			v_u_23.Stroke(v_u_26.Stroke, 1, 0.85),
			["Parent"] = p109
		})
		local v114 = v_u_23.new("Frame", {
			["Name"] = "Fill",
			["Size"] = UDim2.fromScale(0, 1),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["ZIndex"] = 5,
			v_u_23.Corner(v_u_24.Radius.Pill),
			["Parent"] = v113
		})
		return {
			["track"] = v113,
			["fill"] = v114,
			["fillGrad"] = v_u_23.new("UIGradient", {
				["Parent"] = v114
			})
		}
	end
	for v116 = 1, 14 do
		local v117 = v105:NextInteger(14, 26)
		v_u_106[v116] = v_u_23.new("ImageLabel", {
			["Name"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = nil,
			["Image"] = nil,
			["ImageTransparency"] = 1,
			["Visible"] = false,
			["ZIndex"] = 7,
			["Parent"] = nil,
			["Name"] = "Sparkle" .. v116,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(v105:NextNumber(0.06, 0.94), v105:NextNumber(0.06, 0.8)),
			["Size"] = UDim2.fromOffset(v117, v117),
			["Rotation"] = v105:NextInteger(0, 44),
			["Image"] = v_u_32.Fx.Sparkle,
			["Parent"] = v96
		})
		v_u_107[v116] = v105:NextNumber(0, 2)
	end
	local v118 = {
		["Name"] = "LevelLine",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "LEVEL 1",
		["FontFace"] = nil,
		["TextSize"] = 24,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(16, 400),
		["Size"] = UDim2.fromOffset(200, 28),
		["FontFace"] = v_u_27.Display,
		["Parent"] = v_u_63.body,
		["BackgroundTransparency"] = 1
	}
	v118.TextXAlignment = v118.TextXAlignment or Enum.TextXAlignment.Left
	v118.TextColor3 = v118.TextColor3 or v_u_26.Text
	local v_u_119 = v_u_23.new("TextLabel", v118)
	local v120 = {
		["Name"] = "Xp",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 20,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -16, 0, 402),
		["Size"] = UDim2.fromOffset(260, 26),
		["FontFace"] = v_u_27.Bold,
		["TextColor3"] = v_u_26.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_63.body,
		["BackgroundTransparency"] = 1
	}
	v120.TextXAlignment = v120.TextXAlignment or Enum.TextXAlignment.Left
	v120.TextColor3 = v120.TextColor3 or v_u_26.Text
	local v_u_121 = v_u_23.new("TextLabel", v120)
	local v_u_122 = v115(v_u_63.body, UDim2.fromOffset(16, 432), 444, 11)
	local v_u_123 = {}
	for v124 = 1, 6 do
		local v125 = (v124 - 1) % 3
		local v126 = (v124 - 1) // 3
		local v127 = v_u_23.new("Frame", {
			["Name"] = "Stat" .. v124,
			["Position"] = UDim2.fromOffset(v125 * 152 + 14, v126 * 88 + 456),
			["Size"] = UDim2.fromOffset(144, 80),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["BackgroundTransparency"] = 0.94,
			["ZIndex"] = 3,
			v_u_23.Corner(12),
			v_u_23.Stroke(v_u_26.Stroke, 1, 0.9),
			["Parent"] = v_u_63.body
		})
		local v128 = {
			["Name"] = "Value",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "0",
			["FontFace"] = nil,
			["TextSize"] = 40,
			["TextXAlignment"] = nil,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(0, 6),
			["Size"] = UDim2.new(1, 0, 0, 44),
			["FontFace"] = v_u_27.Display,
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["Parent"] = v127,
			["BackgroundTransparency"] = 1
		}
		v128.TextXAlignment = v128.TextXAlignment or Enum.TextXAlignment.Left
		v128.TextColor3 = v128.TextColor3 or v_u_26.Text
		local v129 = v_u_23.new("TextLabel", v128)
		local v130 = {
			["Name"] = "Label",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 19,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(0, 50),
			["Size"] = UDim2.new(1, 0, 0, 24),
			["FontFace"] = v_u_27.Heavy,
			["TextColor3"] = v_u_26.TextMuted,
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["Parent"] = v127,
			["BackgroundTransparency"] = 1
		}
		v130.TextXAlignment = v130.TextXAlignment or Enum.TextXAlignment.Left
		v130.TextColor3 = v130.TextColor3 or v_u_26.Text
		v_u_123[v124] = {
			["value"] = v129,
			["label"] = v_u_23.new("TextLabel", v130)
		}
	end
	local v131 = {
		["Name"] = "Brand",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "TRIBES",
		["FontFace"] = nil,
		["TextSize"] = 19,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(18, 640),
		["Size"] = UDim2.fromOffset(200, 22),
		["FontFace"] = v_u_27.Display,
		["Parent"] = v_u_63.body,
		["BackgroundTransparency"] = 1
	}
	v131.TextXAlignment = v131.TextXAlignment or Enum.TextXAlignment.Left
	v131.TextColor3 = v131.TextColor3 or v_u_26.Text
	local v_u_132 = v_u_23.new("TextLabel", v131)
	local v133 = {
		["Name"] = "Kind",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "PLAYER CARD",
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -18, 0, 642),
		["Size"] = UDim2.fromOffset(220, 20),
		["FontFace"] = v_u_27.Heavy,
		["TextColor3"] = v_u_26.TextMuted,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_63.body,
		["BackgroundTransparency"] = 1
	}
	v133.TextXAlignment = v133.TextXAlignment or Enum.TextXAlignment.Left
	v133.TextColor3 = v133.TextColor3 or v_u_26.Text
	v_u_23.new("TextLabel", v133)
	local v_u_134 = v_u_23.new("ImageLabel", {
		["Name"] = "Headshot",
		["Position"] = UDim2.fromOffset(14, 14),
		["Size"] = UDim2.fromOffset(64, 64),
		["BackgroundColor3"] = v_u_26.PanelHi,
		["Image"] = "",
		["ZIndex"] = 4,
		v_u_23.Corner(v_u_24.Radius.Pill),
		["Parent"] = v_u_64.body
	})
	local v_u_135 = v_u_23.new("UIStroke", {
		["Thickness"] = 2.5,
		["Transparency"] = 0.1,
		["Parent"] = nil,
		["Parent"] = v_u_134
	})
	local v136 = {
		["Name"] = "DisplayName",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 32,
		["TextTruncate"] = nil,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(90, 14),
		["Size"] = UDim2.fromOffset(300, 38),
		["FontFace"] = v_u_27.Display,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Parent"] = v_u_64.body,
		["BackgroundTransparency"] = 1
	}
	v136.TextXAlignment = v136.TextXAlignment or Enum.TextXAlignment.Left
	v136.TextColor3 = v136.TextColor3 or v_u_26.Text
	local v_u_137 = v_u_23.new("TextLabel", v136)
	v_u_23.TextStroke(v_u_26.Void, 1.5, 0.4).Parent = v_u_137
	local v138 = {
		["Name"] = "Username",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 20,
		["TextColor3"] = nil,
		["TextTruncate"] = nil,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(91, 50),
		["Size"] = UDim2.fromOffset(299, 24),
		["FontFace"] = v_u_27.SemiBold,
		["TextColor3"] = v_u_26.TextDim,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Parent"] = v_u_64.body,
		["BackgroundTransparency"] = 1
	}
	v138.TextXAlignment = v138.TextXAlignment or Enum.TextXAlignment.Left
	v138.TextColor3 = v138.TextColor3 or v_u_26.Text
	local v_u_139 = v_u_23.new("TextLabel", v138)
	local v_u_140 = v86(v_u_64.body, 64, UDim2.new(1, -14, 0, 14), Vector2.new(1, 0))
	local v_u_141 = v_u_23.new("Frame", {
		["Name"] = "Divider",
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.6,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(14, 90),
		["Size"] = UDim2.new(1, -28, 0, 2),
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Parent"] = v_u_64.body
	})
	local v_u_142 = {}
	local v_u_143 = {}
	local function v159(p144, p145, p146, p147) -- name: section
		-- upvalues: (copy) v_u_27, (copy) v_u_64, (copy) v_u_26, (copy) v_u_23, (copy) v_u_142, (copy) v_u_143
		local v148 = {
			["Name"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 19,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["Name"] = "Section_" .. p146,
			["Position"] = UDim2.fromOffset(p144, p145),
			["Size"] = UDim2.fromOffset(214, 24),
			["Text"] = p146,
			["FontFace"] = v_u_27.Display,
			["Parent"] = v_u_64.body,
			["BackgroundTransparency"] = 1
		}
		v148.TextXAlignment = v148.TextXAlignment or Enum.TextXAlignment.Left
		v148.TextColor3 = v148.TextColor3 or v_u_26.Text
		local v149 = v_u_23.new("TextLabel", v148)
		local v150 = v_u_142
		table.insert(v150, v149)
		local v151 = p145 + 28
		for _, v152 in p147 do
			local v153 = v152[1]
			local v154 = v152[2]
			local v155 = v_u_23.new("Frame", {
				["Name"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 4,
				["Parent"] = nil,
				["Name"] = "Row_" .. v153,
				["Position"] = UDim2.fromOffset(p144, v151),
				["Size"] = UDim2.fromOffset(214, 35),
				["Parent"] = v_u_64.body
			})
			local v156 = {
				["Name"] = "Label",
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 20,
				["TextColor3"] = nil,
				["TextTruncate"] = nil,
				["ZIndex"] = 4,
				["Parent"] = nil,
				["Size"] = UDim2.new(0.62, 0, 1, 0),
				["Text"] = v154,
				["FontFace"] = v_u_27.SemiBold,
				["TextColor3"] = v_u_26.TextDim,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v155,
				["BackgroundTransparency"] = 1
			}
			v156.TextXAlignment = v156.TextXAlignment or Enum.TextXAlignment.Left
			v156.TextColor3 = v156.TextColor3 or v_u_26.Text
			v_u_23.new("TextLabel", v156)
			local v157 = v_u_143
			local v158 = {
				["Name"] = "Value",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "0",
				["FontFace"] = nil,
				["TextSize"] = 24,
				["TextXAlignment"] = nil,
				["ZIndex"] = 4,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.fromScale(1, 0),
				["Size"] = UDim2.new(0.5, 0, 1, 0),
				["FontFace"] = v_u_27.Display,
				["TextXAlignment"] = Enum.TextXAlignment.Right,
				["Parent"] = v155,
				["BackgroundTransparency"] = 1
			}
			v158.TextXAlignment = v158.TextXAlignment or Enum.TextXAlignment.Left
			v158.TextColor3 = v158.TextColor3 or v_u_26.Text
			v157[v153] = v_u_23.new("TextLabel", v158)
			v_u_23.new("Frame", {
				["Name"] = "Line",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.92,
				["ZIndex"] = 4,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.fromScale(0, 1),
				["Size"] = UDim2.new(1, 0, 0, 1),
				["BackgroundColor3"] = Color3.new(1, 1, 1),
				["Parent"] = v155
			})
			v151 = v151 + 35
		end
		return v151
	end
	v159(14, v159(14, 104, "MATCHES", {
		{ "matches", "Played" },
		{ "wins", "Wins" },
		{ "losses", "Losses" },
		{ "winRate", "Win rate" },
		{ "roundsWon", "Rounds won" }
	}) + 14, "STREAKS", {
		{ "streak", "Current" },
		{ "bestStreak", "Best" }
	})
	local v160 = v159(248, v159(248, 104, "COMBAT", {
		{ "kills", "Kills" },
		{ "deaths", "Deaths" },
		{ "assists", "Assists" },
		{ "kd", "K/D" },
		{ "kpm", "Kills / match" }
	}) + 14, "COLLECTION", {
		{ "items", "Items" },
		{ "maxed", "Maxed" },
		{ "drops", "Drops opened" }
	}) + 14
	local v161 = {
		["Name"] = "KitTitle",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "ACTIVE LOADOUT",
		["RichText"] = true,
		["FontFace"] = nil,
		["TextSize"] = 19,
		["TextTruncate"] = nil,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(14, v160),
		["Size"] = UDim2.fromOffset(448, 24),
		["FontFace"] = v_u_27.Display,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Parent"] = v_u_64.body,
		["BackgroundTransparency"] = 1
	}
	v161.TextXAlignment = v161.TextXAlignment or Enum.TextXAlignment.Left
	v161.TextColor3 = v161.TextColor3 or v_u_26.Text
	local v_u_162 = v_u_23.new("TextLabel", v161)
	local v163 = v_u_23.new("Frame", {
		["Name"] = "Kit",
		["Position"] = UDim2.fromOffset(14, v160 + 30),
		["Size"] = UDim2.fromOffset(448, 57),
		["ZIndex"] = 4,
		v_u_23.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
		["Parent"] = v_u_64.body
	})
	local v_u_164 = {}
	for v165 = 1, 7 do
		v_u_164[v165] = v_u_23.new("Frame", {
			["Name"] = "Item" .. v165,
			["Size"] = UDim2.fromOffset(57, 57),
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["BackgroundTransparency"] = 0.93,
			["LayoutOrder"] = v165,
			["ZIndex"] = 4,
			v_u_23.Corner(10),
			v_u_23.Stroke(v_u_26.Stroke, 1, 0.9),
			["Parent"] = v163
		})
	end
	local v166 = {
		["Name"] = "LevelLine",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "LEVEL 1",
		["FontFace"] = nil,
		["TextSize"] = 22,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(16, 576),
		["Size"] = UDim2.fromOffset(200, 26),
		["FontFace"] = v_u_27.Display,
		["Parent"] = v_u_64.body,
		["BackgroundTransparency"] = 1
	}
	v166.TextXAlignment = v166.TextXAlignment or Enum.TextXAlignment.Left
	v166.TextColor3 = v166.TextColor3 or v_u_26.Text
	local v_u_167 = v_u_23.new("TextLabel", v166)
	local v168 = {
		["Name"] = "Xp",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 19,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -16, 0, 578),
		["Size"] = UDim2.fromOffset(280, 24),
		["FontFace"] = v_u_27.Bold,
		["TextColor3"] = v_u_26.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_64.body,
		["BackgroundTransparency"] = 1
	}
	v168.TextXAlignment = v168.TextXAlignment or Enum.TextXAlignment.Left
	v168.TextColor3 = v168.TextColor3 or v_u_26.Text
	local v_u_169 = v_u_23.new("TextLabel", v168)
	local v_u_170 = v115(v_u_64.body, UDim2.fromOffset(16, 608), 444, 10)
	local v171 = {
		["Name"] = "Brand",
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "TRIBES",
		["FontFace"] = nil,
		["TextSize"] = 19,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(18, 640),
		["Size"] = UDim2.fromOffset(200, 22),
		["FontFace"] = v_u_27.Display,
		["Parent"] = v_u_64.body,
		["BackgroundTransparency"] = 1
	}
	v171.TextXAlignment = v171.TextXAlignment or Enum.TextXAlignment.Left
	v171.TextColor3 = v171.TextColor3 or v_u_26.Text
	local v_u_172 = v_u_23.new("TextLabel", v171)
	local v173 = {
		["Name"] = "Kind",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = "CAREER STATS",
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -18, 0, 642),
		["Size"] = UDim2.fromOffset(220, 20),
		["FontFace"] = v_u_27.Heavy,
		["TextColor3"] = v_u_26.TextMuted,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Parent"] = v_u_64.body,
		["BackgroundTransparency"] = 1
	}
	v173.TextXAlignment = v173.TextXAlignment or Enum.TextXAlignment.Left
	v173.TextColor3 = v173.TextColor3 or v_u_26.Text
	v_u_23.new("TextLabel", v173)
	local v_u_174 = nil
	local v_u_175 = v_u_10[1]
	local function v_u_183(p176) -- name: hex
		local v177 = string.format
		local v178 = p176.R * 255 + 0.5
		local v179 = math.floor(v178)
		local v180 = p176.G * 255 + 0.5
		local v181 = math.floor(v180)
		local v182 = p176.B * 255 + 0.5
		return v177("#%02X%02X%02X", v179, v181, (math.floor(v182)))
	end
	local function v_u_187(p184) -- name: paintTier
		-- upvalues: (ref) v_u_175, (ref) v_u_11, (copy) v_u_24
		local v185 = p184.rimGrad
		local v186
		if v_u_175.prism then
			v186 = v_u_11
		else
			v186 = ColorSequence.new({
				ColorSequenceKeypoint.new(0, v_u_175.hi),
				ColorSequenceKeypoint.new(0.45, v_u_175.lo),
				ColorSequenceKeypoint.new(0.62, v_u_24.Lighten(v_u_175.lo, 0.12)),
				ColorSequenceKeypoint.new(1, v_u_175.hi)
			})
		end
		v185.Color = v186
		p184.bodyGrad.Color = ColorSequence.new(v_u_24.Lighten(v_u_175.deep, 0.05), v_u_24.Darken(v_u_175.deep, 0.45))
		p184.bodyStroke.Color = v_u_175.hi
	end
	local function v_u_194(p188, p189) -- name: paintEmblem
		-- upvalues: (ref) v_u_175
		p188.grad.Color = ColorSequence.new(v_u_175.hi, v_u_175.lo)
		p188.num.Text = tostring(p189)
		local v190 = p188.num
		local v191
		if p189 >= 100 then
			local v192 = p188.frame.Size.X.Offset * 0.4
			v191 = math.floor(v192)
		else
			local v193 = p188.frame.Size.X.Offset * 0.5
			v191 = math.floor(v193)
		end
		v190.TextSize = v191
	end
	local function v_u_263() -- name: paint
		-- upvalues: (copy) v_u_25, (ref) v_u_174, (ref) v_u_175, (ref) v_u_10, (copy) v_u_23, (copy) v_u_187, (copy) v_u_63, (copy) v_u_64, (copy) v_u_194, (copy) v_u_87, (copy) v_u_89, (copy) v_u_31, (copy) v_u_91, (copy) v_u_93, (ref) v_u_11, (copy) v_u_95, (copy) v_u_26, (copy) v_u_97, (copy) v_u_24, (copy) v_u_98, (copy) v_u_99, (copy) v_u_100, (copy) v_u_102, (copy) v_u_104, (ref) v_u_20, (ref) v_u_108, (copy) v_u_106, (copy) v_u_132, (copy) v_u_172, (copy) v_u_119, (copy) v_u_121, (copy) v_u_122, (copy) v_u_123, (copy) v_u_137, (copy) v_u_139, (copy) v_u_135, (copy) v_u_140, (copy) v_u_141, (copy) v_u_142, (copy) v_u_29, (copy) v_u_28, (copy) v_u_143, (copy) v_u_162, (copy) v_u_183, (copy) v_u_164, (copy) v_u_30, (copy) v_u_167, (copy) v_u_169, (copy) v_u_170, (copy) v_u_49, (copy) v_u_50
		local v195 = v_u_25.Profile
		local v196 = v195.stats
		local v197 = type(v196) ~= "table" and {} or v195.stats
		local v198 = v_u_174 or v_u_25.Level()
		local v199 = v_u_10[1]
		for _, v200 in v_u_10 do
			if v200.min > v198 then
				continue
			end
			v199 = v200
		end
		v_u_175 = v199
		local v201 = v_u_25.Xp()
		local v202 = v_u_25.XpToNext
		local v203
		if v_u_174 then
			v203 = v198
		else
			v203 = nil
		end
		local v204 = v202(v203)
		local v205 = v198 >= 200
		local v206 = v205 and "MAX LEVEL" or string.format("%s / %s XP", v_u_23.FormatNumber(v201), v_u_23.FormatNumber(v204))
		local v207 = v205 and 1 or (v204 <= 0 and 0 or v201 / v204)
		v_u_187(v_u_63)
		v_u_187(v_u_64)
		v_u_194(v_u_87, v198)
		v_u_89.Text = v_u_31.DisplayName
		local v208 = utf8.len(v_u_31.DisplayName) or #v_u_31.DisplayName
		v_u_89.TextSize = v208 <= 12 and 38 or (v208 <= 15 and 32 or 27)
		v_u_91.Text = "@" .. v_u_31.Name
		local v209 = v_u_93
		local v210
		if v_u_175.prism then
			v210 = v_u_11
		else
			v210 = ColorSequence.new(v_u_175.hi, v_u_175.lo)
		end
		v209.Color = v210
		v_u_95.Text = v_u_175.name
		v_u_95.TextColor3 = v_u_26.TextDark
		v_u_97.Color = ColorSequence.new(v_u_24.Darken(v_u_175.lo, 0.2), v_u_24.Darken(v_u_175.deep, 0.2))
		v_u_98.Color = v_u_175.hi
		v_u_99.ImageColor3 = v_u_175.hi
		v_u_100.ImageColor3 = v_u_175.accent
		v_u_102.BackgroundColor3 = v_u_24.Darken(v_u_175.deep, 0.15)
		v_u_104.Transparency = v_u_20(v_u_175.holo)
		local v211
		if v_u_175.holo >= 0.45 then
			local v212 = v_u_175.holo * 14
			v211 = math.floor(v212)
		else
			v211 = 0
		end
		v_u_108 = v211
		for v213, v214 in v_u_106 do
			v214.Visible = v213 <= v_u_108
			v214.ImageColor3 = v_u_24.Lighten(v_u_175.accent, 0.45)
		end
		v_u_132.TextColor3 = v_u_175.accent
		v_u_172.TextColor3 = v_u_175.accent
		v_u_119.Text = "LEVEL " .. v198
		v_u_121.Text = v206
		local v215 = v_u_122
		v215.fill.Size = UDim2.fromScale(math.clamp(v207, 0, 1), 1)
		v215.fillGrad.Color = ColorSequence.new(v_u_24.Lighten(v_u_175.accent, 0.25), v_u_175.accent)
		local v216 = v197.matches
		local v217 = (type(v216) ~= "number" or v216 ~= v216) and 0 or v216
		local v218 = v197.wins
		local v219 = (type(v218) ~= "number" or v218 ~= v218) and 0 or v218
		local v220 = v197.losses
		local v221 = (type(v220) ~= "number" or v220 ~= v220) and 0 or v220
		local v222 = v197.kills
		local v223 = (type(v222) ~= "number" or v222 ~= v222) and 0 or v222
		local v224 = v197.deaths
		local v225 = (type(v224) ~= "number" or v224 ~= v224) and 0 or v224
		local v226 = v197.assists
		local v227 = (type(v226) ~= "number" or v226 ~= v226) and 0 or v226
		local v228 = v_u_25.Get("Streak")
		if type(v228) ~= "number" then
			local v229 = v197.streak
			v228 = (type(v229) ~= "number" or v229 ~= v229) and 0 or v229
		end
		local v230 = v197.bestStreak
		local v231 = (type(v230) ~= "number" or v230 ~= v230) and 0 or v230
		local v232 = math.max(v231, v228)
		local v233
		if v217 > 0 then
			local v234 = string.format
			local v235 = v219 / v217 * 100 + 0.5
			v233 = v234("%d%%", (math.floor(v235)))
		else
			v233 = "\226\128\148"
		end
		local v236
		if v225 > 0 then
			v236 = string.format("%.2f", v223 / v225)
		else
			v236 = v223 <= 0 and "\226\128\148" or string.format("%.2f", v223)
		end
		for v237, v238 in {
			{ v_u_23.FormatNumber(v219), "WINS" },
			{ v233, "WIN RATE" },
			{ v236, "K/D" },
			{ v_u_23.FormatNumber(v223), "KILLS" },
			{ v_u_23.FormatNumber(v217), "MATCHES" },
			{ v_u_23.FormatNumber(v232), "BEST STREAK" }
		} do
			v_u_123[v237].value.Text = v238[1]
			v_u_123[v237].label.Text = v238[2]
		end
		v_u_137.Text = v_u_31.DisplayName
		v_u_137.TextSize = v208 <= 12 and 32 or (v208 <= 15 and 28 or 24)
		v_u_139.Text = "@" .. v_u_31.Name
		v_u_135.Color = v_u_175.hi
		v_u_194(v_u_140, v198)
		v_u_141.BackgroundColor3 = v_u_175.hi
		for _, v239 in v_u_142 do
			v239.TextColor3 = v_u_175.accent
		end
		local v240 = 0
		local v241 = 0
		local v242 = 0
		for _, v243 in v_u_29.AllItems() do
			v240 = v240 + 1
			if not (v_u_28 and v_u_28.Owns(v243.id)) then
				continue
			end
			v241 = v241 + 1
			if v_u_28.MaxLevel(v243.id) <= 1 or v_u_28.Level(v243.id) < v_u_28.MaxLevel(v243.id) then
				continue
			end
			v242 = v242 + 1
		end
		local v244 = v195.dropStats
		local v245
		if type(v244) == "table" then
			local v246 = v244.total
			v245 = (type(v246) ~= "number" or v246 ~= v246) and 0 or v246
		else
			v245 = 0
		end
		local v247 = {
			["matches"] = v_u_23.FormatNumber(v217),
			["wins"] = v_u_23.FormatNumber(v219),
			["losses"] = v_u_23.FormatNumber(v221),
			["winRate"] = v233
		}
		local v248 = v_u_23.FormatNumber
		local v249 = v197.roundsWon
		v247.roundsWon = v248((type(v249) ~= "number" or v249 ~= v249) and 0 or v249)
		local v250
		if v228 >= 2 then
			v250 = "\240\159\148\165 " .. v228
		else
			v250 = tostring(v228)
		end
		v247.streak = v250
		v247.bestStreak = v_u_23.FormatNumber(v232)
		v247.kills = v_u_23.FormatNumber(v223)
		v247.deaths = v_u_23.FormatNumber(v225)
		v247.assists = v_u_23.FormatNumber(v227)
		v247.kd = v236
		local v251
		if v217 > 0 then
			v251 = string.format("%.1f", v223 / v217)
		else
			v251 = v223 <= 0 and "\226\128\148" or string.format("%.1f", v223)
		end
		v247.kpm = v251
		v247.items = not (v_u_28 and v_u_28.HasData()) and "\226\128\148" or string.format("%d / %d", v241, v240)
		v247.maxed = not (v_u_28 and v_u_28.HasData()) and "\226\128\148" or tostring(v242)
		v247.drops = v_u_23.FormatNumber(v245)
		for v252, v253 in v_u_143 do
			v253.Text = v247[v252] or "\226\128\148"
		end
		local v254 = v_u_25.Loadout()
		v_u_162.Text = string.format("<font color=\"%s\">ACTIVE LOADOUT</font>", v_u_183(v_u_175.accent))
		local v255 = {}
		for _, v256 in v254.items do
			if #v255 >= 6 then
				continue
			end
			table.insert(v255, v256)
		end
		local v257 = v254.armor
		if type(v257) == "string" then
			local v258 = v254.armor
			table.insert(v255, v258)
		end
		for v259, v260 in v_u_164 do
			local v261 = v255[v259]
			v260.Visible = v261 ~= nil
			v_u_30.Set(v260, v261, {})
		end
		v_u_167.Text = "LEVEL " .. v198
		v_u_169.Text = v206
		local v262 = v_u_170
		v262.fill.Size = UDim2.fromScale(math.clamp(v207, 0, 1), 1)
		v262.fillGrad.Color = ColorSequence.new(v_u_24.Lighten(v_u_175.accent, 0.25), v_u_175.accent)
		v_u_49.ImageColor3 = v_u_175.accent
		v_u_50.ImageColor3 = v_u_175.hi
	end
	local v_u_264 = v_u_23.new("Frame", {
		["Name"] = "PlayerCard",
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = p_u_22.Canvas.Menus
	})
	local v_u_265 = v_u_23.new("TextButton", {
		["Name"] = "PlayerCardCatcher",
		["Size"] = nil,
		["BackgroundTransparency"] = 1,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["Selectable"] = false,
		["Active"] = true,
		["Visible"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_23.BackdropCanvas or v_u_264
	})
	local v_u_266 = v_u_23.IconButton({
		["Name"] = "Close",
		["IconName"] = "cross",
		["IconScale"] = 0.42,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Color"] = nil,
		["Transparency"] = 0.2,
		["Sound"] = "Close",
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Size"] = UDim2.fromOffset(56, 56),
		["Color"] = v_u_26.Panel,
		["Parent"] = v_u_264
	})
	local v_u_267 = v_u_23.Button({
		["Name"] = "Flip",
		["Text"] = "FLIP",
		["TextSize"] = 22,
		["Style"] = "Dark",
		["Size"] = nil,
		["AnchorPoint"] = nil,
		["Radius"] = 14,
		["Sound"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(170, 54),
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Parent"] = v_u_264
	})
	local v_u_268 = require(script.Parent.Parent.RankArt)
	local v_u_269 = v_u_23.Button({
		["Name"] = "Ranks",
		["Text"] = "RANKS",
		["TextSize"] = 22,
		["Style"] = "Dark",
		["Size"] = nil,
		["AnchorPoint"] = nil,
		["Radius"] = 14,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(170, 54),
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Parent"] = v_u_264
	})
	local v_u_270 = v_u_268.Emblem(1, 34, {
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 12, 0.5, 0),
		["Parent"] = v_u_269.Face
	})
	v_u_269.Activated:Connect(function()
		-- upvalues: (copy) p_u_22
		p_u_22.MenuManager.Open("Ranks")
	end)
	v_u_23.KeyCap("F", {
		["Gamepad"] = nil,
		["Height"] = 24,
		["TextSize"] = 15,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["Gamepad"] = Enum.KeyCode.ButtonA,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -12, 0.5, -1),
		["Parent"] = v_u_267.Face
	})
	local v_u_271 = false
	local v_u_272 = false
	local v_u_273 = false
	local v_u_274 = 0
	local v_u_275 = 0
	local v_u_276 = 0
	local v_u_277 = 0
	local v_u_278 = 0
	local v_u_279 = 0
	local v_u_280 = 0
	local v_u_281 = 0
	local v_u_282 = 0
	local v_u_283 = 0
	local v_u_284 = 0
	local v_u_285 = 0
	local v_u_286 = false
	local v_u_287 = nil
	local v_u_288 = 0
	local v_u_289 = 0
	local v_u_290 = 0
	local v_u_291 = 0
	local v_u_292 = false
	local v_u_293 = 0
	local v_u_294 = 0
	local v_u_295 = 0
	local v_u_296 = 0
	local v_u_297 = nil
	local v_u_298 = false
	local v_u_299 = 1
	local v_u_300 = true
	local v_u_301 = 0.8
	local v_u_302 = 0.03
	local v_u_303 = 0
	local v_u_304 = 0
	local v_u_305 = 0
	local v_u_306 = 0
	local v_u_307 = 0
	local v_u_308 = 0
	local v_u_309 = -1
	local v_u_310 = -1
	local function v_u_343() -- name: layout
		-- upvalues: (copy) v_u_23, (ref) v_u_301, (ref) v_u_302, (copy) v_u_266, (copy) v_u_267, (copy) v_u_269, (ref) v_u_307, (ref) v_u_1, (ref) v_u_7, (ref) v_u_303, (copy) v_u_42, (copy) v_u_43, (copy) v_u_63, (copy) v_u_64
		local v311 = v_u_23.CanvasSize()
		local v312 = v_u_23.TopInset()
		if v_u_23.Compact and not v_u_23.Tablet then
			v_u_301 = 0.9
			v_u_302 = 0
			local v313 = v_u_266
			local v314 = UDim2.new
			local v315 = v312 - 52
			v313.Position = v314(1, -16, 0, (math.max(8, v315)))
			v_u_266.Size = UDim2.fromOffset(60, 60)
			local v316 = v311.Y * v_u_301 * 500 / 700
			local v317 = v311.X / 2 + v316 / 2 + (v311.X / 2 - v316 / 2) / 2
			local v318 = v_u_267.Instance
			local v319 = UDim2.fromOffset
			local v320 = math.floor(v317)
			local v321 = v311.Y * 0.84
			v318.Position = v319(v320, (math.floor(v321)))
			v_u_267.Instance.Size = UDim2.fromOffset(170, 60)
			local v322 = v_u_269.Instance
			local v323 = UDim2.fromOffset
			local v324 = math.floor(v317)
			local v325 = v311.Y * 0.84
			v322.Position = v323(v324, math.floor(v325) - 72)
			v_u_269.Instance.Size = UDim2.fromOffset(170, 60)
		else
			v_u_301 = 0.76
			v_u_302 = 0.05
			v_u_266.Position = UDim2.new(1, -24, 0, v312 + 4)
			v_u_266.Size = UDim2.fromOffset(56, 56)
			local v326 = (v311.Y * (0.5 - v_u_302 + v_u_301 / 2) + v311.Y) / 2
			local v327 = math.floor(v326)
			local v328 = v_u_267.Instance
			local v329 = UDim2.fromOffset
			local v330 = v311.X / 2
			v328.Position = v329(math.floor(v330) - 95, v327)
			v_u_267.Instance.Size = UDim2.fromOffset(170, 54)
			local v331 = v_u_269.Instance
			local v332 = UDim2.fromOffset
			local v333 = v311.X / 2
			v331.Position = v332(math.floor(v333) + 95, v327)
			v_u_269.Instance.Size = UDim2.fromOffset(170, 54)
		end
		v_u_307 = v_u_1:GetGuiInset().Y
		local v334 = v_u_7.CurrentCamera
		local v335 = (not v334 and 900 or v334.ViewportSize.Y) * v_u_301 / 700
		local v336 = math.clamp(v335, 1, 1.8)
		local v337 = v336 - v_u_303
		if math.abs(v337) > 0.01 then
			v_u_303 = v336
			local v338 = Vector2.new
			local v339 = v336 * 500
			local v340 = math.floor(v339)
			local v341 = v336 * 700
			local v342 = v338(v340, (math.floor(v341)))
			v_u_42.CanvasSize = v342
			v_u_43.CanvasSize = v342
			v_u_63.scale.Scale = v342.X / 500
			v_u_64.scale.Scale = v342.X / 500
		end
	end
	local function v_u_356() -- name: cardScreenRect
		-- upvalues: (ref) v_u_7, (copy) v_u_34
		local v344 = v_u_7.CurrentCamera
		local v345 = v_u_34.CFrame
		local v346 = (1 / 0)
		local v347 = (1 / 0)
		local v348 = (-1 / 0)
		local v349 = (-1 / 0)
		for _, v350 in {
			Vector3.new(-1, -1, 0),
			Vector3.new(1, -1, 0),
			Vector3.new(-1, 1, 0),
			Vector3.new(1, 1, 0)
		} do
			local v351 = v344:WorldToScreenPoint((v345 * CFrame.new(v350.X * 0.7142857142857143 / 2, v350.Y * 1 / 2, 0)).Position)
			local v352 = v351.X
			v346 = math.min(v346, v352)
			local v353 = v351.Y
			v347 = math.min(v347, v353)
			local v354 = v351.X
			v348 = math.max(v348, v354)
			local v355 = v351.Y
			v349 = math.max(v349, v355)
		end
		return v346, v347, v348, v349
	end
	local function v357() -- name: doFlip
		-- upvalues: (ref) v_u_271, (ref) v_u_272, (ref) v_u_282, (ref) v_u_280, (ref) v_u_281, (copy) p_u_22
		if v_u_271 and not v_u_272 then
			if v_u_282 >= 6.283185307179586 then
				v_u_282 = v_u_282 - 6.283185307179586
				v_u_280 = v_u_280 - 6.283185307179586
			end
			v_u_282 = v_u_282 + 3.141592653589793
			v_u_281 = v_u_281 + 1.5
			p_u_22.Sounds.Play("Card_Flip")
		end
	end
	local function v_u_426(p358) -- name: step
		-- upvalues: (ref) v_u_7, (ref) v_u_286, (ref) v_u_302, (ref) v_u_307, (ref) v_u_301, (ref) v_u_292, (ref) v_u_284, (ref) v_u_285, (ref) v_u_293, (ref) v_u_294, (ref) v_u_295, (ref) v_u_296, (ref) v_u_278, (ref) v_u_276, (ref) v_u_279, (ref) v_u_277, (ref) v_u_281, (ref) v_u_282, (ref) v_u_280, (ref) v_u_274, (ref) v_u_299, (ref) v_u_272, (ref) v_u_275, (ref) v_u_283, (copy) v_u_34, (copy) v_u_35, (ref) v_u_304, (ref) v_u_305, (ref) v_u_306, (copy) v_u_36, (ref) v_u_300, (copy) v_u_42, (copy) v_u_43, (copy) v_u_63, (copy) v_u_64, (ref) v_u_309, (ref) v_u_310, (copy) v_u_104, (ref) v_u_108, (copy) v_u_107, (copy) v_u_106, (copy) v_u_101, (copy) v_u_99, (ref) v_u_308, (copy) v_u_50, (copy) v_u_47, (copy) v_u_48, (copy) v_u_49, (copy) v_u_46, (copy) v_u_44, (copy) v_u_45, (copy) v_u_33, (ref) v_u_273, (ref) v_u_3
		local v359 = math.min(p358, 0.05)
		local v360 = v_u_7.CurrentCamera
		if not v360 then
			return
		end
		local v361 = os.clock()
		local v362 = v360.ViewportSize
		local v363 = 0
		local v364 = 0
		if v_u_286 then
			local v365 = v362.X / 2
			local v366 = v362.Y * (0.5 - v_u_302) - v_u_307
			local v367 = v362.Y * v_u_301 / 2
			local v368
			if v_u_292 then
				v368 = v367 * 500 / 700 * 1.3
			else
				v368 = v362.X * 0.5
			end
			local v369
			if v_u_292 then
				v369 = v367 * 1.3
			else
				v369 = v362.Y * 0.5
			end
			local v370 = (v_u_284 - v365) / v368
			v363 = math.clamp(v370, -1, 1)
			local v371 = (v_u_285 - v366) / v369
			v364 = math.clamp(v371, -1, 1)
		elseif v_u_293 ~= 0 or v_u_294 ~= 0 then
			v363 = v_u_293
			v364 = v_u_294
		end
		local v372 = v_u_286 and 0.35 or 1
		local v373 = v363 * 0.12217304763960307 + v_u_295
		local v374 = v361 * 0.7
		local v375 = v373 + math.sin(v374) * 0.018 * v372
		local v376 = v364 * 0.08726646259971647 + v_u_296
		local v377 = v361 * 0.93
		local v378 = v376 + math.cos(v377) * 0.014 * v372
		v_u_278 = v_u_278 + ((v375 - v_u_276) * 90 - v_u_278 * 13.661039491927399) * v359
		v_u_279 = v_u_279 + ((v378 - v_u_277) * 90 - v_u_279 * 13.661039491927399) * v359
		v_u_276 = v_u_276 + v_u_278 * v359
		v_u_277 = v_u_277 + v_u_279 * v359
		v_u_281 = v_u_281 + ((v_u_282 - v_u_280) * 120 - v_u_281 * 13.145341380123986) * v359
		v_u_280 = v_u_280 + v_u_281 * v359
		local v379 = 0
		local v380 = (v361 - v_u_274) / (v_u_299 * 0.62)
		local v381 = math.clamp(v380, 0, 1)
		local v382, v383
		if v381 < 1 then
			v382 = -(1 - ((v381 - 1) ^ 3 * 2.4 + 1 + (v381 - 1) ^ 2 * 1.4)) * 1.05
			v383 = -(1 - (1 - (1 - v381) ^ 3)) * 3.141592653589793 * 2
		else
			v382 = 0
			v383 = 0
		end
		local v384 = (v361 - v_u_274) / v_u_299 - 0.62
		if v384 > 0 and v384 < 0.35 then
			local v385 = v384 / 0.35 * 3.141592653589793
			v379 = math.sin(v385) * 0.035
		end
		if v_u_272 then
			local v386 = (v361 - v_u_275) / (v_u_299 * 0.24)
			local v387 = math.clamp(v386, 0, 1)
			v382 = v382 - v387 * v387 * v387 * 1.25
			v383 = v383 + v387 * 0.7
			local v388 = v_u_283 - v359 / 0.24
			v_u_283 = math.max(0, v388)
		else
			local v389 = v_u_283 + v359 / 0.3
			v_u_283 = math.min(1, v389)
		end
		local v390 = v360.FieldOfView
		local v391 = math.rad(v390) / 2
		local v392 = math.tan(v391)
		local v393 = 1 / (v392 * 2 * v_u_301)
		local v394 = v393 * 2 * v392
		local v395 = v360.CFrame * CFrame.new(0, (v_u_302 + v382) * v394, -v393 * (1 - v379))
		local v396 = v_u_276 + v_u_280 + v383
		v_u_34.CFrame = v395 * CFrame.Angles(v_u_277, 0, 0) * CFrame.Angles(0, v396, 0)
		local v397 = v_u_276 / 0.12217304763960307
		local v398 = v_u_277 / 0.08726646259971647
		v_u_35.CFrame = v395 * CFrame.new(-v397 * 0.05, v398 * 0.03 + -0.035, -0.14)
		local v399 = v393 + 0.4
		local v400 = v399 * 2 * v392 * 1.2
		local v401 = v400 - v_u_304
		if math.abs(v401) > 0.001 or (v362.X ~= v_u_305 or v362.Y ~= v_u_306) then
			local v402 = v362.X
			local v403 = v362.Y
			v_u_304 = v400
			v_u_305 = v402
			v_u_306 = v403
			local v404 = v_u_36
			local v405 = v400 * v362.X
			local v406 = v362.Y
			local v407 = v405 / math.max(v406, 1) * 1.1
			v404.Size = Vector3.new(v407, v400, 0.004)
			v_u_35.Size = Vector3.new(1.0714285, 1.35, 0.004)
		end
		v_u_36.CFrame = v360.CFrame * CFrame.new(0, 0, -v399)
		local v408 = v_u_34.CFrame.LookVector:Dot(v360.CFrame.Position - v_u_34.Position) < 0
		if v408 ~= v_u_300 then
			v_u_300 = v408
			v_u_42.Enabled = v408
			v_u_43.Enabled = not v408
		end
		local v409
		if v408 then
			v409 = v_u_63
		else
			v409 = v_u_64
		end
		local v410 = math.clamp(v397, -1.4, 1.4) * 0.55 + 0.5
		local v411 = math.clamp(v398, -1.4, 1.4) * 0.55 + 0.45
		local v412 = v410 - v_u_309
		local v413, v414, v415, v416, v417, v418, v419, v420, v421, v422
		if math.abs(v412) > 0.002 then
			v_u_309 = v410
			v_u_310 = v411
			v409.glare.Position = UDim2.fromScale(v410, v411)
			v413 = v409.glare
			v414 = v397 * v397 + v398 * v398
			v415 = math.sqrt(v414)
			v413.ImageTransparency = 0.82 - math.min(1, v415) * 0.12
			v409.band.Position = UDim2.fromScale(0.5 - v397 * 0.6, 0.55 - v398 * 0.3)
			v409.rimGrad.Offset = Vector2.new(v397 * 0.35, v398 * 0.35)
			if v408 then
				v_u_104.Offset = Vector2.new(v397 * 0.6, v398 * 0.4)
				v416 = v397 * 2.3 + v398 * 1.7
				for v425 = 1, v_u_108 do
					v417 = (v416 + v_u_107[v425]) * 3.141592653589793
					v418 = math.cos(v417)
					v419 = v418 <= 0 and 0 or v418 ^ 10
					v_u_106[v425].ImageTransparency = 1 - v419 * 0.75
				end
				v_u_101.Position = UDim2.new(0.5, -v397 * 10, 1, v398 * 5 + 24)
				v_u_99.Position = UDim2.new(0.5, v397 * 7, 0.42, -v398 * 5)
			end
			v_u_308 = (v_u_308 + v359 * 5) % 360
			if v408 then
				v_u_99.Rotation = v_u_308
			end
			v_u_50.Rotation = -v_u_308 * 0.6
			v_u_47.BackgroundTransparency = 1 - v_u_283 * 0.55
			v_u_48.ImageTransparency = 1 - v_u_283 * 0.8
			v_u_49.ImageTransparency = 1 - v_u_283 * 0.3
			v_u_50.ImageTransparency = 1 - v_u_283 * 0.06
			v_u_46.ImageTransparency = 1 - v_u_283 * 0.7
			if v_u_272 and v361 - v_u_275 >= v_u_299 * 0.24 then
				v_u_272 = false
				v420 = v_u_43
				v421 = v_u_44
				v422 = v_u_45
				v_u_42.Enabled = false
				v420.Enabled = false
				v421.Enabled = false
				v422.Enabled = false
				v_u_33.Parent = nil
				if v_u_273 then
					v_u_273 = false
					v_u_3:UnbindFromRenderStep("TR_PlayerCard")
				end
			end
			return
		else
			local v424 = v411 - v_u_310
			if math.abs(v424) > 0.002 then
				v_u_309 = v410
				v_u_310 = v411
				v409.glare.Position = UDim2.fromScale(v410, v411)
				v413 = v409.glare
				v414 = v397 * v397 + v398 * v398
				v415 = math.sqrt(v414)
				v413.ImageTransparency = 0.82 - math.min(1, v415) * 0.12
				v409.band.Position = UDim2.fromScale(0.5 - v397 * 0.6, 0.55 - v398 * 0.3)
				v409.rimGrad.Offset = Vector2.new(v397 * 0.35, v398 * 0.35)
				if v408 then
					v_u_104.Offset = Vector2.new(v397 * 0.6, v398 * 0.4)
					v416 = v397 * 2.3 + v398 * 1.7
					for v425 = 1, v_u_108 do
						v417 = (v416 + v_u_107[v425]) * 3.141592653589793
						v418 = math.cos(v417)
						v419 = v418 <= 0 and 0 or v418 ^ 10
						v_u_106[v425].ImageTransparency = 1 - v419 * 0.75
					end
					v_u_101.Position = UDim2.new(0.5, -v397 * 10, 1, v398 * 5 + 24)
					v_u_99.Position = UDim2.new(0.5, v397 * 7, 0.42, -v398 * 5)
				end
				v_u_308 = (v_u_308 + v359 * 5) % 360
				if v408 then
					v_u_99.Rotation = v_u_308
				end
				v_u_50.Rotation = -v_u_308 * 0.6
				v_u_47.BackgroundTransparency = 1 - v_u_283 * 0.55
				v_u_48.ImageTransparency = 1 - v_u_283 * 0.8
				v_u_49.ImageTransparency = 1 - v_u_283 * 0.3
				v_u_50.ImageTransparency = 1 - v_u_283 * 0.06
				v_u_46.ImageTransparency = 1 - v_u_283 * 0.7
				if v_u_272 and v361 - v_u_275 >= v_u_299 * 0.24 then
					v_u_272 = false
					v420 = v_u_43
					v421 = v_u_44
					v422 = v_u_45
					v_u_42.Enabled = false
					v420.Enabled = false
					v421.Enabled = false
					v422.Enabled = false
					v_u_33.Parent = nil
					if v_u_273 then
						v_u_273 = false
						v_u_3:UnbindFromRenderStep("TR_PlayerCard")
					end
				end
			else
				v_u_308 = (v_u_308 + v359 * 5) % 360
				if v408 then
					v_u_99.Rotation = v_u_308
				end
				v_u_50.Rotation = -v_u_308 * 0.6
				v_u_47.BackgroundTransparency = 1 - v_u_283 * 0.55
				v_u_48.ImageTransparency = 1 - v_u_283 * 0.8
				v_u_49.ImageTransparency = 1 - v_u_283 * 0.3
				v_u_50.ImageTransparency = 1 - v_u_283 * 0.06
				v_u_46.ImageTransparency = 1 - v_u_283 * 0.7
				if v_u_272 and v361 - v_u_275 >= v_u_299 * 0.24 then
					v_u_272 = false
					v420 = v_u_43
					v421 = v_u_44
					v422 = v_u_45
					v_u_42.Enabled = false
					v420.Enabled = false
					v421.Enabled = false
					v422.Enabled = false
					v_u_33.Parent = nil
					if v_u_273 then
						v_u_273 = false
						v_u_3:UnbindFromRenderStep("TR_PlayerCard")
					end
				end
			end
		end
	end
	v_u_265.InputBegan:Connect(function(p427)
		-- upvalues: (ref) v_u_271, (ref) v_u_272, (ref) v_u_287, (ref) v_u_288, (ref) v_u_289, (ref) v_u_290, (ref) v_u_291, (ref) v_u_292, (ref) v_u_286, (ref) v_u_284, (ref) v_u_285
		if v_u_271 and not v_u_272 then
			local v428 = p427.UserInputType
			if v428 == Enum.UserInputType.MouseButton1 or v428 == Enum.UserInputType.Touch then
				v_u_287 = p427
				local v429 = p427.Position.X
				local v430 = p427.Position.Y
				local v431 = os.clock()
				v_u_288 = v429
				v_u_289 = v430
				v_u_290 = v431
				v_u_291 = 0
				if v428 == Enum.UserInputType.Touch then
					v_u_292 = true
					v_u_286 = true
					local v432 = p427.Position.X
					local v433 = p427.Position.Y
					v_u_284 = v432
					v_u_285 = v433
				end
			end
		end
	end)
	v_u_265.InputChanged:Connect(function(p434)
		-- upvalues: (ref) v_u_271, (ref) v_u_292, (ref) v_u_284, (ref) v_u_285, (ref) v_u_291, (ref) v_u_288, (ref) v_u_289
		if v_u_271 and (v_u_292 and p434.UserInputType == Enum.UserInputType.Touch) then
			local v435 = p434.Position.X
			local v436 = p434.Position.Y
			v_u_284 = v435
			v_u_285 = v436
			local v437 = v_u_291
			local v438 = v_u_284 - v_u_288
			local v439 = math.abs(v438)
			local v440 = v_u_285 - v_u_289
			local v441 = v439 + math.abs(v440)
			v_u_291 = math.max(v437, v441)
		end
	end)
	v_u_6.InputChanged:Connect(function(p442)
		-- upvalues: (ref) v_u_271, (ref) v_u_292, (ref) v_u_298, (ref) v_u_284, (ref) v_u_285, (ref) v_u_286, (ref) v_u_293, (ref) v_u_294
		if v_u_271 then
			local v443 = p442.UserInputType
			if v443 == Enum.UserInputType.MouseMovement and not (v_u_292 or v_u_298) then
				local v444 = p442.Position.X
				local v445 = p442.Position.Y
				v_u_284 = v444
				v_u_285 = v445
				v_u_286 = true
			elseif v443 == Enum.UserInputType.Gamepad1 and p442.KeyCode == Enum.KeyCode.Thumbstick2 then
				local v446 = p442.Position
				local v447 = v446.X * v446.X + v446.Y * v446.Y
				if math.sqrt(v447) < 0.2 then
					v_u_293 = 0
					v_u_294 = 0
					return
				end
				local v448 = v446.X
				local v449 = -v446.Y
				v_u_293 = v448
				v_u_294 = v449
				v_u_286 = false
			end
		else
			return
		end
	end)
	v_u_6.InputEnded:Connect(function(p450)
		-- upvalues: (ref) v_u_287, (ref) v_u_292, (ref) v_u_298, (ref) v_u_286, (ref) v_u_271, (ref) v_u_272, (ref) v_u_291, (ref) v_u_288, (ref) v_u_289, (ref) v_u_290, (copy) v_u_356, (ref) v_u_282, (ref) v_u_280, (ref) v_u_281, (copy) p_u_22
		local v451 = p450.UserInputType == Enum.UserInputType.Touch
		if p450 == v_u_287 or v451 and v_u_292 then
			v_u_287 = nil
			if v451 then
				v_u_292 = false
				if not v_u_298 then
					v_u_286 = false
				end
			end
			if v_u_271 and not v_u_272 then
				local v452 = v_u_291
				local v453 = p450.Position.X - v_u_288
				local v454 = v452 + math.abs(v453)
				local v455 = p450.Position.Y - v_u_289
				if v454 + math.abs(v455) <= 16 and os.clock() - v_u_290 <= 0.45 then
					local v456 = v_u_288
					local v457 = v_u_289
					local v458, v459, v460, v461 = v_u_356()
					local v462
					if v458 <= v456 and (v456 <= v460 and v459 <= v457) then
						v462 = v457 <= v461
					else
						v462 = false
					end
					if v462 then
						if v_u_271 then
							if not v_u_272 then
								if v_u_282 >= 6.283185307179586 then
									v_u_282 = v_u_282 - 6.283185307179586
									v_u_280 = v_u_280 - 6.283185307179586
								end
								v_u_282 = v_u_282 + 3.141592653589793
								v_u_281 = v_u_281 + 1.5
								p_u_22.Sounds.Play("Card_Flip")
							end
						end
					else
						p_u_22.MenuManager.Close("PlayerCard")
					end
				end
			else
				return
			end
		else
			return
		end
	end)
	v_u_6.InputBegan:Connect(function(p463, p464)
		-- upvalues: (ref) v_u_271, (ref) v_u_272, (ref) v_u_6, (ref) v_u_282, (ref) v_u_280, (ref) v_u_281, (copy) p_u_22, (ref) v_u_1
		if v_u_271 and not (v_u_272 or v_u_6:GetFocusedTextBox()) then
			if p463.KeyCode == Enum.KeyCode.F and not p464 then
				if v_u_271 then
					if not v_u_272 then
						if v_u_282 >= 6.283185307179586 then
							v_u_282 = v_u_282 - 6.283185307179586
							v_u_280 = v_u_280 - 6.283185307179586
						end
						v_u_282 = v_u_282 + 3.141592653589793
						v_u_281 = v_u_281 + 1.5
						p_u_22.Sounds.Play("Card_Flip")
					end
				end
			elseif p463.KeyCode == Enum.KeyCode.ButtonA and (v_u_1.SelectedObject == nil and v_u_271) then
				if v_u_272 then
					return
				end
				if v_u_282 >= 6.283185307179586 then
					v_u_282 = v_u_282 - 6.283185307179586
					v_u_280 = v_u_280 - 6.283185307179586
				end
				v_u_282 = v_u_282 + 3.141592653589793
				v_u_281 = v_u_281 + 1.5
				p_u_22.Sounds.Play("Card_Flip")
			end
		end
	end)
	local v_u_465 = nil
	local function v_u_473(p466) -- name: setGyro
		-- upvalues: (ref) v_u_465, (ref) v_u_295, (ref) v_u_296, (ref) v_u_297, (copy) v_u_23, (ref) v_u_6
		if v_u_465 then
			v_u_465:Disconnect()
			v_u_465 = nil
		end
		v_u_295 = 0
		v_u_296 = 0
		v_u_297 = nil
		if p466 and (v_u_23.Touch and v_u_6.GyroscopeEnabled) then
			v_u_465 = v_u_6.DeviceRotationChanged:Connect(function(_, p467)
				-- upvalues: (ref) v_u_297, (ref) v_u_295, (ref) v_u_296
				if v_u_297 then
					local v468 = v_u_297:Lerp(p467, 0.03)
					v_u_297 = v468
					local v469, v470 = v468:ToObjectSpace(p467):ToEulerAnglesYXZ()
					local v471 = -v470 * 0.5
					v_u_295 = math.clamp(v471, -0.08726646259971647, 0.08726646259971647)
					local v472 = -v469 * 0.5
					v_u_296 = math.clamp(v472, -0.06981317007977318, 0.06981317007977318)
				else
					v_u_297 = p467
				end
			end)
		end
	end
	v_u_266.Activated:Connect(function()
		-- upvalues: (copy) p_u_22
		p_u_22.MenuManager.Close("PlayerCard")
	end)
	v_u_267.Activated:Connect(v357)
	local v490 = {
		["blur"] = false,
		["open"] = nil,
		["close"] = nil,
		["open"] = function() -- name: open
			-- upvalues: (ref) v_u_271, (ref) v_u_272, (copy) p_u_22, (ref) v_u_21, (ref) v_u_5, (ref) v_u_4, (copy) v_u_101, (copy) v_u_31, (copy) v_u_134, (copy) v_u_263, (copy) v_u_268, (copy) v_u_270, (copy) v_u_343, (ref) v_u_274, (ref) v_u_276, (ref) v_u_277, (ref) v_u_278, (ref) v_u_279, (ref) v_u_280, (ref) v_u_281, (ref) v_u_282, (ref) v_u_283, (ref) v_u_309, (ref) v_u_310, (ref) v_u_298, (ref) v_u_286, (ref) v_u_292, (ref) v_u_287, (ref) v_u_293, (ref) v_u_294, (ref) v_u_300, (copy) v_u_42, (copy) v_u_43, (copy) v_u_44, (copy) v_u_45, (copy) v_u_33, (ref) v_u_7, (copy) v_u_264, (copy) v_u_265, (copy) v_u_23, (copy) v_u_266, (copy) v_u_267, (copy) v_u_473, (ref) v_u_273, (ref) v_u_3, (copy) v_u_426
			if not v_u_271 then
				v_u_271 = true
				v_u_272 = false
				p_u_22.SetHudHidden("PlayerCard", true)
				if p_u_22.TopbarSettings and p_u_22.TopbarSettings.SetHidden then
					p_u_22.TopbarSettings.SetHidden("PlayerCard", true)
				end
				if not v_u_21 then
					local v_u_474 = {}
					local function v477()
						-- upvalues: (ref) v_u_5, (copy) v_u_474, (ref) v_u_4
						local v475 = v_u_5:FindFirstChildOfClass("ChatWindowConfiguration")
						local v476 = v_u_5:FindFirstChildOfClass("ChatInputBarConfiguration")
						if v475 then
							v_u_474.window = v475.Enabled
							v475.Enabled = false
						end
						if v476 then
							v_u_474.bar = v476.Enabled
							v476.Enabled = false
						end
						v_u_474.core = v_u_4:GetCoreGuiEnabled(Enum.CoreGuiType.Chat)
						v_u_4:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, false)
					end
					pcall(v477)
					v_u_21 = v_u_474
				end
				v_u_101.Image = string.format("rbxthumb://type=Avatar&id=%d&w=720&h=720", v_u_31.UserId)
				v_u_134.Image = string.format("rbxthumb://type=AvatarHeadShot&id=%d&w=150&h=150", v_u_31.UserId)
				v_u_263()
				local v478 = v_u_268.SetEmblem
				local v479 = v_u_270
				local v480 = v_u_268.Ranks.RankOf
				local v481 = p_u_22.State.Get
				v478(v479, v480(tonumber(v481("Trophies")) or 0))
				v_u_343()
				v_u_274 = os.clock()
				v_u_276 = 0
				v_u_277 = 0
				v_u_278 = 0
				v_u_279 = 0
				v_u_280 = 0
				v_u_281 = 0
				v_u_282 = 0
				v_u_283 = 0
				v_u_309 = -1
				v_u_310 = -1
				if not v_u_298 then
					v_u_286 = false
				end
				v_u_292 = false
				v_u_287 = nil
				v_u_293 = 0
				v_u_294 = 0
				v_u_300 = true
				local v482 = v_u_43
				local v483 = v_u_44
				local v484 = v_u_45
				v_u_42.Enabled = true
				v482.Enabled = false
				v483.Enabled = true
				v484.Enabled = true
				v_u_33.Parent = v_u_7.CurrentCamera
				v_u_264.Visible = true
				v_u_265.Visible = true
				v_u_23.Enter(v_u_266, Vector2.new(0, -10), 0.25)
				v_u_23.Enter(v_u_267.Instance, Vector2.new(0, 14), 0.35)
				v_u_473(true)
				if not v_u_273 then
					v_u_273 = true
					v_u_3:BindToRenderStep("TR_PlayerCard", Enum.RenderPriority.Camera.Value + 10, v_u_426)
				end
				v_u_426(0)
				p_u_22.Sounds.Play("Card_Whoosh")
			end
		end,
		["close"] = function(p485) -- name: close
			-- upvalues: (ref) v_u_271, (copy) p_u_22, (ref) v_u_21, (ref) v_u_5, (ref) v_u_4, (copy) v_u_264, (copy) v_u_265, (ref) v_u_465, (ref) v_u_295, (ref) v_u_296, (ref) v_u_297, (ref) v_u_272, (ref) v_u_275, (ref) v_u_299, (copy) v_u_426
			if v_u_271 then
				v_u_271 = false
				p_u_22.SetHudHidden("PlayerCard", false)
				if p_u_22.TopbarSettings and p_u_22.TopbarSettings.SetHidden then
					p_u_22.TopbarSettings.SetHidden("PlayerCard", false)
				end
				local v_u_486 = v_u_21
				if v_u_486 then
					v_u_21 = nil
					local function v489()
						-- upvalues: (ref) v_u_5, (copy) v_u_486, (ref) v_u_4
						local v487 = v_u_5:FindFirstChildOfClass("ChatWindowConfiguration")
						local v488 = v_u_5:FindFirstChildOfClass("ChatInputBarConfiguration")
						if v487 and v_u_486.window ~= nil then
							v487.Enabled = v_u_486.window
						end
						if v488 and v_u_486.bar ~= nil then
							v488.Enabled = v_u_486.bar
						end
						if v_u_486.core ~= nil then
							v_u_4:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, v_u_486.core)
						end
					end
					pcall(v489)
				end
				v_u_264.Visible = false
				v_u_265.Visible = false
				if v_u_465 then
					v_u_465:Disconnect()
					v_u_465 = nil
				end
				v_u_295 = 0
				v_u_296 = 0
				v_u_297 = nil
				if p485 then
					v_u_272 = true
					v_u_275 = os.clock() - v_u_299 * 0.24
					v_u_426(0)
				else
					v_u_272 = true
					v_u_275 = os.clock()
				end
			else
				return
			end
		end
	}
	p_u_22.MenuManager.Register("PlayerCard", v490)
	v_u_25.PlayerStateChanged:Connect(function(p491)
		-- upvalues: (copy) p_u_22
		if p491 == "Match" and p_u_22.MenuManager.IsOpen("PlayerCard") then
			p_u_22.MenuManager.Close("PlayerCard", true)
		end
	end)
	v_u_25.ProfileChanged:Connect(function()
		-- upvalues: (ref) v_u_271, (copy) v_u_263
		if v_u_271 then
			v_u_263()
		end
	end)
	v_u_25.AttrChanged:Connect(function(p492)
		-- upvalues: (ref) v_u_271, (copy) v_u_263
		if v_u_271 and (p492 == "Level" or (p492 == "XP" or p492 == "Streak")) then
			v_u_263()
		end
	end)
	v_u_23.LayoutChanged:Connect(function()
		-- upvalues: (ref) v_u_271, (copy) v_u_343
		if v_u_271 then
			v_u_343()
		end
	end)
	v_u_23.ScaleChanged:Connect(function()
		-- upvalues: (ref) v_u_271, (copy) v_u_343
		if v_u_271 then
			v_u_343()
		end
	end)
	function p_u_22.Debug.playerCard(p493, p494, p495)
		-- upvalues: (copy) p_u_22, (ref) v_u_271, (ref) v_u_272, (ref) v_u_282, (ref) v_u_280, (ref) v_u_281, (ref) v_u_7, (ref) v_u_1, (ref) v_u_298, (ref) v_u_286, (ref) v_u_284, (ref) v_u_285, (ref) v_u_302, (ref) v_u_299, (ref) v_u_174, (copy) v_u_263, (copy) v_u_356, (ref) v_u_273, (ref) v_u_300, (ref) v_u_276, (ref) v_u_277, (ref) v_u_175, (copy) v_u_42, (ref) v_u_21, (ref) v_u_292, (ref) v_u_291, (copy) v_u_123, (copy) v_u_143
		if p493 == "open" then
			p_u_22.MenuManager.Open("PlayerCard")
		elseif p493 == "close" then
			p_u_22.MenuManager.Close("PlayerCard")
		elseif p493 == "flip" then
			if v_u_271 and not v_u_272 then
				if v_u_282 >= 6.283185307179586 then
					v_u_282 = v_u_282 - 6.283185307179586
					v_u_280 = v_u_280 - 6.283185307179586
				end
				v_u_282 = v_u_282 + 3.141592653589793
				v_u_281 = v_u_281 + 1.5
				p_u_22.Sounds.Play("Card_Flip")
			end
		elseif p493 == "tilt" then
			if type(p494) == "number" and type(p495) == "number" then
				local v496 = v_u_7.CurrentCamera.ViewportSize
				local v497 = v_u_1:GetGuiInset()
				v_u_298 = true
				v_u_286 = true
				v_u_284 = v496.X / 2 + p494 * v496.X * 0.4
				v_u_285 = v496.Y * (0.5 - v_u_302) - v497.Y + p495 * v496.Y * 0.4
			else
				v_u_298 = false
				v_u_286 = false
			end
		elseif p493 == "pace" then
			v_u_299 = (type(p494) ~= "number" or p494 <= 0) and 1 or p494
		elseif p493 == "level" then
			if type(p494) ~= "number" then
				p494 = nil
			end
			v_u_174 = p494
			if v_u_271 then
				v_u_263()
			end
		end
		local v498, v499, v500, v501
		if v_u_271 then
			v498, v499, v500, v501 = v_u_356()
		else
			v498 = 0
			v499 = 0
			v500 = 0
			v501 = 0
		end
		local v502 = {
			["open"] = v_u_271,
			["closing"] = v_u_272,
			["bound"] = v_u_273
		}
		local v503 = v_u_282 / 3.141592653589793 + 0.5
		v502.flipped = math.floor(v503) % 2 == 1
		v502.front = v_u_300
		local v504 = v_u_276
		local v505 = math.deg(v504) * 10
		v502.yaw = math.floor(v505) / 10
		local v506 = v_u_277
		local v507 = math.deg(v506) * 10
		v502.pitch = math.floor(v507) / 10
		local v508 = v_u_280
		local v509 = math.deg(v508)
		v502.flip = math.floor(v509)
		v502.tier = v_u_175.name
		local v510 = v_u_42.CanvasSize
		v502.canvas = tostring(v510)
		v502.rect = string.format("%d,%d %d,%d", v498, v499, v500, v501)
		v502.hudHidden = p_u_22.HudHidden
		v502.chatHidden = v_u_21 ~= nil
		local v511 = v_u_286
		local v512 = v_u_292
		v502.pointer = string.format("%s %s %d,%d moved %d", tostring(v511), tostring(v512), v_u_284, v_u_285, v_u_291)
		v502.stats = {
			["wins"] = v_u_123[1].value.Text,
			["winRate"] = v_u_123[2].value.Text,
			["kd"] = v_u_123[3].value.Text,
			["items"] = v_u_143.items.Text,
			["drops"] = v_u_143.drops.Text
		}
		return v502
	end
end
return v8