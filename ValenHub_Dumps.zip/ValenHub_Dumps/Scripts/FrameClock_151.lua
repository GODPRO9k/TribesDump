local v_u_1 = {}
v_u_1.__index = v_u_1
function v_u_1.new() -- name: new
	-- upvalues: (copy) v_u_1
	local v2 = {
		["sim"] = 0,
		["mins"] = nil,
		["bucket"] = -1,
		["dtAvg"] = nil,
		["lastNow"] = nil,
		["mins"] = table.create(10, (1 / 0))
	}
	local v3 = v_u_1
	return setmetatable(v2, v3)
end
function v_u_1.Step(p4) -- name: Step
	p4.sim = p4.sim + 0.016666666666666666
end
function v_u_1.Reset(p5) -- name: Reset
	p5.mins[1] = (1 / 0)
	p5.mins[2] = (1 / 0)
	p5.mins[3] = (1 / 0)
	p5.mins[4] = (1 / 0)
	p5.mins[5] = (1 / 0)
	p5.mins[6] = (1 / 0)
	p5.mins[7] = (1 / 0)
	p5.mins[8] = (1 / 0)
	p5.mins[9] = (1 / 0)
	p5.mins[10] = (1 / 0)
	p5.bucket = -1
	p5.lastNow = nil
	p5.dtAvg = nil
end
function v_u_1.Alpha(p6, p7, p8) -- name: Alpha
	local v9 = p6.lastNow
	if v9 then
		local v10 = p7 - v9
		if v10 > 0.25 or v10 < 0 then
			p6:Reset()
		else
			local v11 = p6.dtAvg
			if v11 then
				v10 = v11 + (v10 - v11) * 0.1
			end
			p6.dtAvg = v10
		end
	end
	p6.lastNow = p7
	local v12 = p6.sim - p7
	local v13 = p7 / 0.1
	local v14 = math.floor(v13)
	if v14 ~= p6.bucket then
		local v15
		if p6.bucket < 0 then
			v15 = 10
		else
			local v16 = v14 - p6.bucket
			v15 = math.min(v16, 10)
		end
		for v17 = 1, v15 do
			p6.mins[(v14 - v15 + v17) % 10 + 1] = (1 / 0)
		end
		p6.bucket = v14
	end
	local v18 = v14 % 10 + 1
	if v12 < p6.mins[v18] then
		p6.mins[v18] = v12
	end
	local v19 = (1 / 0)
	for v20 = 1, 10 do
		if p6.mins[v20] >= v19 then
			continue
		end
		v19 = p6.mins[v20]
	end
	if v12 - v19 > 0.016666666666666666 then
		v19 = v12 - 0.016666666666666666
		for v21 = 1, 10 do
			if p6.mins[v21] >= v19 then
				continue
			end
			p6.mins[v21] = v19
		end
	end
	local v22 = p6.dtAvg
	if not p8 and (v22 == nil or v22 > 0.05) then
		return 1
	end
	local v23 = 1 - (v12 - v19) / 0.016666666666666666
	return math.clamp(v23, 0, 1)
end
return v_u_1