local v1 = {}
local v_u_2 = {
	["info"] = "Notify",
	["success"] = "Select",
	["warning"] = "Notify",
	["error"] = "Error"
}
function v1.Init(p_u_3) -- name: Init
	-- upvalues: (copy) v_u_2
	local v_u_4 = p_u_3.UI
	local v5 = p_u_3.Theme
	local v6 = p_u_3.State
	local v_u_7 = v5.Colors
	local v_u_8 = v5.Fonts
	local v_u_9 = {
		["info"] = v_u_7.Accent,
		["success"] = v_u_7.Success,
		["warning"] = v_u_7.Warning,
		["error"] = v_u_7.Danger
	}
	local v_u_10 = v_u_4.new("Frame", {
		["Name"] = "Toasts",
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 120),
		["Size"] = UDim2.fromOffset(640, 200),
		v_u_4.List(Enum.FillDirection.Vertical, 6, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Top),
		["Parent"] = p_u_3.Canvas.Overlay
	})
	local v_u_11 = false
	local v_u_12 = {}
	local function v_u_14(p13) -- name: shown
		while p13 and not p13:IsA("PlayerGui") do
			if p13:IsA("GuiObject") and not p13.Visible then
				return false
			end
			if p13:IsA("ScreenGui") and not p13.Enabled then
				return false
			end
			p13 = p13.Parent
		end
		return p13 ~= nil
	end
	local function v_u_22() -- name: place
		-- upvalues: (copy) v_u_4, (ref) v_u_11, (copy) v_u_10, (copy) v_u_12, (copy) v_u_14
		local v15 = v_u_4.TopInset() + 4
		if not v_u_11 then
			local v16 = v_u_10.Parent.AbsolutePosition.Y
			local v17 = v_u_4.Scale
			local v18 = math.max(v17, 0.01)
			for _, v19 in v_u_12 do
				if not v19.Parent or (not v_u_14(v19) or v19.AbsoluteSize.Y <= 0) then
					continue
				end
				local v20 = (v19.AbsolutePosition.Y + v19.AbsoluteSize.Y - v16) / v18
				local v21 = math.ceil(v20) + 8
				v15 = math.max(v15, v21)
			end
		end
		v_u_10.Position = UDim2.new(0.5, 0, 0, v15)
	end
	p_u_3.MenuManager.Changed:Connect(function(p23)
		-- upvalues: (ref) v_u_11, (copy) v_u_22
		v_u_11 = p23 ~= nil
		v_u_22()
	end)
	function p_u_3.ToastAvoid(p24, p25) -- name: ToastAvoid
		-- upvalues: (copy) v_u_12, (copy) v_u_22
		v_u_12[p24] = p25
		v_u_22()
	end
	v_u_4.LayoutChanged:Connect(v_u_22)
	v_u_4.TopInsetChanged:Connect(v_u_22)
	v_u_22()
	local v_u_26 = {}
	local v_u_27 = {}
	local v_u_28 = 0
	local function v_u_33() -- name: newRow
		-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_8
		local v29 = v_u_4.new("Frame", {
			["Name"] = "Toast",
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = UDim2.fromOffset(0, 44),
			["AutomaticSize"] = Enum.AutomaticSize.X
		})
		local v30 = v_u_4.new("Frame", {
			["Name"] = "Inner",
			["Size"] = UDim2.fromOffset(0, 44),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["BackgroundColor3"] = v_u_7.Panel,
			["BackgroundTransparency"] = 0.12,
			v_u_4.Corner(10),
			v_u_4.Stroke(v_u_7.Stroke, 1.5, 0.7),
			v_u_4.Padding(0, 18, 0, 22),
			["Parent"] = v29
		})
		local v31 = v_u_4.new("Frame", {
			["Name"] = "Accent",
			["Position"] = UDim2.fromOffset(-14, 8),
			["Size"] = UDim2.new(0, 5, 1, -16),
			["BackgroundColor3"] = v_u_7.Accent,
			v_u_4.Corner(3),
			["Parent"] = v30
		})
		local v32 = v_u_4.new("TextLabel", {
			["Name"] = "Text",
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 20,
			["TextColor3"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(0, 1),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["FontFace"] = v_u_8.Heavy,
			["TextColor3"] = v_u_7.Text,
			["Parent"] = v30
		})
		v_u_4.new("UISizeConstraint", {
			["MaxSize"] = Vector2.new(620, 44),
			["Parent"] = v30
		})
		v32.TextTruncate = Enum.TextTruncate.AtEnd
		return {
			["holder"] = nil,
			["inner"] = nil,
			["bar"] = nil,
			["label"] = nil,
			["text"] = "",
			["count"] = 1,
			["expire"] = 0,
			["token"] = 0,
			["holder"] = v29,
			["inner"] = v30,
			["bar"] = v31,
			["label"] = v32
		}
	end
	local function v_u_39(p_u_34) -- name: dismiss
		-- upvalues: (copy) v_u_4, (copy) v_u_26, (copy) v_u_27
		p_u_34.token = p_u_34.token + 1
		local v_u_35 = p_u_34.token
		v_u_4.FadeOut(p_u_34.inner, TweenInfo.new(0.2))
		task.delay(0.22, function()
			-- upvalues: (copy) p_u_34, (copy) v_u_35, (ref) v_u_26, (ref) v_u_27
			if p_u_34.token == v_u_35 then
				local v36 = p_u_34
				local v37 = table.find(v_u_26, v36)
				if v37 then
					table.remove(v_u_26, v37)
				end
				v36.holder.Parent = nil
				local v38 = v_u_27
				table.insert(v38, v36)
			end
		end)
	end
	local v_u_40 = (-1 / 0)
	local function v49(p41, p42, p43) -- name: toast
		-- upvalues: (copy) v_u_9, (copy) v_u_22, (copy) v_u_26, (copy) v_u_4, (copy) v_u_39, (copy) v_u_27, (copy) v_u_33, (ref) v_u_28, (copy) v_u_10, (ref) v_u_40, (copy) p_u_3, (ref) v_u_2
		if type(p41) == "string" and p41 ~= "" then
			local v44 = not (p42 and v_u_9[p42]) and "info" or p42
			v_u_22()
			for _, v45 in v_u_26 do
				if v45.text ~= p41 then
					continue
				end
				v45.count = v45.count + 1
				v45.label.Text = p41 .. "  \195\151" .. v45.count
				v45.expire = os.clock() + 3.5
				v_u_4.Bump(v45.label, 0.08)
				return
			end
			if #v_u_26 >= 3 then
				v_u_39(v_u_26[1])
				table.remove(v_u_26, 1)
			end
			local v_u_46 = table.remove(v_u_27) or v_u_33()
			v_u_46.token = v_u_46.token + 1
			local v_u_47 = v_u_46.token
			v_u_28 = v_u_28 + 1
			v_u_46.text = p41
			v_u_46.count = 1
			v_u_46.expire = os.clock() + (v44 == "error" and 3 or 3.5)
			v_u_46.label.Text = p41
			v_u_46.bar.BackgroundColor3 = v_u_9[v44]
			v_u_46.holder.LayoutOrder = v_u_28
			v_u_46.holder.Parent = v_u_10
			local v48 = v_u_26
			table.insert(v48, v_u_46)
			v_u_4.Enter(v_u_46.inner, Vector2.new(0, -12), 0, UDim2.new())
			if p43 ~= true and os.clock() - v_u_40 >= 1 then
				v_u_40 = os.clock()
				p_u_3.Sounds.Play(v_u_2[v44])
			end
			task.spawn(function()
				-- upvalues: (copy) v_u_46, (copy) v_u_47, (ref) v_u_39
				while v_u_46.token == v_u_47 and os.clock() < v_u_46.expire do
					task.wait(0.25)
				end
				if v_u_46.token == v_u_47 then
					v_u_39(v_u_46)
				end
			end)
		end
	end
	p_u_3.Toast = v49
	v6.Notify:Connect(v49)
end
return v1