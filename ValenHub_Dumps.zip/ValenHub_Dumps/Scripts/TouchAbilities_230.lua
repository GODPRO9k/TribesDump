local v_u_1 = game:GetService("Players")
local v2 = require(script.Parent.Parent:WaitForChild("CommonUtils"))
local v_u_3 = require(script.Parent:WaitForChild("AvatarAbilitiesInterface")).get(v_u_1.LocalPlayer)
local v_u_4 = require(script.Parent:WaitForChild("InputSlots"))
local v5 = v2.get("FlagUtil")
local v_u_6 = v5.getUserFlag("UserAbilitiesUserInterfaceA")
local v_u_7 = v5.getUserFlag("UserAbilitiesUserInterfaceC")
local v_u_8 = {
	{
		["small"] = { 72, 60, 60 },
		["large"] = { 92, 112, 112 }
	},
	{
		["small"] = { 44, 132, 132 },
		["large"] = { 56, 200, 200 }
	},
	{
		["small"] = { 44, 132, 16 },
		["large"] = { 56, 200, 60 }
	},
	{
		["small"] = { 44, 16, 132 },
		["large"] = { 56, 60, 200 }
	},
	{
		["small"] = { 44, 156, 74 },
		["large"] = { 56, 228, 130 }
	},
	{
		["small"] = { 44, 74, 156 },
		["large"] = { 56, 130, 228 }
	},
	{
		["small"] = { 44, 16, 16 },
		["large"] = { 56, 60, 60 }
	}
}
local v_u_9 = { 28, 44 }
local v_u_10 = { 36, 56 }
local v_u_11 = { 16, 12 }
local v_u_12 = { 16, 12 }
local v_u_13 = {}
v_u_13.__index = v_u_13
function v_u_13.new(p14) -- name: new
	-- upvalues: (copy) v_u_13
	local v15 = v_u_13
	local v16 = setmetatable({}, v15)
	v16.parentUIFrame = p14
	v16.managedButtons = {}
	v16.created = false
	v16.enabled = false
	v16.enabledChangedEvent = Instance.new("BindableEvent")
	return v16
end
function v_u_13.Enable(p17, p18) -- name: Enable
	if p17.enabled ~= p18 then
		p17.enabled = p18
		if p18 and not p17.created then
			p17:Create()
			p17.created = true
		end
		p17.enabledChangedEvent:Fire()
	end
end
function v_u_13.CreateAbilityButton(p_u_19, p_u_20, p21, p_u_22, p_u_23, p_u_24) -- name: CreateAbilityButton
	-- upvalues: (copy) v_u_3
	local v_u_25 = false
	local v_u_26 = not p21.ButtonAssetId and "rbxassetid://136780077406114" or p21.ButtonAssetId
	local v_u_27 = not p21.ButtonPressedAssetId and "rbxassetid://76895455502876" or p21.ButtonPressedAssetId
	local v_u_28
	if p21.ButtonInvalidAssetId then
		v_u_28 = p21.ButtonInvalidAssetId
	else
		v_u_28 = nil
	end
	local v_u_29 = Instance.new("ImageButton")
	v_u_29.Name = p_u_20 .. "Button"
	v_u_29.Visible = false
	v_u_29.BackgroundTransparency = 1
	v_u_29.Image = v_u_26
	v_u_29.Parent = p_u_19.parentUIFrame
	for _, v30 in p_u_22:GetChildren() do
		if not (string.find(v30.Name, "Touch") and v30:IsA("InputBinding")) then
			continue
		end
		v30.UIButton = v_u_29
	end
	local function v39() -- name: ResizeButton
		-- upvalues: (copy) p_u_19, (copy) p_u_23, (copy) v_u_29, (copy) p_u_24
		local v31 = p_u_19.parentUIFrame.AbsoluteSize.x
		local v32 = p_u_19.parentUIFrame.AbsoluteSize.y
		local v33 = math.min(v31, v32) <= 500 and p_u_23.small or p_u_23.large
		local v34 = v33[1]
		local v35 = v33[2]
		local v36 = v33[3]
		local v37 = -v35 - v34
		v_u_29.Size = UDim2.new(0, v34, 0, v34)
		if p_u_24 then
			v_u_29.Position = UDim2.new(1, v37, 0, v36)
		else
			local v38 = -v36 - v34
			v_u_29.Position = UDim2.new(1, v37, 1, v38)
		end
	end
	v39()
	local v_u_40 = {}
	local v41 = p_u_19.parentUIFrame:GetPropertyChangedSignal("AbsoluteSize")
	table.insert(v_u_40, v41:Connect(v39))
	local function v_u_46() -- name: UpdateButtonState
		-- upvalues: (ref) v_u_3, (copy) p_u_20, (copy) v_u_29, (copy) p_u_19, (copy) p_u_22, (ref) v_u_25, (ref) v_u_27, (ref) v_u_26, (ref) v_u_28
		local v42 = v_u_3:GetAbilityValid(p_u_20)
		local v43 = v_u_3:GetAbilityActive(p_u_20)
		local v44 = v_u_29
		local v45 = p_u_19.enabled
		if v45 then
			v45 = p_u_22.Enabled
		end
		v44.Visible = v45
		if v_u_29.Visible then
			if v43 or v_u_25 and v42 then
				v_u_29.Image = v_u_27
				v_u_29.ImageTransparency = 0
				return
			end
			if v42 then
				v_u_29.Image = v_u_26
				v_u_29.ImageTransparency = 0
				return
			end
			if v_u_28 then
				v_u_29.Image = v_u_28
				v_u_29.ImageTransparency = 0
				return
			end
			v_u_29.Image = v_u_26
			v_u_29.ImageTransparency = 0.6
		end
	end
	v_u_46()
	v_u_29.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_25, (copy) v_u_46
		v_u_25 = true
		v_u_46()
	end)
	v_u_29.MouseButton1Up:Connect(function()
		-- upvalues: (ref) v_u_25, (copy) v_u_46
		v_u_25 = false
		v_u_46()
	end)
	v_u_29.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_25, (copy) v_u_46
		v_u_25 = false
		v_u_46()
	end)
	local v47 = v_u_3:GetAbilityActiveChangedSignal(p_u_20)
	table.insert(v_u_40, v47:Connect(v_u_46))
	local v48 = v_u_3:GetAbilityValidChangedSignal(p_u_20)
	table.insert(v_u_40, v48:Connect(v_u_46))
	local v49 = p_u_19.enabledChangedEvent.Event
	table.insert(v_u_40, v49:Connect(v_u_46))
	local v50 = p_u_22:GetPropertyChangedSignal("Enabled")
	table.insert(v_u_40, v50:Connect(v_u_46))
	v_u_29.Destroying:Connect(function()
		-- upvalues: (copy) v_u_40
		for _, v51 in v_u_40 do
			v51:Disconnect()
		end
		table.clear(v_u_40)
	end)
	return v_u_29
end
function v_u_13.CreateOverflowScrollButton(p_u_52, p_u_53) -- name: CreateOverflowScrollButton
	-- upvalues: (copy) v_u_1, (copy) v_u_9, (copy) v_u_10, (copy) v_u_11, (copy) v_u_12, (copy) v_u_4
	local v_u_54 = Instance.new("ImageButton")
	v_u_54.Name = "ScrollButton"
	v_u_54.BackgroundTransparency = 1
	v_u_54.Image = "rbxassetid://120193229129639"
	v_u_54.PressedImage = "rbxassetid://122643389561468"
	v_u_54.Parent = p_u_52.parentUIFrame
	local function v65() -- name: ResizeButton
		-- upvalues: (copy) p_u_52, (ref) v_u_1, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (copy) v_u_54, (copy) p_u_53
		local v55 = p_u_52.parentUIFrame.AbsoluteSize.x
		local v56 = p_u_52.parentUIFrame.AbsoluteSize.y
		local v57 = math.min(v55, v56)
		local v58 = v_u_1.LocalPlayer:FindFirstChildOfClass("PlayerGui")
		local v59
		if v58 then
			v59 = v58.CurrentScreenOrientation == Enum.ScreenOrientation.Portrait
		else
			v59 = false
		end
		local v60 = v57 <= 500
		local v61 = v60 and v_u_9 or v_u_10
		local v62 = v60 and v_u_11 or v_u_12
		local v63 = v60 and 8 or 10
		local v64 = v60 and 44 or 56
		v_u_54.Size = UDim2.new(0, v61[1], 0, v61[2])
		if p_u_53 then
			if v59 then
				v_u_54.Position = UDim2.new(1, -v62[1] - v61[2] + 0.5 * (v61[2] - v61[1]), 0, v62[2] + v61[1] + 4 * v63 + 3 * v64 - 0.5 * (v61[2] - v61[1]))
				v_u_54.Rotation = 270
			else
				v_u_54.Position = UDim2.new(1, -v62[1] - 2 * v61[1] - 4 * v63 - 3 * v64, 0, v62[2])
				v_u_54.Rotation = 0
			end
		else
			v_u_54.Position = UDim2.new(1, -v62[1] - v61[1], 0, v62[2])
			if v59 then
				v_u_54.Position = UDim2.new(1, -v62[1] - v61[2] + 0.5 * (v61[2] - v61[1]), 0, v62[2] - 0.5 * (v61[2] - v61[1]))
				v_u_54.Rotation = 90
			else
				v_u_54.Position = UDim2.new(1, -v62[1] - v61[1], 0, v62[2])
				v_u_54.Rotation = 180
			end
		end
	end
	v65()
	local v_u_66 = {}
	local v67 = p_u_52.parentUIFrame:GetPropertyChangedSignal("AbsoluteSize")
	table.insert(v_u_66, v67:Connect(v65))
	v_u_54.Activated:Connect(function()
		-- upvalues: (copy) p_u_53, (ref) v_u_4
		if p_u_53 then
			v_u_4.setOverflowScrollIndex(v_u_4.getOverflowScrollIndex() + 1)
		else
			v_u_4.setOverflowScrollIndex(v_u_4.getOverflowScrollIndex() - 1)
		end
	end)
	v_u_54.Destroying:Connect(function()
		-- upvalues: (copy) v_u_66
		for _, v68 in v_u_66 do
			v68:Disconnect()
		end
		table.clear(v_u_66)
	end)
	return v_u_54
end
function v_u_13.Create(p_u_69) -- name: Create
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_6, (copy) v_u_7, (copy) v_u_9, (copy) v_u_10, (copy) v_u_1, (copy) v_u_11, (copy) v_u_12
	if p_u_69.parentUIFrame then
		local function v97() -- name: CreateButtons
			-- upvalues: (copy) p_u_69, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) v_u_7, (ref) v_u_9, (ref) v_u_10, (ref) v_u_1, (ref) v_u_11, (ref) v_u_12
			for _, v70 in p_u_69.managedButtons do
				v70:Destroy()
			end
			p_u_69.managedButtons = {}
			if v_u_3:isEnabled() then
				local v71 = v_u_4.GetSlotMap()
				for v72, v73 in pairs(v71) do
					local v74 = v_u_4.GetActionInSlot(v72)
					if not v73 or (not v74 or (v72 > #v_u_8 or not v_u_6 and v72 ~= 1)) then
						continue
					end
					local v75 = v_u_3:GetAbilityConfig(v73)
					local v76 = p_u_69.managedButtons
					local v77 = p_u_69
					local v78 = v_u_8[v72]
					table.insert(v76, v77:CreateAbilityButton(v73, v75, v74, v78, false))
				end
				if v_u_6 and v_u_7 then
					local v79 = v_u_4.GetAbilitiesInOverflow()
					local v80, v81
					if #v79 > v_u_4.GetNumOverflowSlots() then
						if v_u_4.getOverflowScrollIndex() > 0 then
							local v82 = p_u_69.managedButtons
							local v83 = p_u_69
							table.insert(v82, v83:CreateOverflowScrollButton(false))
						end
						if v_u_4.getOverflowScrollIndex() < #v79 - v_u_4.GetNumOverflowSlots() then
							local v84 = p_u_69.managedButtons
							local v85 = p_u_69
							table.insert(v84, v85:CreateOverflowScrollButton(true))
						end
						v80 = v_u_9[1] + 8
						v81 = v_u_10[1] + 10
					else
						v80 = 0
						v81 = 0
					end
					local v86 = #v79
					local v87 = v_u_4.GetNumOverflowSlots
					for v88 = 1, math.min(v86, v87()) do
						local v89 = v79[v88 + v_u_4.getOverflowScrollIndex()]
						local v90 = v_u_4.GetOverflowAction(v88)
						if not (v89 and v90) then
							continue
						end
						local v91 = v_u_3:GetAbilityConfig(v89)
						local v92 = v_u_1.LocalPlayer:FindFirstChildOfClass("PlayerGui")
						local v93
						if v92 then
							v93 = v92.CurrentScreenOrientation == Enum.ScreenOrientation.Portrait
						else
							v93 = false
						end
						local v94
						if v93 then
							v94 = {
								["small"] = { 44, v_u_11[1], v_u_11[2] + v80 + (v88 - 1) * 52 },
								["large"] = { 56, v_u_12[1], v_u_12[2] + v81 + (v88 - 1) * 66 }
							}
						else
							v94 = {
								["small"] = { 44, v_u_11[1] + v80 + (v88 - 1) * 52, v_u_11[2] },
								["large"] = { 56, v_u_12[1] + v81 + (v88 - 1) * 66, v_u_12[2] }
							}
						end
						local v95 = p_u_69.managedButtons
						local v96 = p_u_69
						table.insert(v95, v96:CreateAbilityButton(v89, v91, v90, v94, true))
					end
				end
			end
		end
		v97()
		v_u_4.GetSlotMapChangedSignal():Connect(v97)
		v_u_3:GetEnabledChangedSignal():Connect(v97)
		v_u_4.getScrollIndexChangedEvent():Connect(v97)
		local v98 = v_u_1.LocalPlayer:WaitForChild("PlayerGui", 5)
		if v98 then
			v98:GetPropertyChangedSignal("CurrentScreenOrientation"):Connect(v97)
		end
	end
end
return v_u_13