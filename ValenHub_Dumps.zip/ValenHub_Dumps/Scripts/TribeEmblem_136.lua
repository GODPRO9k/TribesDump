local v1 = game:GetService("ReplicatedStorage"):WaitForChild("Shared")
local v_u_2 = require(v1:WaitForChild("Tribes"))
local v_u_3 = require(v1:WaitForChild("TribeArt"))
local v4 = {}
local v_u_5 = nil
local v_u_6 = nil
function v4.Init(p7) -- name: Init
	-- upvalues: (ref) v_u_5, (ref) v_u_6
	v_u_5 = p7
	v_u_6 = p7.Theme
end
function v4.Tag(p8) -- name: Tag
	return (type(p8) ~= "string" or p8 == "") and "" or "[" .. p8 .. "]"
end
function v4.TagColor(p9) -- name: TagColor
	-- upvalues: (copy) v_u_2
	return v_u_2.TextColor(p9)
end
function v4.new(p10, p11) -- name: new
	-- upvalues: (ref) v_u_5, (copy) v_u_3, (ref) v_u_6, (copy) v_u_2
	local v12 = p11 or {}
	local v13 = p10 * 1.08 + 0.5
	local v14 = math.floor(v13)
	local v15 = v_u_5.new("Frame", {
		["Name"] = v12.Name or "Emblem",
		["Size"] = UDim2.fromOffset(p10, v14),
		["Position"] = v12.Position or UDim2.new(),
		["AnchorPoint"] = v12.AnchorPoint or Vector2.zero,
		["LayoutOrder"] = v12.LayoutOrder or 0,
		["ZIndex"] = v12.ZIndex or 1,
		["Parent"] = v12.Parent
	})
	local v16 = v12.ZIndex or 1
	local v_u_17 = v_u_3.Badge ~= ""
	local v_u_18 = nil
	local v19 = p10 <= 36
	local v20 = v19 and 0.74 or 0.66
	local v21 = UDim2.fromScale(v20, v20 * p10 / v14)
	local v_u_22, v_u_23, v_u_24
	if v_u_17 then
		v_u_22 = v_u_5.new("ImageLabel", {
			["Name"] = "Badge",
			["Image"] = nil,
			["Size"] = nil,
			["ScaleType"] = nil,
			["ZIndex"] = nil,
			["Parent"] = nil,
			["Image"] = v_u_3.Badge,
			["Size"] = UDim2.fromScale(1, 1),
			["ScaleType"] = Enum.ScaleType.Fit,
			["ZIndex"] = v16,
			["Parent"] = v15
		})
		v_u_5.new("UIGradient", {
			["Rotation"] = 90,
			["Color"] = nil,
			["Parent"] = nil,
			["Color"] = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(170, 170, 170)),
			["Parent"] = v_u_22
		})
		if v_u_3.BadgeOutline ~= "" and not v19 then
			v_u_18 = v_u_5.new("ImageLabel", {
				["Name"] = "Ring",
				["Image"] = nil,
				["Size"] = nil,
				["ScaleType"] = nil,
				["ZIndex"] = nil,
				["Parent"] = nil,
				["Image"] = v_u_3.BadgeOutline,
				["Size"] = UDim2.fromScale(1, 1),
				["ScaleType"] = Enum.ScaleType.Fit,
				["ZIndex"] = v16 + 1,
				["Parent"] = v15
			})
		end
		local v25 = p10 / 36 + 0.5
		local v26 = math.floor(v25)
		local v27 = math.max(1, v26)
		v_u_23 = v_u_5.new("ImageLabel", {
			["Name"] = "GlyphShadow",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ScaleType"] = nil,
			["ImageColor3"] = nil,
			["ImageTransparency"] = 0.55,
			["ZIndex"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(0.5, 0, 0.46, v27),
			["Size"] = v21,
			["ScaleType"] = Enum.ScaleType.Fit,
			["ImageColor3"] = Color3.new(0, 0, 0),
			["ZIndex"] = v16 + 2,
			["Parent"] = v15
		})
		v_u_24 = v_u_5.new("ImageLabel", {
			["Name"] = "Glyph",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ScaleType"] = nil,
			["ZIndex"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.46),
			["Size"] = v21,
			["ScaleType"] = Enum.ScaleType.Fit,
			["ZIndex"] = v16 + 3,
			["Parent"] = v15
		})
	else
		v_u_22 = nil
		v_u_24 = nil
		v_u_23 = nil
	end
	local v_u_28 = v_u_5.new("Frame", {
		["Name"] = "Square",
		["Size"] = UDim2.fromOffset(p10, p10),
		["Position"] = UDim2.fromOffset(0, v14 - p10),
		["BackgroundColor3"] = v_u_6.Colors.Raised,
		["Visible"] = not v_u_17,
		["ZIndex"] = v16,
		v_u_5.Corner(UDim.new(0.24, 0)),
		["Parent"] = v15
	})
	local v29 = v_u_5.Stroke
	local v30 = v_u_6.Colors.Stroke
	local v31 = p10 / 18
	local v32 = math.floor(v31)
	local v_u_33 = v29(v30, math.max(1, v32), 0)
	v_u_33.Parent = v_u_28
	local v34 = v_u_5.new
	local v35 = {
		["Name"] = "Letter",
		["Size"] = nil,
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["FontFace"] = v_u_6.Fonts.Display
	}
	local v36 = p10 * 0.52
	v35.TextSize = math.floor(v36)
	v35.ZIndex = v16 + 1
	v35.Parent = v_u_28
	local v_u_37 = v34("TextLabel", v35)
	return {
		["Instance"] = v15,
		["Set"] = function(_, p38, p39, p40, p41) -- name: Set
			-- upvalues: (ref) v_u_2, (ref) v_u_3, (copy) v_u_17, (ref) v_u_22, (ref) v_u_18, (ref) v_u_24, (ref) v_u_23, (ref) v_u_28, (ref) v_u_33, (ref) v_u_37
			local v42 = v_u_2.Color(p39)
			local v43 = v_u_2.Color(p40)
			local v44 = v_u_2.ICONS[type(p38) ~= "number" and 1 or p38] or v_u_2.ICONS[1]
			local v45 = v_u_3.Glyphs[v44] or ""
			local v46 = v_u_17
			if v46 then
				v46 = v45 ~= ""
			end
			if v_u_22 then
				v_u_22.Visible = v46
				v_u_22.ImageColor3 = v42
				if v_u_18 then
					v_u_18.Visible = v46
					v_u_18.ImageColor3 = v43
				end
				v_u_24.Visible = v46
				v_u_24.Image = v45
				v_u_24.ImageColor3 = v43
				v_u_23.Visible = v46
				v_u_23.Image = v45
			end
			v_u_28.Visible = not v46
			v_u_28.BackgroundColor3 = v42
			v_u_33.Color = v43
			v_u_37.TextColor3 = v43
			local v47 = v_u_37
			local v48
			if type(p41) == "string" and p41 ~= "" then
				v48 = string.sub(p41, 1, 1)
			else
				v48 = string.upper((string.sub(v44, 1, 1)))
			end
			v47.Text = v48
		end
	}
end
return v4