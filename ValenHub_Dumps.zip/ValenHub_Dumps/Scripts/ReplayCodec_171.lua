local v_u_3 = {
	["VERSION"] = 3,
	["MAGIC"] = 1196707664,
	["REC_FRAME"] = 1,
	["REC_EVENT"] = 2,
	["RECORD_HEADER"] = 5,
	["SAMPLE_BYTES"] = 27,
	["POS_Q"] = 20,
	["ROT_Q"] = 10430.060040584269,
	["VEL_Q"] = 50,
	["HP_Q"] = 2.5,
	["F_ALIVE"] = 1,
	["F_GROUNDED"] = 2,
	["F_SLIDING"] = 4,
	["F_BLOCKING"] = 8,
	["F_AIMING"] = 16,
	["F_VIEW"] = 32,
	["F_FIRST"] = 64,
	["F_AIMCAM"] = 128,
	["V_LEFT"] = 1,
	["VIEW_FORMAT_BYTES"] = 6,
	["VIEW_HZ"] = 15,
	["INV_FORMAT"] = "<BBBBBBHHH",
	["INV_BYTES"] = 12,
	["INTRO_TIME"] = 2,
	["OUTRO_TIME"] = 0.6,
	["MAX_FIGHTERS"] = 16,
	["MAX_KEYS"] = 250,
	["T_FALSE"] = 0,
	["T_TRUE"] = 1,
	["T_U8"] = 2,
	["T_I32"] = 3,
	["T_F32"] = 4,
	["T_F64"] = 5,
	["T_STR"] = 6,
	["T_V3"] = 7,
	["T_CF"] = 8,
	["T_FIGHTER"] = 9,
	["T_PART"] = 10,
	["Writer"] = function(p1) -- name: Writer
		local v2 = math.max(64, p1 or 1024)
		return {
			["buf"] = nil,
			["pos"] = 0,
			["cap"] = nil,
			["buf"] = buffer.create(v2),
			["cap"] = v2
		}
	end
}
local function v_u_9(p4, p5) -- name: ensure
	local v6 = p4.pos + p5
	if v6 > p4.cap then
		local v7 = p4.cap * 2
		while v7 < v6 do
			v7 = v7 * 2
		end
		local v8 = buffer.create(v7)
		buffer.copy(v8, 0, p4.buf, 0, p4.pos)
		p4.buf = v8
		p4.cap = v7
	end
end
v_u_3.Ensure = v_u_9
function v_u_3.U8(p10, p11) -- name: U8
	-- upvalues: (copy) v_u_9
	v_u_9(p10, 1)
	local v12 = p10.buf
	local v13 = p10.pos
	local v14 = math.clamp(p11, 0, 255)
	buffer.writeu8(v12, v13, v14)
	p10.pos = p10.pos + 1
end
function v_u_3.U16(p15, p16) -- name: U16
	-- upvalues: (copy) v_u_9
	v_u_9(p15, 2)
	local v17 = p15.buf
	local v18 = p15.pos
	local v19 = math.clamp(p16, 0, 65535)
	buffer.writeu16(v17, v18, v19)
	p15.pos = p15.pos + 2
end
function v_u_3.I16(p20, p21) -- name: I16
	-- upvalues: (copy) v_u_9
	v_u_9(p20, 2)
	local v22 = p20.buf
	local v23 = p20.pos
	local v24 = math.clamp(p21, -32768, 32767)
	buffer.writei16(v22, v23, v24)
	p20.pos = p20.pos + 2
end
function v_u_3.U32(p25, p26) -- name: U32
	-- upvalues: (copy) v_u_9
	v_u_9(p25, 4)
	local v27 = p25.buf
	local v28 = p25.pos
	buffer.writeu32(v27, v28, p26)
	p25.pos = p25.pos + 4
end
function v_u_3.I32(p29, p30) -- name: I32
	-- upvalues: (copy) v_u_9
	v_u_9(p29, 4)
	local v31 = p29.buf
	local v32 = p29.pos
	buffer.writei32(v31, v32, p30)
	p29.pos = p29.pos + 4
end
function v_u_3.F32(p33, p34) -- name: F32
	-- upvalues: (copy) v_u_9
	v_u_9(p33, 4)
	local v35 = p33.buf
	local v36 = p33.pos
	buffer.writef32(v35, v36, p34)
	p33.pos = p33.pos + 4
end
function v_u_3.F64(p37, p38) -- name: F64
	-- upvalues: (copy) v_u_9
	v_u_9(p37, 8)
	local v39 = p37.buf
	local v40 = p37.pos
	buffer.writef64(v39, v40, p38)
	p37.pos = p37.pos + 8
end
function v_u_3.Str(p41, p42) -- name: Str
	-- upvalues: (copy) v_u_9
	local v43 = #p42
	local v44 = math.min(v43, 255)
	v_u_9(p41, v44 + 1)
	local v45 = p41.buf
	local v46 = p41.pos
	buffer.writeu8(v45, v46, v44)
	buffer.writestring(p41.buf, p41.pos + 1, p42, v44)
	p41.pos = p41.pos + (v44 + 1)
end
function v_u_3.V3(p47, p48) -- name: V3
	-- upvalues: (copy) v_u_9
	v_u_9(p47, 12)
	local v49 = p47.buf
	local v50 = p47.pos
	local v51 = p48.X
	buffer.writef32(v49, v50, v51)
	local v52 = p47.buf
	local v53 = p47.pos + 4
	local v54 = p48.Y
	buffer.writef32(v52, v53, v54)
	local v55 = p47.buf
	local v56 = p47.pos + 8
	local v57 = p48.Z
	buffer.writef32(v55, v56, v57)
	p47.pos = p47.pos + 12
end
function v_u_3.Bytes(p58, p59, p60, p61) -- name: Bytes
	-- upvalues: (copy) v_u_9
	v_u_9(p58, p61)
	buffer.copy(p58.buf, p58.pos, p59, p60, p61)
	p58.pos = p58.pos + p61
end
function v_u_3.Finish(p62) -- name: Finish
	local v63 = buffer.create(p62.pos)
	buffer.copy(v63, 0, p62.buf, 0, p62.pos)
	return v63
end
function v_u_3.Q16(p64, p65) -- name: q16
	local v66 = p64 * p65 + 0.5
	local v67 = math.floor(v66)
	return v67 ~= v67 and 0 or math.clamp(v67, -32767, 32767)
end
function v_u_3.WriteSample(p68, p69, p70, p71, p72, p73, p74, p75, p76, p77, p78) -- name: WriteSample
	-- upvalues: (copy) v_u_9, (copy) v_u_3
	v_u_9(p68, 27)
	local v79 = p68.buf
	local v80 = p68.pos
	local v81, v82, v83 = p70:ToEulerAnglesYXZ()
	local v84 = p69.X * v_u_3.POS_Q + 0.5
	local v85 = math.floor(v84)
	local v86 = v85 ~= v85 and 0 or math.clamp(v85, -32767, 32767)
	buffer.writei16(v79, v80, v86)
	local v87 = v80 + 2
	local v88 = p69.Y * v_u_3.POS_Q + 0.5
	local v89 = math.floor(v88)
	local v90 = v89 ~= v89 and 0 or math.clamp(v89, -32767, 32767)
	buffer.writei16(v79, v87, v90)
	local v91 = v80 + 4
	local v92 = p69.Z * v_u_3.POS_Q + 0.5
	local v93 = math.floor(v92)
	local v94 = v93 ~= v93 and 0 or math.clamp(v93, -32767, 32767)
	buffer.writei16(v79, v91, v94)
	local v95 = v80 + 6
	local v96 = v81 * v_u_3.ROT_Q + 0.5
	local v97 = math.floor(v96)
	local v98 = v97 ~= v97 and 0 or math.clamp(v97, -32767, 32767)
	buffer.writei16(v79, v95, v98)
	local v99 = v80 + 8
	local v100 = v82 * v_u_3.ROT_Q + 0.5
	local v101 = math.floor(v100)
	local v102 = v101 ~= v101 and 0 or math.clamp(v101, -32767, 32767)
	buffer.writei16(v79, v99, v102)
	local v103 = v80 + 10
	local v104 = v83 * v_u_3.ROT_Q + 0.5
	local v105 = math.floor(v104)
	local v106 = v105 ~= v105 and 0 or math.clamp(v105, -32767, 32767)
	buffer.writei16(v79, v103, v106)
	local v107 = v80 + 12
	local v108 = p71.X * v_u_3.VEL_Q + 0.5
	local v109 = math.floor(v108)
	local v110 = v109 ~= v109 and 0 or math.clamp(v109, -32767, 32767)
	buffer.writei16(v79, v107, v110)
	local v111 = v80 + 14
	local v112 = p71.Y * v_u_3.VEL_Q + 0.5
	local v113 = math.floor(v112)
	local v114 = v113 ~= v113 and 0 or math.clamp(v113, -32767, 32767)
	buffer.writei16(v79, v111, v114)
	local v115 = v80 + 16
	local v116 = p71.Z * v_u_3.VEL_Q + 0.5
	local v117 = math.floor(v116)
	local v118 = v117 ~= v117 and 0 or math.clamp(v117, -32767, 32767)
	buffer.writei16(v79, v115, v118)
	local v119 = v80 + 18
	local v120 = math.clamp(p72, 0, 255)
	buffer.writeu8(v79, v119, v120)
	local v121 = v80 + 19
	local v122 = p73 * v_u_3.HP_Q + 0.5
	local v123 = math.floor(v122)
	local v124 = math.clamp(v123, 0, 255)
	buffer.writeu8(v79, v121, v124)
	local v125 = v80 + 20
	local v126 = p74 + 0.5
	local v127 = math.floor(v126)
	local v128 = math.clamp(v127, 0, 255)
	buffer.writeu8(v79, v125, v128)
	local v129 = v80 + 21
	buffer.writeu8(v79, v129, p75)
	local v130 = v80 + 22
	local v131 = p76 * v_u_3.ROT_Q + 0.5
	local v132 = math.floor(v131)
	local v133 = v132 ~= v132 and 0 or math.clamp(v132, -32767, 32767)
	buffer.writei16(v79, v130, v133)
	local v134 = v80 + 24
	local v135 = p77 * v_u_3.ROT_Q + 0.5
	local v136 = math.floor(v135)
	local v137 = v136 ~= v136 and 0 or math.clamp(v136, -32767, 32767)
	buffer.writei16(v79, v134, v137)
	local v138 = v80 + 26
	local v139 = math.floor(p78)
	local v140 = math.clamp(v139, 0, 255)
	buffer.writeu8(v79, v138, v140)
	p68.pos = v80 + 27
end
function v_u_3.WriteValue(p141, p142, p143) -- name: WriteValue
	-- upvalues: (copy) v_u_3
	local v144 = typeof(p142)
	if v144 == "boolean" then
		local v145 = v_u_3.U8
		local v146
		if p142 then
			v146 = v_u_3.T_TRUE
		else
			v146 = v_u_3.T_FALSE
		end
		v145(p141, v146)
	elseif v144 == "number" then
		if p142 ~= p142 or (p142 == (1 / 0) or p142 == (-1 / 0)) then
			return false
		end
		if p142 == math.floor(p142) then
			if p142 >= 0 and p142 <= 255 then
				v_u_3.U8(p141, v_u_3.T_U8)
				v_u_3.U8(p141, p142)
			elseif p142 >= -2147483648 and p142 <= 2147483647 then
				v_u_3.U8(p141, v_u_3.T_I32)
				v_u_3.I32(p141, p142)
			else
				v_u_3.U8(p141, v_u_3.T_F64)
				v_u_3.F64(p141, p142)
			end
		else
			v_u_3.U8(p141, v_u_3.T_F32)
			v_u_3.F32(p141, p142)
		end
	elseif v144 == "string" then
		v_u_3.U8(p141, v_u_3.T_STR)
		v_u_3.Str(p141, p142)
	elseif v144 == "Vector3" then
		v_u_3.U8(p141, v_u_3.T_V3)
		v_u_3.V3(p141, p142)
	elseif v144 == "CFrame" then
		local v147, v148, v149 = p142:ToEulerAnglesXYZ()
		v_u_3.U8(p141, v_u_3.T_CF)
		v_u_3.V3(p141, p142.Position)
		v_u_3.F32(p141, v147)
		v_u_3.F32(p141, v148)
		v_u_3.F32(p141, v149)
	else
		if v144 ~= "Instance" then
			return false
		end
		local v150, v151 = p143(p142)
		if not v150 then
			return false
		end
		if v151 then
			v_u_3.U8(p141, v_u_3.T_PART)
			v_u_3.U8(p141, v150)
			v_u_3.Str(p141, v151)
		else
			v_u_3.U8(p141, v_u_3.T_FIGHTER)
			v_u_3.U8(p141, v150)
		end
	end
	return true
end
function v_u_3.Reader(p152, p153) -- name: Reader
	return {
		["buf"] = p152,
		["pos"] = p153 or 0,
		["len"] = buffer.len(p152)
	}
end
function v_u_3.Left(p154) -- name: Left
	return p154.len - p154.pos
end
function v_u_3.RU8(p155) -- name: RU8
	local v156 = p155.buf
	local v157 = p155.pos
	local v158 = buffer.readu8(v156, v157)
	p155.pos = p155.pos + 1
	return v158
end
function v_u_3.RU16(p159) -- name: RU16
	local v160 = p159.buf
	local v161 = p159.pos
	local v162 = buffer.readu16(v160, v161)
	p159.pos = p159.pos + 2
	return v162
end
function v_u_3.RI16(p163) -- name: RI16
	local v164 = p163.buf
	local v165 = p163.pos
	local v166 = buffer.readi16(v164, v165)
	p163.pos = p163.pos + 2
	return v166
end
function v_u_3.RU32(p167) -- name: RU32
	local v168 = p167.buf
	local v169 = p167.pos
	local v170 = buffer.readu32(v168, v169)
	p167.pos = p167.pos + 4
	return v170
end
function v_u_3.RI32(p171) -- name: RI32
	local v172 = p171.buf
	local v173 = p171.pos
	local v174 = buffer.readi32(v172, v173)
	p171.pos = p171.pos + 4
	return v174
end
function v_u_3.RF32(p175) -- name: RF32
	local v176 = p175.buf
	local v177 = p175.pos
	local v178 = buffer.readf32(v176, v177)
	p175.pos = p175.pos + 4
	return v178
end
function v_u_3.RF64(p179) -- name: RF64
	local v180 = p179.buf
	local v181 = p179.pos
	local v182 = buffer.readf64(v180, v181)
	p179.pos = p179.pos + 8
	return v182
end
function v_u_3.RStr(p183) -- name: RStr
	local v184 = p183.buf
	local v185 = p183.pos
	local v186 = buffer.readu8(v184, v185)
	local v187 = buffer.readstring(p183.buf, p183.pos + 1, v186)
	p183.pos = p183.pos + (v186 + 1)
	return v187
end
function v_u_3.RV3(p188) -- name: RV3
	local v189 = p188.buf
	local v190 = p188.pos
	local v191 = buffer.readf32(v189, v190)
	local v192 = p188.buf
	local v193 = p188.pos + 4
	local v194 = buffer.readf32(v192, v193)
	local v195 = p188.buf
	local v196 = p188.pos + 8
	local v197 = buffer.readf32(v195, v196)
	p188.pos = p188.pos + 12
	return Vector3.new(v191, v194, v197)
end
function v_u_3.ReadValue(p198) -- name: ReadValue
	-- upvalues: (copy) v_u_3
	local v199 = v_u_3.RU8(p198)
	if v199 == v_u_3.T_FALSE then
		return false
	end
	if v199 == v_u_3.T_TRUE then
		return true
	end
	if v199 == v_u_3.T_U8 then
		return v_u_3.RU8(p198)
	end
	if v199 == v_u_3.T_I32 then
		return v_u_3.RI32(p198)
	end
	if v199 == v_u_3.T_F32 then
		return v_u_3.RF32(p198)
	end
	if v199 == v_u_3.T_F64 then
		return v_u_3.RF64(p198)
	end
	if v199 == v_u_3.T_STR then
		return v_u_3.RStr(p198)
	end
	if v199 == v_u_3.T_V3 then
		return v_u_3.RV3(p198)
	end
	if v199 == v_u_3.T_CF then
		local v200 = v_u_3.RV3(p198)
		local v201 = v_u_3.RF32(p198)
		local v202 = v_u_3.RF32(p198)
		local v203 = v_u_3.RF32(p198)
		return CFrame.new(v200) * CFrame.fromEulerAnglesXYZ(v201, v202, v203)
	end
	if v199 == v_u_3.T_FIGHTER then
		return {
			["fighter"] = v_u_3.RU8(p198)
		}
	end
	if v199 == v_u_3.T_PART then
		return {
			["fighter"] = v_u_3.RU8(p198),
			["part"] = v_u_3.RStr(p198)
		}
	end
	error("ReplayCodec: bad value tag " .. tostring(v199))
end
return v_u_3