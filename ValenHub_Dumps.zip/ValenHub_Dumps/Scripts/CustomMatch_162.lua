local v_u_1 = {
	["CODE_LEN"] = 6,
	["ALPHABET"] = "ABCDEFGHJKMNPQRSTUVWXYZ23456789",
	["NAME_MAX"] = 28,
	["NAME_MIN"] = 3,
	["MAX_PLAYERS"] = 10,
	["TEAM_SIZE"] = 3,
	["LIST_MAX"] = 40,
	["LIST_REFRESH"] = 5,
	["NO_REWARDS"] = "Custom matches don\'t give rewards"
}
local v_u_2 = {}
for v3 = 1, #v_u_1.ALPHABET do
	local v4 = v_u_1.ALPHABET
	v_u_2[string.sub(v4, v3, v3)] = true
end
function v_u_1.CleanCode(p5) -- name: CleanCode
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	if type(p5) ~= "string" then
		return ""
	end
	local v6 = {}
	for v7 in string.gmatch(string.upper((string.sub(p5, 1, 64))), ".") do
		if not v_u_2[v7] then
			continue
		end
		table.insert(v6, v7)
		if #v6 < v_u_1.CODE_LEN then
			continue
		end
	end
	return table.concat(v6)
end
function v_u_1.ValidCode(p8) -- name: ValidCode
	-- upvalues: (copy) v_u_1
	local v9 = v_u_1.CleanCode(p8)
	if #v9 == v_u_1.CODE_LEN and (type(p8) == "string" and #p8 <= 64) then
		return v9
	else
		return nil
	end
end
function v_u_1.FormatCode(p10) -- name: FormatCode
	-- upvalues: (copy) v_u_1
	if #p10 == v_u_1.CODE_LEN then
		return string.sub(p10, 1, 3) .. " " .. string.sub(p10, 4)
	else
		return p10
	end
end
function v_u_1.CleanName(p11) -- name: CleanName
	-- upvalues: (copy) v_u_1
	if type(p11) ~= "string" then
		return ""
	end
	local v12 = string.sub(p11, 1, 200)
	local v13 = string.gsub(v12, "[%c]", " ")
	local v14 = string.gsub(v13, "%s+", " ")
	local v15 = string.match(v14, "^%s*(.-)%s*$") or ""
	if not utf8.len(v15) then
		return ""
	end
	if utf8.len(v15) > v_u_1.NAME_MAX then
		local v16 = (utf8.offset(v15, v_u_1.NAME_MAX + 1) or #v15 + 1) - 1
		local v17 = string.sub(v15, 1, v16)
		v15 = string.match(v17, "^(.-)%s*$") or v17
	end
	return v15
end
function v_u_1.DefaultName(p18) -- name: DefaultName
	-- upvalues: (copy) v_u_1
	local v19 = v_u_1.CleanName(p18 .. "\'s match")
	return v19 == "" and "Custom match" or v19
end
return v_u_1