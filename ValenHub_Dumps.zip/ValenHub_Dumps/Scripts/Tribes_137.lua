local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage"):WaitForChild("Shared")
local v_u_3 = require(v2:WaitForChild("Signal"))
local v_u_4 = require(v2:WaitForChild("Tribes"))
local v5 = {}
local v_u_6 = {}
function v5.Init(p_u_7) -- name: Init
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_4, (copy) v_u_6
	local v_u_8 = p_u_7.Remotes
	local v_u_9 = v_u_1.LocalPlayer
	local v_u_10 = {
		["Changed"] = v_u_3.new(),
		["HomeChanged"] = v_u_3.new()
	}
	v_u_8.Timeouts.TribeAction = 20
	local v_u_11 = nil
	local v_u_12 = (-1 / 0)
	local v_u_13 = nil
	local v_u_14 = (-1 / 0)
	local v_u_15 = false
	function v_u_10.Action(p16, ...) -- name: Action
		-- upvalues: (copy) v_u_8, (ref) v_u_4
		local v17, v18, v19 = v_u_8.Invoke("TribeAction", p16, ...)
		if v17 then
			if v18 == true then
				return true, v19
			else
				return false, v_u_4.Message(v19)
			end
		else
			return false, v_u_4.Message("unavailable")
		end
	end
	function v_u_10.Home(p20) -- name: Home
		-- upvalues: (ref) v_u_11, (ref) v_u_12, (ref) v_u_15, (copy) v_u_10
		if not p20 and (v_u_11 and os.clock() - v_u_12 < 8) then
			return v_u_11
		end
		if v_u_15 then
			local v21 = os.clock()
			while v_u_15 and os.clock() - v21 < 10 do
				task.wait(0.05)
			end
			return v_u_11
		end
		v_u_15 = true
		local v22, v23 = v_u_10.Action("Home")
		v_u_15 = false
		if not v22 or type(v23) ~= "table" then
			return nil
		end
		v_u_11 = v23
		v_u_12 = os.clock()
		v_u_10.HomeChanged:Fire(v_u_11)
		return v_u_11
	end
	function v_u_10.Cached() -- name: Cached
		-- upvalues: (ref) v_u_11
		return v_u_11
	end
	local v_u_24 = {}
	local v_u_25 = {}
	local function v_u_34(p26, p27, p28) -- name: listed
		-- upvalues: (copy) v_u_24, (copy) v_u_25, (ref) v_u_4
		local v29 = v_u_24[p26]
		if p27 or (not v29 or os.clock() - v29.at >= 15) then
			if v_u_25[p26] then
				local v30 = os.clock()
				while v_u_25[p26] and os.clock() - v30 < 20 do
					task.wait(0.03)
				end
				local v31 = v_u_24[p26]
				if v31 then
					return true, v31.v
				else
					return false, v_u_4.Message("unavailable")
				end
			else
				v_u_25[p26] = true
				local v32, v33 = p28()
				v_u_25[p26] = nil
				if v32 then
					v_u_24[p26] = {
						["at"] = os.clock(),
						["v"] = v33
					}
				end
				return v32, v33
			end
		else
			return true, v29.v
		end
	end
	function v_u_10.Board(p_u_35, p36) -- name: Board
		-- upvalues: (copy) v_u_34, (copy) v_u_10
		return v_u_34("board:" .. p_u_35, p36, function()
			-- upvalues: (ref) v_u_10, (copy) p_u_35
			return v_u_10.Action("Search", "", p_u_35)
		end)
	end
	function v_u_10.Rank(p_u_37, p38) -- name: Rank
		-- upvalues: (copy) v_u_34, (copy) v_u_9, (copy) v_u_10
		return v_u_34(("rank:%*|%*"):format(v_u_9:GetAttribute("TribeId") or 0, p_u_37), p38, function()
			-- upvalues: (ref) v_u_10, (copy) p_u_37
			return v_u_10.Action("Rank", p_u_37)
		end)
	end
	function v_u_10.CachedBoard(p39) -- name: CachedBoard
		-- upvalues: (copy) v_u_24
		local v40 = v_u_24["board:" .. p39]
		local v41
		if v40 then
			v41 = v40.v
		else
			v41 = nil
		end
		if v40 then
			return v41, os.clock() - v40.at
		else
			return v41, (1 / 0)
		end
	end
	function v_u_10.CachedRank(p42) -- name: CachedRank
		-- upvalues: (copy) v_u_24, (copy) v_u_9
		local v43 = v_u_24[("rank:%*|%*"):format(v_u_9:GetAttribute("TribeId") or 0, p42)]
		local v44
		if v43 then
			v44 = v43.v
		else
			v44 = nil
		end
		if v43 then
			return v44, os.clock() - v43.at
		else
			return v44, (1 / 0)
		end
	end
	task.delay(2, function()
		-- upvalues: (copy) p_u_7, (copy) v_u_10
		local v45 = p_u_7.State
		if not (v45 and (v45.InMatch and v45.InMatch())) then
			task.spawn(v_u_10.Board, "top")
			task.spawn(v_u_10.Board, "alltime")
			if v_u_10.Mine() then
				task.spawn(v_u_10.Rank, "top")
			end
		end
	end)
	function v_u_10.Territories(p46) -- name: Territories
		-- upvalues: (ref) v_u_13, (ref) v_u_14, (copy) v_u_10, (ref) v_u_6
		if not p46 and (v_u_13 and os.clock() - v_u_14 < 30) then
			return v_u_13
		end
		local v47, v48 = v_u_10.Action("Territories")
		if v47 and type(v48) == "table" then
			v_u_13 = v48
			v_u_14 = os.clock()
			local v49 = v48.maps
			for v50, v51 in type(v49) ~= "table" and {} or v48.maps do
				if type(v51) ~= "table" then
					continue
				end
				local v52 = v51.name
				if type(v52) ~= "string" then
					continue
				end
				v_u_6[v50] = v51.name
			end
		end
		return v_u_13
	end
	function v_u_10.CachedTerritories() -- name: CachedTerritories
		-- upvalues: (ref) v_u_13
		return v_u_13
	end
	function v_u_10.MapName(p53) -- name: MapName
		-- upvalues: (ref) v_u_6
		return v_u_6[tostring(p53)] or string.gsub(tostring(p53), "(%l)(%u)", "%1 %2")
	end
	function v_u_10.Of(p54) -- name: Of
		if not p54 then
			return nil
		end
		local v55 = p54:GetAttribute("TribeId")
		local v56 = p54:GetAttribute("TribeTag")
		return type(v55) == "number" and (v55 > 0 and (type(v56) == "string" and v56 ~= "")) and {
			["id"] = v55,
			["tag"] = v56,
			["icon"] = p54:GetAttribute("TribeIcon") or 1,
			["color1"] = p54:GetAttribute("TribeColor1") or 1,
			["color2"] = p54:GetAttribute("TribeColor2") or 1,
			["role"] = p54:GetAttribute("TribeRole") or "member"
		} or nil
	end
	function v_u_10.Mine() -- name: Mine
		-- upvalues: (copy) v_u_10, (copy) v_u_9
		return v_u_10.Of(v_u_9)
	end
	local v_u_57 = false
	local function v58() -- name: invalidate
		-- upvalues: (ref) v_u_12, (copy) v_u_10, (ref) v_u_57, (copy) p_u_7
		v_u_12 = (-1 / 0)
		v_u_10.Changed:Fire()
		if not v_u_57 then
			v_u_57 = true
			task.delay(0.4, function()
				-- upvalues: (ref) v_u_57, (ref) p_u_7, (ref) v_u_10
				v_u_57 = false
				if p_u_7.MenuManager.IsOpen("Tribe") then
					v_u_10.Home(true)
				end
			end)
		end
	end
	local v_u_59 = v_u_14
	local v_u_60 = v_u_57
	local v_u_61 = v_u_12
	for _, v62 in {
		"TribeId",
		"TribeTag",
		"TribeRole",
		"TribeIcon",
		"TribeColor1",
		"TribeColor2"
	} do
		v_u_9:GetAttributeChangedSignal(v62):Connect(v58)
	end
	local v_u_63 = {
		["chief"] = "the Chief",
		["elder"] = "an Elder",
		["member"] = "a Member"
	}
	local v_u_89 = {
		["request"] = function(p64) -- name: request
			local v65 = p64.name or "Someone"
			return ("%* asked to join your tribe"):format((tostring(v65))), "info"
		end,
		["accepted"] = function(p66) -- name: accepted
			local v67 = "You joined %*!"
			local v68
			if type(p66) == "table" then
				local v69 = p66.tag
				v68 = type(v69) ~= "string" and "your tribe" or "[" .. p66.tag .. "]"
			else
				v68 = "your tribe"
			end
			return v67:format(v68), "success"
		end,
		["declined"] = function(p70) -- name: declined
			local v71 = "%* declined your request"
			local v72
			if type(p70) == "table" then
				local v73 = p70.tag
				v72 = type(v73) ~= "string" and "your tribe" or "[" .. p70.tag .. "]"
			else
				v72 = "your tribe"
			end
			return v71:format(v72), "warning"
		end,
		["invited"] = function(p74) -- name: invited
			local v75 = "%* invited you to %* %*. Open Tribes to answer"
			local v76 = p74.from or "Someone"
			local v77 = tostring(v76)
			local v78
			if type(p74) == "table" then
				local v79 = p74.tag
				v78 = type(v79) ~= "string" and "your tribe" or "[" .. p74.tag .. "]"
			else
				v78 = "your tribe"
			end
			local v80 = p74.name or ""
			return v75:format(v77, v78, (tostring(v80))), "info"
		end,
		["kicked"] = function(p81) -- name: kicked
			local v82 = "You were removed from %*"
			local v83
			if type(p81) == "table" then
				local v84 = p81.tag
				v83 = type(v84) ~= "string" and "your tribe" or "[" .. p81.tag .. "]"
			else
				v83 = "your tribe"
			end
			return v82:format(v83), "warning"
		end,
		["role"] = function(p85) -- name: role
			-- upvalues: (copy) v_u_63
			return ("You\'re now %* of your tribe"):format(v_u_63[p85.role] or "a Member"), "success"
		end,
		["took"] = function(p86) -- name: took
			-- upvalues: (copy) v_u_10
			return ("Your tribe took %*!"):format((v_u_10.MapName(p86.mapId))), "success"
		end,
		["lost"] = function(p87) -- name: lost
			-- upvalues: (copy) v_u_10
			local v88 = p87.to or "?"
			return ("[%*] took %* from your tribe"):format(tostring(v88), (v_u_10.MapName(p87.mapId))), "warning"
		end,
		["visitFailed"] = function() -- name: visitFailed
			return "Couldn\'t join their lobby. It may be full.", "error"
		end
	}
	v_u_8.On("TribeEvent", function(p90, p91)
		-- upvalues: (ref) v_u_61, (copy) v_u_10, (ref) v_u_60, (copy) p_u_7, (copy) v_u_89, (ref) v_u_59
		if p90 == "Changed" then
			v_u_61 = (-1 / 0)
			v_u_10.Changed:Fire()
			if not v_u_60 then
				v_u_60 = true
				task.delay(0.4, function()
					-- upvalues: (ref) v_u_60, (ref) p_u_7, (ref) v_u_10
					v_u_60 = false
					if p_u_7.MenuManager.IsOpen("Tribe") then
						v_u_10.Home(true)
					end
				end)
			end
		else
			if p90 == "Notice" and type(p91) == "table" then
				local v92 = v_u_89
				local v93 = p91.kind
				local v94 = v92[tostring(v93)]
				if v94 then
					local v95 = p91.data
					local v96, v97 = v94(type(v95) ~= "table" and {} or p91.data)
					if v96 then
						p_u_7.Toast(v96, v97, true)
					end
				end
				if p91.kind == "took" or p91.kind == "lost" then
					v_u_59 = (-1 / 0)
					return
				end
			elseif p90 == "Chest" and type(p91) == "table" then
				local v98 = p91.territories
				local v99 = (tonumber(v98) or 0) <= 0 and "" or (" +%* territory bonus"):format(p91.territories)
				local v100 = p_u_7.Toast
				local v101 = p91.tier
				v100(("Tribe Chest opened: tier %*%*"):format(tostring(v101), v99), "success", true)
			end
			return
		end
	end)
	p_u_7.Tribes = v_u_10
end
return v5