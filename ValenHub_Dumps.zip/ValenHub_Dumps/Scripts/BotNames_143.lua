local v_u_1 = {}
local v_u_2 = {
	"Liam",
	"Noah",
	"Mason",
	"Ethan",
	"Jacob",
	"Aiden",
	"Jayden",
	"Logan",
	"Lucas",
	"Elijah",
	"Carter",
	"Caden",
	"Jackson",
	"Grayson",
	"Owen",
	"Wyatt",
	"Hunter",
	"Levi",
	"Isaac",
	"Landon",
	"Brayden",
	"Cameron",
	"Dylan",
	"Tyler",
	"Ryan",
	"Nathan",
	"Gavin",
	"Colton",
	"Evan",
	"Julian",
	"Adrian",
	"Chase",
	"Bentley",
	"Xavier",
	"Josiah",
	"Jace",
	"Kayden",
	"Easton",
	"Ryder",
	"Kai",
	"Mateo",
	"Diego",
	"Carlos",
	"Luis",
	"Andre",
	"Malik",
	"Darius",
	"Oliver",
	"Harry",
	"Alfie",
	"Charlie",
	"Freddie",
	"Gabriel",
	"Rafael",
	"Arthur",
	"Miguel",
	"Davi",
	"Enzo",
	"Bruno",
	"Pedro",
	"Joao",
	"Lukas",
	"Jonas",
	"Felix",
	"Leon",
	"Emil",
	"Marco",
	"Nico",
	"Jerome",
	"Kyle",
	"Justin",
	"Brandon",
	"Austin",
	"Jake",
	"Max",
	"Sam",
	"Ben",
	"Leo",
	"Finn",
	"Axel",
	"Zane",
	"Jaxon",
	"Declan",
	"Rowan",
	"Silas",
	"Theo",
	"Ezra",
	"Asher",
	"Maverick",
	"Tristan",
	"Omar",
	"Yusuf",
	"Ali",
	"Kenji"
}
local v_u_3 = {
	"Emma",
	"Olivia",
	"Ava",
	"Sophia",
	"Isabella",
	"Mia",
	"Abigail",
	"Emily",
	"Madison",
	"Chloe",
	"Ella",
	"Avery",
	"Harper",
	"Lily",
	"Addison",
	"Aubrey",
	"Brooklyn",
	"Zoey",
	"Layla",
	"Riley",
	"Kaylee",
	"Paisley",
	"Peyton",
	"Skylar",
	"Bella",
	"Nevaeh",
	"Aaliyah",
	"Kylie",
	"Makayla",
	"Savannah",
	"Mackenzie",
	"Gabriella",
	"Camila",
	"Valentina",
	"Sofia",
	"Luna",
	"Hailey",
	"Jasmine",
	"Ariana",
	"Kennedy",
	"Alexis",
	"Destiny",
	"Trinity",
	"Maddie",
	"Katie",
	"Kaitlyn",
	"Ruby",
	"Ivy",
	"Grace",
	"Amelia",
	"Evie",
	"Freya",
	"Isla",
	"Poppy",
	"Maria",
	"Julia",
	"Beatriz",
	"Larissa",
	"Yasmin",
	"Clara",
	"Lea",
	"Mila",
	"Nina",
	"Elena",
	"Andrea",
	"Jade",
	"Stella",
	"Violet",
	"Hazel",
	"Aurora",
	"Nova",
	"Willow",
	"Emilia",
	"Piper",
	"Quinn",
	"Remi",
	"Leah",
	"Sadie",
	"Nora",
	"Aria",
	"Everly",
	"Daisy",
	"Rosie",
	"Millie",
	"Summer",
	"Autumn",
	"Maya",
	"Kiara",
	"Aisha",
	"Hana"
}
local v_u_4 = {
	"strawberry",
	"cherry",
	"peach",
	"honey",
	"mochi",
	"boba",
	"matcha",
	"lavender",
	"velvet",
	"cloud",
	"moon",
	"star",
	"sunny",
	"dreamy",
	"soft",
	"sweet",
	"angel",
	"bunny",
	"kitty",
	"bubble",
	"sugar",
	"pastel",
	"blossom",
	"daisy",
	"rose",
	"glitter",
	"sparkle",
	"cookie",
	"cupcake",
	"milk",
	"mango",
	"kiwi",
	"lemon",
	"sprinkle",
	"pudding",
	"marshmallow",
	"cocoa",
	"berry",
	"coco",
	"fairy",
	"butterfly",
	"panda",
	"froggy"
}
local v_u_5 = {
	"milk",
	"vibes",
	"core",
	"dreams",
	"bby",
	"cake",
	"pie",
	"girl",
	"love",
	"tea",
	"fluff",
	"latte"
}
local v_u_6 = {
	"Shadow",
	"Dark",
	"Ghost",
	"Frost",
	"Blaze",
	"Storm",
	"Nova",
	"Venom",
	"Toxic",
	"Night",
	"Void",
	"Neon",
	"Pixel",
	"Glitch",
	"Hyper",
	"Turbo",
	"Rogue",
	"Phantom",
	"Cyber",
	"Ninja",
	"Dragon",
	"Wolf",
	"Fox",
	"Tiger",
	"Viper",
	"Crazy",
	"Savage",
	"Swift",
	"Flash",
	"Icy",
	"Lava",
	"Astro",
	"Galaxy",
	"Thunder",
	"Lightning",
	"Epic",
	"Mega",
	"Ultra",
	"Silent",
	"Lucky",
	"Crimson",
	"Golden",
	"Cosmic",
	"Blue",
	"Red",
	"Black"
}
local v_u_7 = {
	"Slayer",
	"Master",
	"King",
	"Queen",
	"Legend",
	"Beast",
	"Gamer",
	"Pro",
	"Boss",
	"Hero",
	"Warrior",
	"Rider",
	"Striker",
	"Hunter",
	"Ghost",
	"Wolf",
	"Fox",
	"Dragon",
	"Ninja",
	"Knight",
	"Reaper",
	"Flame",
	"Storm",
	"Blade",
	"Shot",
	"Wing",
	"Byte",
	"Star",
	"Z",
	"X",
	"Guy",
	"Kid",
	"Dude",
	"Boi",
	"Gaming"
}
local v_u_8 = {
	"YT",
	"TTV",
	"Plays",
	"Playz",
	"RBLX",
	"Gaming",
	"Official",
	"Pro",
	"Alt",
	"Jr",
	"HD",
	"OP",
	"Main"
}
local v_u_9 = {
	"pizza",
	"taco",
	"nugget",
	"waffle",
	"pancake",
	"potato",
	"banana",
	"pickle",
	"noodle",
	"burrito",
	"donut",
	"cookie",
	"cheese",
	"bacon",
	"toast",
	"cereal",
	"popcorn",
	"icecream",
	"sushi",
	"cake",
	"cat",
	"dog",
	"puppy",
	"doggo",
	"kitten",
	"hamster",
	"duck",
	"frog",
	"penguin",
	"dino",
	"shark",
	"bear",
	"bunny"
}
local v_u_10 = {
	"idk_what2name",
	"idkwhattoname",
	"no_name",
	"justaplayer",
	"notanoob",
	"noobmaster",
	"prokid",
	"bacon_hair",
	"imthebest",
	"coolkid",
	"epicgamer",
	"totallynotanoob",
	"randomguy",
	"somebody",
	"justvibing",
	"hihello",
	"lol_xd",
	"noob",
	"guest",
	"ilovepizza",
	"ilovecats",
	"bruhmoment",
	"yeet",
	"whoami"
}
v_u_1.Words = {
	["BOYS"] = v_u_2,
	["GIRLS"] = v_u_3,
	["SOFT"] = v_u_4,
	["GAME_A"] = v_u_6,
	["GAME_B"] = v_u_7,
	["THING"] = v_u_9,
	["MEME"] = v_u_10
}
local v_u_11 = {}
local v_u_12 = {}
local v_u_13 = Random.new()
local function v_u_17(p14, p15) -- name: digits
	local v16 = p14:NextNumber()
	if p15 and v16 < 0.12 then
		return ""
	elseif v16 < 0.27 then
		return tostring(p14:NextInteger(1, 99))
	elseif v16 < 0.45 then
		return tostring(p14:NextInteger(100, 999))
	elseif v16 < 0.62 then
		return tostring(p14:NextInteger(1000, 9999))
	elseif v16 < 0.8 then
		return tostring(p14:NextInteger(2007, 2017))
	elseif v16 < 0.9 then
		return tostring(p14:NextInteger(10000, 99999))
	elseif v16 < 0.95 then
		return string.format("%02d", p14:NextInteger(0, 9))
	else
		return tostring(p14:NextInteger(100000, 999999))
	end
end
local function v_u_27(p18, p19) -- name: respell
	local v20 = p18:NextNumber()
	if v20 < 0.4 then
		local v21 = string.sub(p19, -1)
		return p19 .. string.rep(v21, p18:NextInteger(1, 2))
	end
	if v20 >= 0.65 then
		if v20 >= 0.85 then
			return p19 .. p19:sub(-1) .. "x"
		end
		local v22 = {
			"z",
			"x",
			"ie",
			"y"
		}
		return p19 .. v22[p18:NextInteger(1, #v22)]
	end
	local v23 = string.find(p19, "[aeiouAEIOU]", 2)
	if not v23 then
		return p19 .. "x"
	end
	local v24 = v23 - 1
	local v25 = string.sub(p19, 1, v24)
	local v26 = v23 + 1
	return v25 .. "x" .. string.sub(p19, v26)
end
local function v_u_78(p28) -- name: candidate
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_17, (copy) v_u_27, (copy) v_u_8, (copy) v_u_4, (copy) v_u_5, (copy) v_u_6, (copy) v_u_7, (copy) v_u_9, (copy) v_u_10
	local v29 = p28:NextNumber()
	if v29 < 0.3 then
		local v30
		if p28:NextNumber() < 0.5 then
			local v31 = v_u_2
			v30 = v31[p28:NextInteger(1, #v31)]
		else
			local v32 = v_u_3
			v30 = v32[p28:NextInteger(1, #v32)]
		end
		if p28:NextNumber() < 0.6 then
			v30 = string.lower(v30)
		end
		local v33 = v_u_17(p28, false)
		if v33 == "" then
			return v30
		elseif p28:NextNumber() < 0.35 then
			return v30 .. "_" .. v33
		else
			return v30 .. v33
		end
	elseif v29 < 0.42 then
		local v34
		if p28:NextNumber() < 0.5 then
			local v35 = v_u_2
			v34 = v35[p28:NextInteger(1, #v35)]
		else
			local v36 = v_u_3
			v34 = v36[p28:NextInteger(1, #v36)]
		end
		local v37 = v_u_27
		if p28:NextNumber() < 0.7 then
			v34 = string.lower(v34)
		end
		local v38 = v37(p28, v34)
		local v39 = v_u_17(p28, true)
		if v39 == "" then
			return v38
		elseif p28:NextNumber() < 0.4 then
			return v38 .. "_" .. v39
		else
			return v38 .. v39
		end
	elseif v29 < 0.5 then
		local v40
		if p28:NextNumber() < 0.5 then
			local v41 = v_u_2
			v40 = v41[p28:NextInteger(1, #v41)]
		else
			local v42 = v_u_3
			v40 = v42[p28:NextInteger(1, #v42)]
		end
		local v43 = v_u_8
		local v44 = v43[p28:NextInteger(1, #v43)]
		if p28:NextNumber() < 0.5 then
			v40 = string.lower(v40)
			v44 = string.lower(v44)
		end
		if v44 ~= "" then
			if p28:NextNumber() < 0.3 then
				v40 = v40 .. "_" .. v44
			else
				v40 = v40 .. v44
			end
		end
		return v40 .. (p28:NextNumber() >= 0.4 and "" or v_u_17(p28, true))
	elseif v29 < 0.62 then
		local v45 = v_u_4
		local v46 = v45[p28:NextInteger(1, #v45)]
		local v47 = p28:NextNumber()
		if v47 < 0.45 then
			local v48 = v_u_5
			local v49 = v46 .. v48[p28:NextInteger(1, #v48)]
			if p28:NextNumber() < 0.5 then
				return v_u_27(p28, v49)
			else
				return v49 .. v_u_17(p28, true)
			end
		elseif v47 < 0.65 then
			local v50 = {
				"xo",
				"its",
				"ur",
				"lil",
				"iam"
			}
			local v51 = v50[p28:NextInteger(1, #v50)]
			local v52 = "_"
			local v53
			if p28:NextNumber() < 0.4 then
				local v54 = { "x", "z", "xo" }
				v53 = v54[p28:NextInteger(1, #v54)]
			else
				v53 = ""
			end
			return v51 .. v52 .. v46 .. v53
		elseif v47 < 0.85 then
			local v55 = v_u_4
			return v46 .. v55[p28:NextInteger(1, #v55)] .. (p28:NextNumber() < 0.5 and "z" or v_u_17(p28, true))
		else
			local v56 = {
				"x",
				"xo",
				"xx",
				"07",
				"13",
				"22"
			}
			return v_u_27(p28, v46) .. "_" .. v56[p28:NextInteger(1, #v56)]
		end
	elseif v29 < 0.78 then
		local v57 = v_u_6
		local v58 = v57[p28:NextInteger(1, #v57)]
		local v59 = v_u_7
		local v60 = v59[p28:NextInteger(1, #v59)]
		local v61 = p28:NextNumber()
		if v61 < 0.4 then
			local v62 = v58 .. v60
			local v63 = v_u_17(p28, true)
			if v63 == "" then
				return v62
			elseif p28:NextNumber() < 0.4 then
				return v62 .. "_" .. v63
			else
				return v62 .. v63
			end
		elseif v61 < 0.55 then
			return "xX" .. v58 .. (p28:NextNumber() >= 0.5 and "" or v60) .. "Xx"
		elseif v61 < 0.7 then
			local v64 = v_u_8
			return v58 .. v64[p28:NextInteger(1, #v64)] .. (p28:NextNumber() >= 0.3 and "" or v_u_17(p28, true))
		elseif v61 < 0.85 then
			return string.lower(v58 .. v60) .. v_u_17(p28, false)
		else
			return v58 .. "_" .. v60 .. (p28:NextNumber() >= 0.5 and "" or tostring(p28:NextInteger(1, 99)))
		end
	elseif v29 < 0.87 then
		local v65 = v_u_9
		local v66 = v65[p28:NextInteger(1, #v65)]
		local v67 = {
			"lover",
			"guy",
			"girl",
			"kid",
			"boy",
			"king",
			"queen",
			"man",
			"fan",
			"",
			""
		}
		local v68 = v67[p28:NextInteger(1, #v67)]
		local v69 = v66 .. v68
		local v70 = v_u_17(p28, v68 == "")
		if v70 == "" then
			return v69
		elseif p28:NextNumber() < 0.35 then
			return v69 .. "_" .. v70
		else
			return v69 .. v70
		end
	elseif v29 < 0.94 then
		local v71 = v_u_10
		local v72 = v71[p28:NextInteger(1, #v71)]
		local v73 = v_u_17(p28, false)
		if string.find(v72, "_") then
			return v72 .. v73
		elseif v73 == "" then
			return v72
		elseif p28:NextNumber() < 0.3 then
			return v72 .. "_" .. v73
		else
			return v72 .. v73
		end
	else
		local v74 = ""
		for _ = 1, p28:NextInteger(2, 3) do
			local v75 = p28:NextInteger(1, 20)
			v74 = v74 .. string.sub("abcdefghjklmnprstvwz", v75, v75)
		end
		if p28:NextNumber() < 0.3 then
			v74 = string.upper(v74)
		end
		local v76
		if p28:NextNumber() < 0.25 then
			local v77 = {
				"plays",
				"gaming",
				"yt",
				"lol"
			}
			v76 = v77[p28:NextInteger(1, #v77)]
		else
			v76 = v_u_17(p28, false)
		end
		if v76 == "" then
			return v74
		elseif p28:NextNumber() < 0.4 then
			return v74 .. "_" .. v76
		else
			return v74 .. v76
		end
	end
end
function v_u_1.IsValid(p79) -- name: IsValid
	if #p79 < 3 or #p79 > 20 then
		return false
	end
	if not string.match(p79, "^[%w_]+$") then
		return false
	end
	if string.match(p79, "^%d+$") then
		return false
	end
	local _, v80 = string.gsub(p79, "_", "")
	if v80 > 1 then
		return false
	end
	local v81
	if string.sub(p79, 1, 1) == "_" then
		v81 = false
	else
		v81 = string.sub(p79, -1) ~= "_"
	end
	return v81
end
local function v_u_95(p82, p83) -- name: displayFor
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	if p82:NextNumber() < 0.42 then
		return p83
	else
		local v84 = string.lower(p83)
		local v85 = nil
		for _, v86 in { v_u_2, v_u_3 } do
			for _, v87 in v86 do
				if #v87 < 3 then
					continue
				end
				local v88 = #v87
				if string.sub(v84, 1, v88) ~= string.lower(v87) or v85 and #v87 <= #v85 then
					continue
				end
				v85 = v87
			end
		end
		local v89 = p82:NextNumber()
		if v85 then
			if v89 >= 0.5 then
				if v89 < 0.8 then
					v85 = string.lower(v85)
				elseif v89 < 0.88 then
					v85 = string.upper(v85)
				elseif v89 < 0.95 then
					local v90 = {
						"x",
						"xo",
						"07",
						"11",
						"13"
					}
					v85 = v85 .. "_" .. v90[p82:NextInteger(1, #v90)]
				else
					v85 = p83
				end
			end
		elseif v89 < 0.75 then
			local v91 = string.gsub(p83, "%d+$", "")
			local v92 = string.gsub(v91, "_$", "")
			v85 = string.match(v92, "^xX(.+)Xx$") or v92
		elseif v89 < 0.88 then
			if p82:NextNumber() < 0.5 then
				local v93 = v_u_2
				v85 = v93[p82:NextInteger(1, #v93)]
			else
				local v94 = v_u_3
				v85 = v94[p82:NextInteger(1, #v94)]
			end
			if p82:NextNumber() < 0.35 then
				v85 = string.lower(v85)
			end
		else
			v85 = p83
		end
		if #v85 < 3 or (#v85 > 20 or not string.match(v85, "^[%w_]+$")) then
			return p83
		else
			return v85
		end
	end
end
function v_u_1.Make(p96) -- name: Make
	-- upvalues: (copy) v_u_13, (copy) v_u_2, (copy) v_u_78, (copy) v_u_1, (copy) v_u_11, (copy) v_u_12
	local v97 = p96 or v_u_13
	local v98 = v_u_2
	local v99 = string.lower(v98[v97:NextInteger(1, #v98)]) .. tostring(v97:NextInteger(1000, 99999))
	for _ = 1, 30 do
		local v100 = v_u_78(v97)
		if not v_u_1.IsValid(v100) or v_u_11[v100] then
			continue
		end
		v99 = v100
	end
	v_u_11[v99] = true
	local v101 = v_u_12
	table.insert(v101, v99)
	if #v_u_12 > 300 then
		v_u_11[table.remove(v_u_12, 1)] = nil
	end
	return v99
end
function v_u_1.MakeIdentity(p102) -- name: MakeIdentity
	-- upvalues: (copy) v_u_13, (copy) v_u_1, (copy) v_u_95
	local v103 = p102 or v_u_13
	local v104 = v_u_1.Make(v103)
	return v104, v_u_95(v103, v104)
end
return v_u_1