local v1 = game:GetService("ReplicatedStorage")
local v2 = script.Parent.Parent
local v_u_3 = require(v2.Util)
local v_u_4 = require(v2.Hud)
local v_u_5 = require(v2.Effects)
local v_u_6 = require(v1:WaitForChild("Shared"):WaitForChild("Combat"))
local v_u_7 = {}
v_u_7.__index = v_u_7
function v_u_7.new(p8) -- name: new
	-- upvalues: (copy) v_u_7
	local v9 = v_u_7
	local v10 = setmetatable({}, v9)
	v10.ctx = p8
	v10.tuning = p8.tuning
	v10.preset = p8.preset
	v10.kind = p8.kind
	v10.winds = p8.kind == "Javelin" and true or p8.kind == "Bomb"
	v10.winding = false
	v10.start = 0
	v10.lastThrow = (-1 / 0)
	v10.m1Down = false
	v10.preview = false
	v10.charges = 0
	v10.maxCharges = p8.tuning.charges or 0
	v10.bufferedAt = nil
	v10.conns = {}
	v10.stopLoop = nil
	return v10
end
function v_u_7.StopLoop(p11) -- name: StopLoop
	if p11.stopLoop then
		p11.stopLoop(0.15)
		p11.stopLoop = nil
	end
end
function v_u_7.StartLoop(p12, p13) -- name: StartLoop
	-- upvalues: (copy) v_u_3
	if p13 and not p12.stopLoop then
		local v14 = p12.ctx.tool
		if v14 then
			v14 = p12.ctx.tool:FindFirstChild("Handle")
		end
		p12.stopLoop = v_u_3.Loop(p13, v14 or p12.ctx.root)
	end
end
function v_u_7.Sync(p15) -- name: Sync
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v16 = p15.ctx.tool
	local v17 = v16:GetAttribute("Charges")
	if type(v17) == "number" then
		if p15.charges < v17 and (p15.preset.readySound and p15.ctx.tool.Parent == p15.ctx.char) then
			v_u_3.Sound(p15.preset.readySound, p15.ctx.root)
		end
		p15.charges = v17
	end
	if p15.maxCharges > 0 then
		v_u_4.SetPips(p15.charges, p15.maxCharges)
	end
	local v18 = v16:GetAttribute("NextCharge")
	if type(v18) == "number" and (v18 > 0 and p15.tuning.regen) then
		local v19 = v18 - workspace:GetServerTimeNow()
		if v19 > 0 then
			v_u_4.SetArc(p15.tuning.regen, Color3.fromRGB(150, 200, 255), p15.tuning.regen - v19)
		end
	end
end
function v_u_7.Equip(p_u_20) -- name: Equip
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v21 = p_u_20.ctx
	v_u_4.SetStyle("Throw")
	v_u_4.SetPips(0, 0)
	p_u_20:Sync()
	v_u_3.PlayAnim(v21.animator, p_u_20.preset.hold, 1, 0.2)
	v_u_3.Sound(p_u_20.preset.equip or "Equip_Item", v21.root)
	local v22 = v21.tool
	local v23 = p_u_20.conns
	local v24 = v22:GetAttributeChangedSignal("Charges")
	table.insert(v23, v24:Connect(function()
		-- upvalues: (copy) p_u_20
		p_u_20:Sync()
	end))
	local v25 = p_u_20.conns
	local v26 = v22:GetAttributeChangedSignal("NextCharge")
	table.insert(v25, v26:Connect(function()
		-- upvalues: (copy) p_u_20
		p_u_20:Sync()
	end))
end
function v_u_7.Unequip(p27) -- name: Unequip
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4
	for _, v28 in p27.conns do
		v28:Disconnect()
	end
	table.clear(p27.conns)
	if p27.winding then
		p27:Cancel()
	end
	p27:StopLoop()
	if p27.preview then
		p27.preview = false
		v_u_3.SetAiming(false)
	end
	v_u_3.StopAnim(p27.ctx.animator, p27.preset.hold, 0.15)
	v_u_5.Trajectory(nil)
	v_u_4.SetPips(0, 0)
	v_u_4.SetArc(nil)
end
function v_u_7.Charge(p29) -- name: Charge
	if not p29.winding then
		return 0
	end
	local v30 = (os.clock() - p29.start) / (p29.tuning.drawTime or 0.5)
	return math.clamp(v30, 0, 1)
end
function v_u_7.Launch(p31, p32, p33) -- name: Launch
	-- upvalues: (copy) v_u_3, (copy) v_u_6
	local v34 = p31.ctx
	local v35 = p31.tuning
	local v36
	if (p31.kind == "Sling" and true or v34.weaponId == "bolas") and v_u_3.InFirstPerson() then
		v36 = v_u_3.ShotOrigin(nil)
	else
		v36 = v_u_3.ShotOrigin(v34.tool, "Tip")
	end
	local v37 = v_u_3.AimDirection(v36)
	if p33 and p31.kind ~= "Bomb" then
		v37 = v_u_3.AssistDirection(v36, v37, true)
	end
	local v38 = p31.kind == "Bomb" and 0.16 or (p31.kind == "Sling" and 0.05 or (p31.kind == "Javelin" and 0.04 or 0.01))
	local v39 = (v37 + Vector3.new(0, v38, 0)).Unit
	local v40
	if p31.winds then
		local v41
		v41, v40 = v_u_6.DrawnShot(v35, p32)
	else
		v40 = v_u_6.ShotSpeed(v35)
	end
	return v36, v39, v40
end
function v_u_7.HasCharge(p42) -- name: HasCharge
	return p42.maxCharges <= 0 and true or p42.charges >= 1
end
function v_u_7.NoneLeft(p43) -- name: NoneLeft
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v44 = os.clock()
	if v44 - (p43.lastDry or 0) > 0.4 then
		p43.lastDry = v44
		v_u_3.Sound("Dry_Fire", p43.ctx.root)
		v_u_4.Toast("NONE LEFT THIS ROUND", Color3.fromRGB(255, 110, 90), 1)
	end
end
function v_u_7.Start(p45) -- name: Start
	-- upvalues: (copy) v_u_3
	local v46 = p45.ctx
	local v47 = os.clock()
	if p45.winding or (v47 - p45.lastThrow < (p45.tuning.cooldown or 0.5) or not v_u_3.CanAct()) then
		return false
	end
	if not p45:HasCharge() then
		p45:NoneLeft()
		return false
	end
	p45.bufferedAt = nil
	p45.winding = true
	p45.start = v47
	v46.send("Charge", {
		["tool"] = nil,
		["kind"] = "Throw",
		["on"] = true,
		["tool"] = v46.tool
	})
	v46.emit("Windup", {
		["on"] = true,
		["time"] = nil,
		["time"] = p45.tuning.drawTime or 0.5
	})
	v_u_3.PlayHold(v46.animator, p45.preset.windup, 1)
	v_u_3.Sound(p45.preset.windupSound or "Throw_Windup", v46.root)
	p45:StartLoop(p45.preset.fuseLoop)
	v46.setSpeed("Throw", p45.tuning.drawSpeedMult or 0.8)
	return true
end
function v_u_7.Cancel(p48) -- name: Cancel
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5
	local v49 = p48.ctx
	p48.winding = false
	v49.send("Charge", {
		["tool"] = nil,
		["kind"] = "Throw",
		["on"] = false,
		["tool"] = v49.tool
	})
	v49.emit("Windup", {
		["on"] = false
	})
	v_u_3.StopAnim(v49.animator, p48.preset.windup, 0.1)
	v49.setSpeed("Throw", nil)
	v_u_4.SetCharge(0)
	v_u_5.Trajectory(nil)
	p48:StopLoop()
end
function v_u_7.Release(p50, p51) -- name: Release
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_5, (copy) v_u_4
	local v52 = p50.ctx
	local v53 = p50.tuning
	local v54, v55, v56 = p50:Launch(p51, true)
	p50.lastThrow = os.clock()
	v52.emit("Throw", {
		["charge"] = p51
	})
	v_u_3.FaceCamera()
	if p50.preset.windup then
		v_u_3.StopAnim(v52.animator, p50.preset.windup, 0.04)
	end
	v_u_3.PlayAnim(v52.animator, p50.preset.throw, p50.preset.throwAnimSpeed or 1.3, 0.03)
	local v57 = v52.nextId()
	local v58
	if v53.splash or (v53.smoke or v53.caltrops) then
		v58 = nil
	else
		local v59
		if p50.winds then
			v59 = v_u_6.DrawnShot(v53, p51)
		else
			v59 = v53.damage
		end
		v58 = {
			["damage"] = v59 * v_u_3.ItemBonus(v52.weaponId),
			["tuning"] = v53
		}
	end
	local v60 = v53.returns
	if type(v60) == "table" then
		v_u_5.Chakram(v_u_5.MyKey(v57), v54, v55, v56, v53.returns.range or 45, v53.returns.catch or 4.5, v52.char)
	else
		v_u_5.Projectile(v_u_5.MyKey(v57), v53.projectile or "Javelin", v54, v55 * v56, v53.gravity or 60, v52.char, v58)
	end
	v52.send("Shoot", {
		["tool"] = v52.tool,
		["origin"] = v54,
		["dir"] = v55,
		["id"] = v57,
		["charge"] = p51
	})
	v_u_3.Sound(p50.preset.throwSound or "Throw", v52.root)
	if p50.kind == "Bomb" then
		p50:StopLoop()
	end
	v_u_3.Recoil(p50.preset.recoil or (p50.kind == "Javelin" and 2 or 1), 0)
	if p50.preset.shake then
		v_u_3.Shake(p50.preset.shake, 0.16)
	end
	v_u_4.Kick(p50.preset.recoil and 7 or 4)
	if p50.maxCharges > 0 then
		local v61 = p50.charges - 1
		p50.charges = math.max(0, v61)
		v_u_4.SetPips(p50.charges, p50.maxCharges)
	end
	if p50.kind == "Bomb" then
		v_u_4.SetArc(v53.cooldown or 0.6, Color3.fromRGB(228, 232, 240))
	end
end
function v_u_7.Quick(p62) -- name: Quick
	-- upvalues: (copy) v_u_3
	local v63 = os.clock()
	if (p62.tuning.fireInterval or (p62.tuning.cooldown or 0.4)) > v63 - p62.lastThrow then
		return "cooldown"
	elseif v_u_3.CanAct() then
		if p62:HasCharge() then
			p62.bufferedAt = nil
			p62:Release(1)
			return "fired"
		else
			p62.lastThrow = v63
			p62:NoneLeft()
			return "empty"
		end
	else
		return "frozen"
	end
end
function v_u_7.Throw(p64) -- name: Throw
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5
	if p64.winding then
		if v_u_3.CanAct() then
			local v65 = p64:Charge()
			local v66 = p64.tuning.minCharge
			if type(v66) == "number" and v65 < v66 then
				p64:Cancel()
				local v67 = os.clock()
				if v67 - (p64.lastShort or 0) > 1.5 then
					p64.lastShort = v67
					v_u_4.Toast("HOLD TO WIND UP", Color3.fromRGB(226, 196, 140), 1)
				end
			else
				p64.winding = false
				p64.ctx.setSpeed("Throw", nil)
				v_u_4.SetCharge(0)
				v_u_5.Trajectory(nil)
				p64:Release(v65)
			end
		else
			p64:Cancel()
			return
		end
	else
		return
	end
end
function v_u_7.Input(p68, p69, p70) -- name: Input
	-- upvalues: (copy) v_u_3, (copy) v_u_5
	if p69 == "Primary" then
		p68.m1Down = p70
		if not p68.winds then
			if p70 and p68:Quick() == "cooldown" then
				p68.bufferedAt = os.clock()
			end
			if p68.kind == "Sling" then
				if p70 then
					p68:StartLoop(p68.preset.whirlLoop)
					return
				end
				p68:StopLoop()
			end
			return
		end
		if not p70 then
			p68:Throw()
			return
		end
		if not (p68:Start() or p68.winding) then
			p68.bufferedAt = os.clock()
			return
		end
	elseif p69 == "Secondary" then
		if p68.winds then
			if p70 and p68.winding then
				p68:Cancel()
				return
			end
		else
			p68.preview = p70
			v_u_3.SetAiming(p70, p68.kind == "Sling" and 58 or 55)
			p68.ctx.setSpeed("Aim", p70 and 0.85 or nil)
			if not p70 then
				v_u_5.Trajectory(nil)
			end
		end
	end
end
function v_u_7.Update(p71, _) -- name: Update
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	if p71.kind == "Sling" and (p71.m1Down and not p71.bufferedAt) then
		p71:Quick()
	end
	if p71.bufferedAt then
		if p71.winds then
			if not p71.winding then
				if p71.m1Down or os.clock() - p71.bufferedAt <= 0.15 then
					if p71:Start() and not p71.m1Down then
						p71:Throw()
					end
				else
					p71.bufferedAt = nil
				end
			end
		elseif os.clock() - p71.bufferedAt > 0.15 then
			p71.bufferedAt = nil
		elseif p71:Quick() ~= "cooldown" then
			p71.bufferedAt = nil
		end
	end
	if p71.winding then
		local v72 = p71:Charge()
		v_u_4.SetCharge(v72)
		local v73, v74, v75 = p71:Launch(v72)
		local v76 = p71.tuning
		local v77
		if v76.splash then
			v77 = v76.splash.radius * 2
		elseif v76.smoke then
			v77 = v76.smoke.radius * 1.2
		else
			v77 = not v76.caltrops and 3 or v76.caltrops.radius * 2
		end
		local v78
		if v76.smoke then
			v78 = p71.preset.arcSmoke
		else
			v78 = p71.preset.arc
		end
		v_u_5.Trajectory(v73, v74 * v75, v76.gravity or 60, v78, v77)
	elseif p71.preview and p71.kind == "Sling" then
		local v79, v80, v81 = p71:Launch(1)
		v_u_5.Trajectory(v79, v80 * v81, p71.tuning.gravity or 80, Color3.fromRGB(215, 195, 160), 2)
	end
end
function v_u_7.Interrupt(p82) -- name: Interrupt
	if p82.winding then
		p82:Cancel()
	end
end
return v_u_7