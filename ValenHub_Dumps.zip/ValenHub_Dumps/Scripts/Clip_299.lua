local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1:WaitForChild("Shared"):WaitForChild("ReplayCodec"))
local v_u_83 = {
	["Decode"] = function(p3) -- name: Decode
		-- upvalues: (copy) v_u_2, (copy) v_u_83
		if typeof(p3) ~= "buffer" or buffer.len(p3) < 32 then
			return nil, "empty clip"
		end
		local v4 = v_u_2.Reader(p3)
		if v_u_2.RU32(v4) ~= v_u_2.MAGIC then
			return nil, "not a clip"
		end
		local v5 = v_u_2.RU8(v4)
		if v5 ~= v_u_2.VERSION or v_u_2.SAMPLE_BYTES ~= 27 then
			return nil, ("clip version %* (expected %*)"):format(v5, v_u_2.VERSION)
		end
		local v6 = v_u_2.RF32(v4)
		local v7 = v_u_2.RF32(v4)
		local v8 = v_u_2.RV3(v4)
		local v9 = v_u_2.RU8(v4)
		local v10 = v_u_2.RU8(v4)
		local v11 = {}
		for v12 = 1, v10 do
			v11[v12] = {
				["index"] = nil,
				["id"] = nil,
				["name"] = nil,
				["team"] = nil,
				["left"] = nil,
				["n"] = 0,
				["t"] = nil,
				["px"] = nil,
				["py"] = nil,
				["pz"] = nil,
				["rx"] = nil,
				["ry"] = nil,
				["rz"] = nil,
				["vx"] = nil,
				["vy"] = nil,
				["vz"] = nil,
				["item"] = nil,
				["hp"] = nil,
				["armor"] = nil,
				["flags"] = nil,
				["cursor"] = 1,
				["kn"] = 0,
				["kt"] = nil,
				["kyaw"] = nil,
				["kpitch"] = nil,
				["kfov"] = nil,
				["kflags"] = nil,
				["kcursor"] = 1,
				["grid"] = nil,
				["gcursor"] = 1,
				["index"] = v12,
				["id"] = v_u_2.RStr(v4),
				["name"] = v_u_2.RStr(v4),
				["team"] = v_u_2.RU8(v4),
				["left"] = v_u_2.RU8(v4) == 1,
				["t"] = {},
				["px"] = {},
				["py"] = {},
				["pz"] = {},
				["rx"] = {},
				["ry"] = {},
				["rz"] = {},
				["vx"] = {},
				["vy"] = {},
				["vz"] = {},
				["item"] = {},
				["hp"] = {},
				["armor"] = {},
				["flags"] = {},
				["kt"] = {},
				["kyaw"] = {},
				["kpitch"] = {},
				["kfov"] = {},
				["kflags"] = {}
			}
		end
		local v13 = {}
		local v14 = {}
		for v15 = 1, v_u_2.RU8(v4) do
			v13[v15] = v_u_2.RStr(v4)
		end
		local v16 = {}
		for v17 = 1, v_u_2.RU8(v4) do
			v16[v17] = v_u_2.RStr(v4)
		end
		local v18 = v_u_2.RStr(v4)
		local v19 = v_u_2.RU8(v4)
		local v20 = v_u_2.RU8(v4)
		local v21 = v_u_2.RU32(v4)
		local v22 = v4.pos + v21
		local v23 = v4.len
		local v24 = math.min(v22, v23)
		local v25 = v4.buf
		local v26 = 1 / v_u_2.POS_Q
		local v27 = 1 / v_u_2.ROT_Q
		local v28 = 1 / v_u_2.VEL_Q
		local v29 = 1 / v_u_2.HP_Q
		local v30 = {}
		while v4.pos + v_u_2.RECORD_HEADER <= v24 do
			local _ = v4.pos
			local v31 = v_u_2.RU8(v4)
			local v32 = v_u_2.RU16(v4) / 1000 - v7
			local v33 = v_u_2.RU16(v4)
			local v34 = v4.pos + v33
			if v24 < v34 then
				break
			end
			if v31 == v_u_2.REC_FRAME then
				local v35 = v_u_2.RU16(v4)
				for v36 = 1, v10 do
					local v37 = v36 - 1
					local v38 = bit32.lshift(1, v37)
					if not bit32.btest(v35, v38) then
						continue
					end
					if v34 < v4.pos + v_u_2.SAMPLE_BYTES then
						break
					end
					local v39 = v11[v36]
					local v40 = v39.n + 1
					v39.n = v40
					local v41 = v4.pos
					v39.t[v40] = v32
					v39.px[v40] = buffer.readi16(v25, v41) * v26
					local v42 = v39.py
					local v43 = v41 + 2
					v42[v40] = buffer.readi16(v25, v43) * v26
					local v44 = v39.pz
					local v45 = v41 + 4
					v44[v40] = buffer.readi16(v25, v45) * v26
					local v46 = v39.rx
					local v47 = v41 + 6
					v46[v40] = buffer.readi16(v25, v47) * v27
					local v48 = v39.ry
					local v49 = v41 + 8
					v48[v40] = buffer.readi16(v25, v49) * v27
					local v50 = v39.rz
					local v51 = v41 + 10
					v50[v40] = buffer.readi16(v25, v51) * v27
					local v52 = v39.vx
					local v53 = v41 + 12
					v52[v40] = buffer.readi16(v25, v53) * v28
					local v54 = v39.vy
					local v55 = v41 + 14
					v54[v40] = buffer.readi16(v25, v55) * v28
					local v56 = v39.vz
					local v57 = v41 + 16
					v56[v40] = buffer.readi16(v25, v57) * v28
					local v58 = v39.item
					local v59 = v41 + 18
					v58[v40] = buffer.readu8(v25, v59)
					local v60 = v39.hp
					local v61 = v41 + 19
					v60[v40] = buffer.readu8(v25, v61) * v29
					local v62 = v39.armor
					local v63 = v41 + 20
					v62[v40] = buffer.readu8(v25, v63)
					local v64 = v41 + 21
					local v65 = buffer.readu8(v25, v64)
					v39.flags[v40] = v65
					local v66 = v41 + 22
					local v67 = buffer.readi16(v25, v66)
					local v68 = v41 + 24
					local v69 = buffer.readi16(v25, v68)
					local v70 = v41 + 26
					local v71 = buffer.readu8(v25, v70)
					local v72 = v_u_2.F_VIEW + v_u_2.F_FIRST + v_u_2.F_AIMCAM
					local v73 = bit32.band(v65, v72)
					local v74 = v14[v36]
					if not v74 or (v74[1] ~= v67 or (v74[2] ~= v69 or (v74[3] ~= v71 or v74[4] ~= v73))) then
						v14[v36] = {
							v67,
							v69,
							v71,
							v73
						}
						local v75 = v39.kn + 1
						v39.kn = v75
						v39.kt[v75] = v32
						v39.kyaw[v75] = v67 * v27
						v39.kpitch[v75] = v69 * v27
						v39.kfov[v75] = bit32.band(v71, 127)
						v39.kflags[v75] = v73 + (v71 >= 128 and 256 or 0)
					end
					v4.pos = v41 + v_u_2.SAMPLE_BYTES
				end
			elseif v31 == v_u_2.REC_EVENT then
				local v76 = v13[v_u_2.RU8(v4)]
				local v77 = {}
				for _ = 1, v_u_2.RU8(v4) do
					if v34 <= v4.pos then
						break
					end
					local v78 = v13[v_u_2.RU8(v4)]
					local v79 = v_u_2.ReadValue(v4)
					if not v78 then
						continue
					end
					v77[v78] = v79
				end
				if v76 then
					table.insert(v30, {
						["t"] = v32,
						["kind"] = v76,
						["data"] = v77
					})
				end
			end
			v4.pos = v34
		end
		table.sort(v30, function(p80, p81)
			return p80.t < p81.t
		end)
		local v82 = v11[v9]
		if v82 then
			v_u_83.BuildViewGrid(v82)
		end
		return {
			["duration"] = v6,
			["preroll"] = v7,
			["origin"] = v8,
			["focus"] = v9,
			["fighters"] = v11,
			["events"] = v30,
			["items"] = v16,
			["title"] = v18,
			["kills"] = v19,
			["headshots"] = v20,
			["bytes"] = buffer.len(p3)
		}, nil
	end,
	["NewState"] = function() -- name: NewState
		return {
			["present"] = false,
			["cf"] = nil,
			["vel"] = Vector3.new(0, 0, 0),
			["item"] = 0,
			["hp"] = 0,
			["armor"] = 0,
			["flags"] = 0,
			["view"] = false,
			["viewYaw"] = 0,
			["viewPitch"] = 0,
			["fov"] = 70,
			["first"] = false,
			["aimCam"] = false,
			["bobbing"] = false,
			["cf"] = CFrame.identity
		}
	end,
	["LinearView"] = false
}
local function v_u_89(p84, p85) -- name: keyAt
	local v86 = p84.kn
	if v86 == 0 or p85 < p84.kt[1] then
		return 0
	end
	local v87 = p84.kt
	local v88 = p84.kcursor
	if v86 < v88 or p85 < v87[v88] then
		v88 = 1
	end
	while v88 < v86 and v87[v88 + 1] <= p85 do
		v88 = v88 + 1
	end
	p84.kcursor = v88
	return v88
end
local function v_u_109(p90, p91, p92) -- name: rampAt
	-- upvalues: (copy) v_u_2
	local v93 = p90.kyaw[p91]
	local v94 = p90.kpitch[p91]
	local v95 = p90.kfov[p91]
	local v96 = p91 + 1
	if v96 <= p90.kn then
		local v97 = p90.kflags[v96]
		local v98 = v_u_2.F_VIEW
		if bit32.btest(v97, v98) then
			local v99 = p90.kflags[p91]
			local v100 = v_u_2.F_VIEW
			if bit32.btest(v99, v100) then
				local v101 = p90.kt[v96]
				local v102 = p90.kt[p91]
				local v103 = v101 - 0.1
				local v104 = math.max(v102, v103)
				if v104 < p92 then
					local v105 = p92 - v104
					local v106 = v101 - v104
					local v107 = v105 / math.max(v106, 0.001)
					local v108 = math.clamp(v107, 0, 1)
					v93 = v93 + ((p90.kyaw[v96] - v93 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793) * v108
					v94 = v94 + (p90.kpitch[v96] - v94) * v108
					v95 = v95 + (p90.kfov[v96] - v95) * v108
				end
			end
		end
	end
	return v93, v94, v95
end
local v_u_110 = {
	0.0038659201394728076,
	0.014214791206736984,
	0.0439369336234074,
	0.11416176000968695,
	0.24935220877729622,
	0.4578333617716142,
	0.7066482778577162,
	0.9168553557320289,
	1,
	0.9168553557320289,
	0.7066482778577162,
	0.4578333617716142,
	0.24935220877729622,
	0.11416176000968695,
	0.0439369336234074,
	0.014214791206736984,
	0.0038659201394728076
}
local function v_u_122(p111, p112, p113) -- name: smoothInto
	-- upvalues: (copy) v_u_110
	for v114 = 1, p112 do
		local v115 = v114 - 8
		local v116 = math.max(1, v115)
		local v117 = v114 + 8
		local v118 = 0
		local v119 = 0
		for v120 = v116, math.min(p112, v117) do
			local v121 = v_u_110[v120 - v114 + 8 + 1]
			v118 = v118 + v121
			v119 = v119 + v121 * p111[v120]
		end
		p113[v114] = v119 / v118
	end
end
function v_u_83.BuildViewGrid(p123) -- name: BuildViewGrid
	-- upvalues: (copy) v_u_2, (copy) v_u_109, (copy) v_u_122
	local v124 = p123.kn
	local v125 = 1
	local v126 = {}
	while true do
		while true do
			if v125 > v124 then
				p123.grid = v126
				p123.gcursor = 1
				return
			end
			local v127 = p123.kflags[v125]
			local v128 = v_u_2.F_VIEW
			if not bit32.btest(v127, v128) then
				break
			end
			local v129 = v125
			while v125 + 1 <= v124 do
				local v130 = p123.kflags[v125 + 1]
				local v131 = v_u_2.F_VIEW
				if not bit32.btest(v130, v131) then
					break
				end
				v125 = v125 + 1
			end
			local v132 = p123.kt[v129]
			local v133
			if v125 < v124 then
				v133 = p123.kt[v125 + 1]
			else
				local v134 = (p123.t[p123.n] or v132) + 0.05
				v133 = math.max(v132, v134)
			end
			local v135 = (v133 - v132) / 0.016666666666666666
			local v136 = math.floor(v135) + 2
			local v137 = math.max(1, v136)
			local v138 = table.create(v137, 0)
			local v139 = table.create(v137, 0)
			local v140 = table.create(v137, 0)
			local v141 = 0
			for v142 = 1, v137 do
				local v143 = v132 + (v142 - 1) * 0.016666666666666666
				while v129 < v125 and p123.kt[v129 + 1] <= v143 do
					v129 = v129 + 1
				end
				local v144, v145, v146 = v_u_109(p123, v129, v143)
				if v142 > 1 then
					v141 = v141 + ((v144 - v141 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793)
				else
					v141 = v144
				end
				v138[v142] = v141
				v139[v142] = v145
				v140[v142] = v146
			end
			local v147 = {
				["t0"] = nil,
				["t1"] = nil,
				["dt"] = 0.016666666666666666,
				["n"] = nil,
				["yaw"] = nil,
				["pitch"] = nil,
				["fov"] = nil,
				["t0"] = v132,
				["t1"] = v133,
				["n"] = v137,
				["yaw"] = table.create(v137, 0),
				["pitch"] = table.create(v137, 0),
				["fov"] = table.create(v137, 0)
			}
			v_u_122(v138, v137, v147.yaw)
			v_u_122(v139, v137, v147.pitch)
			v_u_122(v140, v137, v147.fov)
			table.insert(v126, v147)
			v125 = v125 + 1
		end
		v125 = v125 + 1
	end
end
local function v_u_159(p148, p149, p150, p151) -- name: catmull
	local v152 = p150 - 1
	local v153 = p148[math.max(1, v152)]
	local v154 = p148[p150]
	local v155 = p150 + 1
	local v156 = p148[math.min(p149, v155)]
	local v157 = p150 + 2
	local v158 = p148[math.min(p149, v157)]
	return (v154 * 2 + (v156 - v153) * p151 + (v153 * 2 - v154 * 5 + v156 * 4 - v158) * p151 * p151 + (v154 * 3 - v153 - v156 * 3 + v158) * p151 * p151 * p151) * 0.5
end
local function v_u_182(p160, p161, p162) -- name: sampleView
	-- upvalues: (copy) v_u_89, (copy) v_u_2, (copy) v_u_83, (copy) v_u_159, (copy) v_u_109
	local v163 = v_u_89(p160, p161)
	if v163 == 0 then
		p162.view = false
	else
		local v164 = p160.kflags[v163]
		local v165 = v_u_2.F_VIEW
		p162.view = bit32.btest(v164, v165)
		local v166 = v_u_2.F_FIRST
		p162.first = bit32.btest(v164, v166)
		local v167 = v_u_2.F_AIMCAM
		p162.aimCam = bit32.btest(v164, v167)
		p162.bobbing = bit32.btest(v164, 256)
		local v168 = p160.grid
		if v168 and (p162.view and not v_u_83.LinearView) then
			local v169 = p160.gcursor
			local v170 = v168[v169]
			if not v170 or p161 < v170.t0 then
				v170 = v168[1]
				v169 = 1
			end
			while v170 and (v170.t1 < p161 and v169 < #v168) do
				v169 = v169 + 1
				v170 = v168[v169]
			end
			p160.gcursor = v169
			if v170 and (v170.t0 <= p161 and p161 <= v170.t1 + 0.016666666666666666) then
				local v171 = (p161 - v170.t0) / v170.dt
				local v172 = math.floor(v171) + 1
				local v173 = v170.n
				local v174 = math.clamp(v172, 1, v173)
				local v175 = v171 - (v174 - 1)
				local v176 = math.clamp(v175, 0, 1)
				local v177 = v_u_159(v170.fov, v170.n, v174, v176)
				p162.viewYaw = (v_u_159(v170.yaw, v170.n, v174, v176) + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
				p162.viewPitch = v_u_159(v170.pitch, v170.n, v174, v176)
				p162.fov = v177 < 20 and 70 or v177
				return
			end
		end
		local v178, v179, v180 = v_u_109(p160, v163, p161)
		local v181 = v180 < 20 and 70 or v180
		p162.viewYaw = v178
		p162.viewPitch = v179
		p162.fov = v181
	end
end
local function v_u_186(p183, p184, p185) -- name: cfAt
	return CFrame.new(p185.X + p183.px[p184], p185.Y + p183.py[p184], p185.Z + p183.pz[p184]) * CFrame.fromEulerAnglesYXZ(p183.rx[p184], p183.ry[p184], p183.rz[p184])
end
function v_u_83.Sample(p187, p188, p189, p190) -- name: Sample
	-- upvalues: (copy) v_u_186, (copy) v_u_182
	local v191 = p188.n
	if v191 == 0 then
		p190.present = false
		return
	else
		local v192 = p188.t
		local v193 = p188.cursor
		if v191 < v193 or p189 < v192[v193] then
			v193 = 1
		end
		while v193 < v191 and v192[v193 + 1] <= p189 do
			v193 = v193 + 1
		end
		p188.cursor = v193
		local v194 = p187.origin
		if p189 < v192[1] then
			if v192[1] - p189 > 0.3 then
				p190.present = false
				return
			end
			v193 = 1
		end
		local v195 = v192[v193]
		local v196 = v193 + 1
		if v191 < v196 or (v192[v196] - v195 > 0.3 or p189 < v195) then
			p190.present = p189 - v195 <= 0.3
			p190.cf = v_u_186(p188, v193, v194)
			local v197 = p188.vx[v193]
			local v198 = p188.vy[v193]
			local v199 = p188.vz[v193]
			p190.vel = Vector3.new(v197, v198, v199)
			local v200 = p188.item[v193]
			local v201 = p188.hp[v193]
			local v202 = p188.armor[v193]
			local v203 = p188.flags[v193]
			p190.item = v200
			p190.hp = v201
			p190.armor = v202
			p190.flags = v203
			v_u_182(p188, p189, p190)
		else
			local v204 = v192[v196] - v195
			local v205 = (p189 - v195) / v204
			local v206 = math.clamp(v205, 0, 1)
			local v207 = p188.px[v193]
			local v208 = p188.py[v193]
			local v209 = p188.pz[v193]
			local v210 = Vector3.new(v207, v208, v209)
			local v211 = p188.px[v196]
			local v212 = p188.py[v196]
			local v213 = p188.pz[v196]
			local v214 = Vector3.new(v211, v212, v213)
			local v215 = p188.vx[v193]
			local v216 = p188.vy[v193]
			local v217 = p188.vz[v193]
			local v218 = Vector3.new(v215, v216, v217)
			local v219 = p188.vx[v196]
			local v220 = p188.vy[v196]
			local v221 = p188.vz[v196]
			local v222 = Vector3.new(v219, v220, v221)
			if (v214 - v210).Magnitude > 12 then
				if v206 < 0.5 then
					v214 = v210
				end
			else
				local v223 = v206 * v206
				local v224 = v206 * v206 * v206
				local v225 = v224 * 2 - v223 * 3 + 1
				local v226 = v224 - v223 * 2 + v206
				local v227 = v224 * -2 + v223 * 3
				local v228 = v224 - v223
				v214 = v210 * v225 + v218 * (v226 * v204) + v214 * v227 + v222 * (v228 * v204)
			end
			local v229 = CFrame.fromEulerAnglesYXZ(p188.rx[v193], p188.ry[v193], p188.rz[v193])
			local v230 = CFrame.fromEulerAnglesYXZ(p188.rx[v196], p188.ry[v196], p188.rz[v196])
			p190.present = true
			p190.cf = CFrame.new(v194 + v214) * v229:Lerp(v230, v206)
			p190.vel = v218:Lerp(v222, v206)
			if v206 < 0.5 then
				v196 = v193
			end
			local v231 = p188.item[v196]
			local v232 = p188.hp[v196]
			local v233 = p188.armor[v196]
			local v234 = p188.flags[v196]
			p190.item = v231
			p190.hp = v232
			p190.armor = v233
			p190.flags = v234
			v_u_182(p188, p189, p190)
		end
	end
end
return v_u_83