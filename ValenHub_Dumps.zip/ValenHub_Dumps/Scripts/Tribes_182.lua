local v_u_24 = {
	["MAX_MEMBERS"] = 30,
	["FOUND_LEVEL"] = 10,
	["TAG_MIN"] = 2,
	["TAG_MAX"] = 4,
	["NAME_MIN"] = 3,
	["NAME_MAX"] = 20,
	["LEAVE_COOLDOWN"] = 1200,
	["RENOWN_WIN"] = 3,
	["RENOWN_LOSS"] = 1,
	["STACK_MULT"] = { 1, 1.5, 2 },
	["CHEST_TIERS"] = {
		40,
		150,
		400,
		900,
		1800
	},
	["CHEST_MIN"] = 25,
	["CHEST_TERRITORY_MAX"] = 3,
	["WEEK_EPOCH"] = 345600,
	["WEEK_LENGTH"] = 604800,
	["JOIN_MODES"] = { "open", "request", "invite" },
	["ICONS"] = {
		"wolf",
		"bear",
		"raven",
		"eagle",
		"serpent",
		"boar",
		"stag",
		"fox",
		"owl",
		"shark",
		"flame",
		"sun",
		"moon",
		"star",
		"bolt",
		"mountain",
		"wave",
		"tree",
		"crown",
		"swords",
		"axe",
		"bow",
		"shield",
		"gem",
		"lion",
		"dragon",
		"scorpion",
		"anchor",
		"bull",
		"octopus",
		"trident",
		"skull",
		"ram",
		"griffin",
		"claws"
	},
	["COLORS"] = {
		Color3.fromRGB(40, 150, 255),
		Color3.fromRGB(90, 200, 255),
		Color3.fromRGB(40, 190, 170),
		Color3.fromRGB(64, 200, 100),
		Color3.fromRGB(160, 210, 60),
		Color3.fromRGB(255, 205, 50),
		Color3.fromRGB(240, 160, 40),
		Color3.fromRGB(255, 120, 40),
		Color3.fromRGB(235, 60, 60),
		Color3.fromRGB(180, 30, 60),
		Color3.fromRGB(255, 100, 170),
		Color3.fromRGB(210, 70, 200),
		Color3.fromRGB(140, 90, 230),
		Color3.fromRGB(80, 90, 220),
		Color3.fromRGB(30, 50, 120),
		Color3.fromRGB(30, 110, 60),
		Color3.fromRGB(140, 90, 50),
		Color3.fromRGB(210, 180, 120),
		Color3.fromRGB(90, 105, 125),
		Color3.fromRGB(40, 44, 52),
		Color3.fromRGB(170, 178, 190),
		Color3.fromRGB(110, 30, 40),
		Color3.fromRGB(120, 230, 180),
		Color3.fromRGB(180, 140, 255),
		Color3.fromRGB(246, 248, 252)
	},
	["WHITE"] = 25,
	["Color"] = function(p1) -- name: Color
		-- upvalues: (copy) v_u_24
		return v_u_24.COLORS[type(p1) ~= "number" and 1 or p1] or v_u_24.COLORS[1]
	end,
	["TextColor"] = function(p2) -- name: TextColor
		-- upvalues: (copy) v_u_24
		local v3 = v_u_24.Color(p2)
		local _, _, v4 = v3:ToHSV()
		if v4 < 0.62 then
			return v3:Lerp(Color3.new(1, 1, 1), 0.45)
		else
			return v3
		end
	end,
	["Renown"] = function(p5, p6) -- name: Renown
		-- upvalues: (copy) v_u_24
		local v7
		if p5 then
			v7 = v_u_24.RENOWN_WIN
		else
			v7 = v_u_24.RENOWN_LOSS
		end
		local v8 = v_u_24.STACK_MULT
		local v9 = math.floor(p6)
		local v10 = v7 * v8[math.clamp(v9, 1, 3)] + 0.5
		return math.floor(v10)
	end,
	["ChestTier"] = function(p11) -- name: ChestTier
		-- upvalues: (copy) v_u_24
		local v12 = 0
		for v13, v14 in v_u_24.CHEST_TIERS do
			if v14 > p11 then
				continue
			end
			v12 = v13
		end
		return v12
	end,
	["WeekOf"] = function(p15) -- name: WeekOf
		-- upvalues: (copy) v_u_24
		local v16 = (p15 - v_u_24.WEEK_EPOCH) / v_u_24.WEEK_LENGTH
		return math.floor(v16)
	end,
	["WeekEndsAt"] = function(p17) -- name: WeekEndsAt
		-- upvalues: (copy) v_u_24
		return v_u_24.WEEK_EPOCH + (p17 + 1) * v_u_24.WEEK_LENGTH
	end,
	["CleanTag"] = function(p18) -- name: CleanTag
		return string.upper((string.gsub(p18, "%s", "")))
	end,
	["ValidTag"] = function(p19) -- name: ValidTag
		-- upvalues: (copy) v_u_24
		local v20
		if #p19 >= v_u_24.TAG_MIN and #p19 <= v_u_24.TAG_MAX then
			v20 = string.match(p19, "^[A-Z0-9]+$") ~= nil
		else
			v20 = false
		end
		return v20
	end,
	["CleanName"] = function(p21) -- name: CleanName
		local v22 = string.gsub(p21, "%s+", " ")
		return string.match(v22, "^%s*(.-)%s*$") or v22
	end,
	["ValidName"] = function(p23) -- name: ValidName
		-- upvalues: (copy) v_u_24
		if #p23 < v_u_24.NAME_MIN or #p23 > v_u_24.NAME_MAX then
			return false
		else
			return string.match(p23, "^[%w][%w \'%.%-]*[%w%.\']$") ~= nil
		end
	end
}
local v_u_25 = {
	["level"] = nil,
	["bad_tag"] = nil,
	["bad_name"] = nil,
	["filtered"] = "That isn\'t allowed. Try something else.",
	["tag_taken"] = "That tag is taken.",
	["in_tribe"] = "Leave your tribe first.",
	["cooldown"] = "You left a tribe a moment ago. You can join another in a few minutes.",
	["not_found"] = "That tribe doesn\'t exist any more.",
	["full"] = nil,
	["min_level"] = "Your level is below that tribe\'s minimum.",
	["invite_only"] = "That tribe is invite only.",
	["requests_full"] = "That tribe has too many requests waiting. Try again later.",
	["invites_full"] = "Your tribe has too many invites waiting.",
	["not_member"] = "You\'re not in that tribe.",
	["no_permission"] = "Your rank can\'t do that.",
	["no_request"] = "That request is gone.",
	["target_in_tribe"] = "They\'re already in a tribe.",
	["bad_target"] = "You can\'t do that.",
	["unavailable"] = "Tribes are unavailable right now. Try again soon.",
	["busy"] = "One moment.",
	["lobby_only"] = "Do that from the lobby.",
	["offline"] = "They\'re not in a lobby right now.",
	["level"] = ("Reach level %* to found a tribe."):format(v_u_24.FOUND_LEVEL),
	["bad_tag"] = ("Tags are %* to %* letters or numbers."):format(v_u_24.TAG_MIN, v_u_24.TAG_MAX),
	["bad_name"] = ("Names are %* to %* letters, numbers or spaces."):format(v_u_24.NAME_MIN, v_u_24.NAME_MAX),
	["full"] = ("That tribe is full (%* members)."):format(v_u_24.MAX_MEMBERS)
}
function v_u_24.Message(p26) -- name: Message
	-- upvalues: (copy) v_u_25
	return v_u_25[p26] or "Something went wrong. Try again."
end
return v_u_24