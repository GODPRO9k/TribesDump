local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v5 = {}
local v_u_6 = v_u_2.LocalPlayer
local v_u_7 = require(script.Parent.HudBridge)
local v_u_8 = {
	["TR_Replay"] = true,
	["TR_ReplayHud"] = true,
	["TR_ReplayFrame"] = true,
	["TR_Loading"] = true,
	["CombatHUD"] = true,
	["CombatTouch"] = true,
	["CharacterTouch"] = true
}
local v_u_9 = nil
local v_u_10 = nil
task.spawn(function()
	-- upvalues: (copy) v_u_3, (ref) v_u_9, (ref) v_u_10
	local v11 = v_u_3:WaitForChild("Shared")
	local v12 = v11:WaitForChild("Camera", 15)
	if v12 and v12:IsA("ModuleScript") then
		local v13 = require
		local v14, v15 = pcall(v13, v12)
		if v14 and type(v15) == "table" then
			v_u_9 = v15
		end
	end
	local v16 = v11:WaitForChild("Sfx", 15)
	if v16 and v16:IsA("ModuleScript") then
		local v17 = require
		local v18, v19 = pcall(v17, v16)
		if v18 and type(v19) == "table" then
			v_u_10 = v19
		end
	end
end)
local v_u_20 = nil
local function v_u_25(p21, p22) -- name: addHidden
	if p22:IsA("BasePart") or p22:IsA("Decal") then
		local v23 = p21.hidden
		table.insert(v23, p22)
		p22.LocalTransparencyModifier = 1
	elseif p22:IsA("Highlight") and p22.Enabled then
		p22.Enabled = false
		local v24 = p21.highlights
		table.insert(v24, p22)
	end
end
local function v_u_33(p_u_26, p27) -- name: hideModel
	-- upvalues: (copy) v_u_25
	if not p_u_26.models[p27] then
		p_u_26.models[p27] = true
		for _, v28 in p27:GetDescendants() do
			v_u_25(p_u_26, v28)
		end
		local v29 = p_u_26.conns
		local v30 = p27.DescendantAdded
		local function v32(p31)
			-- upvalues: (ref) v_u_25, (copy) p_u_26
			v_u_25(p_u_26, p31)
		end
		table.insert(v29, v30:Connect(v32))
	end
end
local function v_u_40() -- name: realFighters
	-- upvalues: (copy) v_u_2, (copy) v_u_1, (copy) v_u_4
	local v34 = {}
	local v35 = {}
	for _, v36 in v_u_2:GetPlayers() do
		local v37 = v36.Character
		if not v37 or v34[v37] then
			continue
		end
		v34[v37] = true
		table.insert(v35, v37)
	end
	for _, v38 in { "Combatant", "Bot" } do
		for _, v39 in v_u_1:GetTagged(v38) do
			if not v39:IsA("Model") or (v34[v39] or not v39:IsDescendantOf(v_u_4)) then
				continue
			end
			v34[v39] = true
			table.insert(v35, v39)
		end
	end
	return v35
end
function v5.Active() -- name: Active
	-- upvalues: (ref) v_u_20
	return v_u_20 ~= nil
end
function v5.Enter(p41) -- name: Enter
	-- upvalues: (ref) v_u_20, (copy) v_u_4, (copy) v_u_6, (copy) v_u_8, (copy) v_u_7, (ref) v_u_9, (copy) v_u_40, (copy) v_u_33, (copy) v_u_1, (copy) v_u_2, (ref) v_u_10
	if not v_u_20 then
		local v42 = v_u_4.CurrentCamera
		local v_u_43 = {
			["guis"] = nil,
			["hidden"] = nil,
			["models"] = nil,
			["highlights"] = nil,
			["cameraType"] = nil,
			["fov"] = nil,
			["camEnabled"] = true,
			["conns"] = nil,
			["guis"] = {},
			["hidden"] = {},
			["models"] = {},
			["highlights"] = {},
			["cameraType"] = v42.CameraType,
			["fov"] = v42.FieldOfView,
			["conns"] = {}
		}
		v_u_20 = v_u_43
		v_u_6:SetAttribute("ReplayPlaying", true)
		local v44 = v_u_6:FindFirstChildOfClass("PlayerGui")
		if v44 then
			for _, v45 in v44:GetChildren() do
				local v46 = v_u_8[v45.Name]
				if not v46 then
					if v45.Name == "TR_HUD" then
						v46 = v_u_7.ui ~= nil
					else
						v46 = false
					end
				end
				if not v45:IsA("ScreenGui") or (not v45.Enabled or v46) then
					continue
				end
				v45.Enabled = false
				local v47 = v_u_43.guis
				table.insert(v47, v45)
			end
		end
		if v_u_9 then
			local function v48()
				-- upvalues: (copy) v_u_43, (ref) v_u_9
				v_u_43.camEnabled = v_u_9.IsEnabled()
				v_u_9.PushMouseUnlock("Replay")
				v_u_9.SetEnabled(false)
			end
			pcall(v48)
		end
		v42.CameraType = Enum.CameraType.Scriptable
		for _, v49 in v_u_40() do
			v_u_33(v_u_43, v49)
		end
		local v50 = v_u_43.conns
		local v51 = v_u_1:GetInstanceAddedSignal("Combatant")
		local function v53(p52)
			-- upvalues: (ref) v_u_20, (copy) v_u_43, (ref) v_u_33
			if v_u_20 == v_u_43 and p52:IsA("Model") then
				v_u_33(v_u_43, p52)
			end
		end
		table.insert(v50, v51:Connect(v53))
		for _, v54 in v_u_2:GetPlayers() do
			local v55 = v_u_43.conns
			local v56 = v54.CharacterAdded
			local function v58(p57)
				-- upvalues: (ref) v_u_20, (copy) v_u_43, (ref) v_u_33
				if v_u_20 == v_u_43 then
					v_u_33(v_u_43, p57)
				end
			end
			table.insert(v55, v56:Connect(v58))
		end
		if v_u_10 then
			local v59 = v_u_10.Duck
			pcall(v59, "Music", 0.35, p41)
			local v60 = v_u_10.Duck
			pcall(v60, "Ambient", 0.6, p41)
		end
	end
end
function v5.Tick() -- name: Tick
	-- upvalues: (ref) v_u_20
	local v61 = v_u_20
	if v61 then
		local v62 = v61.hidden
		local v63 = 1
		while v63 <= #v62 do
			local v64 = v62[v63]
			if v64.Parent == nil then
				v62[v63] = v62[#v62]
				v62[#v62] = nil
			else
				if v64.LocalTransparencyModifier ~= 1 then
					v64.LocalTransparencyModifier = 1
				end
				v63 = v63 + 1
			end
		end
	end
end
function v5.Leave() -- name: Leave
	-- upvalues: (ref) v_u_20, (copy) v_u_4, (ref) v_u_9, (copy) v_u_6
	local v_u_65 = v_u_20
	if v_u_65 then
		v_u_20 = nil
		for _, v66 in v_u_65.conns do
			v66:Disconnect()
		end
		for _, v67 in v_u_65.hidden do
			if not v67.Parent then
				continue
			end
			v67.LocalTransparencyModifier = 0
		end
		for _, v68 in v_u_65.highlights do
			if not v68.Parent then
				continue
			end
			v68.Enabled = true
		end
		for _, v69 in v_u_65.guis do
			if not v69.Parent then
				continue
			end
			v69.Enabled = true
		end
		local v70 = v_u_4.CurrentCamera
		v70.FieldOfView = v_u_65.fov
		if v_u_9 then
			local function v71()
				-- upvalues: (ref) v_u_9, (copy) v_u_65
				v_u_9.SetEnabled(v_u_65.camEnabled)
				v_u_9.PopMouseUnlock("Replay")
			end
			pcall(v71)
		end
		if not (v_u_9 and v_u_65.camEnabled) then
			v70.CameraType = v_u_65.cameraType
		end
		v_u_6:SetAttribute("ReplayPlaying", nil)
	end
end
return v5