local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("SoundService")
local v3 = require(v_u_1:WaitForChild("Shared"):WaitForChild("Signal"))
local v_u_4 = require(v_u_1.Shared:WaitForChild("Keybinds"))
local v_u_5 = {
	["Changed"] = v3.new(),
	["DEFAULTS"] = {
		["sensitivity"] = 1,
		["padSensitivity"] = 1,
		["padInvertY"] = 0,
		["fov"] = 70,
		["music"] = 0.6,
		["sfx"] = 1,
		["firstPerson"] = 0,
		["viewBobbing"] = 1,
		["friendsOnlyInvites"] = 0,
		["aimAssist"] = 1,
		["mmNoBots"] = 0,
		["mmAutoRegion"] = 1,
		["mmRegions"] = 0,
		["mmPremium"] = 0
	},
	["RANGES"] = {
		["sensitivity"] = { 0.05, 3 },
		["padSensitivity"] = { 0.2, 3 },
		["padInvertY"] = { 0, 1 },
		["fov"] = { 60, 100 },
		["music"] = { 0, 1 },
		["sfx"] = { 0, 1 },
		["firstPerson"] = { 0, 1 },
		["viewBobbing"] = { 0, 1 },
		["friendsOnlyInvites"] = { 0, 1 },
		["aimAssist"] = { 0, 1 },
		["mmNoBots"] = { 0, 1 },
		["mmAutoRegion"] = { 0, 1 },
		["mmRegions"] = { 0, 63 },
		["mmPremium"] = { 0, 1 }
	}
}
local v_u_6 = table.clone(v_u_5.DEFAULTS)
local v_u_7 = false
local v_u_8 = nil
local v_u_9 = {}
local function v_u_36(p10) -- name: apply
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_2, (copy) v_u_9
	local v11 = v_u_6[p10]
	if p10 == "sensitivity" or p10 == "fov" then
		local v12 = v_u_1.Shared:FindFirstChild("Camera")
		local v13
		if v12 and v12:IsA("ModuleScript") then
			local v14 = require
			local v15
			v15, v13 = pcall(v14, v12)
			if not v15 or type(v13) ~= "table" then
				v13 = nil
			end
		else
			v13 = nil
		end
		if v13 then
			if p10 == "sensitivity" then
				v13 = v13.SetSensitivity
			else
				v13 = v13.SetFOV
			end
		end
		if type(v13) == "function" then
			pcall(v13, v11)
			return
		end
		return
	elseif p10 == "padSensitivity" or p10 == "padInvertY" then
		local v16 = v_u_1.Shared:FindFirstChild("Camera")
		local v17
		if v16 and v16:IsA("ModuleScript") then
			local v18 = require
			local v19
			v19, v17 = pcall(v18, v16)
			if not v19 or type(v17) ~= "table" then
				v17 = nil
			end
		else
			v17 = nil
		end
		if v17 then
			v17 = v17.PadLook
		end
		if type(v17) == "table" then
			if p10 == "padSensitivity" then
				local v20 = v17.SetSensitivity
				pcall(v20, v11)
			else
				local v21 = v17.SetInvertY
				local v22 = v11 >= 0.5
				pcall(v21, v22)
			end
		end
		return
	elseif p10 == "firstPerson" or (p10 == "viewBobbing" or p10 == "aimAssist") then
		local v23 = v_u_1.Shared:FindFirstChild("Camera")
		local v24
		if v23 and v23:IsA("ModuleScript") then
			local v25 = require
			local v26
			v26, v24 = pcall(v25, v23)
			if not v26 or type(v24) ~= "table" then
				v24 = nil
			end
		else
			v24 = nil
		end
		if v24 then
			if p10 == "firstPerson" then
				v24 = v24.SetFirstPerson
			elseif p10 == "aimAssist" then
				v24 = v24.SetAimAssist
			else
				v24 = v24.SetViewBobbing
			end
		end
		if type(v24) == "function" then
			local v27 = v11 >= 0.5
			pcall(v24, v27)
			return
		end
		return
	elseif p10 == "music" or p10 == "sfx" then
		local v28 = v_u_1.Shared:FindFirstChild("Sfx")
		local v29
		if v28 and v28:IsA("ModuleScript") then
			local v30 = require
			local v31
			v31, v29 = pcall(v30, v28)
			if not v31 or type(v29) ~= "table" then
				v29 = nil
			end
		else
			v29 = nil
		end
		for _, v32 in p10 == "music" and { "Music" } or { "SFX", "UI", "Ambient" } do
			local v33
			if v29 then
				local v34 = v29.SetVolume
				if type(v34) == "function" then
					local v35 = v29.SetVolume
					pcall(v35, v32, v11)
				else
					v33 = v_u_2:FindFirstChild(v32)
					if not (v33 and v33:IsA("SoundGroup")) then
						continue
					end
					if not v_u_9[v33] then
						v_u_9[v33] = v33.Volume
					end
					v33.Volume = v_u_9[v33] * v11
				end
			else
				v33 = v_u_2:FindFirstChild(v32)
				if not (v33 and v33:IsA("SoundGroup")) then
					continue
				end
				if not v_u_9[v33] then
					v_u_9[v33] = v33.Volume
				end
				v33.Volume = v_u_9[v33] * v11
			end
		end
	end
end
function v_u_5.Get(p37) -- name: Get
	-- upvalues: (copy) v_u_6, (copy) v_u_5
	return v_u_6[p37] or v_u_5.DEFAULTS[p37] or 0
end
local v_u_38 = {}
function v_u_5.Set(p_u_39, p40, p41) -- name: Set
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_36, (ref) v_u_8, (copy) v_u_38
	local v42 = v_u_5.RANGES[p_u_39]
	if v42 then
		local v43 = v42[1]
		local v44 = v42[2]
		p40 = math.clamp(p40, v43, v44)
	end
	v_u_6[p_u_39] = p40
	v_u_36(p_u_39)
	v_u_5.Changed:Fire(p_u_39, p40)
	if p41 and v_u_8 then
		v_u_38[p_u_39] = (v_u_38[p_u_39] or 0) + 1
		local v_u_45 = v_u_38[p_u_39]
		task.delay(0.8, function()
			-- upvalues: (ref) v_u_38, (copy) p_u_39, (copy) v_u_45, (ref) v_u_8, (ref) v_u_6
			if v_u_38[p_u_39] == v_u_45 and not v_u_8.State.Mock then
				local v46 = v_u_8.Remotes.Invoke
				local v47 = p_u_39
				local v48 = v_u_6[p_u_39] * 1000 + 0.5
				v46("ProfileAction", "SetSetting", v47, math.floor(v48) / 1000)
			end
		end)
	end
end
local v_u_49 = {}
local v_u_50 = false
local v_u_51 = (-1 / 0)
local function v_u_60() -- name: flushKeybinds
	-- upvalues: (ref) v_u_50, (ref) v_u_8, (copy) v_u_49, (ref) v_u_51, (copy) v_u_60, (copy) v_u_4
	v_u_50 = false
	if v_u_8 and (not v_u_8.State.Mock and next(v_u_49) ~= nil) then
		local v52 = 2.2 - (os.clock() - v_u_51)
		if v52 > 0 then
			v_u_50 = true
			task.delay(v52, v_u_60)
		else
			local v53 = {}
			local v54 = {}
			for v55 in v_u_49 do
				v53[v55] = v_u_4.SettingValueFor(v55)
				table.insert(v54, v55)
				if #v54 < 24 then
					continue
				end
			end
			for _, v56 in v54 do
				v_u_49[v56] = nil
			end
			v_u_51 = os.clock()
			local v57, v58 = v_u_8.Remotes.Invoke("ProfileAction", "SetSettings", v53)
			if next(v_u_49) ~= nil and not v_u_50 then
				v_u_50 = true
				task.delay(2.3, v_u_60)
			end
			if not v57 or v58 ~= true then
				for _, v59 in v54 do
					v_u_49[v59] = true
				end
				if not v_u_50 then
					v_u_50 = true
					task.delay(3, v_u_60)
				end
			end
		end
	else
		table.clear(v_u_49)
		return
	end
end
local v_u_61 = (-1 / 0)
function v_u_5.SaveKeybinds(p62) -- name: SaveKeybinds
	-- upvalues: (copy) v_u_4, (ref) v_u_61, (copy) v_u_49, (ref) v_u_50, (copy) v_u_60
	local v63 = v_u_4.PREFIX
	v_u_61 = os.clock()
	for _, v64 in p62 do
		v_u_49[v63 .. v64] = true
	end
	if not v_u_50 then
		v_u_50 = true
		task.delay(0.6, v_u_60)
	end
end
function v_u_5.SavePadBinds(p65) -- name: SavePadBinds
	-- upvalues: (copy) v_u_4, (ref) v_u_61, (copy) v_u_49, (ref) v_u_50, (copy) v_u_60
	local v66 = v_u_4.PAD_PREFIX
	v_u_61 = os.clock()
	for _, v67 in p65 do
		v_u_49[v66 .. v67] = true
	end
	if not v_u_50 then
		v_u_50 = true
		task.delay(0.6, v_u_60)
	end
end
function v_u_5.PendingKeys() -- name: PendingKeys
	-- upvalues: (copy) v_u_49
	local v68 = {}
	for v69 in v_u_49 do
		table.insert(v68, v69)
	end
	table.sort(v68)
	return v68
end
function v_u_5.Init(p70) -- name: Init
	-- upvalues: (ref) v_u_8, (ref) v_u_7, (copy) v_u_4, (copy) v_u_5, (copy) v_u_6, (copy) v_u_36, (copy) v_u_49, (ref) v_u_50, (ref) v_u_61, (copy) v_u_1
	v_u_8 = p70
	local function v76(p71) -- name: fromProfile
		-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_5, (ref) v_u_6, (ref) v_u_36
		if not v_u_7 and type(p71) == "table" then
			local v72 = p71.settings
			if type(v72) == "table" then
				v_u_7 = true
				v_u_4.Load(p71.settings)
				for v73 in v_u_5.DEFAULTS do
					local v74 = p71.settings[v73]
					if type(v74) ~= "number" then
						continue
					end
					v_u_6[v73] = v74
				end
				for v75 in v_u_5.DEFAULTS do
					v_u_36(v75)
					v_u_5.Changed:Fire(v75, v_u_6[v75])
				end
				return
			end
		end
	end
	p70.State.ProfileChanged:Connect(v76)
	if p70.State.HasProfile then
		v76(p70.State.Profile)
	end
	p70.State.ProfileChanged:Connect(function(p77)
		-- upvalues: (ref) v_u_7, (ref) v_u_49, (ref) v_u_50, (ref) v_u_61, (ref) v_u_4
		if v_u_7 and type(p77) == "table" then
			local v78 = p77.settings
			if type(v78) == "table" and (next(v_u_49) == nil and (not v_u_50 and os.clock() - v_u_61 > 6)) then
				v_u_4.Load(p77.settings)
			end
		end
	end)
	local v79 = v_u_1.Shared:FindFirstChild("Camera")
	local v80
	if v79 and v79:IsA("ModuleScript") then
		local v81 = require
		local v82
		v82, v80 = pcall(v81, v79)
		if not v82 or type(v80) ~= "table" then
			v80 = nil
		end
	else
		v80 = nil
	end
	if v80 then
		local v83 = v80.FirstPersonChanged
		if typeof(v83) == "RBXScriptSignal" then
			v80.FirstPersonChanged:Connect(function(p84)
				-- upvalues: (ref) v_u_5
				if v_u_5.Get("firstPerson") >= 0.5 ~= p84 then
					v_u_5.Set("firstPerson", p84 and 1 or 0, true)
				end
			end)
		end
	end
	task.delay(3, function()
		-- upvalues: (ref) v_u_5, (ref) v_u_36
		for v85 in v_u_5.DEFAULTS do
			v_u_36(v85)
		end
	end)
end
return v_u_5