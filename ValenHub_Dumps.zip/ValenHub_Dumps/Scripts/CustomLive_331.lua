local v_u_1 = game:GetService("ProximityPromptService")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Workspace")
return {
	["Init"] = function(p_u_4) -- name: Init
		-- upvalues: (copy) v_u_3, (copy) v_u_1, (copy) v_u_2
		local v5 = p_u_4.UI
		local v6 = p_u_4.Theme
		local v_u_7 = p_u_4.State
		local v8 = v6.Colors
		local v9 = v6.Fonts
		local v_u_10 = p_u_4.Custom
		local v11 = UDim2.fromOffset
		local v12 = string.format
		local v13 = v8.TextDim.R * 255 + 0.5
		local v14 = math.floor(v13)
		local v15 = v8.TextDim.G * 255 + 0.5
		local v16 = math.floor(v15)
		local v17 = v8.TextDim.B * 255 + 0.5
		local v_u_18 = v12("#%02X%02X%02X", v14, v16, (math.floor(v17)))
		local v_u_19 = v5.new("BillboardGui", {
			["Name"] = "TR_CustomLive",
			["Size"] = nil,
			["LightInfluence"] = 0,
			["Brightness"] = 1,
			["AlwaysOnTop"] = false,
			["MaxDistance"] = 170,
			["ResetOnSpawn"] = false,
			["Active"] = false,
			["ClipsDescendants"] = false,
			["ZIndexBehavior"] = nil,
			["Enabled"] = false,
			["Parent"] = nil,
			["Size"] = v11(320, 180),
			["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
			["Parent"] = p_u_4.PlayerGui
		})
		local v_u_20 = v5.new("Frame", {
			["Name"] = "Pill",
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 0.5, -6),
			["Size"] = v11(0, 30),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["BackgroundColor3"] = v8.Void,
			["BackgroundTransparency"] = 0.3,
			v5.Corner(v6.Radius.Pill),
			v5.Padding(0, 13, 0, 11),
			v5.List(Enum.FillDirection.Horizontal, 7, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
			["Parent"] = v_u_19
		})
		local v_u_21 = v5.new("UIStroke", {
			["Name"] = "Rim",
			["Color"] = nil,
			["Thickness"] = 1.5,
			["Transparency"] = 0.55,
			["Parent"] = nil,
			["Color"] = v8.Success,
			["Parent"] = v_u_20
		})
		local v_u_22 = v5.new("Frame", {
			["Name"] = "Dot",
			["Size"] = v11(9, 9),
			["BackgroundColor3"] = v8.Success,
			["LayoutOrder"] = 1,
			v5.Corner(v6.Radius.Pill),
			["Parent"] = v_u_20
		})
		local v_u_23 = v5.new("TextLabel", {
			["Name"] = "Label",
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Text"] = "",
			["RichText"] = true,
			["FontFace"] = nil,
			["TextSize"] = 17,
			["TextColor3"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["Size"] = v11(0, 30),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["FontFace"] = v9.Heavy,
			["TextColor3"] = v8.Text,
			["Parent"] = v_u_20
		})
		local v_u_24 = v5.new("UIScale", {
			["Name"] = "Fit",
			["Parent"] = nil,
			["Parent"] = v_u_20
		})
		local v_u_25 = nil
		local v_u_26 = Vector3.new(0, 0, 0)
		local v_u_27 = nil
		local v_u_28 = nil
		local function v_u_35() -- name: resolve
			-- upvalues: (ref) v_u_25, (ref) v_u_3, (ref) v_u_26, (copy) v_u_19
			if v_u_25 and v_u_25:IsDescendantOf(v_u_3) then
				return
			else
				v_u_25 = nil
				local v29 = v_u_3:FindFirstChild("Lobby")
				if v29 then
					v29 = v29:FindFirstChild("CustomMatches")
				end
				if v29 then
					local v30 = v29:FindFirstChild("SignBoard")
					if v30 and v30:IsA("BasePart") then
						v_u_25 = v30
						local v31 = v30.Size.Y / 2 + 0.13 + 0.55
						v_u_26 = Vector3.new(0, v31, 0)
					elseif v29:IsA("Model") and v29.PrimaryPart then
						local v32, v33 = v29:GetBoundingBox()
						v_u_25 = v29.PrimaryPart
						local v34 = v32.Position.Y + v33.Y / 2 + 0.55 - v29.PrimaryPart.Position.Y
						v_u_26 = Vector3.new(0, v34, 0)
					end
					v_u_19.Adornee = v_u_25
					v_u_19.StudsOffsetWorldSpace = v_u_26
				end
			end
		end
		local v_u_36 = 0
		local v_u_37 = false
		local v_u_38 = 0
		local v_u_39 = (-1 / 0)
		local v_u_40 = 1
		local function v_u_44() -- name: paintPrompt
			-- upvalues: (ref) v_u_27, (ref) v_u_3, (ref) v_u_28, (copy) v_u_10, (ref) v_u_36
			local v41 = v_u_27
			if not (v41 and v41:IsDescendantOf(v_u_3)) then
				v41 = v_u_3:FindFirstChild("Lobby")
				if v41 then
					v41 = v41:FindFirstChild("CustomMatches")
				end
				if v41 then
					v41 = v41:FindFirstChild("CustomMatchesPrompt", true)
				end
				if not (v41 and v41:IsA("ProximityPrompt")) then
					v41 = nil
				end
				v_u_27 = v41
			end
			if v41 then
				if v_u_28 == nil then
					v_u_28 = v41.ObjectText
				end
				local v42 = v_u_10.IsServer() and 0 or v_u_36
				local v43
				if v42 == 1 then
					v43 = "1 match live"
				elseif v42 > 1 then
					v43 = ("%* matches live"):format(v42)
				else
					v43 = v_u_28 or ""
				end
				if v41.ObjectText ~= v43 then
					v41.ObjectText = v43
				end
			end
		end
		local function v_u_49() -- name: refresh
			-- upvalues: (ref) v_u_3, (ref) v_u_36, (copy) v_u_23, (copy) v_u_18, (ref) v_u_38, (ref) v_u_39, (ref) v_u_40, (copy) v_u_44, (ref) v_u_25, (copy) v_u_7, (copy) p_u_4, (copy) v_u_10, (ref) v_u_37
			local v45 = v_u_3:GetAttribute("CustomLive")
			local v46 = (type(v45) ~= "number" or v45 <= 0) and 0 or math.floor(v45)
			if v46 ~= v_u_36 then
				local v47 = v_u_36
				v_u_36 = v46
				if v46 > 0 then
					v_u_23.Text = ("%* <font color=\"%*\">LIVE</font>"):format(v46, v_u_18)
					if v47 > 0 and v_u_38 > 0.5 then
						v_u_39 = os.clock()
						v_u_40 = 0.86
					end
				end
				v_u_44()
			end
			local v48 = v_u_36 > 0 and v_u_25 ~= nil and not (v_u_7.InMatch() or p_u_4.HudHidden)
			if v48 then
				v48 = not v_u_10.IsServer()
			end
			if v48 and (not v_u_37 and v_u_38 < 0.05) then
				v_u_39 = os.clock()
				v_u_40 = 0.6
			end
			v_u_37 = v48
		end
		v_u_3:GetAttributeChangedSignal("CustomLive"):Connect(v_u_49)
		v_u_3:GetAttributeChangedSignal("CustomServer"):Connect(function()
			-- upvalues: (copy) v_u_49, (copy) v_u_44
			v_u_49()
			v_u_44()
		end)
		v_u_7.PlayerStateChanged:Connect(v_u_49)
		p_u_4.HudHiddenChanged:Connect(v_u_49)
		v_u_10.Changed:Connect(v_u_49)
		v_u_1.PromptShown:Connect(function(p50)
			-- upvalues: (ref) v_u_27, (copy) v_u_44
			if p50.Name == "CustomMatchesPrompt" then
				v_u_27 = p50
				v_u_44()
			end
		end)
		v5.Every(v_u_19, 1, function()
			-- upvalues: (ref) v_u_25, (ref) v_u_3, (copy) v_u_35, (copy) v_u_49, (copy) v_u_44
			if not (v_u_25 and v_u_25:IsDescendantOf(v_u_3)) then
				v_u_35()
				v_u_49()
				v_u_44()
			end
		end)
		v_u_35()
		v_u_49()
		v_u_44()
		local v_u_51 = p_u_4.PlayerGui
		local v_u_52 = { 0.25, 0.75 }
		local v_u_53 = { -0.4, 0, 0.4 }
		local function v_u_57(p54, p55) -- name: isPanel
			-- upvalues: (copy) v_u_19
			if p54:IsDescendantOf(v_u_19) then
				return false
			else
				local v56 = p54.AbsoluteSize
				if v56.X >= p55.X * 0.7 and v56.Y >= p55.Y * 0.7 then
					return false
				else
					return p54.BackgroundTransparency < 0.6 and true or ((p54:IsA("ImageLabel") or p54:IsA("ImageButton")) and (p54.Image ~= "" and p54.ImageTransparency < 0.6) and true or false)
				end
			end
		end
		local function v_u_71(p58, p59) -- name: hudCovers
			-- upvalues: (ref) v_u_26, (copy) v_u_20, (copy) v_u_52, (copy) v_u_53, (copy) v_u_51, (copy) v_u_57
			local v60, v61 = p58:WorldToScreenPoint(p59.Position + v_u_26)
			if not v61 then
				return false
			end
			local v62 = v_u_20.AbsoluteSize.X
			local v63 = v_u_20.AbsoluteSize.Y
			local v64 = v60.Y + v_u_20.Position.Y.Offset
			local v65 = p58.ViewportSize
			for _, v66 in v_u_52 do
				local v67 = v64 - v63 * (1 - v66)
				for _, v68 in v_u_53 do
					for _, v69 in v_u_51:GetGuiObjectsAtPosition(v60.X + v62 * v68, v67) do
						if not v_u_57(v69, v65) then
							continue
						end
						v70 = true
					end
					local v70 = false
					if not v70 then
						break
					end
					return true
				end
			end
			return false
		end
		local v_u_72 = -1
		local v_u_73 = -1
		local v_u_74 = 1
		local v_u_75 = false
		local v_u_76 = (-1 / 0)
		local v_u_77 = (1 / 0)
		v_u_2.RenderStepped:Connect(function(p78)
			-- upvalues: (ref) v_u_37, (ref) v_u_38, (copy) v_u_19, (ref) v_u_3, (ref) v_u_25, (ref) v_u_26, (ref) v_u_76, (copy) v_u_71, (ref) v_u_75, (ref) v_u_77, (ref) v_u_74, (ref) v_u_39, (ref) v_u_40, (ref) v_u_72, (copy) v_u_24, (ref) v_u_73, (copy) v_u_20, (copy) v_u_21, (copy) v_u_23, (copy) v_u_22
			if v_u_37 or v_u_38 > 0 then
				local v79 = v_u_3.CurrentCamera
				local v80 = v_u_25
				if v79 and v80 then
					local v81 = v_u_38
					local v82
					if v_u_37 then
						v82 = p78 / 0.25
					else
						v82 = -p78 / 0.3
					end
					local v83 = v81 + v82
					v_u_38 = math.clamp(v83, 0, 1)
					local v84 = (v80.Position + v_u_26 - v79.CFrame.Position).Magnitude
					local v85 = (170 - v84) / 25
					local v86 = math.clamp(v85, 0, 1)
					local v87 = os.clock()
					if v_u_38 * v86 > 0 and v87 - v_u_76 >= 0.12 then
						v_u_76 = v87
						if v_u_71(v79, v80) then
							v_u_75 = true
							v_u_77 = (1 / 0)
						elseif v_u_75 then
							local v88 = v_u_77
							v_u_77 = math.min(v88, v87)
							if v87 - v_u_77 >= 0.3 then
								v_u_75 = false
							end
						end
					end
					local v89 = v_u_74
					local v90
					if v_u_75 then
						v90 = -p78 / 0.15
					else
						v90 = p78 / 0.25
					end
					local v91 = v89 + v90
					v_u_74 = math.clamp(v91, 0, 1)
					local v92 = v_u_38 * v86 * v_u_74
					v_u_19.Enabled = v92 > 0
					if v92 > 0 then
						local v93 = v79.ViewportSize.Y / 1080
						local v94 = math.clamp(v93, 0.72, 1.3)
						local v95 = 300 / math.max(v84, 1) + 22
						local v96 = math.min(v95, 44) * v94 / 30
						local v97 = os.clock() - v_u_39
						if v97 < 0.45 then
							local v98 = v_u_40
							local v99 = 1 - v_u_40
							local v100 = v97 / 0.45
							v96 = v96 * (v98 + v99 * ((v100 - 1) ^ 3 * 2.70158 + 1 + (v100 - 1) ^ 2 * 1.70158))
						end
						local v101 = v96 * 200 + 0.5
						local v102 = math.floor(v101) / 200
						if v102 ~= v_u_72 then
							v_u_72 = v102
							v_u_24.Scale = v102
						end
						local v103 = v94 * 6 + 0.5
						local v104 = math.floor(v103)
						if v104 ~= v_u_73 then
							v_u_73 = v104
							v_u_20.Position = UDim2.new(0.5, 0, 0.5, -v104)
						end
						local v105 = os.clock() * 2.6179938779914944
						local v106 = (0.5 - math.cos(v105) * 0.5) * 0.55
						v_u_20.BackgroundTransparency = 1 - v92 * 0.7
						v_u_21.Transparency = 1 - v92 * 0.45
						v_u_23.TextTransparency = 1 - v92
						v_u_22.BackgroundTransparency = 1 - v92 * (1 - v106)
					end
				else
					v_u_38 = 0
					v_u_19.Enabled = false
					return
				end
			else
				if v_u_19.Enabled then
					v_u_19.Enabled = false
				end
				return
			end
		end)
		function p_u_4.Debug.customLive()
			-- upvalues: (ref) v_u_3, (ref) v_u_36, (ref) v_u_37, (ref) v_u_38, (ref) v_u_75, (ref) v_u_74, (copy) v_u_19, (ref) v_u_25, (ref) v_u_27, (copy) v_u_24, (copy) v_u_20, (ref) v_u_26
			local v107 = v_u_3.CurrentCamera
			local v108 = {
				["count"] = v_u_36,
				["attr"] = v_u_3:GetAttribute("CustomLive") or false,
				["players"] = v_u_3:GetAttribute("CustomLivePlayers") or false,
				["target"] = v_u_37
			}
			local v109 = v_u_38 * 100 + 0.5
			v108.alpha = math.floor(v109) / 100
			v108.covered = v_u_75
			local v110 = v_u_74 * 100 + 0.5
			v108.cover = math.floor(v110) / 100
			v108.enabled = v_u_19.Enabled
			v108.text = v_u_36 <= 0 and "" or ("%* LIVE"):format(v_u_36)
			local v111
			if v_u_25 then
				v111 = v_u_25:GetFullName()
			else
				v111 = false
			end
			v108.adornee = v111
			local v112
			if v_u_27 then
				v112 = v_u_27.ObjectText
			else
				v112 = false
			end
			v108.prompt = v112
			local v113 = v_u_24.Scale * 100 + 0.5
			v108.scale = math.floor(v113) / 100
			local v114 = {}
			local v115 = v_u_20.AbsoluteSize.X
			local v116 = math.floor(v115)
			local v117 = v_u_20.AbsoluteSize.Y
			__set_list(v114, 1, {v116, (math.floor(v117))})
			v108.pillPx = v114
			local v118
			if v_u_25 and v107 then
				local v119 = (v_u_25.Position + v_u_26 - v107.CFrame.Position).Magnitude
				v118 = math.floor(v119)
			else
				v118 = false
			end
			v108.dist = v118
			return v108
		end
	end
}