local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService"):IsServer()
local v_u_3
if v_u_2 then
	v_u_3 = v1:FindFirstChild("Remotes")
	if not v_u_3 then
		v_u_3 = Instance.new("Folder")
		v_u_3.Name = "Remotes"
		v_u_3.Parent = v1
	end
else
	v_u_3 = v1:WaitForChild("Remotes")
end
local function v_u_11(p4, p5) -- name: get
	-- upvalues: (ref) v_u_3, (copy) v_u_2
	local v6 = v_u_3:FindFirstChild(p5)
	if v6 then
		local v7 = v6.ClassName == p4
		local v8 = ("Remote %* is a %*, expected %*"):format(p5, v6.ClassName, p4)
		assert(v7, v8)
		return v6
	end
	if not v_u_2 then
		local v9 = v_u_3:WaitForChild(p5, 15)
		if not v9 then
			warn((("[Net] still waiting for remote \'%*\' (is its server module loaded?)"):format(p5)))
			v9 = v_u_3:WaitForChild(p5)
		end
		return v9
	end
	local v10 = Instance.new(p4)
	v10.Name = p5
	v10.Parent = v_u_3
	return v10
end
return {
	["Event"] = function(p12) -- name: Event
		-- upvalues: (copy) v_u_11
		return v_u_11("RemoteEvent", p12)
	end,
	["UnreliableEvent"] = function(p13) -- name: UnreliableEvent
		-- upvalues: (copy) v_u_11
		return v_u_11("UnreliableRemoteEvent", p13)
	end,
	["Function"] = function(p14) -- name: Function
		-- upvalues: (copy) v_u_11
		return v_u_11("RemoteFunction", p14)
	end,
	["RateLimiter"] = function(p_u_15, p16) -- name: RateLimiter
		local v_u_17 = p16 or p_u_15
		local v_u_18 = {}
		game:GetService("Players").PlayerRemoving:Connect(function(p19)
			-- upvalues: (copy) v_u_18
			v_u_18[p19] = nil
		end)
		return function(p20)
			-- upvalues: (copy) v_u_18, (copy) v_u_17, (copy) p_u_15
			local v21 = os.clock()
			local v22 = v_u_18[p20]
			if not v22 then
				v22 = {
					["tokens"] = v_u_17,
					["t"] = v21
				}
				v_u_18[p20] = v22
			end
			local v23 = v_u_17
			local v24 = v22.tokens + (v21 - v22.t) * p_u_15
			v22.tokens = math.min(v23, v24)
			v22.t = v21
			if v22.tokens < 1 then
				return false
			end
			v22.tokens = v22.tokens - 1
			return true
		end
	end
}