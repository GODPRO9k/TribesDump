return table.freeze({
	["SlideLegs"] = "rbxassetid://77416758447437",
	["SlideUpper"] = "rbxassetid://115641667120144",
	["SlideFallback"] = "rbxassetid://2506281703",
	["R15"] = nil,
	["R6"] = nil,
	["Emotes"] = nil,
	["R15"] = {
		["idle"] = "rbxassetid://2510196951",
		["idle2"] = "rbxassetid://2510197257",
		["walk"] = "rbxassetid://2510202577",
		["run"] = "rbxassetid://2510198475",
		["jump"] = "rbxassetid://2510197830",
		["fall"] = "rbxassetid://2510195892",
		["climb"] = "rbxassetid://2510192778",
		["swim"] = "rbxassetid://2510199791",
		["swimidle"] = "rbxassetid://2510201162",
		["sit"] = "rbxassetid://2506281703"
	},
	["R6"] = {
		["idle"] = "rbxassetid://180435571",
		["idle2"] = "rbxassetid://180435792",
		["walk"] = "rbxassetid://180426354",
		["run"] = "rbxassetid://180426354",
		["jump"] = "rbxassetid://125750702",
		["fall"] = "rbxassetid://180436148",
		["climb"] = "rbxassetid://180436334",
		["swim"] = "rbxassetid://180426354",
		["swimidle"] = "rbxassetid://180435571",
		["sit"] = "rbxassetid://178130996"
	},
	["Emotes"] = {
		["wave"] = "rbxassetid://507770239",
		["point"] = "rbxassetid://507770453",
		["cheer"] = "rbxassetid://507770677",
		["laugh"] = "rbxassetid://507770818",
		["dance"] = "rbxassetid://507771019",
		["dance2"] = "rbxassetid://507776043",
		["dance3"] = "rbxassetid://507777268"
	}
})