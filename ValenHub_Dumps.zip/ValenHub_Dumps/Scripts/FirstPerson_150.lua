local v_u_1 = {
	["EYE_EASE"] = 5
}
local v_u_2 = v_u_1.EYE_EASE
v_u_1.STRIDE = 7
v_u_1.BOB_SPEED = 21
v_u_1.BOB_EASE = 8
v_u_1.CAM_BOB_Y = 0.03
v_u_1.CAM_BOB_ROLL = 0.002617993877991494
local v_u_3 = false
local v_u_4 = true
local v_u_5 = 0
local v_u_6 = nil
local v_u_7 = 0
local v_u_8 = 0
local v_u_9 = 0
local v_u_10 = nil
function v_u_1.Set(p11) -- name: Set
	-- upvalues: (ref) v_u_3
	v_u_3 = p11 == true
end
function v_u_1.Get() -- name: Get
	-- upvalues: (ref) v_u_3
	return v_u_3
end
function v_u_1.SetBobbing(p12) -- name: SetBobbing
	-- upvalues: (ref) v_u_4
	v_u_4 = p12 == true
end
function v_u_1.GetBobbing() -- name: GetBobbing
	-- upvalues: (ref) v_u_4
	return v_u_4
end
function v_u_1.Step(p13, p14) -- name: Step
	-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_10, (ref) v_u_8, (ref) v_u_3
	if p14 then
		local v15 = v_u_3 and 1 or 0
		if v_u_5 < v15 then
			local v16 = v_u_5 + p13 / 0.2
			v_u_5 = math.min(v15, v16)
		elseif v15 < v_u_5 then
			local v17 = v_u_5 - p13 / 0.2
			v_u_5 = math.max(v15, v17)
		end
		return v_u_5
	end
	v_u_5 = 0
	v_u_6 = nil
	v_u_10 = nil
	v_u_8 = 0
	return 0
end
function v_u_1.Eased() -- name: Eased
	-- upvalues: (ref) v_u_5
	local v18 = v_u_5
	return v18 * v18 * (3 - v18 * 2)
end
function v_u_1.StepBob(p19, p20, p21, p22) -- name: StepBob
	-- upvalues: (ref) v_u_10, (ref) v_u_9, (copy) v_u_1, (ref) v_u_8, (ref) v_u_7
	local v23 = v_u_10
	local v24
	if v23 and p19 > 0 then
		local v25 = p20 - v23
		local v26 = v25.X
		local v27 = v25.Z
		local v28 = Vector3.new(v26, 0, v27).Magnitude / p19
		v24 = v28 > 80 and 0 or v28
	else
		v24 = 0
	end
	v_u_10 = p20
	local v29 = v_u_9
	local v30 = v24 - v_u_9
	local v31 = p19 * -12
	v_u_9 = v29 + v30 * (1 - math.exp(v31))
	local v32
	if p21 and not p22 then
		local v33 = (v_u_9 - 1) / (v_u_1.BOB_SPEED - 1)
		v32 = math.clamp(v33, 0, 1.25)
	else
		v32 = 0
	end
	local v34 = v_u_8
	local v35 = v32 - v_u_8
	local v36 = -v_u_1.BOB_EASE * p19
	v_u_8 = v34 + v35 * (1 - math.exp(v36))
	if v_u_8 < 0.002 and v32 == 0 then
		v_u_8 = 0
	end
	if p21 then
		v_u_7 = (v_u_7 + v24 * p19 / v_u_1.STRIDE * 2 * 3.141592653589793) % 12.566370614359172
	end
end
function v_u_1.Bob() -- name: Bob
	-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_9
	return v_u_7, v_u_8, v_u_9
end
function v_u_1.CameraBob() -- name: CameraBob
	-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_7, (copy) v_u_1
	if not v_u_4 or v_u_8 <= 0 then
		return 0, 0
	end
	local v37 = v_u_8
	local v38 = v_u_7 * 2
	local v39 = v_u_7
	return -math.cos(v38) * 0.5 * v_u_1.CAM_BOB_Y * v37, math.sin(v39) * v_u_1.CAM_BOB_ROLL * v37
end
function v_u_1.Eye(p40, p41, p42, p43, p44) -- name: Eye
	-- upvalues: (ref) v_u_6, (copy) v_u_2
	local v45 = (not p43 and 1.5 or p43.Position.Y - p42.Position.Y) + 0.25
	local v46 = v_u_6
	if v46 ~= nil then
		local v47 = v45 - v46
		local v48 = -v_u_2 * p40
		v45 = v46 + v47 * (1 - math.exp(v48))
	end
	v_u_6 = v45
	local v49 = p44.X
	local v50 = p44.Z
	local v51 = Vector3.new(v49, 0, v50)
	local v52 = v51.Magnitude <= 0.001 and Vector3.new(0, 0, 0) or v51.Unit * 0.3
	return p41 + Vector3.new(0, v45, 0) - v52
end
return v_u_1