local v_u_1 = game:GetService("Lighting")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = require(v_u_3:WaitForChild("Shared"):WaitForChild("Config"))
local v7 = {}
local v_u_8 = v2.LocalPlayer
local v_u_9 = {
	"ClockTime",
	"Brightness",
	"Ambient",
	"OutdoorAmbient",
	"ExposureCompensation",
	"EnvironmentDiffuseScale",
	"EnvironmentSpecularScale",
	"ShadowSoftness",
	"GeographicLatitude",
	"ColorShift_Top",
	"ColorShift_Bottom",
	"FogColor",
	"FogStart",
	"FogEnd"
}
local v_u_10 = {
	["Atmosphere"] = true,
	["Sky"] = true,
	["BloomEffect"] = true,
	["ColorCorrectionEffect"] = true,
	["SunRaysEffect"] = true,
	["DepthOfFieldEffect"] = true,
	["BlurEffect"] = true
}
local v_u_11 = {}
local v_u_12 = {}
local v_u_13 = {}
local v_u_14 = {}
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = 0
local v_u_18 = Instance.new("Folder")
v_u_18.Name = "CoreLightingStash"
local v_u_19 = Instance.new("ColorCorrectionEffect")
v_u_19.Name = "CoreTransition"
v_u_19.Enabled = false
local function v_u_30() -- name: wantedName
	-- upvalues: (copy) v_u_8, (copy) v_u_5, (copy) v_u_3, (ref) v_u_15
	local v20
	if v_u_8:GetAttribute("State") == "Match" then
		v20 = v_u_8:GetAttribute("MatchId")
	else
		v20 = v_u_8:GetAttribute("Spectating")
	end
	if (type(v20) ~= "string" and "" or v20) == "" then
		return "Lobby"
	end
	local v21
	if v_u_8:GetAttribute("State") == "Match" then
		v21 = v_u_8:GetAttribute("MatchId")
	else
		v21 = v_u_8:GetAttribute("Spectating")
	end
	local v22 = type(v21) ~= "string" and "" or v21
	local v23 = type(v22) == "string" and v22 ~= "" and v_u_5:FindFirstChild("Arenas")
	if v23 then
		v23 = v23:FindFirstChild(v22)
	end
	if not v23 then
		return v_u_15 or "Lobby"
	end
	local v24 = v23:GetAttribute("LightingPreset")
	if type(v24) == "string" and v24 ~= "" then
		local v25 = v_u_3:FindFirstChild("Lighting")
		local v26
		if v25 and v24 then
			v26 = v25:FindFirstChild(v24)
		else
			v26 = nil
		end
		if v26 then
			return v24
		end
	end
	local v27 = v23:GetAttribute("MapId")
	if type(v27) == "string" then
		local v28 = v_u_3:FindFirstChild("Lighting")
		local v29
		if v28 and v27 then
			v29 = v28:FindFirstChild(v27)
		else
			v29 = nil
		end
		if v29 then
			return v27
		end
	end
	return (type(v24) ~= "string" or v24 == "") and "Lobby" or v24
end
local function v_u_36() -- name: restoreDefaults
	-- upvalues: (copy) v_u_11, (copy) v_u_1, (copy) v_u_13, (copy) v_u_14
	for v_u_31, v_u_32 in v_u_11 do
		local function v33()
			-- upvalues: (ref) v_u_1, (copy) v_u_31, (copy) v_u_32
			v_u_1[v_u_31] = v_u_32
		end
		pcall(v33)
	end
	for _, v34 in v_u_13 do
		v34:Destroy()
	end
	table.clear(v_u_13)
	for _, v35 in v_u_14 do
		v35.Parent = v_u_1
	end
	table.clear(v_u_14)
end
local function v_u_48(p37) -- name: applyNow
	-- upvalues: (copy) v_u_36, (ref) v_u_16, (copy) v_u_9, (copy) v_u_1, (copy) v_u_10, (copy) v_u_12, (copy) v_u_18, (copy) v_u_14, (copy) v_u_13
	v_u_36()
	v_u_16 = p37
	if p37 then
		for _, v_u_38 in v_u_9 do
			local v_u_39 = p37:GetAttribute(v_u_38)
			if v_u_39 == nil then
				continue
			end
			local function v40()
				-- upvalues: (ref) v_u_1, (copy) v_u_38, (copy) v_u_39
				v_u_1[v_u_38] = v_u_39
			end
			pcall(v40)
		end
		local v41 = {}
		for _, v42 in p37:GetChildren() do
			if not v_u_10[v42.ClassName] then
				continue
			end
			v41[v42.ClassName] = true
		end
		for _, v43 in v_u_1:GetChildren() do
			if not (v_u_12[v43] and v41[v43.ClassName]) then
				continue
			end
			v43.Parent = v_u_18
			local v44 = v_u_14
			table.insert(v44, v43)
		end
		for _, v45 in p37:GetChildren() do
			if not v_u_10[v45.ClassName] then
				continue
			end
			local v46 = v45:Clone()
			v46.Parent = v_u_1
			local v47 = v_u_13
			table.insert(v47, v46)
		end
	end
end
local function v_u_61() -- name: landed
	-- upvalues: (copy) v_u_8, (copy) v_u_5, (copy) v_u_6
	if v_u_8:GetAttribute("State") ~= "Match" then
		local v49
		if v_u_8:GetAttribute("State") == "Match" then
			v49 = v_u_8:GetAttribute("MatchId")
		else
			v49 = v_u_8:GetAttribute("Spectating")
		end
		if (type(v49) ~= "string" and "" or v49) ~= "" then
			local v50
			if v_u_8:GetAttribute("State") == "Match" then
				v50 = v_u_8:GetAttribute("MatchId")
			else
				v50 = v_u_8:GetAttribute("Spectating")
			end
			local v51 = type(v50) ~= "string" and "" or v50
			local v52 = type(v51) == "string" and v51 ~= "" and v_u_5:FindFirstChild("Arenas")
			if v52 then
				v52 = v52:FindFirstChild(v51)
			end
			local v53
			if v52 then
				v53 = v52:GetAttribute("RingCenterX")
			else
				v53 = v52
			end
			if v52 then
				v52 = v52:GetAttribute("RingCenterZ")
			end
			local v54 = v_u_5.CurrentCamera
			if type(v53) ~= "number" or (type(v52) ~= "number" or not v54) then
				return false
			end
			local v55 = v54.CFrame.Position
			return Vector2.new(v55.X - v53, v55.Z - v52).Magnitude < 600
		end
	end
	local v56 = v_u_8.Character
	if v56 then
		v56 = v56:FindFirstChild("HumanoidRootPart")
	end
	if v56 and v56:IsA("BasePart") then
		local v57 = v56.Position
		if v_u_8:GetAttribute("State") == "Match" then
			local v58 = v_u_8:GetAttribute("MatchId")
			local v59 = type(v58) == "string" and v58 ~= "" and v_u_5:FindFirstChild("Arenas")
			if v59 then
				v59 = v59:FindFirstChild(v58)
			end
			local v60
			if v59 then
				v60 = v59:GetAttribute("RingCenterX")
			else
				v60 = v59
			end
			if v59 then
				v59 = v59:GetAttribute("RingCenterZ")
			end
			if type(v60) == "number" and type(v59) == "number" then
				return Vector2.new(v57.X - v60, v57.Z - v59).Magnitude < 600
			else
				return false
			end
		else
			return Vector2.new(v57.X - v_u_6.LOBBY_CENTER.X, v57.Z - v_u_6.LOBBY_CENTER.Z).Magnitude < v_u_6.LOBBY_HALF_SIZE + 200
		end
	else
		return false
	end
end
local function v_u_65(p62, p63) -- name: fade
	-- upvalues: (copy) v_u_4, (copy) v_u_19
	local v64 = v_u_4:Create(v_u_19, TweenInfo.new(p63, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
		["TintColor"] = p62
	})
	v64:Play()
	return v64
end
local function v_u_77(p66) -- name: refresh
	-- upvalues: (copy) v_u_30, (copy) v_u_3, (ref) v_u_15, (ref) v_u_16, (copy) v_u_19, (ref) v_u_17, (copy) v_u_48, (copy) v_u_65, (copy) v_u_61
	local v_u_67 = v_u_30()
	local v68 = v_u_3:FindFirstChild("Lighting")
	local v69
	if v68 and v_u_67 then
		v69 = v68:FindFirstChild(v_u_67)
	else
		v69 = nil
	end
	if v_u_67 == v_u_15 and (v69 == v_u_16 and not v_u_19.Enabled) then
		return
	else
		v_u_17 = v_u_17 + 1
		local v_u_70 = v_u_17
		local v71
		if v_u_15 == nil then
			v71 = false
		else
			v71 = v_u_67 ~= v_u_15
		end
		v_u_15 = v_u_67
		if p66 and v71 or v_u_19.Enabled then
			task.spawn(function()
				-- upvalues: (ref) v_u_19, (ref) v_u_65, (copy) v_u_70, (ref) v_u_17, (ref) v_u_61, (ref) v_u_48, (copy) v_u_67, (ref) v_u_3
				v_u_19.Enabled = true
				v_u_65(Color3.new(0.05, 0.05, 0.06), 0.25).Completed:Wait()
				local v72 = os.clock() + 2.5
				while os.clock() < v72 and (v_u_70 == v_u_17 and not v_u_61()) do
					task.wait(0.05)
				end
				if v_u_70 == v_u_17 then
					local v73 = v_u_48
					local v74 = v_u_67
					local v75 = v_u_3:FindFirstChild("Lighting")
					local v76
					if v75 and v74 then
						v76 = v75:FindFirstChild(v74)
					else
						v76 = nil
					end
					v73(v76)
					task.wait(0.1)
					if v_u_70 == v_u_17 then
						v_u_65(Color3.new(1, 1, 1), 0.45).Completed:Wait()
						if v_u_70 == v_u_17 then
							v_u_19.Enabled = false
						end
					end
				else
					return
				end
			end)
		else
			v_u_48(v69)
		end
	end
end
function v7.Current() -- name: Current
	-- upvalues: (ref) v_u_15
	return v_u_15
end
function v7.Start() -- name: Start
	-- upvalues: (copy) v_u_9, (copy) v_u_1, (copy) v_u_11, (copy) v_u_12, (copy) v_u_19, (copy) v_u_77, (copy) v_u_8, (copy) v_u_3, (copy) v_u_5
	for _, v_u_78 in v_u_9 do
		local function v79()
			-- upvalues: (ref) v_u_1, (copy) v_u_78
			return v_u_1[v_u_78]
		end
		local v80, v81 = pcall(v79)
		if not v80 then
			continue
		end
		v_u_11[v_u_78] = v81
	end
	for _, v82 in v_u_1:GetChildren() do
		v_u_12[v82] = true
	end
	v_u_19.Parent = v_u_1
	v_u_77(false)
	v_u_8:GetAttributeChangedSignal("State"):Connect(function()
		-- upvalues: (ref) v_u_77
		v_u_77(true)
	end)
	v_u_8:GetAttributeChangedSignal("MatchId"):Connect(function()
		-- upvalues: (ref) v_u_77
		v_u_77(true)
	end)
	v_u_8:GetAttributeChangedSignal("Spectating"):Connect(function()
		-- upvalues: (ref) v_u_77
		v_u_77(true)
	end)
	local v83 = v_u_3:FindFirstChild("Lighting")
	if v83 then
		v83.ChildAdded:Connect(function()
			-- upvalues: (ref) v_u_77
			task.defer(v_u_77, false)
		end)
		v_u_77(false)
	else
		local v_u_84 = nil
		v_u_84 = v_u_3.ChildAdded:Connect(function(p85)
			-- upvalues: (ref) v_u_84, (ref) v_u_77
			if p85.Name == "Lighting" then
				v_u_84:Disconnect()
				p85.ChildAdded:Connect(function()
					-- upvalues: (ref) v_u_77
					task.defer(v_u_77, false)
				end)
				v_u_77(false)
			end
		end)
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_77
		local v86 = v_u_5:WaitForChild("Arenas", 60)
		if v86 then
			v86.ChildAdded:Connect(function(p87)
				-- upvalues: (ref) v_u_8, (ref) v_u_77
				local v88 = p87.Name
				local v89
				if v_u_8:GetAttribute("State") == "Match" then
					v89 = v_u_8:GetAttribute("MatchId")
				else
					v89 = v_u_8:GetAttribute("Spectating")
				end
				if v88 == (type(v89) ~= "string" and "" or v89) then
					task.defer(v_u_77, true)
				end
			end)
		end
	end)
end
return v7