local v_u_1 = {}
v_u_1.__index = v_u_1
function v_u_1.new(p2, p3, p4) -- name: new
	-- upvalues: (copy) v_u_1
	local v5 = {
		["value"] = p2,
		["velocity"] = p2 * 0,
		["target"] = p2,
		["frequency"] = p3,
		["damping"] = p4 or 1
	}
	local v6 = v_u_1
	return setmetatable(v5, v6)
end
function v_u_1.Update(p7, p8) -- name: Update
	local v9 = p7.frequency * 2 * 3.141592653589793
	local v10 = p7.damping
	local v11 = math.min(p8, 0.13333333333333333)
	local v12 = p7.value
	local v13 = p7.velocity
	local v14 = p7.target
	while v11 > 1e-6 do
		local v15 = math.min(0.004166666666666667, v11)
		v11 = v11 - v15
		v13 = v13 + ((v14 - v12) * (v9 * v9) - v13 * (v10 * 2 * v9)) * v15
		v12 = v12 + v13 * v15
	end
	p7.value = v12
	p7.velocity = v13
	return v12
end
function v_u_1.Impulse(p16, p17) -- name: Impulse
	p16.velocity = p16.velocity + p17
end
function v_u_1.Snap(p18, p19) -- name: Snap
	p18.value = p19
	p18.target = p19
	p18.velocity = p19 * 0
end
return v_u_1