local v1 = {
	["GROUPS"] = {
		["SFX"] = 0.9,
		["UI"] = 0.7,
		["Music"] = 0.5,
		["Ambient"] = 0.6
	}
}
local v2 = {
	["default"] = { 8, 150 },
	["foot"] = { 6, 90 },
	["body"] = { 8, 120 },
	["melee"] = { 6, 110 },
	["hit"] = { 6, 150 },
	["bow"] = { 8, 220 },
	["gun"] = { 14, 420 },
	["boom"] = { 18, 450 },
	["impact"] = { 5, 140 },
	["util"] = { 6, 110 },
	["loop"] = { 5, 70 },
	["emitter"] = { 4, 40 },
	["ambient"] = { 10, 180 }
}
v1.ROLL = v2
local v_u_3 = {
	["Arrow_Flesh"] = {
		["id"] = 115374295541411,
		["vol"] = 0.8,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: arrow into a body",
		["roll"] = v2.hit
	},
	["Arrow_Impact"] = {
		["id"] = 126557162337377,
		["vol"] = 0.7,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: arrow into the world",
		["roll"] = v2.impact
	},
	["Bandage_Wrap"] = {
		["id"] = 9113834008,
		["vol"] = 0.7,
		["roll"] = nil,
		["src"] = "Out Alive (PSE)",
		["roll"] = v2.util
	},
	["Block_Hit"] = {
		["id"] = 109675024264804,
		["vol"] = 0.8,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: blocked melee hit",
		["roll"] = v2.hit
	},
	["Block_Up"] = {
		["id"] = 125538743065045,
		["vol"] = 0.4,
		["pitch"] = 1.2,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: raise block",
		["roll"] = v2.melee
	},
	["Bow_Draw"] = {
		["id"] = 82271313074659,
		["vol"] = 0.6,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.melee
	},
	["Bow_Full"] = {
		["id"] = 15675032796,
		["vol"] = 0.5,
		["pitch"] = 1.4,
		["roll"] = nil,
		["src"] = "Out Alive (Roblox UI)",
		["use"] = "combat: full draw ping",
		["roll"] = v2.melee
	},
	["Bow_Release"] = {
		["id"] = 136967567038278,
		["vol"] = 0.8,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.bow
	},
	["Cast_Fire"] = {
		["id"] = 113831670560719,
		["vol"] = 0.8,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.bow
	},
	["Cast_Frost"] = {
		["id"] = 77519143061231,
		["vol"] = 0.8,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.bow
	},
	["Cast_Lightning"] = {
		["id"] = 9114277757,
		["vol"] = 0.7,
		["pitch"] = 1.1,
		["roll"] = nil,
		["src"] = "Out Alive (PSE)",
		["roll"] = v2.bow
	},
	["Charge_Full"] = {
		["id"] = 15675032796,
		["vol"] = 0.5,
		["pitch"] = 1.6,
		["roll"] = nil,
		["src"] = "Out Alive (Roblox UI)",
		["roll"] = v2.melee
	},
	["Charge_Up"] = {
		["id"] = 131969177643108,
		["vol"] = 0.5,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.melee
	},
	["Crossbow_Fire"] = {
		["id"] = 9114001369,
		["vol"] = 1,
		["pitch"] = 1.05,
		["roll"] = nil,
		["src"] = "Out Alive (PSE Crossbow Fire 12)",
		["use"] = "combat: crossbow shot",
		["roll"] = v2.bow
	},
	["Crossbow_Reload"] = {
		["id"] = 609345653,
		["vol"] = 0.5,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: crossbow reload",
		["roll"] = v2.melee
	},
	["Death_Poof"] = {
		["id"] = 9113263647,
		["vol"] = 0.7,
		["pitch"] = 0.9,
		["roll"] = nil,
		["src"] = "Out Alive (PSE)",
		["roll"] = v2.hit
	},
	["Denied"] = {
		["id"] = 87519554692663,
		["vol"] = 0.5,
		["group"] = "UI",
		["src"] = "Out Alive (Creator Store)"
	},
	["Drink"] = {
		["id"] = 9114171955,
		["vol"] = 0.7,
		["roll"] = nil,
		["src"] = "Out Alive (PSE)",
		["roll"] = v2.util
	},
	["Dry_Fire"] = {
		["id"] = 15675032796,
		["vol"] = 0.5,
		["pitch"] = 0.7,
		["roll"] = nil,
		["src"] = "Out Alive (Roblox UI)",
		["use"] = "combat: out of ammo / charges",
		["roll"] = v2.melee
	},
	["Equip_Blade"] = {
		["id"] = 9119744718,
		["vol"] = 0.5,
		["roll"] = nil,
		["src"] = "Out Alive (PSE sword draw)",
		["use"] = "combat: equip dagger/spear",
		["roll"] = v2.melee
	},
	["Equip_Bow"] = {
		["id"] = 74248579135630,
		["vol"] = 0.4,
		["pitch"] = 0.8,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: equip bows/sling",
		["roll"] = v2.melee
	},
	["Equip_Crossbow"] = {
		["id"] = 609345653,
		["vol"] = 0.35,
		["pitch"] = 1.3,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: equip crossbow",
		["roll"] = v2.melee
	},
	["Equip_Heavy"] = {
		["id"] = 7886392785,
		["vol"] = 0.5,
		["pitch"] = 0.9,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: equip axe/club",
		["roll"] = v2.melee
	},
	["Equip_Item"] = {
		["id"] = 15675012262,
		["vol"] = 0.4,
		["roll"] = nil,
		["src"] = "Out Alive (Roblox UI)",
		["use"] = "combat: equip utilities/throwables",
		["roll"] = v2.melee
	},
	["Equip_Staff"] = {
		["id"] = 87633794002285,
		["vol"] = 0.4,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.melee
	},
	["Explosion"] = {
		["id"] = 130565967505452,
		["vol"] = 0.9,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.boom
	},
	["Explosion_Big"] = {
		["id"] = 139900006476219,
		["vol"] = 1,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.boom
	},
	["Heal_Done"] = {
		["id"] = 6373199071,
		["vol"] = 0.6,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: heal finished",
		["roll"] = v2.util
	},
	["Hit_Headshot"] = {
		["id"] = 118799613600209,
		["vol"] = 0.7,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: headshot ding at the victim",
		["roll"] = v2.hit
	},
	["Hit_Melee"] = {
		["id"] = 104694053505293,
		["vol"] = 0.8,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: generic melee hit",
		["roll"] = v2.hit
	},
	["Hit_Melee_Heavy"] = {
		["id"] = 101232234433592,
		["vol"] = 0.9,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: heavy melee hit",
		["roll"] = v2.hit
	},
	["Hit_Punch"] = {
		["id"] = 132504023010884,
		["vol"] = 0.8,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: stone / blunt hit",
		["roll"] = v2.hit
	},
	["Hitmarker_Classic"] = {
		["id"] = 5952120301,
		["vol"] = 0.55,
		["group"] = "SFX",
		["jitter"] = 0,
		["src"] = "Out Alive\'s Hitmarker (Creator Store)"
	},
	["Hitmarker_Shield"] = {
		["id"] = 83597774521615,
		["vol"] = 0.4,
		["pitch"] = 1.2,
		["jitter"] = 0,
		["src"] = "Out Alive (Creator Store)"
	},
	["Hurt"] = {
		["id"] = 126895218143022,
		["vol"] = 0.7,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.hit
	},
	["Hurt_Shield"] = {
		["id"] = 83597774521615,
		["vol"] = 0.5,
		["pitch"] = 0.9,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.hit
	},
	["Ice_Shatter"] = {
		["id"] = 80067573243829,
		["vol"] = 0.7,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.impact
	},
	["Impact_Dirt"] = {
		["id"] = 126557162337377,
		["vol"] = 0.5,
		["pitch"] = 0.85,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.impact
	},
	["Impact_Metal"] = {
		["id"] = 102462537156803,
		["vol"] = 0.5,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.impact
	},
	["Impact_Stone"] = {
		["id"] = 126557162337377,
		["vol"] = 0.5,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: sling stone / thrown item into the world",
		["roll"] = v2.impact
	},
	["Impact_Wood"] = {
		["id"] = 92132728020816,
		["vol"] = 0.6,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.impact
	},
	["Javelin_Hit"] = {
		["id"] = 88474597246685,
		["vol"] = 0.8,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: javelin hit",
		["roll"] = v2.hit
	},
	["Kill"] = {
		["id"] = 6455272657,
		["vol"] = 0.8,
		["jitter"] = 0,
		["src"] = "Out Alive (Creator Store)"
	},
	["Lightning_Zap"] = {
		["id"] = 97096310054904,
		["vol"] = 0.8,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.impact
	},
	["Lunge"] = {
		["id"] = 119573908217733,
		["vol"] = 0.8,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: lunge whoosh",
		["roll"] = v2.melee
	},
	["Shield_Break"] = {
		["id"] = 9114856749,
		["vol"] = 0.8,
		["pitch"] = 1.1,
		["roll"] = nil,
		["src"] = "Out Alive (PSE)",
		["roll"] = v2.hit
	},
	["Shield_Up"] = {
		["id"] = 4612377122,
		["vol"] = 0.6,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.util
	},
	["Spear_Thrust"] = {
		["id"] = 5789211405,
		["vol"] = 0.6,
		["pitch"] = 0.9,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.melee
	},
	["Swing_Heavy"] = {
		["id"] = 101266427032050,
		["vol"] = 0.8,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.melee
	},
	["Swing_Light"] = {
		["id"] = 115208821337480,
		["vol"] = 0.6,
		["pitch"] = 1.15,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.melee
	},
	["Swing_Punch"] = {
		["id"] = 74248579135630,
		["vol"] = 0.55,
		["pitch"] = 1.1,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.melee
	},
	["Swing_Sword"] = {
		["id"] = 134671877618939,
		["vol"] = 0.7,
		["pitch"] = 1.05,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["roll"] = v2.melee
	},
	["Throw"] = {
		["id"] = 138269694368715,
		["vol"] = 0.7,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: generic throw (bombs)",
		["roll"] = v2.bow
	},
	["Throw_Windup"] = {
		["id"] = 131969177643108,
		["vol"] = 0.4,
		["pitch"] = 0.8,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "combat: throw wind-up",
		["roll"] = v2.melee
	},
	["Character/Jump"] = {
		["id"] = 9113823745,
		["vol"] = 1.5,
		["roll"] = nil,
		["src"] = "Out Alive (PSE)",
		["use"] = "character",
		["roll"] = v2.body
	},
	["Character/Land"] = {
		["id"] = 9113469292,
		["vol"] = 0.3,
		["roll"] = nil,
		["src"] = "Out Alive (PSE)",
		["use"] = "character",
		["roll"] = v2.body
	},
	["Character/LandHeavy"] = {
		["id"] = 18782451032,
		["vol"] = 0.8,
		["roll"] = nil,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "character",
		["roll"] = v2.body
	},
	["Character/Slide"] = {
		["id"] = 9114658416,
		["vol"] = 0.3,
		["roll"] = nil,
		["src"] = "Out Alive (PSE)",
		["use"] = "character",
		["roll"] = v2.body
	},
	["Character/Footstep_Dirt"] = {
		["variants"] = nil,
		["vol"] = 0.6,
		["roll"] = nil,
		["jitter"] = 0.06,
		["throttle"] = 0.02,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "character",
		["variants"] = {
			{ "Footstep_Dirt_1", 80932364310315 },
			{ "Footstep_Dirt_2", 130611100801821 },
			{ "Footstep_Dirt_3", 97480467702673 },
			{ "Footstep_Dirt_4", 114765760744945 }
		},
		["roll"] = v2.foot
	},
	["Character/Footstep_Grass"] = {
		["variants"] = nil,
		["vol"] = 0.9,
		["roll"] = nil,
		["jitter"] = 0.06,
		["throttle"] = 0.02,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "character",
		["variants"] = {
			{ "Footstep_Grass_1", 105277634319381 },
			{ "Footstep_Grass_2", 98069158661569 },
			{ "Footstep_Grass_3", 135182192451997 },
			{ "Footstep_Grass_4", 116425333836106 }
		},
		["roll"] = v2.foot
	},
	["Character/Footstep_Metal"] = {
		["variants"] = nil,
		["vol"] = 0.28,
		["roll"] = nil,
		["jitter"] = 0.06,
		["throttle"] = 0.02,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "character",
		["variants"] = {
			{ "Footstep_Metal_1", 78580994772675 },
			{ "Footstep_Metal_2", 79005288283137 },
			{ "Footstep_Metal_3", 98060045106272 },
			{ "Footstep_Metal_4", 122668036980895 }
		},
		["roll"] = v2.foot
	},
	["Character/Footstep_Sand"] = {
		["variants"] = nil,
		["vol"] = 0.8,
		["roll"] = nil,
		["jitter"] = 0.06,
		["throttle"] = 0.02,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "character",
		["variants"] = {
			{ "Footstep_Sand_1", 84209465430801 },
			{ "Footstep_Sand_2", 115151668857364 },
			{ "Footstep_Sand_3", 93919782627384 },
			{ "Footstep_Sand_4", 105793766638092 }
		},
		["roll"] = v2.foot
	},
	["Character/Footstep_Snow"] = {
		["variants"] = nil,
		["vol"] = 0.75,
		["roll"] = nil,
		["jitter"] = 0.06,
		["throttle"] = 0.02,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "character",
		["variants"] = {
			{ "Footstep_Snow_1", 72043022297629 },
			{ "Footstep_Snow_2", 135918121539048 }
		},
		["roll"] = v2.foot
	},
	["Character/Footstep_Stone"] = {
		["variants"] = nil,
		["vol"] = 0.75,
		["roll"] = nil,
		["jitter"] = 0.06,
		["throttle"] = 0.02,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "character",
		["variants"] = {
			{ "Footstep_Stone_1", 81623756670923 },
			{ "Footstep_Stone_2", 78754179999047 },
			{ "Footstep_Stone_3", 79418255155423 },
			{ "Footstep_Stone_4", 112240321395589 }
		},
		["roll"] = v2.foot
	},
	["Character/Footstep_Wood"] = {
		["variants"] = nil,
		["vol"] = 0.4,
		["roll"] = nil,
		["jitter"] = 0.06,
		["throttle"] = 0.02,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "character",
		["variants"] = {
			{ "Footstep_Wood_1", 87921439933530 },
			{ "Footstep_Wood_2", 89597871459985 },
			{ "Footstep_Wood_3", 139932856876296 },
			{ "Footstep_Wood_4", 75643573822739 }
		},
		["roll"] = v2.foot
	},
	["UI/Click"] = {
		["id"] = 15675059323,
		["vol"] = 0.5,
		["src"] = "Out Alive (Roblox UI)",
		["use"] = "ui"
	},
	["UI/Close"] = {
		["id"] = 10066914500,
		["vol"] = 0.5,
		["src"] = "Out Alive (Roblox UI)",
		["use"] = "ui"
	},
	["UI/Coin"] = {
		["id"] = 135483737426662,
		["vol"] = 0.5,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "ui: shells gained"
	},
	["UI/Defeat"] = {
		["id"] = 125909120236588,
		["vol"] = 0.5,
		["src"] = "Out Alive (APM sting)"
	},
	["UI/Error"] = {
		["id"] = 87519554692663,
		["vol"] = 0.5,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "ui"
	},
	["UI/Fanfare"] = {
		["id"] = 9045751375,
		["vol"] = 0.5,
		["src"] = "Out Alive (APM sting)"
	},
	["UI/Hover"] = {
		["id"] = 10066931761,
		["vol"] = 0.5,
		["throttle"] = 0.05,
		["src"] = "Out Alive (Roblox UI)",
		["use"] = "ui"
	},
	["UI/LevelUp"] = {
		["id"] = 112485797063762,
		["vol"] = 0.5,
		["src"] = "Out Alive (Creator Store)",
		["use"] = "ui: results level up"
	},
	["UI/Notify"] = {
		["id"] = 15675085146,
		["vol"] = 0.5,
		["src"] = "Out Alive (Roblox UI)",
		["use"] = "ui: Notify toasts"
	},
	["UI/Open"] = {
		["id"] = 10128766965,
		["vol"] = 0.5,
		["src"] = "Out Alive (Roblox UI)",
		["use"] = "ui"
	},
	["UI/Purchase"] = {
		["id"] = 10066947742,
		["vol"] = 0.5,
		["src"] = "Out Alive (Roblox UI)",
		["use"] = "ui: armory purchase"
	},
	["UI/Select"] = {
		["id"] = 10128760939,
		["vol"] = 0.5,
		["src"] = "Out Alive (Roblox UI)",
		["use"] = "ui"
	},
	["UI/Stinger"] = {
		["id"] = 15675043410,
		["vol"] = 0.5,
		["src"] = "Out Alive (Roblox UI)"
	},
	["UI/Tick"] = {
		["id"] = 15675032796,
		["vol"] = 0.5,
		["throttle"] = 0.03,
		["src"] = "Out Alive (Roblox UI)"
	},
	["UI/Whoosh"] = {
		["id"] = 15675012262,
		["vol"] = 0.5,
		["src"] = "Out Alive (Roblox UI)",
		["use"] = "ui: panel slide"
	},
	["Music/Raid_Drop"] = {
		["id"] = 1841408135,
		["vol"] = 0.45,
		["src"] = "Out Alive (APM)"
	},
	["Music/Raid_Tension"] = {
		["id"] = 9043585893,
		["vol"] = 0.9,
		["looped"] = true,
		["src"] = "Out Alive (APM)"
	},
	["Ambience/Fire_Emitter"] = {
		["id"] = 9112780193,
		["vol"] = 1.5,
		["looped"] = true,
		["roll"] = nil,
		["src"] = "PSE Fireplace Constant Burning Flame 1",
		["use"] = "audio: 3D crackle on lobby fires/torches",
		["roll"] = v2.emitter
	},
	["Ambience/Lobby_Crowd"] = {
		["id"] = 9112885241,
		["vol"] = 3,
		["looped"] = true,
		["src"] = "Out Alive (PSE Theater Crowd)"
	},
	["Ambience/Lobby_Fire"] = {
		["id"] = 9112780193,
		["vol"] = 1,
		["looped"] = true,
		["src"] = "PSE Fireplace Constant Burning Flame 1",
		["use"] = "audio: lobby campfire bed"
	},
	["Ambience/Lobby_Wind"] = {
		["id"] = 5799870105,
		["vol"] = 1.2,
		["looped"] = true,
		["src"] = "Out Alive (Creator Store \'Ambient wind\')",
		["use"] = "audio: lobby gentle wind"
	},
	["Ambience/Raid_Birds"] = {
		["id"] = 9112749254,
		["vol"] = 3,
		["looped"] = true,
		["src"] = "PSE Birds Park 1",
		["use"] = "audio: lobby birds"
	},
	["Ambience/Raid_Forest"] = {
		["id"] = 9112781689,
		["vol"] = 8,
		["looped"] = true,
		["src"] = "PSE Forest Ambience 2",
		["use"] = "audio: default map bed"
	},
	["Ambience/Raid_HighWind"] = {
		["id"] = 9112832297,
		["vol"] = 1.2,
		["looped"] = true,
		["src"] = "PSE Mountain Birds 2",
		["use"] = "audio: Frostfang layer"
	},
	["Ambience/Raid_Water"] = {
		["id"] = 9120552671,
		["vol"] = 0.35,
		["looped"] = true,
		["src"] = "PSE Waterfall Steady Stream 2"
	},
	["ShortBow_Draw"] = {
		["id"] = 126901578730722,
		["vol"] = 0.55,
		["roll"] = nil,
		["src"] = "AB Weapons/Bow/b_Bow_Charge.wav",
		["use"] = "combat: short_bow draw start",
		["roll"] = v2.melee
	},
	["ShortBow_Fire"] = {
		["id"] = 92086615499961,
		["vol"] = 0.8,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "AB Weapons/Bow/b_Bow_Shot_Single_01.wav",
		["use"] = "combat: short_bow release",
		["roll"] = v2.bow
	},
	["Longbow_Draw"] = {
		["id"] = 126901578730722,
		["vol"] = 0.6,
		["pitch"] = 0.72,
		["roll"] = nil,
		["src"] = "AB b_Bow_Charge.wav (slowed for the 1.1 s draw)",
		["use"] = "combat: longbow draw start",
		["roll"] = v2.melee
	},
	["Longbow_Fire"] = {
		["id"] = 102348991811317,
		["vol"] = 0.9,
		["pitch"] = 0.9,
		["roll"] = nil,
		["jitter"] = 0.04,
		["layers"] = nil,
		["src"] = "BW weapons/bow/new_bow_fire.ogg (+ ShortBow_Fire layer)",
		["use"] = "combat: longbow release",
		["roll"] = v2.bow,
		["layers"] = {
			{ "ShortBow_Fire", 0.45 }
		}
	},
	["Arrow_Thunk"] = {
		["id"] = 76369685858365,
		["vol"] = 0.7,
		["roll"] = nil,
		["src"] = "AB Weapons/Bow/b_Bow_Arrow_Hit_Block.wav",
		["use"] = "combat: arrow/bolt sticks in wood or stone",
		["roll"] = v2.impact
	},
	["Crossbow_Crank"] = {
		["id"] = 73130229405839,
		["vol"] = 0.6,
		["roll"] = nil,
		["src"] = "AB Weapons/Crossbow/b_Crossbow_Charge_01.wav",
		["use"] = "combat: crossbow reload (with Crossbow_Reload)",
		["roll"] = v2.melee
	},
	["Crossbow_Ready"] = {
		["id"] = 71569456500667,
		["vol"] = 0.5,
		["roll"] = nil,
		["jitter"] = 0.02,
		["src"] = "AB Weapons/Crossbow/b_Crossbow_OffCooldown_01.wav",
		["use"] = "combat: crossbow loaded",
		["roll"] = v2.melee
	},
	["Musket_Fire"] = {
		["id"] = 140278314632008,
		["vol"] = 1,
		["roll"] = nil,
		["jitter"] = 0.04,
		["throttle"] = 0.05,
		["src"] = "BW weapons/sniper/sniper_fire.ogg",
		["use"] = "combat: musket shot",
		["roll"] = v2.gun
	},
	["Blunderbuss_Fire"] = {
		["id"] = 135577867864343,
		["vol"] = 1,
		["roll"] = nil,
		["jitter"] = 0.04,
		["throttle"] = 0.05,
		["src"] = "BW weapons/blunderbuss/blunderbuss_shoot.ogg",
		["use"] = "combat: blunderbuss shot",
		["roll"] = v2.gun
	},
	["Flintlock_Fire"] = {
		["id"] = 98876672349966,
		["vol"] = 0.9,
		["roll"] = nil,
		["jitter"] = 0.05,
		["throttle"] = 0.05,
		["src"] = "BW kits/gun_blade/gun_blade_shot.ogg",
		["use"] = "combat: flintlock shot",
		["roll"] = v2.gun
	},
	["Gun_Cock"] = {
		["id"] = 140587929894820,
		["vol"] = 0.6,
		["roll"] = nil,
		["jitter"] = 0.03,
		["src"] = "BW kits/gun_blade/gun_blade_trigger.ogg",
		["use"] = "combat: black-powder reload finished (hammer cocked)",
		["roll"] = v2.melee
	},
	["Musket_Ramrod"] = {
		["id"] = 9113454517,
		["vol"] = 0.55,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "PSE Blade Scrape Slide Metal Rod Against Knife 3",
		["use"] = "Musket_Reload sequence",
		["roll"] = v2.melee
	},
	["Musket_Ramrod_Tap"] = {
		["id"] = 9113449143,
		["vol"] = 0.45,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "PSE Blade Hits Metal Rod On Knife Impacts 1",
		["use"] = "Musket_Reload sequence",
		["roll"] = v2.melee
	},
	["Musket_Reload"] = {
		["id"] = 9113454517,
		["vol"] = 0.55,
		["roll"] = nil,
		["sequence"] = nil,
		["src"] = "PSE rod scrape + taps (a 1.8 s ramrod sequence)",
		["use"] = "combat: musket reload start (then Gun_Cock at the end)",
		["roll"] = v2.melee,
		["sequence"] = {
			{ "Musket_Ramrod_Tap", 0.75 },
			{
				"Musket_Ramrod_Tap",
				1.05,
				0.8,
				1.1
			},
			{
				"Musket_Ramrod",
				1.35,
				0.8,
				1.15
			}
		}
	},
	["Blunderbuss_Reload"] = {
		["id"] = 9113454517,
		["vol"] = 0.5,
		["pitch"] = 0.85,
		["roll"] = nil,
		["sequence"] = nil,
		["src"] = "PSE rod scrape + tap, lower",
		["use"] = "combat: blunderbuss reload start (then Gun_Cock)",
		["roll"] = v2.melee,
		["sequence"] = {
			{
				"Musket_Ramrod_Tap",
				0.7,
				0.9,
				0.85
			}
		}
	},
	["Flintlock_Reload"] = {
		["id"] = 9113454517,
		["vol"] = 0.45,
		["pitch"] = 1.25,
		["roll"] = nil,
		["sequence"] = nil,
		["src"] = "PSE rod scrape + tap, higher",
		["use"] = "combat: flintlock reload start (then Gun_Cock)",
		["roll"] = v2.melee,
		["sequence"] = {
			{
				"Musket_Ramrod_Tap",
				0.55,
				0.8,
				1.25
			}
		}
	},
	["Equip_Gun"] = {
		["id"] = 140587929894820,
		["vol"] = 0.4,
		["pitch"] = 1.1,
		["roll"] = nil,
		["src"] = "BW gun_blade_trigger.ogg",
		["use"] = "combat: equip musket/flintlock/blunderbuss",
		["roll"] = v2.melee
	},
	["Knife_Throw"] = {
		["id"] = 120195513115090,
		["vol"] = 0.65,
		["pitch"] = 1.1,
		["roll"] = nil,
		["jitter"] = 0.07,
		["src"] = "BW kits/ninja/ninja_chakram_throw_1.ogg",
		["use"] = "combat: throwing knife release",
		["roll"] = v2.bow
	},
	["Knife_Hit"] = {
		["id"] = 77184284707707,
		["vol"] = 0.75,
		["roll"] = nil,
		["jitter"] = 0.06,
		["src"] = "BW kits/ninja/ninja_chakram_hit_player_1.ogg",
		["use"] = "combat: knife into a body",
		["roll"] = v2.hit
	},
	["Knife_Thunk"] = {
		["id"] = 133716837404893,
		["vol"] = 0.6,
		["roll"] = nil,
		["jitter"] = 0.06,
		["src"] = "BW kits/ninja/ninja_chakram_hit_block_1.ogg",
		["use"] = "combat: knife sticks in the world",
		["roll"] = v2.impact
	},
	["Knife_Ready"] = {
		["id"] = 80258412716795,
		["vol"] = 0.4,
		["roll"] = nil,
		["jitter"] = 0,
		["src"] = "BW weapons/dagger/dagger_ready.ogg",
		["use"] = "combat: a knife charge regenerated (local only)",
		["roll"] = v2.melee
	},
	["Javelin_Throw"] = {
		["id"] = 96719407120432,
		["vol"] = 0.8,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "BW weapons/spear/spear_throw.ogg",
		["use"] = "combat: javelin release",
		["roll"] = v2.bow
	},
	["Javelin_Draw"] = {
		["id"] = 131969177643108,
		["vol"] = 0.45,
		["pitch"] = 0.75,
		["roll"] = nil,
		["src"] = "Out Alive Throw_Windup (Creator Store)",
		["use"] = "combat: javelin wind-up",
		["roll"] = v2.melee
	},
	["Sling_Whirl"] = {
		["id"] = 97518847590368,
		["vol"] = 0.45,
		["pitch"] = 1.2,
		["looped"] = true,
		["roll"] = nil,
		["src"] = "BW weapons/lasso/lasso_swing.ogg",
		["use"] = "combat: Sfx.Loop while the sling is held ready / firing",
		["roll"] = v2.melee
	},
	["Sling_Fire"] = {
		["id"] = 103632917862016,
		["vol"] = 0.75,
		["roll"] = nil,
		["jitter"] = 0.07,
		["src"] = "AB Weapons/Slingshot/b_Slingshot_Shot_01.wav",
		["use"] = "combat: sling release",
		["roll"] = v2.bow
	},
	["Stone_Hit"] = {
		["id"] = 132504023010884,
		["vol"] = 0.8,
		["pitch"] = 1.1,
		["roll"] = nil,
		["src"] = "Out Alive Hit_Punch (Creator Store)",
		["use"] = "combat: sling stone into a body",
		["roll"] = v2.hit
	},
	["Sword_Swing"] = {
		["variants"] = nil,
		["vol"] = 0.7,
		["roll"] = nil,
		["jitter"] = 0.06,
		["src"] = "AB Weapons/Sword/b_Sword_Swing_Iron_01/02.wav",
		["use"] = "combat: bronze_sword swing",
		["variants"] = {
			{ "Sword_Swing_1", 138006253867986 },
			{ "Sword_Swing_2", 95793369699102 }
		},
		["roll"] = v2.melee
	},
	["Sword_Hit"] = {
		["variants"] = nil,
		["vol"] = 0.85,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "AB Weapons/Sword/b_Sword_Hit_01/02.wav",
		["use"] = "combat: sword hits a body",
		["variants"] = {
			{ "Sword_Hit_1", 132627523631533 },
			{ "Sword_Hit_2", 138796106344811 }
		},
		["roll"] = v2.hit
	},
	["Equip_Sword"] = {
		["id"] = 124813359023958,
		["vol"] = 0.5,
		["roll"] = nil,
		["src"] = "AB Weapons/Sword/b_Sword_Equip.wav",
		["use"] = "combat: equip bronze_sword",
		["roll"] = v2.melee
	},
	["Axe_Swing"] = {
		["id"] = 92204765901636,
		["vol"] = 0.75,
		["pitch"] = 1.1,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "AB Weapons/Warhammer/b_Warhammer_Swing_Iron_01.wav",
		["use"] = "combat: axe light swing",
		["roll"] = v2.melee
	},
	["Axe_Heavy"] = {
		["id"] = 121263146891457,
		["vol"] = 0.85,
		["roll"] = nil,
		["jitter"] = 0.03,
		["src"] = "BW weapons/sledgehammer/sledgehammer_swing.ogg",
		["use"] = "combat: axe charged overhead release",
		["roll"] = v2.melee
	},
	["Axe_Hit"] = {
		["id"] = 115836679271430,
		["vol"] = 0.9,
		["roll"] = nil,
		["jitter"] = 0.05,
		["layers"] = nil,
		["src"] = "AB Weapons/Warhammer/b_Warhammer_Hit_01.wav (+ Hit_Melee_Heavy)",
		["use"] = "combat: axe hits a body",
		["roll"] = v2.hit,
		["layers"] = {
			{ "Hit_Melee_Heavy", 0.5 }
		}
	},
	["Melee_Charge"] = {
		["id"] = 81514395642268,
		["vol"] = 0.55,
		["roll"] = nil,
		["jitter"] = 0,
		["src"] = "AB Weapons/Sword/b_Sword_Alt_Charge.wav",
		["use"] = "combat: axe charge start",
		["roll"] = v2.melee
	},
	["Spear_Stab"] = {
		["id"] = 99029938714428,
		["vol"] = 0.75,
		["roll"] = nil,
		["jitter"] = 0.06,
		["src"] = "BW weapons/spear/spear_stab_1.ogg",
		["use"] = "combat: spear stab",
		["roll"] = v2.melee
	},
	["Spear_Charge"] = {
		["id"] = 86042464991708,
		["vol"] = 0.55,
		["roll"] = nil,
		["jitter"] = 0,
		["src"] = "BW weapons/spear/spear_charge.ogg",
		["use"] = "combat: spear lunge charge",
		["roll"] = v2.melee
	},
	["Spear_Lunge"] = {
		["id"] = 128001816559066,
		["vol"] = 0.8,
		["roll"] = nil,
		["jitter"] = 0.04,
		["layers"] = nil,
		["src"] = "AB Weapons/Sword/b_Sword_Alt_Lunge.wav (+ Lunge)",
		["use"] = "combat: spear charged lunge release",
		["roll"] = v2.melee,
		["layers"] = {
			{ "Lunge", 0.6 }
		}
	},
	["Spear_Hit"] = {
		["id"] = 72220943963461,
		["vol"] = 0.85,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "BW weapons/spear/spear_hit.ogg",
		["use"] = "combat: spear / javelin hits a body",
		["roll"] = v2.hit
	},
	["Dagger_Swing"] = {
		["variants"] = nil,
		["vol"] = 0.65,
		["roll"] = nil,
		["jitter"] = 0.07,
		["src"] = "BW weapons/dagger/dagger_swing_1/2.ogg",
		["use"] = "combat: dagger slash",
		["variants"] = {
			{ "Dagger_Swing_1", 127692867370593 },
			{ "Dagger_Swing_2", 92827046997594 }
		},
		["roll"] = v2.melee
	},
	["Dagger_Hit"] = {
		["id"] = 104694053505293,
		["vol"] = 0.7,
		["pitch"] = 1.15,
		["roll"] = nil,
		["jitter"] = 0.06,
		["src"] = "Out Alive Hit_Melee (Creator Store)",
		["use"] = "combat: dagger hits a body",
		["roll"] = v2.hit
	},
	["Backstab"] = {
		["id"] = 125346458541650,
		["vol"] = 0.85,
		["roll"] = nil,
		["jitter"] = 0.02,
		["src"] = "BW gameplay/combat/critical_strike.ogg",
		["use"] = "combat: dagger backstab bonus hit",
		["roll"] = v2.hit
	},
	["Club_Swing"] = {
		["id"] = 93423984902098,
		["vol"] = 0.75,
		["pitch"] = 0.95,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "AB Weapons/Warhammer/b_Warhammer_Swing_Wood_01.wav",
		["use"] = "combat: club swing",
		["roll"] = v2.melee
	},
	["Club_Hit"] = {
		["id"] = 82989963513270,
		["vol"] = 0.9,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "BW weapons/sledgehammer/sledgehammer_impact_1.ogg",
		["use"] = "combat: club hits a body (stagger)",
		["roll"] = v2.hit
	},
	["FireBomb_Fuse"] = {
		["id"] = 90890459599929,
		["vol"] = 0.45,
		["looped"] = true,
		["roll"] = nil,
		["src"] = "AB Items/TNT/b_Item_TNT_Hiss_01.wav",
		["use"] = "combat: Sfx.Loop on the pot while drawn / in flight",
		["roll"] = v2.util
	},
	["FireBomb_Throw"] = {
		["id"] = 99843224727823,
		["vol"] = 0.7,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "AB Items/Fireball/b_Fireball_Throw_01.wav",
		["use"] = "combat: fire bomb release",
		["roll"] = v2.bow
	},
	["FireBomb_Shatter"] = {
		["id"] = 123752499371730,
		["vol"] = 0.8,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "BW gameplay/environmental_debris/pot_break.ogg",
		["use"] = "FireBomb_Explode layer",
		["roll"] = v2.boom
	},
	["FireBomb_Explode"] = {
		["id"] = 90729400777581,
		["vol"] = 1,
		["roll"] = nil,
		["jitter"] = 0.04,
		["layers"] = nil,
		["src"] = "BW weapons/fireball/fireball_explode.ogg + pot_break",
		["use"] = "combat: fire bomb shatters in flame",
		["roll"] = v2.boom,
		["layers"] = {
			{ "FireBomb_Shatter", 1 }
		}
	},
	["Burn_Loop"] = {
		["id"] = 96751085201244,
		["vol"] = 0.5,
		["looped"] = true,
		["roll"] = nil,
		["src"] = "BW gameplay/status_effects/burn_loop.ogg",
		["use"] = "combat: Sfx.Loop on a burning fighter",
		["roll"] = v2.loop
	},
	["Smoke_Pop"] = {
		["id"] = 94373991380707,
		["vol"] = 0.9,
		["roll"] = nil,
		["jitter"] = 0.04,
		["src"] = "BW kits/smoke/smoke_grenade_pop.ogg",
		["use"] = "combat: smoke bomb bursts",
		["roll"] = v2.boom
	},
	["Smoke_Hiss_Loop"] = {
		["id"] = 120580003478085,
		["vol"] = 0.4,
		["looped"] = true,
		["roll"] = nil,
		["src"] = "BW kits/smoke/smoke_grenade_emit_loop.ogg",
		["use"] = "combat: Sfx.Loop in the cloud for its 7 s",
		["roll"] = v2.util
	},
	["Herbs_Chew"] = {
		["id"] = 106260674804740,
		["vol"] = 0.6,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "BW gameplay/consumables/eat_food_1.ogg",
		["use"] = "combat: herbs use (0.6 s)",
		["roll"] = v2.util
	},
	["Herbs_Heal"] = {
		["id"] = 77670435116945,
		["vol"] = 0.45,
		["roll"] = nil,
		["jitter"] = 0.03,
		["src"] = "BW kits/nyoka/nyoka_heal_applied_0.ogg",
		["use"] = "combat: heal-over-time starts (then Heal_Done)",
		["roll"] = v2.util
	},
	["Trap_Set"] = {
		["id"] = 128283214623159,
		["vol"] = 0.6,
		["roll"] = nil,
		["src"] = "BW kits/trapper/snap_trap_setup.ogg",
		["use"] = "combat: trap placed (owner + allies only: it\'s hidden)",
		["roll"] = v2.util
	},
	["Trap_Armed"] = {
		["id"] = 71569456500667,
		["vol"] = 0.35,
		["pitch"] = 0.8,
		["roll"] = nil,
		["jitter"] = 0,
		["src"] = "AB b_Crossbow_OffCooldown_01.wav (lower)",
		["use"] = "combat: trap armed click (owner only)",
		["roll"] = v2.util
	},
	["Trap_Snap"] = {
		["id"] = 106775818947002,
		["vol"] = 1,
		["roll"] = nil,
		["jitter"] = 0.03,
		["layers"] = nil,
		["src"] = "BW kits/trapper/snap_trap_close.ogg (+ Hit_Melee_Heavy)",
		["use"] = "combat: trap snaps on a victim",
		["roll"] = v2.hit,
		["layers"] = {
			{ "Hit_Melee_Heavy", 0.45 }
		}
	},
	["War_Horn"] = {
		["id"] = 4624851445,
		["vol"] = 2,
		["roll"] = nil,
		["src"] = "Creator Store \'War Horn Sound Effect\' (InfiniteGalaxiiBoy, public, 5.1 s)",
		["use"] = "combat: the war horn, heard across the arena",
		["roll"] = v2.boom
	},
	["Harpoon_Throw"] = {
		["id"] = 95585309549157,
		["vol"] = 0.9,
		["roll"] = nil,
		["jitter"] = 0.04,
		["src"] = "BW kits/harpoon/harpoon_throw.ogg",
		["use"] = "combat: harpoon release",
		["roll"] = v2.bow
	},
	["Harpoon_Hit"] = {
		["id"] = 95621512446636,
		["vol"] = 0.95,
		["roll"] = nil,
		["jitter"] = 0.04,
		["src"] = "BW kits/harpoon/harpoon_hit_enemy.ogg",
		["use"] = "combat: harpoon into a body (then the drag)",
		["roll"] = v2.hit
	},
	["Harpoon_Thunk"] = {
		["id"] = 108001786869670,
		["vol"] = 0.8,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "BW kits/harpoon/harpoon_hit_part.ogg",
		["use"] = "combat: harpoon into the world",
		["roll"] = v2.impact
	},
	["Gauntlet_Swing"] = {
		["id"] = 74248579135630,
		["vol"] = 0.6,
		["pitch"] = 1.18,
		["roll"] = nil,
		["jitter"] = 0.08,
		["src"] = "Out Alive Swing_Punch (Creator Store)",
		["use"] = "combat: gauntlet punch whoosh",
		["roll"] = v2.melee
	},
	["Gauntlet_Hit"] = {
		["id"] = 132504023010884,
		["vol"] = 0.85,
		["pitch"] = 1.05,
		["roll"] = nil,
		["jitter"] = 0.07,
		["layers"] = nil,
		["src"] = "Out Alive Hit_Punch + BW sledgehammer impact",
		["use"] = "combat: gauntlet punch into a body",
		["roll"] = v2.hit,
		["layers"] = {
			{ "Club_Hit", 0.35 }
		}
	},
	["Gauntlet_Dash"] = {
		["id"] = 119573908217733,
		["vol"] = 0.75,
		["pitch"] = 1.15,
		["roll"] = nil,
		["jitter"] = 0.04,
		["layers"] = nil,
		["src"] = "Out Alive Lunge (Creator Store)",
		["use"] = "combat: gauntlets dash punch",
		["roll"] = v2.melee,
		["layers"] = {
			{ "Gauntlet_Swing", 0.8 }
		}
	},
	["Gauntlet_Equip"] = {
		["id"] = 7886392785,
		["vol"] = 0.5,
		["pitch"] = 1.25,
		["roll"] = nil,
		["layers"] = nil,
		["src"] = "Out Alive Equip_Heavy (Creator Store)",
		["use"] = "combat: gauntlets drawn (fists knocked together)",
		["roll"] = v2.melee,
		["layers"] = {
			{ "Hit_Punch", 0.25 }
		}
	},
	["Scythe_Swing"] = {
		["id"] = 92204765901636,
		["vol"] = 0.8,
		["pitch"] = 0.82,
		["roll"] = nil,
		["jitter"] = 0.05,
		["layers"] = nil,
		["src"] = "AB Weapons/Warhammer/b_Warhammer_Swing_Iron_01.wav, slowed",
		["use"] = "combat: scythe sweep",
		["roll"] = v2.melee,
		["layers"] = {
			{ "Swing_Heavy", 0.45 }
		}
	},
	["Scythe_Hit"] = {
		["id"] = 132627523631533,
		["vol"] = 0.9,
		["pitch"] = 0.82,
		["roll"] = nil,
		["jitter"] = 0.05,
		["layers"] = nil,
		["src"] = "AB Weapons/Sword/b_Sword_Hit_01.wav, lower",
		["use"] = "combat: scythe blade into a body",
		["roll"] = v2.hit,
		["layers"] = {
			{ "Hit_Melee_Heavy", 0.45 }
		}
	},
	["Scythe_Reap"] = {
		["id"] = 121263146891457,
		["vol"] = 0.9,
		["pitch"] = 0.86,
		["roll"] = nil,
		["jitter"] = 0.03,
		["layers"] = nil,
		["src"] = "BW weapons/sledgehammer/sledgehammer_swing.ogg, slowed",
		["use"] = "combat: the scythe\'s reaping dash",
		["roll"] = v2.melee,
		["layers"] = {
			{ "Scythe_Swing", 0.6 }
		}
	},
	["Scythe_Drag"] = {
		["id"] = 95621512446636,
		["vol"] = 0.7,
		["pitch"] = 1.1,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "BW kits/harpoon/harpoon_hit_enemy.ogg",
		["use"] = "combat: (unused since the scythe\'s reaping dash replaced the reap\'s pull)",
		["roll"] = v2.hit
	},
	["Caltrops_Scatter"] = {
		["id"] = 102462537156803,
		["vol"] = 0.75,
		["pitch"] = 1.15,
		["roll"] = nil,
		["jitter"] = 0.06,
		["layers"] = nil,
		["sequence"] = nil,
		["src"] = "Impact_Metal + knife thunks (uploaded / public)",
		["use"] = "combat: the caltrops bag bursts, spikes clatter",
		["roll"] = v2.util,
		["layers"] = {
			{ "Knife_Thunk", 0.55 },
			{ "Trap_Armed", 0.5 }
		},
		["sequence"] = {
			{
				"Knife_Thunk",
				0.09,
				0.4,
				1.25
			},
			{
				"Impact_Metal",
				0.16,
				0.35,
				1.35
			}
		}
	},
	["Caltrops_Step"] = {
		["id"] = 77184284707707,
		["vol"] = 0.7,
		["pitch"] = 1.3,
		["roll"] = nil,
		["jitter"] = 0.08,
		["layers"] = nil,
		["throttle"] = 0.2,
		["src"] = "BW knife hit, higher",
		["use"] = "combat: an enemy steps on caltrops",
		["roll"] = v2.hit,
		["layers"] = {
			{ "Impact_Metal", 0.25 }
		}
	},
	["Katana_Draw"] = {
		["id"] = 96383198624136,
		["vol"] = 0.6,
		["roll"] = nil,
		["src"] = "BW kits/hannah/hannah_unsheath_sword.ogg",
		["use"] = "combat: katana drawn",
		["roll"] = v2.melee
	},
	["Katana_Swing"] = {
		["variants"] = nil,
		["vol"] = 0.7,
		["pitch"] = 1.05,
		["roll"] = nil,
		["jitter"] = 0.06,
		["src"] = "BW weapons/rapier/hero_rapier_swing_1/2.ogg",
		["use"] = "combat: katana cut",
		["variants"] = {
			{ "Katana_Swing_1", 124233585285712 },
			{ "Katana_Swing_2", 135894941077717 }
		},
		["roll"] = v2.melee
	},
	["Katana_Hit"] = {
		["id"] = 72441375900713,
		["vol"] = 0.85,
		["roll"] = nil,
		["jitter"] = 0.05,
		["layers"] = nil,
		["src"] = "BW weapons/rapier/rapier_hit_1.ogg + the sword\'s hit",
		["use"] = "combat: katana into a body",
		["roll"] = v2.hit,
		["layers"] = {
			{ "Sword_Hit", 0.35 }
		}
	},
	["Katana_Flick"] = {
		["id"] = 96236471072156,
		["vol"] = 0.6,
		["pitch"] = 1.15,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "BW weapons/rapier/hero_rapier_thrust_1.ogg, higher",
		["use"] = "combat: katana parry raised",
		["roll"] = v2.melee
	},
	["Katana_Parry"] = {
		["id"] = 90770813773453,
		["vol"] = 0.95,
		["roll"] = nil,
		["jitter"] = 0.04,
		["layers"] = nil,
		["src"] = "BW kits/sword_shield/iron_shield_reactive.ogg + metal",
		["use"] = "combat: a melee hit parried (clang)",
		["roll"] = v2.hit,
		["layers"] = {
			{ "Impact_Metal", 0.45 }
		}
	},
	["Katana_Deflect"] = {
		["id"] = 130589277512304,
		["vol"] = 0.95,
		["roll"] = nil,
		["jitter"] = 0.04,
		["layers"] = nil,
		["src"] = "BW weapons/scissor_sword/scissor_sword_projectile_intercept.ogg",
		["use"] = "combat: a projectile turned by a parry",
		["roll"] = v2.hit,
		["layers"] = {
			{ "Katana_Parry", 0.4 }
		}
	},
	["Hatchet_Swing"] = {
		["variants"] = nil,
		["vol"] = 0.65,
		["pitch"] = 0.86,
		["roll"] = nil,
		["jitter"] = 0.07,
		["src"] = "BW weapons/dagger/dagger_swing_1/2.ogg, lower",
		["use"] = "combat: hatchet chop whoosh",
		["variants"] = {
			{ "Dagger_Swing_1", 127692867370593 },
			{ "Dagger_Swing_2", 92827046997594 }
		},
		["roll"] = v2.melee
	},
	["Hatchet_Hit"] = {
		["id"] = 105022540107750,
		["vol"] = 0.85,
		["roll"] = nil,
		["jitter"] = 0.06,
		["layers"] = nil,
		["src"] = "BW weapons/rainbow_axe/rainbow_axe_hit_1.ogg + the axe\'s",
		["use"] = "combat: hatchet into a body",
		["roll"] = v2.hit,
		["layers"] = {
			{ "Axe_Hit", 0.3 }
		}
	},
	["Hatchet_Throw"] = {
		["id"] = 96719407120432,
		["vol"] = 0.8,
		["pitch"] = 1.15,
		["roll"] = nil,
		["jitter"] = 0.05,
		["layers"] = nil,
		["src"] = "BW weapons/spear/spear_throw.ogg (the javelin\'s), higher + the heavy swing whoosh",
		["use"] = "combat: a hatchet thrown",
		["roll"] = v2.bow,
		["layers"] = {
			{ "Swing_Heavy", 0.35 }
		}
	},
	["Hatchet_Spin"] = {
		["id"] = 119793433876308,
		["vol"] = 0.45,
		["looped"] = true,
		["roll"] = nil,
		["src"] = "BW weapons/bananarang/bananarang_flying_loop.ogg",
		["use"] = "combat: Sfx.Loop on a hatchet in flight",
		["roll"] = v2.loop
	},
	["Hatchet_Thunk"] = {
		["id"] = 133716837404893,
		["vol"] = 0.85,
		["pitch"] = 0.8,
		["roll"] = nil,
		["jitter"] = 0.05,
		["layers"] = nil,
		["src"] = "BW ninja chakram block hit, lower + axe",
		["use"] = "combat: a thrown hatchet sticks in the world",
		["roll"] = v2.impact,
		["layers"] = {
			{ "Axe_Hit", 0.4 }
		}
	},
	["Hatchet_Catch"] = {
		["id"] = 140017396799829,
		["vol"] = 0.6,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "BW kits/ninja/ninja_chakram_return_1.ogg",
		["use"] = "combat: a thrown hatchet back in hand / the hatchets drawn",
		["roll"] = v2.melee
	},
	["Beehive_Break"] = {
		["id"] = 126752109621089,
		["vol"] = 0.85,
		["roll"] = nil,
		["jitter"] = 0.05,
		["src"] = "BW kits/queen_bee/beehive_grenade_explode.ogg",
		["use"] = "combat: the beehive breaks, the swarm comes out",
		["roll"] = v2.util
	},
	["Bees_Loop"] = {
		["id"] = 110990152136243,
		["vol"] = 0.55,
		["looped"] = true,
		["roll"] = nil,
		["src"] = "BW kits/beekeeper/bee_loop.ogg",
		["use"] = "combat: Sfx.Loop on a swarm / the skep in hand",
		["roll"] = v2.loop
	},
	["Bees_Angry"] = {
		["id"] = 80629211664979,
		["vol"] = 0.7,
		["roll"] = nil,
		["jitter"] = 0.08,
		["throttle"] = 0.35,
		["region"] = nil,
		["fade"] = 0.25,
		["src"] = "BW kits/beekeeper/angry_bee.ogg, its first 0.6 s",
		["use"] = "combat: a swarm stings (the victim)",
		["roll"] = v2.hit,
		["region"] = { 0, 0.6 }
	},
	["Hitmarker"] = {
		["id"] = 86056933612310,
		["vol"] = 0.6,
		["jitter"] = 0.03,
		["throttle"] = 0.03,
		["src"] = "AB Combat/b_Damage_Hitmarker.wav (Out Alive\'s is Hitmarker_Classic)",
		["use"] = "combat: HitConfirm, melee / any hit"
	},
	["Hitmarker_Ranged"] = {
		["id"] = 131134487230797,
		["vol"] = 0.55,
		["jitter"] = 0.03,
		["throttle"] = 0.03,
		["src"] = "AB Combat/b_Damage_Hitmarker_Projectile.wav",
		["use"] = "combat: HitConfirm, projectile body hit"
	},
	["Hitmarker_Headshot"] = {
		["id"] = 75401679275066,
		["vol"] = 0.6,
		["jitter"] = 0,
		["throttle"] = 0.03,
		["src"] = "mix: AB b_Damage_Hitmarker.wav + BW combat/damage_hit_hard.ogg + BW combat/headshot.ogg",
		["use"] = "combat: HitConfirm headshot (not a kill)"
	},
	["Hitmarker_Crit"] = {
		["id"] = 140141851399717,
		["vol"] = 0.7,
		["jitter"] = 0,
		["throttle"] = 0.03,
		["src"] = "AB Combat/b_Damage_Hitmarker_Projectile_Headshot.wav",
		["use"] = "combat: HitConfirm crit of a weapon without a critSound (the headshot sound until 2026-10-18)"
	},
	["Kill_Confirm"] = {
		["id"] = 110518245960492,
		["vol"] = 0.75,
		["jitter"] = 0,
		["throttle"] = 0.1,
		["priority"] = true,
		["src"] = "AB Combat/Kill/b_Kill_Player_01.wav",
		["use"] = "combat: HitConfirm killed = true"
	},
	["Kill_Confirm_Headshot"] = {
		["id"] = 119005221786699,
		["vol"] = 0.9,
		["jitter"] = 0,
		["throttle"] = 0.1,
		["priority"] = true,
		["src"] = "mix: the headshot confirm (fuller ring), then AB Kill/b_Kill_Player_01.wav at +0.1 s",
		["use"] = "combat: HitConfirm killed + headshot (instead of Kill_Confirm)"
	},
	["Kill_Double"] = {
		["id"] = 83538874964605,
		["vol"] = 0.55,
		["jitter"] = 0,
		["priority"] = true,
		["src"] = "AB Combat/Kill/b_Kill_MultiOverlay_02_Double.wav",
		["use"] = "audio: 2nd kill in a round"
	},
	["Kill_Triple"] = {
		["id"] = 89431749742288,
		["vol"] = 0.6,
		["jitter"] = 0,
		["priority"] = true,
		["src"] = "AB Combat/Kill/b_Kill_MultiOverlay_03_Triple.wav",
		["use"] = "audio: 3rd kill in a round (ace)"
	},
	["Kill_Ally"] = {
		["id"] = 115356703887014,
		["vol"] = 0.4,
		["jitter"] = 0,
		["src"] = "AB Combat/Kill/b_Kill_AllyGet_01.wav",
		["use"] = "audio: a teammate got a kill"
	},
	["Damage_Receive"] = {
		["id"] = 90896645448330,
		["vol"] = 0.6,
		["jitter"] = 0.05,
		["throttle"] = 0.06,
		["priority"] = true,
		["src"] = "AB Combat/b_Damage_Receive.wav",
		["use"] = "combat: DamageTaken (amount < 30)"
	},
	["Damage_Receive_Heavy"] = {
		["id"] = 81948228534644,
		["vol"] = 0.7,
		["jitter"] = 0.04,
		["throttle"] = 0.06,
		["priority"] = true,
		["src"] = "AB Combat/b_Damage_Receive_Heavy.wav",
		["use"] = "combat: DamageTaken (amount >= 30)"
	},
	["LowHealth_Heartbeat"] = {
		["id"] = 119226227195420,
		["vol"] = 0.6,
		["looped"] = true,
		["jitter"] = 0,
		["src"] = "BW kits/beast/werewolf_heartbeat.ogg",
		["use"] = "audio: loop below 35 HP"
	},
	["Death"] = {
		["id"] = 122285072111730,
		["vol"] = 0.55,
		["jitter"] = 0,
		["region"] = nil,
		["fade"] = 1,
		["priority"] = true,
		["src"] = "AB Combat/Death/b_Death_01.wav (first 3 s)",
		["use"] = "audio: you were eliminated",
		["region"] = { 0, 3 }
	},
	["Teammate_Down"] = {
		["id"] = 129029029936603,
		["vol"] = 0.5,
		["jitter"] = 0,
		["src"] = "AB Combat/Death/b_Death_Ally_01.wav",
		["use"] = "audio: a teammate was eliminated"
	},
	["Match/Intro"] = {
		["id"] = 87412723628379,
		["vol"] = 0.6,
		["src"] = "AB Match/b_Game_RevealPlayers.wav",
		["use"] = "audio: MatchStart (VS screen)"
	},
	["Match/Spawn"] = {
		["id"] = 116555090631185,
		["vol"] = 0.35,
		["src"] = "AB Countdown/b_Game_SpawnPlayer_01.wav",
		["use"] = "audio: PreRound start (respawned)"
	},
	["Match/Countdown_3"] = {
		["id"] = 77226944088370,
		["vol"] = 0.55,
		["src"] = "BW ui/countdown/countdown_tick_3.ogg",
		["use"] = "audio: PreRound 3"
	},
	["Match/Countdown_2"] = {
		["id"] = 100633236510272,
		["vol"] = 0.55,
		["src"] = "BW ui/countdown/countdown_tick_2.ogg",
		["use"] = "audio: PreRound 2"
	},
	["Match/Countdown_1"] = {
		["id"] = 122664273445858,
		["vol"] = 0.6,
		["src"] = "BW ui/countdown/countdown_tick_1.ogg",
		["use"] = "audio: PreRound 1"
	},
	["Match/Countdown_Tick"] = {
		["id"] = 121527440781141,
		["vol"] = 0.45,
		["src"] = "BW ui/countdown/countdown_tick.ogg",
		["use"] = "generic countdown tick"
	},
	["Match/Fight"] = {
		["variants"] = nil,
		["vol"] = 0.7,
		["jitter"] = 0,
		["src"] = "APM Music x3 (Roblox-licensed, human composers) + BW countdown_gamestart",
		["use"] = "audio: Live starts",
		["variants"] = {
			{ "Fight_TribalSting", 1836741224 },
			{ "Fight_Timpani", 1846877523 },
			{ "Fight_GameStart", 130071938133363 },
			{ "Fight_Drums", 1840000986 }
		}
	},
	["Match/Fight_Drums"] = {
		["id"] = 1840000986,
		["vol"] = 0.6,
		["src"] = "APM Gauntlet (SFX): intense sting with stomping drums",
		["use"] = "Match/Fight layer"
	},
	["Match/Round_Win"] = {
		["id"] = 128146233770060,
		["vol"] = 0.6,
		["region"] = nil,
		["fade"] = 1.2,
		["src"] = "BW game_modes/pvp_arena/pvp_arena_round_win_cheer.ogg (first 4.5 s)",
		["use"] = "audio: RoundEnd, your tribe won",
		["region"] = { 0, 4.5 }
	},
	["Match/Round_Lose"] = {
		["id"] = 129326028062982,
		["vol"] = 0.6,
		["region"] = nil,
		["fade"] = 1.2,
		["src"] = "BW game_modes/pvp_arena/pvp_arena_round_end.ogg (first 4.5 s)",
		["use"] = "audio: RoundEnd, your tribe lost",
		["region"] = { 0, 4.5 }
	},
	["Match/Round_Draw"] = {
		["id"] = 129326028062982,
		["vol"] = 0.5,
		["pitch"] = 0.94,
		["region"] = nil,
		["fade"] = 1.2,
		["src"] = "BW pvp_arena_round_end.ogg (lower)",
		["use"] = "audio: RoundEnd, draw",
		["region"] = { 0, 4 }
	},
	["Match/Overtime_Warning"] = {
		["id"] = 9114820307,
		["vol"] = 0.7,
		["pitch"] = 0.9,
		["region"] = nil,
		["fade"] = 1,
		["layers"] = nil,
		["src"] = "PSE Horn Blow 6 (old conch shell) + Ring_Ignite",
		["use"] = "audio: Overtime (ring of fire)",
		["region"] = { 0, 4.5 },
		["layers"] = {
			{ "Match/Ring_Ignite", 1 }
		}
	},
	["Match/Ring_Ignite"] = {
		["id"] = 116659851001368,
		["vol"] = 0.65,
		["src"] = "BW gameplay/enchantments/fire_enchant_apply.ogg",
		["use"] = "Overtime_Warning layer"
	},
	["Match/Ring_Fire_Loop"] = {
		["id"] = 9112780462,
		["vol"] = 1.2,
		["pitch"] = 0.7,
		["looped"] = true,
		["src"] = "PSE Fireplace Constant Burning Flame 4 (slowed to a roar)",
		["use"] = "audio: 2D loop during Overtime, louder near/outside the ring"
	},
	["Match/Elimination"] = {
		["id"] = 114802634846689,
		["vol"] = 0.45,
		["jitter"] = 0,
		["src"] = "BW gameplay/match/kill.ogg",
		["use"] = "audio: your own elimination banner"
	},
	["Match/Final_Round"] = {
		["id"] = 131304880023328,
		["vol"] = 0.85,
		["pitch"] = 0.74,
		["jitter"] = 0,
		["src"] = "BW gameplay/lucky_blocks/lucky_block_slam.ogg (the drop reveal\'s landing slam, pitched down to a deep hit)",
		["use"] = "vfx: FINAL ROUND slams in (Screens/Decider)"
	},
	["Match/Tribe_Clash"] = {
		["id"] = 131304880023328,
		["vol"] = 0.8,
		["pitch"] = 0.82,
		["jitter"] = 0,
		["src"] = "BW lucky_block_slam.ogg (the drop reveal\'s landing slam), pitched down",
		["use"] = "ui: the TRIBE CLASH intro\'s crests colliding (Screens/Banners, 2026-10-11)"
	},
	["Match/Final_Heartbeat"] = {
		["id"] = 119226227195420,
		["vol"] = 1.2,
		["pitch"] = 0.94,
		["jitter"] = 0,
		["region"] = nil,
		["throttle"] = 0.2,
		["src"] = "BW kits/beast/werewolf_heartbeat.ogg (one lub-dub: its first 0.5 s)",
		["use"] = "vfx: each FINAL ROUND countdown digit (Screens/Decider)",
		["region"] = { 0, 0.5 }
	},
	["Match/Victory"] = {
		["id"] = 89143136685639,
		["vol"] = 0.7,
		["group"] = "Music",
		["src"] = "AB Match/b_Game_Victory.wav",
		["use"] = "audio: MatchEnd, won"
	},
	["Match/Defeat"] = {
		["id"] = 97253601264356,
		["vol"] = 0.65,
		["group"] = "Music",
		["src"] = "AB Match/b_Game_Defeat.wav",
		["use"] = "audio: MatchEnd, lost"
	},
	["Countdown_Tick"] = {
		["id"] = 121527440781141,
		["vol"] = 0.45,
		["group"] = "SFX",
		["src"] = "alias of Match/Countdown_Tick"
	},
	["Fight"] = {
		["id"] = 1840000986,
		["vol"] = 0.6,
		["src"] = "Out Alive\'s name: the drum sting (the horn is gone, 2026-10-09; nothing plays this)"
	},
	["UI/Tab"] = {
		["id"] = 10128760939,
		["vol"] = 0.4,
		["pitch"] = 1.12,
		["src"] = "Roblox UI Select (higher)",
		["use"] = "ui: tab switch"
	},
	["UI/Equip"] = {
		["id"] = 123152847708845,
		["vol"] = 0.45,
		["region"] = nil,
		["fade"] = 0.4,
		["src"] = "AB UI/Kit Selection Menu/b_UI_Kits_SelectKit_Generic.wav (first 1.2 s)",
		["use"] = "ui: loadout slot set",
		["region"] = { 0, 1.2 }
	},
	["UI/Unlock"] = {
		["id"] = 71081057733937,
		["vol"] = 0.55,
		["src"] = "AB UI/Kit Selection Menu/Unlock/b_UI_Kits_Unlock_100Percent.wav",
		["use"] = "ui: weapon unlocked"
	},
	["UI/Queue_Join"] = {
		["id"] = 134754357615530,
		["vol"] = 0.5,
		["src"] = "AB UI/b_UI_Queue_Start.wav",
		["use"] = "ui/lobby: joined a pad side / Quick Play"
	},
	["UI/Queue_Leave"] = {
		["id"] = 10066914500,
		["vol"] = 0.45,
		["pitch"] = 0.88,
		["src"] = "Roblox UI Back (lower)",
		["use"] = "ui/lobby: left a pad"
	},
	["UI/Pad_Tick"] = {
		["id"] = 121527440781141,
		["vol"] = 0.35,
		["pitch"] = 1.05,
		["throttle"] = 0.2,
		["src"] = "BW ui/countdown/countdown_tick.ogg",
		["use"] = "ui: each of the last 5 s of a pad countdown you\'re on"
	},
	["UI/Match_Found"] = {
		["id"] = 130071938133363,
		["vol"] = 0.5,
		["src"] = "BW ui/countdown/countdown_gamestart.ogg",
		["use"] = "ui/lobby: pad countdown hit zero"
	},
	["UI/Spectate_Switch"] = {
		["id"] = 112230937348492,
		["vol"] = 0.45,
		["src"] = "AB UI/b_UI_Spectate_Switch.wav",
		["use"] = "ui/character: spectate next/prev"
	},
	["UI/XP_Tick"] = {
		["id"] = 122058924626639,
		["vol"] = 0.35,
		["throttle"] = 0.08,
		["src"] = "BW ui/battle_pass/battle_pass_progress_exp_gain.ogg",
		["use"] = "ui: results XP bar fill"
	},
	["Firework/Launch"] = {
		["id"] = 120634345651113,
		["vol"] = 0.3,
		["src"] = "BW events/lunar/firework_launch.ogg",
		["use"] = "lobby: countdown rocket launch"
	},
	["Firework/Explode"] = {
		["variants"] = nil,
		["vol"] = 0.5,
		["jitter"] = 0.05,
		["src"] = "BW events/lunar/firework_explode_1/2/3.ogg",
		["use"] = "lobby: countdown firework burst",
		["variants"] = {
			{ "Firework_Explode_1", 97323434808015 },
			{ "Firework_Explode_2", 77254794364876 },
			{ "Firework_Explode_3", 130012491228201 }
		}
	},
	["Firework/Crackle"] = {
		["variants"] = nil,
		["vol"] = 0.35,
		["jitter"] = 0.04,
		["src"] = "BW events/lunar/firework_crackle_1/2/3.ogg",
		["use"] = "lobby: countdown firework crackle tail",
		["variants"] = {
			{ "Firework_Crackle_1", 113104508017107 },
			{ "Firework_Crackle_2", 89277184195679 },
			{ "Firework_Crackle_3", 103851344884842 }
		}
	},
	["UI/Reward"] = {
		["id"] = 139391495215873,
		["vol"] = 0.5,
		["src"] = "BW ui/rewards/reward_claim.ogg",
		["use"] = "ui: shells reward on results"
	},
	["UI/Armory_Open"] = {
		["id"] = 126064401477583,
		["vol"] = 0.5,
		["src"] = "AB UI/b_UI_Shop_Items_Open.wav",
		["use"] = "ui: armory / loadout opened"
	},
	["UI/Drop_Land"] = {
		["id"] = 131304880023328,
		["vol"] = 0.5,
		["src"] = "BW gameplay/lucky_blocks/lucky_block_slam.ogg",
		["use"] = "ui: the drop chest lands"
	},
	["UI/Rank_Land"] = {
		["id"] = 131304880023328,
		["vol"] = 0.42,
		["region"] = nil,
		["fade"] = 0.14,
		["jitter"] = 0,
		["src"] = "BW lucky_block_slam.ogg (the drop\'s landing), its first 0.32 s",
		["use"] = "ui: a rank emblem landed on the road (the ranked news takeover) until 2026-10-16: UI/Rank_Pop",
		["region"] = { 0, 0.32 }
	},
	["UI/Rank_Pop"] = {
		["id"] = 86252508990428,
		["vol"] = 0.5,
		["jitter"] = 0,
		["layers"] = nil,
		["src"] = "BW weapons/wand/wand_bubble_pop.ogg + UI/Rank_Pop_Tick",
		["use"] = "ui: a rank emblem pops onto the road (the ranked news takeover, Screens/News)",
		["layers"] = {
			{ "UI/Rank_Pop_Tick", 0.35 }
		}
	},
	["UI/Rank_Pop_Tick"] = {
		["id"] = 86806395082071,
		["vol"] = 0.4,
		["jitter"] = 0,
		["src"] = "BW ui/common/bubble_pop5.ogg",
		["use"] = "ui: layer of UI/Rank_Pop"
	},
	["UI/Drop_Rattle"] = {
		["id"] = 81426719351030,
		["vol"] = 1.3,
		["region"] = nil,
		["fade"] = 0.2,
		["throttle"] = 0.25,
		["src"] = "BW gameplay/treasure_chests/treasure_chest_unlocking.ogg (first 0.7 s)",
		["use"] = "ui: the closed chest wiggles",
		["region"] = { 0, 0.7 }
	},
	["UI/Drop_Open"] = {
		["id"] = 131503537140156,
		["vol"] = 0.5,
		["layers"] = nil,
		["src"] = "AB Blocks/Chest/b_Chest_Open_01.wav + UI/Drop_Open_Burst",
		["use"] = "ui: the lid bursts open",
		["layers"] = {
			{ "UI/Drop_Open_Burst", 0.9 }
		}
	},
	["UI/Drop_Open_Burst"] = {
		["id"] = 124258750415409,
		["vol"] = 0.45,
		["src"] = "BW gameplay/lucky_blocks/lucky_box_reveal_rare.ogg",
		["use"] = "ui: layer of UI/Drop_Open"
	},
	["UI/Drop_Open_Golden"] = {
		["id"] = 78430051260118,
		["vol"] = 0.5,
		["src"] = "BW gameplay/lucky_blocks/lucky_box_reveal_legendary.ogg",
		["use"] = "ui: a Golden Drop opens (with UI/Drop_Open)"
	},
	["UI/Drop_BuildUp"] = {
		["id"] = 89612765355531,
		["vol"] = 0.65,
		["src"] = "AB Cosmetics/Shop/b_CosmeticsShop_Reveal_BuildUp.wav",
		["use"] = "ui: a Golden Drop\'s build-up before it opens"
	},
	["UI/Card_Whoosh"] = {
		["id"] = 114112498573948,
		["vol"] = 0.45,
		["throttle"] = 0.08,
		["src"] = "BW kits/card/card_throw_1.ogg",
		["use"] = "ui: a card flies out of the chest"
	},
	["UI/Card_Flip"] = {
		["id"] = 140074735988604,
		["vol"] = 1.6,
		["throttle"] = 0.08,
		["src"] = "BW kits/card/card_turn.ogg",
		["use"] = "ui: a card flips face up"
	},
	["UI/Card_Reveal"] = {
		["id"] = 126691171598104,
		["vol"] = 0.35,
		["src"] = "AB Cosmetics/Shop/b_CosmeticsShop_Reveal_2Uncommon.wav",
		["use"] = "ui: a card\'s face shows"
	},
	["UI/NewItem_Fanfare"] = {
		["id"] = 120268447491273,
		["vol"] = 0.55,
		["src"] = "AB Cosmetics/Shop/b_CosmeticsShop_Reveal_5Legendary.wav",
		["use"] = "ui: NEW ITEM! (a drop unlocked an item)"
	},
	["UI/Upgrade_Ready"] = {
		["id"] = 106233481101602,
		["vol"] = 1.1,
		["src"] = "BW kits/card/card_upgrade_available.ogg",
		["use"] = "ui: UPGRADE READY stamp on a card"
	},
	["Music/Lobby_Tribal_1"] = {
		["id"] = 9039802639,
		["vol"] = 0.55,
		["src"] = "APM Lily Swamp (Afro Musique, ORGANIK - RHYTHMIC NATURE 2): peaceful hang drum + percussion, 90 bpm",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_Tribal_2"] = {
		["id"] = 9039803082,
		["vol"] = 0.55,
		["src"] = "APM Easy Hang (ORGANIK 2): delicate hang drum + gentle percussion, 75 bpm",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_Tribal_3"] = {
		["id"] = 9039803087,
		["vol"] = 0.55,
		["src"] = "APM Crystal Pools (ORGANIK 2): kalimba + udu clay drum, 65 bpm",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_Tribal_4"] = {
		["id"] = 9039802691,
		["vol"] = 0.55,
		["src"] = "APM Camel Bells (Afro Musique, ORGANIK 2): gentle, meditative adungu + subtle percussion, 148 s",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_Tribal_5"] = {
		["id"] = 9039803323,
		["vol"] = 0.55,
		["src"] = "APM Daydream (ORGANIK 2): ektar + sansula (kalimba), dreamy, 233 s",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_Tribal_6"] = {
		["id"] = 9039803313,
		["vol"] = 0.55,
		["src"] = "APM The Labyrinth (ORGANIK 2): calm hang drum + sansula, light percussion, 184 s",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_Tribal_7"] = {
		["id"] = 9039802855,
		["vol"] = 0.55,
		["src"] = "APM Travel Light (ORGANIK 2): spacious sansula + light percussion, calm and reflective, 206 s",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_Tribal_8"] = {
		["id"] = 9039803307,
		["vol"] = 0.55,
		["src"] = "APM May (ORGANIK 2): dreamy, nostalgic adungu + percussion, 114 s",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_Tribal_9"] = {
		["id"] = 9048456663,
		["vol"] = 0.5,
		["src"] = "APM Touch Of Warmth (Cinematic Hang Drum): minimalist hang drum, 141 s",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_Tribal_10"] = {
		["id"] = 9048450725,
		["vol"] = 0.5,
		["src"] = "APM Cloud Cover (Cinematic Hang Drum): minimalist hang drum, 161 s",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_Tribal_11"] = {
		["id"] = 1839849040,
		["vol"] = 0.5,
		["src"] = "APM Warm Rain and Rhythm (A WORLD OF CALM): melodic, meandering thumb piano, 154 s",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_TheHunt"] = {
		["id"] = 82676660442838,
		["vol"] = 0.55,
		["src"] = "Ovani Nordic Vol. 1: The Hunt (Intensity 2 -> Main)",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_Kyrre"] = {
		["id"] = 110391451155196,
		["vol"] = 0.55,
		["src"] = "Ovani Nordic Vol. 1: Kyrre (Intensity 2 -> Main)",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_WildFlower"] = {
		["id"] = 138661716710578,
		["vol"] = 0.55,
		["src"] = "Ovani Nordic Vol. 1: Wild Flower (Intensity 2 -> Main)",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_AxeThrowers"] = {
		["id"] = 95619441224123,
		["vol"] = 0.55,
		["src"] = "Ovani Nordic Vol. 1: Axe Throwers (Intensity 2 -> Main)",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_TheHavens"] = {
		["id"] = 91064526460177,
		["vol"] = 0.55,
		["src"] = "Ovani Nordic Vol. 1: The Havens (Intensity 2 -> Main)",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_Longships"] = {
		["id"] = 130095978225539,
		["vol"] = 0.55,
		["src"] = "Ovani Nordic Vol. 1: Longships (Intensity 1 -> 2)",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_Freya"] = {
		["id"] = 115597913040467,
		["vol"] = 0.55,
		["src"] = "Ovani Nordic Vol. 1: Freya (Intensity 1 -> 2)",
		["use"] = "audio: lobby playlist"
	},
	["Music/Lobby_ChoppyWaters"] = {
		["id"] = 105685331528114,
		["vol"] = 0.55,
		["src"] = "Ovani Nordic Vol. 1: Choppy Waters (Intensity 1 -> Main)",
		["use"] = "audio: lobby playlist"
	},
	["Music/Match_Jungle"] = {
		["id"] = 1840002098,
		["vol"] = 0.32,
		["looped"] = true,
		["src"] = "APM Forest Darkness (b) (TRIBAL TENSION: BEDS): pulsating bed, drums, distant woodwind",
		["use"] = "audio: in-match bed (jungle / default)"
	},
	["Music/Match_Snow"] = {
		["id"] = 1840003052,
		["vol"] = 0.32,
		["looped"] = true,
		["src"] = "APM Call of the Wild (b) (TRIBAL TENSION: BEDS): dark drone with ethnic flutes",
		["use"] = "audio: in-match bed (snow)"
	},
	["Music/Match_Desert"] = {
		["id"] = 1840001875,
		["vol"] = 0.3,
		["looped"] = true,
		["src"] = "APM Primal Pressure (d) (TRIBAL TENSION: BEDS): tribal drums, percussion, distant strings",
		["use"] = "audio: in-match bed (desert)"
	},
	["Music/Match_Beach"] = {
		["id"] = 1840001246,
		["vol"] = 0.3,
		["looped"] = true,
		["src"] = "APM Delicate Fear (a) (TRIBAL TENSION: BEDS): rising bed with tribal drums",
		["use"] = "audio: in-match bed (beach)"
	},
	["Music/Overtime"] = {
		["id"] = 1840000039,
		["vol"] = 0.45,
		["src"] = "APM End Game (a 30) (TRIBAL TENSION: TRAILERS): frantic tribal drums to a big finale, 29 s",
		["use"] = "audio: Overtime (25 s sudden death)"
	},
	["Music/Final_Round"] = {
		["id"] = 1839999913,
		["vol"] = 0.34,
		["looped"] = true,
		["src"] = "APM Jungle Drums (b) (TRIBAL TENSION: TRAILERS, Juice Music): atmospheric, edgy drum-based trailer cue; a slow, sparse start that builds with evolving dramatic rhythms, 126 s",
		["use"] = "audio: the deciding round\'s bed (LocalPlayer FinalRound)"
	},
	["Ambience/Jungle"] = {
		["id"] = 9114891241,
		["vol"] = 1.6,
		["looped"] = true,
		["src"] = "PSE Jungle Ambience 4: day, light insects, distant owl, warbler, chirps",
		["use"] = "audio: Sunstone Temple bed"
	},
	["Ambience/Snow_Wind"] = {
		["id"] = 88323424231930,
		["vol"] = 0.8,
		["looped"] = true,
		["src"] = "AB Ambience/Beds/b_Ambient_Bed_Cold_01.wav",
		["use"] = "audio: Frostfang Pass bed"
	},
	["Ambience/Desert_Wind"] = {
		["id"] = 9114057128,
		["vol"] = 1.4,
		["looped"] = true,
		["src"] = "PSE Desert Wind Whistley Light Gusts 2",
		["use"] = "audio: Ember Canyon bed"
	},
	["Ambience/Beach_Waves"] = {
		["id"] = 9119677305,
		["vol"] = 1.2,
		["looped"] = true,
		["src"] = "PSE Surf Ocean Wave Impact On Zuma Beach 4",
		["use"] = "audio: Driftwood Cove bed"
	},
	["Ambience/Seagulls"] = {
		["id"] = 9112870701,
		["vol"] = 0.8,
		["looped"] = true,
		["src"] = "PSE Seagulls 2 (distant flock, loop)",
		["use"] = "audio: Driftwood Cove layer"
	},
	["Ambience/Gust_Cold"] = {
		["id"] = 128419820908856,
		["vol"] = 0.6,
		["roll"] = nil,
		["jitter"] = 0.08,
		["src"] = "AB Ambience/3D positional/b_Ambient_3D_M_WindGustCold_01.wav",
		["use"] = "audio: Frostfang sweetener",
		["roll"] = v2.ambient
	},
	["Ambience/Gust_Warm"] = {
		["id"] = 128419820908856,
		["vol"] = 0.5,
		["pitch"] = 0.8,
		["roll"] = nil,
		["jitter"] = 0.08,
		["src"] = "AB b_Ambient_3D_M_WindGustCold_01.wav (lower)",
		["use"] = "audio: Ember Canyon sweetener",
		["roll"] = v2.ambient
	},
	["Ambience/Bird_Call"] = {
		["id"] = 114048020110675,
		["vol"] = 0.45,
		["roll"] = nil,
		["jitter"] = 0.12,
		["src"] = "AB Ambience/3D positional/b_Ambient_3D_M_BirdLittle_Kingfisher_01.wav",
		["use"] = "audio: jungle + lobby sweetener",
		["roll"] = v2.ambient
	}
}
v1.MAP_THEMES = {
	["SunstoneTemple"] = "Jungle",
	["FrostfangPass"] = "Snow",
	["EmberCanyon"] = "Desert",
	["DriftwoodCove"] = "Beach",
	["IcefallFjord"] = "Snow",
	["HarvestHollow"] = "Default",
	["AuroraGlacier"] = "Snow",
	["MangroveMarsh"] = "Jungle",
	["TitansAmphitheatre"] = "Default",
	["GiantwoodGrove"] = "Default",
	["OvergrownRuins"] = "Jungle",
	["DevArena"] = "Default"
}
v1.THEME_KEYWORDS = {
	{ "sun", "Jungle" },
	{ "temple", "Jungle" },
	{ "jungle", "Jungle" },
	{ "forest", "Jungle" },
	{ "frost", "Snow" },
	{ "snow", "Snow" },
	{ "ice", "Snow" },
	{ "winter", "Snow" },
	{ "ember", "Desert" },
	{ "canyon", "Desert" },
	{ "desert", "Desert" },
	{ "dune", "Desert" },
	{ "drift", "Beach" },
	{ "cove", "Beach" },
	{ "beach", "Beach" },
	{ "isle", "Beach" },
	{ "island", "Beach" }
}
local v4 = {
	["Jungle"] = {
		["beds"] = nil,
		["sweeteners"] = nil,
		["every"] = nil,
		["music"] = "Music/Match_Jungle",
		["beds"] = {
			{ "Ambience/Jungle", 1 }
		},
		["sweeteners"] = { "Ambience/Bird_Call" },
		["every"] = { 5, 12 }
	},
	["Snow"] = {
		["beds"] = nil,
		["sweeteners"] = nil,
		["every"] = nil,
		["music"] = "Music/Match_Snow",
		["beds"] = {
			{ "Ambience/Snow_Wind", 1 },
			{ "Ambience/Raid_HighWind", 0.5 }
		},
		["sweeteners"] = { "Ambience/Gust_Cold" },
		["every"] = { 7, 15 }
	},
	["Desert"] = {
		["beds"] = nil,
		["sweeteners"] = nil,
		["every"] = nil,
		["music"] = "Music/Match_Desert",
		["beds"] = {
			{ "Ambience/Desert_Wind", 1 }
		},
		["sweeteners"] = { "Ambience/Gust_Warm" },
		["every"] = { 8, 16 }
	},
	["Beach"] = {
		["beds"] = nil,
		["sweeteners"] = nil,
		["every"] = nil,
		["music"] = "Music/Match_Beach",
		["beds"] = {
			{ "Ambience/Beach_Waves", 1 },
			{ "Ambience/Seagulls", 0.6 }
		},
		["sweeteners"] = {},
		["every"] = { 10, 20 }
	},
	["Default"] = {
		["beds"] = nil,
		["sweeteners"] = nil,
		["every"] = nil,
		["music"] = "Music/Match_Jungle",
		["beds"] = {
			{ "Ambience/Raid_Forest", 0.8 }
		},
		["sweeteners"] = { "Ambience/Bird_Call" },
		["every"] = { 8, 16 }
	},
	["Lobby"] = {
		["beds"] = {
			{ "Ambience/Raid_Birds", 0.55 },
			{ "Ambience/Lobby_Wind", 0.6 },
			{ "Ambience/Lobby_Fire", 0.35 }
		},
		["sweeteners"] = { "Ambience/Bird_Call" },
		["every"] = { 9, 18 }
	}
}
v1.THEMES = v4
v1.LOBBY_PLAYLIST = {
	"Music/Lobby_TheHunt",
	"Music/Lobby_Kyrre",
	"Music/Lobby_WildFlower",
	"Music/Lobby_TheHavens",
	"Music/Lobby_Freya",
	"Music/Lobby_ChoppyWaters"
}
local v_u_5 = {
	["UI"] = "UI",
	["Music"] = "Music",
	["Ambience"] = "Ambient"
}
function v1.Get(p6) -- name: Get
	-- upvalues: (copy) v_u_3
	return v_u_3[p6]
end
function v1.All() -- name: All
	-- upvalues: (copy) v_u_3
	return v_u_3
end
function v1.groupOf(p7) -- name: groupOf
	-- upvalues: (copy) v_u_3, (copy) v_u_5
	local v8 = v_u_3[p7]
	if v8 and v8.group then
		return v8.group
	end
	local v9 = string.match(p7, "^([^/]+)/")
	return v9 and v_u_5[v9] or "SFX"
end
return v1