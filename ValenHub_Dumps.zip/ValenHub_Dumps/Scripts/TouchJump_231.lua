local v1 = require(script.Parent.Parent:WaitForChild("CommonUtils"))
local v_u_2 = v1.get("ConnectionUtil")
local v_u_3 = v1.get("CharacterUtil")
local v4 = v1.get("FlagUtil")
local v_u_5 = v4.getUserFlag("UserPlayerScriptsCCLIntegrationD")
local v_u_6 = v4.getUserFlag("UserPlayerScriptsRefactor1")
local v_u_7 = v4.getUserFlag("UserPlayerScriptsFixTouchJumpVisibility")
game:GetService("Players")
local v_u_8 = require(script.Parent:WaitForChild("AvatarAbilitiesInterface"))
local v_u_9 = { "rbxasset://textures/ui/Input/JumpButtonRegular.png", "rbxasset://textures/ui/Input/JumpButtonPressed.png" }
local v_u_10 = require(script.Parent:WaitForChild("ActionController"))
local v_u_11 = setmetatable({}, v_u_10)
v_u_11.__index = v_u_11
function v_u_11.new(p12, p13) -- name: new
	-- upvalues: (copy) v_u_10, (copy) v_u_11, (copy) v_u_7, (copy) v_u_2
	local v14 = v_u_10.new()
	local v15 = v_u_11
	local v_u_16 = setmetatable(v14, v15)
	v_u_16.playerData = p13
	p12.eventBus:subscribe("ACTIONS_RELOADED"):Connect(function()
		-- upvalues: (copy) v_u_16, (ref) v_u_7
		v_u_16:Create()
		if v_u_7 and v_u_16._active then
			v_u_16._active = false
			v_u_16:EnableButton(true)
		end
	end)
	v_u_16.parentUIFrame = nil
	v_u_16.jumpButton = nil
	v_u_16.externallyEnabled = false
	v_u_16._active = false
	v_u_16._connectionUtil = v_u_2.new()
	return v_u_16
end
function v_u_11._reset(p17) -- name: _reset
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_9
	if p17.jumpButton then
		if not v_u_5 and v_u_8.isEnabled() then
			p17.jumpButton.Image = v_u_9[1]
			return
		end
		p17.jumpButton.ImageRectOffset = Vector2.new(1, 146)
	end
end
function v_u_11.EnableButton(p18, p19) -- name: EnableButton
	if p19 ~= p18._active then
		if p19 then
			if not p18.jumpButton then
				p18:Create()
			end
			p18.jumpButton.Visible = true
		elseif p18.jumpButton then
			p18.jumpButton.Visible = false
		end
		p18:_reset()
		p18._active = p19
	end
end
function v_u_11.UpdateEnabled(p20) -- name: UpdateEnabled
	-- upvalues: (copy) v_u_3
	local v21 = v_u_3.getChild("Humanoid", "Humanoid")
	if v21 and p20.externallyEnabled and (v21.UseJumpPower and v21.JumpPower > 0 or not v21.UseJumpPower and v21.JumpHeight > 0) and v21:GetStateEnabled(Enum.HumanoidStateType.Jumping) then
		p20:EnableButton(true)
	else
		p20:EnableButton(false)
	end
end
function v_u_11._setupConfigurations(p_u_22) -- name: _setupConfigurations
	-- upvalues: (copy) v_u_3
	local function v_u_23() -- name: update
		-- upvalues: (copy) p_u_22
		p_u_22:UpdateEnabled()
	end
	local v27 = v_u_3.onChild("Humanoid", "Humanoid", function(p24)
		-- upvalues: (copy) p_u_22, (copy) v_u_23
		p_u_22:UpdateEnabled()
		p_u_22:_reset()
		p_u_22._connectionUtil:trackConnection("HUMANOID_JUMP_POWER", p24:GetPropertyChangedSignal("JumpPower"):Connect(v_u_23))
		p_u_22._connectionUtil:trackConnection("HUMANOID_JUMP_HEIGHT", p24:GetPropertyChangedSignal("JumpHeight"):Connect(v_u_23))
		p_u_22._connectionUtil:trackConnection("HUMANOID_STATE_ENABLED_CHANGED", p24.StateEnabledChanged:Connect(function(p25, p26)
			-- upvalues: (ref) p_u_22
			if p25 == Enum.HumanoidStateType.Jumping and p26 ~= p_u_22._active then
				p_u_22:UpdateEnabled()
			end
		end))
	end)
	p_u_22._connectionUtil:trackConnection("HUMANOID", v27)
end
function v_u_11.Enable(p28, p29, p30) -- name: Enable
	-- upvalues: (copy) v_u_10
	if p30 then
		p28.parentUIFrame = p30
	end
	if p28.externallyEnabled == p29 then
		return
	else
		p28.externallyEnabled = p29
		v_u_10.Enable(p28, p29)
		p28:UpdateEnabled()
		if p29 then
			p28:_setupConfigurations()
		else
			p28._connectionUtil:disconnectAll()
		end
	end
end
function v_u_11.Create(p_u_31) -- name: Create
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_8, (copy) v_u_9
	if p_u_31.parentUIFrame then
		if p_u_31.jumpButton then
			p_u_31.jumpButton:Destroy()
			p_u_31.jumpButton = nil
		end
		if p_u_31.absoluteSizeChangedConn then
			p_u_31.absoluteSizeChangedConn:Disconnect()
			p_u_31.absoluteSizeChangedConn = nil
		end
		if not v_u_5 and p_u_31.avatarAbilitiesEnabledChangedConn then
			p_u_31.avatarAbilitiesEnabledChangedConn:Disconnect()
			p_u_31.avatarAbilitiesEnabledChangedConn = nil
		end
		p_u_31.jumpButton = Instance.new("ImageButton")
		p_u_31.jumpButton.Name = "JumpButton"
		p_u_31.jumpButton.Visible = false
		p_u_31.jumpButton.BackgroundTransparency = 1
		if v_u_6 then
			p_u_31.jumpButton.ZIndex = 10
		end
		if v_u_5 or not v_u_8.isEnabled() then
			p_u_31.jumpButton.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
			p_u_31.jumpButton.ImageRectOffset = Vector2.new(1, 146)
			p_u_31.jumpButton.ImageRectSize = Vector2.new(144, 144)
		else
			p_u_31.jumpButton.Image = v_u_9[1]
		end
		local function v39() -- name: ResizeJumpButton
			-- upvalues: (copy) p_u_31, (ref) v_u_5, (ref) v_u_8, (ref) v_u_9
			local v32 = p_u_31.parentUIFrame.AbsoluteSize.x
			local v33 = p_u_31.parentUIFrame.AbsoluteSize.y
			local v34 = math.min(v32, v33) <= 500
			if v_u_5 or not v_u_8.isEnabled() then
				local v35 = v34 and 70 or 120
				p_u_31.jumpButton.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
				p_u_31.jumpButton.ImageRectOffset = Vector2.new(1, 146)
				p_u_31.jumpButton.ImageRectSize = Vector2.new(144, 144)
				p_u_31.jumpButton.Size = UDim2.new(0, v35, 0, v35)
				p_u_31.jumpButton.Position = v34 and UDim2.new(1, -(v35 * 1.5 - 10), 1, -v35 - 20) or UDim2.new(1, -(v35 * 1.5 - 10), 1, -v35 * 1.75)
			else
				local v36 = v34 and 72 or 120
				local v37 = -v36 - (v34 and 64 or 100)
				local v38 = -v36 - (v34 and 64 or 112)
				p_u_31.jumpButton.Image = v_u_9[1]
				p_u_31.jumpButton.ImageRectOffset = Vector2.new(0, 0)
				p_u_31.jumpButton.ImageRectSize = Vector2.new(0, 0)
				p_u_31.jumpButton.Size = UDim2.new(0, v36, 0, v36)
				p_u_31.jumpButton.Position = UDim2.new(1, v37, 1, v38)
			end
		end
		v39()
		p_u_31.absoluteSizeChangedConn = p_u_31.parentUIFrame:GetPropertyChangedSignal("AbsoluteSize"):Connect(v39)
		if not v_u_5 then
			p_u_31.avatarAbilitiesEnabledChangedConn = v_u_8.GetEnabledChangedSignal():Connect(v39)
		end
		p_u_31.jumpButton.Parent = p_u_31.parentUIFrame
		if p_u_31.playerData.actions.JumpAction then
			p_u_31.playerData.actions.JumpAction:WaitForChild("TouchBinding").UIButton = p_u_31.jumpButton
			p_u_31.playerData.actions.JumpAction.Pressed:Connect(function()
				-- upvalues: (copy) p_u_31, (ref) v_u_5, (ref) v_u_8, (ref) v_u_9
				if p_u_31.jumpButton then
					if v_u_5 or not v_u_8.isEnabled() then
						p_u_31.jumpButton.ImageRectOffset = Vector2.new(146, 146)
					else
						p_u_31.jumpButton.Image = v_u_9[2]
					end
				else
					return
				end
			end)
			p_u_31.playerData.actions.JumpAction.Released:Connect(function()
				-- upvalues: (copy) p_u_31, (ref) v_u_5, (ref) v_u_8, (ref) v_u_9
				if p_u_31.jumpButton then
					if v_u_5 or not v_u_8.isEnabled() then
						p_u_31.jumpButton.ImageRectOffset = Vector2.new(1, 146)
					else
						p_u_31.jumpButton.Image = v_u_9[1]
					end
				else
					return
				end
			end)
		end
	else
		return
	end
end
return v_u_11