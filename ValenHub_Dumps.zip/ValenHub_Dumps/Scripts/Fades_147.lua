local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent:WaitForChild("Fighters"))
local v5 = {
	["DECOR_FADE"] = 0.75,
	["ALLY_FADE"] = 0.7
}
local v_u_6 = v2.LocalPlayer
local v_u_7 = {}
local v_u_8 = {}
local v_u_9 = 0
local v_u_10 = {}
local v_u_11 = {}
local v_u_12 = 0
local v_u_13 = false
local function v_u_20(p14) -- name: isDecor
	if not p14:IsA("BasePart") or (not p14.Anchored or p14.Transparency >= 0.95) then
		return false
	end
	if not p14:HasTag("Foliage") and (p14.CanCollide or p14.CanQuery) then
		return false
	end
	local v15 = p14.Size
	local v16 = v15.X
	local v17 = v15.Y
	local v18 = v15.Z
	if math.max(v16, v17, v18) < 1 then
		return false
	end
	local v19 = p14:FindFirstAncestorWhichIsA("Model")
	while v19 do
		if v19:HasTag("BearTrap") or v19:FindFirstChildOfClass("Humanoid") then
			return false
		end
		v19 = v19:FindFirstAncestorWhichIsA("Model")
	end
	return true
end
local function v_u_66(p21) -- name: addDecor
	-- upvalues: (copy) v_u_8, (copy) v_u_20, (copy) v_u_7, (ref) v_u_9
	if v_u_8[p21] or not v_u_20(p21) then
		return
	else
		local v22 = p21.CFrame
		local v23 = p21.Size / 2
		local v24 = v22.RightVector * v23.X
		local v25 = v22.UpVector * v23.Y
		local v26 = v22.LookVector * v23.Z
		local v27 = v24.X
		local v28 = math.abs(v27)
		local v29 = v25.X
		local v30 = v28 + math.abs(v29)
		local v31 = v26.X
		local v32 = v30 + math.abs(v31)
		local v33 = v24.Y
		local v34 = math.abs(v33)
		local v35 = v25.Y
		local v36 = v34 + math.abs(v35)
		local v37 = v26.Y
		local v38 = v36 + math.abs(v37)
		local v39 = v24.Z
		local v40 = math.abs(v39)
		local v41 = v25.Z
		local v42 = v40 + math.abs(v41)
		local v43 = v26.Z
		local v44 = v42 + math.abs(v43)
		local v45 = Vector3.new(v32, v38, v44)
		local v46 = (v22.Position - v45) / 16
		local v47 = (v22.Position + v45) / 16
		local v48 = v46.X
		local v49 = math.floor(v48)
		local v50 = v46.Y
		local v51 = math.floor(v50)
		local v52 = v46.Z
		local v53 = math.floor(v52)
		local v54 = v47.X
		local v55 = math.floor(v54)
		local v56 = v47.Y
		local v57 = math.floor(v56)
		local v58 = v47.Z
		local v59 = math.floor(v58)
		if (v55 - v49 + 1) * (v57 - v51 + 1) * (v59 - v53 + 1) <= 64 then
			local v60 = {}
			for v61 = v49, v55 do
				for v62 = v51, v57 do
					for v63 = v53, v59 do
						local v64 = v61 .. "," .. v62 .. "," .. v63
						local v65 = v_u_7[v64]
						if not v65 then
							v65 = {}
							v_u_7[v64] = v65
						end
						v65[p21] = true
						table.insert(v60, v64)
					end
				end
			end
			v_u_8[p21] = {
				["part"] = p21,
				["cells"] = v60
			}
			v_u_9 = v_u_9 + 1
		end
	end
end
local function v_u_71(p67) -- name: removeDecor
	-- upvalues: (copy) v_u_8, (ref) v_u_9, (copy) v_u_7, (copy) v_u_10
	local v68 = v_u_8[p67]
	if v68 then
		v_u_8[v68.part] = nil
		v_u_9 = v_u_9 - 1
		for _, v69 in v68.cells do
			local v70 = v_u_7[v69]
			if not v70 then
				continue
			end
			v70[v68.part] = nil
			if next(v70) ~= nil then
				continue
			end
			v_u_7[v69] = nil
		end
		if v_u_10[v68.part] then
			v_u_10[v68.part] = nil
			v68.part.LocalTransparencyModifier = 0
		end
	end
end
local function v_u_74(p72) -- name: watchDecorRoot
	-- upvalues: (copy) v_u_66, (copy) v_u_71
	for _, v73 in p72:GetDescendants() do
		v_u_66(v73)
	end
	p72.DescendantAdded:Connect(v_u_66)
	p72.DescendantRemoving:Connect(v_u_71)
end
local function v_u_79() -- name: startDecorWatch
	-- upvalues: (ref) v_u_13, (copy) v_u_3, (copy) v_u_74, (copy) v_u_1, (copy) v_u_66, (copy) v_u_71
	if not v_u_13 then
		v_u_13 = true
		for _, v75 in { "Arenas", "Lobby" } do
			local v76 = v_u_3:FindFirstChild(v75)
			if not v76 then
				continue
			end
			v_u_74(v76)
		end
		v_u_3.ChildAdded:Connect(function(p77)
			-- upvalues: (ref) v_u_74
			if p77.Name == "Arenas" or p77.Name == "Lobby" then
				v_u_74(p77)
			end
		end)
		v_u_1:GetInstanceAddedSignal("Foliage"):Connect(v_u_66)
		v_u_1:GetInstanceRemovedSignal("Foliage"):Connect(v_u_71)
		for _, v78 in v_u_1:GetTagged("Foliage") do
			v_u_66(v78)
		end
	end
end
local function v_u_94(p80, p81) -- name: boxDistance
	local v82 = p80.CFrame:PointToObjectSpace(p81)
	local v83 = p80.Size / 2
	local v84 = v82.X
	local v85 = math.abs(v84) - v83.X
	local v86 = math.max(v85, 0)
	local v87 = v82.Y
	local v88 = math.abs(v87) - v83.Y
	local v89 = math.max(v88, 0)
	local v90 = v82.Z
	local v91 = math.abs(v90) - v83.Z
	local v92 = math.max(v91, 0)
	local v93 = v86 * v86 + v89 * v89 + v92 * v92
	return math.sqrt(v93)
end
local function v_u_113(p95, p96) -- name: markDecorNear
	-- upvalues: (copy) v_u_7, (copy) v_u_11, (copy) v_u_94
	local v97 = (p95 - Vector3.new(1, 1, 1) * p96) / 16
	local v98 = (p95 + Vector3.new(1, 1, 1) * p96) / 16
	local v99 = v97.X
	local v100 = math.floor(v99)
	local v101 = v98.X
	for v102 = v100, math.floor(v101) do
		local v103 = v97.Y
		local v104 = math.floor(v103)
		local v105 = v98.Y
		for v106 = v104, math.floor(v105) do
			local v107 = v97.Z
			local v108 = math.floor(v107)
			local v109 = v98.Z
			for v110 = v108, math.floor(v109) do
				local v111 = v_u_7[v102 .. "," .. v106 .. "," .. v110]
				if not v111 then
					continue
				end
				for v112 in v111 do
					if v_u_11[v112] or v_u_94(v112, p95) >= p96 then
						continue
					end
					v_u_11[v112] = true
				end
			end
		end
	end
end
function v5.ClearDecor() -- name: ClearDecor
	-- upvalues: (copy) v_u_10
	for v114 in v_u_10 do
		if not v114.Parent then
			continue
		end
		v114.LocalTransparencyModifier = 0
	end
	table.clear(v_u_10)
end
function v5.UpdateDecor(p115, p116) -- name: UpdateDecor
	-- upvalues: (ref) v_u_12, (copy) v_u_79, (copy) v_u_11, (copy) v_u_113, (copy) v_u_10
	local v117 = os.clock()
	if v117 - v_u_12 >= 0.1 then
		v_u_12 = v117
		v_u_79()
		table.clear(v_u_11)
		v_u_113(p115, 3)
		if p116 then
			v_u_113(p115:Lerp(p116, 0.33), 1.2)
			v_u_113(p115:Lerp(p116, 0.66), 1.2)
		end
		for v118 in v_u_11 do
			if v_u_10[v118] then
				continue
			end
			v_u_10[v118] = true
			v118.LocalTransparencyModifier = 0.75
		end
		for v119 in v_u_10 do
			if v_u_11[v119] then
				continue
			end
			v_u_10[v119] = nil
			if not v119.Parent then
				continue
			end
			v119.LocalTransparencyModifier = 0
		end
	end
end
local v_u_120 = {}
local function v_u_127(p121, p122, p123) -- name: setAllyLtm
	if p121.dirty then
		table.clear(p121.parts)
		for _, v124 in p122:GetDescendants() do
			if not (v124:IsA("BasePart") or v124:IsA("Decal")) then
				continue
			end
			local v125 = p121.parts
			table.insert(v125, v124)
		end
		p121.dirty = false
	end
	for _, v126 in p121.parts do
		if v126.LocalTransparencyModifier == p123 or not v126.Parent then
			continue
		end
		v126.LocalTransparencyModifier = p123
	end
end
function v5.ClearAllies() -- name: ClearAllies
	-- upvalues: (copy) v_u_120, (copy) v_u_127
	for v128 in v_u_120 do
		local v129 = v_u_120[v128]
		if not v129 then
			continue
		end
		v_u_120[v128] = nil
		for _, v130 in v129.conns do
			v130:Disconnect()
		end
		v129.dirty = true
		v_u_127(v129, v128, 0)
	end
end
local function v_u_136(p131, p132) -- name: isAlly
	-- upvalues: (copy) v_u_6
	if p131 == p132 then
		return false
	end
	local v133 = v_u_6:GetAttribute("MatchId")
	if type(v133) ~= "string" or (v133 == "" or p131:GetAttribute("MatchId") ~= v133) then
		return false
	end
	local v134 = v_u_6:GetAttribute("Team")
	local v135
	if v134 == nil then
		v135 = false
	else
		v135 = p131:GetAttribute("Team") == v134
	end
	return v135
end
function v5.UpdateAllies(p137, p138, p139) -- name: UpdateAllies
	-- upvalues: (copy) v_u_4, (copy) v_u_120, (copy) v_u_136, (copy) v_u_127
	for _, v140 in v_u_4.List() do
		local v141 = v140:FindFirstChildOfClass("Humanoid")
		local v142 = v140:FindFirstChild("HumanoidRootPart")
		local v143 = v_u_120[v140] ~= nil
		local v144
		if v141 and (v141.Health > 0 and (v142 and (v142:IsA("BasePart") and v_u_136(v140, p139)))) then
			local v145 = v140:FindFirstChild("Head")
			local v146 = v142.Position
			local v147 = p138 - p137
			local v148 = v147:Dot(v147)
			local v149
			if v148 > 1e-6 then
				local v150 = (v146 - p137):Dot(v147) / v148
				v149 = math.clamp(v150, 0, 1)
			else
				v149 = 0
			end
			local v151 = (p137 + v147 * v149 - v146).Magnitude
			if v145 and v145:IsA("BasePart") then
				local v152 = v145.Position
				local v153 = p138 - p137
				local v154 = v153:Dot(v153)
				local v155
				if v154 > 1e-6 then
					local v156 = (v152 - p137):Dot(v153) / v154
					v155 = math.clamp(v156, 0, 1)
				else
					v155 = 0
				end
				local v157 = (p137 + v153 * v155 - v152).Magnitude
				v151 = math.min(v151, v157)
			end
			v144 = v151 < (v143 and 5.6 or 5)
		else
			v144 = false
		end
		if v144 and not v143 then
			local v_u_158 = {
				["parts"] = nil,
				["dirty"] = true,
				["conns"] = nil,
				["parts"] = {},
				["conns"] = {}
			}
			local v159 = v_u_158.conns
			local v160 = v140.DescendantAdded
			table.insert(v159, v160:Connect(function()
				-- upvalues: (copy) v_u_158
				v_u_158.dirty = true
			end))
			v_u_120[v140] = v_u_158
			v_u_127(v_u_158, v140, 0.7)
		elseif v144 and v143 then
			local v161 = v_u_120[v140]
			if not v161.dirty then
				continue
			end
			v_u_127(v161, v140, 0.7)
		else
			if not v143 then
				continue
			end
			local v162 = v_u_120[v140]
			if not v162 then
				continue
			end
			v_u_120[v140] = nil
			for _, v163 in v162.conns do
				v163:Disconnect()
			end
			v162.dirty = true
			v_u_127(v162, v140, 0)
		end
	end
	for v164 in v_u_120 do
		if v164.Parent then
			continue
		end
		local v165 = v_u_120[v164]
		if not v165 then
			continue
		end
		v_u_120[v164] = nil
		for _, v166 in v165.conns do
			v166:Disconnect()
		end
		v165.dirty = true
		v_u_127(v165, v164, 0)
	end
end
function v5.Stats() -- name: Stats
	-- upvalues: (copy) v_u_10, (copy) v_u_120, (ref) v_u_9
	local v167 = 0
	local v168 = 0
	for _ in v_u_10 do
		v167 = v167 + 1
	end
	for _ in v_u_120 do
		v168 = v168 + 1
	end
	return {
		["decorParts"] = v_u_9,
		["decorFaded"] = v167,
		["alliesFaded"] = v168
	}
end
return v5