local v1 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
game:GetService("StarterPlayer")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
UserSettings():GetService("UserGameSettings")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = require(script.Parent:WaitForChild("InputReplication"))
local v_u_6 = require(script.Parent:WaitForChild("AvatarAbilitiesInterface")).get(v2.LocalPlayer)
local v_u_7 = v1.getUserFlag("UserPlayerScriptsPlayerControlState2")
local v_u_8 = v1.getUserFlag("UserAbilitiesUserInterfaceB")
local v_u_9 = v1.getUserFlag("UserPSUseBindToAnimation")
local v_u_10 = v_u_8 and "ControlState" or "PlayerControlState"
local v_u_11 = {}
v_u_11.__index = v_u_11
local v_u_12 = {}
local v_u_13 = {}
local v_u_14 = {}
local v_u_15 = {}
local v_u_16 = Instance.new("BindableEvent")
local v_u_17 = 0
local v_u_18 = Instance.new("BindableEvent")
local function v_u_24(p19, p20) -- name: shallow_equal
	if p19 == p20 then
		return true
	end
	for v21, v22 in pairs(p19) do
		if p20[v21] == v22 then
			continue
		end
		return false
	end
	for v23, _ in pairs(p20) do
		if p19[v23] ~= nil then
			continue
		end
		return false
	end
	return true
end
function v_u_11.GetNumOverflowSlots() -- name: GetNumOverflowSlots
	return 3
end
function v_u_11.getOverflowScrollIndex() -- name: getOverflowScrollIndex
	-- upvalues: (ref) v_u_17
	return v_u_17
end
function v_u_11.setOverflowScrollIndex(p25) -- name: setOverflowScrollIndex
	-- upvalues: (ref) v_u_17, (ref) v_u_13, (copy) v_u_18
	local v26 = v_u_17
	local v27 = #v_u_13 - 3
	local v28 = math.min(v27, p25)
	v_u_17 = math.max(0, v28)
	if v_u_17 ~= v26 then
		v_u_18:Fire()
	end
end
function v_u_11.getScrollIndexChangedEvent() -- name: getScrollIndexChangedEvent
	-- upvalues: (copy) v_u_18
	return v_u_18.Event
end
function v_u_11.setupSlotActions(p_u_29, p_u_30) -- name: setupSlotActions
	-- upvalues: (copy) v_u_7, (copy) v_u_9, (copy) v_u_3, (copy) v_u_6, (copy) v_u_5, (copy) v_u_12, (ref) v_u_13, (copy) v_u_4, (copy) v_u_11, (copy) v_u_24, (copy) v_u_16, (copy) v_u_8, (copy) v_u_10, (copy) v_u_14, (copy) v_u_15, (ref) v_u_17
	local function v_u_34(p31) -- name: getAbilityAction
		-- upvalues: (ref) v_u_7, (copy) p_u_30, (copy) p_u_29
		if p31 then
			local v32
			if v_u_7 and not p_u_30 then
				v32 = script.Parent.Parent:FindFirstChild("InputContexts")
			else
				v32 = p_u_29:FindFirstChild("InputContexts")
			end
			if v32 then
				local v33 = v32:FindFirstChild("CharacterContext")
				if v33 then
					return v33:FindFirstChild(p31 .. "Action")
				else
					return nil
				end
			else
				return nil
			end
		else
			return nil
		end
	end
	if not v_u_7 then
		if v_u_9 then
			v_u_3:BindToAnimation(function(_)
				-- upvalues: (ref) v_u_6, (ref) v_u_5, (copy) p_u_29
				if v_u_6:isEnabled() then
					v_u_5.FireCustomInputs(p_u_29)
					v_u_5.SendInputToCCLCharacter(p_u_29)
				end
			end, Enum.StepFrequency.Hz60)
		else
			v_u_3:BindToSimulation(function(_)
				-- upvalues: (ref) v_u_6, (ref) v_u_5, (copy) p_u_29
				if v_u_6:isEnabled() then
					v_u_5.FireCustomInputs(p_u_29)
					v_u_5.SendInputToCCLCharacter(p_u_29)
				end
			end, Enum.StepFrequency.Hz60)
		end
	end
	local v_u_35 = {}
	local function v63() -- name: updateSlotMap
		-- upvalues: (ref) v_u_12, (ref) v_u_13, (ref) v_u_6, (ref) v_u_4, (copy) v_u_35, (ref) v_u_11, (ref) v_u_24, (ref) v_u_16
		local v36 = table.clone(v_u_12)
		local v37 = table.clone(v_u_13)
		local v38 = v_u_6:GetAbilities()
		local v39 = v_u_4.PreferredInput == Enum.PreferredInput.Touch and 7 or 11
		for v40, v41 in pairs(v_u_12) do
			for v44, v43 in pairs(v38) do
				if v43 ~= v41 then
					continue
				end
			end
			local v44 = nil
			if v44 and v39 >= v40 then
				break
			end
			v_u_12[v40] = nil
		end
		v_u_13 = {}
		local v45 = {}
		for _, v46 in ipairs(v38) do
			local v47 = v_u_12
			for v50, v49 in pairs(v47) do
				if v49 ~= v46 then
					continue
				end
			end
			local v50 = nil
			if v50 then
				break
			end
			table.insert(v45, v46)
		end
		for _, v51 in ipairs(v45) do
			local v52 = v_u_6:GetAbilityConfig(v51)
			if not v52 then
				continue
			end
			local v53 = v52.Slot
			local v54 = tonumber(v53)
			if v54 <= 0 then
				continue
			end
			if v_u_12[v54] or v54 > v39 then
				local v55 = v_u_13
				table.insert(v55, v51)
			else
				v_u_12[v54] = v51
			end
		end
		for _, v56 in ipairs(v45) do
			local v57 = v_u_6:GetAbilityConfig(v56)
			if not v57 then
				continue
			end
			local v58 = v57.Slot
			if tonumber(v58) ~= 0 then
				continue
			end
			local v59 = v_u_35[v56]
			if v59 and (v59 > 0 and (v59 <= v39 and not v_u_12[v59])) then
				v_u_12[v59] = v56
			else
				local v60 = -1
				for v61 = 1, v39 do
					if v_u_12[v61] then
						continue
					end
					v60 = v61
				end
				if v60 == -1 then
					local v62 = v_u_13
					table.insert(v62, v56)
				else
					v_u_12[v60] = v56
					v_u_35[v56] = v60
				end
			end
		end
		v_u_11.setOverflowScrollIndex(v_u_11.getOverflowScrollIndex())
		if not (v_u_24(v_u_12, v36) and v_u_24(v_u_13, v37)) then
			v_u_16:Fire()
		end
	end
	v_u_6:GetAbilitiesChangedSignal():Connect(v63)
	v_u_4:GetPropertyChangedSignal("PreferredInput"):Connect(v63)
	v63()
	task.spawn(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_10, (ref) v_u_7, (copy) p_u_30, (copy) p_u_29, (ref) v_u_14, (ref) v_u_12, (copy) v_u_34, (ref) v_u_15, (ref) v_u_13, (ref) v_u_17
		local function v_u_69(p64, p65, p66) -- name: UpdateAbilityInPCS
			-- upvalues: (ref) v_u_8, (ref) v_u_10
			local v67 = p64.Character
			if v67 then
				local v68
				if v_u_8 then
					v68 = v67:FindFirstChildOfClass(v_u_10)
				else
					v68 = v67:FindFirstChild(v_u_10)
				end
				if v68 then
					v68:UpdateFields({
						[p65] = p66
					})
				end
			else
				return
			end
		end
		local v70
		if v_u_7 and not p_u_30 then
			v70 = script.Parent.Parent:FindFirstChild("InputContexts")
		else
			v70 = p_u_29:WaitForChild("InputContexts", (1 / 0))
		end
		local v71 = v70:WaitForChild("CharacterContext")
		for v_u_72 = 1, 11 do
			local v73 = v71:WaitForChild("AbilityAction" .. tostring(v_u_72))
			v_u_14[v_u_72] = v73
			v73.StateChanged:Connect(function(p74)
				-- upvalues: (ref) v_u_7, (ref) v_u_12, (copy) v_u_72, (copy) v_u_69, (ref) p_u_29, (ref) v_u_34
				if v_u_7 then
					if v_u_12[v_u_72] ~= nil and v_u_12[v_u_72] ~= "" then
						v_u_69(p_u_29, v_u_12[v_u_72], p74)
						return
					end
				else
					local v75 = v_u_34(v_u_12[v_u_72])
					local v76 = v75 and v75:FindFirstChild("ScriptableBinding")
					if v76 then
						v76:Fire(p74)
					end
				end
			end)
		end
		if v_u_7 then
			for v_u_77 = 1, 3 do
				local v78 = v71:WaitForChild("OverflowAction" .. tostring(v_u_77))
				v_u_15[v_u_77] = v78
				v78.StateChanged:Connect(function(p79)
					-- upvalues: (ref) v_u_13, (copy) v_u_77, (ref) v_u_17, (copy) v_u_69, (ref) p_u_29
					local v80 = v_u_13[v_u_77 + v_u_17]
					if v80 ~= nil and v80 ~= "" then
						v_u_69(p_u_29, v80, p79)
					end
				end)
			end
		end
	end)
end
function v_u_11.GetSlotMapChangedSignal() -- name: GetSlotMapChangedSignal
	-- upvalues: (copy) v_u_16
	return v_u_16.Event
end
function v_u_11.GetSlotMap() -- name: GetSlotMap
	-- upvalues: (copy) v_u_12
	return v_u_12
end
function v_u_11.GetAbilitiesInOverflow() -- name: GetAbilitiesInOverflow
	-- upvalues: (ref) v_u_13
	return v_u_13
end
function v_u_11.GetActionInSlot(p81) -- name: GetActionInSlot
	-- upvalues: (copy) v_u_14
	return v_u_14[p81]
end
function v_u_11.GetOverflowAction(p82) -- name: GetOverflowAction
	-- upvalues: (copy) v_u_15
	return v_u_15[p82]
end
return v_u_11