local v1 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
local v_u_2 = script.Parent.Parent:WaitForChild("InputContexts"):WaitForChild("CameraContext"):WaitForChild("MouseLockSwitchAction")
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = UserSettings().GameSettings
local v_u_6 = require(script.Parent:WaitForChild("CameraUtils"))
local v_u_7 = v1.getUserFlag("UserFixStuckShiftLock")
local v_u_8 = {}
v_u_8.__index = v_u_8
function v_u_8.new() -- name: new
	-- upvalues: (copy) v_u_8, (copy) v_u_5, (copy) v_u_3, (copy) v_u_4, (copy) v_u_2
	local v9 = v_u_8
	local v_u_10 = setmetatable({}, v9)
	v_u_10.isMouseLocked = false
	v_u_10.savedMouseCursor = nil
	v_u_10.enabled = false
	v_u_10.mouseLockToggledEvent = Instance.new("BindableEvent")
	v_u_5.Changed:Connect(function(p11)
		-- upvalues: (copy) v_u_10
		if p11 == "ControlMode" or p11 == "ComputerMovementMode" then
			v_u_10:UpdateMouseLockAvailability()
		end
	end)
	v_u_3.LocalPlayer:GetPropertyChangedSignal("DevEnableMouseLock"):Connect(function()
		-- upvalues: (copy) v_u_10
		v_u_10:UpdateMouseLockAvailability()
	end)
	v_u_3.LocalPlayer:GetPropertyChangedSignal("DevComputerMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_10
		v_u_10:UpdateMouseLockAvailability()
	end)
	v_u_4:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		-- upvalues: (copy) v_u_10
		v_u_10:UpdateMouseLockAvailability()
	end)
	v_u_10:UpdateMouseLockAvailability()
	v_u_2.Pressed:Connect(function()
		-- upvalues: (copy) v_u_10
		v_u_10:OnMouseLockToggled()
	end)
	return v_u_10
end
function v_u_8.GetIsMouseLocked(p12) -- name: GetIsMouseLocked
	return p12.isMouseLocked
end
function v_u_8.GetBindableToggleEvent(p13) -- name: GetBindableToggleEvent
	return p13.mouseLockToggledEvent.Event
end
function v_u_8.GetMouseLockOffset(_) -- name: GetMouseLockOffset
	return Vector3.new(1.75, 0, 0)
end
function v_u_8.UpdateMouseLockAvailability(p14) -- name: UpdateMouseLockAvailability
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4
	local v15 = v_u_3.LocalPlayer.DevEnableMouseLock
	local v16 = v_u_3.LocalPlayer.DevComputerMovementMode == Enum.DevComputerMovementMode.Scriptable
	local v17 = v_u_5.ControlMode == Enum.ControlMode.MouseLockSwitch
	local v18 = v_u_5.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove
	local v19 = v_u_4.PreferredInput == Enum.PreferredInput.KeyboardAndMouse and (v15 and (v17 and not v18))
	if v19 then
		v19 = not v16
	end
	if v19 ~= p14.enabled then
		p14:EnableMouseLock(v19)
	end
end
function v_u_8.OnMouseLockToggled(p20) -- name: OnMouseLockToggled
	-- upvalues: (copy) v_u_6
	p20.isMouseLocked = not p20.isMouseLocked
	if p20.isMouseLocked then
		local v21 = script:FindFirstChild("CursorImage")
		if v21 and (v21:IsA("StringValue") and v21.Value) then
			v_u_6.setMouseIconOverride(v21.Value)
		else
			if v21 then
				v21:Destroy()
			end
			local v22 = Instance.new("StringValue")
			assert(v22, "")
			v22.Name = "CursorImage"
			v22.Value = "rbxasset://textures/MouseLockedCursor.png"
			v22.Parent = script
			v_u_6.setMouseIconOverride("rbxasset://textures/MouseLockedCursor.png")
		end
	else
		v_u_6.restoreMouseIcon()
	end
	p20.mouseLockToggledEvent:Fire()
end
function v_u_8.IsMouseLocked(p23) -- name: IsMouseLocked
	local v24 = p23.enabled
	if v24 then
		v24 = p23.isMouseLocked
	end
	return v24
end
function v_u_8.EnableMouseLock(p25, p26) -- name: EnableMouseLock
	-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_7
	if p26 == p25.enabled then
		return
	else
		p25.enabled = p26
		if p25.enabled then
			v_u_2.Enabled = true
		else
			v_u_6.restoreMouseIcon()
			v_u_2.Enabled = false
			if v_u_7 then
				if p25.isMouseLocked then
					p25.isMouseLocked = false
					p25.mouseLockToggledEvent:Fire()
					return
				end
			else
				if p25.isMouseLocked then
					p25.mouseLockToggledEvent:Fire()
				end
				p25.isMouseLocked = false
			end
		end
	end
end
return v_u_8