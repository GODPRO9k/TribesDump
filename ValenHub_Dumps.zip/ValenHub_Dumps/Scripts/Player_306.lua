local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = v2:WaitForChild("Shared")
local v_u_6 = require(v_u_5:WaitForChild("ReplayCodec"))
local v_u_7 = require(v_u_5:WaitForChild("Combat"))
local v_u_8 = require(v_u_5.Combat:WaitForChild("Ballistics"))
local v_u_9 = require(script.Parent.Clip)
local v_u_10 = require(script.Parent.Puppets)
local v_u_11 = require(script.Parent.Locomotion)
local v_u_12 = require(script.Parent.Director)
local v_u_13 = require(script.Parent.Overlay)
local v_u_14 = require(script.Parent.Stage)
local v_u_15 = require(script.Parent.PoseTrace)
local v_u_16 = require(script.Parent.Hud)
local v_u_17 = require(script.Parent.View)
local v_u_18 = require(script.Parent.Diag)
local v_u_19 = {}
local v_u_20 = v1.LocalPlayer
local v_u_21 = script.Parent.Parent
local v_u_22 = {}
local function v_u_29() -- name: loadCombat
	-- upvalues: (copy) v_u_22, (copy) v_u_21
	if v_u_22.Controller then
		return
	else
		local v23 = v_u_21:FindFirstChild("Combat")
		if v23 then
			for _, v24 in {
				"Controller",
				"Util",
				"Effects",
				"Presentation",
				"Guard",
				"Poses",
				"Hud"
			} do
				local v25 = v23:FindFirstChild(v24)
				if not (v25 and v25:IsA("ModuleScript")) then
					continue
				end
				local v26 = require
				local v27, v28 = pcall(v26, v25)
				if v27 and type(v28) == "table" then
					v_u_22[v24] = v28
				else
					warn("[Replay] combat module unavailable:", v24, v28)
				end
			end
		end
	end
end
local v_u_30 = {}
task.spawn(function()
	-- upvalues: (copy) v_u_21, (copy) v_u_30
	local v31 = v_u_21:WaitForChild("Character", 15)
	if v31 then
		v31 = v31:WaitForChild("Procedural", 15)
	end
	if v31 and v31:IsA("ModuleScript") then
		local v32 = require
		local v33, v34 = pcall(v32, v31)
		if v33 and type(v34) == "table" then
			v_u_30.Procedural = v34
		end
	end
end)
local v_u_35 = nil
task.spawn(function()
	-- upvalues: (copy) v_u_5, (ref) v_u_35
	local v36 = v_u_5:WaitForChild("Sfx", 15)
	if v36 and v36:IsA("ModuleScript") then
		local v37 = require
		local v38, v39 = pcall(v37, v36)
		if v38 and type(v39) == "table" then
			v_u_35 = v39
		end
	end
end)
local v_u_40 = nil
local v_u_41 = 0
local v_u_42 = {}
local v_u_43 = {}
local function v_u_51(p44) -- name: holdFor
	-- upvalues: (copy) v_u_22, (copy) v_u_7
	local v45 = v_u_22.Presentation
	if not (p44 and v45) then
		return nil
	end
	local v46 = v45.For
	local v47 = v_u_7.Kind
	local v48, v49 = pcall(v46, p44, v47(p44))
	if v48 and type(v49) == "table" then
		local v50 = v49.hold
		if type(v50) == "string" then
			return v49.hold
		end
	end
	return nil
end
local function v_u_58(p52, p53) -- name: setItem
	-- upvalues: (copy) v_u_10, (copy) v_u_22, (copy) v_u_51
	local v54 = p52.hold
	if v_u_10.SetItem(p52, p53) then
		local v55 = v_u_22.Util
		local v56 = v_u_51(p53)
		if v55 and (v54 and v54 ~= v56) then
			v55.StopAnim(p52.animator, v54, 0.15)
		end
		if v55 and (v56 and p52.alive) then
			local v57 = v55.GetTrack(p52.animator, v56)
			if v57 and not v57.IsPlaying then
				v55.PlayAnim(p52.animator, v56, 1, 0.2)
			end
		end
		p52.hold = v56
	end
end
local function v_u_63(p59) -- name: onPuppetDied
	-- upvalues: (copy) v_u_11, (copy) v_u_22
	if p59.loco then
		v_u_11.Stop(p59.loco)
	end
	for _, v60 in p59.animator:GetPlayingAnimationTracks() do
		v60:Stop(0.25)
	end
	if p59.blocking and v_u_22.Guard then
		local v61 = v_u_22.Guard.Set
		local v62 = p59.model
		pcall(v61, v62, false)
		p59.blocking = false
	end
end
local function v_u_72(p64, p65) -- name: resolveRefs
	-- upvalues: (copy) v_u_10
	for v66, v67 in p65 do
		if type(v67) ~= "table" then
			continue
		end
		local v68 = v67.fighter
		local v69
		if type(v68) == "number" then
			v69 = p64.puppets[v68]
		else
			v69 = nil
		end
		if v69 then
			local v70 = v67.part
			local v71
			if type(v70) == "string" then
				v71 = v_u_10.Part(v69, v67.part)
			else
				v71 = v69.model
			end
			p65[v66] = v71
		else
			p65[v66] = nil
		end
	end
end
local function v_u_92(p73, p74) -- name: playAnim
	-- upvalues: (copy) v_u_22
	local v75 = p74.attacker
	local v76
	if type(v75) == "table" then
		local v77 = v75.fighter
		if type(v77) == "number" then
			v76 = v75.fighter
		else
			v76 = nil
		end
	else
		v76 = nil
	end
	if v76 then
		v76 = p73.puppets[v76]
	end
	local v78 = v_u_22.Util
	if v76 and (v78 and (v76.alive and v76.visible)) then
		local v79 = p74.name
		if type(v79) == "string" then
			local v80 = p74.speed
			local v81 = tonumber(v80) or 1
			if p74.op == "Play" then
				local v82 = v78.PlayAnim
				local v83 = v76.animator
				local v84 = p74.name
				local v85 = p74.fade
				local v86 = tonumber(v85)
				local v87 = p74.weight
				v82(v83, v84, v81, v86, (tonumber(v87)))
				return
			elseif p74.op == "Hold" then
				v78.PlayHold(v76.animator, p74.name, v81)
			elseif p74.op == "Stop" then
				local v88 = v78.StopAnim
				local v89 = v76.animator
				local v90 = p74.name
				local v91 = p74.fade
				v88(v89, v90, (tonumber(v91)))
			end
		end
	end
end
local v_u_93 = nil
local function v_u_120(p94, p95, p96, p97, p98, p99, p100) -- name: logAction
	-- upvalues: (ref) v_u_93, (copy) v_u_7
	local v101 = v_u_93
	if v101 and p94.phase == "play" then
		if p95 == "Projectile" and p98 == p94.focus then
			local v102 = p96.origin
			if typeof(v102) == "Vector3" then
				local v103 = p96.velocity
				if typeof(v103) == "Vector3" and p96.velocity.Magnitude > 0.1 then
					local v104 = p96.key
					local v105 = tostring(v104)
					local v106 = p94.landed[v105] or p94.landed[v105 .. "/1"]
					local v107
					if v106 then
						local v108 = (v106 - p96.origin).Magnitude
						v107 = math.clamp(v108, 8, 400)
					else
						v107 = 80
					end
					local v109 = v101.pending
					local v110 = {
						["kind"] = "shot",
						["t"] = nil,
						["point"] = nil,
						["victim"] = nil,
						["weapon"] = nil,
						["t"] = p97,
						["point"] = p96.origin + p96.velocity.Unit * v107,
						["victim"] = p94.landedOn[v105] or p94.landedOn[v105 .. "/1"],
						["weapon"] = p96.weaponId
					}
					table.insert(v109, v110)
					return
				end
			end
		end
		if p95 == "Hit" and p99 == p94.focus then
			local v111 = p96.position
			if typeof(v111) == "Vector3" then
				local v112 = p96.weaponId
				if type(v112) == "string" and v_u_7.IsMelee(v_u_7.Kind(p96.weaponId)) then
					local v113 = v101.pending
					local v114 = {
						["kind"] = "melee",
						["t"] = nil,
						["point"] = nil,
						["victim"] = nil,
						["weapon"] = nil,
						["killed"] = nil,
						["t"] = p97,
						["point"] = p96.position
					}
					local v115 = p96.target
					local v116
					if type(v115) == "table" then
						local v117 = v115.fighter
						if type(v117) == "number" then
							v116 = v115.fighter
						else
							v116 = nil
						end
					else
						v116 = nil
					end
					v114.victim = v116
					v114.weapon = p96.weaponId
					v114.killed = p96.killed == true
					table.insert(v113, v114)
					return
				end
			end
		end
		if p95 == "Damage" and (p99 == p94.focus and (p96.killed == true and p100)) then
			local v118 = v101.pending
			local v119 = {
				["kind"] = "kill",
				["t"] = nil,
				["victim"] = nil,
				["weapon"] = nil,
				["t"] = p97,
				["victim"] = p100,
				["weapon"] = p96.weaponId
			}
			table.insert(v118, v119)
		end
	end
end
local function v_u_157(p121, p122, p123) -- name: logCamera
	-- upvalues: (ref) v_u_93
	local v124 = v_u_93
	if v124 and p121.phase == "play" then
		local v125 = p123.CFrame
		local v126 = v125.LookVector
		local v127 = #v124.t + 1
		v124.t[v127] = p122
		local v128 = v124.yaw
		local v129 = -v126.X
		local v130 = -v126.Z
		v128[v127] = math.atan2(v129, v130)
		local v131 = v124.pitch
		local v132 = v126.Y
		local v133 = math.clamp(v132, -1, 1)
		v131[v127] = math.asin(v133)
		local v134 = v124.x
		local v135 = v124.y
		local v136 = v124.z
		local v137 = v125.Position.X
		local v138 = v125.Position.Y
		local v139 = v125.Position.Z
		v134[v127] = v137
		v135[v127] = v138
		v136[v127] = v139
		v124.fov[v127] = p123.FieldOfView
		v124.startTime = p121.payload.startTime
		v124.focus = p121.clip.fighters[p121.focus].id
		v124.duration = p121.clip.duration
		for _, v140 in v124.pending do
			local v141 = {
				["kind"] = v140.kind,
				["t"] = v140.t,
				["frameT"] = p122,
				["weapon"] = v140.weapon,
				["killed"] = v140.killed
			}
			if v140.point then
				local v142 = v140.point - v125.Position
				local v143 = (v142 - v126 * v142:Dot(v126)).Magnitude
				local v144 = v126:Dot(v142.Unit)
				local v145 = math.clamp(v144, -1, 1)
				local v146 = math.acos(v145)
				local v147 = math.deg(v146)
				v141.missStuds = v143
				v141.missDeg = v147
				v141.dist = (v140.point - v125.Position).Magnitude
			end
			local v148 = v140.victim
			local v149
			if v148 then
				v149 = p121.states[v148]
			else
				v149 = v148
			end
			if v149 and v149.present then
				local v150 = v149.cf.Position + Vector3.new(0, 0.5, 0) - v125.Position
				local v151 = (v150 - v126 * v150:Dot(v126)).Magnitude
				local v152 = v126:Dot(v150.Unit)
				local v153 = math.clamp(v152, -1, 1)
				local v154 = math.acos(v153)
				local v155 = math.deg(v154)
				v141.victimMissStuds = v151
				v141.victimMissDeg = v155
				v141.victim = p121.clip.fighters[v148].id
			end
			local v156 = v124.shots
			table.insert(v156, v141)
		end
		table.clear(v124.pending)
	end
end
local function v_u_219(p158, p159) -- name: dispatch
	-- upvalues: (copy) v_u_92, (ref) v_u_93, (copy) v_u_120, (copy) v_u_72, (copy) v_u_16, (copy) v_u_12, (copy) v_u_17, (copy) v_u_22, (copy) v_u_7
	local v160 = p159.kind
	local v161 = p159.data
	local v162 = p158.stats
	v162.events = v162.events + 1
	p158.stats.kinds[v160] = (p158.stats.kinds[v160] or 0) + 1
	if v160 == "Phase" then
		return
	elseif v160 == "Anim" then
		v_u_92(p158, v161)
		return
	else
		local v163 = v161.killer
		if type(v163) == "table" then
			local v164 = v163.fighter
			if type(v164) == "number" then
				local _ = v163.fighter
			end
		end
		local v165 = v161.target
		local v166
		if type(v165) == "table" then
			local v167 = v165.fighter
			if type(v167) == "number" then
				v166 = v165.fighter
			else
				v166 = nil
			end
		else
			v166 = nil
		end
		local v168 = v161.shooter
		local v169
		if type(v168) == "table" then
			local v170 = v168.fighter
			if type(v170) == "number" then
				v169 = v168.fighter
			else
				v169 = nil
			end
		else
			v169 = nil
		end
		local v171 = v161.attacker
		local v172
		if type(v171) == "table" then
			local v173 = v171.fighter
			if type(v173) == "number" then
				v172 = v171.fighter
			else
				v172 = nil
			end
		else
			v172 = nil
		end
		local v174 = v161.fighter
		local v175
		if type(v174) == "table" then
			local v176 = v174.fighter
			if type(v176) == "number" then
				v175 = v174.fighter
			else
				v175 = nil
			end
		else
			v175 = nil
		end
		local v177 = v161.victim
		local v178
		if type(v177) == "table" then
			local v179 = v177.fighter
			if type(v179) == "number" then
				v178 = v177.fighter
			else
				v178 = nil
			end
		else
			v178 = nil
		end
		if v_u_93 then
			v_u_120(p158, v160, v161, p159.t, v169, v172, v178)
		end
		if v160 == "Projectile" and (v169 == p158.focus and p158.phase == "play") then
			local v180 = v161.origin
			if typeof(v180) == "Vector3" then
				local v181 = v161.velocity
				if typeof(v181) == "Vector3" and v161.velocity.Magnitude > 0.1 then
					local v182 = v161.key
					local v183 = tostring(v182)
					local v184 = p158.landed[v183] or p158.landed[v183 .. "/1"]
					local v185
					if v184 then
						local v186 = (v184 - v161.origin).Magnitude
						v185 = math.clamp(v186, 8, 400)
					else
						v185 = 80
					end
					p158.diagShot = v161.origin + v161.velocity.Unit * v185
				end
			end
		end
		v_u_72(p158, v161)
		if v160 == "Inv" then
			if v175 == p158.focus then
				v_u_16.OnFighterEvent("Inv", v161, p159.t)
			end
			return
		elseif v160 == "Damage" then
			local v187 = p158.clip.fighters
			if v172 == p158.focus and v178 ~= p158.focus then
				local v188 = v_u_16.HitConfirm
				local v189
				if v178 and v187[v178] then
					v189 = v187[v178].id
				else
					v189 = nil
				end
				v188(v161, v189)
				if v161.killed == true then
					v_u_12.OnKill()
					return
				end
			elseif v178 == p158.focus then
				local v190 = v_u_16.DamageTaken
				local v191
				if v172 and v187[v172] then
					v191 = v187[v172].id
				else
					v191 = nil
				end
				v190(v161, v191)
				if v161.damageType ~= "Burn" and v161.damageType ~= "World" then
					local v192 = v_u_17.Hurt
					local v193 = v161.amount
					v192(tonumber(v193) or 0, v161.blocked == true)
				end
			end
		else
			local v194
			if v160 == "Hit" then
				v194 = v161.target
			elseif v160 == "ProjectileHit" then
				v194 = v161.character
			else
				v194 = nil
			end
			if typeof(v194) == "Instance" then
				local v195 = v161.position
				if typeof(v195) == "Vector3" then
					local v196 = v194:FindFirstChild("HumanoidRootPart")
					if v196 and v196:IsA("BasePart") then
						local v197 = v161.position - v196.Position
						local v198 = v197.X
						local v199 = v197.Z
						local v200 = Vector3.new(v198, 0, v199).Magnitude - 1.5
						local v201 = math.max(0, v200)
						local v202 = p158.stats
						v202.hits = v202.hits + 1
						local v203 = p158.stats
						v203.hitErrSum = v203.hitErrSum + v201
						local v204 = p158.stats
						local v205 = p158.stats.hitErrMax
						v204.hitErrMax = math.max(v205, v201)
					end
				end
			end
			if v160 == "Projectile" or v160 == "ProjectileHit" then
				local v206 = v161.key
				v161.key = "R|" .. tostring(v206)
			end
			local v207
			if (v169 or v172) == p158.focus then
				v207 = true
			elseif v160 == "Heal" then
				v207 = v166 == p158.focus
			else
				v207 = false
			end
			local v208 = v_u_22.Controller
			if v207 and (v160 == "Swing" and v_u_12.InFirstPerson()) then
				local v209 = v_u_22.Util
				local v210 = v_u_22.Presentation
				if v209 and v210 then
					local v211 = v210.For
					local v212 = v161.weaponId
					local v213 = v_u_7.Kind(v161.weaponId) or "Fists"
					local v214, v215 = pcall(v211, v212, v213)
					if v214 and type(v215) == "table" then
						local v216
						if v161.heavy == true then
							v216 = v215.heavySound or v215.swingSound
						elseif v161.lunge == true then
							v216 = v215.lungeSound or v215.swingSound
						else
							v216 = v215.swingSound
						end
						local v217 = v209.Sound
						pcall(v217, v216 or "Swing_Sword")
					end
				end
			elseif v208 then
				local v218 = v208.PlayFX
				if type(v218) == "function" then
					v208.PlayFX(v160, v161)
				end
			end
			if v207 and (v160 == "Charge" or (v160 == "Projectile" or (v160 == "Swing" or (v160 == "Reload" or (v160 == "Use" or v160 == "Heal"))))) then
				v_u_17.OnFighterEvent(v160, v161, v_u_16.ChargeAt(p159.t))
				v_u_16.OnFighterEvent(v160, v161, p159.t)
			end
		end
	end
end
local function v_u_278(p220) -- name: applyPreroll
	-- upvalues: (copy) v_u_16, (copy) v_u_219, (copy) v_u_22, (copy) v_u_8
	local v221 = p220.clip.events
	local v222 = {}
	for _, v223 in v221 do
		if v223.kind ~= "ProjectileHit" then
			continue
		end
		local v224 = v223.data.key
		local v225 = tostring(v224)
		if v222[v225] ~= nil then
			continue
		end
		v222[v225] = v223.t
	end
	local v226 = 1
	local v227 = {}
	while true do
		local v228, v229, v230, v231, v232, v233, v234, v235, v236, v237, v238, v239, v240, v241, v242, v243, v244, v245, v246, v247, v248, v249, v250, v251, v252, v253, v254, v255, v256, v257, v258, v259
		while true do
			while true do
				if v226 > #v221 or v221[v226].t >= 0 then
					p220.nextEvent = v226
					local v260 = v_u_22.Util
					if v260 then
						for v261, v262 in v227 do
							local v263 = p220.puppets[v261]
							if not (v263 and v263.alive) then
								continue
							end
							for v264, v265 in v262 do
								v260.PlayHold(v263.animator, v264, v265)
							end
						end
					end
					return
				end
				local v266 = v221[v226]
				local v267 = v266.data
				if v266.kind ~= "Anim" then
					break
				end
				local v268 = v267.attacker
				local v269
				if type(v268) == "table" then
					local v270 = v268.fighter
					if type(v270) == "number" then
						v269 = v268.fighter
					else
						v269 = nil
					end
				else
					v269 = nil
				end
				if v269 then
					local v271 = v267.name
					if type(v271) == "string" then
						v227[v269] = v227[v269] or {}
						if v267.op == "Hold" then
							local v272 = v227[v269]
							local v273 = v267.name
							local v274 = v267.speed
							v272[v273] = tonumber(v274) or 1
						elseif v267.op == "Stop" then
							v227[v269][v267.name] = nil
						end
					end
				end
				v226 = v226 + 1
			end
			if v266.kind == "Inv" then
				break
			end
			if v266.kind == "Charge" then
				v228 = v267.attacker
				if type(v228) == "table" then
					v229 = v228.fighter
					if type(v229) == "number" then
						v230 = v228.fighter
					else
						v230 = nil
					end
				else
					v230 = nil
				end
				if v230 == p220.focus then
					v_u_16.OnFighterEvent("Charge", v267, v266.t)
					v226 = v226 + 1
				else
					if v266.kind == "Projectile" then
						goto l9
					end
					if v266.kind ~= "Swing" then
						if v266.kind == "Smoke" then
							v231 = v267.duration
							v232 = (tonumber(v231) or 7) + v266.t
							if v232 > 0.4 then
								v267.duration = v232
								v_u_219(p220, v266)
							end
						elseif v266.kind == "Status" and v267.status == "Burn" then
							v233 = v267.duration
							v234 = (tonumber(v233) or 1) + v266.t
							if v234 > 0.2 then
								v267.duration = v234
								v_u_219(p220, v266)
							end
						elseif v266.kind == "Projectile" and (v266.t > -2.5 and not v267.pellets) then
							v235 = v267.key
							v236 = tostring(v235)
							v237 = v222[v236]
							v238 = v_u_22.Effects
							v239 = v267.shooter
							if type(v239) == "table" then
								v240 = v239.fighter
								if type(v240) == "number" then
									v241 = v239.fighter
								else
									v241 = nil
								end
							else
								v241 = nil
							end
							if v241 then
								v241 = p220.puppets[v241]
							end
							if (v237 == nil or v237 >= 0) and v238 then
								v242 = v267.origin
								if typeof(v242) == "Vector3" then
									v243 = v267.velocity
									if typeof(v243) == "Vector3" then
										v244 = v267.kind
										if type(v244) == "string" then
											v245 = v267.gravity
											v246 = tonumber(v245) or 0
											v247 = v_u_8.new(v267.origin, v267.velocity, v246, 0)
											v_u_8.Advance(v247, -v266.t)
											v248 = v238.Projectile
											v249 = "R|" .. v236
											v250 = v267.kind
											v251 = v247.pos
											v252 = v247.vel
											if v241 then
												v253 = v241.model
											else
												v253 = nil
											end
											pcall(v248, v249, v250, v251, v252, v246, v253)
										end
									end
								end
							end
						end
						goto l66
					end
					::l16::
					v254 = v267.attacker
					if type(v254) == "table" then
						v255 = v254.fighter
						if type(v255) == "number" then
							v256 = v254.fighter
						else
							v256 = nil
						end
					else
						v256 = nil
					end
					if v256 ~= p220.focus then
						if v266.kind == "Smoke" then
							v231 = v267.duration
							v232 = (tonumber(v231) or 7) + v266.t
							if v232 > 0.4 then
								v267.duration = v232
								v_u_219(p220, v266)
							end
						elseif v266.kind == "Status" and v267.status == "Burn" then
							v233 = v267.duration
							v234 = (tonumber(v233) or 1) + v266.t
							if v234 > 0.2 then
								v267.duration = v234
								v_u_219(p220, v266)
							end
						elseif v266.kind == "Projectile" and (v266.t > -2.5 and not v267.pellets) then
							v235 = v267.key
							v236 = tostring(v235)
							v237 = v222[v236]
							v238 = v_u_22.Effects
							v239 = v267.shooter
							if type(v239) == "table" then
								v240 = v239.fighter
								if type(v240) == "number" then
									v241 = v239.fighter
								else
									v241 = nil
								end
							else
								v241 = nil
							end
							if v241 then
								v241 = p220.puppets[v241]
							end
							if (v237 == nil or v237 >= 0) and v238 then
								v242 = v267.origin
								if typeof(v242) == "Vector3" then
									v243 = v267.velocity
									if typeof(v243) == "Vector3" then
										v244 = v267.kind
										if type(v244) == "string" then
											v245 = v267.gravity
											v246 = tonumber(v245) or 0
											v247 = v_u_8.new(v267.origin, v267.velocity, v246, 0)
											v_u_8.Advance(v247, -v266.t)
											v248 = v238.Projectile
											v249 = "R|" .. v236
											v250 = v267.kind
											v251 = v247.pos
											v252 = v247.vel
											if v241 then
												v253 = v241.model
											else
												v253 = nil
											end
											pcall(v248, v249, v250, v251, v252, v246, v253)
										end
									end
								end
							end
						end
						goto l66
					end
					v_u_16.OnFighterEvent("Charge", {
						["on"] = false
					}, v266.t)
					v226 = v226 + 1
				end
			elseif v266.kind == "Projectile" then
				v257 = v267.shooter
				if type(v257) == "table" then
					v258 = v257.fighter
					if type(v258) == "number" then
						v259 = v257.fighter
					else
						v259 = nil
					end
				else
					v259 = nil
				end
				if v259 ~= p220.focus then
					goto l73
				end
				v_u_16.OnFighterEvent("Charge", {
					["on"] = false
				}, v266.t)
				v226 = v226 + 1
			else
				if v266.kind ~= "Swing" then
					if v266.kind == "Smoke" then
						v231 = v267.duration
						v232 = (tonumber(v231) or 7) + v266.t
						if v232 > 0.4 then
							v267.duration = v232
							v_u_219(p220, v266)
						end
					elseif v266.kind == "Status" and v267.status == "Burn" then
						v233 = v267.duration
						v234 = (tonumber(v233) or 1) + v266.t
						if v234 > 0.2 then
							v267.duration = v234
							v_u_219(p220, v266)
						end
					elseif v266.kind == "Projectile" and (v266.t > -2.5 and not v267.pellets) then
						v235 = v267.key
						v236 = tostring(v235)
						v237 = v222[v236]
						v238 = v_u_22.Effects
						v239 = v267.shooter
						if type(v239) == "table" then
							v240 = v239.fighter
							if type(v240) == "number" then
								v241 = v239.fighter
							else
								v241 = nil
							end
						else
							v241 = nil
						end
						if v241 then
							v241 = p220.puppets[v241]
						end
						if (v237 == nil or v237 >= 0) and v238 then
							v242 = v267.origin
							if typeof(v242) == "Vector3" then
								v243 = v267.velocity
								if typeof(v243) == "Vector3" then
									v244 = v267.kind
									if type(v244) == "string" then
										v245 = v267.gravity
										v246 = tonumber(v245) or 0
										v247 = v_u_8.new(v267.origin, v267.velocity, v246, 0)
										v_u_8.Advance(v247, -v266.t)
										v248 = v238.Projectile
										v249 = "R|" .. v236
										v250 = v267.kind
										v251 = v247.pos
										v252 = v247.vel
										if v241 then
											v253 = v241.model
										else
											v253 = nil
										end
										pcall(v248, v249, v250, v251, v252, v246, v253)
									end
								end
							end
						end
					end
					goto l66
				end
				v254 = v267.attacker
				if type(v254) == "table" then
					v255 = v254.fighter
					if type(v255) == "number" then
						v256 = v254.fighter
					else
						v256 = nil
					end
				else
					v256 = nil
				end
				if v256 == p220.focus then
					v_u_16.OnFighterEvent("Charge", {
						["on"] = false
					}, v266.t)
					v226 = v226 + 1
				else
					if v266.kind == "Smoke" then
						v231 = v267.duration
						v232 = (tonumber(v231) or 7) + v266.t
						if v232 > 0.4 then
							v267.duration = v232
							v_u_219(p220, v266)
						end
					elseif v266.kind == "Status" and v267.status == "Burn" then
						v233 = v267.duration
						v234 = (tonumber(v233) or 1) + v266.t
						if v234 > 0.2 then
							v267.duration = v234
							v_u_219(p220, v266)
						end
					elseif v266.kind == "Projectile" and (v266.t > -2.5 and not v267.pellets) then
						v235 = v267.key
						v236 = tostring(v235)
						v237 = v222[v236]
						v238 = v_u_22.Effects
						v239 = v267.shooter
						if type(v239) == "table" then
							v240 = v239.fighter
							if type(v240) == "number" then
								v241 = v239.fighter
							else
								v241 = nil
							end
						else
							v241 = nil
						end
						if v241 then
							v241 = p220.puppets[v241]
						end
						if (v237 == nil or v237 >= 0) and v238 then
							v242 = v267.origin
							if typeof(v242) == "Vector3" then
								v243 = v267.velocity
								if typeof(v243) == "Vector3" then
									v244 = v267.kind
									if type(v244) == "string" then
										v245 = v267.gravity
										v246 = tonumber(v245) or 0
										v247 = v_u_8.new(v267.origin, v267.velocity, v246, 0)
										v_u_8.Advance(v247, -v266.t)
										v248 = v238.Projectile
										v249 = "R|" .. v236
										v250 = v267.kind
										v251 = v247.pos
										v252 = v247.vel
										if v241 then
											v253 = v241.model
										else
											v253 = nil
										end
										pcall(v248, v249, v250, v251, v252, v246, v253)
									end
								end
							end
						end
					end
					::l66::
					v226 = v226 + 1
				end
			end
		end
		local v275 = v267.fighter
		local v276
		if type(v275) == "table" then
			local v277 = v275.fighter
			if type(v277) == "number" then
				v276 = v275.fighter
			else
				v276 = nil
			end
		else
			v276 = nil
		end
		if v276 == p220.focus then
			v_u_16.OnFighterEvent("Inv", v267, v266.t)
			v226 = v226 + 1
		elseif v266.kind == "Charge" then
			v228 = v267.attacker
			if type(v228) == "table" then
				v229 = v228.fighter
				if type(v229) == "number" then
					v230 = v228.fighter
				else
					v230 = nil
				end
			else
				v230 = nil
			end
			if v230 == p220.focus then
				v_u_16.OnFighterEvent("Charge", v267, v266.t)
				v226 = v226 + 1
			else
				if v266.kind ~= "Projectile" then
					if v266.kind == "Swing" then
						goto l16
					end
					if v266.kind == "Smoke" then
						v231 = v267.duration
						v232 = (tonumber(v231) or 7) + v266.t
						if v232 > 0.4 then
							v267.duration = v232
							v_u_219(p220, v266)
						end
					elseif v266.kind == "Status" and v267.status == "Burn" then
						v233 = v267.duration
						v234 = (tonumber(v233) or 1) + v266.t
						if v234 > 0.2 then
							v267.duration = v234
							v_u_219(p220, v266)
						end
					elseif v266.kind == "Projectile" and (v266.t > -2.5 and not v267.pellets) then
						v235 = v267.key
						v236 = tostring(v235)
						v237 = v222[v236]
						v238 = v_u_22.Effects
						v239 = v267.shooter
						if type(v239) == "table" then
							v240 = v239.fighter
							if type(v240) == "number" then
								v241 = v239.fighter
							else
								v241 = nil
							end
						else
							v241 = nil
						end
						if v241 then
							v241 = p220.puppets[v241]
						end
						if (v237 == nil or v237 >= 0) and v238 then
							v242 = v267.origin
							if typeof(v242) == "Vector3" then
								v243 = v267.velocity
								if typeof(v243) == "Vector3" then
									v244 = v267.kind
									if type(v244) == "string" then
										v245 = v267.gravity
										v246 = tonumber(v245) or 0
										v247 = v_u_8.new(v267.origin, v267.velocity, v246, 0)
										v_u_8.Advance(v247, -v266.t)
										v248 = v238.Projectile
										v249 = "R|" .. v236
										v250 = v267.kind
										v251 = v247.pos
										v252 = v247.vel
										if v241 then
											v253 = v241.model
										else
											v253 = nil
										end
										pcall(v248, v249, v250, v251, v252, v246, v253)
									end
								end
							end
						end
					end
					goto l66
				end
				::l9::
				v257 = v267.shooter
				if type(v257) == "table" then
					v258 = v257.fighter
					if type(v258) == "number" then
						v259 = v257.fighter
					else
						v259 = nil
					end
				else
					v259 = nil
				end
				if v259 == p220.focus then
					v_u_16.OnFighterEvent("Charge", {
						["on"] = false
					}, v266.t)
					v226 = v226 + 1
				else
					::l73::
					if v266.kind ~= "Swing" then
						if v266.kind == "Smoke" then
							v231 = v267.duration
							v232 = (tonumber(v231) or 7) + v266.t
							if v232 > 0.4 then
								v267.duration = v232
								v_u_219(p220, v266)
							end
						elseif v266.kind == "Status" and v267.status == "Burn" then
							v233 = v267.duration
							v234 = (tonumber(v233) or 1) + v266.t
							if v234 > 0.2 then
								v267.duration = v234
								v_u_219(p220, v266)
							end
						elseif v266.kind == "Projectile" and (v266.t > -2.5 and not v267.pellets) then
							v235 = v267.key
							v236 = tostring(v235)
							v237 = v222[v236]
							v238 = v_u_22.Effects
							v239 = v267.shooter
							if type(v239) == "table" then
								v240 = v239.fighter
								if type(v240) == "number" then
									v241 = v239.fighter
								else
									v241 = nil
								end
							else
								v241 = nil
							end
							if v241 then
								v241 = p220.puppets[v241]
							end
							if (v237 == nil or v237 >= 0) and v238 then
								v242 = v267.origin
								if typeof(v242) == "Vector3" then
									v243 = v267.velocity
									if typeof(v243) == "Vector3" then
										v244 = v267.kind
										if type(v244) == "string" then
											v245 = v267.gravity
											v246 = tonumber(v245) or 0
											v247 = v_u_8.new(v267.origin, v267.velocity, v246, 0)
											v_u_8.Advance(v247, -v266.t)
											v248 = v238.Projectile
											v249 = "R|" .. v236
											v250 = v267.kind
											v251 = v247.pos
											v252 = v247.vel
											if v241 then
												v253 = v241.model
											else
												v253 = nil
											end
											pcall(v248, v249, v250, v251, v252, v246, v253)
										end
									end
								end
							end
						end
						goto l66
					end
					v254 = v267.attacker
					if type(v254) == "table" then
						v255 = v254.fighter
						if type(v255) == "number" then
							v256 = v254.fighter
						else
							v256 = nil
						end
					else
						v256 = nil
					end
					if v256 ~= p220.focus then
						if v266.kind == "Smoke" then
							v231 = v267.duration
							v232 = (tonumber(v231) or 7) + v266.t
							if v232 > 0.4 then
								v267.duration = v232
								v_u_219(p220, v266)
							end
						elseif v266.kind == "Status" and v267.status == "Burn" then
							v233 = v267.duration
							v234 = (tonumber(v233) or 1) + v266.t
							if v234 > 0.2 then
								v267.duration = v234
								v_u_219(p220, v266)
							end
						elseif v266.kind == "Projectile" and (v266.t > -2.5 and not v267.pellets) then
							v235 = v267.key
							v236 = tostring(v235)
							v237 = v222[v236]
							v238 = v_u_22.Effects
							v239 = v267.shooter
							if type(v239) == "table" then
								v240 = v239.fighter
								if type(v240) == "number" then
									v241 = v239.fighter
								else
									v241 = nil
								end
							else
								v241 = nil
							end
							if v241 then
								v241 = p220.puppets[v241]
							end
							if (v237 == nil or v237 >= 0) and v238 then
								v242 = v267.origin
								if typeof(v242) == "Vector3" then
									v243 = v267.velocity
									if typeof(v243) == "Vector3" then
										v244 = v267.kind
										if type(v244) == "string" then
											v245 = v267.gravity
											v246 = tonumber(v245) or 0
											v247 = v_u_8.new(v267.origin, v267.velocity, v246, 0)
											v_u_8.Advance(v247, -v266.t)
											v248 = v238.Projectile
											v249 = "R|" .. v236
											v250 = v267.kind
											v251 = v247.pos
											v252 = v247.vel
											if v241 then
												v253 = v241.model
											else
												v253 = nil
											end
											pcall(v248, v249, v250, v251, v252, v246, v253)
										end
									end
								end
							end
						end
						goto l66
					end
					v_u_16.OnFighterEvent("Charge", {
						["on"] = false
					}, v266.t)
					v226 = v226 + 1
				end
			end
		elseif v266.kind == "Projectile" then
			v257 = v267.shooter
			if type(v257) == "table" then
				v258 = v257.fighter
				if type(v258) == "number" then
					v259 = v257.fighter
				else
					v259 = nil
				end
			else
				v259 = nil
			end
			if v259 ~= p220.focus then
				goto l73
			end
			v_u_16.OnFighterEvent("Charge", {
				["on"] = false
			}, v266.t)
			v226 = v226 + 1
		else
			if v266.kind ~= "Swing" then
				if v266.kind == "Smoke" then
					v231 = v267.duration
					v232 = (tonumber(v231) or 7) + v266.t
					if v232 > 0.4 then
						v267.duration = v232
						v_u_219(p220, v266)
					end
				elseif v266.kind == "Status" and v267.status == "Burn" then
					v233 = v267.duration
					v234 = (tonumber(v233) or 1) + v266.t
					if v234 > 0.2 then
						v267.duration = v234
						v_u_219(p220, v266)
					end
				elseif v266.kind == "Projectile" and (v266.t > -2.5 and not v267.pellets) then
					v235 = v267.key
					v236 = tostring(v235)
					v237 = v222[v236]
					v238 = v_u_22.Effects
					v239 = v267.shooter
					if type(v239) == "table" then
						v240 = v239.fighter
						if type(v240) == "number" then
							v241 = v239.fighter
						else
							v241 = nil
						end
					else
						v241 = nil
					end
					if v241 then
						v241 = p220.puppets[v241]
					end
					if (v237 == nil or v237 >= 0) and v238 then
						v242 = v267.origin
						if typeof(v242) == "Vector3" then
							v243 = v267.velocity
							if typeof(v243) == "Vector3" then
								v244 = v267.kind
								if type(v244) == "string" then
									v245 = v267.gravity
									v246 = tonumber(v245) or 0
									v247 = v_u_8.new(v267.origin, v267.velocity, v246, 0)
									v_u_8.Advance(v247, -v266.t)
									v248 = v238.Projectile
									v249 = "R|" .. v236
									v250 = v267.kind
									v251 = v247.pos
									v252 = v247.vel
									if v241 then
										v253 = v241.model
									else
										v253 = nil
									end
									pcall(v248, v249, v250, v251, v252, v246, v253)
								end
							end
						end
					end
				end
				goto l66
			end
			v254 = v267.attacker
			if type(v254) == "table" then
				v255 = v254.fighter
				if type(v255) == "number" then
					v256 = v254.fighter
				else
					v256 = nil
				end
			else
				v256 = nil
			end
			if v256 ~= p220.focus then
				if v266.kind == "Smoke" then
					v231 = v267.duration
					v232 = (tonumber(v231) or 7) + v266.t
					if v232 > 0.4 then
						v267.duration = v232
						v_u_219(p220, v266)
					end
				elseif v266.kind == "Status" and v267.status == "Burn" then
					v233 = v267.duration
					v234 = (tonumber(v233) or 1) + v266.t
					if v234 > 0.2 then
						v267.duration = v234
						v_u_219(p220, v266)
					end
				elseif v266.kind == "Projectile" and (v266.t > -2.5 and not v267.pellets) then
					v235 = v267.key
					v236 = tostring(v235)
					v237 = v222[v236]
					v238 = v_u_22.Effects
					v239 = v267.shooter
					if type(v239) == "table" then
						v240 = v239.fighter
						if type(v240) == "number" then
							v241 = v239.fighter
						else
							v241 = nil
						end
					else
						v241 = nil
					end
					if v241 then
						v241 = p220.puppets[v241]
					end
					if (v237 == nil or v237 >= 0) and v238 then
						v242 = v267.origin
						if typeof(v242) == "Vector3" then
							v243 = v267.velocity
							if typeof(v243) == "Vector3" then
								v244 = v267.kind
								if type(v244) == "string" then
									v245 = v267.gravity
									v246 = tonumber(v245) or 0
									v247 = v_u_8.new(v267.origin, v267.velocity, v246, 0)
									v_u_8.Advance(v247, -v266.t)
									v248 = v238.Projectile
									v249 = "R|" .. v236
									v250 = v267.kind
									v251 = v247.pos
									v252 = v247.vel
									if v241 then
										v253 = v241.model
									else
										v253 = nil
									end
									pcall(v248, v249, v250, v251, v252, v246, v253)
								end
							end
						end
					end
				end
				goto l66
			end
			v_u_16.OnFighterEvent("Charge", {
				["on"] = false
			}, v266.t)
			v226 = v226 + 1
		end
	end
end
local function v_u_308(p279, p280) -- name: aimSegments
	local v281 = {}
	local v282 = {}
	for _, v283 in p279.events do
		if v283.kind ~= "ProjectileHit" then
			continue
		end
		local v284 = v283.data.position
		if typeof(v284) ~= "Vector3" then
			continue
		end
		local v285 = v283.data.key
		local v286 = tostring(v285)
		if v281[v286] then
			continue
		end
		v281[v286] = v283.data.position
		local v287 = v283.data.character
		local v288
		if type(v287) == "table" then
			local v289 = v287.fighter
			if type(v289) == "number" then
				v288 = v287.fighter
			else
				v288 = nil
			end
		else
			v288 = nil
		end
		if not v288 then
			continue
		end
		v282[v286] = v288
	end
	local v290 = nil
	local v291 = {}
	for _, v292 in p279.events do
		local v293 = v292.data
		if v292.kind == "Charge" then
			local v294 = v293.attacker
			local v295
			if type(v294) == "table" then
				local v296 = v294.fighter
				if type(v296) == "number" then
					v295 = v294.fighter
				else
					v295 = nil
				end
			else
				v295 = nil
			end
			if v295 ~= p280 then
				goto l15
			end
			if v293.on == true then
				v290 = v292.t
			else
				v290 = nil
			end
		else
			::l15::
			if v292.kind ~= "Projectile" then
				continue
			end
			local v297 = v293.shooter
			local v298
			if type(v297) == "table" then
				local v299 = v297.fighter
				if type(v299) == "number" then
					v298 = v297.fighter
				else
					v298 = nil
				end
			else
				v298 = nil
			end
			if v298 ~= p280 then
				continue
			end
			local v300 = v293.origin
			if typeof(v300) ~= "Vector3" then
				continue
			end
			local v301 = v293.velocity
			if typeof(v301) ~= "Vector3" or v293.velocity.Magnitude <= 0.1 then
				continue
			end
			local v302 = v293.key
			local v303 = tostring(v302)
			local v304 = v281[v303] or v281[v303 .. "/1"]
			local v305
			if v304 then
				local v306 = (v304 - v293.origin).Magnitude
				v305 = math.clamp(v306, 8, 400)
			else
				v305 = 80
			end
			if not v290 or v292.t - v290 >= 2.5 then
				v290 = v292.t - 0.45
			end
			local v307 = {
				["t0"] = v290 - 0.05,
				["t1"] = v292.t + 0.4,
				["shot"] = v292.t,
				["point"] = v293.origin + v293.velocity.Unit * v305
			}
			table.insert(v291, v307)
			v290 = nil
		end
	end
	return v291, v281, v282
end
local function v_u_332(p309, p310, p311, p312) -- name: startFall
	-- upvalues: (copy) v_u_4
	local v313 = p311.cf
	local v314 = p311.vel.X
	local v315 = p311.vel.Z
	local v316 = Vector3.new(v314, 0, v315)
	local v317 = v313.LookVector.X
	local v318 = v313.LookVector.Z
	local v319 = Vector3.new(v317, 0, v318)
	local v320 = v319.Magnitude <= 0.05 and Vector3.new(0, 0, -1) or v319.Unit
	local v321
	if v316.Magnitude > 3 then
		v321 = v316.Unit
	else
		v321 = -v320
	end
	local v322 = p310.hum.HipHeight + p310.root.Size.Y / 2
	local v323 = v_u_4
	local v324 = v313.Position + Vector3.new(0, 1, 0)
	local v325 = -(v322 + 8)
	local v326 = v323:Raycast(v324, Vector3.new(0, v325, 0), p309.params)
	local v327
	if v326 then
		v327 = v326.Position.Y
	else
		v327 = v313.Position.Y - v322
	end
	local v328 = v313.Position.X
	local v329 = v313.Position.Z
	local v330 = Vector3.new(v328, v327, v329)
	local v331 = CFrame.lookAt(v330 + Vector3.new(0, v322, 0), v330 + Vector3.new(0, v322, 0) + v320)
	p310.fall = {
		["at"] = p312 <= 0.05 and -10 or p312,
		["stand"] = v331,
		["pivot"] = v330 + Vector3.new(0, 0.55, 0),
		["axis"] = (Vector3.new(0, 1, 0)):Cross(v321).Unit
	}
end
local function v_u_339(p333, p334) -- name: fallPose
	local v335 = p333.fall
	local v336 = (p334 - v335.at) / 0.45
	local v337 = math.clamp(v336, 0, 1)
	local v338 = v335.pivot
	return CFrame.new(v338) * CFrame.fromAxisAngle(v335.axis, v337 * v337 * 3.141592653589793 / 2) * CFrame.new(-v338) * v335.stand
end
local function v_u_361(p340, p341, p342, p343, p344) -- name: applyState
	-- upvalues: (copy) v_u_6, (copy) v_u_10, (copy) v_u_42, (copy) v_u_43, (copy) v_u_339, (copy) v_u_63, (copy) v_u_332, (copy) v_u_58, (copy) v_u_22
	local v345 = not p342.present
	if not v345 then
		local v346 = p342.flags
		local v347 = v_u_6.F_ALIVE
		v345 = not bit32.btest(v346, v347)
	end
	if p341.fall and v345 then
		v_u_10.SetVisible(p341, true)
		local v348 = p343 + 1
		v_u_42[v348] = p341.root
		v_u_43[v348] = v_u_339(p341, p344)
		return v348
	end
	if not p342.present then
		v_u_10.SetVisible(p341, false)
		return p343
	end
	v_u_10.SetVisible(p341, true)
	local v349 = p342.flags
	local v350 = v_u_6.F_ALIVE
	local v351 = bit32.btest(v349, v350)
	if v351 ~= p341.alive then
		p341.alive = v351
		if v351 then
			p341.fall = nil
		else
			v_u_63(p341)
			v_u_332(p340, p341, p342, p344)
		end
	end
	local v352 = p343 + 1
	v_u_42[v352] = p341.root
	local v353 = v_u_43
	local v354
	if p341.fall then
		v354 = v_u_339(p341, p344)
	else
		v354 = p342.cf
	end
	v353[v352] = v354
	if v351 then
		local v355
		if p342.item > 0 then
			v355 = p340.clip.items[p342.item]
		else
			v355 = nil
		end
		if v355 ~= p341.itemId then
			v_u_58(p341, v355)
		end
		local v356 = p342.flags
		local v357 = v_u_6.F_BLOCKING
		local v358 = bit32.btest(v356, v357)
		if v358 ~= p341.blocking then
			p341.blocking = v358
			if v_u_22.Guard then
				local v359 = v_u_22.Guard.Set
				local v360 = p341.model
				pcall(v359, v360, v358)
			end
		end
	end
	return v352
end
local v_u_362 = nil
local v_u_363 = false
local v_u_364 = 1
local function v_u_370(p365) -- name: clipTime
	-- upvalues: (ref) v_u_364, (ref) v_u_362, (ref) v_u_363
	if p365.phase ~= "play" then
		return p365.phase == "intro" and 0 or p365.lastT
	end
	local v366 = (os.clock() - p365.t0) * v_u_364
	local v367 = p365.payload.startTime
	if not v_u_362 or (type(v367) ~= "number" or v_u_362 - v367 > v366) then
		return v366
	end
	if not v_u_363 then
		v_u_363 = true
		for _, v368 in p365.puppets do
			for _, v369 in v368.animator:GetPlayingAnimationTracks() do
				v369:AdjustSpeed(0)
			end
		end
	end
	p365.t0 = os.clock() - (v_u_362 - v367) / v_u_364
	return v_u_362 - v367
end
local v_u_371 = nil
local function v_u_373(p372) -- name: diagInspect
	-- upvalues: (copy) v_u_10, (copy) v_u_18
	return v_u_10.Inspect(p372, v_u_18.FAR)
end
local function v_u_461(p374) -- name: step
	-- upvalues: (ref) v_u_40, (ref) v_u_364, (copy) v_u_370, (copy) v_u_219, (copy) v_u_9, (copy) v_u_361, (copy) v_u_42, (copy) v_u_43, (copy) v_u_16, (copy) v_u_4, (ref) v_u_363, (copy) v_u_11, (copy) v_u_6, (copy) v_u_22, (copy) v_u_14, (copy) v_u_15, (copy) v_u_12, (copy) v_u_17, (copy) v_u_18, (copy) v_u_373, (copy) v_u_3, (ref) v_u_93, (copy) v_u_157, (ref) v_u_371
	local v_u_375 = v_u_40
	if v_u_375 then
		local v376 = p374 * v_u_364
		local v377 = os.clock()
		local v_u_378 = v_u_375.clip
		local v_u_379 = v_u_370(v_u_375)
		if v_u_375.phase == "play" then
			local v380 = v_u_378.duration
			v_u_379 = math.min(v_u_379, v380)
			local v381 = v_u_378.events
			while v_u_375.nextEvent <= #v381 and v381[v_u_375.nextEvent].t <= v_u_379 do
				local v382 = v381[v_u_375.nextEvent]
				v_u_375.nextEvent = v_u_375.nextEvent + 1
				local v383 = v_u_219
				local v384, v385 = pcall(v383, v_u_375, v382)
				if v384 then
					continue
				end
				local v386 = v_u_375.stats
				v386.fxErrors = v386.fxErrors + 1
				if v_u_375.stats.fxErrors > 3 then
					continue
				end
				warn("[Replay] event error:", v382.kind, v385)
			end
		end
		local v387 = 0
		for v388, v389 in v_u_375.puppets do
			local v390 = v_u_375.states[v388]
			v_u_9.Sample(v_u_378, v_u_378.fighters[v388], v_u_379, v390)
			v387 = v_u_361(v_u_375, v389, v390, v387, v_u_379)
		end
		for v391 = v387 + 1, #v_u_42 do
			v_u_42[v391] = nil
			v_u_43[v391] = nil
		end
		if v_u_375.phase == "play" then
			local v392 = v_u_375.states[v_u_375.focus]
			if v392 and v392.present then
				local v393 = v_u_16.Update
				local v394
				if v392.item > 0 then
					v394 = v_u_378.items[v392.item]
				else
					v394 = nil
				end
				v393(v_u_379, v394, v392.hp, v392.armor, v392.flags)
			end
		end
		if v387 > 0 then
			v_u_4:BulkMoveTo(v_u_42, v_u_43, Enum.BulkMoveMode.FireCFrameChanged)
		end
		v_u_375.locoAcc = v_u_375.locoAcc + (v_u_363 and 0 or v376)
		if v_u_375.locoAcc >= 0.03333333333333333 then
			local v395 = v_u_375.locoAcc
			local v396 = math.min(v395, 0.1)
			v_u_375.locoAcc = 0
			local v397 = os.clock()
			for v398, v399 in v_u_375.puppets do
				local v400 = v_u_375.states[v398]
				if not (v399.loco and v399.visible) then
					continue
				end
				local v401 = v_u_11.Step
				local v402 = v399.loco
				local v403 = v400.vel
				local v404 = v400.flags
				local v405 = v_u_6.F_GROUNDED
				local v406 = bit32.btest(v404, v405)
				local v407 = v400.flags
				local v408 = v_u_6.F_SLIDING
				v401(v402, v396, v397, v403, v406, bit32.btest(v407, v408), v399.alive)
			end
		end
		v_u_375.holdAcc = v_u_375.holdAcc + (v_u_363 and 0 or v376)
		if v_u_375.holdAcc >= 0.5 then
			v_u_375.holdAcc = 0
			local v409 = v_u_22.Util
			for _, v410 in v_u_375.puppets do
				if not (v409 and (v410.hold and (v410.alive and v410.visible))) then
					continue
				end
				local v411 = v409.GetTrack(v410.animator, v410.hold)
				if not v411 or v411.IsPlaying then
					continue
				end
				v409.PlayAnim(v410.animator, v410.hold, 1, 0.2)
			end
		end
		v_u_14.Tick()
		local v412 = v_u_375.payload.startTime
		if v_u_375.phase == "play" and (type(v412) == "number" and v_u_15.Active()) then
			for _, v413 in v_u_375.puppets do
				if not (v413.visible and v413.alive) then
					continue
				end
				v_u_15.Compare(v413.id, v413.model, v412 + v_u_379)
			end
		end
		local v414 = v_u_375.puppets[v_u_375.focus]
		local v415 = v_u_375.states[v_u_375.focus]
		local v416 = v_u_4.CurrentCamera
		if v416.CameraType ~= Enum.CameraType.Scriptable then
			v416.CameraType = Enum.CameraType.Scriptable
		end
		if v415 and v415.present then
			local v417 = v415.cf.Position
			local v418 = v415.cf.LookVector
			local v419 = v418.X
			local v420 = v418.Z
			local v421 = Vector3.new(v419, 0, v420)
			local v422 = 0
			local v423 = v_u_375.clip.fighters[v_u_375.focus].team
			if v421.Magnitude > 0.1 then
				local v424 = v421.Unit
				for v425, v426 in v_u_375.puppets do
					local v427 = v_u_375.states[v425]
					if v426.team == v423 or not (v426.visible and (v426.alive and v427.present)) then
						continue
					end
					local v428 = v427.cf.Position - v417
					local v429 = v428.X
					local v430 = v428.Z
					local v431 = Vector3.new(v429, 0, v430)
					local v432 = v431.Magnitude
					if v432 <= 0.5 or (v432 >= 16 or v431.Unit:Dot(v424) <= 0.2) then
						continue
					end
					local v433 = 1 - (v432 - 5) / 11
					local v434 = math.clamp(v433, 0, 1)
					v422 = math.max(v422, v434)
				end
			end
			v_u_12.SetAction(v422)
			local v435 = v_u_12.SetAimed
			local v436 = v415.flags
			local v437 = v_u_6.F_AIMING
			v435((bit32.btest(v436, v437)))
			local v438
			if v414 then
				v438 = v414.alive
			else
				local v439 = v415.flags
				local v440 = v_u_6.F_ALIVE
				v438 = bit32.btest(v439, v440)
			end
			local v441
			if v414 then
				v441 = v414.model
			else
				v441 = nil
			end
			v_u_12.Update(v416, v376, v_u_379, v415.cf, v438, v_u_17.Frame(v376, v415, v441, v438))
			local v442 = v_u_17.AfterCamera
			local v443 = v_u_12.InFirstPerson()
			local v444
			if v415.item > 0 then
				v444 = v_u_378.items[v415.item]
			else
				v444 = nil
			end
			v442(v376, v415, v441, v438, v443, v444, v_u_16.HeldCharges())
		else
			v_u_12.Update(v416, v376, v_u_379, nil, false)
			if v415 then
				v_u_17.AfterCamera(v376, v415, nil, false, false, nil, nil)
			end
		end
		if v_u_375.phase == "play" then
			local v445 = v_u_375.diagShot
			if v445 then
				v_u_375.diagShot = nil
				local v446 = v_u_18.Shot
				pcall(v446, v416, v445)
			end
			v_u_375.diagAcc = v_u_375.diagAcc + v376
			if v_u_375.diagAcc >= 0.1 then
				v_u_375.diagAcc = 0
				local v447 = v_u_18.Frame
				pcall(v447, v_u_375, v416)
			end
		end
		if v_u_375.phase == "play" and v_u_375.diagStage < 2 and (v_u_375.diagStage == 0 and 1.5 or v_u_378.duration * 0.5) <= v_u_379 then
			v_u_375.diagStage = v_u_375.diagStage + 1
			local v448 = v_u_18.Check
			local v449 = v_u_375.diagStage == 1 and "early" or "mid"
			local v450 = v_u_12.InFirstPerson()
			local v451 = v_u_373
			local function v453(p452)
				-- upvalues: (ref) v_u_9, (copy) v_u_378, (ref) v_u_379, (copy) v_u_375
				v_u_9.Sample(v_u_378, v_u_378.fighters[p452], v_u_379, v_u_375.states[p452])
			end
			local v454, v455 = pcall(v448, v449, v_u_375, v450, v451, v453)
			if not v454 and v_u_3:IsStudio() then
				warn("[Replay] diag failed:", v455)
			end
		end
		if v_u_93 then
			v_u_157(v_u_375, v_u_379, v416)
		end
		local v456 = os.clock() - v377
		local v457 = v_u_375.stats
		v457.frames = v457.frames + 1
		local v458 = v_u_375.stats
		v458.stepTime = v458.stepTime + v456
		local v459 = v_u_375.stats
		local v460 = v_u_375.stats.maxStep
		v459.maxStep = math.max(v460, v456)
		if v_u_375.phase == "play" and (v_u_378.duration <= v_u_379 and not v_u_363) then
			v_u_371(v_u_375)
		end
	end
end
local function v_u_479(p462) -- name: cleanup
	-- upvalues: (ref) v_u_40, (ref) v_u_363, (copy) v_u_3, (copy) v_u_13, (copy) v_u_22, (copy) v_u_4, (copy) v_u_30, (copy) v_u_10, (copy) v_u_17, (copy) v_u_18, (copy) v_u_16, (copy) v_u_14
	if v_u_40 == p462 then
		v_u_40 = nil
		v_u_363 = false
		local function v463()
			-- upvalues: (ref) v_u_3
			v_u_3:UnbindFromRenderStep("TribesReplay")
		end
		pcall(v463)
		v_u_13.UnbindSkip()
		local v464 = v_u_22.Effects
		if v464 then
			v464.ParamsOverride = nil
		end
		local v465 = v_u_4:FindFirstChild("FX")
		if v465 then
			for _, v466 in v465:GetDescendants() do
				if not v466:IsA("WeldConstraint") or (v466.Name ~= "StickWeld" or not (v466.Part0 and v466.Part0:IsDescendantOf(p462.folder))) then
					continue
				end
				local v467 = v466.Parent
				if v467 then
					v467 = v466.Parent.Parent
				end
				if not (v467 and v467:IsA("Model")) then
					v467 = v466.Parent
				end
				if v467 then
					for _, v468 in v467:GetDescendants() do
						if not v468:IsA("BasePart") then
							continue
						end
						v468.Anchored = true
						v468.Transparency = 1
					end
					if v467:IsA("BasePart") then
						v467.Anchored = true
						v467.Transparency = 1
					end
				end
				v466:Destroy()
			end
		end
		for _, v469 in p462.puppets do
			if v_u_22.Guard and v469.blocking then
				local v470 = v_u_22.Guard.Set
				local v471 = v469.model
				pcall(v470, v471, false)
			end
			local v472 = v_u_30.Procedural
			if v472 then
				local v473 = v472.Untrack
				if type(v473) == "function" then
					local v474 = v472.Untrack
					local v475 = v469.model
					pcall(v474, v475)
				end
			end
			v_u_10.Destroy(v469)
		end
		local v476 = v_u_17.End
		pcall(v476)
		local v477 = v_u_18.End
		pcall(v477)
		p462.folder:Destroy()
		local v478 = v_u_16.End
		pcall(v478)
		v_u_14.Leave()
	end
end
v_u_371 = function(p_u_480)
	-- upvalues: (ref) v_u_40, (copy) v_u_370, (copy) v_u_18, (copy) v_u_13, (copy) v_u_479, (copy) v_u_6
	if v_u_40 == p_u_480 and p_u_480.phase ~= "outro" then
		p_u_480.lastT = v_u_370(p_u_480)
		p_u_480.phase = "outro"
		local v481 = v_u_18.Flush
		pcall(v481)
		v_u_13.UnbindSkip()
		v_u_13.Outro(function()
			-- upvalues: (ref) v_u_479, (copy) p_u_480
			v_u_479(p_u_480)
		end, v_u_6.OUTRO_TIME)
	end
end
function v_u_19.Skip() -- name: Skip
	-- upvalues: (ref) v_u_40, (ref) v_u_371
	local v482 = v_u_40
	if v482 then
		v_u_371(v482)
	end
end
function v_u_19.Stop(_) -- name: Stop
	-- upvalues: (ref) v_u_40, (copy) v_u_13, (copy) v_u_479
	local v483 = v_u_40
	if v483 then
		v_u_13.Hide()
		v_u_479(v483)
	end
end
function v_u_19.IsPlaying() -- name: IsPlaying
	-- upvalues: (ref) v_u_40
	return v_u_40 ~= nil
end
local function v_u_494(p484) -- name: findMap
	-- upvalues: (copy) v_u_4, (copy) v_u_20
	local v485 = v_u_4:FindFirstChild("Arenas")
	if not v485 then
		return nil
	end
	local v486 = v_u_20:GetAttribute("MatchId")
	local v487
	if type(v486) == "string" then
		v487 = v485:FindFirstChild(v486)
	else
		v487 = false
	end
	if v487 then
		v487 = v487:FindFirstChild("Map")
	end
	if v487 then
		return v487
	end
	for _, v488 in v485:GetChildren() do
		local v489 = v488:FindFirstChild("Map")
		local v490 = v488:GetAttribute("RingCenterX")
		local v491 = v488:GetAttribute("RingCenterZ")
		if not v489 or (type(v490) ~= "number" or type(v491) ~= "number") then
			continue
		end
		local v492 = v490 - p484.X
		if math.abs(v492) >= 5 then
			continue
		end
		local v493 = v491 - p484.Z
		if math.abs(v493) >= 5 then
			continue
		end
		return v489
	end
	return nil
end
function v_u_19.Play(p495) -- name: Play
	-- upvalues: (ref) v_u_40, (copy) v_u_19, (copy) v_u_9, (copy) v_u_29, (copy) v_u_308, (copy) v_u_12, (copy) v_u_3, (copy) v_u_4, (ref) v_u_41, (copy) v_u_494, (copy) v_u_11, (copy) v_u_18, (copy) v_u_6, (copy) v_u_15, (copy) v_u_14, (copy) v_u_17, (copy) v_u_22, (copy) v_u_20, (copy) v_u_10, (copy) v_u_30, (copy) v_u_13, (copy) v_u_461, (copy) v_u_16, (copy) v_u_278
	if type(p495) == "table" then
		local v496 = p495.clip
		if typeof(v496) == "buffer" then
			if v_u_40 then
				v_u_19.Stop("replaced")
			end
			local v497 = v_u_9.Decode
			local v498 = p495.clip
			local v499, v_u_501, v_u_501 = pcall(v497, v498)
			if v499 and v_u_501 then
				local v502 = v_u_501.fighters[v_u_501.focus]
				if v502 and v502.n ~= 0 then
					v_u_29()
					local v503, v504, v505 = v_u_308(v_u_501, v_u_501.focus)
					v_u_12.SetSegments(v503)
					local v506 = v_u_9
					local v507 = v_u_3:IsStudio()
					if v507 then
						v507 = v_u_4:GetAttribute("ReplayViewLinear") == true
					end
					v506.LinearView = v507
					v_u_41 = v_u_41 + 1
					local v_u_508 = Instance.new("Folder")
					v_u_508.Name = "Replay"
					local v509 = v_u_494(v_u_501.origin)
					local v510 = RaycastParams.new()
					v510.FilterType = Enum.RaycastFilterType.Include
					v510.IgnoreWater = true
					v510.FilterDescendantsInstances = v509 and { v509 } or {}
					v_u_12.SetWorld(v509 and { v509 } or {})
					v_u_11.SetGround(v509 and { v509 } or {})
					local v_u_511 = {
						["token"] = nil,
						["clip"] = nil,
						["payload"] = nil,
						["puppets"] = nil,
						["states"] = nil,
						["folder"] = nil,
						["phase"] = "intro",
						["t0"] = 0,
						["lastT"] = 0,
						["nextEvent"] = 1,
						["locoAcc"] = 0,
						["holdAcc"] = 0,
						["focus"] = nil,
						["chain"] = 0,
						["lastKillT"] = (-1 / 0),
						["params"] = nil,
						["built"] = false,
						["diagStage"] = 0,
						["diagAcc"] = 0,
						["diagShot"] = nil,
						["landed"] = nil,
						["landedOn"] = nil,
						["healthy"] = nil,
						["stats"] = nil,
						["token"] = v_u_41,
						["clip"] = v_u_501,
						["payload"] = p495,
						["puppets"] = {},
						["states"] = {},
						["folder"] = v_u_508,
						["focus"] = v_u_501.focus,
						["params"] = v510,
						["landed"] = v504,
						["landedOn"] = v505,
						["healthy"] = {},
						["stats"] = {
							["events"] = 0,
							["fxErrors"] = 0,
							["frames"] = 0,
							["stepTime"] = 0,
							["maxStep"] = 0,
							["missing"] = 0,
							["standIns"] = 0,
							["hits"] = 0,
							["hitErrSum"] = 0,
							["hitErrMax"] = 0,
							["kinds"] = nil,
							["kinds"] = {}
						}
					}
					v_u_40 = v_u_511
					for v512 in v_u_501.fighters do
						v_u_511.states[v512] = v_u_9.NewState()
					end
					local v513 = v_u_18.Begin
					pcall(v513, v_u_501)
					local v514 = v_u_6.INTRO_TIME + v_u_501.duration + v_u_6.OUTRO_TIME
					v_u_15.Reset()
					v_u_14.Enter(v514)
					local v515 = v_u_17.Begin
					pcall(v515, v510)
					v_u_508.Parent = v_u_4
					local v516 = v_u_22.Effects
					if v516 then
						function v516.ParamsOverride(p517)
							-- upvalues: (ref) v_u_40, (copy) v_u_511
							if p517 and (p517:GetAttribute("ReplayPuppet") ~= nil and v_u_40 == v_u_511) then
								return v_u_511.params
							else
								return nil
							end
						end
					end
					local v518 = v_u_20:GetAttribute("Team")
					local v_u_519 = v502.team
					local function v_u_566(p_u_520, p521) -- name: makePuppet
						-- upvalues: (copy) v_u_501, (copy) v_u_511, (ref) v_u_9, (ref) v_u_10, (copy) v_u_508, (ref) v_u_18, (ref) v_u_11, (ref) v_u_30, (ref) v_u_6, (ref) v_u_22, (copy) v_u_519, (ref) v_u_13
						local v522 = v_u_501.fighters[p_u_520]
						if v522.n == 0 or v_u_511.puppets[p_u_520] then
							return
						end
						local v523 = v_u_511.states[p_u_520]
						v_u_9.Sample(v_u_501, v522, 0, v523)
						local v524 = nil
						local v525 = nil
						local v526 = nil
						local v527 = nil
						local v528 = nil
						local v529 = -1
						local v530 = false
						local v531 = nil
						for _ = 1, 4 do
							local v532 = nil
							for v533, v534 in v_u_511.puppets do
								if not v_u_511.healthy[v533] then
									continue
								end
								v532 = v534.model
							end
							local v535, v536
							v535, v536, v529 = v_u_10.Build(p_u_520, v522.id, v522.name, v522.team, v_u_508, v531, v532)
							v525 = v525 or v536
							if not v535 then
								break
							end
							v535.root.CFrame = v523.cf
							v_u_10.SetVisible(v535, true)
							v535.root.CFrame = v523.cf
							local v537 = v_u_10.Inspect
							local v538 = v_u_18.FAR
							local v539, v540 = pcall(v537, v535, v538)
							local v541
							if v539 then
								v541 = v_u_18.Evaluate(v540)
							else
								v541 = nil
							end
							if v541 == nil then
								if v526 then
									v_u_10.Destroy(v526)
									v526 = v535
									v530 = true
								else
									v526 = v535
									v530 = true
								end
								break
							end
							if v524 == nil then
								v527 = v535.src
								if v539 then
									v528 = v540
								else
									v528 = nil
								end
							else
								v541 = v524
							end
							if v526 then
								v_u_10.Destroy(v526)
							end
							v531 = v535.src
							v526 = v535
							v524 = v541
						end
						if v524 == nil and v525 then
							v524, v527 = string.match(v525, "^(%w+):(%w+)$")
						end
						local v542 = v_u_18.Built
						local v543 = p521 == true
						pcall(v542, p_u_520, v526, v524, v527, v528, v529, v530, v543)
						if v526 then
							if p521 then
								local v544 = v_u_511.stats
								v544.missing = v544.missing - 1
							end
							v_u_511.healthy[p_u_520] = v530
							if v526.standIn then
								local v545 = v_u_511.stats
								v545.standIns = v545.standIns + 1
							end
							if v526.debugUnparent then
								v526.model.Parent = nil
							end
							v526.loco = v_u_11.new(v526.hum, v526.root, v526.animator)
							local v546 = v_u_30.Procedural
							if v546 then
								local v547 = v546.Track
								if type(v547) == "function" then
									local v548 = v546.Track
									local v549 = v526.model
									local function v557()
										-- upvalues: (ref) v_u_511, (copy) p_u_520, (ref) v_u_6
										local v550 = v_u_511.states[p_u_520]
										local v551 = v550.vel
										local v552 = v550.flags
										local v553 = v_u_6.F_GROUNDED
										local v554 = bit32.btest(v552, v553)
										local v555 = v550.flags
										local v556 = v_u_6.F_SLIDING
										return v551, v554, bit32.btest(v555, v556)
									end
									pcall(v548, v549, v557)
								end
							end
							local v558 = v_u_22.Poses
							if v558 then
								local v559 = v558.Watch
								if type(v559) == "function" then
									local v560 = v558.Watch
									local v561 = v526.model
									pcall(v560, v561)
								end
							end
							if v522.team ~= v_u_519 then
								local v562 = v526.model
								local v563 = v_u_13.Colors.Enemy
								local v564 = Instance.new("Highlight")
								v564.Name = "ReplayOutline"
								v564.DepthMode = Enum.HighlightDepthMode.Occluded
								v564.FillTransparency = 1
								v564.OutlineTransparency = 0.35
								v564.OutlineColor = v563
								v564.Adornee = v562
								v564.Parent = v562
							end
							v_u_511.puppets[p_u_520] = v526
						elseif not p521 then
							local v565 = v_u_511.stats
							v565.missing = v565.missing + 1
						end
					end
					v_u_566(v_u_501.focus)
					local v567 = v_u_511.puppets[v_u_501.focus]
					local v568 = v_u_13.ShowIntro
					local v569 = {}
					local v570 = p495.name or v502.name
					v569.name = tostring(v570)
					local v571 = p495.title or v_u_501.title
					v569.title = tostring(v571)
					local v572
					if v567 then
						v572 = v567.model
					else
						v572 = nil
					end
					v569.portrait = v572
					v569.ally = v518 == v_u_519
					v568(v569)
					v_u_13.BindSkip(v_u_19.Skip)
					v_u_9.Sample(v_u_501, v502, 0, v_u_511.states[v_u_501.focus])
					v_u_12.SetShoulderSide(v502.left and -1 or 1)
					v_u_12.Begin(v_u_511.states[v_u_501.focus].cf, v_u_501.duration)
					v_u_3:BindToRenderStep("TribesReplay", Enum.RenderPriority.Camera.Value + 5, v_u_461)
					task.spawn(function()
						-- upvalues: (copy) v_u_501, (ref) v_u_40, (copy) v_u_511, (copy) v_u_566
						for v573 in v_u_501.fighters do
							if v_u_40 ~= v_u_511 then
								return
							end
							if v573 == v_u_501.focus then
								continue
							end
							local v574 = v_u_566
							local v575, v576 = pcall(v574, v573)
							if not v575 then
								warn("[Replay] puppet failed:", v576)
							end
							task.wait()
						end
						for v577, v578 in v_u_501.fighters do
							if v_u_40 ~= v_u_511 then
								return
							end
							if v578.n <= 0 or v_u_511.puppets[v577] then
								continue
							end
							local v579 = v_u_566
							pcall(v579, v577, true)
						end
						v_u_511.built = true
					end)
					task.delay(v_u_6.INTRO_TIME, function()
						-- upvalues: (ref) v_u_40, (copy) v_u_511, (ref) v_u_16, (copy) v_u_501, (ref) v_u_278, (ref) v_u_13
						if v_u_40 == v_u_511 and v_u_511.phase == "intro" then
							v_u_511.phase = "play"
							v_u_511.t0 = os.clock()
							local v580 = v_u_16.Begin
							local v581 = v_u_501.items
							pcall(v580, v581)
							local v582 = v_u_278
							local v583 = v_u_511
							local v584, v585 = pcall(v582, v583)
							if not v584 then
								warn("[Replay] preroll failed:", v585)
							end
							v_u_13.Reveal()
						end
					end)
				else
					warn("[Replay] clip has no samples for its fighter")
				end
			else
				local v586 = warn
				local v587 = "[Replay] bad clip:"
				v586(v587, v_u_501)
				return
			end
		end
	end
end
function v_u_19.DebugFreeze(p588) -- name: DebugFreeze
	-- upvalues: (ref) v_u_362, (ref) v_u_363
	v_u_362 = p588
	v_u_363 = false
end
function v_u_19.DebugRate(p589) -- name: DebugRate
	-- upvalues: (ref) v_u_364
	v_u_364 = (type(p589) ~= "number" or p589 <= 0) and 1 or math.clamp(p589, 0.05, 4)
end
function v_u_19.DebugCamLog(p590) -- name: DebugCamLog
	-- upvalues: (ref) v_u_93, (copy) v_u_9
	local v591 = v_u_93
	if p590 == true then
		v_u_93 = {
			["t"] = {},
			["yaw"] = {},
			["pitch"] = {},
			["x"] = {},
			["y"] = {},
			["z"] = {},
			["fov"] = {},
			["shots"] = {},
			["pending"] = {}
		}
		return true
	else
		if p590 == false then
			v_u_93 = nil
		end
		return v591 and {
			["t"] = v591.t,
			["yaw"] = v591.yaw,
			["pitch"] = v591.pitch,
			["x"] = v591.x,
			["y"] = v591.y,
			["z"] = v591.z,
			["fov"] = v591.fov,
			["shots"] = v591.shots,
			["startTime"] = v591.startTime,
			["focus"] = v591.focus,
			["duration"] = v591.duration,
			["linear"] = v_u_9.LinearView
		} or false
	end
end
function v_u_19.DebugPuppet(p592) -- name: DebugPuppet
	-- upvalues: (ref) v_u_40
	local v593 = v_u_40
	if not v593 then
		return nil
	end
	for _, v594 in v593.puppets do
		if v594.id ~= p592 then
			continue
		end
		return v594.model
	end
	return nil
end
function v_u_19.DebugAnim() -- name: DebugAnim
	-- upvalues: (ref) v_u_40
	local v595 = v_u_40
	if not v595 then
		return {
			["playing"] = false
		}
	end
	local v596 = {}
	for _, v597 in v595.puppets do
		local v598 = {}
		for _, v599 in v597.animator:GetPlayingAnimationTracks() do
			local v600 = v599.Animation
			local v601 = string.format
			local v602 = v600 and v600.Name or "?"
			local v603 = v599.WeightCurrent
			local v604 = v599.Speed
			local v605 = v599.TimePosition
			local v606 = v599.Length
			local v607 = v599.Priority.Name
			table.insert(v598, v601("%s w%.2f s%.2f t%.2f/%.2f %s", v602, v603, v604, v605, v606, v607))
		end
		local v608 = {}
		for _, v609 in {
			"Root",
			"Waist",
			"RightShoulder",
			"LeftHip"
		} do
			local v610 = v597.model:FindFirstChild(v609, true)
			if v610 and v610:IsA("Motor6D") then
				local _, v611 = v610.Transform:ToAxisAngle()
				local v612 = string.format
				local v613 = v610.Part0 and (v610.Part0.Name or "nil") or "nil"
				local v614 = v610.Part1 and v610.Part1.Name or "nil"
				local v615 = math.deg(v611)
				table.insert(v608, v612("%s %s->%s %.1fdeg", v609, v613, v614, v615))
			else
				local v616 = v609 .. " " .. (not v610 and "missing" or v610.ClassName)
				table.insert(v608, v616)
			end
		end
		v596[v597.id] = {
			["visible"] = v597.visible,
			["alive"] = v597.alive,
			["item"] = v597.itemId,
			["hold"] = v597.hold,
			["tracks"] = v598,
			["joints"] = v608
		}
	end
	return v596
end
function v_u_19.DebugState() -- name: DebugState
	-- upvalues: (ref) v_u_40, (copy) v_u_370, (copy) v_u_12
	local v617 = v_u_40
	if not v617 then
		return {
			["playing"] = false
		}
	end
	local v618 = {}
	for v619, v620 in v617.puppets do
		local v621 = v617.states[v619]
		local v622 = {
			["index"] = v619,
			["id"] = v620.id,
			["visible"] = v620.visible,
			["alive"] = v620.alive,
			["item"] = v620.itemId,
			["hold"] = v620.hold,
			["standIn"] = v620.standIn,
			["src"] = v620.src,
			["liveParts"] = v620.liveParts
		}
		local v623
		if v621.present then
			v623 = v621.cf.Position
		else
			v623 = nil
		end
		v622.pos = v623
		v622.playing = #v620.animator:GetPlayingAnimationTracks()
		table.insert(v618, v622)
	end
	return {
		["playing"] = true,
		["phase"] = nil,
		["t"] = nil,
		["duration"] = nil,
		["focus"] = nil,
		["focusName"] = nil,
		["startTime"] = nil,
		["firstPerson"] = nil,
		["title"] = nil,
		["events"] = nil,
		["dispatched"] = nil,
		["bytes"] = nil,
		["puppets"] = nil,
		["stats"] = nil,
		["stepMsAvg"] = nil,
		["stepMsMax"] = nil,
		["phase"] = v617.phase,
		["t"] = v_u_370(v617),
		["duration"] = v617.clip.duration,
		["focus"] = v617.clip.fighters[v617.focus].id,
		["focusName"] = v617.clip.fighters[v617.focus].name,
		["startTime"] = v617.payload.startTime,
		["firstPerson"] = v_u_12.InFirstPerson(),
		["title"] = v617.clip.title,
		["events"] = #v617.clip.events,
		["dispatched"] = v617.nextEvent - 1,
		["bytes"] = v617.clip.bytes,
		["puppets"] = v618,
		["stats"] = v617.stats,
		["stepMsAvg"] = v617.stats.frames <= 0 and 0 or v617.stats.stepTime * 1000 / v617.stats.frames,
		["stepMsMax"] = v617.stats.maxStep * 1000
	}
end
return v_u_19