local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
return {
	["Init"] = function(p_u_4) -- name: Init
		-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_3
		local v_u_5 = p_u_4.UI
		local v_u_6 = p_u_4.Theme.Colors
		local v_u_7 = v_u_1.LocalPlayer
		local function v8()
			-- upvalues: (ref) v_u_2
			return require(v_u_2:WaitForChild("Shared"):WaitForChild("Config"))
		end
		local v9, v10 = pcall(v8)
		local v11
		if v9 and type(v10) == "table" then
			v11 = v10.STAGING_PLACE_ID
		else
			v11 = nil
		end
		if v_u_3:IsStudio() or v11 and game.PlaceId == v11 then
			local function v12()
				-- upvalues: (ref) v_u_2
				return require(v_u_2.Shared:WaitForChild("Camera"):WaitForChild("Smoothing"))
			end
			local v13, v_u_14 = pcall(v12)
			if not v13 then
				v_u_14 = nil
			end
			local function v15()
				-- upvalues: (ref) v_u_2
				return require(v_u_2.Shared:WaitForChild("Simulation"))
			end
			local v16, v_u_17 = pcall(v15)
			if not v16 then
				v_u_17 = nil
			end
			local v_u_18 = nil
			local v_u_19 = nil
			local v_u_20 = nil
			local v_u_21 = false
			local v_u_22 = {}
			local v_u_23 = {}
			local function v26()
				-- upvalues: (ref) v_u_3, (ref) v_u_21, (copy) v_u_22
				v_u_3.Rollback:Connect(function()
					-- upvalues: (ref) v_u_21, (ref) v_u_22
					if v_u_21 then
						local v24 = v_u_22
						local v25 = os.clock
						table.insert(v24, v25())
					end
				end)
			end
			pcall(v26)
			local function v29()
				-- upvalues: (ref) v_u_3, (ref) v_u_21, (copy) v_u_23
				v_u_3.Misprediction:Connect(function()
					-- upvalues: (ref) v_u_21, (ref) v_u_23
					if v_u_21 then
						local v27 = v_u_23
						local v28 = os.clock
						table.insert(v27, v28())
					end
				end)
			end
			pcall(v29)
			local function v_u_32(p30, p31) -- name: perSecond
				while p30[1] and p31 - p30[1] > 1 do
					table.remove(p30, 1)
				end
				return #p30
			end
			local v_u_33 = {}
			local v_u_34 = nil
			local v_u_35 = -1000000000
			local v_u_36 = nil
			local v_u_37 = nil
			local v_u_38 = 0
			local v_u_39 = {}
			local v_u_40 = 0
			local function v_u_53(_) -- name: judge
				-- upvalues: (ref) v_u_37, (ref) v_u_14, (ref) v_u_36, (ref) v_u_38, (ref) v_u_40, (copy) v_u_39
				local v41 = v_u_37
				local v42 = 0
				local v43 = 0
				local v44 = 0
				if v_u_14 then
					for _, v45 in v_u_14.CorrectionsSince(v_u_36 - 0.1) do
						if v45[1] > v_u_36 + 0.7 then
							continue
						end
						local v46 = v45[2]
						local v47 = v45[4]
						local v48 = Vector3.new(v46, 0, v47)
						v42 = v42 + v48:Dot(v41)
						v43 = v43 + (v48 - v41 * v48:Dot(v41)).Magnitude
						v44 = v44 + 1
					end
				end
				v_u_38 = v_u_38 + 1
				local v49
				if v44 == 0 then
					v49 = string.format("STOP %d: clean (no correction)", v_u_38)
				else
					v49 = string.format("STOP %d: %s %.2f  side %.2f  (%d corr)", v_u_38, v42 < 0 and "BACK" or "fwd", math.abs(v42), v43, v44)
					if v42 < 0 then
						local v50 = v_u_40
						local v51 = -v42
						v_u_40 = math.max(v50, v51)
					end
				end
				local v52 = v_u_39
				table.insert(v52, 1, v49)
				if #v_u_39 > 6 then
					table.remove(v_u_39)
				end
				v_u_36 = nil
				v_u_37 = nil
			end
			local function v_u_75(_) -- name: frame
				-- upvalues: (copy) v_u_33, (copy) v_u_7, (ref) v_u_34, (ref) v_u_35, (ref) v_u_36, (ref) v_u_37, (copy) v_u_53, (ref) v_u_14, (ref) v_u_17, (copy) v_u_32, (copy) v_u_22, (copy) v_u_23, (ref) v_u_40, (ref) v_u_3, (copy) v_u_39, (ref) v_u_19
				local v54 = os.clock()
				local v55 = v_u_33
				table.insert(v55, v54)
				while v_u_33[1] and v54 - v_u_33[1] > 0.5 do
					table.remove(v_u_33, 1)
				end
				local v56 = #v_u_33 / 0.5
				local v57 = v_u_7.Character
				if v57 then
					v57 = v57:FindFirstChild("HumanoidRootPart")
				end
				local v58
				if v57 and v57:IsA("BasePart") then
					local v59 = v57.AssemblyLinearVelocity * Vector3.new(1, 0, 1)
					v58 = v59.Magnitude
					if v58 > 12 then
						v_u_34 = v59.Unit
						v_u_35 = v54
					elseif v58 < 1 and (v_u_36 == nil and (v_u_34 and v54 - v_u_35 < 0.35)) then
						local v60 = v_u_34
						v_u_36 = v54
						v_u_37 = v60
						v_u_34 = nil
					end
				else
					v58 = 0
				end
				if v_u_36 and v54 - v_u_36 > 0.7 then
					v_u_53(v54)
				end
				local v61, v62
				if v_u_14 then
					local v63 = v_u_14.Stats()
					v61 = v_u_14.BodyOn() and v63.proxyShown and "PROXY" or (v_u_14.BodyOn() and "PROXY (waiting)" or "REAL (60 Hz steps)")
					v62 = v_u_14.CameraOffset().Magnitude
				else
					v62 = 0
					v61 = "?"
				end
				local v64 = v_u_17 and v_u_17.ClientAuthority and "CLIENT (no prediction, no rollbacks)" or "SERVER (client predicts)"
				local v65 = {}
				local v66 = string.format
				local v67 = v56 + 0.5
				__set_list(v65, 1, {v66("MOVEMENT DEBUG   fps %d", (math.floor(v67))), string.format("authority %s   steps %s", v64, not (v_u_17 and v_u_17.StepSource) and "?" or v_u_17.StepSource()), string.format("rollbacks/s %d   mispredictions/s %d", v_u_32(v_u_22, v54), (v_u_32(v_u_23, v54))), string.format("speed %.1f   body %s   drawn-sim %.2f", v58, v61, v62), string.format("worst pull-back %.2f studs", v_u_40)})
				if v_u_17 and v_u_17.ArrivalHolds then
					local v68, v69 = v_u_17.ArrivalHolds()
					local v70 = string.format
					table.insert(v65, v70("held for missing ground: %d times, %.1f s", v68, v69))
				end
				if v_u_3:IsStudio() and (v_u_17 and v_u_17.WriteGuardStats) then
					local v71 = v_u_17.WriteGuardStats()
					local v72 = string.format
					local v73 = v71.violations or 0
					table.insert(v65, v72("root writes outside the simulation: %d", v73))
				end
				for _, v74 in v_u_39 do
					table.insert(v65, v74)
				end
				if v_u_19 then
					v_u_19.Text = table.concat(v65, "\n")
				end
			end
			local function v_u_77() -- name: build
				-- upvalues: (ref) v_u_18, (copy) v_u_5, (copy) v_u_6, (copy) p_u_4, (ref) v_u_19
				if not v_u_18 then
					local v76 = v_u_5.new("Frame", {
						["Name"] = "MoveDebug",
						["Position"] = UDim2.new(0, 12, 0.3, 0),
						["Size"] = UDim2.fromOffset(360, 190),
						["BackgroundColor3"] = v_u_6.Void,
						["BackgroundTransparency"] = 0.35,
						["Active"] = false,
						["ZIndex"] = 50,
						v_u_5.Corner(8),
						v_u_5.Padding(8, 10, 8, 10),
						["Parent"] = p_u_4.Canvas.Top
					})
					v_u_19 = v_u_5.new("TextLabel", {
						["Name"] = "Text",
						["Size"] = nil,
						["Text"] = "",
						["FontFace"] = nil,
						["TextSize"] = 14,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["TextYAlignment"] = nil,
						["ZIndex"] = 51,
						["Parent"] = nil,
						["Size"] = UDim2.fromScale(1, 1),
						["FontFace"] = Font.fromEnum(Enum.Font.RobotoMono),
						["TextColor3"] = v_u_6.Text,
						["TextXAlignment"] = Enum.TextXAlignment.Left,
						["TextYAlignment"] = Enum.TextYAlignment.Top,
						["Parent"] = v76
					})
					v_u_18 = v76
				end
			end
			local function v_u_79(p78) -- name: setShown
				-- upvalues: (ref) v_u_21, (copy) v_u_77, (ref) v_u_40, (ref) v_u_38, (copy) v_u_39, (copy) v_u_22, (copy) v_u_23, (ref) v_u_20, (ref) v_u_3, (copy) v_u_75, (ref) v_u_18
				v_u_21 = p78
				if p78 then
					v_u_77()
					v_u_40 = 0
					v_u_38 = 0
					table.clear(v_u_39)
					table.clear(v_u_22)
					table.clear(v_u_23)
					if not v_u_20 then
						v_u_20 = v_u_3.RenderStepped:Connect(v_u_75)
					end
				elseif v_u_20 then
					v_u_20:Disconnect()
					v_u_20 = nil
				end
				if v_u_18 then
					v_u_18.Visible = p78
				end
			end
			function p_u_4.MoveDebugToggle()
				-- upvalues: (copy) v_u_79, (ref) v_u_21, (copy) p_u_4
				v_u_79(not v_u_21)
				p_u_4.Toast(v_u_21 and "Movement debug on" or "Movement debug off", "info")
			end
			function p_u_4.BodySmoothingToggle()
				-- upvalues: (ref) v_u_14, (copy) p_u_4
				if v_u_14 then
					local v80 = not v_u_14.BodyOn()
					v_u_14.SetBody(v80)
					p_u_4.Toast(v80 and "Body smoothing ON: a visual copy is drawn smoothly" or "Body smoothing OFF: your character at 60 Hz steps", "info")
				end
			end
			function p_u_4.MoveDebugShown()
				-- upvalues: (ref) v_u_21
				return v_u_21
			end
			function p_u_4.BodySmoothingOn()
				-- upvalues: (ref) v_u_14
				local v81
				if v_u_14 == nil then
					v81 = false
				else
					v81 = v_u_14.BodyOn() == true
				end
				return v81
			end
			function p_u_4.Debug.moveDebug(p82)
				-- upvalues: (copy) p_u_4, (ref) v_u_21, (ref) v_u_14, (copy) v_u_39, (ref) v_u_19
				if p82 == "toggle" then
					p_u_4.MoveDebugToggle()
				elseif p82 == "body" then
					p_u_4.BodySmoothingToggle()
				end
				local v83 = {
					["shown"] = v_u_21
				}
				local v84 = v_u_14
				if v84 then
					v84 = v_u_14.BodyOn()
				end
				v83.body = v84
				v83.stops = v_u_39
				v83.text = v_u_19 and v_u_19.Text or ""
				return v83
			end
		end
	end
}