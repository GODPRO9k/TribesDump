local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = game:GetService("TweenService")
local v5 = game:GetService("RunService")
local v_u_6 = game:GetService("GuiService")
local v_u_7 = game:GetService("Players")
local v8 = require(v_u_1:WaitForChild("Shared"):WaitForChild("Signal"))
local v_u_9 = require(v_u_1.Shared:WaitForChild("Keybinds"))
local v_u_10 = require(script.Parent:WaitForChild("UI"))
local v_u_11 = {}
local v_u_12 = {}
local v_u_13 = nil
local v_u_14 = {}
local v_u_15 = false
local v_u_16 = nil
local v_u_17 = 0
v_u_11.Changed = v8.new()
function v_u_11.Camera() -- name: Camera
	-- upvalues: (ref) v_u_16, (ref) v_u_17, (copy) v_u_1
	if v_u_16 then
		return v_u_16
	end
	if os.clock() - v_u_17 < 3 then
		return nil
	end
	v_u_17 = os.clock()
	local v18 = v_u_1:FindFirstChild("Shared")
	if v18 then
		v18 = v18:FindFirstChild("Camera")
	end
	if v18 and v18:IsA("ModuleScript") then
		local v19 = require
		local v20, v21 = pcall(v19, v18)
		if v20 and type(v21) == "table" then
			v_u_16 = v21
		end
	end
	return v_u_16
end
local function v_u_25() -- name: applyMouse
	-- upvalues: (copy) v_u_14, (ref) v_u_15, (copy) v_u_11, (copy) v_u_2
	local v22 = next(v_u_14) ~= nil
	if v22 ~= v_u_15 then
		v_u_15 = v22
		local v23 = v_u_11.Camera()
		if v23 then
			local v24
			if v22 then
				v24 = v23.PushMouseUnlock
			else
				v24 = v23.PopMouseUnlock
			end
			if type(v24) == "function" then
				pcall(v24, "UI")
			end
		end
		if v22 then
			v_u_2.MouseIconEnabled = true
		end
	end
end
function v_u_11.PushMouse(p26) -- name: PushMouse
	-- upvalues: (copy) v_u_14, (copy) v_u_25
	v_u_14[p26] = true
	v_u_25()
end
function v_u_11.PopMouse(p27) -- name: PopMouse
	-- upvalues: (copy) v_u_14, (copy) v_u_25
	v_u_14[p27] = nil
	v_u_25()
end
local v_u_28 = nil
local function v_u_32(p29) -- name: setBlur
	-- upvalues: (copy) v_u_3, (ref) v_u_28, (copy) v_u_4
	local v30 = v_u_3.CurrentCamera
	if v30 then
		if not v_u_28 or v_u_28.Parent ~= v30 then
			if v_u_28 then
				v_u_28:Destroy()
			end
			local v31 = Instance.new("BlurEffect")
			v31.Name = "TribesMenuBlur"
			v31.Size = 0
			v31.Parent = v30
			v_u_28 = v31
		end
		v_u_4:Create(v_u_28, TweenInfo.new(0.25, Enum.EasingStyle.Quad), {
			["Size"] = p29 and 12 or 0
		}):Play()
	end
end
local v_u_33 = nil
local function v_u_39() -- name: hideChat
	-- upvalues: (ref) v_u_33
	if not v_u_33 then
		local v_u_34 = {}
		v_u_33 = v_u_34
		pcall(function()
			-- upvalues: (copy) v_u_34
			local v35 = game:GetService("TextChatService")
			local v36 = v35:FindFirstChildOfClass("ChatWindowConfiguration")
			local v37 = v35:FindFirstChildOfClass("ChatInputBarConfiguration")
			if v36 then
				v_u_34.window = v36.Enabled
				v36.Enabled = false
			end
			if v37 then
				v_u_34.bar = v37.Enabled
				v37.Enabled = false
			end
		end)
		pcall(function()
			-- upvalues: (copy) v_u_34
			local v38 = game:GetService("StarterGui")
			v_u_34.core = v38:GetCoreGuiEnabled(Enum.CoreGuiType.Chat)
			v38:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, false)
		end)
	end
end
local function v_u_44() -- name: restoreChat
	-- upvalues: (ref) v_u_33
	local v_u_40 = v_u_33
	if v_u_40 then
		v_u_33 = nil
		pcall(function()
			-- upvalues: (copy) v_u_40
			local v41 = game:GetService("TextChatService")
			local v42 = v41:FindFirstChildOfClass("ChatWindowConfiguration")
			local v43 = v41:FindFirstChildOfClass("ChatInputBarConfiguration")
			if v42 and v_u_40.window ~= nil then
				v42.Enabled = v_u_40.window
			end
			if v43 and v_u_40.bar ~= nil then
				v43.Enabled = v_u_40.bar
			end
		end)
		pcall(function()
			-- upvalues: (copy) v_u_40
			if v_u_40.core ~= nil then
				game:GetService("StarterGui"):SetCoreGuiEnabled(Enum.CoreGuiType.Chat, v_u_40.core)
			end
		end)
	end
end
local v_u_45 = {}
function v_u_11.HoldChat(p46, p47) -- name: HoldChat
	-- upvalues: (copy) v_u_45, (copy) v_u_39, (copy) v_u_44
	if p47 then
		v_u_45[p46] = true
		v_u_39()
	else
		v_u_45[p46] = nil
		if next(v_u_45) == nil then
			v_u_44()
		end
	end
end
local v_u_48 = {}
local v_u_49 = false
v_u_11.FocusChanged = v8.new()
local function v_u_51(p50) -- name: usable
	if typeof(p50) ~= "Instance" or not (p50:IsA("GuiObject") and (p50:IsDescendantOf(game) and p50.Selectable)) then
		return false
	end
	while p50 and p50 ~= game do
		if p50:IsA("GuiObject") and not p50.Visible or p50:IsA("ScreenGui") and not p50.Enabled then
			return false
		end
		p50 = p50.Parent
	end
	return true
end
local function v_u_56(p52) -- name: selectOwner
	-- upvalues: (copy) v_u_10, (copy) v_u_51, (copy) v_u_6, (ref) v_u_13, (copy) v_u_12, (copy) v_u_48
	if v_u_10.Gamepad then
		if p52 and v_u_51(v_u_6.SelectedObject) then
			return
		else
			local v53
			if v_u_13 then
				v53 = v_u_12[v_u_13]
				if v53 then
					v53 = v53.select
				end
			else
				v53 = v_u_48[#v_u_48]
				if v53 then
					v53 = v53.select
				end
			end
			if v53 then
				local v54, v55 = pcall(v53)
				if v54 and v_u_51(v55) then
					v_u_6.SelectedObject = v55
				end
			end
		end
	else
		return
	end
end
local v_u_57 = false
local v_u_58 = 0
local v_u_59 = {}
local v_u_60 = {}
local function v_u_65() -- name: characterContexts
	-- upvalues: (copy) v_u_7
	local v61 = game:GetService("StarterPlayer"):FindFirstChild("PlayerModule")
	local v62 = {}
	for _, v64 in { v_u_7.LocalPlayer, v61 } do
		local v64
		if v64 then
			v64 = v64:FindFirstChild("InputContexts")
		end
		if v64 then
			v64 = v64:FindFirstChild("CharacterContext")
		end
		if not (v64 and v64:IsA("InputContext")) then
			continue
		end
		table.insert(v62, v64)
	end
	return v62
end
local function v_u_71() -- name: refreshPadBlock
	-- upvalues: (copy) v_u_10, (ref) v_u_13, (copy) v_u_48, (ref) v_u_49, (ref) v_u_58, (ref) v_u_57, (copy) v_u_9, (copy) v_u_65, (copy) v_u_60, (copy) v_u_7, (copy) v_u_59
	local v66 = v_u_10.Gamepad
	if v66 then
		v66 = v_u_13 ~= nil and true or (v_u_48[#v_u_48] ~= nil and true or v_u_49)
	end
	v_u_58 = v_u_58 + 1
	if v66 then
		if v_u_57 ~= true then
			v_u_57 = true
			v_u_9.SetPadBlocked(true)
			for _, v67 in v_u_65() do
				if not v67.Enabled then
					continue
				end
				v67.Enabled = false
				v_u_60[v67] = true
			end
			v_u_7.LocalPlayer:SetAttribute("PadMenu", true)
		end
	elseif v_u_57 then
		local v_u_68 = v_u_58
		task.spawn(function()
			-- upvalues: (ref) v_u_59, (copy) v_u_68, (ref) v_u_58, (ref) v_u_57, (ref) v_u_9, (ref) v_u_60, (ref) v_u_7
			local v69 = os.clock()
			while (v_u_59[Enum.KeyCode.ButtonA] or v_u_59[Enum.KeyCode.ButtonB]) and os.clock() - v69 < 3 do
				task.wait()
			end
			task.wait(0.05)
			if v_u_68 == v_u_58 then
				if v_u_57 == false then
					return
				end
				v_u_57 = false
				v_u_9.SetPadBlocked(false)
				for v70 in v_u_60 do
					if not v70.Parent then
						continue
					end
					v70.Enabled = true
				end
				table.clear(v_u_60)
				v_u_7.LocalPlayer:SetAttribute("PadMenu", false)
			end
		end)
	end
end
function v_u_11.PadBlocked() -- name: PadBlocked
	-- upvalues: (ref) v_u_57
	return v_u_57
end
function v_u_11.PushFocus(p72, p73, p74) -- name: PushFocus
	-- upvalues: (copy) v_u_11, (copy) v_u_48, (ref) v_u_49, (copy) v_u_71, (ref) v_u_13, (copy) v_u_56
	v_u_11.PopFocus(p72, true)
	local v75 = v_u_48
	local v76 = {
		["key"] = p72,
		["select"] = p73,
		["back"] = p74,
		["at"] = os.clock()
	}
	table.insert(v75, v76)
	if v_u_49 then
		v_u_49 = false
		v_u_71()
		v_u_11.FocusChanged:Fire()
	end
	if not v_u_13 then
		v_u_56()
	end
	v_u_71()
	v_u_11.FocusChanged:Fire()
end
function v_u_11.PopFocus(p77, p78) -- name: PopFocus
	-- upvalues: (copy) v_u_48, (ref) v_u_13, (copy) v_u_6, (copy) v_u_56, (copy) v_u_71, (copy) v_u_11
	for v79, v80 in v_u_48 do
		if v80.key ~= p77 then
			continue
		end
		table.remove(v_u_48, v79)
		if not p78 then
			if not v_u_13 then
				v_u_6.SelectedObject = nil
				v_u_56()
			end
			v_u_71()
			v_u_11.FocusChanged:Fire()
		end
		return
	end
end
function v_u_11.HasFocus(p81) -- name: HasFocus
	-- upvalues: (copy) v_u_48
	if p81 == nil then
		return v_u_48[#v_u_48] ~= nil
	end
	for _, v82 in v_u_48 do
		if v82.key ~= p81 then
			continue
		end
		return true
	end
	return false
end
function v_u_11.Reselect() -- name: Reselect
	-- upvalues: (ref) v_u_13, (copy) v_u_48, (copy) v_u_56
	if v_u_13 or v_u_48[#v_u_48] then
		v_u_56(true)
	end
end
function v_u_11.HudFocus(p83) -- name: HudFocus
	-- upvalues: (copy) v_u_10, (ref) v_u_13, (copy) v_u_48, (copy) v_u_51, (ref) v_u_49, (copy) v_u_6, (copy) v_u_71, (copy) v_u_11
	if not v_u_10.Gamepad or (v_u_13 or (v_u_48[#v_u_48] or not v_u_51(p83))) then
		return false
	end
	v_u_49 = true
	v_u_6.SelectedObject = p83
	v_u_71()
	v_u_11.FocusChanged:Fire()
	return true
end
function v_u_11.EndHudFocus() -- name: EndHudFocus
	-- upvalues: (ref) v_u_49, (copy) v_u_6, (copy) v_u_71, (copy) v_u_11
	if v_u_49 then
		v_u_49 = false
		v_u_6.SelectedObject = nil
		v_u_71()
		v_u_11.FocusChanged:Fire()
	end
end
function v_u_11.HudFocused() -- name: HudFocused
	-- upvalues: (ref) v_u_49
	return v_u_49
end
function v_u_11.Register(p84, p85) -- name: Register
	-- upvalues: (copy) v_u_12
	v_u_12[p84] = p85
end
local v_u_86 = nil
function v_u_11.SetLoader(p87) -- name: SetLoader
	-- upvalues: (ref) v_u_86
	v_u_86 = p87
end
function v_u_11.IsOpen(p88) -- name: IsOpen
	-- upvalues: (ref) v_u_13
	if p88 == nil then
		return v_u_13 ~= nil
	else
		return v_u_13 == p88
	end
end
function v_u_11.Current() -- name: Current
	-- upvalues: (ref) v_u_13
	return v_u_13
end
local v_u_89 = (-1 / 0)
function v_u_11.RecentlyOpen(p90) -- name: RecentlyOpen
	-- upvalues: (ref) v_u_13, (ref) v_u_89
	return v_u_13 ~= nil and true or os.clock() - v_u_89 < (p90 or 0.2)
end
function v_u_11.Close(p91, p92) -- name: Close
	-- upvalues: (ref) v_u_13, (copy) v_u_12, (ref) v_u_89, (copy) v_u_11, (copy) v_u_32, (copy) v_u_14, (copy) v_u_25, (copy) v_u_6, (copy) v_u_56, (copy) v_u_71
	local v93 = p91 or v_u_13
	if v93 and v93 == v_u_13 then
		local v94 = v_u_12[v93]
		v_u_13 = nil
		v_u_89 = os.clock()
		if v94 then
			local v95 = v94.close
			local v96, v97 = pcall(v95, p92)
			if not v96 then
				warn("[UI] menu " .. v93 .. " failed to close: " .. tostring(v97))
			end
		end
		v_u_11.HoldChat("menu", false)
		v_u_32(false)
		v_u_14.Menu = nil
		v_u_25()
		v_u_6.SelectedObject = nil
		v_u_56()
		v_u_71()
		v_u_11.Changed:Fire(nil)
	end
end
function v_u_11.Open(p98, ...) -- name: Open
	-- upvalues: (copy) v_u_12, (ref) v_u_86, (ref) v_u_13, (copy) v_u_11, (ref) v_u_49, (copy) v_u_71, (copy) v_u_6, (copy) v_u_32, (copy) v_u_14, (copy) v_u_25, (copy) v_u_56
	local v99 = v_u_12[p98]
	if not v99 and v_u_86 then
		v_u_86(p98)
		v99 = v_u_12[p98]
	end
	if v99 then
		if v_u_13 == p98 then
			v99.open(...)
		else
			v_u_11.HoldChat("menu", true)
			if v_u_13 then
				local v100 = v_u_12[v_u_13]
				v_u_13 = nil
				if v100 then
					v100.close(true)
				end
			end
			v_u_13 = p98
			if v_u_49 then
				v_u_49 = false
				v_u_71()
				v_u_11.FocusChanged:Fire()
			end
			v_u_6.SelectedObject = nil
			v99.open(...)
			v_u_32(v99.blur ~= false)
			v_u_14.Menu = true
			v_u_25()
			v_u_56(true)
			v_u_71()
			v_u_11.Changed:Fire(p98)
		end
	else
		warn("[UI] unknown menu " .. p98)
		return
	end
end
function v_u_11.Toggle(p101, ...) -- name: Toggle
	-- upvalues: (ref) v_u_13, (copy) v_u_11
	if v_u_13 == p101 then
		v_u_11.Close(p101)
	else
		v_u_11.Open(p101, ...)
	end
end
function v_u_11.CloseAll(p102) -- name: CloseAll
	-- upvalues: (ref) v_u_13, (copy) v_u_11
	if v_u_13 then
		v_u_11.Close(v_u_13, p102)
	end
end
function v_u_11.Back() -- name: Back
	-- upvalues: (ref) v_u_13, (copy) v_u_12, (copy) v_u_11, (copy) v_u_48, (ref) v_u_49, (copy) v_u_6, (copy) v_u_71
	if v_u_13 then
		local v103 = v_u_12[v_u_13]
		if v103 and v103.back then
			local v104 = v103.back
			local v105, v106 = pcall(v104)
			if v105 and v106 then
				return true
			end
		end
		v_u_11.Close(v_u_13)
		return true
	end
	local v107 = v_u_48[#v_u_48]
	if not v107 then
		if not v_u_49 then
			return false
		end
		if v_u_49 then
			v_u_49 = false
			v_u_6.SelectedObject = nil
			v_u_71()
			v_u_11.FocusChanged:Fire()
		end
		return true
	end
	if not v107.back then
		return false
	end
	local v108 = v107.back
	local v109, v110 = pcall(v108)
	if v109 then
		v109 = v110 == true
	end
	return v109
end
v_u_9.OnInput("Began", function(p111)
	-- upvalues: (copy) v_u_59, (copy) v_u_11
	local v112 = p111.KeyCode
	if v112 == Enum.KeyCode.ButtonA or v112 == Enum.KeyCode.ButtonB then
		v_u_59[v112] = true
	end
	if v112 == Enum.KeyCode.ButtonB then
		v_u_11.Back()
	end
end)
v_u_9.OnInput("Ended", function(p113)
	-- upvalues: (copy) v_u_59
	local v114 = p113.KeyCode
	if v114 == Enum.KeyCode.ButtonA or v114 == Enum.KeyCode.ButtonB then
		v_u_59[v114] = nil
	end
end)
v_u_9.OnInput("Changed", function(p115)
	-- upvalues: (ref) v_u_49, (copy) v_u_6, (copy) v_u_71, (copy) v_u_11
	if v_u_49 and (p115.KeyCode == Enum.KeyCode.Thumbstick1 and p115.Position.Magnitude > 0.6) then
		if not v_u_49 then
			return
		end
		v_u_49 = false
		v_u_6.SelectedObject = nil
		v_u_71()
		v_u_11.FocusChanged:Fire()
	end
end)
v_u_6:GetPropertyChangedSignal("SelectedObject"):Connect(function()
	-- upvalues: (copy) v_u_6, (ref) v_u_49, (copy) v_u_71, (copy) v_u_11, (copy) v_u_10, (ref) v_u_13, (copy) v_u_48
	if v_u_6.SelectedObject == nil then
		if v_u_49 then
			if v_u_49 then
				v_u_49 = false
				v_u_71()
				v_u_11.FocusChanged:Fire()
			end
		else
			if v_u_10.Gamepad and (v_u_13 or v_u_48[#v_u_48]) then
				task.defer(v_u_11.Reselect)
			end
			return
		end
	else
		return
	end
end)
local v_u_116 = 0
task.spawn(function()
	-- upvalues: (ref) v_u_49, (copy) v_u_51, (copy) v_u_6, (copy) v_u_7, (copy) v_u_71, (copy) v_u_11, (ref) v_u_13, (copy) v_u_48, (ref) v_u_116
	while true do
		task.wait(0.5)
		if v_u_49 and (not v_u_51(v_u_6.SelectedObject) or v_u_7.LocalPlayer:GetAttribute("State") == "Match") and v_u_49 then
			v_u_49 = false
			v_u_6.SelectedObject = nil
			v_u_71()
			v_u_11.FocusChanged:Fire()
		end
		local v117
		if v_u_13 then
			v117 = nil
		else
			v117 = v_u_48[#v_u_48]
		end
		if v117 then
			local v118 = v117.select
			local v119, v120 = pcall(v118)
			if v119 and v_u_51(v120) then
				v_u_116 = 0
			else
				v_u_116 = v_u_116 + 1
				if v_u_116 < 4 then
					continue
				end
				v_u_116 = 0
				v_u_11.PopFocus(v117.key)
			end
		else
			v_u_116 = 0
		end
	end
end)
v_u_10.GamepadChanged:Connect(function(p121)
	-- upvalues: (copy) v_u_56, (ref) v_u_49, (copy) v_u_6, (copy) v_u_71
	if p121 then
		v_u_56(true)
	else
		v_u_49 = false
		v_u_6.SelectedObject = nil
	end
	v_u_71()
end)
function v_u_11.Reasons() -- name: Reasons
	-- upvalues: (copy) v_u_14
	local v122 = {}
	for v123 in v_u_14 do
		table.insert(v122, v123)
	end
	table.sort(v122)
	return v122
end
v5:BindToRenderStep("TribesUIMouse", Enum.RenderPriority.Camera.Value + 5, function()
	-- upvalues: (copy) v_u_14, (ref) v_u_13, (copy) v_u_25, (ref) v_u_15, (copy) v_u_11, (copy) v_u_2
	if v_u_14.Menu and v_u_13 == nil then
		v_u_14.Menu = nil
		v_u_25()
	end
	if v_u_15 then
		if not v_u_11.Camera() then
			v_u_2.MouseBehavior = Enum.MouseBehavior.Default
		end
		v_u_2.MouseIconEnabled = true
	end
end)
return v_u_11