local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("GuiService")
local v_u_5 = require(game:GetService("ReplicatedStorage"):WaitForChild("Shared"):WaitForChild("Keybinds"))
local v6 = {}
local function v10(p7) -- name: pct
	local v8 = string.format
	local v9 = p7 * 100 + 0.5
	return v8("%d%%", (math.floor(v9)))
end
local v_u_11 = {}
local v17 = {
	["title"] = "CAMERA",
	["items"] = nil,
	["items"] = {
		{
			["key"] = "sensitivity",
			["kind"] = "slider",
			["label"] = "CAMERA SENSITIVITY",
			["desc"] = "How fast the camera turns",
			["step"] = 0.05,
			["notPad"] = true,
			["fmt"] = nil,
			["fmt"] = function(p12) -- name: fmt
				return string.format("%.2fx", p12)
			end
		},
		{
			["key"] = "padSensitivity",
			["kind"] = "slider",
			["label"] = "CONTROLLER SENSITIVITY",
			["desc"] = "How fast the right stick turns the camera",
			["step"] = 0.05,
			["padOnly"] = true,
			["fmt"] = nil,
			["fmt"] = function(p13) -- name: fmt
				return string.format("%.2fx", p13)
			end
		},
		{
			["key"] = "padInvertY",
			["kind"] = "switch",
			["label"] = "INVERT Y",
			["desc"] = "Push the stick up to look down",
			["padOnly"] = true
		},
		{
			["key"] = "fov",
			["kind"] = "slider",
			["label"] = "FIELD OF VIEW",
			["desc"] = "How much of the map you see",
			["step"] = 1,
			["round"] = true,
			["fmt"] = nil,
			["fmt"] = function(p14) -- name: fmt
				local v15 = p14 + 0.5
				local v16 = math.floor(v15)
				return tostring(v16)
			end
		},
		{
			["key"] = "aimAssist",
			["kind"] = "switch",
			["label"] = "AIM ASSIST",
			["desc"] = "Helps your aim stay on enemies",
			["assistOnly"] = true
		},
		{
			["key"] = "firstPerson",
			["kind"] = "switch",
			["label"] = "FIRST PERSON",
			["desc"] = "Start in first person",
			["capAction"] = "View",
			["pad"] = nil,
			["pad"] = Enum.KeyCode.DPadUp
		},
		{
			["key"] = "viewBobbing",
			["kind"] = "switch",
			["label"] = "VIEW BOBBING",
			["desc"] = "Camera bounce as you walk in first person"
		}
	}
}
local v18 = {
	["title"] = "AUDIO",
	["items"] = nil,
	["items"] = {
		{
			["key"] = "music",
			["kind"] = "slider",
			["label"] = "MUSIC",
			["desc"] = "Lobby and match music",
			["step"] = 0.05,
			["fmt"] = nil,
			["fmt"] = v10
		},
		{
			["key"] = "sfx",
			["kind"] = "slider",
			["label"] = "SOUND EFFECTS",
			["desc"] = "Combat, menus and ambience",
			["step"] = 0.05,
			["fmt"] = nil,
			["fmt"] = v10
		}
	}
}
__set_list(v_u_11, 1, {v17, v18, {
	["title"] = "PARTY",
	["items"] = nil,
	["items"] = {
		{
			["key"] = "friendsOnlyInvites",
			["kind"] = "switch",
			["label"] = "FRIENDS-ONLY INVITES",
			["desc"] = "Only your Roblox friends can invite you to a party"
		}
	}
}, {
	["title"] = "CONTROLS",
	["touchOnly"] = true,
	["items"] = nil,
	["items"] = {
		{
			["kind"] = "action",
			["label"] = "BUTTON LAYOUT",
			["desc"] = "Move and resize your on-screen buttons"
		}
	}
}, {
	["title"] = "CONTROLS",
	["keyboardOnly"] = true,
	["keybinds"] = true,
	["items"] = nil,
	["items"] = {}
}, {
	["title"] = "CONTROLLER",
	["padbinds"] = true,
	["items"] = nil,
	["items"] = {}
}, {
	["title"] = "STAGING",
	["staging"] = true,
	["items"] = nil,
	["items"] = {
		{
			["kind"] = "action",
			["run"] = "replayNewPlayer",
			["button"] = "REPLAY",
			["label"] = "REPLAY NEW-PLAYER FLOW",
			["desc"] = "Welcome card, first match and starter loadouts again"
		},
		{
			["kind"] = "action",
			["run"] = "replayFullHub",
			["button"] = "REPLAY",
			["label"] = "REPLAY WITH A FULL HUB",
			["desc"] = "New player again; FIGHT sends you to a match server"
		},
		{
			["kind"] = "action",
			["run"] = "showNews",
			["button"] = "SHOW",
			["label"] = "SHOW NEWS POPUP",
			["desc"] = "What returning players see when they join"
		},
		{
			["key"] = "moveDebug",
			["kind"] = "switch",
			["session"] = true,
			["label"] = "MOVEMENT DEBUG",
			["desc"] = "Overlay: fps, rollbacks, corrections per stop"
		},
		{
			["key"] = "bodySmoothing",
			["kind"] = "switch",
			["session"] = true,
			["label"] = "BODY SMOOTHING",
			["desc"] = "On: a smooth visual copy; off: your character at 60 Hz steps"
		},
		{
			["key"] = "premiumTest",
			["kind"] = "switch",
			["session"] = true,
			["label"] = "PREMIUM QUEUE ACCESS",
			["desc"] = "Count as a paying player with an old account (test)"
		}
	}
}})
local v_u_19 = {
	["winW"] = 720,
	["rowH"] = 64,
	["pad"] = 18,
	["label"] = 19,
	["desc"] = 16,
	["title"] = 16,
	["cap"] = 22,
	["switchW"] = 58,
	["trackW"] = 236,
	["trackH"] = 8,
	["knob"] = 22,
	["valueW"] = 64,
	["value"] = 19,
	["sectionGap"] = 18,
	["titleGap"] = 8,
	["footerBtn"] = 52,
	["footerTop"] = 16,
	["button"] = 20,
	["kbRowH"] = 52,
	["chipW"] = 124,
	["chipH"] = 36,
	["chipText"] = 16,
	["chipGap"] = 8,
	["itemGap"] = 6,
	["kbHeader"] = 34
}
local v_u_20 = {
	["winW"] = 880,
	["rowH"] = 74,
	["pad"] = 20,
	["label"] = 22,
	["desc"] = 17,
	["title"] = 18,
	["cap"] = 24,
	["switchW"] = 70,
	["trackW"] = 272,
	["trackH"] = 10,
	["knob"] = 28,
	["valueW"] = 78,
	["value"] = 22,
	["sectionGap"] = 18,
	["titleGap"] = 8,
	["footerBtn"] = 58,
	["footerTop"] = 14,
	["button"] = 22,
	["kbRowH"] = 60,
	["chipW"] = 136,
	["chipH"] = 42,
	["chipText"] = 18,
	["chipGap"] = 8,
	["itemGap"] = 6,
	["kbHeader"] = 38
}
local v_u_21 = Color3.fromRGB(58, 63, 78)
local v_u_22 = Color3.fromRGB(142, 149, 166)
function v6.Init(p_u_23) -- name: Init
	-- upvalues: (copy) v_u_19, (copy) v_u_1, (copy) v_u_4, (copy) v_u_2, (copy) v_u_22, (copy) v_u_21, (copy) v_u_5, (copy) v_u_20, (copy) v_u_11, (copy) v_u_3
	local v_u_24 = p_u_23.UI
	local v_u_25 = p_u_23.Theme
	local v_u_26 = p_u_23.State
	local v_u_27 = v_u_25.Colors
	local v_u_28 = v_u_25.Fonts
	local v_u_29 = require(script.Parent.Parent.SettingsStore)
	local v_u_30 = v_u_24.Window({
		["Name"] = "Settings",
		["Title"] = "SETTINGS",
		["Size"] = nil,
		["Parent"] = nil,
		["OnCloseRequested"] = nil,
		["Size"] = UDim2.fromOffset(v_u_19.winW, 640),
		["Parent"] = p_u_23.Canvas.Menus,
		["OnCloseRequested"] = function() -- name: OnCloseRequested
			-- upvalues: (copy) p_u_23
			p_u_23.MenuManager.Close("Settings")
		end
	})
	local v_u_31 = v_u_30.Content
	local v_u_32 = {}
	local v_u_33 = {}
	local v_u_34 = {}
	local v_u_35 = {}
	local v_u_36 = nil
	local v_u_37 = nil
	local v_u_38 = nil
	local v_u_39 = nil
	local v_u_40 = nil
	local v_u_41 = 640
	local v_u_42 = v_u_19
	local v_u_43 = nil
	local v_u_44 = 0
	local v_u_45 = false
	local v_u_46 = 0
	local v_u_47 = {}
	local v_u_48 = {}
	local v_u_49 = nil
	local function v_u_57(p_u_50, p51) -- name: addNav
		-- upvalues: (ref) v_u_47
		local v52 = v_u_47
		local v53 = {
			["items"] = p_u_50,
			["land"] = p51 or p_u_50[1]
		}
		table.insert(v52, v53)
		for v_u_54, v_u_55 in p_u_50 do
			pcall(function()
				-- upvalues: (copy) v_u_55, (copy) v_u_54, (copy) p_u_50
				local v56 = v_u_55
				if v_u_54 == 1 then
					v56.SelectionBehaviorLeft = Enum.SelectionBehavior.Stop
				end
				if v_u_54 == #p_u_50 then
					v56.SelectionBehaviorRight = Enum.SelectionBehavior.Stop
				end
			end)
		end
	end
	local function v_u_66() -- name: leaveCost
		-- upvalues: (copy) v_u_26, (ref) v_u_1
		local v58 = v_u_26.Match
		local v59
		if v58 then
			v59 = v58.phase
		else
			v59 = v58
		end
		if workspace:GetAttribute("CustomServer") == true then
			return "You\'ll wait in this server\'s lobby until the next match.", false
		end
		if v59 == "MatchEnd" then
			return "The match is over. Your result and rewards are kept.", false
		end
		if v59 == "RoundEnd" and v58 then
			local v60 = v58.teams
			if type(v60) == "table" then
				for _, v61 in v58.teams do
					if type(v61) ~= "table" then
						continue
					end
					local v62 = v61.score
					if (tonumber(v62) or 0) < v_u_26.RoundsToWin() then
						continue
					end
					return "The match is decided. Your result and rewards are kept.", false
				end
			end
		end
		if v59 == "Intro" then
			if v58 then
				v58 = v58.round
			end
			if (tonumber(v58) or 1) <= 1 then
				return "The match hasn\'t started yet. Nothing is recorded.", false
			end
		end
		local v63 = "You\'ll forfeit: it counts as a loss with no XP, and a bot takes your place."
		local v64 = v_u_1.LocalPlayer
		local v65 = tonumber(v64:GetAttribute("Streak")) or 0
		if v65 >= 2 then
			v63 = v63 .. string.format("\nYour \240\159\148\165 %d win streak ends.", v65)
		end
		return v63, true
	end
	local v_u_67 = nil
	local function v_u_68() -- name: closeConfirm
		-- upvalues: (ref) v_u_67
		if v_u_67 then
			v_u_67.layer.Visible = false
		end
	end
	local function v_u_81() -- name: openConfirm
		-- upvalues: (ref) v_u_67, (copy) v_u_24, (copy) v_u_27, (copy) v_u_25, (copy) v_u_30, (copy) v_u_68, (copy) v_u_28, (copy) p_u_23, (copy) v_u_66, (ref) v_u_4
		if not v_u_67 then
			local v69 = v_u_24.new("TextButton", {
				["Name"] = "LeaveConfirm",
				["Size"] = UDim2.fromScale(1, 1),
				["BackgroundColor3"] = v_u_27.Void,
				["BackgroundTransparency"] = 0.3,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["Selectable"] = false,
				["ZIndex"] = 40,
				v_u_24.Corner(v_u_25.Radius.Window or UDim.new(0, 18)),
				["Parent"] = v_u_30.Holder
			})
			v69.Activated:Connect(v_u_68)
			local v_u_70 = v_u_24.Panel({
				["Name"] = "Card",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundTransparency"] = 0.02,
				["Radius"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromOffset(470, 250),
				["Radius"] = UDim.new(0, 16),
				["Parent"] = v69
			})
			v_u_24.new("TextButton", {
				["Name"] = "Sink",
				["Size"] = nil,
				["BackgroundTransparency"] = 1,
				["Text"] = "",
				["Selectable"] = false,
				["ZIndex"] = 41,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v_u_70
			})
			pcall(function()
				-- upvalues: (copy) v_u_70
				local v71 = v_u_70
				v71.SelectionGroup = true
				local v72 = Enum.SelectionBehavior.Stop
				local v73 = Enum.SelectionBehavior.Stop
				v71.SelectionBehaviorUp = v72
				v71.SelectionBehaviorDown = v73
				local v74 = Enum.SelectionBehavior.Stop
				local v75 = Enum.SelectionBehavior.Stop
				v71.SelectionBehaviorLeft = v74
				v71.SelectionBehaviorRight = v75
			end)
			v_u_24.DisplayText({
				["Name"] = "Title",
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "LEAVE MATCH?",
				["TextSize"] = 36,
				["TextColor3"] = nil,
				["ZIndex"] = 42,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(0, 24),
				["Size"] = UDim2.new(1, 0, 0, 40),
				["TextColor3"] = v_u_27.Text,
				["Parent"] = v_u_70
			})
			v_u_67 = {
				["layer"] = v69,
				["card"] = v_u_70,
				["body"] = v_u_24.new("TextLabel", {
					["Name"] = "Body",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Text"] = "",
					["FontFace"] = nil,
					["TextSize"] = 19,
					["TextColor3"] = nil,
					["TextWrapped"] = true,
					["ZIndex"] = 42,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0),
					["Position"] = UDim2.new(0.5, 0, 0, 74),
					["Size"] = UDim2.new(1, -56, 0, 70),
					["FontFace"] = v_u_28.Bold,
					["TextColor3"] = v_u_27.TextDim,
					["Parent"] = v_u_70
				}),
				["stay"] = v_u_24.Button({
					["Name"] = "Stay",
					["Text"] = "STAY",
					["TextSize"] = 22,
					["Style"] = "Dark",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 43,
					["Parent"] = nil,
					["OnClick"] = nil,
					["AnchorPoint"] = Vector2.new(0, 1),
					["Position"] = UDim2.new(0, 28, 1, -24),
					["Size"] = UDim2.fromOffset(196, 58),
					["Parent"] = v_u_70,
					["OnClick"] = v_u_68
				}),
				["go"] = v_u_24.Button({
					["Name"] = "Leave",
					["Text"] = "LEAVE",
					["TextSize"] = 22,
					["Style"] = "Danger",
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 43,
					["Parent"] = nil,
					["OnClick"] = nil,
					["AnchorPoint"] = Vector2.new(1, 1),
					["Position"] = UDim2.new(1, -28, 1, -24),
					["Size"] = UDim2.fromOffset(196, 58),
					["Parent"] = v_u_70,
					["OnClick"] = function() -- name: OnClick
						-- upvalues: (ref) v_u_67, (ref) p_u_23
						if v_u_67 then
							v_u_67.layer.Visible = false
						end
						p_u_23.MenuManager.Close("Settings")
						p_u_23.QueueAction("LeaveMatch")
					end
				})
			}
		end
		local v76 = v_u_67
		local v77, v78 = v_u_66()
		v76.body.Text = v77
		local v79 = v76.body
		local v80
		if v78 then
			v80 = v_u_27.Text
		else
			v80 = v_u_27.TextDim
		end
		v79.TextColor3 = v80
		v76.layer.Visible = true
		v_u_24.Enter(v76.card, Vector2.new(0, 16), 0, UDim2.fromScale(0.5, 0.5))
		if v_u_24.Gamepad then
			v_u_4.SelectedObject = v76.stay.Instance
		end
	end
	local v82 = false
	local v_u_83 = v_u_24.new("Frame", {
		["Name"] = "SettingsSelection",
		["Size"] = UDim2.fromScale(1, 1),
		v_u_24.Corner(12),
		v_u_24.Stroke(v_u_27.Accent, 2, 0)
	})
	local v_u_84 = nil
	local function v_u_94(p85, p_u_86) -- name: hookRowFeedback
		-- upvalues: (copy) v_u_24, (copy) v_u_25, (ref) v_u_84
		local v_u_87 = false
		p85.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_24, (ref) v_u_87, (copy) p_u_86, (ref) v_u_25
			if not v_u_24.Touch then
				v_u_87 = true
				local v88 = p_u_86
				v_u_24.Tween(v88, v_u_25.Tween.Fast, {
					["BackgroundTransparency"] = 0.955
				})
			end
		end)
		p85.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_87, (copy) p_u_86, (ref) v_u_84, (ref) v_u_24, (ref) v_u_25
			v_u_87 = false
			local v89 = p_u_86
			local v90 = v_u_84 == p_u_86 and 0.94 or 1
			v_u_24.Tween(v89, v_u_25.Tween.Fast, {
				["BackgroundTransparency"] = v90
			})
		end)
		if p85:IsA("GuiButton") then
			p85.MouseButton1Down:Connect(function()
				-- upvalues: (copy) p_u_86, (ref) v_u_24, (ref) v_u_25
				local v91 = p_u_86
				v_u_24.Tween(v91, v_u_25.Tween.Fast, {
					["BackgroundTransparency"] = 0.93
				})
			end)
			p85.MouseButton1Up:Connect(function()
				-- upvalues: (copy) p_u_86, (ref) v_u_87, (ref) v_u_24, (ref) v_u_25
				local v92 = p_u_86
				local v93 = v_u_87 and 0.955 or 1
				v_u_24.Tween(v92, v_u_25.Tween.Fast, {
					["BackgroundTransparency"] = v93
				})
			end)
		end
	end
	local function v_u_96(p95) -- name: tick
		-- upvalues: (ref) v_u_44, (copy) p_u_23
		if os.clock() - v_u_44 > 0.06 then
			v_u_44 = os.clock()
			p_u_23.Sounds.Play("Tick", {
				["volume"] = 0.2,
				["pitch"] = nil,
				["pitch"] = p95 * 0.6 + 0.8
			})
		end
	end
	local function v_u_102(p97, p98, p99) -- name: textBlock
		-- upvalues: (copy) v_u_24, (ref) v_u_42, (copy) v_u_28, (copy) v_u_27, (ref) v_u_22
		local v100 = v_u_24.new("Frame", {
			["Name"] = "Text",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, v_u_42.pad, 0.5, 0),
			["Size"] = UDim2.new(1, -(v_u_42.pad * 2 + p99 + 16), 0, v_u_42.label + 4 + v_u_42.desc),
			["Parent"] = p97
		})
		local v101 = v_u_24.new("Frame", {
			["Name"] = "Line",
			["Size"] = UDim2.new(1, 0, 0, v_u_42.label),
			v_u_24.List(Enum.FillDirection.Horizontal, 10, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
			["Parent"] = v100
		})
		v_u_24.new("TextLabel", {
			["Name"] = "Label",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["TextXAlignment"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Text"] = p98.label,
			["FontFace"] = v_u_28.Heavy,
			["TextSize"] = v_u_42.label,
			["TextColor3"] = v_u_27.Text,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.new(0, 0, 1, 0),
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Parent"] = v101
		})
		if p98.capAction then
			v_u_24.ActionCap(p98.capAction, {
				["Height"] = nil,
				["TextSize"] = nil,
				["Gamepad"] = nil,
				["LayoutOrder"] = 2,
				["Parent"] = nil,
				["Height"] = v_u_42.cap,
				["TextSize"] = v_u_42.cap - 8,
				["Gamepad"] = p98.pad,
				["Parent"] = v101
			})
		elseif p98.cap then
			v_u_24.KeyCap(p98.cap, {
				["Height"] = nil,
				["TextSize"] = nil,
				["Gamepad"] = nil,
				["LayoutOrder"] = 2,
				["Parent"] = nil,
				["Height"] = v_u_42.cap,
				["TextSize"] = v_u_42.cap - 8,
				["Gamepad"] = p98.pad,
				["Parent"] = v101
			})
		end
		v_u_24.new("TextLabel", {
			["Name"] = "Desc",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = p98.desc,
			["FontFace"] = v_u_28.SemiBold,
			["TextSize"] = v_u_42.desc,
			["TextColor3"] = v_u_22,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Position"] = UDim2.fromOffset(0, v_u_42.label + 4),
			["Size"] = UDim2.new(1, 0, 0, v_u_42.desc),
			["Parent"] = v100
		})
	end
	local function v_u_109(p103, p104, p105, p106) -- name: rowBase
		-- upvalues: (copy) v_u_24, (ref) v_u_42, (copy) v_u_27, (copy) v_u_83, (ref) v_u_35, (copy) v_u_57
		local v107 = v_u_24.new(p103, {
			["Name"] = p106.key or p106.label,
			["Size"] = UDim2.new(1, 0, 0, v_u_42.rowH),
			["LayoutOrder"] = p105,
			["Parent"] = p104
		})
		if p105 > 1 then
			v_u_24.new("Frame", {
				["Name"] = "Divider",
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.93,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_27.Stroke,
				["Position"] = UDim2.fromOffset(v_u_42.pad, 0),
				["Size"] = UDim2.new(1, -v_u_42.pad * 2, 0, 1),
				["Parent"] = v107
			})
		end
		local v108 = v_u_24.new("Frame", {
			["Name"] = "Highlight",
			["BackgroundColor3"] = v_u_27.White,
			["BackgroundTransparency"] = 1,
			["Position"] = UDim2.fromOffset(4, 4),
			["Size"] = UDim2.new(1, -8, 1, -8),
			v_u_24.Corner(9),
			["Parent"] = v107
		})
		v107.SelectionImageObject = v_u_83
		v_u_35[v107] = v108
		v_u_57({ v107 })
		return v107, v108
	end
	local function v_u_128(p110, p111, p_u_112) -- name: sliderRow
		-- upvalues: (copy) v_u_29, (ref) v_u_42, (copy) v_u_109, (copy) v_u_102, (copy) v_u_24, (copy) v_u_28, (copy) v_u_27, (ref) v_u_21, (copy) v_u_25, (ref) v_u_34, (copy) v_u_94, (ref) v_u_36, (ref) v_u_32, (ref) v_u_43, (ref) v_u_37
		local v113 = p_u_112.key
		local v_u_114 = v_u_29.RANGES[v113]
		local v115 = v_u_42.trackW + 16 + v_u_42.valueW
		local v_u_116, v117 = v_u_109("Frame", p110, p111, p_u_112)
		v_u_102(v_u_116, p_u_112, v115)
		local v118 = v_u_24.new("Frame", {
			["Name"] = "Control",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, -v_u_42.pad, 0, 0),
			["Size"] = UDim2.new(0, v115, 1, 0),
			["Parent"] = v_u_116
		})
		local v_u_119 = v_u_24.new("TextLabel", {
			["Name"] = "Value",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.fromScale(1, 0.5),
			["Size"] = UDim2.fromOffset(v_u_42.valueW, v_u_42.value + 4),
			["FontFace"] = v_u_28.Heavy,
			["TextSize"] = v_u_42.value,
			["TextColor3"] = v_u_27.Text,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["Parent"] = v118
		})
		local v_u_120 = v_u_24.new("Frame", {
			["Name"] = "Track",
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.fromScale(0, 0.5),
			["Size"] = UDim2.fromOffset(v_u_42.trackW, v_u_42.trackH),
			["BackgroundColor3"] = v_u_21,
			v_u_24.Corner(v_u_25.Radius.Pill),
			["Parent"] = v118
		})
		local v_u_121 = v_u_24.new("Frame", {
			["Name"] = "Fill",
			["Size"] = UDim2.fromScale(0, 1),
			["BackgroundColor3"] = v_u_27.Accent,
			v_u_24.Corner(v_u_25.Radius.Pill),
			["Parent"] = v_u_120
		})
		local v_u_122 = v_u_24.new("Frame", {
			["Name"] = "Knob",
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0, 0.5),
			["Size"] = UDim2.fromOffset(v_u_42.knob, v_u_42.knob),
			["BackgroundColor3"] = v_u_27.Bone,
			["ZIndex"] = 2,
			v_u_24.Corner(v_u_25.Radius.Pill),
			v_u_24.Stroke(v_u_27.AccentDark, 2, 0.1),
			["Parent"] = v_u_120
		})
		local v123 = v_u_24.new("TextButton", {
			["Name"] = "Hit",
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 5,
			["Selectable"] = false,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(-14, 0),
			["Size"] = UDim2.new(1, 14 + v_u_42.pad, 1, 0),
			["Parent"] = v118
		})
		v_u_116.Selectable = true
		pcall(function()
			-- upvalues: (copy) v_u_116
			v_u_116.SelectionBehaviorLeft = Enum.SelectionBehavior.Stop
			v_u_116.SelectionBehaviorRight = Enum.SelectionBehavior.Stop
		end)
		v_u_34[v_u_116] = p_u_112
		v_u_94(v123, v117)
		v_u_36 = v_u_36 or v_u_116
		v_u_32[v113] = function(p124, p125)
			-- upvalues: (copy) v_u_114, (copy) v_u_119, (copy) p_u_112, (copy) v_u_121, (copy) v_u_122, (ref) v_u_24, (ref) v_u_25
			local v126 = (p124 - v_u_114[1]) / (v_u_114[2] - v_u_114[1])
			local v127 = math.clamp(v126, 0, 1)
			v_u_119.Text = p_u_112.fmt(p124)
			if p125 then
				v_u_121.Size = UDim2.fromScale(v127, 1)
				v_u_122.Position = UDim2.fromScale(v127, 0.5)
			else
				v_u_24.Tween(v_u_121, v_u_25.Tween.Fast, {
					["Size"] = UDim2.fromScale(v127, 1)
				})
				v_u_24.Tween(v_u_122, v_u_25.Tween.Fast, {
					["Position"] = UDim2.fromScale(v127, 0.5)
				})
			end
		end
		v123.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_43, (copy) p_u_112, (copy) v_u_120, (copy) v_u_122, (ref) v_u_37, (ref) v_u_24, (ref) v_u_25
			v_u_43 = {
				["item"] = p_u_112,
				["track"] = v_u_120,
				["knob"] = v_u_122
			}
			if v_u_37 then
				v_u_37.ScrollingEnabled = false
			end
			v_u_24.Tween(v_u_24.GetScaleObj(v_u_122), v_u_25.Tween.PopSmall, {
				["Scale"] = 1.2
			})
		end)
	end
	local function v_u_148(p129, p130, p_u_131) -- name: switchRow
		-- upvalues: (copy) v_u_109, (copy) v_u_24, (ref) v_u_42, (copy) v_u_102, (copy) v_u_94, (ref) v_u_36, (ref) v_u_32, (copy) p_u_23, (copy) v_u_29, (ref) v_u_33
		local v_u_132 = p_u_131.key
		local v133, v134 = v_u_109("TextButton", p129, p130, p_u_131)
		local v_u_135 = v_u_24.Switch({
			["Width"] = v_u_42.switchW,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -v_u_42.pad, 0.5, 0),
			["Parent"] = v133
		})
		v_u_102(v133, p_u_131, v_u_42.switchW)
		v_u_94(v133, v134)
		v_u_36 = v_u_36 or v133
		v_u_32[v_u_132] = function(p136, p137)
			-- upvalues: (copy) p_u_131, (copy) v_u_132, (ref) p_u_23, (copy) v_u_135
			if p_u_131.session then
				local v138 = v_u_132
				local v139
				if v138 == "moveDebug" then
					v139 = p_u_23.MoveDebugShown
					local _ = p_u_23.MoveDebugToggle
				elseif v138 == "bodySmoothing" then
					v139 = p_u_23.BodySmoothingOn
					local _ = p_u_23.BodySmoothingToggle
				elseif v138 == "premiumTest" then
					v139 = p_u_23.PremiumTestOn
					local _ = p_u_23.PremiumTestToggle
				else
					v139 = nil
				end
				local v140 = v_u_135
				local v141
				if v139 == nil then
					v141 = false
				else
					v141 = v139() == true
				end
				v140:Set(v141, p137)
			else
				v_u_135:Set(p136 >= 0.5, p137)
			end
		end
		local function v147() -- name: flip
			-- upvalues: (copy) p_u_131, (copy) v_u_132, (ref) p_u_23, (copy) v_u_135, (ref) v_u_29
			if p_u_131.session then
				local v142 = v_u_132
				local v143, v144
				if v142 == "moveDebug" then
					v143 = p_u_23.MoveDebugShown
					v144 = p_u_23.MoveDebugToggle
				elseif v142 == "bodySmoothing" then
					v143 = p_u_23.BodySmoothingOn
					v144 = p_u_23.BodySmoothingToggle
				elseif v142 == "premiumTest" then
					v143 = p_u_23.PremiumTestOn
					v144 = p_u_23.PremiumTestToggle
				else
					v144 = nil
					v143 = nil
				end
				if v144 then
					v144()
				end
				local v145
				if v143 == nil then
					v145 = false
				else
					v145 = v143() == true
				end
				v_u_135:Set(v145, false)
				p_u_23.Sounds.Play("Click", {
					["pitch"] = v145 and 1.08 or 0.94
				})
			else
				local v146 = v_u_29.Get(v_u_132) < 0.5
				v_u_29.Set(v_u_132, v146 and 1 or 0, true)
				p_u_23.Sounds.Play("Click", {
					["pitch"] = v146 and 1.08 or 0.94
				})
			end
		end
		v_u_33[v_u_132] = v147
		v133.Activated:Connect(v147)
	end
	local function v_u_156(p149, p150, p_u_151) -- name: actionRow
		-- upvalues: (copy) v_u_109, (copy) v_u_24, (ref) v_u_42, (copy) v_u_28, (copy) v_u_27, (copy) v_u_102, (copy) v_u_94, (ref) v_u_36, (copy) p_u_23
		local v152, v153 = v_u_109("TextButton", p149, p150, p_u_151)
		local v154 = p_u_151.button and 120 or 90
		local v155 = v_u_24.new("Frame", {
			["Name"] = "Edit",
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -v_u_42.pad, 0.5, 0),
			["Size"] = UDim2.fromOffset(v154, v_u_42.label + 8),
			v_u_24.List(Enum.FillDirection.Horizontal, 4, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
			["Parent"] = v152
		})
		v_u_24.new("TextLabel", {
			["Name"] = "Text",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Text"] = p_u_151.button or "EDIT",
			["FontFace"] = v_u_28.Heavy,
			["TextSize"] = v_u_42.value,
			["TextColor3"] = v_u_27.Accent,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.new(0, 0, 1, 0),
			["Parent"] = v155
		})
		v_u_24.Icon("chevRight", v_u_42.value, v_u_27.Accent, {
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["Parent"] = v155
		})
		v_u_102(v152, p_u_151, v154)
		v_u_94(v152, v153)
		v_u_36 = v_u_36 or v152
		v152.Activated:Connect(function()
			-- upvalues: (ref) p_u_23, (copy) p_u_151
			p_u_23.Sounds.Play("Click")
			if p_u_151.run == "replayNewPlayer" or p_u_151.run == "replayFullHub" then
				if p_u_23.ReplayNewPlayer then
					task.spawn(p_u_23.ReplayNewPlayer, p_u_151.run == "replayFullHub")
					return
				end
			else
				if p_u_151.run == "showNews" then
					p_u_23.MenuManager.Open("News")
					return
				end
				if p_u_23.OpenTouchEditor then
					p_u_23.OpenTouchEditor()
				end
			end
		end)
	end
	local v_u_157 = v_u_84
	local v_u_158 = v82
	local v_u_159 = v_u_43
	local v_u_160 = v_u_32
	local v_u_161 = v_u_37
	local v_u_162 = v_u_67
	local v_u_163 = v_u_36
	local v_u_164 = v_u_47
	local v_u_165 = v_u_33
	local v_u_166 = v_u_34
	local v_u_167 = v_u_35
	local v_u_168 = v_u_42
	local v_u_169 = {}
	local v170 = nil
	local function v_u_177(p171, p172) -- name: setSlider
		-- upvalues: (copy) v_u_29, (copy) v_u_96
		local v173 = p171.key
		local v174 = v_u_29.RANGES[v173]
		if p171.round then
			local v175 = p172 + 0.5
			p172 = math.floor(v175)
		elseif p171.step then
			local v176 = p172 / p171.step + 0.5
			p172 = math.floor(v176) * p171.step
		end
		v_u_29.Set(v173, p172, true)
		v_u_96((v_u_29.Get(v173) - v174[1]) / (v174[2] - v174[1]))
	end
	for _, v178 in v_u_5.ACTIONS do
		if v178.group == "items" and v178.max == 1 then
			if not v170 then
				v170 = {
					["label"] = "ITEMS",
					["ids"] = nil,
					["items"] = true,
					["ids"] = {}
				}
				table.insert(v_u_169, v170)
			end
			local v179 = v170.ids
			local v180 = v178.id
			table.insert(v179, v180)
		else
			local v181 = {
				["label"] = nil,
				["ids"] = nil,
				["items"] = false,
				["label"] = v178.label,
				["ids"] = { v178.id }
			}
			table.insert(v_u_169, v181)
		end
	end
	local v_u_182 = {}
	local v_u_183 = nil
	local v_u_184 = nil
	local v_u_185 = 0
	local v_u_186 = v_u_27.Void
	local v_u_187 = nil
	local function v_u_194(p188) -- name: paintChip
		-- upvalues: (ref) v_u_5, (copy) v_u_27, (ref) v_u_187
		local v189 = v_u_5.Get(p188.id)[p188.slot]
		local v190 = p188.label
		local v191
		if v189 then
			if p188.items then
				v191 = v_u_5.CapFor(v189) or "?"
			else
				v191 = v_u_5.Display(v189)
			end
		else
			v191 = "\226\128\148"
		end
		v190.Text = v191
		local v192 = p188.label
		local v193
		if v189 then
			v193 = v_u_27.Text
		else
			v193 = v_u_27.TextMuted
		end
		v192.TextColor3 = v193
		p188.button.BackgroundTransparency = v189 and 0.35 or 0.72
		if v_u_187 ~= p188.button then
			p188.stroke.Color = v_u_27.Stroke
			p188.stroke.Transparency = v189 and 0.8 or 0.9
		end
	end
	local function v_u_197() -- name: paintKeybinds
		-- upvalues: (ref) v_u_182, (copy) v_u_194, (ref) v_u_183, (ref) v_u_5
		for _, v195 in v_u_182 do
			for _, v196 in v195 do
				v_u_194(v196)
			end
		end
		if v_u_183 then
			v_u_183:SetEnabled(not v_u_5.AllDefault())
		end
	end
	local function v_u_201(p198) -- name: flashChips
		-- upvalues: (ref) v_u_182, (copy) v_u_27, (copy) v_u_24, (copy) v_u_186, (copy) v_u_194, (copy) v_u_25
		for _, v_u_199 in v_u_182[p198] or {} do
			v_u_199.button.BackgroundColor3 = v_u_27.AccentDark
			v_u_199.button.BackgroundTransparency = 0.05
			local v200 = {
				["BackgroundColor3"] = v_u_186
			}
			v_u_24.Tween(v_u_199.button, TweenInfo.new(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v200)
			task.delay(0.7, function()
				-- upvalues: (copy) v_u_199, (ref) v_u_194
				if v_u_199.button.Parent then
					v_u_194(v_u_199)
				end
			end)
			v_u_24.Pop(v_u_199.button, 0.25, v_u_25.Tween.PopSmall)
		end
	end
	local v_u_202 = nil
	local v_u_203 = nil
	local v_u_204 = 0
	local v_u_205 = nil
	local v_u_206 = 0
	local function v_u_210() -- name: closeCapture
		-- upvalues: (ref) v_u_203, (ref) v_u_204, (copy) p_u_23, (ref) v_u_202, (ref) v_u_206, (ref) v_u_205, (copy) v_u_30, (copy) v_u_24, (ref) v_u_4
		local v207 = v_u_203
		v_u_203 = nil
		v_u_204 = v_u_204 + 1
		p_u_23.PadCapturing = false
		if v_u_202 then
			v_u_202.layer.Visible = false
		end
		local v208 = v_u_202
		if v208 and v208.box:IsFocused() then
			v208.box:ReleaseFocus()
		end
		if v207 and v207.pad then
			v_u_206 = os.clock() + 0.25
			local v209 = v207.sel
			v_u_205 = v209
			if v209 and (v_u_30.IsOpen and (v_u_24.Gamepad and (v209.Parent and v_u_4.SelectedObject == nil))) then
				v_u_4.SelectedObject = v209
			end
		end
	end
	local function v_u_217(p211) -- name: refuse
		-- upvalues: (ref) v_u_202, (ref) v_u_204, (ref) v_u_203, (copy) v_u_27, (copy) v_u_24, (copy) p_u_23
		local v212 = v_u_202
		v_u_204 = v_u_204 + 1
		local v_u_213 = v_u_204
		local v214
		if v_u_203 == nil then
			v214 = false
		else
			v214 = v_u_203.pad == true
		end
		v212.line1.Text = string.upper(p211)
		v212.line1.TextColor3 = v_u_27.Danger
		v212.line2.Text = v214 and "Pick another button" or "Pick another key"
		v212.line2.Visible = true
		v212.holdHint.Visible = false
		v212.padStroke.Color = v_u_27.Danger
		v_u_24.Shake(v212.pad, 6)
		p_u_23.Sounds.Play("Error")
		task.delay(1.8, function()
			-- upvalues: (copy) v_u_213, (ref) v_u_204, (ref) v_u_203, (ref) v_u_202, (ref) v_u_27
			if v_u_213 == v_u_204 and v_u_203 then
				local v215 = v_u_202
				local v216
				if v_u_203 == nil then
					v216 = false
				else
					v216 = v_u_203.pad == true
				end
				v215.line1.Text = v216 and "PRESS A BUTTON" or "PRESS A KEY"
				v215.line1.TextColor3 = v_u_27.Text
				v215.line2.Text = "or click here with a mouse button"
				v215.line2.Visible = not v216
				v215.holdHint.Visible = v216
				v215.padStroke.Color = v_u_27.Accent
			end
		end)
	end
	local function v_u_236(p218) -- name: commit
		-- upvalues: (ref) v_u_203, (copy) v_u_210, (ref) v_u_5, (copy) p_u_23, (copy) v_u_29, (copy) v_u_201, (ref) v_u_184, (ref) v_u_185, (copy) v_u_24, (copy) v_u_25
		local v219 = v_u_203
		if v219 then
			v_u_210()
			local v220, v221, v222 = v_u_5.Assign(v219.id, v219.slot, p218)
			if #v220 == 0 then
				p_u_23.Sounds.Play("Click")
			else
				v_u_29.SaveKeybinds(v220)
				p_u_23.Sounds.Play("Select")
				v_u_201(v219.id)
				if v221 then
					v_u_201(v221)
					local v223 = v222 or {}
					if #v223 == 0 then
						local v224 = string.format
						local v225 = "%s IS NOW UNBOUND"
						local v226 = v_u_5.Action(v221)
						if v226 then
							v221 = v226.label
						end
						local v227 = v224(v225, v221)
						local v_u_228 = v_u_184
						if v_u_228 then
							v_u_185 = v_u_185 + 1
							local v_u_229 = v_u_185
							v_u_228.Text = v227
							v_u_228.TextTransparency = 0
							task.delay(4, function()
								-- upvalues: (copy) v_u_229, (ref) v_u_185, (copy) v_u_228, (ref) v_u_24, (ref) v_u_25
								if v_u_229 == v_u_185 and v_u_228.Parent then
									v_u_24.Tween(v_u_228, v_u_25.Tween.Smooth, {
										["TextTransparency"] = 1
									})
								end
							end)
						end
					end
					local v230 = string.format
					local v231 = "SWAPPED \194\183 %s NOW USES %s"
					local v232 = v_u_5.Action(v221)
					if v232 then
						v221 = v232.label
					end
					local v233 = v230(v231, v221, v_u_5.Display(v223[1]))
					local v_u_234 = v_u_184
					if not v_u_234 then
						return
					end
					v_u_185 = v_u_185 + 1
					local v_u_235 = v_u_185
					v_u_234.Text = v233
					v_u_234.TextTransparency = 0
					task.delay(4, function()
						-- upvalues: (copy) v_u_235, (ref) v_u_185, (copy) v_u_234, (ref) v_u_24, (ref) v_u_25
						if v_u_235 == v_u_185 and v_u_234.Parent then
							v_u_24.Tween(v_u_234, v_u_25.Tween.Smooth, {
								["TextTransparency"] = 1
							})
						end
					end)
				end
			end
		else
			return
		end
	end
	local function v_u_261() -- name: buildCapture
		-- upvalues: (copy) v_u_24, (copy) v_u_27, (copy) v_u_25, (copy) v_u_30, (copy) v_u_210, (copy) v_u_28, (ref) v_u_203, (ref) v_u_5, (copy) v_u_29, (copy) v_u_201
		local v_u_237 = v_u_24.new("TextButton", {
			["Name"] = "KeyCapture",
			["Size"] = UDim2.fromScale(1, 1),
			["BackgroundColor3"] = v_u_27.Void,
			["BackgroundTransparency"] = 0.3,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["Selectable"] = false,
			["Visible"] = false,
			["ZIndex"] = 50,
			v_u_24.Corner(v_u_25.Radius.Window or UDim.new(0, 18)),
			["Parent"] = v_u_30.Holder
		})
		v_u_237.Activated:Connect(v_u_210)
		local v238 = v_u_24.Panel({
			["Name"] = "Card",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundTransparency"] = 0.02,
			["Radius"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(480, 330),
			["Radius"] = UDim.new(0, 16),
			["Parent"] = v_u_237
		})
		v_u_24.new("TextButton", {
			["Name"] = "Sink",
			["Size"] = nil,
			["BackgroundTransparency"] = 1,
			["Text"] = "",
			["Selectable"] = false,
			["ZIndex"] = 51,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v238
		})
		local v239 = v_u_24.new("TextLabel", {
			["Name"] = "Eyebrow",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "REBIND",
			["FontFace"] = nil,
			["TextSize"] = 15,
			["TextColor3"] = nil,
			["ZIndex"] = 52,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(0, 22),
			["Size"] = UDim2.new(1, 0, 0, 18),
			["FontFace"] = v_u_28.Heavy,
			["TextColor3"] = v_u_27.TextMuted,
			["Parent"] = v238
		})
		local v240 = v_u_24.DisplayText({
			["Name"] = "Title",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["TextSize"] = 34,
			["TextColor3"] = nil,
			["ZIndex"] = 52,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(0, 42),
			["Size"] = UDim2.new(1, 0, 0, 38),
			["TextColor3"] = v_u_27.Text,
			["Parent"] = v238
		})
		local v241 = v_u_24.new("TextLabel", {
			["Name"] = "Now",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 16,
			["TextColor3"] = nil,
			["RichText"] = true,
			["ZIndex"] = 52,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(0, 82),
			["Size"] = UDim2.new(1, 0, 0, 20),
			["FontFace"] = v_u_28.Bold,
			["TextColor3"] = v_u_27.TextDim,
			["Parent"] = v238
		})
		local v242 = v_u_24.new("Frame", {
			["Name"] = "NowPad",
			["Position"] = UDim2.fromOffset(0, 80),
			["Size"] = UDim2.new(1, 0, 0, 24),
			["Visible"] = false,
			v_u_24.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
			["Parent"] = v238
		})
		v_u_24.new("TextLabel", {
			["Name"] = "Label",
			["Text"] = "NOW",
			["FontFace"] = nil,
			["TextSize"] = 16,
			["TextColor3"] = nil,
			["AutomaticSize"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["ZIndex"] = 52,
			["Parent"] = nil,
			["FontFace"] = v_u_28.Bold,
			["TextColor3"] = v_u_27.TextDim,
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Size"] = UDim2.fromOffset(0, 20),
			["Parent"] = v242
		})
		local v243 = v_u_24.PadCap(Enum.KeyCode.ButtonA, {
			["Height"] = 24,
			["LayoutOrder"] = 2,
			["ZIndex"] = 52,
			["Parent"] = nil,
			["Parent"] = v242
		})
		local v244 = v_u_24.new("Frame", {
			["Name"] = "Pad",
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 114),
			["Size"] = UDim2.new(1, -56, 0, 112),
			["BackgroundColor3"] = v_u_27.Void,
			["BackgroundTransparency"] = 0.4,
			["ZIndex"] = 52,
			v_u_24.Corner(14),
			["Parent"] = v238
		})
		local v_u_245 = v_u_24.Stroke(v_u_27.Accent, 2, 0.1)
		v_u_245.Parent = v244
		local v246 = v_u_24.DisplayText({
			["Name"] = "Line1",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "PRESS A KEY",
			["TextSize"] = 28,
			["TextScaled"] = true,
			["TextColor3"] = nil,
			["ZIndex"] = 53,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(12, 26),
			["Size"] = UDim2.new(1, -24, 0, 32),
			["TextColor3"] = v_u_27.Text,
			["Parent"] = v244
		})
		v_u_24.new("UITextSizeConstraint", {
			["MaxTextSize"] = 28,
			["MinTextSize"] = 12,
			["Parent"] = nil,
			["Parent"] = v246
		})
		local v247 = v_u_24.new("TextLabel", {
			["Name"] = "Line2",
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 17,
			["TextColor3"] = nil,
			["ZIndex"] = 53,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(12, 64),
			["Size"] = UDim2.new(1, -24, 0, 20),
			["FontFace"] = v_u_28.SemiBold,
			["TextColor3"] = v_u_27.TextDim,
			["Parent"] = v244
		})
		local v_u_248 = v_u_24.new("Frame", {
			["Name"] = "HoldHint",
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 62),
			["Size"] = UDim2.new(1, -24, 0, 26),
			["Visible"] = false,
			v_u_24.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
			["Parent"] = v244
		})
		local function v251(p249, p250) -- name: hintText
			-- upvalues: (ref) v_u_24, (ref) v_u_28, (ref) v_u_27, (copy) v_u_248
			v_u_24.new("TextLabel", {
				["Name"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 17,
				["TextColor3"] = nil,
				["AutomaticSize"] = nil,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["ZIndex"] = 53,
				["Parent"] = nil,
				["Name"] = "T" .. p250,
				["Text"] = p249,
				["FontFace"] = v_u_28.SemiBold,
				["TextColor3"] = v_u_27.TextDim,
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["Size"] = UDim2.fromOffset(0, 22),
				["LayoutOrder"] = p250,
				["Parent"] = v_u_248
			})
		end
		v251("Hold", 1)
		local v252 = v_u_24.PadCap(Enum.KeyCode.ButtonB, {
			["Height"] = 24,
			["LayoutOrder"] = 2,
			["ZIndex"] = 53,
			["Parent"] = nil,
			["Parent"] = v_u_248
		})
		v251("to cancel", 3)
		local v253 = v_u_24.new("Frame", {
			["Name"] = "Hold",
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, -8),
			["Size"] = UDim2.new(1, -40, 0, 4),
			["BackgroundColor3"] = v_u_27.Void,
			["BackgroundTransparency"] = 0.5,
			["Visible"] = false,
			["ZIndex"] = 53,
			v_u_24.Corner(v_u_25.Radius.Pill),
			["Parent"] = v244
		})
		local v254 = v_u_24.new("Frame", {
			["Name"] = "Fill",
			["Size"] = UDim2.fromScale(0, 1),
			["BackgroundColor3"] = v_u_27.Danger,
			["ZIndex"] = 54,
			v_u_24.Corner(v_u_25.Radius.Pill),
			["Parent"] = v253
		})
		local v256 = v_u_24.Button({
			["Name"] = "Clear",
			["Text"] = "CLEAR",
			["TextSize"] = 20,
			["Style"] = "Dark",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 53,
			["Parent"] = nil,
			["OnClick"] = nil,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 28, 1, -24),
			["Size"] = UDim2.fromOffset(200, 54),
			["Parent"] = v238,
			["OnClick"] = function() -- name: OnClick
				-- upvalues: (ref) v_u_203, (ref) v_u_210, (ref) v_u_5, (ref) v_u_29, (ref) v_u_201
				local v255 = v_u_203
				if v255 then
					v_u_210()
					if v_u_5.Get(v255.id)[v255.slot] then
						v_u_5.Clear(v255.id, v255.slot)
						v_u_29.SaveKeybinds({ v255.id })
						v_u_201(v255.id)
					end
				end
			end
		})
		local v257 = v_u_24.Button({
			["Name"] = "Cancel",
			["Text"] = "CANCEL",
			["TextSize"] = 20,
			["Style"] = "Dark",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 53,
			["Parent"] = nil,
			["OnClick"] = nil,
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(1, -28, 1, -24),
			["Size"] = UDim2.fromOffset(200, 54),
			["Parent"] = v238,
			["OnClick"] = v_u_210
		})
		local v_u_258 = v_u_24.new("TextBox", {
			["Name"] = "KeySink",
			["Size"] = nil,
			["BackgroundTransparency"] = 1,
			["TextTransparency"] = 1,
			["Text"] = "",
			["ClearTextOnFocus"] = true,
			["Selectable"] = false,
			["ZIndex"] = 50,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(1, 1),
			["Parent"] = v_u_237
		})
		v_u_258.FocusLost:Connect(function()
			-- upvalues: (ref) v_u_203, (copy) v_u_237, (copy) v_u_258
			task.defer(function()
				-- upvalues: (ref) v_u_203, (ref) v_u_237, (ref) v_u_258
				if v_u_203 and (not v_u_203.pad and (v_u_237.Visible and not v_u_258:IsFocused())) then
					v_u_258:CaptureFocus()
				end
			end)
		end)
		v_u_258:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (copy) v_u_258
			if v_u_258.Text ~= "" then
				v_u_258.Text = ""
			end
		end)
		v_u_24.Every(v_u_237, 0.03333333333333333, function()
			-- upvalues: (copy) v_u_237, (ref) v_u_203, (copy) v_u_245
			if v_u_237.Visible and v_u_203 then
				local v259 = v_u_245
				local v260 = os.clock() * 5
				v259.Transparency = (math.sin(v260) * 0.5 + 0.5) * 0.35 + 0.15
			end
		end)
		return {
			["layer"] = v_u_237,
			["card"] = v238,
			["eyebrow"] = v239,
			["title"] = v240,
			["now"] = v241,
			["pad"] = v244,
			["padStroke"] = v_u_245,
			["line1"] = v246,
			["line2"] = v247,
			["clear"] = v256,
			["cancel"] = v257,
			["box"] = v_u_258,
			["nowPad"] = v242,
			["nowCap"] = v243,
			["holdHint"] = v_u_248,
			["holdCap"] = v252,
			["hold"] = v253,
			["holdFill"] = v254
		}
	end
	local function v_u_278(p262, p263) -- name: openCapture
		-- upvalues: (ref) v_u_202, (copy) v_u_261, (ref) v_u_5, (ref) v_u_203, (ref) v_u_204, (copy) v_u_27, (copy) v_u_24, (copy) p_u_23
		if not v_u_202 then
			v_u_202 = v_u_261()
		end
		local v_u_264 = v_u_202
		local v265 = v_u_5.Get(p262)
		local v266 = #v265 + 1
		local v267 = math.clamp(p263, 1, v266)
		v_u_203 = {
			["id"] = p262,
			["slot"] = v267,
			["at"] = os.clock()
		}
		v_u_204 = v_u_204 + 1
		local v268 = v_u_5.Action(p262)
		v_u_264.eyebrow.Text = v267 > 1 and "SECOND KEY FOR" or "REBIND"
		local v269 = v_u_264.title
		if v268 then
			p262 = v268.label
		end
		v269.Text = p262
		local v270 = v265[v267]
		v_u_264.now.Text = not v270 and "NOT BOUND" or string.format("NOW  <font color=\"#FFFFFF\">%s</font>", v_u_5.Display(v270))
		v_u_264.now.Visible = true
		v_u_264.nowPad.Visible = false
		v_u_264.hold.Visible = false
		v_u_264.cancel.Instance.Visible = true
		v_u_264.card.Size = UDim2.fromOffset(480, 330)
		local v271 = v_u_202
		local v272
		if v_u_203 == nil then
			v272 = false
		else
			v272 = v_u_203.pad == true
		end
		v271.line1.Text = v272 and "PRESS A BUTTON" or "PRESS A KEY"
		v271.line1.TextColor3 = v_u_27.Text
		v271.line2.Text = "or click here with a mouse button"
		v271.line2.Visible = not v272
		v271.holdHint.Visible = v272
		v271.padStroke.Color = v_u_27.Accent
		local v273 = v270 ~= nil
		v_u_264.clear.Instance.Visible = v273
		local v274 = v_u_264.cancel.Instance
		local v275
		if v273 then
			v275 = Vector2.new(1, 1)
		else
			v275 = Vector2.new(0.5, 1)
		end
		v274.AnchorPoint = v275
		local v276 = v_u_264.cancel.Instance
		local v277
		if v273 then
			v277 = UDim2.new(1, -28, 1, -24)
		else
			v277 = UDim2.new(0.5, 0, 1, -24)
		end
		v276.Position = v277
		v_u_264.layer.Visible = true
		v_u_24.Enter(v_u_264.card, Vector2.new(0, 14), 0, UDim2.fromScale(0.5, 0.5))
		p_u_23.Sounds.Play("Click")
		task.defer(function()
			-- upvalues: (ref) v_u_203, (copy) v_u_264
			if v_u_203 and not v_u_264.box:IsFocused() then
				v_u_264.box:CaptureFocus()
			end
		end)
	end
	v_u_2.InputBegan:Connect(function(p279)
		-- upvalues: (ref) v_u_202, (ref) v_u_203, (ref) v_u_5, (copy) v_u_236, (copy) v_u_217, (copy) v_u_210
		local v280 = v_u_202
		if v_u_203 and (v280 and not v_u_203.pad) then
			local v281 = p279.UserInputType
			if v281 == Enum.UserInputType.Keyboard then
				if p279.KeyCode == Enum.KeyCode.Unknown then
					return
				else
					local v282 = p279.KeyCode.Name
					local v283, v284 = v_u_5.Bindable(v282)
					if v283 then
						v_u_236(v282)
					else
						v_u_217(v284 or "That key can\'t be used")
					end
				end
			else
				if v281 == Enum.UserInputType.MouseButton1 or (v281 == Enum.UserInputType.MouseButton2 or v281 == Enum.UserInputType.MouseButton3) then
					local v285 = Vector2.new(p279.Position.X, p279.Position.Y)
					local v286 = v280.pad
					local v287
					if v286.Visible then
						local v288 = v286.AbsolutePosition
						local v289 = v286.AbsoluteSize
						if v285.X >= v288.X and (v285.Y >= v288.Y and v285.X <= v288.X + v289.X) then
							v287 = v285.Y <= v288.Y + v289.Y
						else
							v287 = false
						end
					else
						v287 = false
					end
					if v287 then
						v_u_236(v281.Name)
						return
					end
					local v290 = v280.card
					local v291
					if v290.Visible then
						local v292 = v290.AbsolutePosition
						local v293 = v290.AbsoluteSize
						if v285.X >= v292.X and (v285.Y >= v292.Y and v285.X <= v292.X + v293.X) then
							v291 = v285.Y <= v292.Y + v293.Y
						else
							v291 = false
						end
					else
						v291 = false
					end
					if v291 then
						return
					end
					if v281 ~= Enum.UserInputType.MouseButton1 then
						v_u_210()
					end
				end
				return
			end
		else
			return
		end
	end)
	local function v_u_305(p294, p_u_295, p_u_296, p297, p298, p299) -- name: keyChip
		-- upvalues: (copy) v_u_24, (ref) v_u_168, (copy) v_u_186, (copy) v_u_27, (copy) v_u_28, (ref) v_u_187, (copy) v_u_25, (ref) v_u_5, (copy) v_u_278, (ref) v_u_182, (copy) v_u_194
		local v_u_300 = v_u_24.new("TextButton", {
			["Name"] = p_u_295 .. "_" .. p_u_296,
			["Size"] = UDim2.fromOffset(p297, v_u_168.chipH),
			["BackgroundColor3"] = v_u_186,
			["BackgroundTransparency"] = 0.35,
			["AutoButtonColor"] = false,
			["Text"] = "",
			["Selectable"] = false,
			["LayoutOrder"] = p299,
			v_u_24.Corner(8),
			["Parent"] = p294
		})
		local v_u_301 = v_u_24.Stroke(v_u_27.Stroke, 1, 0.8)
		v_u_301.Parent = v_u_300
		local v302 = v_u_24.new("TextLabel", {
			["Name"] = "Key",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextScaled"] = true,
			["TextColor3"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.new(1, -10, 0, v_u_168.chipText + 2),
			["FontFace"] = v_u_28.Heavy,
			["TextColor3"] = v_u_27.Text,
			["Parent"] = v_u_300
		})
		v_u_24.new("UITextSizeConstraint", {
			["MaxTextSize"] = nil,
			["MinTextSize"] = 9,
			["Parent"] = nil,
			["MaxTextSize"] = v_u_168.chipText,
			["Parent"] = v302
		})
		local v303 = {
			["button"] = v_u_300,
			["label"] = v302,
			["stroke"] = v_u_301,
			["id"] = p_u_295,
			["slot"] = p_u_296,
			["items"] = p298
		}
		v_u_300.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_187, (copy) v_u_300, (ref) v_u_24, (copy) v_u_301, (ref) v_u_25, (ref) v_u_27
			v_u_187 = v_u_300
			v_u_24.Tween(v_u_301, v_u_25.Tween.Fast, {
				["Color"] = nil,
				["Transparency"] = 0.1,
				["Color"] = v_u_27.Accent
			})
		end)
		v_u_300.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_187, (copy) v_u_300, (ref) v_u_24, (copy) v_u_301, (ref) v_u_25, (ref) v_u_27, (ref) v_u_5, (copy) p_u_295, (copy) p_u_296
			if v_u_187 == v_u_300 then
				v_u_187 = nil
			end
			v_u_24.Tween(v_u_301, v_u_25.Tween.Fast, {
				["Color"] = v_u_27.Stroke,
				["Transparency"] = v_u_5.Get(p_u_295)[p_u_296] and 0.8 or 0.9
			})
		end)
		v_u_300.Activated:Connect(function()
			-- upvalues: (ref) v_u_278, (copy) p_u_295, (copy) p_u_296
			v_u_278(p_u_295, p_u_296)
		end)
		v_u_182[p_u_295] = v_u_182[p_u_295] or {}
		local v304 = v_u_182[p_u_295]
		table.insert(v304, v303)
		v_u_194(v303)
		return v303
	end
	local function v_u_335(p306, p307) -- name: keybindSection
		-- upvalues: (ref) v_u_182, (ref) v_u_168, (copy) v_u_169, (copy) v_u_24, (ref) v_u_183, (copy) v_u_210, (ref) v_u_5, (copy) v_u_29, (copy) v_u_201, (ref) v_u_184, (ref) v_u_185, (copy) v_u_25, (copy) v_u_28, (copy) v_u_27, (copy) v_u_305, (copy) v_u_197
		v_u_182 = {}
		local v308 = v_u_168.kbHeader
		local v309 = #v_u_169 * v_u_168.kbRowH
		local v310 = v_u_24.new("Frame", {
			["Name"] = "KEYBINDS",
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, v308 + v_u_168.titleGap + v309),
			["LayoutOrder"] = p307,
			["Parent"] = p306
		})
		local v311 = v_u_168.title + 8
		v_u_24.SectionTitle("CONTROLS", {
			["Position"] = UDim2.fromOffset(0, v308 - v311),
			["Size"] = UDim2.new(1, 0, 0, v311),
			["TextSize"] = v_u_168.title,
			["Parent"] = v310
		})
		v_u_183 = v_u_24.Button({
			["Name"] = "ResetKeys",
			["Text"] = "RESET TO DEFAULTS",
			["TextSize"] = nil,
			["Style"] = "Dark",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Radius"] = 9,
			["Parent"] = nil,
			["OnClick"] = nil,
			["TextSize"] = v_u_24.Compact and 16 or 14,
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(1, 0, 0, v308),
			["Size"] = UDim2.fromOffset(v_u_24.Compact and 214 or 186, v308 - 2),
			["Parent"] = v310,
			["OnClick"] = function() -- name: OnClick
				-- upvalues: (ref) v_u_210, (ref) v_u_5, (ref) v_u_29, (ref) v_u_201, (ref) v_u_184, (ref) v_u_185, (ref) v_u_24, (ref) v_u_25
				v_u_210()
				local v312 = v_u_5.ResetAll()
				if #v312 > 0 then
					v_u_29.SaveKeybinds(v312)
					for _, v313 in v312 do
						v_u_201(v313)
					end
					local v_u_314 = v_u_184
					if not v_u_314 then
						return
					end
					v_u_185 = v_u_185 + 1
					local v_u_315 = v_u_185
					v_u_314.Text = "EVERY KEY IS BACK TO ITS DEFAULT"
					v_u_314.TextTransparency = 0
					task.delay(4, function()
						-- upvalues: (copy) v_u_315, (ref) v_u_185, (copy) v_u_314, (ref) v_u_24, (ref) v_u_25
						if v_u_315 == v_u_185 and v_u_314.Parent then
							v_u_24.Tween(v_u_314, v_u_25.Tween.Smooth, {
								["TextTransparency"] = 1
							})
						end
					end)
				end
			end
		})
		v_u_184 = v_u_24.new("TextLabel", {
			["Name"] = "Notice",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["TextTransparency"] = 1,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(1, -((v_u_24.Compact and 214 or 186) + 12), 0, v308 - 4),
			["Size"] = UDim2.new(1, -((v_u_24.Compact and 214 or 186) + 12 + 150), 0, v311),
			["FontFace"] = v_u_28.Heavy,
			["TextSize"] = v_u_24.Compact and 15 or 13,
			["TextColor3"] = v_u_27.Warning,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Parent"] = v310
		})
		local v316 = v_u_24.new("Frame", {
			["Name"] = "Card",
			["Position"] = UDim2.fromOffset(0, v308 + v_u_168.titleGap),
			["Size"] = UDim2.new(1, 0, 0, v309),
			["BackgroundColor3"] = v_u_27.PanelHi,
			["BackgroundTransparency"] = 0.3,
			v_u_24.Corner(12),
			v_u_24.Stroke(v_u_27.Stroke, 1, 0.92),
			v_u_24.List(Enum.FillDirection.Vertical, 0),
			["Parent"] = v310
		})
		local v317 = v_u_168.chipW * 2 + v_u_168.chipGap
		for v318, v319 in v_u_169 do
			local v320 = v_u_24.new("Frame", {
				["Name"] = v319.ids[1],
				["Size"] = UDim2.new(1, 0, 0, v_u_168.kbRowH),
				["LayoutOrder"] = v318,
				["Parent"] = v316
			})
			if v318 > 1 then
				v_u_24.new("Frame", {
					["Name"] = "Divider",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.93,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["BackgroundColor3"] = v_u_27.Stroke,
					["Position"] = UDim2.fromOffset(v_u_168.pad, 0),
					["Size"] = UDim2.new(1, -v_u_168.pad * 2, 0, 1),
					["Parent"] = v320
				})
			end
			v_u_24.new("TextLabel", {
				["Name"] = "Label",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = nil,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, v_u_168.pad, 0.5, 0),
				["Size"] = UDim2.new(1, -(v_u_168.pad * 2 + v317 + 12), 0, v_u_168.label + 4),
				["Text"] = v319.label,
				["FontFace"] = v_u_28.Heavy,
				["TextSize"] = v_u_168.label,
				["TextColor3"] = v_u_27.Text,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Parent"] = v320
			})
			local v321 = v_u_24.new
			local v322 = "Frame"
			local v323 = {
				["Name"] = "Keys",
				["AnchorPoint"] = Vector2.new(1, 0.5),
				["Position"] = UDim2.new(1, -v_u_168.pad, 0.5, 0),
				["Size"] = UDim2.fromOffset(v317, v_u_168.chipH)
			}
			local v324 = v_u_24.List
			local v325 = Enum.FillDirection.Horizontal
			local v326
			if v319.items then
				v326 = v_u_168.itemGap
			else
				v326 = v_u_168.chipGap
			end
			__set_list(v323, 1, {(v324(v325, v326, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center))})
			v323.Parent = v320
			local v327 = v321(v322, v323)
			if v319.items then
				local v328 = #v319.ids
				local v329 = (v317 - (v328 - 1) * v_u_168.itemGap) / v328
				local v330 = math.floor(v329)
				for v331, v332 in v319.ids do
					v_u_305(v327, v332, 1, v330, true, v331)
				end
			else
				local v333 = v_u_5.Action(v319.ids[1])
				for v334 = 1, v333.max do
					v_u_305(v327, v333.id, v334, v_u_168.chipW, false, v334)
				end
			end
		end
		v_u_197()
		return v310
	end
	v_u_5.Changed:Connect(v_u_197)
	local v_u_336 = {}
	local v_u_337 = {}
	local v_u_338 = nil
	local v_u_339 = nil
	local v_u_340 = nil
	local v_u_341 = nil
	local v_u_342 = 0
	local v_u_343 = v_u_24.new("Frame", {
		["Name"] = "ChipSelection",
		["Position"] = UDim2.fromOffset(-4, -4),
		["Size"] = UDim2.new(1, 8, 1, 8),
		["BackgroundTransparency"] = 1,
		v_u_24.Corner(12),
		v_u_24.Stroke(v_u_27.Accent, 2, 0)
	})
	local function v_u_355() -- name: paintPadBinds
		-- upvalues: (ref) v_u_336, (ref) v_u_5, (copy) v_u_24, (ref) v_u_338, (ref) v_u_4, (ref) v_u_163
		for _, v344 in v_u_336 do
			for _, v345 in v344 do
				local v_u_346 = v_u_5.PadGet(v345.id)[v345.slot]
				local v347 = v_u_24.SetCapPad
				local v348 = v345.cap
				local v349
				if v_u_346 then
					local v350
					v350, v349 = pcall(function()
						-- upvalues: (copy) v_u_346
						return Enum.KeyCode[v_u_346]
					end)
					if not v350 then
						v349 = nil
					end
				else
					v349 = nil
				end
				v347(v348, v349)
				v345.dash.Visible = v_u_346 == nil
				v345.button.BackgroundTransparency = v_u_346 and 0.35 or 0.72
				v345.stroke.Transparency = v_u_346 and 0.8 or 0.9
			end
		end
		if v_u_338 then
			local v351 = not v_u_5.PadAllDefault()
			v_u_338:SetEnabled(v351)
			v_u_338.Instance.Selectable = v351
			if not v351 and v_u_4.SelectedObject == v_u_338.Instance then
				local v352 = v_u_4
				local v353 = v_u_5.PAD_ACTIONS[1]
				if v353 then
					v353 = v_u_336[v353.id]
				end
				local v354
				if v353 and #v353 > 0 then
					v354 = v353[#v353].button
				else
					v354 = nil
				end
				v352.SelectedObject = v354 or v_u_163
			end
		end
	end
	local function v_u_365(p356) -- name: flashPadChips
		-- upvalues: (ref) v_u_336, (copy) v_u_27, (copy) v_u_24, (copy) v_u_186, (ref) v_u_5, (copy) v_u_25
		for _, v_u_357 in v_u_336[p356] or {} do
			v_u_357.button.BackgroundColor3 = v_u_27.AccentDark
			v_u_357.button.BackgroundTransparency = 0.05
			local v358 = {
				["BackgroundColor3"] = v_u_186
			}
			v_u_24.Tween(v_u_357.button, TweenInfo.new(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v358)
			task.delay(0.7, function()
				-- upvalues: (copy) v_u_357, (ref) v_u_5, (ref) v_u_24
				if v_u_357.button.Parent then
					local v359 = v_u_357
					local v_u_360 = v_u_5.PadGet(v359.id)[v359.slot]
					local v361 = v_u_24.SetCapPad
					local v362 = v359.cap
					local v363
					if v_u_360 then
						local v364
						v364, v363 = pcall(function()
							-- upvalues: (copy) v_u_360
							return Enum.KeyCode[v_u_360]
						end)
						if not v364 then
							v363 = nil
						end
					else
						v363 = nil
					end
					v361(v362, v363)
					v359.dash.Visible = v_u_360 == nil
					v359.button.BackgroundTransparency = v_u_360 and 0.35 or 0.72
					v359.stroke.Transparency = v_u_360 and 0.8 or 0.9
				end
			end)
			v_u_24.Pop(v_u_357.button, 0.25, v_u_25.Tween.PopSmall)
		end
	end
	local function v_u_372(p366, p367) -- name: padNote
		-- upvalues: (ref) v_u_339, (ref) v_u_340, (ref) v_u_341, (ref) v_u_342, (copy) v_u_24, (copy) v_u_25
		local v_u_368 = v_u_339
		local v_u_369 = v_u_340
		local v_u_370 = v_u_341
		if v_u_368 and (v_u_369 and v_u_370) then
			v_u_342 = v_u_342 + 1
			local v_u_371 = v_u_342
			v_u_369.Text = p366
			v_u_369.TextTransparency = 0
			v_u_24.SetCapFade(v_u_370, 0)
			v_u_24.SetCapPad(v_u_370, p367)
			v_u_368.Visible = true
			v_u_368.BackgroundTransparency = 0.1
			v_u_24.Pop(v_u_368, 0.85, v_u_25.Tween.PopSmall)
			task.delay(4, function()
				-- upvalues: (copy) v_u_371, (ref) v_u_342, (copy) v_u_368, (ref) v_u_24, (copy) v_u_369, (ref) v_u_25, (copy) v_u_370
				if v_u_371 == v_u_342 and v_u_368.Parent then
					v_u_24.Tween(v_u_369, v_u_25.Tween.Smooth, {
						["TextTransparency"] = 1
					})
					v_u_24.Tween(v_u_368, v_u_25.Tween.Smooth, {
						["BackgroundTransparency"] = 1
					})
					v_u_24.SetCapFade(v_u_370, 0.6)
					task.delay(0.35, function()
						-- upvalues: (ref) v_u_371, (ref) v_u_342, (ref) v_u_368
						if v_u_371 == v_u_342 and v_u_368.Parent then
							v_u_368.Visible = false
						end
					end)
				end
			end)
		end
	end
	local function v_u_388(p373) -- name: noteMoves
		-- upvalues: (ref) v_u_5, (copy) v_u_372
		if #p373 == 0 then
			return
		else
			local v_u_374 = p373[1].now[1]
			local v375 = {}
			local v376 = p373[1].id
			local v377 = v_u_5.PadAction(v376)
			if v377 then
				v376 = v377.label
			end
			__set_list(v375, 1, {v376})
			local v378 = 0
			for v379 = 2, #p373 do
				if p373[v379].now[1] == v_u_374 then
					local v380 = p373[v379].id
					local v381 = v_u_5.PadAction(v380)
					if v381 then
						v380 = v381.label
					end
					table.insert(v375, v380)
				else
					v378 = v378 + 1
				end
			end
			local v382 = table.concat(v375, " AND ") .. (v378 <= 0 and "" or string.format(" (+%d)", v378))
			local v383 = #v375 > 1
			if v_u_374 == nil then
				v_u_372(string.format("%s %s NOW UNBOUND", v382, v383 and "ARE" or "IS"), nil)
			else
				local v384 = v_u_372
				local v385 = string.format("SWAPPED \194\183 %s NOW %s", v382, v383 and "USE" or "USES")
				local v386
				if v_u_374 then
					local v387
					v387, v386 = pcall(function()
						-- upvalues: (copy) v_u_374
						return Enum.KeyCode[v_u_374]
					end)
					if not v387 then
						v386 = nil
					end
				else
					v386 = nil
				end
				v384(v385, v386)
			end
		end
	end
	local function v_u_406(p389, p390, p391) -- name: openPadCapture
		-- upvalues: (ref) v_u_5, (ref) v_u_202, (copy) v_u_261, (ref) v_u_203, (ref) v_u_4, (ref) v_u_204, (copy) p_u_23, (copy) v_u_24, (copy) v_u_27, (ref) v_u_205
		local v392 = v_u_5.PadAction(p389)
		if v392 then
			if not v_u_202 then
				v_u_202 = v_u_261()
			end
			local v393 = v_u_202
			local v394 = v_u_5.PadGet(p389)
			local v395 = v392.max
			local v396 = #v394 + 1
			local v397 = math.min(v395, v396)
			local v398 = math.clamp(p390, 1, v397)
			v_u_203 = {
				["id"] = nil,
				["slot"] = nil,
				["pad"] = true,
				["sel"] = nil,
				["at"] = nil,
				["id"] = p389,
				["slot"] = v398,
				["sel"] = p391 or v_u_4.SelectedObject,
				["at"] = os.clock()
			}
			v_u_204 = v_u_204 + 1
			p_u_23.PadCapturing = true
			v393.eyebrow.Text = v398 > 1 and "SECOND BUTTON FOR" or "REBIND"
			v393.title.Text = v392.label
			local v_u_399 = v394[v398]
			v393.now.Text = "NOT BOUND"
			v393.now.Visible = v_u_399 == nil
			v393.nowPad.Visible = v_u_399 ~= nil
			local v400 = v_u_24.SetCapPad
			local v401 = v393.nowCap
			local v402
			if v_u_399 then
				local v403
				v403, v402 = pcall(function()
					-- upvalues: (copy) v_u_399
					return Enum.KeyCode[v_u_399]
				end)
				if not v403 then
					v402 = nil
				end
			else
				v402 = nil
			end
			v400(v401, v402)
			v_u_24.SetCapPad(v393.holdCap, Enum.KeyCode.ButtonB)
			v393.hold.Visible = false
			v393.holdFill.Size = UDim2.fromScale(0, 1)
			v393.clear.Instance.Visible = false
			v393.cancel.Instance.Visible = false
			v393.card.Size = UDim2.fromOffset(480, 262)
			local v404 = v_u_202
			local v405
			if v_u_203 == nil then
				v405 = false
			else
				v405 = v_u_203.pad == true
			end
			v404.line1.Text = v405 and "PRESS A BUTTON" or "PRESS A KEY"
			v404.line1.TextColor3 = v_u_27.Text
			v404.line2.Text = "or click here with a mouse button"
			v404.line2.Visible = not v405
			v404.holdHint.Visible = v405
			v404.padStroke.Color = v_u_27.Accent
			v393.layer.Visible = true
			v_u_24.Enter(v393.card, Vector2.new(0, 14), 0, UDim2.fromScale(0.5, 0.5))
			p_u_23.Sounds.Play("Click")
			v_u_205 = nil
			v_u_4.SelectedObject = nil
		end
	end
	local function v_u_412(p407) -- name: padCommit
		-- upvalues: (ref) v_u_203, (copy) v_u_210, (ref) v_u_5, (copy) p_u_23, (copy) v_u_29, (copy) v_u_365, (copy) v_u_388
		local v408 = v_u_203
		if v408 and v408.pad then
			v_u_210()
			local v409, v410 = v_u_5.PadAssign(v408.id, v408.slot, p407)
			if #v409 == 0 then
				p_u_23.Sounds.Play("Click")
			else
				v_u_29.SavePadBinds(v409)
				p_u_23.Sounds.Play("Select")
				for _, v411 in v409 do
					v_u_365(v411)
				end
				v_u_388(v410)
			end
		else
			return
		end
	end
	local function v_u_429(p413) -- name: padUnbind
		-- upvalues: (ref) v_u_5, (copy) v_u_29, (copy) p_u_23, (copy) v_u_365, (copy) v_u_372
		if v_u_5.PadGet(p413.id)[p413.slot] then
			v_u_5.PadClear(p413.id, p413.slot)
			v_u_29.SavePadBinds({ p413.id })
			p_u_23.Sounds.Play("Click", {
				["pitch"] = 0.9
			})
			v_u_365(p413.id)
			local v414 = v_u_5.PadGet(p413.id)
			if #v414 == 0 then
				local v415 = v_u_372
				local v416 = string.format
				local v417 = "%s IS NOW UNBOUND"
				local v418 = p413.id
				local v419 = v_u_5.PadAction(v418)
				if v419 then
					v418 = v419.label
				end
				v415(v416(v417, v418), nil)
			else
				local v420 = v_u_372
				local v421 = string.format
				local v422 = "%s NOW USES"
				local v423 = p413.id
				local v424 = v_u_5.PadAction(v423)
				if v424 then
					v423 = v424.label
				end
				local v425 = v421(v422, v423)
				local v_u_426 = v414[1]
				local v427
				if v_u_426 then
					local v428
					v428, v427 = pcall(function()
						-- upvalues: (copy) v_u_426
						return Enum.KeyCode[v_u_426]
					end)
					if not v428 then
						v427 = nil
					end
				else
					v427 = nil
				end
				v420(v425, v427)
			end
		else
			return
		end
	end
	v_u_5.OnInput("Began", function(p430)
		-- upvalues: (ref) v_u_203, (copy) v_u_30, (copy) v_u_24, (ref) v_u_4, (ref) v_u_337, (copy) v_u_429, (copy) v_u_210, (ref) v_u_202, (copy) p_u_23, (ref) v_u_5, (copy) v_u_217, (copy) v_u_27
		local v431 = p430.UserInputType
		local v432 = p430.KeyCode
		local v433 = v431.Name
		local v434 = string.sub(v433, 1, 7) == "Gamepad"
		local v_u_435 = v_u_203
		if v_u_435 then
			if v_u_435.pad and v_u_30.IsOpen then
				if v431 == Enum.UserInputType.Keyboard then
					if v432 ~= Enum.KeyCode.Unknown then
						v_u_210()
					end
				elseif v434 and v432 ~= Enum.KeyCode.Unknown then
					local v436 = v432.Name
					if string.sub(v436, 1, 10) ~= "Thumbstick" then
						if os.clock() - v_u_435.at < 0.15 or v_u_435.down then
							return
						else
							local v437 = v432.Name
							local v_u_438 = v_u_202
							if v437 == "ButtonB" then
								local v439 = os.clock()
								v_u_435.down = v437
								v_u_435.bAt = v439
								v_u_438.hold.Visible = true
								task.spawn(function()
									-- upvalues: (ref) v_u_203, (copy) v_u_435, (copy) v_u_438, (ref) p_u_23, (ref) v_u_210
									while v_u_203 == v_u_435 and v_u_435.bAt do
										local v440 = (os.clock() - v_u_435.bAt) / 0.6
										v_u_438.holdFill.Size = UDim2.fromScale(math.clamp(v440, 0, 1), 1)
										if v440 >= 1 then
											p_u_23.Sounds.Play("Close")
											v_u_210()
											return
										end
										task.wait()
									end
								end)
								return
							else
								local v441, v442 = v_u_5.PadBindable(v437)
								if v441 then
									v_u_435.down = v437
									v_u_438.padStroke.Color = v_u_27.Text
								else
									v_u_217(v442 or "That button can\'t be used")
								end
							end
						end
					end
				end
			else
				return
			end
		else
			if v434 and (v432 == Enum.KeyCode.ButtonX and (v_u_30.IsOpen and v_u_24.Gamepad)) then
				local v443 = v_u_4.SelectedObject
				if v443 then
					v443 = v_u_337[v443]
				end
				if v443 then
					v_u_429(v443)
				end
			end
			return
		end
	end)
	v_u_5.OnInput("Ended", function(p444)
		-- upvalues: (ref) v_u_203, (copy) v_u_412
		local v445 = v_u_203
		local v446 = p444.KeyCode.Name
		if v445 and (v445.pad and v445.down == v446) then
			if v446 == "ButtonB" then
				local v447 = os.clock() - (v445.bAt or os.clock())
				v445.bAt = nil
				if v447 >= 0.6 then
					return
				end
			end
			v_u_412(v446)
		end
	end)
	local function v_u_461(p448, p_u_449, p_u_450, p451) -- name: padChip
		-- upvalues: (copy) v_u_24, (ref) v_u_168, (copy) v_u_186, (copy) v_u_343, (copy) v_u_27, (copy) v_u_28, (copy) v_u_25, (ref) v_u_5, (ref) v_u_203, (ref) v_u_206, (copy) v_u_406, (ref) v_u_336, (ref) v_u_337
		local v_u_452 = v_u_24.new("TextButton", {
			["Name"] = p_u_449 .. "_" .. p_u_450,
			["Size"] = UDim2.fromOffset(v_u_168.chipW, v_u_168.chipH),
			["BackgroundColor3"] = v_u_186,
			["BackgroundTransparency"] = 0.35,
			["AutoButtonColor"] = false,
			["Text"] = "",
			["Selectable"] = true,
			["SelectionImageObject"] = v_u_343,
			["LayoutOrder"] = p451,
			v_u_24.Corner(8),
			["Parent"] = p448
		})
		local v_u_453 = v_u_24.Stroke(v_u_27.Stroke, 1, 0.8)
		v_u_453.Parent = v_u_452
		local v454 = {
			["button"] = v_u_452,
			["cap"] = v_u_24.PadCap(Enum.KeyCode.ButtonA, {
				["Height"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["ZIndex"] = 2,
				["Parent"] = nil,
				["Height"] = v_u_168.chipH - 8,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Parent"] = v_u_452
			}),
			["dash"] = v_u_24.new("TextLabel", {
				["Name"] = "Empty",
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Text"] = "\226\128\148",
				["FontFace"] = nil,
				["TextSize"] = nil,
				["TextColor3"] = nil,
				["Visible"] = false,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.new(1, -10, 0, v_u_168.chipText + 2),
				["FontFace"] = v_u_28.Heavy,
				["TextSize"] = v_u_168.chipText,
				["TextColor3"] = v_u_27.TextMuted,
				["Parent"] = v_u_452
			}),
			["stroke"] = v_u_453,
			["id"] = p_u_449,
			["slot"] = p_u_450
		}
		v_u_452.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_24, (copy) v_u_453, (ref) v_u_25, (ref) v_u_27
			v_u_24.Tween(v_u_453, v_u_25.Tween.Fast, {
				["Color"] = nil,
				["Transparency"] = 0.1,
				["Color"] = v_u_27.Accent
			})
		end)
		v_u_452.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_24, (copy) v_u_453, (ref) v_u_25, (ref) v_u_27, (ref) v_u_5, (copy) p_u_449, (copy) p_u_450
			v_u_24.Tween(v_u_453, v_u_25.Tween.Fast, {
				["Color"] = v_u_27.Stroke,
				["Transparency"] = v_u_5.PadGet(p_u_449)[p_u_450] and 0.8 or 0.9
			})
		end)
		v_u_452.Activated:Connect(function()
			-- upvalues: (ref) v_u_203, (ref) v_u_206, (ref) v_u_406, (copy) p_u_449, (copy) p_u_450, (copy) v_u_452
			if not v_u_203 and os.clock() >= v_u_206 then
				v_u_406(p_u_449, p_u_450, v_u_452)
			end
		end)
		v_u_336[p_u_449] = v_u_336[p_u_449] or {}
		local v455 = v_u_336[p_u_449]
		table.insert(v455, v454)
		v_u_337[v_u_452] = v454
		local v_u_456 = v_u_5.PadGet(v454.id)[v454.slot]
		local v457 = v_u_24.SetCapPad
		local v458 = v454.cap
		local v459
		if v_u_456 then
			local v460
			v460, v459 = pcall(function()
				-- upvalues: (copy) v_u_456
				return Enum.KeyCode[v_u_456]
			end)
			if not v460 then
				v459 = nil
			end
		else
			v459 = nil
		end
		v457(v458, v459)
		v454.dash.Visible = v_u_456 == nil
		v454.button.BackgroundTransparency = v_u_456 and 0.35 or 0.72
		v454.stroke.Transparency = v_u_456 and 0.8 or 0.9
		return v454
	end
	local function v_u_493(p462, p463) -- name: padSection
		-- upvalues: (ref) v_u_336, (ref) v_u_337, (ref) v_u_168, (ref) v_u_5, (copy) v_u_24, (ref) v_u_338, (ref) v_u_203, (copy) v_u_210, (copy) v_u_29, (copy) v_u_365, (copy) v_u_372, (copy) v_u_57, (ref) v_u_48, (copy) v_u_27, (copy) v_u_102, (copy) v_u_461, (ref) v_u_167, (copy) v_u_28, (ref) v_u_22, (copy) v_u_355
		v_u_336 = {}
		v_u_337 = {}
		local v464 = v_u_168.kbHeader
		local v465 = #v_u_5.PAD_ACTIONS * v_u_168.rowH
		local v466 = v_u_168.desc + 22
		local v467 = v_u_24.new("Frame", {
			["Name"] = "CONTROLLER",
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, v464 + v_u_168.titleGap + v465 + v466),
			["LayoutOrder"] = p463,
			["Parent"] = p462
		})
		local v468 = v_u_168.title + 8
		v_u_24.SectionTitle("CONTROLLER", {
			["Position"] = UDim2.fromOffset(0, v464 - v468),
			["Size"] = UDim2.new(1, 0, 0, v468),
			["TextSize"] = v_u_168.title,
			["Parent"] = v467
		})
		local v469 = v_u_24.Compact and 214 or 186
		v_u_338 = v_u_24.Button({
			["Name"] = "ResetPad",
			["Text"] = "RESET TO DEFAULTS",
			["TextSize"] = nil,
			["Style"] = "Dark",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Radius"] = 9,
			["Parent"] = nil,
			["OnClick"] = nil,
			["TextSize"] = v_u_24.Compact and 16 or 14,
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(1, 0, 0, v464),
			["Size"] = UDim2.fromOffset(v469, v464 - 2),
			["Parent"] = v467,
			["OnClick"] = function() -- name: OnClick
				-- upvalues: (ref) v_u_203, (ref) v_u_210, (ref) v_u_5, (ref) v_u_29, (ref) v_u_365, (ref) v_u_372
				if v_u_203 then
					v_u_210()
				end
				local v470 = v_u_5.PadResetAll()
				if #v470 > 0 then
					v_u_29.SavePadBinds(v470)
					for _, v471 in v470 do
						v_u_365(v471)
					end
					v_u_372("EVERY BUTTON IS BACK TO ITS DEFAULT", nil)
				end
			end
		})
		v_u_57({ v_u_338.Instance })
		v_u_48[v_u_338.Instance] = v467
		local v472 = v_u_24.new("Frame", {
			["Name"] = "Card",
			["Position"] = UDim2.fromOffset(0, v464 + v_u_168.titleGap),
			["Size"] = UDim2.new(1, 0, 0, v465),
			["BackgroundColor3"] = v_u_27.PanelHi,
			["BackgroundTransparency"] = 0.3,
			v_u_24.Corner(12),
			v_u_24.Stroke(v_u_27.Stroke, 1, 0.92),
			v_u_24.List(Enum.FillDirection.Vertical, 0),
			["Parent"] = v467
		})
		local v473 = v_u_168.chipW * 2 + v_u_168.chipGap
		for v474, v475 in v_u_5.PAD_ACTIONS do
			local v476 = v_u_24.new("Frame", {
				["Name"] = v475.id,
				["Size"] = UDim2.new(1, 0, 0, v_u_168.rowH),
				["LayoutOrder"] = v474,
				["Parent"] = v472
			})
			if v474 > 1 then
				v_u_24.new("Frame", {
					["Name"] = "Divider",
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.93,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["BackgroundColor3"] = v_u_27.Stroke,
					["Position"] = UDim2.fromOffset(v_u_168.pad, 0),
					["Size"] = UDim2.new(1, -v_u_168.pad * 2, 0, 1),
					["Parent"] = v476
				})
			end
			local v477 = v_u_24.new("Frame", {
				["Name"] = "Highlight",
				["BackgroundColor3"] = v_u_27.White,
				["BackgroundTransparency"] = 1,
				["Position"] = UDim2.fromOffset(4, 4),
				["Size"] = UDim2.new(1, -8, 1, -8),
				v_u_24.Corner(9),
				["Parent"] = v476
			})
			v_u_102(v476, {
				["kind"] = "padbind",
				["label"] = nil,
				["desc"] = nil,
				["label"] = v475.label,
				["desc"] = v475.desc
			}, v473)
			local v478 = v_u_24.new("Frame", {
				["Name"] = "Buttons",
				["AnchorPoint"] = Vector2.new(1, 0.5),
				["Position"] = UDim2.new(1, -v_u_168.pad, 0.5, 0),
				["Size"] = UDim2.fromOffset(v473, v_u_168.chipH),
				v_u_24.List(Enum.FillDirection.Horizontal, v_u_168.chipGap, Enum.HorizontalAlignment.Right, Enum.VerticalAlignment.Center),
				["Parent"] = v476
			})
			local v479 = {}
			for v480 = 1, v475.max do
				local v481 = v_u_461(v478, v475.id, v480, v480)
				v_u_167[v481.button] = v477
				local v482 = v481.button
				table.insert(v479, v482)
			end
			v_u_57(v479, v479[#v479])
			if v474 ~= 1 then
				break
			end
			v_u_48[v479[#v479]] = v467
		end
		local v_u_483 = v_u_24.new("Frame", {
			["Name"] = "Legend",
			["Position"] = UDim2.fromOffset(v_u_168.pad, v464 + v_u_168.titleGap + v465 + 10),
			["Size"] = UDim2.new(1, -v_u_168.pad * 2, 0, v_u_168.desc + 6),
			v_u_24.List(Enum.FillDirection.Horizontal, 6, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
			["Parent"] = v467
		})
		local function v492(p484, p485, p486) -- name: legendText
			-- upvalues: (ref) v_u_24, (ref) v_u_28, (ref) v_u_168, (ref) v_u_27, (ref) v_u_22, (copy) v_u_483
			local v487 = v_u_24.new
			local v488 = "TextLabel"
			local v489 = {
				["Name"] = "T" .. p485,
				["Text"] = p484
			}
			local v490
			if p486 then
				v490 = v_u_28.Heavy
			else
				v490 = v_u_28.SemiBold
			end
			v489.FontFace = v490
			v489.TextSize = v_u_168.desc
			local v491
			if p486 then
				v491 = v_u_27.TextDim
			else
				v491 = v_u_22
			end
			v489.TextColor3 = v491
			v489.AutomaticSize = Enum.AutomaticSize.X
			v489.Size = UDim2.fromOffset(0, v_u_168.desc + 4)
			v489.LayoutOrder = p485
			v489.Parent = v_u_483
			v487(v488, v489)
		end
		v_u_24.PadCap(Enum.KeyCode.ButtonA, {
			["Height"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Height"] = v_u_168.desc + 6,
			["Parent"] = v_u_483
		})
		v492("CHANGE", 2, true)
		v492("  ", 3, false)
		v_u_24.PadCap(Enum.KeyCode.ButtonX, {
			["Height"] = nil,
			["LayoutOrder"] = 4,
			["Parent"] = nil,
			["Height"] = v_u_168.desc + 6,
			["Parent"] = v_u_483
		})
		v492("UNBIND", 5, true)
		v492("   \194\183   Menu buttons can\'t be changed", 6, false)
		v_u_355()
		return v467
	end
	v_u_5.PadChanged:Connect(v_u_355)
	local function v_u_496() -- name: updateFade
		-- upvalues: (ref) v_u_161, (ref) v_u_38
		local v494 = v_u_161
		local v495 = v_u_38
		if v494 and v495 then
			v495.Visible = v494.AbsoluteCanvasSize.Y - (v494.CanvasPosition.Y + v494.AbsoluteWindowSize.Y) > 2
		end
	end
	local function v_u_540() -- name: build
		-- upvalues: (copy) v_u_31, (ref) v_u_160, (ref) v_u_165, (ref) v_u_166, (ref) v_u_167, (ref) v_u_163, (ref) v_u_157, (ref) v_u_159, (ref) v_u_164, (ref) v_u_48, (ref) v_u_49, (ref) v_u_205, (copy) v_u_210, (ref) v_u_202, (ref) v_u_182, (ref) v_u_183, (ref) v_u_184, (ref) v_u_336, (ref) v_u_337, (ref) v_u_338, (ref) v_u_339, (ref) v_u_340, (ref) v_u_341, (ref) v_u_168, (copy) v_u_24, (ref) v_u_20, (ref) v_u_19, (ref) v_u_40, (copy) p_u_23, (ref) v_u_2, (ref) v_u_158, (ref) v_u_161, (ref) v_u_11, (copy) v_u_335, (copy) v_u_493, (copy) v_u_27, (copy) v_u_128, (copy) v_u_148, (copy) v_u_156, (ref) v_u_41, (ref) v_u_38, (copy) v_u_496, (copy) v_u_29, (ref) v_u_39, (copy) v_u_26, (ref) v_u_45, (copy) v_u_81, (copy) v_u_25, (copy) v_u_28, (ref) v_u_162
		for _, v497 in v_u_31:GetChildren() do
			if v497:IsA("UIPadding") then
				continue
			end
			v497:Destroy()
		end
		v_u_160 = {}
		v_u_165 = {}
		v_u_166 = {}
		v_u_167 = {}
		v_u_163 = nil
		v_u_157 = nil
		v_u_159 = nil
		v_u_164 = {}
		v_u_48 = {}
		v_u_49 = nil
		v_u_205 = nil
		v_u_210()
		if v_u_202 then
			v_u_202.layer:Destroy()
			v_u_202 = nil
		end
		v_u_182 = {}
		v_u_183 = nil
		v_u_184 = nil
		v_u_336 = {}
		v_u_337 = {}
		v_u_338 = nil
		v_u_339 = nil
		v_u_340 = nil
		v_u_341 = nil
		local v498
		if v_u_24.Compact then
			v498 = v_u_20
		else
			v498 = v_u_19
		end
		v_u_168 = v498
		local v499 = v_u_24.Compact and "c" or "d"
		local v500 = v_u_24.Touch
		if v500 then
			v500 = p_u_23.OpenTouchEditor ~= nil
		end
		local v501 = v500 and "t" or ""
		local v502 = not v_u_24.Touch and v_u_2.KeyboardEnabled
		if v502 then
			v502 = not v_u_24.Gamepad
		end
		v_u_40 = v499 .. v501 .. (v502 and "k" or "") .. ((v_u_24.Touch or (v_u_24.Gamepad or v_u_158)) and "a" or "") .. (v_u_24.Gamepad and "p" or "")
		local v503 = v_u_24.Touch
		if v503 then
			v503 = p_u_23.OpenTouchEditor ~= nil
		end
		local v504 = not v_u_24.Touch and v_u_2.KeyboardEnabled
		if v504 then
			v504 = not v_u_24.Gamepad
		end
		local v505 = v_u_24.Touch or (v_u_24.Gamepad or v_u_158)
		local v506 = v_u_168.footerTop + v_u_168.footerBtn
		local v507 = v_u_24.new("ScrollingFrame", {
			["Name"] = "Scroll",
			["Size"] = nil,
			["ScrollBarThickness"] = 5,
			["AutomaticCanvasSize"] = nil,
			["VerticalScrollBarInset"] = nil,
			["Selectable"] = false,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 14, 1, -(v506 + 14)),
			["AutomaticCanvasSize"] = Enum.AutomaticSize.None,
			["VerticalScrollBarInset"] = Enum.ScrollBarInset.None,
			["Parent"] = v_u_31
		})
		v_u_161 = v507
		local v508 = v_u_24.new("Frame", {
			["Name"] = "List",
			["Size"] = UDim2.new(1, -14, 1, 0),
			v_u_24.List(Enum.FillDirection.Vertical, v_u_168.sectionGap),
			["Parent"] = v507
		})
		local v509 = 0
		local v510 = 0
		for v511, v512 in v_u_11 do
			if v512.touchOnly and not v503 or (v512.keyboardOnly and not v504 or v512.staging and not p_u_23.ReplayNewPlayer) then
				continue
			end
			if v512.keybinds then
				v509 = v509 + v_u_335(v508, v511).Size.Y.Offset
				v510 = v510 + 1
			elseif v512.padbinds then
				if not v_u_24.Gamepad then
					continue
				end
				v509 = v509 + v_u_493(v508, v511).Size.Y.Offset
				v510 = v510 + 1
			else
				local v513 = v_u_24.Gamepad
				local v514 = {}
				for _, v515 in v512.items do
					if not v505 and v515.assistOnly or (not v513 and v515.padOnly or v513 and v515.notPad) then
						continue
					end
					table.insert(v514, v515)
				end
				local v516 = #v514 * v_u_168.rowH
				local v517 = v_u_168.title + 8
				local v518 = v_u_24.new("Frame", {
					["Name"] = v512.title,
					["Size"] = UDim2.new(1, 0, 0, v517 + v_u_168.titleGap + v516),
					["LayoutOrder"] = v511,
					["Parent"] = v508
				})
				v_u_24.SectionTitle(v512.title, {
					["Size"] = UDim2.new(1, 0, 0, v517),
					["TextSize"] = v_u_168.title,
					["Parent"] = v518
				})
				local v519 = v_u_24.new("Frame", {
					["Name"] = "Card",
					["Position"] = UDim2.fromOffset(0, v517 + v_u_168.titleGap),
					["Size"] = UDim2.new(1, 0, 0, v516),
					["BackgroundColor3"] = v_u_27.PanelHi,
					["BackgroundTransparency"] = 0.3,
					v_u_24.Corner(12),
					v_u_24.Stroke(v_u_27.Stroke, 1, 0.92),
					v_u_24.List(Enum.FillDirection.Vertical, 0),
					["Parent"] = v518
				})
				local v520 = #v_u_164
				for v521, v522 in v514 do
					if v522.kind == "slider" then
						v_u_128(v519, v521, v522)
					elseif v522.kind == "switch" then
						v_u_148(v519, v521, v522)
					else
						v_u_156(v519, v521, v522)
					end
				end
				local v523 = v_u_164[v520 + 1]
				if v523 then
					v_u_48[v523.land] = v518
				end
				v509 = v509 + v518.Size.Y.Offset
				v510 = v510 + 1
			end
		end
		local v524 = v510 - 1
		local v525 = v509 + (math.max(0, v524) * v_u_168.sectionGap + 4)
		v507.CanvasSize = UDim2.fromOffset(0, v525)
		v_u_41 = v525 + 92 + 14 + v506 + 18
		v_u_38 = v_u_24.new("Frame", {
			["Name"] = "Fade",
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 0, 1, -(v506 + 14)),
			["Size"] = UDim2.new(1, 0, 0, 36),
			["BackgroundColor3"] = v_u_27.PanelLo,
			["ZIndex"] = 4,
			["Visible"] = false,
			v_u_24.Gradient(Color3.new(1, 1, 1), Color3.new(1, 1, 1), 90, NumberSequence.new(1, 0.05)),
			["Parent"] = v_u_31
		})
		v507:GetPropertyChangedSignal("CanvasPosition"):Connect(v_u_496)
		v507:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(v_u_496)
		v507:GetPropertyChangedSignal("AbsoluteCanvasSize"):Connect(v_u_496)
		local v526 = v_u_24.new("Frame", {
			["Name"] = "Footer",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.fromScale(0, 1),
			["Size"] = UDim2.new(1, 0, 0, v506),
			["Parent"] = v_u_31
		})
		v_u_24.new("Frame", {
			["Name"] = "Divider",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.92,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_27.Stroke,
			["Size"] = UDim2.new(1, 0, 0, 1),
			["Parent"] = v526
		})
		local v_u_529 = v_u_24.Button({
			["Name"] = "Reset",
			["Text"] = "DEFAULTS",
			["TextSize"] = nil,
			["Style"] = "Dark",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["OnClick"] = nil,
			["TextSize"] = v_u_168.button,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.fromScale(0, 1),
			["Size"] = UDim2.fromOffset(v_u_24.Compact and 210 or 190, v_u_168.footerBtn),
			["Parent"] = v526,
			["OnClick"] = function() -- name: OnClick
				-- upvalues: (ref) v_u_29
				for v527, v528 in v_u_29.DEFAULTS do
					v_u_29.Set(v527, v528, true)
				end
			end
		})
		v_u_39 = v_u_24.Button({
			["Name"] = "LeaveMatch",
			["Text"] = "LEAVE MATCH",
			["TextSize"] = nil,
			["Style"] = "Danger",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = nil,
			["Parent"] = nil,
			["TextSize"] = v_u_168.button,
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.fromScale(1, 1),
			["Size"] = UDim2.fromOffset(v_u_24.Compact and 250 or 230, v_u_168.footerBtn),
			["Visible"] = v_u_26.InMatch(),
			["Parent"] = v526
		})
		v_u_45 = false
		v_u_39.Activated:Connect(v_u_81)
		v_u_49 = {
			["items"] = { v_u_529.Instance, v_u_39.Instance },
			["land"] = v_u_529.Instance
		}
		if v_u_24.Gamepad then
			local v530 = v_u_24.Compact and 36 or 32
			local v531 = v_u_24.new("Frame", {
				["Name"] = "PadNotice",
				["AnchorPoint"] = Vector2.new(0.5, 1),
				["Position"] = UDim2.new(0.5, 0, 1, -(v506 + 14 + 8)),
				["Size"] = UDim2.fromOffset(0, v530),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["BackgroundColor3"] = v_u_27.Void,
				["BackgroundTransparency"] = 0.1,
				["Visible"] = false,
				["ZIndex"] = 8,
				v_u_24.Corner(v_u_25.Radius.Pill),
				v_u_24.Stroke(v_u_27.Warning, 1, 0.55),
				v_u_24.Padding(0, 16, 0, 16),
				v_u_24.List(Enum.FillDirection.Horizontal, 8, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
				["Parent"] = v_u_31
			})
			v_u_340 = v_u_24.new("TextLabel", {
				["Name"] = "Text",
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = nil,
				["TextColor3"] = nil,
				["AutomaticSize"] = nil,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["ZIndex"] = 9,
				["Parent"] = nil,
				["FontFace"] = v_u_28.Heavy,
				["TextSize"] = v_u_24.Compact and 16 or 14,
				["TextColor3"] = v_u_27.Warning,
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["Size"] = UDim2.fromOffset(0, v530),
				["Parent"] = v531
			})
			v_u_341 = v_u_24.PadCap(Enum.KeyCode.ButtonA, {
				["Height"] = nil,
				["LayoutOrder"] = 2,
				["ZIndex"] = 9,
				["Parent"] = nil,
				["Height"] = v530 - 8,
				["Parent"] = v531
			})
			v_u_339 = v531
		end
		local function v534()
			-- upvalues: (copy) v_u_529, (ref) v_u_39
			local v532 = v_u_529.Instance
			local v533 = v_u_39.Instance
			v532.SelectionBehaviorLeft = Enum.SelectionBehavior.Stop
			v533.SelectionBehaviorRight = Enum.SelectionBehavior.Stop
			v532.SelectionBehaviorDown = Enum.SelectionBehavior.Stop
			v533.SelectionBehaviorDown = Enum.SelectionBehavior.Stop
		end
		pcall(v534)
		function p_u_23.Debug.leaveConfirm()
			-- upvalues: (ref) v_u_81, (ref) v_u_162
			v_u_81()
			local v535 = v_u_162
			local v536 = {}
			local v537
			if v535 then
				v537 = v535.layer.Visible
			else
				v537 = v535
			end
			v536.visible = v537
			if v535 then
				v535 = v535.body.Text
			end
			v536.body = v535
			return v536
		end
		for v538, v539 in v_u_160 do
			v539(v_u_29.Get(v538), true)
		end
	end
	local function v_u_551() -- name: resize
		-- upvalues: (copy) v_u_24, (ref) v_u_41, (ref) v_u_168, (copy) v_u_30, (copy) v_u_496
		local v541 = v_u_24.CanvasSize()
		local v542 = v541.Y - v_u_24.TopInset() - 12
		local v543 = v_u_41
		local v544 = math.min(v543, v542)
		local v545 = v_u_41
		local v546 = math.min(v545, 360)
		local v547 = math.max(v544, v546)
		local v548 = v_u_168.winW
		local v549 = v541.X - 24
		local v550 = math.min(v548, v549)
		v_u_30.Holder.Size = UDim2.fromOffset(v550, v547)
		v_u_30.Refit()
		task.defer(v_u_496)
	end
	local function v556() -- name: relayout
		-- upvalues: (copy) v_u_30, (copy) v_u_24, (copy) p_u_23, (ref) v_u_2, (ref) v_u_158, (ref) v_u_40, (copy) v_u_540, (copy) v_u_551
		if v_u_30.IsOpen then
			local v552 = v_u_24.Compact and "c" or "d"
			local v553 = v_u_24.Touch
			if v553 then
				v553 = p_u_23.OpenTouchEditor ~= nil
			end
			local v554 = v553 and "t" or ""
			local v555 = not v_u_24.Touch and v_u_2.KeyboardEnabled
			if v555 then
				v555 = not v_u_24.Gamepad
			end
			if v552 .. v554 .. (v555 and "k" or "") .. ((v_u_24.Touch or (v_u_24.Gamepad or v_u_158)) and "a" or "") .. (v_u_24.Gamepad and "p" or "") ~= v_u_40 then
				v_u_540()
			end
			v_u_551()
		end
	end
	v_u_24.ScaleChanged:Connect(v556)
	v_u_24.LayoutChanged:Connect(v556)
	v_u_24.TouchChanged:Connect(v556)
	v_u_24.TopInsetChanged:Connect(v556)
	v_u_24.GamepadChanged:Connect(function()
		-- upvalues: (copy) v_u_30, (ref) v_u_203, (copy) v_u_24, (copy) p_u_23, (ref) v_u_2, (ref) v_u_158, (ref) v_u_40, (copy) v_u_540, (copy) v_u_551
		if v_u_30.IsOpen and not v_u_203 then
			local v557 = v_u_24.Compact and "c" or "d"
			local v558 = v_u_24.Touch
			if v558 then
				v558 = p_u_23.OpenTouchEditor ~= nil
			end
			local v559 = v558 and "t" or ""
			local v560 = not v_u_24.Touch and v_u_2.KeyboardEnabled
			if v560 then
				v560 = not v_u_24.Gamepad
			end
			if v557 .. v559 .. (v560 and "k" or "") .. ((v_u_24.Touch or (v_u_24.Gamepad or v_u_158)) and "a" or "") .. (v_u_24.Gamepad and "p" or "") ~= v_u_40 then
				if not v_u_30.IsOpen then
					return
				end
				local v561 = v_u_24.Compact and "c" or "d"
				local v562 = v_u_24.Touch
				if v562 then
					v562 = p_u_23.OpenTouchEditor ~= nil
				end
				local v563 = v562 and "t" or ""
				local v564 = not v_u_24.Touch and v_u_2.KeyboardEnabled
				if v564 then
					v564 = not v_u_24.Gamepad
				end
				if v561 .. v563 .. (v564 and "k" or "") .. ((v_u_24.Touch or (v_u_24.Gamepad or v_u_158)) and "a" or "") .. (v_u_24.Gamepad and "p" or "") ~= v_u_40 then
					v_u_540()
				end
				v_u_551()
			end
		end
	end)
	v_u_29.Changed:Connect(function(p565, p566)
		-- upvalues: (ref) v_u_160, (copy) v_u_30, (ref) v_u_159
		local v567 = v_u_160[p565]
		if v567 then
			local v568 = not v_u_30.IsOpen
			if not v568 then
				if v_u_159 == nil then
					v568 = false
				else
					v568 = v_u_159.item.key == p565
				end
			end
			v567(p566, v568)
		end
	end)
	v_u_2.InputEnded:Connect(function(p569)
		-- upvalues: (ref) v_u_159, (ref) v_u_161, (copy) v_u_24, (copy) v_u_25
		if v_u_159 and (p569.UserInputType == Enum.UserInputType.MouseButton1 or p569.UserInputType == Enum.UserInputType.Touch) then
			local v570 = v_u_159
			if not v570 then
				return
			end
			v_u_159 = nil
			if v_u_161 then
				v_u_161.ScrollingEnabled = true
			end
			v_u_24.Tween(v_u_24.GetScaleObj(v570.knob), v_u_25.Tween.PopSmall, {
				["Scale"] = 1
			})
		end
	end)
	v_u_3.RenderStepped:Connect(function()
		-- upvalues: (ref) v_u_159, (copy) v_u_30, (ref) v_u_161, (copy) v_u_24, (copy) v_u_25, (copy) v_u_29, (copy) v_u_96
		local v571 = v_u_159
		if v571 then
			if v_u_30.IsOpen then
				local v572 = v571.item.key
				local v573 = v_u_29.RANGES[v572]
				local v574 = v_u_24.PointerAbs().X - v571.track.AbsolutePosition.X
				local v575 = v571.track.AbsoluteSize.X
				local v576 = v574 / math.max(1, v575)
				local v577 = math.clamp(v576, 0, 1)
				local v578 = v573[1] + v577 * (v573[2] - v573[1])
				if v571.item.round then
					local v579 = v578 + 0.5
					v578 = math.floor(v579)
				end
				if v578 ~= v_u_29.Get(v572) then
					v_u_29.Set(v572, v578, true)
					v_u_96(v577)
				end
				return
			else
				local v580 = v_u_159
				if v580 then
					v_u_159 = nil
					if v_u_161 then
						v_u_161.ScrollingEnabled = true
					end
					v_u_24.Tween(v_u_24.GetScaleObj(v580.knob), v_u_25.Tween.PopSmall, {
						["Scale"] = 1
					})
				end
			end
		else
			return
		end
	end)
	local v_u_581 = {
		["token"] = 0,
		["dir"] = 0,
		["source"] = nil,
		["steps"] = 0
	}
	local function v_u_596(p_u_582, p583) -- name: startNudge
		-- upvalues: (ref) v_u_4, (ref) v_u_166, (copy) v_u_30, (ref) v_u_203, (copy) v_u_581, (copy) v_u_177, (copy) v_u_29
		local v_u_584 = v_u_4.SelectedObject
		local v_u_585
		if v_u_584 then
			v_u_585 = v_u_166[v_u_584]
		else
			v_u_585 = v_u_584
		end
		if not v_u_585 or (not v_u_30.IsOpen or v_u_203) then
			return false
		end
		if v_u_581.dir == p_u_582 and v_u_581.source == p583 then
			return true
		end
		local v586 = v_u_581
		v586.token = v586.token + 1
		local v_u_587 = v_u_581.token
		local v588 = v_u_581
		v_u_581.dir = p_u_582
		v588.source = p583
		local v_u_589 = v_u_585.key
		local v_u_590 = v_u_585.step or 0.05
		v_u_177(v_u_585, v_u_29.Get(v_u_589) + p_u_582 * v_u_590)
		local v591 = v_u_581
		v591.steps = v591.steps + 1
		task.spawn(function()
			-- upvalues: (copy) v_u_587, (ref) v_u_581, (ref) v_u_30, (ref) v_u_4, (copy) v_u_584, (ref) v_u_177, (copy) v_u_585, (ref) v_u_29, (copy) v_u_589, (copy) p_u_582, (copy) v_u_590
			task.wait(0.35)
			local v592 = os.clock()
			while v_u_587 == v_u_581.token and (v_u_30.IsOpen and v_u_4.SelectedObject == v_u_584) do
				v_u_177(v_u_585, v_u_29.Get(v_u_589) + p_u_582 * v_u_590)
				local v593 = v_u_581
				v593.steps = v593.steps + 1
				local v594 = (os.clock() - v592) / 1
				local v595 = math.clamp(v594, 0, 1)
				task.wait(v595 * -0.06 + 0.09)
			end
		end)
		return true
	end
	v_u_5.OnInput("Began", function(p597)
		-- upvalues: (copy) v_u_30, (copy) v_u_596
		local v598 = p597.KeyCode == Enum.KeyCode.DPadLeft and -1 or (p597.KeyCode == Enum.KeyCode.DPadRight and 1 or 0)
		if v598 ~= 0 and v_u_30.IsOpen then
			v_u_596(v598, "dpad")
		end
	end)
	v_u_5.OnInput("Ended", function(p599)
		-- upvalues: (copy) v_u_581
		if p599.KeyCode == Enum.KeyCode.DPadLeft or p599.KeyCode == Enum.KeyCode.DPadRight then
			if v_u_581.source == "dpad" then
				local v600 = v_u_581
				v600.token = v600.token + 1
				local v601 = v_u_581
				v_u_581.dir = 0
				v601.source = nil
				return
			end
		elseif p599.KeyCode == Enum.KeyCode.Thumbstick1 and v_u_581.source == "stick" then
			local v602 = v_u_581
			v602.token = v602.token + 1
			local v603 = v_u_581
			v_u_581.dir = 0
			v603.source = nil
		end
	end)
	v_u_5.OnInput("Changed", function(p604)
		-- upvalues: (copy) v_u_30, (copy) v_u_596, (copy) v_u_581
		if p604.KeyCode == Enum.KeyCode.Thumbstick1 then
			local v605 = p604.Position.X
			local v606 = p604.Position.Y
			local v607 = math.abs(v605)
			if v607 >= 0.5 and math.abs(v606) < v607 then
				if not (v_u_30.IsOpen and v_u_596(v605 > 0 and 1 or -1, "stick")) and v_u_581.source == "stick" then
					local v608 = v_u_581
					v608.token = v608.token + 1
					local v609 = v_u_581
					v_u_581.dir = 0
					v609.source = nil
					return
				end
			elseif (v607 < 0.35 or v607 < math.abs(v606)) and v_u_581.source == "stick" then
				local v610 = v_u_581
				v610.token = v610.token + 1
				local v611 = v_u_581
				v_u_581.dir = 0
				v611.source = nil
			end
		end
	end)
	local function v_u_613(p612) -- name: navUsable
		if not (p612 and (p612.Parent and p612.Selectable)) then
			return false
		end
		while p612 and not p612:IsA("LayerCollector") do
			if p612:IsA("GuiObject") and not p612.Visible then
				return false
			end
			p612 = p612.Parent
		end
		return p612 ~= nil
	end
	local function v_u_623() -- name: navChain
		-- upvalues: (copy) v_u_613, (copy) v_u_30, (ref) v_u_164, (ref) v_u_49
		local v_u_614 = {}
		local function v621(p615) -- name: add
			-- upvalues: (ref) v_u_613, (copy) v_u_614
			local v616 = {}
			for _, v617 in p615.items do
				if not v_u_613(v617) then
					continue
				end
				table.insert(v616, v617)
			end
			if #v616 > 0 then
				local v618 = v_u_614
				local v619 = {
					["items"] = v616
				}
				local v620
				if table.find(v616, p615.land) then
					v620 = p615.land
				else
					v620 = v616[#v616]
				end
				v619.land = v620
				table.insert(v618, v619)
			end
		end
		v621({
			["items"] = { v_u_30.CloseButton },
			["land"] = v_u_30.CloseButton
		})
		for _, v622 in v_u_164 do
			v621(v622)
		end
		if v_u_49 then
			v621(v_u_49)
		end
		return v_u_614
	end
	local function v_u_634(p_u_624) -- name: wireNav
		-- upvalues: (copy) v_u_623
		local v625 = v_u_623()
		for v626, v_u_627 in v625 do
			local v_u_628 = table.find(v_u_627.items, p_u_624)
			if not v_u_628 then
				continue
			end
			local v_u_629 = v625[v626 - 1]
			local v_u_630 = v625[v626 + 1]
			pcall(function()
				-- upvalues: (copy) p_u_624, (copy) v_u_629, (copy) v_u_630, (copy) v_u_627, (copy) v_u_628
				local v631 = p_u_624
				local v632
				if v_u_629 then
					v632 = v_u_629.land
				else
					v632 = nil
				end
				v631.NextSelectionUp = v632
				local v633
				if v_u_630 then
					v633 = v_u_630.land
				else
					v633 = nil
				end
				v631.NextSelectionDown = v633
				v631.NextSelectionLeft = v_u_627.items[v_u_628 - 1]
				v631.NextSelectionRight = v_u_627.items[v_u_628 + 1]
			end)
			return true
		end
		return false
	end
	local function v_u_649(p635) -- name: revealSelected
		-- upvalues: (ref) v_u_161, (copy) v_u_24, (ref) v_u_48, (copy) v_u_25
		local v636 = v_u_161
		if v636 and p635:IsDescendantOf(v636) then
			local v637 = v636.AbsoluteWindowSize.Y
			local v638
			if p635.Size.Y.Offset > 0 and p635.Size.Y.Scale == 0 then
				v638 = p635.AbsoluteSize.Y / p635.Size.Y.Offset
			else
				v638 = v_u_24.Scale
			end
			local v639 = p635.AbsolutePosition.Y - v636.AbsolutePosition.Y
			local v640 = v639 + p635.AbsoluteSize.Y
			local v641 = v_u_48[p635]
			if v641 then
				local v642 = v641.AbsolutePosition.Y - v636.AbsolutePosition.Y
				v639 = math.min(v639, v642)
			end
			local v643 = v636.CanvasPosition.Y
			local v644
			if v639 < 6 * v638 then
				v644 = v643 + v639 - 6 * v638
			elseif v637 - 48 * v638 < v640 then
				v644 = v643 + v640 - (v637 - 48 * v638)
			else
				v644 = v643
			end
			local v645 = v636.AbsoluteCanvasSize.Y - v637
			local v646 = math.max(0, v645)
			local v647 = math.clamp(v644, 0, v646)
			local v648 = v647 - v643
			if math.abs(v648) > 1 then
				v_u_24.Tween(v636, v_u_25.Tween.Fast, {
					["CanvasPosition"] = Vector2.new(0, v647)
				})
			end
		end
	end
	v_u_4:GetPropertyChangedSignal("SelectedObject"):Connect(function()
		-- upvalues: (ref) v_u_4, (ref) v_u_167, (ref) v_u_157, (copy) v_u_24, (copy) v_u_25, (copy) v_u_30, (copy) v_u_634, (copy) v_u_649
		local v650 = v_u_4.SelectedObject
		local v651
		if v650 then
			v651 = v_u_167[v650]
		else
			v651 = v650
		end
		if v_u_157 and v_u_157 ~= v651 then
			local v652 = v_u_157
			v_u_24.Tween(v652, v_u_25.Tween.Fast, {
				["BackgroundTransparency"] = 1
			})
		end
		v_u_157 = v651
		if v651 then
			v_u_24.Tween(v651, v_u_25.Tween.Fast, {
				["BackgroundTransparency"] = 0.94
			})
		end
		if v650 and (v_u_30.IsOpen and v650:IsDescendantOf(v_u_30.Root)) then
			v_u_634(v650)
			v_u_649(v650)
		end
	end)
	v_u_26.PlayerStateChanged:Connect(function()
		-- upvalues: (ref) v_u_39, (copy) v_u_26
		if v_u_39 then
			v_u_39.Instance.Visible = v_u_26.InMatch()
		end
	end)
	function p_u_23.Debug.aimAssistRow(p653, p654)
		-- upvalues: (ref) v_u_165, (ref) v_u_158, (copy) v_u_30, (copy) v_u_24, (copy) p_u_23, (ref) v_u_2, (ref) v_u_40, (copy) v_u_540, (copy) v_u_551, (copy) v_u_31, (copy) v_u_29
		if p653 == "flip" then
			local v655 = v_u_165.aimAssist
			if v655 then
				v655()
			end
		elseif p653 == "show" then
			v_u_158 = p654 == true
			if v_u_30.IsOpen then
				local v656 = v_u_24.Compact and "c" or "d"
				local v657 = v_u_24.Touch
				if v657 then
					v657 = p_u_23.OpenTouchEditor ~= nil
				end
				local v658 = v657 and "t" or ""
				local v659 = not v_u_24.Touch and v_u_2.KeyboardEnabled
				if v659 then
					v659 = not v_u_24.Gamepad
				end
				if v656 .. v658 .. (v659 and "k" or "") .. ((v_u_24.Touch or (v_u_24.Gamepad or v_u_158)) and "a" or "") .. (v_u_24.Gamepad and "p" or "") ~= v_u_40 then
					v_u_540()
				end
				v_u_551()
			end
		end
		local v660 = v_u_31:FindFirstChild("aimAssist", true)
		local v661
		if v660 and (v660:IsA("GuiObject") and v_u_30.IsOpen) then
			local v662 = v660
			v661 = true
			while v660 and v660 ~= v_u_31 do
				if v660:IsA("GuiObject") and not v660.Visible then
					v661 = false
				end
				v660 = v660.Parent
			end
			v660 = v662
		else
			v661 = false
		end
		local v663 = game:GetService("ReplicatedStorage").Shared:FindFirstChild("Camera")
		local v664 = require
		local v665, v666 = pcall(v664, v663)
		local v667
		if v665 and type(v666) == "table" then
			local v668 = v666.GetAimAssistEnabled
			if type(v668) == "function" then
				v667 = v666.GetAimAssistEnabled()
			else
				v667 = nil
			end
		else
			v667 = nil
		end
		return {
			["shown"] = v661,
			["row"] = v660 ~= nil,
			["value"] = v_u_29.Get("aimAssist"),
			["camera"] = v667,
			["touch"] = v_u_24.Touch
		}
	end
	function p_u_23.Debug.keybinds(p669, p670, p671)
		-- upvalues: (copy) v_u_278, (copy) v_u_210, (ref) v_u_5, (copy) v_u_29, (ref) v_u_202, (ref) v_u_203, (ref) v_u_184, (ref) v_u_182
		if p669 == "capture" and type(p670) == "string" then
			v_u_278(p670, p671 or 1)
		elseif p669 == "cancel" then
			v_u_210()
		elseif p669 == "reset" then
			local v672 = v_u_5.ResetAll()
			v_u_29.SaveKeybinds(v672)
			return v672
		end
		local v673 = {}
		for _, v674 in v_u_5.ACTIONS do
			v673[v674.id] = table.concat(v_u_5.Get(v674.id), ",")
		end
		local v675 = v_u_202
		local v676
		if v_u_203 then
			v676 = v_u_203.id .. "#" .. v_u_203.slot
		else
			v676 = false
		end
		v673._capturing = v676
		local v677
		if v675 == nil then
			v677 = false
		else
			v677 = v675.layer.Visible
		end
		v673._card = v677
		local v678
		if v675 then
			v678 = v675.line1.Text
		else
			v678 = nil
		end
		v673._pad = v678
		local v679
		if v675 == nil then
			v679 = false
		else
			v679 = v675.box:IsFocused()
		end
		v673._focus = v679
		local v680
		if v_u_184 then
			v680 = v_u_184.Text
		else
			v680 = nil
		end
		v673._notice = v680
		v673._section = next(v_u_182) ~= nil
		return v673
	end
	function p_u_23.Debug.padSettings(p681, p682, p683)
		-- upvalues: (ref) v_u_336, (ref) v_u_4, (ref) v_u_161, (copy) v_u_406, (ref) v_u_338, (ref) v_u_5, (copy) v_u_29, (copy) v_u_355, (copy) v_u_30, (copy) v_u_24, (ref) v_u_337, (ref) v_u_166, (copy) v_u_581, (copy) v_u_623, (ref) v_u_202, (ref) v_u_203, (ref) v_u_339, (ref) v_u_340, (copy) p_u_23
		if p681 == "select" and type(p682) == "string" then
			local v684 = v_u_336[p682]
			if v684 then
				local v685 = #v684
				v684 = v684[math.clamp(p683 or 1, 1, v685)]
			end
			if v684 then
				v_u_4.SelectedObject = v684.button
			end
		elseif p681 == "row" and type(p682) == "string" then
			local v686 = v_u_161
			if v686 then
				v686 = v_u_161:FindFirstChild(p682, true)
			end
			if v686 and v686:IsA("GuiObject") then
				v_u_4.SelectedObject = v686
			end
		elseif p681 == "nav" and type(p682) == "string" then
			local v687 = v_u_4.SelectedObject
			if v687 then
				v687 = v687["NextSelection" .. p682]
			end
			if v687 then
				v_u_4.SelectedObject = v687
			end
		elseif p681 == "capture" and type(p682) == "string" then
			local v688 = v_u_336[p682]
			if v688 then
				local v689 = #v688
				local v690 = math.max(1, v689)
				v688 = v688[math.clamp(p683 or 1, 1, v690)]
			end
			local v691 = v_u_406
			local v692 = p683 or 1
			if v688 then
				v688 = v688.button
			end
			v691(p682, v692, v688)
		elseif p681 == "reset" and v_u_338 then
			local v693 = v_u_5.PadResetAll()
			v_u_29.SavePadBinds(v693)
			v_u_355()
		end
		local v694 = v_u_4.SelectedObject
		local v695 = {
			["open"] = v_u_30.IsOpen,
			["gamepad"] = v_u_24.Gamepad
		}
		local v696
		if v694 then
			local v697 = v_u_337[v694]
			if v697 then
				v696 = "chip:" .. v697.id .. "#" .. v697.slot
			else
				v696 = v694.Name
			end
		else
			v696 = nil
		end
		v695.selected = v696 or false
		local v698
		if v694 then
			v698 = v_u_166[v694]
		else
			v698 = v694
		end
		v695.slider = v698 and {
			["key"] = v698.key,
			["value"] = v_u_29.Get(v698.key)
		} or false
		v695.nudgeSteps = v_u_581.steps
		local v699 = {}
		for _, v700 in v_u_623() do
			local v701 = {}
			for _, v702 in v700.items do
				local v703
				if v702 then
					local v704 = v_u_337[v702]
					if v704 then
						v703 = "chip:" .. v704.id .. "#" .. v704.slot
					else
						v703 = v702.Name
					end
				else
					v703 = nil
				end
				table.insert(v701, v703)
			end
			local v705 = table.concat
			table.insert(v699, v705(v701, "|"))
		end
		v695.chain = v699
		if v_u_161 then
			local v706 = v_u_161.CanvasPosition.Y + 0.5
			v695.canvasY = math.floor(v706)
			local v707 = v_u_161.AbsoluteWindowSize.Y + 0.5
			v695.view = math.floor(v707)
			local v708 = v_u_161.AbsoluteCanvasSize.Y + 0.5
			v695.canvasH = math.floor(v708)
			if v694 and v694:IsDescendantOf(v_u_161) then
				local v709 = v694.AbsolutePosition.Y - v_u_161.AbsolutePosition.Y
				local v710 = v709 + 0.5
				local v711 = math.floor(v710)
				local v712 = v709 + v694.AbsoluteSize.Y + 0.5
				local v713 = math.floor(v712)
				v695.selTop = v711
				v695.selBottom = v713
			end
		end
		local v714 = v_u_202
		local v715
		if v_u_203 then
			v715 = v_u_203.id .. "#" .. v_u_203.slot .. (v_u_203.pad and " pad" or " kb")
		else
			v715 = false
		end
		v695._capturing = v715
		local v716
		if v714 == nil then
			v716 = false
		else
			v716 = v714.layer.Visible
		end
		v695._card = v716
		local v717
		if v714 then
			v717 = v714.line1.Text
		else
			v717 = nil
		end
		v695._pad = v717
		local v718
		if v714 then
			v718 = v714.holdHint.Visible and "hold B to cancel" or v714.line2.Text
		else
			v718 = nil
		end
		v695._hint = v718
		local v719
		if v_u_339 and (v_u_339.Visible and v_u_340) then
			v719 = v_u_340.Text
		else
			v719 = false
		end
		v695._notice = v719
		v695._section = next(v_u_336) ~= nil
		local v720
		if v_u_338 then
			v720 = v_u_338.Instance.Selectable
		else
			v720 = nil
		end
		v695._resetEnabled = v720
		v695._padCapturing = p_u_23.PadCapturing == true
		local v721 = {}
		for v722, v723 in v_u_336 do
			local v724 = {}
			for _, v725 in v723 do
				local v726 = v725.cap:FindFirstChild("Glyph")
				local v727 = v725.dash.Visible and "-" or (v726 and v726.Visible and "img" or v725.cap:FindFirstChild("Key").Text)
				table.insert(v724, v727)
			end
			v721[v722] = table.concat(v_u_5.PadGet(v722), ",") .. " [" .. table.concat(v724, ",") .. "]"
		end
		v695.rows = v721
		return v695
	end
	local v739 = {
		["open"] = function() -- name: open
			-- upvalues: (copy) v_u_24, (copy) p_u_23, (ref) v_u_2, (ref) v_u_158, (ref) v_u_40, (copy) v_u_540, (ref) v_u_160, (copy) v_u_29, (ref) v_u_39, (copy) v_u_26, (ref) v_u_162, (ref) v_u_45, (ref) v_u_46, (ref) v_u_161, (copy) v_u_551, (copy) v_u_30, (ref) v_u_163, (ref) v_u_4
			local v728 = v_u_24.Compact and "c" or "d"
			local v729 = v_u_24.Touch
			if v729 then
				v729 = p_u_23.OpenTouchEditor ~= nil
			end
			local v730 = v729 and "t" or ""
			local v731 = not v_u_24.Touch and v_u_2.KeyboardEnabled
			if v731 then
				v731 = not v_u_24.Gamepad
			end
			if v728 .. v730 .. (v731 and "k" or "") .. ((v_u_24.Touch or (v_u_24.Gamepad or v_u_158)) and "a" or "") .. (v_u_24.Gamepad and "p" or "") ~= v_u_40 then
				v_u_540()
			end
			for v732, v733 in v_u_160 do
				v733(v_u_29.Get(v732), true)
			end
			v_u_39.Instance.Visible = v_u_26.InMatch()
			if v_u_162 then
				v_u_162.layer.Visible = false
			end
			v_u_45 = false
			v_u_46 = v_u_46 + 1
			v_u_39:SetText("LEAVE MATCH")
			if v_u_161 then
				v_u_161.CanvasPosition = Vector2.zero
			end
			v_u_551()
			v_u_30:Open()
			if v_u_163 and v_u_24.Gamepad then
				v_u_4.SelectedObject = v_u_163
			end
		end,
		["close"] = function(p734) -- name: close
			-- upvalues: (ref) v_u_162, (copy) v_u_210, (ref) v_u_205, (copy) v_u_581, (ref) v_u_159, (ref) v_u_161, (copy) v_u_24, (copy) v_u_25, (ref) v_u_4, (copy) v_u_30
			if v_u_162 then
				v_u_162.layer.Visible = false
			end
			v_u_210()
			v_u_205 = nil
			local v735 = v_u_581
			v735.token = v735.token + 1
			local v736 = v_u_581
			v_u_581.dir = 0
			v736.source = nil
			local v737 = v_u_159
			if v737 then
				v_u_159 = nil
				if v_u_161 then
					v_u_161.ScrollingEnabled = true
				end
				v_u_24.Tween(v_u_24.GetScaleObj(v737.knob), v_u_25.Tween.PopSmall, {
					["Scale"] = 1
				})
			end
			local v738 = v_u_4.SelectedObject
			if v738 and v738:IsDescendantOf(v_u_30.Root) then
				v_u_4.SelectedObject = nil
			end
			v_u_30:Close(p734)
		end,
		["select"] = function() -- name: select
			-- upvalues: (ref) v_u_203, (ref) v_u_205, (copy) v_u_613, (ref) v_u_163
			if v_u_203 and v_u_203.pad then
				return nil
			elseif v_u_205 and v_u_613(v_u_205) then
				return v_u_205
			else
				return v_u_163
			end
		end,
		["back"] = function() -- name: back
			-- upvalues: (ref) v_u_203, (copy) v_u_210, (ref) v_u_162, (ref) v_u_39, (copy) v_u_24, (ref) v_u_4
			if v_u_203 then
				if not v_u_203.pad then
					v_u_210()
				end
				return true
			end
			if not (v_u_162 and v_u_162.layer.Visible) then
				return false
			end
			if v_u_162 then
				v_u_162.layer.Visible = false
			end
			if v_u_39 and v_u_24.Gamepad then
				v_u_4.SelectedObject = v_u_39.Instance
			end
			return true
		end
	}
	p_u_23.MenuManager.Register("Settings", v739)
end
return v6