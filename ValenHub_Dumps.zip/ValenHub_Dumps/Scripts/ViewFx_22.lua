local v1 = {}
local v_u_2 = {
	["flash"] = "rbxassetid://132385497945381",
	["side"] = "rbxassetid://133080098550406",
	["smoke"] = "rbxassetid://136705730872514",
	["spark"] = "rbxassetid://106505437894279",
	["star"] = "rbxassetid://121298090783218",
	["ring"] = "rbxassetid://99127423363509",
	["glow"] = "rbxassetid://120877893267841",
	["dust"] = "rbxassetid://131207259844964",
	["swoosh"] = "rbxassetid://91777724554771",
	["ember"] = "rbxassetid://112265693545203"
}
local v_u_3 = {
	["flash"] = true,
	["smoke"] = true,
	["dust"] = true
}
v1.TEX = v_u_2
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = {}
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = 0
local v_u_10 = 0
local v_u_11 = false
local v_u_12 = false
local v_u_13 = nil
local v_u_14 = 0
local v_u_15 = false
local function v_u_22(...) -- name: seq
	local v16 = { ... }
	local v17 = {}
	for v18 = 1, #v16, 2 do
		local v19 = NumberSequenceKeypoint.new
		local v20 = v16[v18]
		local v21 = v16[v18 + 1]
		table.insert(v17, v19(v20, v21))
	end
	return NumberSequence.new(v17)
end
local function v_u_34(p23, p24, p25) -- name: emitter
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (ref) v_u_15, (copy) v_u_6
	local v26 = Instance.new("Attachment")
	v26.Name = p24
	v26.Parent = p23
	local v27 = Instance.new("ParticleEmitter")
	v27.Name = p24
	v27.Enabled = false
	v27.LockedToPart = true
	v27.LightInfluence = 0
	v27.LightEmission = 0.4
	v27.Speed = NumberRange.new(0)
	v27.Rate = 0
	for v28, v29 in p25 do
		v27[v28] = v29
	end
	local v30 = p25.Texture
	if type(v30) == "string" then
		for v31, v32 in v_u_2 do
			if v32 ~= v30 or (not v_u_3[v31] or string.find(v32, "rbxasset://", 1, true)) then
				continue
			end
			v27.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid2x2
			v27.FlipbookMode = Enum.ParticleFlipbookMode.Random
		end
	end
	v27.Parent = v26
	if v_u_15 then
		v27.TimeScale = 0.01
	end
	local v33 = {
		["att"] = v26,
		["e"] = v27
	}
	v_u_6[p24] = v33
	return v33
end
Color3.fromRGB(255, 196, 120)
local v_u_35 = Color3.fromRGB(255, 150, 70)
local function v_u_135() -- name: build
	-- upvalues: (ref) v_u_5, (copy) v_u_34, (copy) v_u_2, (copy) v_u_22, (copy) v_u_35, (ref) v_u_13, (ref) v_u_8, (ref) v_u_7
	local v36 = Instance.new("Part")
	v36.Name = "TribesViewFx"
	v36.Anchored = true
	v36.CanCollide = false
	v36.CanQuery = false
	v36.CanTouch = false
	v36.CastShadow = false
	v36.Transparency = 1
	v36.Size = Vector3.new(0.05, 0.05, 0.05)
	local v37 = Instance.new("Part")
	v37.Name = "TribesViewMuzzle"
	v37.Anchored = true
	v37.CanCollide = false
	v37.CanQuery = false
	v37.CanTouch = false
	v37.CastShadow = false
	v37.Transparency = 1
	v37.Size = Vector3.new(0.05, 0.05, 0.05)
	v_u_5 = v37
	local v38 = v_u_34
	local v39 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0.28,
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["ZOffset"] = 0.3,
		["Texture"] = v_u_2.flash
	}
	local v40 = Color3.fromRGB(255, 186, 92)
	local v41 = Color3.fromRGB(214, 96, 36)
	v39.Color = ColorSequence.new(v40, v41 or v40)
	v39.Size = v_u_22(0, 0.07, 0.35, 0.14, 1, 0.1)
	v39.Transparency = v_u_22(0, 0.05, 0.6, 0.35, 1, 1)
	v39.Lifetime = NumberRange.new(0.05, 0.065)
	v39.Rotation = NumberRange.new(0, 360)
	v38(v37, "flash", v39)
	local v42 = v_u_34
	local v43 = {
		["Texture"] = nil,
		["Color"] = nil,
		["Orientation"] = nil,
		["Speed"] = nil,
		["Size"] = nil,
		["Squash"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["ZOffset"] = 0.25,
		["Texture"] = v_u_2.side
	}
	local v44 = Color3.fromRGB(255, 170, 80)
	local v45 = Color3.fromRGB(200, 80, 30)
	v43.Color = ColorSequence.new(v44, v45 or v44)
	v43.Orientation = Enum.ParticleOrientation.VelocityParallel
	v43.Speed = NumberRange.new(0.6)
	v43.Size = v_u_22(0, 0.05, 0.4, 0.1, 1, 0.07)
	v43.Squash = v_u_22(0, 1.2, 1, 1)
	v43.Transparency = v_u_22(0, 0.1, 0.6, 0.4, 1, 1)
	v43.Lifetime = NumberRange.new(0.045, 0.06)
	v43.Rotation = NumberRange.new(90)
	v42(v37, "tongue", v43)
	local v46 = v_u_34
	local v47 = {
		["Texture"] = nil,
		["Color"] = nil,
		["Orientation"] = nil,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Drag"] = 6,
		["Acceleration"] = Vector3.new(0, -1.5, 0),
		["Size"] = nil,
		["Squash"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["ZOffset"] = 0.2,
		["Texture"] = v_u_2.spark
	}
	local v48 = Color3.fromRGB(255, 210, 130)
	local v49 = v_u_35
	v47.Color = ColorSequence.new(v48, v49 or v48)
	v47.Orientation = Enum.ParticleOrientation.VelocityParallel
	v47.Speed = NumberRange.new(2.2, 4.5)
	v47.SpreadAngle = Vector2.new(14, 14)
	v47.Size = v_u_22(0, 0.016, 1, 0.004)
	v47.Squash = v_u_22(0, 2, 1, 1)
	v47.Transparency = v_u_22(0, 0.05, 1, 1)
	v47.Lifetime = NumberRange.new(0.08, 0.2)
	v47.Rotation = NumberRange.new(90)
	v46(v37, "sparks", v47)
	local v50 = v_u_34
	local v51 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0,
		["LightInfluence"] = 0.6,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Drag"] = 2.6,
		["Acceleration"] = Vector3.new(0, 0.12, 0),
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["RotSpeed"] = nil,
		["ZOffset"] = 0.1,
		["Texture"] = v_u_2.smoke
	}
	local v52 = Color3.fromRGB(150, 146, 140)
	local v53 = Color3.fromRGB(122, 118, 114)
	v51.Color = ColorSequence.new(v52, v53 or v52)
	v51.Speed = NumberRange.new(0.35, 0.8)
	v51.SpreadAngle = Vector2.new(18, 18)
	v51.Size = v_u_22(0, 0.05, 0.3, 0.14, 1, 0.26)
	v51.Transparency = v_u_22(0, 0.45, 0.25, 0.55, 1, 1)
	v51.Lifetime = NumberRange.new(0.6, 1)
	v51.Rotation = NumberRange.new(0, 360)
	v51.RotSpeed = NumberRange.new(-50, 50)
	v50(v36, "smoke", v51)
	local v54 = v_u_34
	local v55 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0,
		["LightInfluence"] = 0.6,
		["Speed"] = nil,
		["Acceleration"] = Vector3.new(0, 0.22, 0),
		["Drag"] = 1,
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["RotSpeed"] = nil,
		["Rate"] = 22,
		["Texture"] = v_u_2.smoke
	}
	local v56, v57 = Color3.fromRGB(150, 146, 140)
	v55.Color = ColorSequence.new(v56, v57 or v56)
	v55.Speed = NumberRange.new(0.05, 0.12)
	v55.Size = v_u_22(0, 0.02, 1, 0.09)
	v55.Transparency = v_u_22(0, 0.55, 0.4, 0.7, 1, 1)
	v55.Lifetime = NumberRange.new(0.5, 0.9)
	v55.Rotation = NumberRange.new(0, 360)
	v55.RotSpeed = NumberRange.new(-40, 40)
	v54(v36, "wisp", v55)
	local v58 = v_u_34
	local v59 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0.2,
		["Orientation"] = nil,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Drag"] = 8,
		["Size"] = nil,
		["Squash"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["Texture"] = v_u_2.spark
	}
	local v60, v61 = Color3.fromRGB(240, 232, 214)
	v59.Color = ColorSequence.new(v60, v61 or v60)
	v59.Orientation = Enum.ParticleOrientation.VelocityParallel
	v59.Speed = NumberRange.new(2.5, 4)
	v59.SpreadAngle = Vector2.new(4, 4)
	v59.Size = v_u_22(0, 0.012, 1, 0.002)
	v59.Squash = v_u_22(0, 2.5, 1, 1)
	v59.Transparency = v_u_22(0, 0.3, 1, 1)
	v59.Lifetime = NumberRange.new(0.06, 0.1)
	v59.Rotation = NumberRange.new(90)
	v58(v36, "twang", v59)
	local v62 = v_u_34
	local v63 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0,
		["LightInfluence"] = 0.8,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Acceleration"] = Vector3.new(0, -0.3, 0),
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["Texture"] = v_u_2.dust
	}
	local v64, v65 = Color3.fromRGB(96, 90, 84)
	v63.Color = ColorSequence.new(v64, v65 or v64)
	v63.Speed = NumberRange.new(0.05, 0.2)
	v63.SpreadAngle = Vector2.new(60, 60)
	v63.Size = v_u_22(0, 0.03, 1, 0.07)
	v63.Transparency = v_u_22(0, 0.3, 1, 1)
	v63.Lifetime = NumberRange.new(0.25, 0.45)
	v63.Rotation = NumberRange.new(0, 360)
	v62(v36, "powder", v63)
	local v66 = v_u_34
	local v67 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0,
		["LightInfluence"] = 0.8,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Acceleration"] = Vector3.new(0, 0.15, 0),
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["Texture"] = v_u_2.dust
	}
	local v68, v69 = Color3.fromRGB(190, 184, 176)
	v67.Color = ColorSequence.new(v68, v69 or v68)
	v67.Speed = NumberRange.new(0.1, 0.3)
	v67.SpreadAngle = Vector2.new(40, 40)
	v67.Size = v_u_22(0, 0.05, 1, 0.12)
	v67.Transparency = v_u_22(0, 0.4, 1, 1)
	v67.Lifetime = NumberRange.new(0.3, 0.5)
	v67.Rotation = NumberRange.new(0, 360)
	v66(v36, "puff", v67)
	local v70 = v_u_34
	local v71 = {
		["Texture"] = nil,
		["Color"] = nil,
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["ZOffset"] = 0.2,
		["Texture"] = v_u_2.flash
	}
	local v72 = Color3.fromRGB(255, 150, 60)
	local v73 = Color3.fromRGB(200, 80, 30)
	v71.Color = ColorSequence.new(v72, v73 or v72)
	v71.Size = v_u_22(0, 0.035, 0.5, 0.04, 1, 0.02)
	v71.Transparency = v_u_22(0, 0.1, 0.6, 0.4, 1, 1)
	v71.Lifetime = NumberRange.new(0.05, 0.06)
	v71.Rotation = NumberRange.new(0, 360)
	v70(v36, "pan", v71)
	local v74 = v_u_34
	local v75 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0.4,
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["ZOffset"] = 0.2,
		["Texture"] = v_u_2.star
	}
	local v76, v77 = Color3.fromRGB(255, 200, 130)
	v75.Color = ColorSequence.new(v76, v77 or v76)
	v75.Size = v_u_22(0, 0.03, 0.3, 0.05, 1, 0)
	v75.Transparency = v_u_22(0, 0.2, 1, 1)
	v75.Lifetime = NumberRange.new(0.12, 0.16)
	v75.Rotation = NumberRange.new(0, 45)
	v74(v36, "glint", v75)
	local v78 = v_u_34
	local v79 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0.4,
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["ZOffset"] = 0.2,
		["Texture"] = v_u_2.star
	}
	local v80, v81 = Color3.fromRGB(255, 214, 160)
	v79.Color = ColorSequence.new(v80, v81 or v80)
	v79.Size = v_u_22(0, 0.05, 0.25, 0.09, 1, 0)
	v79.Transparency = v_u_22(0, 0.05, 0.7, 0.35, 1, 1)
	v79.Lifetime = NumberRange.new(0.06, 0.07)
	v79.Rotation = NumberRange.new(0, 45)
	v78(v36, "flare", v79)
	local v82 = v_u_34
	local v83 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0.25,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Acceleration"] = Vector3.new(0, 0.5, 0),
		["Drag"] = 2,
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["RotSpeed"] = nil,
		["Texture"] = v_u_2.star
	}
	local v84 = Color3.fromRGB(150, 215, 140)
	local v85 = Color3.fromRGB(95, 175, 105)
	v83.Color = ColorSequence.new(v84, v85 or v84)
	v83.Speed = NumberRange.new(0.15, 0.45)
	v83.SpreadAngle = Vector2.new(70, 70)
	v83.Size = v_u_22(0, 0, 0.2, 0.03, 1, 0)
	v83.Transparency = v_u_22(0, 0.1, 1, 1)
	v83.Lifetime = NumberRange.new(0.2, 0.3)
	v83.Rotation = NumberRange.new(0, 90)
	v83.RotSpeed = NumberRange.new(-90, 90)
	v82(v36, "sparkle", v83)
	local v86 = v_u_34
	local v87 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0.3,
		["Speed"] = nil,
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["Texture"] = v_u_2.star
	}
	local v88 = Color3.fromRGB(236, 190, 90)
	local v89 = Color3.fromRGB(205, 140, 45)
	v87.Color = ColorSequence.new(v88, v89 or v88)
	v87.Speed = NumberRange.new(0)
	v87.Size = v_u_22(0, 0, 0.3, 0.04, 1, 0)
	v87.Transparency = v_u_22(0, 0.1, 1, 1)
	v87.Lifetime = NumberRange.new(0.07, 0.1)
	v87.Rotation = NumberRange.new(0, 90)
	v86(v36, "gold", v87)
	local v90 = v_u_34
	local v91 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0,
		["LightInfluence"] = 0.6,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Acceleration"] = Vector3.new(0, -3, 0),
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Texture"] = v_u_2.glow
	}
	local v92, v93 = Color3.fromRGB(236, 220, 170)
	v91.Color = ColorSequence.new(v92, v93 or v92)
	v91.Speed = NumberRange.new(0.25, 0.6)
	v91.SpreadAngle = Vector2.new(50, 50)
	v91.Size = v_u_22(0, 0.008, 1, 0.006)
	v91.Transparency = v_u_22(0, 0, 0.7, 0.2, 1, 1)
	v91.Lifetime = NumberRange.new(0.25, 0.4)
	v90(v36, "crumbs", v91)
	local v94 = v_u_34
	local v95 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0.1,
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["ZOffset"] = 0.1,
		["Texture"] = v_u_2.ring
	}
	local v96, v97 = Color3.fromRGB(255, 200, 120)
	v95.Color = ColorSequence.new(v96, v97 or v96)
	v95.Size = v_u_22(0, 0.03, 1, 0.22)
	v95.Transparency = v_u_22(0, 0.6, 1, 1)
	v95.Lifetime = NumberRange.new(0.4, 0.45)
	v94(v36, "ring", v95)
	local v98 = v_u_34
	local v99 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0,
		["LightInfluence"] = 0.8,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Acceleration"] = Vector3.new(0, 0.1, 0),
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["Texture"] = v_u_2.dust
	}
	local v100, v101 = Color3.fromRGB(176, 160, 136)
	v99.Color = ColorSequence.new(v100, v101 or v100)
	v99.Speed = NumberRange.new(0.1, 0.35)
	v99.SpreadAngle = Vector2.new(70, 70)
	v99.Size = v_u_22(0, 0.03, 1, 0.1)
	v99.Transparency = v_u_22(0, 0.45, 1, 1)
	v99.Lifetime = NumberRange.new(0.35, 0.6)
	v99.Rotation = NumberRange.new(0, 360)
	v98(v36, "dust", v99)
	local v102 = v_u_34
	local v103 = {
		["Texture"] = nil,
		["Color"] = nil,
		["Orientation"] = nil,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Drag"] = 7,
		["Acceleration"] = Vector3.new(0, -4, 0),
		["Size"] = nil,
		["Squash"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["Texture"] = v_u_2.spark
	}
	local v104 = Color3.fromRGB(255, 214, 140)
	local v105 = v_u_35
	v103.Color = ColorSequence.new(v104, v105 or v104)
	v103.Orientation = Enum.ParticleOrientation.VelocityParallel
	v103.Speed = NumberRange.new(0.8, 2)
	v103.SpreadAngle = Vector2.new(180, 180)
	v103.Size = v_u_22(0, 0.012, 1, 0.003)
	v103.Squash = v_u_22(0, 2, 1, 1)
	v103.Transparency = v_u_22(0, 0.1, 1, 1)
	v103.Lifetime = NumberRange.new(0.12, 0.26)
	v103.Rotation = NumberRange.new(90)
	v102(v36, "block_spark", v103)
	local v106 = v_u_34
	local v107 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0,
		["LightInfluence"] = 0.8,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Acceleration"] = Vector3.new(0, -2, 0),
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["Texture"] = v_u_2.dust
	}
	local v108, v109 = Color3.fromRGB(150, 116, 80)
	v107.Color = ColorSequence.new(v108, v109 or v108)
	v107.Speed = NumberRange.new(0.4, 1)
	v107.SpreadAngle = Vector2.new(70, 70)
	v107.Size = v_u_22(0, 0.015, 1, 0.04)
	v107.Transparency = v_u_22(0, 0.3, 1, 1)
	v107.Lifetime = NumberRange.new(0.2, 0.35)
	v107.Rotation = NumberRange.new(0, 360)
	v106(v36, "wood_hit", v107)
	local v110 = v_u_34
	local v111 = {
		["Texture"] = nil,
		["Color"] = nil,
		["Speed"] = nil,
		["Acceleration"] = Vector3.new(0, 0.6, 0),
		["SpreadAngle"] = nil,
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["Rate"] = 40,
		["LightEmission"] = 0.35,
		["Texture"] = v_u_2.ember
	}
	local v112 = Color3.fromRGB(255, 190, 90)
	local v113 = Color3.fromRGB(240, 90, 40)
	v111.Color = ColorSequence.new(v112, v113 or v112)
	v111.Speed = NumberRange.new(0.05, 0.15)
	v111.SpreadAngle = Vector2.new(25, 25)
	v111.Size = v_u_22(0, 0.02, 0.4, 0.028, 1, 0)
	v111.Transparency = v_u_22(0, 0.25, 1, 1)
	v111.Lifetime = NumberRange.new(0.18, 0.3)
	v111.Rotation = NumberRange.new(-15, 15)
	v110(v36, "embers", v111)
	local v114 = v_u_34
	local v115 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0.35,
		["Speed"] = nil,
		["Acceleration"] = Vector3.new(0, 0.5, 0),
		["SpreadAngle"] = nil,
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["Rate"] = 22,
		["Texture"] = v_u_2.side
	}
	local v116 = Color3.fromRGB(255, 170, 70)
	local v117 = Color3.fromRGB(220, 80, 30)
	v115.Color = ColorSequence.new(v116, v117 or v116)
	v115.Speed = NumberRange.new(0.1, 0.2)
	v115.SpreadAngle = Vector2.new(10, 10)
	v115.Size = v_u_22(0, 0.09, 0.5, 0.07, 1, 0.02)
	v115.Transparency = v_u_22(0, 0.2, 1, 1)
	v115.Lifetime = NumberRange.new(0.15, 0.24)
	v115.Rotation = NumberRange.new(-90)
	v114(v36, "flame", v115)
	local v118 = v_u_34
	local v119 = {
		["Texture"] = nil,
		["Color"] = nil,
		["Speed"] = nil,
		["Acceleration"] = Vector3.new(0, -0.4, 0),
		["SpreadAngle"] = nil,
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Rotation"] = nil,
		["Rate"] = 18,
		["LightEmission"] = 0.3,
		["Texture"] = v_u_2.spark
	}
	local v120 = Color3.fromRGB(255, 190, 110)
	local v121 = Color3.fromRGB(235, 120, 50)
	v119.Color = ColorSequence.new(v120, v121 or v120)
	v119.Speed = NumberRange.new(0.15, 0.35)
	v119.SpreadAngle = Vector2.new(60, 60)
	v119.Size = v_u_22(0, 0.012, 1, 0)
	v119.Transparency = v_u_22(0, 0.2, 1, 1)
	v119.Lifetime = NumberRange.new(0.15, 0.25)
	v119.Rotation = NumberRange.new(0, 360)
	v118(v36, "fuse", v119)
	local v122 = v_u_34
	local v123 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0.1,
		["Size"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["ZOffset"] = 0.1,
		["Texture"] = v_u_2.ring
	}
	local v124, v125 = Color3.fromRGB(214, 204, 186)
	v123.Color = ColorSequence.new(v124, v125 or v124)
	v123.Size = v_u_22(0, 0.03, 1, 0.08)
	v123.Transparency = v_u_22(0, 0.35, 1, 1)
	v123.Lifetime = NumberRange.new(0.1, 0.12)
	v122(v36, "puncture", v123)
	local v126 = v_u_34
	local v127 = {
		["Texture"] = nil,
		["Color"] = nil,
		["LightEmission"] = 0.15,
		["Orientation"] = nil,
		["Speed"] = nil,
		["SpreadAngle"] = nil,
		["Drag"] = 8,
		["Size"] = nil,
		["Squash"] = nil,
		["Transparency"] = nil,
		["Lifetime"] = nil,
		["Texture"] = v_u_2.spark
	}
	local v128, v129 = Color3.fromRGB(230, 214, 180)
	v127.Color = ColorSequence.new(v128, v129 or v128)
	v127.Orientation = Enum.ParticleOrientation.VelocityParallel
	v127.Speed = NumberRange.new(1.5, 2.5)
	v127.SpreadAngle = Vector2.new(25, 25)
	v127.Size = v_u_22(0, 0.006, 1, 0.002)
	v127.Squash = v_u_22(0, 3, 1, 1)
	v127.Transparency = v_u_22(0, 0.3, 1, 1)
	v127.Lifetime = NumberRange.new(0.06, 0.09)
	v126(v36, "puncture_lines", v127)
	local v130 = Instance.new("Attachment")
	v130.Name = "streak0"
	v130.Parent = v36
	local v131 = Instance.new("Attachment")
	v131.Name = "streak1"
	v131.Parent = v36
	local v132 = Instance.new("Beam")
	v132.Attachment0 = v130
	v132.Attachment1 = v131
	v132.FaceCamera = true
	v132.Segments = 1
	v132.Width0 = 0.004
	v132.Width1 = 0.02
	v132.LightEmission = 0.15
	v132.LightInfluence = 0.4
	v132.Color = ColorSequence.new(Color3.fromRGB(176, 166, 150))
	v132.Transparency = NumberSequence.new(1, 0.4)
	v132.Enabled = false
	v132.Parent = v36
	v_u_13 = {
		["a0"] = v130,
		["a1"] = v131,
		["beam"] = v132
	}
	local v133 = Instance.new("Attachment")
	v133.Name = "light"
	v133.Parent = v37
	v_u_8 = v133
	local v134 = Instance.new("PointLight")
	v134.Brightness = 1
	v134.Range = 9
	v134.Color = Color3.fromRGB(255, 170, 90)
	v134.Shadows = false
	v134.Enabled = false
	v134.Parent = v133
	v_u_7 = v134
	return v36
end
function v1.Preload() -- name: Preload
	-- upvalues: (ref) v_u_4, (copy) v_u_135, (copy) v_u_6
	v_u_4 = v_u_4 or v_u_135()
	task.spawn(function()
		-- upvalues: (ref) v_u_6
		local v_u_136 = {}
		for _, v137 in v_u_6 do
			local v138 = v137.e
			table.insert(v_u_136, v138)
		end
		pcall(function()
			-- upvalues: (copy) v_u_136
			game:GetService("ContentProvider"):PreloadAsync(v_u_136)
		end)
	end)
end
function v1.Follow(p139, p140) -- name: Follow
	-- upvalues: (ref) v_u_14, (ref) v_u_4, (copy) v_u_135, (ref) v_u_5, (ref) v_u_7, (ref) v_u_9, (copy) v_u_6, (ref) v_u_10
	v_u_14 = os.clock()
	if v_u_4 then
		local v141 = v_u_4 or v_u_135()
		v_u_4 = v141
		v141.CFrame = p140
		if v141.Parent ~= p139 then
			v141.Parent = p139
		end
		local v142 = v_u_5
		if v142 and v142.Parent ~= p139 then
			v142.Parent = p139
		end
		if v_u_7 and (v_u_7.Enabled and v_u_9 <= v_u_14) then
			v_u_7.Enabled = false
		end
		local v143 = v_u_6.wisp
		if v143 and (v143.e.Enabled and v_u_10 <= v_u_14) then
			v143.e.Enabled = false
		end
	end
end
local v_u_144 = {
	["musket"] = {
		["flash"] = 0.09,
		["tongue"] = 0.17,
		["squash"] = 2.4,
		["sparks"] = 8,
		["spread"] = 10,
		["smoke"] = 4,
		["wisp"] = 1.1
	},
	["blunderbuss"] = {
		["flash"] = 0.075,
		["tongue"] = 0.08,
		["squash"] = 0.6,
		["sparks"] = 20,
		["spread"] = 28,
		["smoke"] = 6,
		["wisp"] = 1.2,
		["sparkSize"] = 0.03,
		["sparkSquash"] = 3,
		["sparkMin"] = 3,
		["sparkMax"] = 6,
		["sparkAt"] = 0.05
	},
	["pistol"] = {
		["flash"] = 0.085,
		["tongue"] = 0.09,
		["squash"] = 0.8,
		["sparks"] = 6,
		["spread"] = 14,
		["smoke"] = 2,
		["wisp"] = 0.7
	}
}
function v1.Play(p145, p146, p147) -- name: Play
	-- upvalues: (ref) v_u_4, (copy) v_u_135, (ref) v_u_5, (copy) v_u_144, (copy) v_u_6, (copy) v_u_22, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_11, (ref) v_u_12
	local v148 = workspace.CurrentCamera
	if v148 then
		local v149 = v148.CFrame
		local v150 = v_u_4 or v_u_135()
		v_u_4 = v150
		v150.CFrame = v149
		if v150.Parent ~= v148 then
			v150.Parent = v148
		end
		local v151 = v_u_5
		if v151 and v151.Parent ~= v148 then
			v151.Parent = v148
		end
		local v152 = p147 or {}
		local v153 = p146.LookVector
		local v154 = p146.RightVector
		local v155 = CFrame.fromMatrix(p146.Position, v154, v153, v154:Cross(v153))
		if p145 == "muzzle" then
			local v156 = v_u_144[v152.style or "musket"] or v_u_144.musket
			local v157 = v_u_6.flash
			local v158 = v_u_6.tongue
			local v159 = v_u_6.sparks
			if v157 then
				v157.e.Size = v_u_22(0, v156.flash, 0.4, v156.flash * 1.08, 1, v156.flash * 0.5)
			end
			if v158 then
				v158.e.Size = v_u_22(0, v156.tongue, 0.5, v156.tongue * 1.1, 1, v156.tongue * 0.6)
				v158.e.Squash = v_u_22(0, v156.squash, 1, v156.squash * 0.7)
			end
			if v159 then
				v159.e.SpreadAngle = Vector2.new(v156.spread, v156.spread)
				v159.e.Size = v_u_22(0, v156.sparkSize or 0.016, 1, (v156.sparkSize or 0.016) * 0.27)
				v159.e.Squash = v_u_22(0, v156.sparkSquash or 2, 1, (v156.sparkSquash or 2) * 0.5)
				v159.e.Speed = NumberRange.new(v156.sparkMin or 2.2, v156.sparkMax or 4.5)
			end
			local v160 = v_u_5
			if v160 then
				v160.CFrame = v148.CFrame * v155
			end
			local v161 = CFrame.new(0, v156.flash * 0.3, 0)
			local v162 = v_u_6.flash
			if v162 then
				v162.att.CFrame = v161
				v162.e:Emit(1)
			end
			local v163 = CFrame.new(0, v156.tongue * v156.squash * 0.5, 0)
			local v164 = v_u_6.tongue
			if v164 then
				v164.att.CFrame = v163
				v164.e:Emit(2)
			end
			local v165 = CFrame.new(0, v156.sparkAt or 0.03, 0)
			local v166 = v156.sparks
			local v167 = v_u_6.sparks
			if v167 then
				v167.att.CFrame = v165
				v167.e:Emit(v166)
			end
			local v168 = v155 + p146.LookVector * 0.03
			local v169 = v156.smoke
			local v170 = v_u_6.smoke
			if v170 then
				v170.att.CFrame = v168
				v170.e:Emit(v169)
			end
			local v171 = v_u_6.wisp
			if v171 then
				v171.att.CFrame = v155
				v171.e.Enabled = true
				v_u_10 = os.clock() + v156.wisp
			end
			if v_u_7 and v_u_8 then
				v_u_8.CFrame = CFrame.identity
				v_u_7.Enabled = true
				v_u_9 = os.clock() + 0.05
				return
			end
		elseif p145 == "pan" then
			local v172 = v_u_6.pan
			if v172 then
				v172.att.CFrame = v155
				v172.e:Emit(1)
			end
			local v173 = v_u_6.puff
			if v173 then
				v173.att.CFrame = v155
				v173.e:Emit(2)
				return
			end
		elseif p145 == "twang" then
			local v174 = v_u_6.twang
			if v174 then
				v174.att.CFrame = v155
				v174.e:Emit(4)
				return
			end
		elseif p145 == "powder" then
			local v175 = v_u_6.powder
			if v175 then
				v175.att.CFrame = v155
				v175.e:Emit(6)
				return
			end
		elseif p145 == "puff" then
			local v176 = v_u_6.puff
			if v176 then
				v176.att.CFrame = v155
				v176.e:Emit(3)
				return
			end
		elseif p145 == "click" or (p145 == "glint" or p145 == "bolt") then
			local v177 = v_u_6.glint
			if v177 then
				v177.att.CFrame = v155
				v177.e:Emit(1)
				return
			end
		elseif p145 == "flare" then
			local v178 = v_u_6.flare
			if v178 then
				v178.att.CFrame = v155
				v178.e:Emit(1)
			end
			local v179 = v_u_6.glint
			if v179 then
				v179.att.CFrame = v155
				v179.e:Emit(1)
				return
			end
		elseif p145 == "sparkle" then
			local v180 = v_u_6.sparkle
			if v180 then
				v180.att.CFrame = v155
				v180.e:Emit(6)
				return
			end
		elseif p145 == "gold" then
			local v181 = v_u_6.gold
			if v181 then
				v181.att.CFrame = v155
				v181.e:Emit(2)
				return
			end
		elseif p145 == "crumbs" then
			local v182 = v_u_6.crumbs
			if v182 then
				v182.att.CFrame = v155
				v182.e:Emit(5)
				return
			end
		elseif p145 == "ring" then
			local v183 = v_u_6.ring
			if v183 then
				v183.att.CFrame = p146
				v183.e:Emit(1)
				return
			end
		elseif p145 == "dust" then
			local v184 = v_u_6.dust
			if v184 then
				v184.att.CFrame = v155
				v184.e:Emit(5)
				return
			end
		elseif p145 == "puncture" then
			local v185 = v_u_6.puncture
			if v185 then
				v185.att.CFrame = v155
				v185.e:Emit(1)
			end
			local v186 = v_u_6.puncture_lines
			if v186 then
				v186.att.CFrame = v155
				v186.e:Emit(6)
				return
			end
		elseif p145 == "block_spark" then
			local v187 = v_u_6.block_spark
			if v187 then
				v187.att.CFrame = v155
				v187.e:Emit(16)
			end
			local v188 = v_u_6.glint
			if v188 then
				v188.att.CFrame = v155
				v188.e:Emit(1)
				return
			end
		elseif p145 == "wood_hit" then
			local v189 = v_u_6.wood_hit
			if v189 then
				v189.att.CFrame = v155
				v189.e:Emit(8)
				return
			end
		else
			if p145 == "embers" then
				for _, v190 in { "embers", "flame" } do
					local v191 = v_u_6[v190]
					if not v191 then
						continue
					end
					v191.att.CFrame = v155
					v191.e.Enabled = v152.on ~= false
				end
				v_u_11 = v152.on ~= false
				return
			end
			local v192 = p145 == "fuse" and v_u_6.fuse
			if v192 then
				v192.att.CFrame = v155
				v192.e.Enabled = v152.on ~= false
				v192.e.Rate = v152.rate or 18
				v_u_12 = v152.on ~= false
			end
		end
	end
end
function v1.Streak(p193, p194, p195, p196) -- name: Streak
	-- upvalues: (ref) v_u_13, (ref) v_u_4, (copy) v_u_135, (ref) v_u_5
	local v197 = v_u_13
	if v197 then
		if p193 and (p194 and (p194 - p193).Magnitude >= 0.004) then
			local v198 = workspace.CurrentCamera
			if v198 then
				local v199 = v198.CFrame
				local v200 = v_u_4 or v_u_135()
				v_u_4 = v200
				v200.CFrame = v199
				if v200.Parent ~= v198 then
					v200.Parent = v198
				end
				local v201 = v_u_5
				if v201 and v201.Parent ~= v198 then
					v201.Parent = v198
				end
			end
			v197.a0.Position = p193
			v197.a1.Position = p194
			local v202 = p196 or 0.02
			if v197.beam.Width1 ~= v202 then
				v197.beam.Width1 = v202
				v197.beam.Width0 = not p196 and 0.004 or v202 * 0.2
			end
			v197.beam.Transparency = NumberSequence.new(1, 1 - math.clamp(p195 or 1, 0, 1) * 0.75)
			v197.beam.Enabled = true
		else
			v197.beam.Enabled = false
		end
	else
		return
	end
end
function v1.Track(p203, p204) -- name: Track
	-- upvalues: (ref) v_u_5, (copy) v_u_6, (ref) v_u_11, (ref) v_u_12
	if p203 == "muzzle" then
		local v205 = v_u_5
		local v206 = workspace.CurrentCamera
		if v205 and v206 then
			local v207 = v206.CFrame
			local v208 = p204.LookVector
			local v209 = p204.RightVector
			v205.CFrame = v207 * CFrame.fromMatrix(p204.Position, v209, v208, v209:Cross(v208))
		end
		local v210 = v_u_6.wisp
		if v210 and v210.e.Enabled then
			local v211 = v210.att
			local v212 = p204.LookVector
			local v213 = p204.RightVector
			v211.CFrame = CFrame.fromMatrix(p204.Position, v213, v212, v213:Cross(v212))
			return
		end
	else
		if p203 == "embers" and v_u_11 then
			for _, v214 in { "embers", "flame" } do
				local v215 = v_u_6[v214]
				if not v215 then
					continue
				end
				local v216 = v215.att
				local v217 = p204.LookVector
				local v218 = p204.RightVector
				v216.CFrame = CFrame.fromMatrix(p204.Position, v218, v217, v218:Cross(v217))
			end
			return
		end
		local v219 = p203 == "fuse" and (v_u_12 and v_u_6.fuse)
		if v219 then
			local v220 = v219.att
			local v221 = p204.LookVector
			local v222 = p204.RightVector
			v220.CFrame = CFrame.fromMatrix(p204.Position, v222, v221, v222:Cross(v221))
		end
	end
end
function v1.Freeze(p223) -- name: Freeze
	-- upvalues: (ref) v_u_15, (copy) v_u_6
	v_u_15 = p223
	for _, v224 in v_u_6 do
		v224.e.TimeScale = p223 and 0.01 or 1
	end
end
function v1.Hide() -- name: Hide
	-- upvalues: (copy) v_u_6, (ref) v_u_11, (ref) v_u_12, (ref) v_u_7, (ref) v_u_13
	for _, v225 in v_u_6 do
		v225.e.Enabled = false
		v225.e:Clear()
	end
	v_u_11 = false
	v_u_12 = false
	if v_u_7 then
		v_u_7.Enabled = false
	end
	if v_u_13 then
		v_u_13.beam.Enabled = false
	end
end
return v1