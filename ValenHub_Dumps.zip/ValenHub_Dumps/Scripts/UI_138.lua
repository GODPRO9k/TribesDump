local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = game:GetService("GuiService")
local v_u_7 = require(script.Parent.Theme)
local v_u_8 = require(script.Parent.Sounds)
local v_u_9 = require(v1:WaitForChild("Shared"):WaitForChild("Signal"))
local v_u_10 = require(v1.Shared:WaitForChild("Keybinds"))
local v11 = {
	["Icons"] = {},
	["WeaponArt"] = {}
}
local v12 = v1.Shared:FindFirstChild("UIAssets")
local v_u_13
if v12 then
	local v14 = require
	local v15
	v15, v_u_13 = pcall(v14, v12)
	if not v15 then
		v_u_13 = v11
	end
else
	v_u_13 = v11
end
local v_u_16 = v_u_7.Colors
local v_u_17 = v_u_7.Fonts
local v_u_18 = {
	["Theme"] = v_u_7,
	["Sounds"] = v_u_8,
	["Assets"] = v_u_13
}
local v_u_19 = {
	["Frame"] = {
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0
	},
	["TextLabel"] = {
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["TextColor3"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 18,
		["RichText"] = false,
		["TextColor3"] = v_u_16.Text,
		["FontFace"] = v_u_17.Heavy
	},
	["TextButton"] = {
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["AutoButtonColor"] = false,
		["Text"] = ""
	},
	["ImageLabel"] = {
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0
	},
	["ImageButton"] = {
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["AutoButtonColor"] = false
	},
	["ScrollingFrame"] = {
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["ScrollBarThickness"] = 6,
		["ScrollBarImageColor3"] = nil,
		["ScrollBarImageTransparency"] = 0.2,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["VerticalScrollBarInset"] = nil,
		["ScrollBarImageColor3"] = v_u_16.StrokeSoft,
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["VerticalScrollBarInset"] = Enum.ScrollBarInset.ScrollBar
	},
	["ViewportFrame"] = {
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0
	},
	["CanvasGroup"] = {
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0
	}
}
function v_u_18.new(p20, p21) -- name: new
	-- upvalues: (copy) v_u_19
	local v22 = Instance.new(p20)
	local v23 = v_u_19[p20]
	if v23 then
		for v24, v25 in v23 do
			v22[v24] = v25
		end
	end
	local v26 = nil
	if p21 then
		if v23 and (p21.BackgroundColor3 ~= nil and p21.BackgroundTransparency == nil) then
			v22.BackgroundTransparency = 0
		end
		for v27, v28 in p21 do
			if v27 == "Parent" then
				v26 = v28
			else
				if type(v27) == "number" then
					continue
				end
				v22[v27] = v28
			end
		end
		for _, v29 in ipairs(p21) do
			v29.Parent = v22
		end
	end
	if v26 then
		v22.Parent = v26
	end
	return v22
end
function v_u_18.Corner(p30) -- name: Corner
	-- upvalues: (copy) v_u_18, (copy) v_u_7
	if type(p30) == "number" then
		p30 = UDim.new(0, p30)
	end
	return v_u_18.new("UICorner", {
		["CornerRadius"] = p30 or v_u_7.Radius.Medium
	})
end
function v_u_18.Stroke(p31, p32, p33) -- name: Stroke
	-- upvalues: (copy) v_u_18, (copy) v_u_16
	return v_u_18.new("UIStroke", {
		["Color"] = p31 or v_u_16.Stroke,
		["Thickness"] = p32 or 2,
		["Transparency"] = p33 or 0,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["LineJoinMode"] = Enum.LineJoinMode.Round
	})
end
function v_u_18.TextStroke(p34, p35, p36) -- name: TextStroke
	-- upvalues: (copy) v_u_18, (copy) v_u_16
	return v_u_18.new("UIStroke", {
		["Color"] = p34 or v_u_16.Void,
		["Thickness"] = p35 or 2,
		["Transparency"] = p36 or 0,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Contextual,
		["LineJoinMode"] = Enum.LineJoinMode.Round
	})
end
function v_u_18.Gradient(p37, p38, p39, p40) -- name: Gradient
	-- upvalues: (copy) v_u_18
	if typeof(p37) ~= "ColorSequence" then
		p37 = ColorSequence.new(p37, p38 or p37)
	end
	return v_u_18.new("UIGradient", {
		["Color"] = p37,
		["Rotation"] = p39 or 90,
		["Transparency"] = p40 or NumberSequence.new(0)
	})
end
function v_u_18.Padding(p41, p42, p43, p44) -- name: Padding
	-- upvalues: (copy) v_u_18
	return v_u_18.new("UIPadding", {
		["PaddingTop"] = UDim.new(0, p41),
		["PaddingRight"] = UDim.new(0, p42 or p41),
		["PaddingBottom"] = UDim.new(0, p43 or p41),
		["PaddingLeft"] = UDim.new(0, p44 or (p42 or p41))
	})
end
function v_u_18.List(p45, p46, p47, p48) -- name: List
	-- upvalues: (copy) v_u_18
	return v_u_18.new("UIListLayout", {
		["FillDirection"] = p45 or Enum.FillDirection.Vertical,
		["Padding"] = UDim.new(0, p46 or 8),
		["HorizontalAlignment"] = p47 or Enum.HorizontalAlignment.Left,
		["VerticalAlignment"] = p48 or Enum.VerticalAlignment.Top,
		["SortOrder"] = Enum.SortOrder.LayoutOrder
	})
end
function v_u_18.DisplayText(p49) -- name: DisplayText
	-- upvalues: (copy) v_u_16, (copy) v_u_17, (copy) v_u_18
	local v50 = table.clone(p49)
	local v51 = v50.StrokeThickness or 1.5
	local v52 = math.min(v51, 2)
	local v53 = v50.StrokeColor or v_u_16.Void
	v50.StrokeThickness = nil
	v50.StrokeColor = nil
	v50.FontFace = v50.FontFace or v_u_17.Display
	local v54 = v_u_18.new("TextLabel", v50)
	v_u_18.TextStroke(v53, v52, 0.45).Parent = v54
	return v54
end
function v_u_18.Image(p55, p56) -- name: Image
	-- upvalues: (copy) v_u_18
	local v57 = not p56 and {} or table.clone(p56)
	v57.Image = p55 or ""
	v57.ScaleType = v57.ScaleType or Enum.ScaleType.Fit
	return v_u_18.new("ImageLabel", v57)
end
function v_u_18.Tween(p58, p59, p60) -- name: Tween
	-- upvalues: (copy) v_u_2
	local v61 = v_u_2:Create(p58, p59, p60)
	v61:Play()
	return v61
end
function v_u_18.GetScaleObj(p62, p63) -- name: getScaleObj
	local v64 = p63 or "AnimScale"
	local v65 = p62:FindFirstChild(v64)
	if v65 and v65:IsA("UIScale") then
		return v65
	end
	local v66 = Instance.new("UIScale")
	v66.Name = v64
	v66.Parent = p62
	return v66
end
function v_u_18.Pop(p67, p68, p69) -- name: Pop
	-- upvalues: (copy) v_u_18, (copy) v_u_7
	local v70 = p67:FindFirstChild("AnimScale")
	if not (v70 and v70:IsA("UIScale")) then
		v70 = Instance.new("UIScale")
		v70.Name = "AnimScale"
		v70.Parent = p67
	end
	v70.Scale = p68 or 0.6
	v_u_18.Tween(v70, p69 or v_u_7.Tween.Pop, {
		["Scale"] = 1
	})
end
function v_u_18.Bump(p71, p72) -- name: Bump
	-- upvalues: (copy) v_u_18, (copy) v_u_7
	local v73 = p71:FindFirstChild("AnimScale")
	if not (v73 and v73:IsA("UIScale")) then
		v73 = Instance.new("UIScale")
		v73.Name = "AnimScale"
		v73.Parent = p71
	end
	v73.Scale = 1 + (p72 or 0.15)
	v_u_18.Tween(v73, v_u_7.Tween.PopSmall, {
		["Scale"] = 1
	})
end
function v_u_18.SlideIn(p_u_74, p75, p76, p77) -- name: SlideIn
	-- upvalues: (copy) v_u_18, (copy) v_u_7
	if not p77 then
		p77 = p_u_74:GetAttribute("_slideTarget")
		if typeof(p77) ~= "UDim2" then
			p77 = p_u_74.Position
		end
	end
	local v78 = p75 or Vector2.new(0, 24)
	p_u_74:SetAttribute("_slideTarget", p77)
	p_u_74.Position = p77 + UDim2.fromOffset(v78.X, v78.Y)
	local v79 = v_u_18.Tween(p_u_74, p76 or v_u_7.Tween.Smooth, {
		["Position"] = p77
	})
	v79.Completed:Connect(function(p80)
		-- upvalues: (copy) p_u_74
		if p80 == Enum.PlaybackState.Completed then
			p_u_74:SetAttribute("_slideTarget", nil)
		end
	end)
	return v79
end
local function v_u_85(p81) -- name: fadeProps
	local v82 = {}
	if p81:IsA("GuiObject") then
		v82.BackgroundTransparency = p81.BackgroundTransparency
	end
	if p81:IsA("TextLabel") or (p81:IsA("TextButton") or p81:IsA("TextBox")) then
		v82.TextTransparency = p81.TextTransparency
	elseif p81:IsA("ImageLabel") or (p81:IsA("ImageButton") or p81:IsA("ViewportFrame")) then
		v82.ImageTransparency = p81.ImageTransparency
	elseif p81:IsA("UIStroke") then
		v82.Transparency = p81.Transparency
	end
	for v83, v84 in v82 do
		if v84 < 1 then
			continue
		end
		v82[v83] = nil
	end
	if next(v82) then
		return v82
	else
		return nil
	end
end
local v_u_86 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_93(p87) -- name: capture
	-- upvalues: (copy) v_u_86, (copy) v_u_85
	local v88 = v_u_86[p87]
	if v88 then
		return v88
	end
	local v89 = {}
	local v90 = v_u_85(p87)
	if v90 then
		v89[p87] = v90
	end
	for _, v91 in p87:GetDescendants() do
		local v92 = v_u_85(v91)
		if not v92 then
			continue
		end
		v89[v91] = v92
	end
	v_u_86[p87] = v89
	return v89
end
function v_u_18.ResetFade(p94) -- name: ResetFade
	-- upvalues: (copy) v_u_86
	v_u_86[p94] = nil
end
function v_u_18.FadeIn(p95, p96) -- name: FadeIn
	-- upvalues: (copy) v_u_7, (copy) v_u_93, (copy) v_u_18
	local v97 = p96 or v_u_7.Tween.Smooth
	for v98, v99 in v_u_93(p95) do
		if v98 ~= p95 and not v98:IsDescendantOf(p95) then
			continue
		end
		for v100 in v99 do
			v98[v100] = 1
		end
		v_u_18.Tween(v98, v97, v99)
	end
end
function v_u_18.FadeOut(p101, p102) -- name: FadeOut
	-- upvalues: (copy) v_u_7, (copy) v_u_93, (copy) v_u_18
	local v103 = p102 or v_u_7.Tween.Close
	for v104, v105 in v_u_93(p101) do
		if v104 ~= p101 and not v104:IsDescendantOf(p101) then
			continue
		end
		local v106 = {}
		for v107 in v105 do
			v106[v107] = 1
		end
		v_u_18.Tween(v104, v103, v106)
	end
end
function v_u_18.Unfade(p108) -- name: Unfade
	-- upvalues: (copy) v_u_93
	for v109, v110 in v_u_93(p108) do
		if v109 ~= p108 and not v109:IsDescendantOf(p108) then
			continue
		end
		for v111, v112 in v110 do
			v109[v111] = v112
		end
	end
end
function v_u_18.Enter(p113, p114, p115, p116) -- name: Enter
	-- upvalues: (copy) v_u_18
	local v117 = p115 or 0
	v_u_18.SlideIn(p113, p114, TweenInfo.new(0.36, Enum.EasingStyle.Back, Enum.EasingDirection.Out, 0, false, v117), p116)
	v_u_18.FadeIn(p113, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, v117))
end
function v_u_18.Shake(p_u_118, p119) -- name: Shake
	local v_u_120 = p_u_118:GetAttribute("_shakeBase")
	if v_u_120 == nil then
		v_u_120 = p_u_118:GetAttribute("_slideTarget")
		if typeof(v_u_120) ~= "UDim2" then
			v_u_120 = p_u_118.Position
		end
		p_u_118:SetAttribute("_shakeBase", v_u_120)
	end
	local v_u_121 = p119 or 8
	task.spawn(function()
		-- upvalues: (copy) v_u_121, (copy) p_u_118, (ref) v_u_120
		for _, v122 in {
			v_u_121,
			-v_u_121,
			v_u_121 * 0.6,
			-v_u_121 * 0.6,
			v_u_121 * 0.3,
			0
		} do
			p_u_118.Position = v_u_120 + UDim2.fromOffset(v122, 0)
			task.wait(0.03)
		end
		p_u_118.Position = v_u_120
		p_u_118:SetAttribute("_shakeBase", nil)
	end)
end
function v_u_18.CountUp(p_u_123, p124, p_u_125) -- name: CountUp
	-- upvalues: (copy) v_u_18
	local v_u_126 = p124 or v_u_18.FormatNumber
	local v_u_127 = Instance.new("NumberValue")
	v_u_127.Parent = p_u_123
	local v_u_128 = 0
	v_u_127.Changed:Connect(function(p129)
		-- upvalues: (ref) v_u_128, (copy) p_u_123, (copy) v_u_126
		v_u_128 = p129
		local v130 = p_u_123
		local v131 = v_u_126
		local v132 = p129 + 0.5
		v130.Text = v131((math.floor(v132)))
	end)
	local v_u_133 = nil
	return function(p134, p135)
		-- upvalues: (ref) v_u_133, (copy) v_u_127, (copy) p_u_123, (copy) v_u_126, (copy) p_u_125, (ref) v_u_128, (ref) v_u_18
		if v_u_133 then
			v_u_133:Cancel()
		end
		if p135 then
			v_u_127.Value = p134
			local v136 = p_u_123
			local v137 = v_u_126
			local v138 = p134 + 0.5
			v136.Text = v137((math.floor(v138)))
		else
			local v139 = p_u_125
			if not v139 then
				local v140 = p134 - v_u_128
				local v141 = math.abs(v140) / 400
				v139 = math.clamp(v141, 0.35, 1.2)
			end
			v_u_133 = v_u_18.Tween(v_u_127, TweenInfo.new(v139, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), {
				["Value"] = p134
			})
		end
	end
end
function v_u_18.FormatNumber(p142) -- name: FormatNumber
	local v143 = math.abs(p142)
	local v144 = math.floor(v143)
	local v145 = tostring(v144):reverse():gsub("(%d%d%d)", "%1,"):reverse()
	if v145:sub(1, 1) == "," then
		v145 = v145:sub(2)
	end
	return (p142 < 0 and "-" or "") .. v145
end
function v_u_18.FormatCompact(p146) -- name: FormatCompact
	-- upvalues: (copy) v_u_18
	local v147 = math.abs(p146)
	local v148
	if v147 >= 1000000 then
		v148 = string.format("%.2fM", v147 / 1000000)
	else
		if v147 < 10000 then
			return v_u_18.FormatNumber(p146)
		end
		v148 = string.format("%.1fK", v147 / 1000)
	end
	local v149 = v148:gsub("%.0+([KM])$", "%1"):gsub("(%.%d)0([KM])$", "%1%2")
	return (p146 < 0 and "-" or "") .. v149
end
function v_u_18.FormatTime(p150) -- name: FormatTime
	local v151 = math.ceil(p150)
	local v152 = math.max(0, v151)
	return string.format("%d:%02d", v152 // 60, v152 % 60)
end
v_u_18.Scale = 1
v_u_18.ScaleChanged = v_u_9.new()
v_u_18.BackdropCanvas = nil
v_u_18.Touch = false
v_u_18.Compact = false
v_u_18.Tablet = false
v_u_18.LayoutChanged = v_u_9.new()
v_u_18.TouchChanged = v_u_9.new()
v_u_18.COMPACT_DESIGN = Vector2.new(1280, 600)
v_u_18.TV_DESIGN = Vector2.new(1280, 720)
v_u_18.Gamepad = false
v_u_18.GamepadChanged = v_u_9.new()
v_u_18.TenFoot = false
v_u_18.DebugDevice = nil
local function v_u_158() -- name: preferredTouch
	-- upvalues: (copy) v_u_5
	local function v153()
		-- upvalues: (ref) v_u_5
		return v_u_5.PreferredInput
	end
	local v154, v_u_155 = pcall(v153)
	if v154 and v_u_155 ~= nil then
		local v156, v157 = pcall(function()
			-- upvalues: (copy) v_u_155
			return v_u_155 == Enum.PreferredInput.Touch
		end)
		if v156 then
			return v157
		else
			return nil
		end
	else
		return nil
	end
end
local v_u_159 = nil
local function v_u_161(p160) -- name: decisive
	if p160 == Enum.UserInputType.Touch then
		return true
	elseif p160 == Enum.UserInputType.Keyboard or (p160 == Enum.UserInputType.MouseButton1 or (p160 == Enum.UserInputType.MouseButton2 or (p160 == Enum.UserInputType.MouseWheel or string.find(p160.Name, "Gamepad", 1, true)))) then
		return false
	else
		return nil
	end
end
local v162
if v_u_5.TouchEnabled then
	local v163 = v_u_5.TouchEnabled
	if v163 then
		local v164 = v_u_5.KeyboardEnabled
		if v164 then
			v164 = v_u_5.MouseEnabled
		end
		v163 = not v164
	end
	if v163 then
		v162 = true
	else
		v162 = v_u_158()
		if v162 == nil then
			if v_u_159 == nil then
				if v_u_161(v_u_5:GetLastInputType()) == true then
					v_u_159 = true
				else
					v_u_159 = false
				end
			end
			v162 = v_u_159
		end
	end
else
	v162 = false
end
v_u_18.Touch = v162
local function v_u_176() -- name: computeScale
	-- upvalues: (copy) v_u_18, (copy) v_u_3, (copy) v_u_7
	local v165 = v_u_18.DebugDevice
	local v_u_166, v167, v168
	if v165 then
		v_u_166 = v165.compact ~= false
		v_u_166 = v_u_166
		if v_u_166 then
			v167 = v165.tablet == true
		end
		v168 = v165.scale
	else
		local v169 = v_u_3.CurrentCamera
		local v170 = v169 and v169.ViewportSize or v_u_7.DesignSize
		if v170.X < 2 or v170.Y < 2 then
			return 1
		end
		v_u_166 = v_u_18.Touch or v170.Y < 560
		local v171 = v_u_18.TenFoot
		if v171 then
			v171 = not v_u_166
		end
		local v172
		if v_u_166 then
			v172 = v_u_18.COMPACT_DESIGN
		elseif v171 then
			v172 = v_u_18.TV_DESIGN
		else
			v172 = v_u_7.DesignSize
		end
		local v173 = v170.X / v172.X
		local v174 = v170.Y / v172.Y
		local v175 = math.min(v173, v174)
		v168 = math.clamp(v175, 0.4, v171 and 3.2 or 1.6)
		v_u_166 = v_u_166
		if v_u_166 then
			v167 = v170.Y / v168 >= 760
		end
	end
	if v_u_166 ~= v_u_18.Compact or v167 ~= v_u_18.Tablet then
		v_u_18.Compact = v_u_166
		v_u_18.Tablet = v167
		task.defer(function()
			-- upvalues: (ref) v_u_18, (ref) v_u_166
			v_u_18.LayoutChanged:Fire(v_u_166)
		end)
	end
	return v168
end
local v_u_177 = {}
local function v_u_189() -- name: applyScale
	-- upvalues: (copy) v_u_176, (copy) v_u_18, (copy) v_u_3, (copy) v_u_7, (copy) v_u_177
	local v178 = v_u_176()
	v_u_18.Scale = v178
	local v179 = v_u_18.DebugDevice
	local v180 = v_u_3.CurrentCamera
	local v181 = v180 and v180.ViewportSize or v_u_7.DesignSize
	for _, v182 in v_u_177 do
		v182.scale.Scale = v178
		if v179 then
			v182.frame.Size = UDim2.fromOffset(v179.rect.X / v178, v179.rect.Y / v178)
			local v183 = v182.frame
			local v184
			if v179.topLeft then
				v184 = UDim2.new()
			else
				local v185 = UDim2.fromOffset
				local v186 = (v181.X - v179.rect.X) / 2
				local v187 = math.floor(v186)
				local v188 = (v181.Y - v179.rect.Y) / 2
				v184 = v185(v187, (math.floor(v188)))
			end
			v183.Position = v184
		else
			v182.frame.Size = UDim2.fromScale(1 / v178, 1 / v178)
			v182.frame.Position = UDim2.new()
		end
	end
	v_u_18.ScaleChanged:Fire(v178)
end
local v_u_190 = 0
local v_u_191 = nil
local function v_u_200() -- name: reconsiderTouch
	-- upvalues: (copy) v_u_18, (copy) v_u_5, (copy) v_u_158, (ref) v_u_159, (copy) v_u_161, (ref) v_u_191, (ref) v_u_190, (copy) v_u_189
	if v_u_18.DebugDevice then
		return
	else
		local v_u_192
		if v_u_5.TouchEnabled then
			local v193 = v_u_5.TouchEnabled
			if v193 then
				local v194 = v_u_5.KeyboardEnabled
				if v194 then
					v194 = v_u_5.MouseEnabled
				end
				v193 = not v194
			end
			if v193 then
				v_u_192 = true
			else
				v_u_192 = v_u_158()
				if v_u_192 == nil then
					if v_u_159 == nil then
						v_u_159 = v_u_161(v_u_5:GetLastInputType()) == true
					end
					v_u_192 = v_u_159
				end
			end
		else
			v_u_192 = false
		end
		if v_u_192 == v_u_18.Touch then
			if v_u_191 ~= nil then
				v_u_191 = nil
				v_u_190 = v_u_190 + 1
			end
			return
		elseif v_u_191 ~= v_u_192 then
			v_u_191 = v_u_192
			v_u_190 = v_u_190 + 1
			local v_u_195 = v_u_190
			task.delay(0.3, function()
				-- upvalues: (copy) v_u_195, (ref) v_u_190, (ref) v_u_191, (ref) v_u_18, (ref) v_u_5, (ref) v_u_158, (ref) v_u_159, (ref) v_u_161, (copy) v_u_192, (ref) v_u_189
				if v_u_195 == v_u_190 then
					v_u_191 = nil
					if not v_u_18.DebugDevice then
						local v196
						if v_u_5.TouchEnabled then
							local v197 = v_u_5.TouchEnabled
							if v197 then
								local v198 = v_u_5.KeyboardEnabled
								if v198 then
									v198 = v_u_5.MouseEnabled
								end
								v197 = not v198
							end
							if v197 then
								v196 = true
							else
								v196 = v_u_158()
								if v196 == nil then
									if v_u_159 == nil then
										v_u_159 = v_u_161(v_u_5:GetLastInputType()) == true
									end
									v196 = v_u_159
								end
							end
						else
							v196 = false
						end
						if v196 == v_u_192 then
							local v199 = v_u_192
							if v199 == v_u_18.Touch then
								return
							end
							v_u_18.Touch = v199
							v_u_189()
							v_u_18.TouchChanged:Fire(v199)
						end
					end
				end
			end)
		end
	end
end
v_u_5.LastInputTypeChanged:Connect(function(p201)
	-- upvalues: (copy) v_u_161, (ref) v_u_159, (copy) v_u_200
	local v202 = v_u_161(p201)
	if v202 ~= nil then
		v_u_159 = v202
	end
	v_u_200()
end)
pcall(function()
	-- upvalues: (copy) v_u_5, (copy) v_u_200
	v_u_5:GetPropertyChangedSignal("PreferredInput"):Connect(v_u_200)
end)
local v_u_203 = v_u_159
local v_u_204 = v_u_190
local v_u_205 = v_u_191
for _, v206 in { "TouchEnabled", "KeyboardEnabled", "MouseEnabled" } do
	v_u_5:GetPropertyChangedSignal(v206):Connect(v_u_200)
end
local v_u_207 = nil
local v_u_208 = string.find(v_u_5:GetLastInputType().Name, "Gamepad", 1, true) ~= nil
local function v_u_213() -- name: reconsiderGamepad
	-- upvalues: (ref) v_u_207, (copy) v_u_18, (copy) v_u_5, (ref) v_u_208
	local v209
	if v_u_207 == nil then
		if v_u_18.Touch then
			v209 = false
		else
			local function v210()
				-- upvalues: (ref) v_u_5
				return v_u_5.PreferredInput == Enum.PreferredInput.Gamepad
			end
			local v211, v212 = pcall(v210)
			v209 = not (v211 and v212) and (not v_u_208 and v_u_18.TenFoot)
			if v209 then
				v209 = not v_u_5.KeyboardEnabled
			end
		end
	else
		v209 = v_u_207
	end
	if v209 ~= v_u_18.Gamepad then
		v_u_18.Gamepad = v209
		v_u_18.GamepadChanged:Fire(v209)
	end
end
v_u_5.LastInputTypeChanged:Connect(function(p214)
	-- upvalues: (ref) v_u_208, (copy) v_u_161, (ref) v_u_207, (copy) v_u_18, (copy) v_u_5
	if string.find(p214.Name, "Gamepad", 1, true) then
		v_u_208 = true
	elseif v_u_161(p214) ~= nil then
		v_u_208 = false
	end
	local v215
	if v_u_207 == nil then
		if v_u_18.Touch then
			v215 = false
		else
			local function v216()
				-- upvalues: (ref) v_u_5
				return v_u_5.PreferredInput == Enum.PreferredInput.Gamepad
			end
			local v217, v218 = pcall(v216)
			v215 = not (v217 and v218) and (not v_u_208 and v_u_18.TenFoot)
			if v215 then
				v215 = not v_u_5.KeyboardEnabled
			end
		end
	else
		v215 = v_u_207
	end
	if v215 ~= v_u_18.Gamepad then
		v_u_18.Gamepad = v215
		v_u_18.GamepadChanged:Fire(v215)
	end
end)
pcall(function()
	-- upvalues: (copy) v_u_5, (copy) v_u_213
	v_u_5:GetPropertyChangedSignal("PreferredInput"):Connect(v_u_213)
end)
v_u_18.TouchChanged:Connect(v_u_213)
function v_u_18.SetDebugGamepad(p219) -- name: SetDebugGamepad
	-- upvalues: (ref) v_u_207, (copy) v_u_18, (copy) v_u_5, (ref) v_u_208
	v_u_207 = p219
	local v220
	if v_u_207 == nil then
		if v_u_18.Touch then
			v220 = false
		else
			local function v221()
				-- upvalues: (ref) v_u_5
				return v_u_5.PreferredInput == Enum.PreferredInput.Gamepad
			end
			local v222, v223 = pcall(v221)
			v220 = not (v222 and v223) and (not v_u_208 and v_u_18.TenFoot)
			if v220 then
				v220 = not v_u_5.KeyboardEnabled
			end
		end
	else
		v220 = v_u_207
	end
	if v220 ~= v_u_18.Gamepad then
		v_u_18.Gamepad = v220
		v_u_18.GamepadChanged:Fire(v220)
	end
end
local v224, v225 = pcall(function()
	-- upvalues: (copy) v_u_6
	return v_u_6:IsTenFootInterface()
end)
local v226 = v224
if v226 then
	v226 = v225 == true
end
v_u_18.TenFoot = v226
function v_u_18.SetDebugTenFoot(p227) -- name: SetDebugTenFoot
	-- upvalues: (copy) v_u_18, (copy) v_u_189, (ref) v_u_207, (copy) v_u_5, (ref) v_u_208
	if p227 ~= v_u_18.TenFoot then
		v_u_18.TenFoot = p227
		v_u_189()
		local v228
		if v_u_207 == nil then
			if v_u_18.Touch then
				v228 = false
			else
				local function v229()
					-- upvalues: (ref) v_u_5
					return v_u_5.PreferredInput == Enum.PreferredInput.Gamepad
				end
				local v230, v231 = pcall(v229)
				v228 = not (v230 and v231) and (not v_u_208 and v_u_18.TenFoot)
				if v228 then
					v228 = not v_u_5.KeyboardEnabled
				end
			end
		else
			v228 = v_u_207
		end
		if v228 ~= v_u_18.Gamepad then
			v_u_18.Gamepad = v228
			v_u_18.GamepadChanged:Fire(v228)
		end
		v_u_18.TouchChanged:Fire(v_u_18.Touch)
	end
end
if v_u_207 == nil then
	if v_u_18.Touch then
		v_u_207 = false
	else
		local v232, v233 = pcall(function()
			-- upvalues: (copy) v_u_5
			return v_u_5.PreferredInput == Enum.PreferredInput.Gamepad
		end)
		v_u_207 = not (v232 and v233) and (not v_u_208 and v_u_18.TenFoot)
		if v_u_207 then
			v_u_207 = not v_u_5.KeyboardEnabled
		end
	end
end
v_u_18.Gamepad = v_u_207
function v_u_18.SetDebugDevice(p234, p235) -- name: SetDebugDevice
	-- upvalues: (copy) v_u_18, (ref) v_u_204, (ref) v_u_205, (copy) v_u_5, (copy) v_u_158, (ref) v_u_203, (copy) v_u_161, (copy) v_u_189
	v_u_18.DebugDevice = p234
	v_u_204 = v_u_204 + 1
	v_u_205 = nil
	local v236
	if p234 then
		v236 = p235 ~= false
	elseif v_u_5.TouchEnabled then
		local v237 = v_u_5.TouchEnabled
		if v237 then
			local v238 = v_u_5.KeyboardEnabled
			if v238 then
				v238 = v_u_5.MouseEnabled
			end
			v237 = not v238
		end
		if v237 then
			v236 = true
		else
			v236 = v_u_158()
			if v236 == nil then
				if v_u_203 == nil then
					v_u_203 = v_u_161(v_u_5:GetLastInputType()) == true
				end
				v236 = v_u_203
			end
		end
	else
		v236 = false
	end
	if v236 == v_u_18.Touch then
		v_u_189()
		return
	elseif v236 ~= v_u_18.Touch then
		v_u_18.Touch = v236
		v_u_189()
		v_u_18.TouchChanged:Fire(v236)
	end
end
local v_u_239 = nil
local function v241() -- name: hookCamera
	-- upvalues: (ref) v_u_239, (copy) v_u_3, (copy) v_u_189
	if v_u_239 then
		v_u_239:Disconnect()
	end
	local v240 = v_u_3.CurrentCamera
	if v240 then
		v_u_239 = v240:GetPropertyChangedSignal("ViewportSize"):Connect(v_u_189)
	end
	v_u_189()
end
v_u_3:GetPropertyChangedSignal("CurrentCamera"):Connect(v241)
if v_u_239 then
	v_u_239:Disconnect()
end
local v242 = v_u_3.CurrentCamera
if v242 then
	v_u_239 = v242:GetPropertyChangedSignal("ViewportSize"):Connect(v_u_189)
end
v_u_189()
local v_u_243 = {}
v_u_18.TouchChanged:Connect(function(p244)
	-- upvalues: (copy) v_u_243, (copy) v_u_18
	for v245 in v_u_243 do
		local v246
		if p244 or v_u_18.TenFoot then
			v246 = Enum.ScreenInsets.DeviceSafeInsets
		else
			v246 = Enum.ScreenInsets.None
		end
		v245.ScreenInsets = v246
	end
end)
function v_u_18.Screen(p247, p248, p249, p250) -- name: Screen
	-- upvalues: (copy) v_u_18, (copy) v_u_243, (copy) v_u_177
	local v251
	if p250 == nil then
		v251 = false
	else
		v251 = p250.fullBleed == true
	end
	local v_u_252 = v_u_18.new("ScreenGui", {
		["Name"] = nil,
		["DisplayOrder"] = nil,
		["ResetOnSpawn"] = false,
		["IgnoreGuiInset"] = true,
		["ZIndexBehavior"] = nil,
		["Name"] = p247,
		["DisplayOrder"] = p248,
		["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling
	})
	local v253
	if (v_u_18.Touch or v_u_18.TenFoot) and not v251 then
		v253 = Enum.ScreenInsets.DeviceSafeInsets
	else
		v253 = Enum.ScreenInsets.None
	end
	v_u_252.ScreenInsets = v253
	if not v251 then
		v_u_243[v_u_252] = true
		v_u_252.Destroying:Connect(function()
			-- upvalues: (ref) v_u_243, (copy) v_u_252
			v_u_243[v_u_252] = nil
		end)
	end
	local v254 = v_u_18.new("Frame", {
		["Name"] = "Canvas",
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_252
	})
	local v255 = v_u_18.new("UIScale", {
		["Name"] = "CanvasScale",
		["Parent"] = nil,
		["Parent"] = v254
	})
	local v256 = v_u_177
	table.insert(v256, {
		["frame"] = v254,
		["scale"] = v255
	})
	v255.Scale = v_u_18.Scale
	v254.Size = UDim2.fromScale(1 / v_u_18.Scale, 1 / v_u_18.Scale)
	v_u_252.Parent = p249
	return v_u_252, v254
end
function v_u_18.CanvasSize() -- name: CanvasSize
	-- upvalues: (copy) v_u_18, (copy) v_u_3, (copy) v_u_7
	local v257 = v_u_18.DebugDevice
	if v257 then
		return v257.rect / v257.scale
	end
	local v258 = v_u_3.CurrentCamera
	return (v258 and v258.ViewportSize or v_u_7.DesignSize) / v_u_18.Scale
end
v_u_18.TopInsetChanged = v_u_9.new()
function v_u_18.TopInset() -- name: TopInset
	-- upvalues: (copy) v_u_18, (copy) v_u_6
	local v259 = v_u_18.DebugDevice
	if v259 then
		return (v259.topInset or 60) + 4
	end
	local function v260()
		-- upvalues: (ref) v_u_6
		return v_u_6.TopbarInset
	end
	local v261, v262 = pcall(v260)
	local v263 = not (v261 and v262) and 58 or v262.Max.Y
	local v264 = v263 <= 0 and 58 or v263
	local v265 = v_u_18.Scale
	local v266 = v264 / math.max(v265, 0.01)
	return math.ceil(v266) + 4
end
function v_u_18.TopCentreY(p267) -- name: TopCentreY
	-- upvalues: (copy) v_u_18, (copy) v_u_6, (copy) v_u_3
	if v_u_18.DebugDevice then
		return v_u_18.TopInset()
	end
	local function v268()
		-- upvalues: (ref) v_u_6
		return v_u_6.TopbarInset
	end
	local v269, v270 = pcall(v268)
	if not v269 or (not v270 or v270.Width <= 0) then
		return v_u_18.TopInset()
	end
	local v271 = v_u_3.CurrentCamera
	local v272 = not v271 and 0 or v271.ViewportSize.X
	local v273 = v_u_18.Scale
	local v274 = p267 * math.max(v273, 0.01) / 2 + 2
	local v275 = v272 / 2
	return v270.Min.X + v_u_18.TopbarReserved + 8 <= v275 - v274 and v275 + v274 <= v270.Max.X and 6 or v_u_18.TopInset()
end
v_u_18.TopbarReserved = 0
pcall(function()
	-- upvalues: (copy) v_u_6, (copy) v_u_18
	v_u_6:GetPropertyChangedSignal("TopbarInset"):Connect(function()
		-- upvalues: (ref) v_u_18
		v_u_18.TopInsetChanged:Fire()
	end)
end)
v_u_18.ScaleChanged:Connect(function()
	-- upvalues: (copy) v_u_18
	v_u_18.TopInsetChanged:Fire()
end)
function v_u_18.OnResize(p_u_276) -- name: OnResize
	-- upvalues: (copy) v_u_18
	local v_u_277 = false
	v_u_18.ScaleChanged:Connect(function()
		-- upvalues: (ref) v_u_277, (copy) p_u_276
		if not v_u_277 then
			v_u_277 = true
			task.defer(function()
				-- upvalues: (ref) v_u_277, (ref) p_u_276
				v_u_277 = false
				p_u_276()
			end)
		end
	end)
end
v_u_18.ChatChanged = v_u_9.new()
v_u_18.DebugChatRect = nil
local v_u_278 = nil
local function v_u_294(p279, p280, p281) -- name: unionRect
	if p281.X < 2 or p281.Y < 2 then
		return p279
	end
	if not p279 then
		return Rect.new(p280, p280 + p281)
	end
	local v282 = Rect.new
	local v283 = p279.Min.X
	local v284 = p280.X
	local v285 = math.min(v283, v284)
	local v286 = p279.Min.Y
	local v287 = p280.Y
	local v288 = math.min(v286, v287)
	local v289 = p279.Max.X
	local v290 = p280.X + p281.X
	local v291 = math.max(v289, v290)
	local v292 = p279.Max.Y
	local v293 = p280.Y + p281.Y
	return v282(v285, v288, v291, (math.max(v292, v293)))
end
local function v_u_306() -- name: readChatRect
	-- upvalues: (copy) v_u_18, (copy) v_u_294
	if v_u_18.DebugChatRect then
		return v_u_18.DebugChatRect
	end
	local v_u_295 = game:GetService("StarterGui")
	if not v_u_295:GetCoreGuiEnabled(Enum.CoreGuiType.Chat) then
		return nil
	end
	local v296, v297 = pcall(function()
		-- upvalues: (copy) v_u_295
		return v_u_295:GetCore("ChatActive")
	end)
	if v296 and v297 == false then
		return nil
	end
	local v298 = game:GetService("TextChatService")
	local v299 = nil
	local v300 = v298:FindFirstChildOfClass("ChatWindowConfiguration")
	if v300 and v300.Enabled then
		v299 = v_u_294(v299, v300.AbsolutePosition, v300.AbsoluteSize)
	end
	local v301 = v298:FindFirstChildOfClass("ChatInputBarConfiguration")
	if v301 and v301.Enabled then
		v299 = v_u_294(v299, v301.AbsolutePosition, v301.AbsoluteSize)
	end
	if v299 then
		return v299
	end
	local v302 = game:GetService("Players").LocalPlayer
	if v302 then
		v302 = v302:FindFirstChildOfClass("PlayerGui")
	end
	if v302 then
		v302 = v302:FindFirstChild("Chat")
	end
	if not (v302 and (v302:IsA("ScreenGui") and v302.Enabled)) then
		return nil
	end
	local v303 = v302:FindFirstChild("Frame")
	if not (v303 and (v303:IsA("GuiObject") and v303.Visible)) then
		return nil
	end
	local v304 = nil
	for _, v305 in v303:GetChildren() do
		if not (v305:IsA("GuiObject") and (v305.Visible and string.find(v305.Name, "ParentFrame", 1, true))) then
			continue
		end
		v304 = v_u_294(v304, v305.AbsolutePosition, v305.AbsoluteSize)
	end
	return v304
end
local function v_u_314(p307, p308) -- name: sameRect
	if p307 == nil or p308 == nil then
		return p307 == p308
	end
	local v309 = p307.Min.X - p308.Min.X
	local v310
	if math.abs(v309) < 2 then
		local v311 = p307.Min.Y - p308.Min.Y
		if math.abs(v311) < 2 then
			local v312 = p307.Max.X - p308.Max.X
			if math.abs(v312) < 2 then
				local v313 = p307.Max.Y - p308.Max.Y
				v310 = math.abs(v313) < 2
			else
				v310 = false
			end
		else
			v310 = false
		end
	else
		v310 = false
	end
	return v310
end
local v_u_315 = 0
v_u_4.Heartbeat:Connect(function(p316)
	-- upvalues: (ref) v_u_315, (copy) v_u_306, (copy) v_u_314, (ref) v_u_278, (copy) v_u_18
	v_u_315 = v_u_315 + p316
	if v_u_315 >= 0.2 then
		v_u_315 = 0
		local v317 = v_u_306
		local v318, v319 = pcall(v317)
		if not v318 then
			v319 = nil
		end
		if not v_u_314(v319, v_u_278) then
			v_u_278 = v319
			v_u_18.ChatChanged:Fire(v319)
		end
	end
end)
function v_u_18.ChatRect() -- name: ChatRect
	-- upvalues: (ref) v_u_278
	return v_u_278
end
function v_u_18.ChatRectIn(p320) -- name: ChatRectIn
	-- upvalues: (ref) v_u_278, (copy) v_u_18
	local v321 = v_u_278
	if not v321 then
		return nil
	end
	local v322 = p320.AbsolutePosition
	local v323 = v_u_18.Scale
	local v324 = math.max(v323, 0.01)
	return Rect.new((v321.Min - v322) / v324, (v321.Max - v322) / v324)
end
local v_u_325 = Vector2.zero
local function v328(p326) -- name: trackPointer
	-- upvalues: (ref) v_u_325
	local v327 = p326.UserInputType
	if v327 == Enum.UserInputType.Touch or (v327 == Enum.UserInputType.MouseMovement or v327 == Enum.UserInputType.MouseButton1) then
		v_u_325 = Vector2.new(p326.Position.X, p326.Position.Y)
	end
end
v_u_5.InputBegan:Connect(v328)
v_u_5.InputChanged:Connect(v328)
function v_u_18.PointerAbs() -- name: PointerAbs
	-- upvalues: (ref) v_u_325
	return v_u_325
end
function v_u_18.Panel(p329) -- name: Panel
	-- upvalues: (copy) v_u_16, (copy) v_u_18, (copy) v_u_7
	local v330 = table.clone(p329)
	local v331 = v330.Radius
	local v332 = v330.StrokeColor or v_u_16.Stroke
	local v333 = v330.StrokeTransparency or 0.9
	local v334 = v330.NoStroke
	local v335 = v330.TopColor or v_u_16.Panel
	local v336 = v330.BottomColor or v_u_16.PanelLo
	v330.Radius = nil
	v330.Trim = nil
	v330.StrokeColor = nil
	v330.StrokeTransparency = nil
	v330.NoStroke = nil
	v330.TopColor = nil
	v330.BottomColor = nil
	local v337 = v330.StrokeThickness or 1
	v330.StrokeThickness = nil
	v330.BackgroundTransparency = v330.BackgroundTransparency or 0.12
	v330.BackgroundColor3 = Color3.new(1, 1, 1)
	local v338 = v_u_18.new("Frame", v330)
	v_u_18.Corner(v331 or v_u_7.Radius.Large).Parent = v338
	v_u_18.Gradient(v335, v336, 90).Parent = v338
	if not v334 then
		v_u_18.Stroke(v332, v337, v333).Parent = v338
	end
	return v338
end
function v_u_18.TeethTrim(p339) -- name: TeethTrim
	-- upvalues: (copy) v_u_18
	return v_u_18.new("Frame", {
		["Name"] = "Trim",
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(0, 0),
		["Parent"] = p339.Parent
	})
end
function v_u_18.DropShadow(p340, p341, p342, p343) -- name: DropShadow
	-- upvalues: (copy) v_u_18, (copy) v_u_16
	local v344 = p343 or 0.5
	local v345 = p342 or 6
	local v346 = p341 or 14
	for v347, v348 in { 0, 4, 9 } do
		v_u_18.new("Frame", {
			["Name"] = "Shadow" .. v347,
			["BackgroundColor3"] = v_u_16.Void,
			["BackgroundTransparency"] = 1 - v344 / (v347 * 1.6),
			["Size"] = UDim2.new(1, v348 * 2, 1, v348 * 2),
			["Position"] = UDim2.fromOffset(-v348, -v348 + v345),
			["ZIndex"] = 0,
			v_u_18.Corner(v346 + v348),
			["Parent"] = p340
		})
	end
end
function v_u_18.Bar(p349) -- name: Bar
	-- upvalues: (copy) v_u_18, (copy) v_u_16, (copy) v_u_7
	local v350 = v_u_18.new("Frame", {
		["Name"] = p349.Name or "Bar",
		["Size"] = p349.Size or UDim2.fromOffset(200, 10),
		["Position"] = p349.Position or UDim2.new(),
		["AnchorPoint"] = p349.AnchorPoint or Vector2.zero,
		["BackgroundColor3"] = p349.TrackColor or v_u_16.Inset,
		["BackgroundTransparency"] = p349.TrackTransparency or 0.2,
		["LayoutOrder"] = p349.LayoutOrder or 0,
		["ClipsDescendants"] = true,
		v_u_18.Corner(p349.Radius or v_u_7.Radius.Pill),
		["Parent"] = p349.Parent
	})
	if p349.Stroke ~= false then
		v_u_18.Stroke(v_u_16.Stroke, 1.5, 0.8).Parent = v350
	end
	local v_u_351 = v_u_18.new("Frame", {
		["Name"] = "Fill",
		["Size"] = UDim2.fromScale(p349.Value or 0, 1),
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		v_u_18.Corner(p349.Radius or v_u_7.Radius.Pill),
		["Parent"] = v350
	})
	local v_u_352 = v_u_18.Gradient(v_u_7.Lighten(p349.Color or v_u_16.Accent, 0.2), p349.Color or v_u_16.Accent, 90)
	v_u_352.Parent = v_u_351
	local v_u_353 = nil
	return {
		["Frame"] = v350,
		["Fill"] = v_u_351,
		["Set"] = function(p354, p355, p356) -- name: Set
			-- upvalues: (ref) v_u_353, (copy) v_u_351, (ref) v_u_18, (ref) v_u_7
			local v357 = math.clamp(p354, 0, 1)
			if v_u_353 then
				v_u_353:Cancel()
				v_u_353 = nil
			end
			if p355 then
				v_u_351.Size = UDim2.fromScale(v357, 1)
			else
				v_u_353 = v_u_18.Tween(v_u_351, p356 or v_u_7.Tween.Smooth, {
					["Size"] = UDim2.fromScale(v357, 1)
				})
			end
		end,
		["SetColor"] = function(p358) -- name: SetColor
			-- upvalues: (copy) v_u_352, (ref) v_u_7
			v_u_352.Color = ColorSequence.new(v_u_7.Lighten(p358, 0.2), p358)
		end
	}
end
local v_u_359 = {
	["Primary"] = {
		["top"] = Color3.fromRGB(64, 168, 255),
		["bottom"] = Color3.fromRGB(28, 132, 246),
		["lip"] = Color3.fromRGB(12, 70, 160),
		["stroke"] = Color3.fromRGB(150, 210, 255),
		["text"] = v_u_16.Text
	},
	["Success"] = {
		["top"] = Color3.fromRGB(84, 224, 124),
		["bottom"] = Color3.fromRGB(40, 184, 92),
		["lip"] = Color3.fromRGB(16, 100, 48),
		["stroke"] = Color3.fromRGB(170, 255, 200),
		["text"] = v_u_16.Text
	},
	["Danger"] = {
		["top"] = Color3.fromRGB(255, 92, 98),
		["bottom"] = Color3.fromRGB(226, 52, 62),
		["lip"] = Color3.fromRGB(120, 18, 28),
		["stroke"] = Color3.fromRGB(255, 170, 176),
		["text"] = v_u_16.Text
	},
	["Dark"] = {
		["top"] = Color3.fromRGB(44, 48, 60),
		["bottom"] = Color3.fromRGB(34, 37, 47),
		["lip"] = Color3.fromRGB(16, 18, 24),
		["stroke"] = Color3.fromRGB(96, 104, 124),
		["text"] = v_u_16.Text
	},
	["Light"] = {
		["top"] = Color3.fromRGB(250, 251, 253),
		["bottom"] = Color3.fromRGB(226, 230, 238),
		["lip"] = Color3.fromRGB(150, 156, 172),
		["stroke"] = Color3.fromRGB(255, 255, 255),
		["text"] = v_u_16.TextDark
	},
	["Disabled"] = {
		["top"] = Color3.fromRGB(46, 49, 58),
		["bottom"] = Color3.fromRGB(38, 41, 49),
		["lip"] = Color3.fromRGB(20, 22, 28),
		["stroke"] = Color3.fromRGB(70, 75, 88),
		["text"] = Color3.fromRGB(130, 136, 150)
	}
}
v_u_359.Ochre = v_u_359.Primary
v_u_359.Jade = v_u_359.Success
v_u_359.Ally = v_u_359.Primary
v_u_18.ButtonStyles = v_u_359
function v_u_18.Button(p_u_360) -- name: Button
	-- upvalues: (copy) v_u_359, (copy) v_u_18, (copy) v_u_17, (copy) v_u_16, (copy) v_u_9, (copy) v_u_7, (copy) v_u_8
	local v361 = p_u_360.Style or "Primary"
	local v362 = v_u_359[v361] or v_u_359.Primary
	local v363 = p_u_360.Radius or 12
	local v_u_364 = v_u_18.new("TextButton", {
		["Name"] = nil,
		["Size"] = nil,
		["Position"] = nil,
		["AnchorPoint"] = nil,
		["LayoutOrder"] = nil,
		["ZIndex"] = nil,
		["Visible"] = nil,
		["Selectable"] = true,
		["Name"] = p_u_360.Name or "Button",
		["Size"] = p_u_360.Size or UDim2.fromOffset(220, 58),
		["Position"] = p_u_360.Position or UDim2.new(),
		["AnchorPoint"] = p_u_360.AnchorPoint or Vector2.zero,
		["LayoutOrder"] = p_u_360.LayoutOrder or 0,
		["ZIndex"] = p_u_360.ZIndex or 1,
		["Visible"] = p_u_360.Visible ~= false
	})
	local v365 = v_u_18.new("Frame", {
		["Name"] = "Scaler",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundTransparency"] = 1,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_364
	})
	local v_u_366 = v365:FindFirstChild("HoverScale")
	if not (v_u_366 and v_u_366:IsA("UIScale")) then
		v_u_366 = Instance.new("UIScale")
		v_u_366.Name = "HoverScale"
		v_u_366.Parent = v365
	end
	local v_u_367 = v_u_18.new("Frame", {
		["Name"] = "Lip",
		["BackgroundColor3"] = v362.lip,
		["Size"] = UDim2.new(1, 0, 1, -3),
		["Position"] = UDim2.fromOffset(0, 3),
		v_u_18.Corner(v363),
		["Parent"] = v365
	})
	local v_u_368 = v_u_18.new("Frame", {
		["Name"] = "Face",
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Size"] = UDim2.new(1, 0, 1, -3),
		v_u_18.Corner(v363),
		["Parent"] = v365
	})
	local v_u_369 = v_u_18.Gradient(v362.top, v362.bottom, 90)
	v_u_369.Parent = v_u_368
	local v_u_370 = v_u_18.Stroke(v362.stroke, 1, 0.6)
	v_u_370.Parent = v_u_368
	local v_u_371 = v_u_18.new("Frame", {
		["Name"] = "Glow",
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["BackgroundTransparency"] = 1,
		["Size"] = UDim2.fromScale(1, 1),
		v_u_18.Corner(v363),
		["Parent"] = v_u_368
	})
	local v372 = v_u_18.new("Frame", {
		["Name"] = "Content",
		["Size"] = UDim2.fromScale(1, 1),
		v_u_18.List(Enum.FillDirection.Horizontal, p_u_360.Gap or 8, Enum.HorizontalAlignment.Center, Enum.VerticalAlignment.Center),
		["Parent"] = v_u_368
	})
	if p_u_360.Icon then
		p_u_360.Icon.LayoutOrder = 0
		p_u_360.Icon.Parent = v372
	end
	local v_u_373 = v_u_18.new("TextLabel", {
		["Name"] = "Label",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["Text"] = p_u_360.Text or "BUTTON",
		["FontFace"] = p_u_360.Font or v_u_17.Display,
		["TextSize"] = p_u_360.TextSize or 22,
		["TextColor3"] = v362.text,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.new(0, 0, 1, 0),
		["Parent"] = v372
	})
	local v_u_374 = v_u_18.TextStroke(v_u_16.Void, 1, 1)
	v_u_374.Parent = v_u_373
	local v_u_375 = {
		["Instance"] = v_u_364,
		["Face"] = v_u_368,
		["Label"] = v_u_373,
		["Content"] = v372,
		["Activated"] = v_u_9.new(),
		["Enabled"] = p_u_360.Enabled ~= false,
		["Style"] = v361
	}
	local v_u_376 = false
	local v_u_377 = false
	local function v_u_380() -- name: refresh
		-- upvalues: (ref) v_u_377, (ref) v_u_18, (copy) v_u_368, (ref) v_u_7, (ref) v_u_376, (copy) v_u_375, (copy) v_u_366, (copy) v_u_371
		local v378 = v_u_377 and 2 or 0
		v_u_18.Tween(v_u_368, v_u_7.Tween.Instant, {
			["Position"] = UDim2.fromOffset(0, v378)
		})
		local v379 = v_u_377 and 0.96 or (v_u_376 and v_u_375.Enabled and 1.04 or 1)
		v_u_18.Tween(v_u_366, v_u_7.Tween.PopSmall, {
			["Scale"] = v379
		})
		v_u_18.Tween(v_u_371, v_u_7.Tween.Fast, {
			["BackgroundTransparency"] = v_u_376 and v_u_375.Enabled and 0.86 or 1
		})
	end
	v_u_364.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_376, (copy) v_u_375, (ref) v_u_18, (ref) v_u_8, (copy) v_u_380
		v_u_376 = true
		if v_u_375.Enabled and not v_u_18.Touch then
			v_u_8.Play("Hover")
		end
		v_u_380()
	end)
	v_u_364.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_376, (ref) v_u_377, (copy) v_u_380
		v_u_376 = false
		v_u_377 = false
		v_u_380()
	end)
	v_u_364.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_377, (copy) v_u_380
		v_u_377 = true
		v_u_380()
	end)
	v_u_364.MouseButton1Up:Connect(function()
		-- upvalues: (ref) v_u_377, (copy) v_u_380
		v_u_377 = false
		v_u_380()
	end)
	v_u_364.Activated:Connect(function()
		-- upvalues: (copy) v_u_375, (ref) v_u_8, (ref) v_u_18, (copy) v_u_364, (copy) p_u_360
		if v_u_375.Enabled then
			if p_u_360.Sound ~= false then
				v_u_8.Play(p_u_360.Sound or "Click")
			end
			v_u_375.Activated:Fire()
			if p_u_360.OnClick then
				task.spawn(p_u_360.OnClick)
			end
		else
			v_u_8.Play("Error")
			v_u_18.Shake(v_u_364, 5)
			if p_u_360.OnDisabledClick then
				task.spawn(p_u_360.OnDisabledClick)
			end
		end
	end)
	function v_u_375.SetText(_, p381) -- name: SetText
		-- upvalues: (copy) v_u_373
		v_u_373.Text = p381
	end
	function v_u_375.SetEnabled(p382, p383) -- name: SetEnabled
		-- upvalues: (copy) v_u_375, (ref) v_u_359, (copy) v_u_369, (copy) v_u_367, (copy) v_u_370, (copy) v_u_373, (copy) v_u_374, (copy) v_u_380
		p382.Enabled = p383
		local v384 = v_u_359[not v_u_375.Enabled and "Disabled" or v_u_375.Style] or v_u_359.Primary
		v_u_369.Color = ColorSequence.new(v384.top, v384.bottom)
		v_u_367.BackgroundColor3 = v384.lip
		v_u_370.Color = v384.stroke
		v_u_373.TextColor3 = v384.text
		v_u_374.Transparency = 1
		v_u_380()
	end
	function v_u_375.SetStyle(p385, p386) -- name: SetStyle
		-- upvalues: (copy) v_u_375, (ref) v_u_359, (copy) v_u_369, (copy) v_u_367, (copy) v_u_370, (copy) v_u_373, (copy) v_u_374
		p385.Style = p386
		local v387 = v_u_359[not v_u_375.Enabled and "Disabled" or v_u_375.Style] or v_u_359.Primary
		v_u_369.Color = ColorSequence.new(v387.top, v387.bottom)
		v_u_367.BackgroundColor3 = v387.lip
		v_u_370.Color = v387.stroke
		v_u_373.TextColor3 = v387.text
		v_u_374.Transparency = 1
	end
	local v388 = v_u_359[not v_u_375.Enabled and "Disabled" or v_u_375.Style] or v_u_359.Primary
	v_u_369.Color = ColorSequence.new(v388.top, v388.bottom)
	v_u_367.BackgroundColor3 = v388.lip
	v_u_370.Color = v388.stroke
	v_u_373.TextColor3 = v388.text
	v_u_374.Transparency = 1
	if p_u_360.Parent then
		v_u_364.Parent = p_u_360.Parent
	end
	return v_u_375
end
function v_u_18.IconButton(p_u_389) -- name: IconButton
	-- upvalues: (copy) v_u_18, (copy) v_u_16, (copy) v_u_17, (copy) v_u_8, (copy) v_u_7
	local v390 = p_u_389.Size or UDim2.fromOffset(44, 44)
	local v_u_391 = v_u_18.new("TextButton", {
		["Name"] = p_u_389.Name or "IconButton",
		["Size"] = v390,
		["Position"] = p_u_389.Position or UDim2.new(),
		["AnchorPoint"] = p_u_389.AnchorPoint or Vector2.zero,
		["BackgroundColor3"] = p_u_389.Color or v_u_16.Raised,
		["BackgroundTransparency"] = p_u_389.Transparency or 0.1,
		["Text"] = p_u_389.IconName and "" or (p_u_389.Text or ""),
		["TextColor3"] = p_u_389.TextColor or v_u_16.Text,
		["FontFace"] = p_u_389.Font or v_u_17.Display,
		["TextSize"] = p_u_389.TextSize or 26,
		["ZIndex"] = p_u_389.ZIndex or 1,
		["LayoutOrder"] = p_u_389.LayoutOrder or 0,
		["Visible"] = p_u_389.Visible ~= false,
		v_u_18.Corner(p_u_389.Radius or 10),
		["Parent"] = p_u_389.Parent
	})
	v_u_18.Stroke(p_u_389.StrokeColor or v_u_16.Stroke, 1, p_u_389.StrokeTransparency or 0.85).Parent = v_u_391
	if p_u_389.IconName then
		local v392 = v390.Y.Offset * (p_u_389.IconScale or 0.5)
		local v393 = math.floor(v392)
		v_u_18.Icon(p_u_389.IconName, v393, p_u_389.TextColor or v_u_16.Text, {
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["ZIndex"] = p_u_389.ZIndex,
			["Parent"] = v_u_391
		})
	end
	local v_u_394 = v_u_391:FindFirstChild("HoverScale")
	if not (v_u_394 and v_u_394:IsA("UIScale")) then
		v_u_394 = Instance.new("UIScale")
		v_u_394.Name = "HoverScale"
		v_u_394.Parent = v_u_391
	end
	local v_u_395 = v_u_391.BackgroundColor3
	v_u_391.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_18, (ref) v_u_8, (copy) v_u_394, (ref) v_u_7, (copy) v_u_391, (copy) p_u_389, (copy) v_u_395
		if not v_u_18.Touch then
			v_u_8.Play("Hover")
		end
		v_u_18.Tween(v_u_394, v_u_7.Tween.PopSmall, {
			["Scale"] = 1.08
		})
		v_u_18.Tween(v_u_391, v_u_7.Tween.Fast, {
			["BackgroundColor3"] = p_u_389.HoverColor or v_u_7.Lighten(v_u_395, 0.15)
		})
	end)
	v_u_391.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_18, (copy) v_u_394, (ref) v_u_7, (copy) v_u_391, (copy) v_u_395
		v_u_18.Tween(v_u_394, v_u_7.Tween.PopSmall, {
			["Scale"] = 1
		})
		local v396 = {
			["BackgroundColor3"] = v_u_395
		}
		v_u_18.Tween(v_u_391, v_u_7.Tween.Fast, v396)
	end)
	v_u_391.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_18, (copy) v_u_394, (ref) v_u_7
		v_u_18.Tween(v_u_394, v_u_7.Tween.Instant, {
			["Scale"] = 0.9
		})
	end)
	v_u_391.MouseButton1Up:Connect(function()
		-- upvalues: (ref) v_u_18, (copy) v_u_394, (ref) v_u_7
		v_u_18.Tween(v_u_394, v_u_7.Tween.PopSmall, {
			["Scale"] = 1
		})
	end)
	v_u_391.Activated:Connect(function()
		-- upvalues: (copy) p_u_389, (ref) v_u_8
		if p_u_389.Sound ~= false then
			v_u_8.Play(p_u_389.Sound or "Click")
		end
		if p_u_389.OnClick then
			task.spawn(p_u_389.OnClick)
		end
	end)
	return v_u_391
end
local v_u_397 = Color3.fromRGB(58, 63, 78)
function v_u_18.Switch(p398) -- name: Switch
	-- upvalues: (copy) v_u_18, (copy) v_u_397, (copy) v_u_7, (copy) v_u_16
	local v399 = p398 or {}
	local v400 = v399.Width or 60
	local v401 = v399.Height
	if not v401 then
		local v402 = v400 * 0.53 + 0.5
		v401 = math.floor(v402)
	end
	local v403 = v401 * 0.12 + 0.5
	local v404 = math.floor(v403)
	local v_u_405 = math.max(3, v404)
	local v_u_406 = v401 - v_u_405 * 2
	local v_u_407 = v_u_18.new("Frame", {
		["Name"] = v399.Name or "Switch",
		["Size"] = UDim2.fromOffset(v400, v401),
		["Position"] = v399.Position or UDim2.new(),
		["AnchorPoint"] = v399.AnchorPoint or Vector2.zero,
		["LayoutOrder"] = v399.LayoutOrder or 0,
		["ZIndex"] = v399.ZIndex or 1,
		["BackgroundColor3"] = v_u_397,
		v_u_18.Corner(v_u_7.Radius.Pill),
		["Parent"] = v399.Parent
	})
	local v_u_408 = v_u_18.Stroke(v_u_16.Stroke, 1, 0.88)
	v_u_408.Parent = v_u_407
	local v_u_409 = v_u_18.new("Frame", {
		["Name"] = "Knob",
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, v_u_405, 0.5, 0),
		["Size"] = UDim2.fromOffset(v_u_406, v_u_406),
		["BackgroundColor3"] = v_u_16.Bone,
		["ZIndex"] = (v399.ZIndex or 1) + 1,
		v_u_18.Corner(v_u_7.Radius.Pill),
		v_u_18.Stroke(v_u_16.Void, 1, 0.8),
		["Parent"] = v_u_407
	})
	local v410 = v_u_18.Icon
	local v411 = v_u_406 * 0.56
	local v412 = math.floor(v411)
	local v413 = v_u_16.AccentDark
	local v414 = {
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5)
	}
	local v415 = v_u_406 * 0.12 + 0.5
	local v416 = math.floor(v415)
	v414.Thickness = math.max(2, v416)
	v414.ZIndex = (v399.ZIndex or 1) + 2
	v414.Parent = v_u_409
	local v_u_417 = v410("check", v412, v413, v414)
	v_u_417.Visible = false
	local v425 = {
		["Instance"] = nil,
		["On"] = false,
		["Instance"] = v_u_407,
		["Set"] = function(p418, p419, p420) -- name: Set
			-- upvalues: (copy) v_u_405, (copy) v_u_406, (ref) v_u_16, (ref) v_u_397, (copy) v_u_409, (copy) v_u_407, (copy) v_u_408, (copy) v_u_417, (ref) v_u_18, (ref) v_u_7
			local v421 = p419 ~= p418.On
			p418.On = p419
			local v422
			if p419 then
				v422 = UDim2.new(1, -(v_u_405 + v_u_406), 0.5, 0)
			else
				v422 = UDim2.new(0, v_u_405, 0.5, 0)
			end
			local v423
			if p419 then
				v423 = v_u_16.Accent
			else
				v423 = v_u_397
			end
			local v424 = p419 and 0.7 or 0.88
			if p420 then
				v_u_409.Position = v422
				v_u_407.BackgroundColor3 = v423
				v_u_408.Transparency = v424
				v_u_417.Visible = p419
			else
				v_u_18.Tween(v_u_409, v_u_7.Tween.Smooth, {
					["Position"] = v422
				})
				v_u_18.Tween(v_u_407, v_u_7.Tween.Fast, {
					["BackgroundColor3"] = v423
				})
				v_u_18.Tween(v_u_408, v_u_7.Tween.Fast, {
					["Transparency"] = v424
				})
				v_u_417.Visible = p419
				if p419 and v421 then
					v_u_18.Pop(v_u_417, 0.4, v_u_7.Tween.PopSmall)
				end
			end
		end
	}
	v425:Set(v399.On == true, true)
	return v425
end
local v_u_426 = {}
local v_u_427 = {}
local v_u_428 = {}
local v_u_429 = nil
v_u_18.TouchChanged:Connect(function()
	-- upvalues: (copy) v_u_426, (ref) v_u_429
	for v430 in v_u_426 do
		v430.Visible = v_u_429(v430)
	end
end)
local v_u_431 = {}
local v_u_432 = {
	[Enum.KeyCode.ButtonSelect] = "VIEW",
	[Enum.KeyCode.ButtonStart] = "MENU",
	[Enum.KeyCode.ButtonA] = "A",
	[Enum.KeyCode.ButtonB] = "B",
	[Enum.KeyCode.ButtonX] = "X",
	[Enum.KeyCode.ButtonY] = "Y",
	[Enum.KeyCode.ButtonL1] = "LB",
	[Enum.KeyCode.ButtonR1] = "RB",
	[Enum.KeyCode.ButtonL2] = "LT",
	[Enum.KeyCode.ButtonR2] = "RT",
	[Enum.KeyCode.ButtonL3] = "LS",
	[Enum.KeyCode.ButtonR3] = "RS"
}
local v_u_433 = {}
local v_u_434 = {}
local v_u_435 = {}
local function v_u_454(p436, p_u_437) -- name: paintPadCap
	-- upvalues: (copy) v_u_18, (copy) v_u_5, (copy) v_u_432, (copy) v_u_434, (copy) v_u_433, (copy) v_u_435
	local v438 = p436:FindFirstChild("Key")
	local v439 = p436:FindFirstChild("Glyph")
	local v440 = p436:FindFirstChild("Mouse")
	if v438 and v439 then
		local v441 = ""
		if v_u_18.Gamepad then
			local function v442()
				-- upvalues: (ref) v_u_5, (copy) p_u_437
				return v_u_5:GetImageForKeyCode(p_u_437.code)
			end
			local v443, v444 = pcall(v442)
			v441 = (not v443 or type(v444) ~= "string") and "" or v444
			if v441 == "" then
				v438.Text = v_u_432[p_u_437.code] or p_u_437.code.Name
			end
		else
			v438.Text = p_u_437.key
		end
		v439.Image = v441
		v439.Visible = v441 ~= ""
		local v445
		if v440 == nil then
			v445 = false
		else
			v445 = v441 == ""
		end
		if v440 then
			v440.Visible = v445
		end
		local v446
		if v441 == "" then
			v446 = not v445
		else
			v446 = false
		end
		v438.Visible = v446
		local v447 = v441 ~= "" and true or v445
		v_u_434[p436] = v447
		local v448 = v447 and 1 or (v_u_433[p436] or 0.25)
		p436.BackgroundTransparency = v448 + (1 - v448) * (v_u_435[p436] or 0)
		local v449 = p436:FindFirstChildOfClass("UIStroke")
		if v449 then
			v449.Enabled = not v447
		end
		local v450 = p436.Size.Y.Offset
		local v451 = UDim2.fromOffset
		local v452
		if v441 == "" then
			if v445 then
				v452 = v450
			else
				local v453 = #v438.Text * (v450 * 0.4) + 12
				v452 = math.max(v450, v453)
			end
		else
			v452 = v450 + 4
		end
		p436.Size = v451(v452, v450)
	end
end
v_u_429 = function(p455) -- name: capVisible
	-- upvalues: (copy) v_u_18, (copy) v_u_431, (copy) v_u_428, (copy) v_u_427
	if v_u_18.Touch then
		return false
	elseif v_u_431[p455] == nil then
		local v456 = not v_u_427[p455]
		if v456 then
			v456 = not v_u_18.Gamepad
		end
		return v456
	elseif v_u_18.Gamepad then
		return not v_u_428[p455]
	else
		return not v_u_427[p455]
	end
end
v_u_18.GamepadChanged:Connect(function()
	-- upvalues: (copy) v_u_431, (copy) v_u_454, (copy) v_u_426, (ref) v_u_429
	for v457, v458 in v_u_431 do
		v_u_454(v457, v458)
	end
	for v459 in v_u_426 do
		v459.Visible = v_u_429(v459)
	end
end)
function v_u_18.KeyCap(p460, p461) -- name: KeyCap
	-- upvalues: (ref) v_u_13, (copy) v_u_18, (copy) v_u_16, (copy) v_u_433, (copy) v_u_434, (copy) v_u_435, (copy) v_u_17, (copy) v_u_426, (copy) v_u_431, (copy) v_u_454, (ref) v_u_429
	local v462 = p461 or {}
	local v463 = v462.Height or 24
	local v464 = v_u_13.Mouse
	local v465
	if type(v464) == "table" then
		if p460 == "M1" then
			v465 = v464.Left
		elseif p460 == "M2" then
			v465 = v464.Right
		else
			v465 = nil
		end
	else
		v465 = nil
	end
	local v466 = v_u_18.new
	local v467 = "Frame"
	local v468 = {
		["Name"] = "KeyCap",
		["Visible"] = not v_u_18.Touch
	}
	local v469 = UDim2.fromOffset
	local v470
	if v465 then
		v470 = v463
	else
		local v471 = #p460 * (v463 * 0.4) + 12
		v470 = math.max(v463, v471)
	end
	v468.Size = v469(v470, v463)
	v468.BackgroundColor3 = v462.Color or v_u_16.Void
	v468.BackgroundTransparency = v462.Transparency or 0.25
	v468.Position = v462.Position or UDim2.new()
	v468.AnchorPoint = v462.AnchorPoint or Vector2.zero
	v468.LayoutOrder = v462.LayoutOrder or 0
	v468.ZIndex = v462.ZIndex or 1
	__set_list(v468, 1, {v_u_18.Corner(v462.Radius or 6), (v_u_18.Stroke(v_u_16.Stroke, 1, 0.75))})
	v468.Parent = v462.Parent
	local v_u_472 = v466(v467, v468)
	v_u_433[v_u_472] = v462.Transparency or 0.25
	v_u_472.Destroying:Connect(function()
		-- upvalues: (ref) v_u_433, (copy) v_u_472, (ref) v_u_434, (ref) v_u_435
		local v473 = v_u_434
		local v474 = v_u_472
		local v475 = v_u_435
		local v476 = v_u_472
		v_u_433[v_u_472] = nil
		v473[v474] = nil
		v475[v476] = nil
	end)
	local v477 = v_u_18.new
	local v478 = "TextLabel"
	local v479 = {
		["Name"] = "Key",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Text"] = p460,
		["FontFace"] = v_u_17.Heavy
	}
	local v480 = v462.TextSize
	if not v480 then
		local v481 = v463 * 0.66
		v480 = math.floor(v481)
	end
	v479.TextSize = v480
	v479.TextColor3 = v_u_16.Text
	v479.Size = UDim2.fromScale(1, 1)
	v479.ZIndex = v462.ZIndex or 1
	v479.Parent = v_u_472
	v477(v478, v479)
	if v465 then
		v_u_18.new("ImageLabel", {
			["Name"] = "Mouse",
			["BackgroundTransparency"] = 1,
			["Image"] = nil,
			["Size"] = nil,
			["Position"] = nil,
			["AnchorPoint"] = nil,
			["ScaleType"] = nil,
			["ZIndex"] = nil,
			["Parent"] = nil,
			["Image"] = v465,
			["Size"] = UDim2.fromOffset(v463 + 10, v463 + 10),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["ScaleType"] = Enum.ScaleType.Fit,
			["ZIndex"] = v462.ZIndex or 1,
			["Parent"] = v_u_472
		})
		v_u_472:FindFirstChild("Key").Visible = false
		v_u_434[v_u_472] = true
		v_u_472.BackgroundTransparency = 1 + 0 * (v_u_435[v_u_472] or 0)
		local v482 = v_u_472:FindFirstChildOfClass("UIStroke")
		if v482 then
			v482.Enabled = false
		end
	end
	if not v462.Managed then
		v_u_426[v_u_472] = true
		v_u_472.Destroying:Connect(function()
			-- upvalues: (ref) v_u_426, (copy) v_u_472
			v_u_426[v_u_472] = nil
		end)
	end
	local v483 = v462.Gamepad
	if typeof(v483) ~= "EnumItem" then
		if not v462.Managed then
			v_u_472.Visible = v_u_429(v_u_472)
		end
		return v_u_472
	end
	v_u_18.new("ImageLabel", {
		["Name"] = "Glyph",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Position"] = nil,
		["AnchorPoint"] = nil,
		["ScaleType"] = nil,
		["ZIndex"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 4, 1, 4),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["ScaleType"] = Enum.ScaleType.Fit,
		["ZIndex"] = v462.ZIndex or 1,
		["Parent"] = v_u_472
	})
	local v484 = {
		["key"] = p460,
		["code"] = v462.Gamepad,
		["width"] = v_u_472.Size.X.Offset
	}
	v_u_431[v_u_472] = v484
	v_u_472.Destroying:Connect(function()
		-- upvalues: (ref) v_u_431, (copy) v_u_472
		v_u_431[v_u_472] = nil
	end)
	v_u_454(v_u_472, v484)
	return v_u_472
end
function v_u_18.SetCapKey(p485, p486) -- name: SetCapKey
	-- upvalues: (copy) v_u_427, (ref) v_u_429, (ref) v_u_13, (copy) v_u_18, (copy) v_u_435, (copy) v_u_431, (copy) v_u_454, (copy) v_u_434, (copy) v_u_433
	if p486 == nil then
		v_u_427[p485] = true
		p485.Visible = v_u_429(p485)
		return
	else
		if v_u_427[p485] then
			v_u_427[p485] = nil
			p485.Visible = v_u_429(p485)
		end
		local v487 = p485.Size.Y.Offset
		local v488 = p485:FindFirstChild("Key")
		local v489 = v_u_13.Mouse
		local v490
		if type(v489) == "table" then
			if p486 == "M1" then
				v490 = v489.Left
			elseif p486 == "M2" then
				v490 = v489.Right
			else
				v490 = nil
			end
		else
			v490 = nil
		end
		local v491 = p485:FindFirstChild("Mouse")
		if v490 then
			(v491 or v_u_18.new("ImageLabel", {
				["Name"] = "Mouse",
				["BackgroundTransparency"] = 1,
				["ImageTransparency"] = nil,
				["Size"] = nil,
				["Position"] = nil,
				["AnchorPoint"] = nil,
				["ScaleType"] = nil,
				["ZIndex"] = nil,
				["Parent"] = nil,
				["ImageTransparency"] = v_u_435[p485] or 0,
				["Size"] = UDim2.fromOffset(v487 + 10, v487 + 10),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["ScaleType"] = Enum.ScaleType.Fit,
				["ZIndex"] = p485.ZIndex,
				["Parent"] = p485
			})).Image = v490
		elseif v491 then
			v491:Destroy()
		end
		if v488 then
			v488.Text = p486
		end
		local v492 = v_u_431[p485]
		if v492 then
			v492.key = p486
			v_u_454(p485, v492)
		else
			if v488 then
				v488.Visible = v490 == nil
			end
			local v493 = v490 ~= nil
			v_u_434[p485] = v493
			local v494 = v493 and 1 or (v_u_433[p485] or 0.25)
			p485.BackgroundTransparency = v494 + (1 - v494) * (v_u_435[p485] or 0)
			local v495 = p485:FindFirstChildOfClass("UIStroke")
			if v495 then
				v495.Enabled = not v493
			end
			local v496 = UDim2.fromOffset
			local v497
			if v490 then
				v497 = v487
			else
				local v498 = #p486 * (v487 * 0.4) + 12
				v497 = math.max(v487, v498)
			end
			p485.Size = v496(v497, v487)
		end
	end
end
function v_u_18.PadCap(p499, p500) -- name: PadCap
	-- upvalues: (copy) v_u_18
	local v501 = table.clone(p500 or {})
	v501.Gamepad = p499
	local v502 = v_u_18.KeyCap("", v501)
	v_u_18.SetCapKey(v502, nil)
	return v502
end
function v_u_18.SetCapFade(p503, p504) -- name: SetCapFade
	-- upvalues: (copy) v_u_435, (copy) v_u_434, (copy) v_u_433
	local v505 = math.clamp(p504, 0, 1)
	local v506 = v_u_435
	local v507
	if v505 > 0 then
		v507 = v505
	else
		v507 = nil
	end
	v506[p503] = v507
	local v508 = v_u_434[p503] == true
	v_u_434[p503] = v508
	local v509 = v508 and 1 or (v_u_433[p503] or 0.25)
	p503.BackgroundTransparency = v509 + (1 - v509) * (v_u_435[p503] or 0)
	local v510 = p503:FindFirstChildOfClass("UIStroke")
	if v510 then
		v510.Enabled = not v508
	end
	local v511 = p503:FindFirstChildOfClass("UIStroke")
	if v511 then
		v511.Transparency = v505 * 0.25 + 0.75
	end
	for _, v512 in p503:GetChildren() do
		if v512:IsA("TextLabel") then
			v512.TextTransparency = v505
		else
			if not v512:IsA("ImageLabel") then
				continue
			end
			v512.ImageTransparency = v505
		end
	end
end
function v_u_18.SetCapPad(p513, p514) -- name: SetCapPad
	-- upvalues: (copy) v_u_431, (copy) v_u_428, (copy) v_u_454, (ref) v_u_429
	local v515 = v_u_431[p513]
	if v515 then
		v_u_428[p513] = not p514 and true or nil
		if p514 then
			v515.code = p514
		end
		v_u_454(p513, v515)
		p513.Visible = v_u_429(p513)
	end
end
function v_u_18.ActionCap(p_u_516, p517) -- name: ActionCap
	-- upvalues: (copy) v_u_10, (copy) v_u_18, (copy) v_u_427, (copy) v_u_428
	local v518 = v_u_10.PadAction(p_u_516) ~= nil
	if v518 then
		p517 = table.clone(p517 or {})
		p517.Gamepad = v_u_10.PadCode(p_u_516) or (p517.Gamepad or Enum.KeyCode.ButtonA)
	end
	local v_u_519 = v_u_18.KeyCap(v_u_10.CapText(p_u_516) or "?", p517)
	v_u_18.SetCapKey(v_u_519, v_u_10.CapText(p_u_516))
	if v518 then
		v_u_18.SetCapPad(v_u_519, v_u_10.PadCode(p_u_516))
	end
	local v_u_521 = v_u_10.Changed:Connect(function(p520)
		-- upvalues: (copy) p_u_516, (ref) v_u_18, (copy) v_u_519, (ref) v_u_10
		if table.find(p520, p_u_516) then
			v_u_18.SetCapKey(v_u_519, v_u_10.CapText(p_u_516))
		end
	end)
	local v_u_522
	if v518 then
		v_u_522 = v_u_10.PadChanged:Connect(function(p523)
			-- upvalues: (copy) p_u_516, (ref) v_u_18, (copy) v_u_519, (ref) v_u_10
			if table.find(p523, p_u_516) then
				v_u_18.SetCapPad(v_u_519, v_u_10.PadCode(p_u_516))
			end
		end)
	else
		v_u_522 = nil
	end
	v_u_519.Destroying:Connect(function()
		-- upvalues: (copy) v_u_521, (copy) v_u_522, (ref) v_u_427, (copy) v_u_519, (ref) v_u_428
		v_u_521:Disconnect()
		if v_u_522 then
			v_u_522:Disconnect()
		end
		v_u_427[v_u_519] = nil
		v_u_428[v_u_519] = nil
	end)
	return v_u_519
end
function v_u_18.CapInfo(p524) -- name: CapInfo
	-- upvalues: (copy) v_u_431, (copy) v_u_426, (copy) v_u_428, (copy) v_u_427
	local v525 = v_u_431[p524]
	if not (v525 or v_u_426[p524]) then
		return nil
	end
	local v526 = p524:FindFirstChild("Glyph")
	local v527 = {}
	local v528
	if v525 then
		v528 = v525.key
	else
		v528 = p524:FindFirstChild("Key")
		if v528 then
			v528 = p524:FindFirstChild("Key").Text
		end
	end
	v527.key = v528
	local v529
	if v525 then
		v529 = v525.code.Name
	else
		v529 = false
	end
	v527.pad = v529
	v527.padUnbound = v_u_428[p524] == true
	v527.unbound = v_u_427[p524] == true
	v527.visible = p524.Visible
	local v530
	if v526 and v526.Visible then
		v530 = v526.Image
	else
		v530 = false
	end
	v527.glyph = v530
	return v527
end
function v_u_18.PadActionCap(p_u_531, p532) -- name: PadActionCap
	-- upvalues: (copy) v_u_18, (copy) v_u_10, (copy) v_u_428
	local v_u_533 = v_u_18.PadCap(v_u_10.PadCode(p_u_531) or Enum.KeyCode.ButtonA, p532)
	v_u_18.SetCapPad(v_u_533, v_u_10.PadCode(p_u_531))
	local v_u_535 = v_u_10.PadChanged:Connect(function(p534)
		-- upvalues: (copy) p_u_531, (ref) v_u_18, (copy) v_u_533, (ref) v_u_10
		if table.find(p534, p_u_531) then
			v_u_18.SetCapPad(v_u_533, v_u_10.PadCode(p_u_531))
		end
	end)
	v_u_533.Destroying:Connect(function()
		-- upvalues: (copy) v_u_535, (ref) v_u_428, (copy) v_u_533
		v_u_535:Disconnect()
		v_u_428[v_u_533] = nil
	end)
	return v_u_533
end
function v_u_18.Pill(p536, p537, p538) -- name: Pill
	-- upvalues: (copy) v_u_18, (copy) v_u_7, (copy) v_u_17, (copy) v_u_16
	local v539 = p538 or {}
	local v540 = v_u_18.new("Frame", {
		["Name"] = v539.Name or "Pill",
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.fromOffset(0, v539.Height or 22),
		["Position"] = v539.Position or UDim2.new(),
		["AnchorPoint"] = v539.AnchorPoint or Vector2.zero,
		["BackgroundColor3"] = p537,
		["BackgroundTransparency"] = v539.Transparency or 0.1,
		["LayoutOrder"] = v539.LayoutOrder or 0,
		["ZIndex"] = v539.ZIndex or 1,
		v_u_18.Corner(v_u_7.Radius.Pill),
		v_u_18.Padding(0, v539.PadX or 9, 0, v539.PadX or 9),
		["Parent"] = v539.Parent
	})
	v_u_18.new("TextLabel", {
		["Name"] = "Text",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Text"] = string.upper(p536),
		["FontFace"] = v539.Font or v_u_17.Heavy,
		["TextSize"] = v539.TextSize or 14,
		["TextColor3"] = v539.TextColor or v_u_16.Text,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.fromScale(0, 1),
		["ZIndex"] = v539.ZIndex or 1,
		["Parent"] = v540
	})
	return v540
end
function v_u_18.ShellAmount(p541, p542) -- name: ShellAmount
	-- upvalues: (copy) v_u_18, (ref) v_u_13, (copy) v_u_17, (copy) v_u_16
	local v543 = p542 or {}
	local v544 = v543.TextSize or 22
	local v545 = v_u_18.new("Frame", {
		["Name"] = "Shells",
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.fromOffset(0, v544 + 6),
		["LayoutOrder"] = v543.LayoutOrder or 0,
		["Position"] = v543.Position or UDim2.new(),
		["AnchorPoint"] = v543.AnchorPoint or Vector2.zero,
		["ZIndex"] = v543.ZIndex or 1,
		v_u_18.List(Enum.FillDirection.Horizontal, 5, Enum.HorizontalAlignment.Left, Enum.VerticalAlignment.Center),
		["Parent"] = v543.Parent
	})
	local v546 = v_u_18.Image
	local v547 = v_u_13.Icons.Shell
	local v548 = {
		["Name"] = "Icon",
		["Size"] = nil,
		["LayoutOrder"] = 0,
		["ZIndex"] = nil,
		["Parent"] = nil
	}
	local v549 = UDim2.fromOffset
	local v550 = v544 * 1.15
	local v551 = math.floor(v550)
	local v552 = v544 * 1.15
	v548.Size = v549(v551, (math.floor(v552)))
	v548.ZIndex = v543.ZIndex or 1
	v548.Parent = v545
	v546(v547, v548)
	local v553 = v_u_18.new("TextLabel", {
		["Name"] = "Amount",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Text"] = v_u_18.FormatNumber(p541),
		["FontFace"] = v543.Font or v_u_17.Display,
		["TextSize"] = v544,
		["TextColor3"] = v543.Color or v_u_16.Shell,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.fromScale(0, 1),
		["ZIndex"] = v543.ZIndex or 1,
		["Parent"] = v545
	})
	if v543.Stroke ~= false then
		v_u_18.TextStroke(v_u_16.Void, 2, 0.2).Parent = v553
	end
	return v545, v553
end
function v_u_18.LevelBadge(p554, p555, p556) -- name: LevelBadge
	-- upvalues: (copy) v_u_18, (copy) v_u_7, (copy) v_u_16, (copy) v_u_17
	local v557 = p556 or {}
	local v558 = v_u_18.new("Frame", {
		["Name"] = "LevelBadge",
		["Size"] = nil,
		["Position"] = nil,
		["AnchorPoint"] = nil,
		["LayoutOrder"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(p555, p555),
		["Position"] = v557.Position or UDim2.new(),
		["AnchorPoint"] = v557.AnchorPoint or Vector2.zero,
		["LayoutOrder"] = v557.LayoutOrder or 0,
		["ZIndex"] = v557.ZIndex or 1,
		["Parent"] = v557.Parent
	})
	v_u_18.new("Frame", {
		["Name"] = "Disc",
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(0.86, 0.86),
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["ZIndex"] = v557.ZIndex or 1,
		v_u_18.Corner(v_u_7.Radius.Pill),
		v_u_18.Gradient(v_u_7.Lighten(v_u_16.Accent, 0.12), v_u_16.AccentDark, 90),
		v_u_18.Stroke(v_u_16.Stroke, 1, 0.75),
		["Parent"] = v558
	})
	local v559 = v_u_18.new
	local v560 = {
		["Name"] = "Level",
		["Size"] = nil,
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Text"] = tostring(p554),
		["FontFace"] = v_u_17.Display
	}
	local v561 = p555 * (p554 >= 100 and 0.34 or 0.42)
	v560.TextSize = math.floor(v561)
	v560.TextColor3 = v_u_16.Text
	v560.ZIndex = (v557.ZIndex or 1) + 1
	v560.Parent = v558
	return v558, v559("TextLabel", v560)
end
local function v_u_578(p562, p563, p564, p565, p566, p567, p568) -- name: line
	-- upvalues: (copy) v_u_18, (copy) v_u_7
	local v569 = p564 * p563
	local v570 = p565 * p563
	local v571 = (v569 + v570) / 2
	local v572 = v570 - v569
	local v573 = v_u_18.new
	local v574 = {
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v571.X, v571.Y),
		["Size"] = UDim2.fromOffset(v572.Magnitude + p566, p566)
	}
	local v575 = v572.Y
	local v576 = v572.X
	local v577 = math.atan2(v575, v576)
	v574.Rotation = math.deg(v577)
	v574.BackgroundColor3 = p567
	v574.ZIndex = p568 or 1
	__set_list(v574, 1, {(v_u_18.Corner(v_u_7.Radius.Pill))})
	v574.Parent = p562
	v573("Frame", v574)
end
function v_u_18.Icon(p579, p580, p581, p582) -- name: Icon
	-- upvalues: (copy) v_u_16, (copy) v_u_18, (copy) v_u_578, (copy) v_u_7
	local v583 = p582 or {}
	local v584 = p581 or v_u_16.Text
	local v585 = v583.Thickness
	if not v585 then
		local v586 = p580 * 0.16 + 0.5
		local v587 = math.floor(v586)
		v585 = math.max(2, v587)
	end
	local v588 = v583.ZIndex or 1
	local v589 = v_u_18.new("Frame", {
		["Name"] = "Icon_" .. p579,
		["Size"] = UDim2.fromOffset(p580, p580),
		["Position"] = v583.Position or UDim2.new(),
		["AnchorPoint"] = v583.AnchorPoint or Vector2.zero,
		["LayoutOrder"] = v583.LayoutOrder or 0,
		["ZIndex"] = v588,
		["Parent"] = v583.Parent
	})
	local v590 = Vector2.new
	if p579 == "cross" then
		v_u_578(v589, p580, v590(0.2, 0.2), v590(0.8, 0.8), v585, v584, v588)
		v_u_578(v589, p580, v590(0.8, 0.2), v590(0.2, 0.8), v585, v584, v588)
		return v589
	end
	if p579 == "check" then
		v_u_578(v589, p580, v590(0.18, 0.52), v590(0.42, 0.76), v585, v584, v588)
		v_u_578(v589, p580, v590(0.42, 0.76), v590(0.84, 0.26), v585, v584, v588)
		return v589
	end
	if p579 == "minus" then
		v_u_578(v589, p580, v590(0.18, 0.5), v590(0.82, 0.5), v585, v584, v588)
		return v589
	end
	if p579 == "plus" then
		v_u_578(v589, p580, v590(0.5, 0.16), v590(0.5, 0.84), v585, v584, v588)
		v_u_578(v589, p580, v590(0.16, 0.5), v590(0.84, 0.5), v585, v584, v588)
		return v589
	end
	if p579 == "chevLeft" then
		v_u_578(v589, p580, v590(0.64, 0.2), v590(0.34, 0.5), v585, v584, v588)
		v_u_578(v589, p580, v590(0.34, 0.5), v590(0.64, 0.8), v585, v584, v588)
		return v589
	end
	if p579 == "chevRight" then
		v_u_578(v589, p580, v590(0.36, 0.2), v590(0.66, 0.5), v585, v584, v588)
		v_u_578(v589, p580, v590(0.66, 0.5), v590(0.36, 0.8), v585, v584, v588)
		return v589
	end
	if p579 == "chevUp" then
		v_u_578(v589, p580, v590(0.22, 0.64), v590(0.5, 0.34), v585, v584, v588)
		v_u_578(v589, p580, v590(0.5, 0.34), v590(0.78, 0.64), v585, v584, v588)
		return v589
	end
	if p579 == "chevDown" then
		v_u_578(v589, p580, v590(0.22, 0.36), v590(0.5, 0.66), v585, v584, v588)
		v_u_578(v589, p580, v590(0.5, 0.66), v590(0.78, 0.36), v585, v584, v588)
		return v589
	end
	if p579 ~= "pencil" then
		if p579 ~= "gear" then
			if p579 == "person" then
				v_u_18.new("Frame", {
					["AnchorPoint"] = Vector2.new(0.5, 0),
					["Position"] = UDim2.fromScale(0.5, 0.06),
					["Size"] = UDim2.fromScale(0.42, 0.42),
					["BackgroundColor3"] = v584,
					["ZIndex"] = v588,
					v_u_18.Corner(v_u_7.Radius.Pill),
					["Parent"] = v589
				})
				v_u_18.new("Frame", {
					["AnchorPoint"] = Vector2.new(0.5, 1),
					["Position"] = UDim2.fromScale(0.5, 1),
					["Size"] = UDim2.fromScale(0.8, 0.44),
					["BackgroundColor3"] = v584,
					["ZIndex"] = v588,
					v_u_18.Corner(UDim.new(0.45, 0)),
					["Parent"] = v589
				})
			end
			return v589
		end
		for v591 = 0, 3 do
			local v592 = v591 * 45
			local v593 = math.rad(v592)
			local v594 = v590(math.cos(v593), (math.sin(v593))) * 0.4
			local v595 = v_u_578
			local v596 = v590(0.5, 0.5) - v594
			local v597 = v590(0.5, 0.5) + v594
			local v598 = p580 * 0.2
			local v599 = math.floor(v598)
			v595(v589, p580, v596, v597, math.max(3, v599), v584, v588)
		end
		v_u_18.new("Frame", {
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromScale(0.62, 0.62),
			["BackgroundColor3"] = v584,
			["ZIndex"] = v588,
			v_u_18.Corner(v_u_7.Radius.Pill),
			["Parent"] = v589
		})
		v_u_18.new("Frame", {
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromScale(0.26, 0.26),
			["BackgroundColor3"] = v583.HoleColor or v_u_16.Panel,
			["ZIndex"] = v588,
			v_u_18.Corner(v_u_7.Radius.Pill),
			["Parent"] = v589
		})
		return v589
	end
	v_u_578(v589, p580, v590(0.3, 0.7), v590(0.76, 0.24), v585 * 1.25, v584, v588)
	local v600 = v_u_578
	local v601 = v590(0.22, 0.78)
	local v602 = v590(0.3, 0.7)
	local v603 = v585 * 0.7
	v600(v589, p580, v601, v602, math.max(1, v603), v584, v588)
	local v604 = v_u_578
	local v605 = v590(0.16, 0.9)
	local v606 = v590(0.84, 0.9)
	local v607 = v585 * 0.6
	v604(v589, p580, v605, v606, math.max(1, v607), v584, v588)
	return v589
end
local v_u_608 = Font.new("rbxasset://LuaPackages/Packages/_Index/BuilderIcons/BuilderIcons/BuilderIcons.json", Enum.FontWeight.Regular)
function v_u_18.Glyph(p609, p_u_610, p611, p612) -- name: Glyph
	-- upvalues: (copy) v_u_18, (copy) v_u_608, (copy) v_u_16
	local v613 = p612 or {}
	local v_u_614 = v_u_18.new("TextLabel", {
		["Name"] = v613.Name or "Glyph_" .. p609,
		["Text"] = p609,
		["FontFace"] = v_u_608,
		["TextSize"] = p_u_610,
		["TextColor3"] = p611 or v_u_16.Text,
		["Size"] = UDim2.fromOffset(p_u_610, p_u_610),
		["Position"] = v613.Position or UDim2.new(),
		["AnchorPoint"] = v613.AnchorPoint or Vector2.zero,
		["LayoutOrder"] = v613.LayoutOrder or 0,
		["ZIndex"] = v613.ZIndex or 1,
		["Parent"] = v613.Parent
	})
	task.delay(2, function()
		-- upvalues: (copy) v_u_614, (copy) p_u_610
		local v615 = v_u_614.TextBounds.X
		if v_u_614.Parent and p_u_610 * 1.6 < v615 then
			v_u_614.TextTransparency = 1
		end
	end)
	return v_u_614
end
function v_u_18.SelectionRing(p616, p617) -- name: SelectionRing
	-- upvalues: (copy) v_u_18, (copy) v_u_16
	local v_u_618 = v_u_18.new("Frame", {
		["Name"] = "SelectionRing",
		["Position"] = UDim2.fromOffset(-4, -4),
		["Size"] = UDim2.new(1, 8, 1, 8),
		["BackgroundTransparency"] = 1,
		v_u_18.Corner((p617 or 12) + 4),
		v_u_18.Stroke(v_u_16.Text, 3, 0)
	})
	local function v620(p619) -- name: apply
		-- upvalues: (copy) v_u_618
		if p619:IsA("GuiButton") and (p619.Selectable and p619.SelectionImageObject == nil) then
			p619.SelectionImageObject = v_u_618
		end
	end
	for _, v621 in p616:GetDescendants() do
		if not v621:IsA("GuiButton") or (not v621.Selectable or v621.SelectionImageObject ~= nil) then
			continue
		end
		v621.SelectionImageObject = v_u_618
	end
	p616.DescendantAdded:Connect(v620)
	return v_u_618
end
local v_u_622 = TweenInfo.new(0.34, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
function v_u_18.WindowCloseSize() -- name: WindowCloseSize
	-- upvalues: (copy) v_u_18
	return v_u_18.Touch and 72 or 50
end
function v_u_18.Window(p_u_623) -- name: Window
	-- upvalues: (copy) v_u_18, (copy) v_u_16, (copy) v_u_17, (copy) v_u_9, (copy) v_u_8, (copy) v_u_7, (copy) v_u_622
	local v_u_624 = v_u_18.new("Frame", {
		["Name"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Name"] = p_u_623.Name or "Window",
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = p_u_623.Parent
	})
	local v_u_625 = v_u_18.new("TextButton", {
		["Name"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["Modal"] = true,
		["Selectable"] = false,
		["Visible"] = nil,
		["Parent"] = nil,
		["Name"] = (p_u_623.Name or "Window") .. "Backdrop",
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundColor3"] = v_u_16.Void,
		["Visible"] = v_u_18.BackdropCanvas == nil,
		["Parent"] = v_u_18.BackdropCanvas or v_u_624
	})
	if v_u_18.BackdropCanvas then
		v_u_624:GetPropertyChangedSignal("Visible"):Connect(function()
			-- upvalues: (copy) v_u_625, (copy) v_u_624
			v_u_625.Visible = v_u_624.Visible
		end)
	end
	local v_u_626 = v_u_18.new("Frame", {
		["Name"] = "Holder",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = p_u_623.Size or UDim2.fromOffset(1000, 640),
		["Parent"] = v_u_624
	})
	v_u_18.DropShadow(v_u_626, 16, 8, 0.55)
	pcall(function()
		-- upvalues: (copy) v_u_626
		local v627 = v_u_626
		v627.SelectionGroup = true
		local v628 = Enum.SelectionBehavior.Stop
		local v629 = Enum.SelectionBehavior.Stop
		v627.SelectionBehaviorUp = v628
		v627.SelectionBehaviorDown = v629
		local v630 = Enum.SelectionBehavior.Stop
		local v631 = Enum.SelectionBehavior.Stop
		v627.SelectionBehaviorLeft = v630
		v627.SelectionBehaviorRight = v631
	end)
	local v_u_632 = v_u_626:FindFirstChild("FitScale")
	if not (v_u_632 and v_u_632:IsA("UIScale")) then
		v_u_632 = Instance.new("UIScale")
		v_u_632.Name = "FitScale"
		v_u_632.Parent = v_u_626
	end
	local function v_u_645() -- name: applyFit
		-- upvalues: (ref) v_u_18, (copy) v_u_626, (copy) v_u_632
		local v633 = v_u_18.CanvasSize()
		local v634 = v_u_626.Size
		local v635 = v634.X.Offset
		local v636 = v634.Y.Offset
		if v635 <= 0 or v636 <= 0 then
			v_u_632.Scale = 1
		else
			local v637 = v_u_18.TopInset()
			local v638 = v_u_632
			local v639 = (v633.X - 24) / v635
			local v640 = (v633.Y - v637 - 12) / v636
			v638.Scale = math.min(1, v639, v640)
			local v641 = v636 * v_u_632.Scale
			local v642 = v633.Y / 2
			local v643 = v637 + v641 / 2
			local v644 = math.max(v642, v643)
			v_u_626:SetAttribute("_base", UDim2.new(0.5, 0, 0, v644))
			if not v_u_626:GetAttribute("_slideTarget") then
				v_u_626.Position = UDim2.new(0.5, 0, 0, v644)
			end
		end
	end
	v_u_18.ScaleChanged:Connect(v_u_645)
	local v646 = v_u_18.Panel({
		["Name"] = "Body",
		["Size"] = nil,
		["Active"] = true,
		["BackgroundTransparency"] = 0.04,
		["StrokeTransparency"] = 0.88,
		["Radius"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Radius"] = UDim.new(0, 16),
		["Parent"] = v_u_626
	})
	local v647 = p_u_623.HeaderHeight or 78
	local v_u_648 = v_u_18.new("Frame", {
		["Name"] = "Header",
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v647),
		["Parent"] = v646
	})
	local v649 = v_u_18.DisplayText({
		["Name"] = "Title",
		["Text"] = nil,
		["TextSize"] = 36,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["StrokeThickness"] = 0,
		["Parent"] = nil,
		["Text"] = p_u_623.Title or "",
		["TextColor3"] = v_u_16.Text,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(28, 14),
		["Size"] = UDim2.new(1, -150, 0, 40),
		["Parent"] = v_u_648
	})
	local v650 = v_u_18.new("TextLabel", {
		["Name"] = "Subtitle",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 17,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = p_u_623.Subtitle or "",
		["FontFace"] = v_u_17.SemiBold,
		["TextColor3"] = v_u_16.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(30, 52),
		["Size"] = UDim2.new(1, -150, 0, 20),
		["Parent"] = v_u_648
	})
	v_u_18.new("Frame", {
		["Name"] = "Divider",
		["BackgroundColor3"] = v_u_16.Divider,
		["BackgroundTransparency"] = 0.2,
		["Size"] = UDim2.new(1, -48, 0, 2),
		["Position"] = UDim2.new(0, 24, 1, -2),
		v_u_18.Gradient(Color3.new(1, 1, 1), Color3.new(1, 1, 1), 0, NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0.4), NumberSequenceKeypoint.new(1, 1) })),
		["Parent"] = v_u_648
	})
	local v_u_651 = {
		["Root"] = nil,
		["Holder"] = nil,
		["Body"] = nil,
		["Header"] = nil,
		["Title"] = nil,
		["Subtitle"] = nil,
		["Opened"] = nil,
		["Closed"] = nil,
		["IsOpen"] = false,
		["Refit"] = nil,
		["Root"] = v_u_624,
		["Holder"] = v_u_626,
		["Body"] = v646,
		["Header"] = v_u_648,
		["Title"] = v649,
		["Subtitle"] = v650,
		["Opened"] = v_u_9.new(),
		["Closed"] = v_u_9.new(),
		["Refit"] = v_u_645
	}
	local function v_u_653() -- name: makeClose
		-- upvalues: (ref) v_u_18, (ref) v_u_16, (copy) v_u_648, (copy) p_u_623
		local v652 = v_u_18.WindowCloseSize()
		return v_u_18.IconButton({
			["Name"] = "Close",
			["IconName"] = "cross",
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Color"] = nil,
			["HoverColor"] = nil,
			["Sound"] = "Close",
			["Parent"] = nil,
			["OnClick"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, -14, 0, 12),
			["Size"] = UDim2.fromOffset(v652, v652),
			["Color"] = v_u_16.Raised,
			["HoverColor"] = v_u_16.Danger,
			["Parent"] = v_u_648,
			["OnClick"] = function() -- name: OnClick
				-- upvalues: (ref) p_u_623
				if p_u_623.OnCloseRequested then
					p_u_623.OnCloseRequested()
				end
			end
		})
	end
	local v_u_654 = v_u_653()
	v_u_651.CloseButton = v_u_654
	v_u_18.TouchChanged:Connect(function()
		-- upvalues: (ref) v_u_654, (copy) v_u_653, (copy) v_u_651
		v_u_654:Destroy()
		v_u_654 = v_u_653()
		v_u_651.CloseButton = v_u_654
	end)
	v_u_651.Content = v_u_18.new("Frame", {
		["Name"] = "Content",
		["Position"] = UDim2.fromOffset(0, v647),
		["Size"] = UDim2.new(1, 0, 1, -v647),
		v_u_18.Padding(14, 22, 18, 22),
		["Parent"] = v646
	})
	local v_u_655 = 0
	local v_u_656 = false
	v_u_625.InputBegan:Connect(function(p657)
		-- upvalues: (ref) v_u_656
		local v658 = p657.UserInputType
		if v658 == Enum.UserInputType.MouseButton1 or v658 == Enum.UserInputType.Touch then
			v_u_656 = true
		end
	end)
	v_u_625.Activated:Connect(function()
		-- upvalues: (ref) v_u_655, (ref) v_u_656, (copy) p_u_623, (ref) v_u_8
		if os.clock() - v_u_655 >= 0.4 and v_u_656 then
			if p_u_623.CloseOnBackdrop ~= false and p_u_623.OnCloseRequested then
				v_u_8.Play("Close")
				p_u_623.OnCloseRequested()
			end
		end
	end)
	local v_u_659 = 0
	function v_u_651.Open(p660) -- name: Open
		-- upvalues: (ref) v_u_655, (ref) v_u_656, (ref) v_u_659, (copy) v_u_624, (copy) v_u_625, (ref) v_u_18, (ref) v_u_7, (copy) p_u_623, (copy) v_u_645, (copy) v_u_626, (ref) v_u_622, (ref) v_u_8
		if not p660.IsOpen then
			p660.IsOpen = true
			v_u_655 = os.clock()
			v_u_656 = false
			v_u_659 = v_u_659 + 1
			v_u_624.Visible = true
			v_u_625.BackgroundTransparency = 1
			v_u_18.Tween(v_u_625, v_u_7.Tween.Smooth, {
				["BackgroundTransparency"] = p_u_623.DimTransparency or 0.4
			})
			v_u_645()
			local v661 = v_u_626:GetAttribute("_base")
			local v662 = v_u_18.SlideIn
			local v663 = v_u_626
			local v664 = Vector2.new(0, 50)
			local v665 = v_u_622
			if typeof(v661) ~= "UDim2" then
				v661 = UDim2.fromScale(0.5, 0.5)
			end
			v662(v663, v664, v665, v661)
			v_u_8.Play(p_u_623.OpenSound or "Open")
			p660.Opened:Fire()
		end
	end
	function v_u_651.Close(p666, p667) -- name: Close
		-- upvalues: (ref) v_u_659, (copy) v_u_624, (ref) v_u_18, (copy) v_u_625, (ref) v_u_7, (copy) v_u_626
		if p666.IsOpen then
			p666.IsOpen = false
			v_u_659 = v_u_659 + 1
			local v_u_668 = v_u_659
			p666.Closed:Fire()
			if p667 then
				v_u_624.Visible = false
			else
				v_u_18.Tween(v_u_625, v_u_7.Tween.Close, {
					["BackgroundTransparency"] = 1
				})
				local v669 = v_u_626:GetAttribute("_base")
				if typeof(v669) ~= "UDim2" then
					v669 = UDim2.fromScale(0.5, 0.5)
				end
				v_u_18.Tween(v_u_626, v_u_7.Tween.Close, {
					["Position"] = v669 + UDim2.fromOffset(0, 30)
				})
				task.delay(0.15, function()
					-- upvalues: (ref) v_u_659, (copy) v_u_668, (ref) v_u_624
					if v_u_659 == v_u_668 then
						v_u_624.Visible = false
					end
				end)
			end
		else
			return
		end
	end
	return v_u_651
end
function v_u_18.SectionTitle(p670, p671) -- name: SectionTitle
	-- upvalues: (copy) v_u_18, (copy) v_u_16, (copy) v_u_17
	local v672 = p671 or {}
	local v673 = v_u_18.new("Frame", {
		["Name"] = "Section",
		["Size"] = nil,
		["Position"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Size"] = v672.Size or UDim2.new(1, 0, 0, 24),
		["Position"] = v672.Position or UDim2.new(),
		["LayoutOrder"] = v672.LayoutOrder or 0,
		["Parent"] = v672.Parent
	})
	v_u_18.new("Frame", {
		["BackgroundColor3"] = v672.Color or v_u_16.Accent,
		["Size"] = UDim2.fromOffset(4, 16),
		["Position"] = UDim2.fromOffset(0, 4),
		v_u_18.Corner(2),
		["Parent"] = v673
	})
	v_u_18.new("TextLabel", {
		["Name"] = "Text",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = string.upper(p670),
		["FontFace"] = v_u_17.Heavy,
		["TextSize"] = v672.TextSize or 16,
		["TextColor3"] = v672.TextColor or v_u_16.TextDim,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(12, 0),
		["Size"] = UDim2.new(1, -12, 1, 0),
		["Parent"] = v673
	})
	return v673
end
function v_u_18.Every(p_u_674, p_u_675, p_u_676) -- name: Every
	-- upvalues: (copy) v_u_4
	local v_u_677 = 0
	local v_u_678 = nil
	v_u_678 = v_u_4.Heartbeat:Connect(function(p679)
		-- upvalues: (copy) p_u_674, (ref) v_u_678, (ref) v_u_677, (copy) p_u_675, (copy) p_u_676
		if p_u_674.Parent then
			v_u_677 = v_u_677 + p679
			if p_u_675 <= v_u_677 then
				v_u_677 = 0
				p_u_676()
			end
		else
			v_u_678:Disconnect()
		end
	end)
	return v_u_678
end
return v_u_18