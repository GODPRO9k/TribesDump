local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent:WaitForChild("Effects"))
local v_u_5 = require(script.Parent:WaitForChild("Characters"))
local v_u_6 = require(script.Parent:WaitForChild("Perf"))
local v_u_7 = require(script.Parent:WaitForChild("Quality"))
local v8 = {}
local v_u_9 = {
	[Enum.Material.Grass] = "Grass",
	[Enum.Material.LeafyGrass] = "Grass",
	[Enum.Material.Ground] = "Dirt",
	[Enum.Material.Mud] = "Dirt",
	[Enum.Material.Sand] = "Sand",
	[Enum.Material.Salt] = "Grass",
	[Enum.Material.Snow] = "Snow",
	[Enum.Material.Glacier] = "Snow",
	[Enum.Material.Ice] = "Snow",
	[Enum.Material.Wood] = "Wood",
	[Enum.Material.WoodPlanks] = "Wood",
	[Enum.Material.Metal] = "Metal",
	[Enum.Material.DiamondPlate] = "Metal",
	[Enum.Material.CorrodedMetal] = "Metal",
	[Enum.Material.Foil] = "Metal",
	[Enum.Material.Water] = "Water",
	[Enum.Material.Fabric] = "Soft",
	[Enum.Material.Carpet] = "Soft",
	[Enum.Material.Leather] = "Soft",
	[Enum.Material.Cardboard] = "Wood",
	[Enum.Material.Slate] = "Stone",
	[Enum.Material.Cobblestone] = "Stone",
	[Enum.Material.Rock] = "Stone",
	[Enum.Material.Basalt] = "Dirt",
	[Enum.Material.Limestone] = "Stone",
	[Enum.Material.Sandstone] = "Stone",
	[Enum.Material.Granite] = "Stone",
	[Enum.Material.Brick] = "Stone",
	[Enum.Material.Pavement] = "Stone",
	[Enum.Material.Concrete] = "Stone",
	[Enum.Material.Marble] = "Stone",
	[Enum.Material.CrackedLava] = "Stone"
}
local v_u_10 = {}
local v_u_11 = v1.LocalPlayer
local v_u_12 = RaycastParams.new()
v_u_12.FilterType = Enum.RaycastFilterType.Exclude
v_u_12.IgnoreWater = false
function v8.SurfaceFor(p13) -- name: surfaceFor
	-- upvalues: (copy) v_u_9
	return v_u_9[p13] or "Stone"
end
local function v_u_16(p14) -- name: stepSoundName
	local v15 = game:GetService("ReplicatedStorage"):FindFirstChild("Assets")
	if v15 then
		v15 = v15:FindFirstChild("Sounds")
	end
	if v15 then
		v15 = v15:FindFirstChild("Character")
	end
	if v15 then
		if v15:FindFirstChild("Footstep_" .. p14) then
			return "Footstep_" .. p14
		end
		if v15:FindFirstChild("Footstep_Stone") then
			return "Footstep_Stone"
		end
	end
	return "Footstep"
end
v8.StepSoundName = v_u_16
local v_u_17 = {
	["Running"] = true,
	["Landing"] = true,
	["Jumping"] = true,
	["FreeFalling"] = true,
	["GettingUp"] = true
}
local function v_u_23(p18) -- name: muteDefaultSounds
	-- upvalues: (copy) v_u_17
	local v19 = p18:WaitForChild("HumanoidRootPart", 10)
	if v19 then
		local function v21(p_u_20) -- name: mute
			-- upvalues: (ref) v_u_17
			if p_u_20:IsA("Sound") and v_u_17[p_u_20.Name] then
				p_u_20.Volume = 0
				p_u_20:GetPropertyChangedSignal("Volume"):Connect(function()
					-- upvalues: (copy) p_u_20
					if p_u_20.Volume ~= 0 then
						p_u_20.Volume = 0
					end
				end)
			end
		end
		for _, v22 in v19:GetChildren() do
			v21(v22)
		end
		v19.ChildAdded:Connect(v21)
	end
end
local v_u_24 = {}
local v_u_25 = 0
local function v_u_46(p26, p27, p28, p29, p30) -- name: step
	-- upvalues: (copy) v_u_11, (ref) v_u_25, (copy) v_u_7, (copy) v_u_24, (copy) v_u_12, (copy) v_u_3, (copy) v_u_9, (copy) v_u_4, (copy) v_u_16
	local v31 = p26 == v_u_11.Character
	if v31 or v_u_25 < v_u_7.budget.maxSteps then
		local v32 = p27:GetAttribute("SWade")
		if type(v32) == "number" and v32 >= 0.3 then
			return
		else
			local v33 = p27.Position
			local v34 = p28.HipHeight + p27.Size.Y / 2
			local v35 = v33 - Vector3.new(0, v34, 0)
			local v36
			if v31 and p28.FloorMaterial ~= Enum.Material.Air then
				v36 = p28.FloorMaterial
			else
				v_u_24[1] = p26
				v_u_12.FilterDescendantsInstances = v_u_24
				local v37 = v_u_3
				local v38 = p27.Position
				local v39 = -(p28.HipHeight + p27.Size.Y / 2 + 1.5)
				local v40 = v37:Raycast(v38, Vector3.new(0, v39, 0), v_u_12)
				if not v40 then
					return
				end
				v36 = v40.Material
				v35 = v40.Position
			end
			local v41 = v_u_9[v36] or "Stone"
			if v41 ~= "Water" then
				local v42 = p30 > 23
				local v43 = (v42 and 1 or 0.8) * (v31 and 0.55 or 1)
				p29.leftFoot = not p29.leftFoot
				local v44 = p27.CFrame.RightVector * (p29.leftFoot and -0.5 or 0.5)
				local v45 = v_u_4.PlaySoundAt(v_u_16(v41), v35 + v44, {
					["volume"] = nil,
					["pitchVar"] = 0.09,
					["speed"] = nil,
					["maxDistance"] = 90,
					["volume"] = v43,
					["speed"] = v42 and 1.05 or 1
				})
				if v45 then
					v_u_25 = v_u_25 + 1
					v45.Destroying:Once(function()
						-- upvalues: (ref) v_u_25
						v_u_25 = v_u_25 - 1
					end)
				end
				if v42 and (v41 == "Dirt" or (v41 == "Sand" or v41 == "Snow")) and (math.random() < 0.5 and (v31 or v_u_7.budget.remoteDust)) then
					v_u_4.Dust(v35 + v44, 0.35, v_u_4.DustColor(v36))
				end
			end
		end
	else
		return
	end
end
local v_u_47 = {}
local v_u_48 = 90
local v_u_49 = 0
local function v_u_95(p50) -- name: update
	-- upvalues: (copy) v_u_7, (ref) v_u_49, (copy) v_u_3, (copy) v_u_11, (ref) v_u_48, (copy) v_u_47, (copy) v_u_5, (copy) v_u_10, (copy) v_u_23, (copy) v_u_4, (copy) v_u_46
	local v51 = v_u_7.budget
	v_u_49 = v_u_49 + p50
	local v52 = v_u_49 >= 1 / v51.remoteHz
	local v53 = v_u_49
	if v52 then
		v_u_49 = 0
	end
	local v54 = v_u_3.CurrentCamera
	local v55 = not v54 and Vector3.new(0, 0, 0) or v54.CFrame.Position
	local v56 = v_u_11.Character
	local v57 = v_u_48 * v_u_48
	table.clear(v_u_47)
	local v58 = 0
	for _, v59 in v_u_5.List() do
		v_u_47[v59] = true
		local v60 = v59 == v56
		if not (v60 or v52) then
			continue
		end
		local v61
		if v60 then
			v61 = p50
		else
			v61 = v53
		end
		local v62 = v_u_10[v59]
		if not v62 then
			v62 = {
				["humanoid"] = nil,
				["root"] = nil,
				["distance"] = 0,
				["lastPos"] = nil,
				["lastVy"] = 0,
				["airTime"] = 0,
				["leftFoot"] = false
			}
			v_u_10[v59] = v62
			task.spawn(v_u_23, v59)
		end
		local v63 = v62.humanoid
		local v64 = v62.root
		if not v63 or v63.Parent ~= v59 then
			v63 = v59:FindFirstChildOfClass("Humanoid")
			v62.humanoid = v63
		end
		if not v64 or v64.Parent ~= v59 then
			v64 = v59:FindFirstChild("HumanoidRootPart")
			if not (v64 and v64:IsA("BasePart")) then
				v64 = nil
			end
			v62.root = v64
		end
		if not v63 or (not v64 or v63.Health <= 0) then
			continue
		end
		local v65 = v64.Position
		local v66 = v59 == v56
		local v67 = v65 - v55
		if v66 then
			::l38::
			local v68 = v64.AssemblyLinearVelocity
			local v69 = v68.X
			local v70 = v68.Z
			local v71 = Vector3.new(v69, 0, v70).Magnitude
			local v72
			if v66 then
				v72 = v63.FloorMaterial ~= Enum.Material.Air
			else
				local v73 = v63:GetState()
				local v74 = v68.Y
				if math.abs(v74) < 6 and (v73 ~= Enum.HumanoidStateType.Freefall and v73 ~= Enum.HumanoidStateType.Jumping) then
					v72 = v73 ~= Enum.HumanoidStateType.Swimming
				else
					v72 = false
				end
			end
			if not v66 then
				if v72 then
					if v62.airTime > 0.35 and v62.lastVy < -30 then
						local v75 = v63.HipHeight + v64.Size.Y / 2
						local v76 = v65 - Vector3.new(0, v75, 0)
						local v77 = -v62.lastVy
						if v77 > 72 then
							local v78 = (v77 - 64) / 60
							local v79 = math.clamp(v78, 0, 1)
							if v51.remoteDust then
								v_u_4.Dust(v76, v79 * 1.4 + 0.6, v_u_4.DustColor(nil))
							end
							v_u_4.PlaySoundAt(v79 > 0.5 and "LandHeavy" or "Land", v76, {
								["volume"] = nil,
								["pitchVar"] = 0.06,
								["maxDistance"] = 90,
								["volume"] = v79 * 0.6 + 0.35
							})
						else
							v_u_46(v59, v64, v63, v62, 16)
						end
						v62.airTime = 0
					else
						v62.airTime = 0
					end
				else
					v62.airTime = v62.airTime + v61
				end
				v62.lastVy = v68.Y
			end
			local v80
			if v66 then
				v80 = v59:GetAttribute("Sliding") == true
			else
				v80 = v71 > 30
			end
			if v72 and (v71 > 2 and not v80) then
				local v81
				if v62.lastPos then
					local v82 = v65.X
					local v83 = v65.Z
					local v84 = Vector3.new(v82, 0, v83)
					local v85 = v62.lastPos.X
					local v86 = v62.lastPos.Z
					v81 = (v84 - Vector3.new(v85, 0, v86)).Magnitude
				else
					v81 = 0
				end
				if v81 < 10 then
					v62.distance = v62.distance + v81
				end
				if (v71 > 15 and 5.2 or 3.9) <= v62.distance then
					v62.distance = 0
					v_u_46(v59, v64, v63, v62, v71)
				end
			else
				local v87 = v62.distance
				v62.distance = math.min(v87, 2.34)
			end
			v62.lastPos = v65
		else
			if v57 >= v67.X * v67.X + v67.Y * v67.Y + v67.Z * v67.Z then
				v58 = v58 + 1
				goto l38
			end
			v62.lastPos = v65
		end
	end
	if v52 then
		for v88 in v_u_10 do
			if v_u_47[v88] then
				continue
			end
			v_u_10[v88] = nil
		end
	end
	if v52 then
		local v89 = v51.stepCap
		if v89 < v58 then
			local v90 = v_u_48 * 0.92
			v_u_48 = math.max(30, v90)
		elseif v58 < v89 * 0.7 then
			local v91 = v51.stepRadius
			local v92 = v_u_48 + v53 * 20
			v_u_48 = math.min(v91, v92)
		end
		local v93 = v_u_48
		local v94 = v51.stepRadius
		v_u_48 = math.min(v93, v94)
	end
end
function v8.Start() -- name: Start
	-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_95
	v_u_2.Heartbeat:Connect(function(p96)
		-- upvalues: (ref) v_u_6, (ref) v_u_95
		local v97 = v_u_6.Begin()
		v_u_95(p96)
		v_u_6.End("Footsteps", v97)
	end)
end
return v8